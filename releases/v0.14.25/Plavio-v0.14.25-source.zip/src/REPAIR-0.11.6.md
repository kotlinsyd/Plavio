# Plavio 0.11.6: account and Live repair

## Publishing is not the fix

Uploading the project to GitLab or GitHub does not change the configuration or player code already installed on a phone. A repository can distribute a corrected build, but publishing alone cannot make a rejected API configuration valid or fix playback.

This mobile-only candidate is derived from the exact supplied `Plavio-0.11.5-mobile-source.zip`. It is version 0.11.6, versionCode 87, package `com.pulsestream.app`. No production service, addon, deployment or repository was changed.

## Account login: better diagnosis, not a claimed backend repair

Offline comparison confirmed that the delivered 0.11.5 APK and source contain matching cloud endpoint and public client configuration. The endpoint is HTTPS and not a placeholder. The public client JWT declares the anon role, its project reference matches the configured host, and its declared expiry is not past as of this task. These are consistency checks only: they do not verify the signature, current gateway acceptance, whether legacy keys are enabled, or whether this is the intended cloud project.

No account request was made. An explicit API-key rejection would indicate a rejected app/API configuration, not an incorrect account password. A disabled, rotated or otherwise invalid public client key still needs the maintainer to verify the intended project's currently accepted public configuration through their authorized deployment process. This candidate leaves the endpoint and key unchanged; it does not claim to fix login.

`CloudManager.kt` now performs local configuration preflight and uses `CloudAuthErrors.kt` to distinguish explicit API-key rejection and missing auth routes from ordinary credential failures, email verification, rate limits and temporary server errors. Raw provider errors are no longer echoed to the screen.

## Live: reproduced compatibility defects

Three compatibility gaps were reproduced with local fixtures:

1. **IPTV URL headers were not extracted.** A stream written as `https://cdn.example/live.m3u8|User-Agent=FixtureAgent&Referer=https%3A%2F%2Fportal.example%2F` was copied wholesale into the player URL. The required headers were not separated into request headers. `StremioParser.kt` now extracts a fully well-formed header suffix while preserving the actual URL and signed query. Malformed suffixes remain untouched. Explicit header objects override proxy headers, which override embedded URL headers; this precedence is now case-insensitive.
2. **Encoded playlist extensions were missed.** Full-URL MIME detection did not recognize encoded punctuation such as `%2Em3u8` or `%2Empd`. `PlaybackHeaders.kt` now decodes a detection-only copy. The actual playback URL is not rewritten.
3. **Range-rejecting gateways could not recover their format.** If HEAD was unsupported or generic and the small ranged GET returned 400, 405 or 416, MIME recovery stopped even when an ordinary GET would return a playlist. `PlaybackContentProbe.kt` now retries an ordinary GET, reads at most the same 4 KiB prefix and closes the response. It does not retry 401/403 as a range workaround.

These defects can explain failures for compatible provider response shapes. They do not establish which defect affects the owner's actual sports addon, whose real response and device playback were not examined.

## What the trace found working

Catalog and metadata entries without a type already inherit the catalog/request type. Live passes that type through `TvChannelRef` into the stream request. The addon API builds escaped resource path segments and retains configured query parameters. Live accepts direct HTTP(S) candidates; RTMP and other unsupported schemes are not made playable by this repair. The channel-to-player request retains URL, headers, MIME hint, source list and originating channel.

Live's initial channel selection does not use the separate Plavio Pick reachability scorer to approve or reject a channel. The MIME probe is format-error recovery in the player, not the initial Live catalog resolver.

The Nuvio-derived default User-Agent and existing validated header policy are retained. Unsafe and hop-by-hop headers remain blocked. Sensitive addon headers remain origin-scoped across redirects and media subresources; no CDN allowlist or credential forwarding exception was added. Platform TLS validation and the HTTPS-to-HTTP redirect prohibition are unchanged. A provider requiring sensitive headers across different origins may still fail under this deliberate protection; that requires evidence and a separate narrowly scoped design decision, not a blanket bypass.

## Verification and remaining phone check

Final local validation results are recorded in `docs/validation-summary.txt` and `docs/verified-build.log`. Regression comparison details are in `docs/original-regressions.json` once the final gates complete.

`PlaybackHandoffTest.kt` uses Robolectric and actual Media3 source factories plus the playback HTTP data source against loopback fixtures. It checks HLS/DASH source selection, manifest transport, exact encoded URL preservation, probe/player header parity, cross-origin header stripping and unsupported-transport rejection. It does not run a real provider, full manifest/segment playback, Android hardware decoding, or phone playback.

The owner should install this as an update over the earlier debug APK and test the same failing sports channel. If it still fails, useful non-secret evidence is: one or two channel names; addon name/version; comparison app name; phone model and Android version; and the exact on-screen playback error/code. For login, provide the exact on-screen message or a screenshot with email and personal data hidden. Do not send passwords, API-key values, full configured addon URLs, signed stream URLs, cookies or header values. A sanitized provider response shape with URL scheme/extension and header names only can help identify an unsupported transport or header format.

The inherited ARM FFmpeg binaries are unchanged. Their existing 4 KiB alignment limitation remains; this is a debug testing build, not a production/native release certification. No TV build or TV test was run.
