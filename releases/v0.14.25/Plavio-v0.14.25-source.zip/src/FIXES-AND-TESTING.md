# Plavio 0.11.5 — mobile test delivery

This is an isolated follow-up to the supplied **0.11.4** source, version **0.11.5 (86)**. It is a debug build for owner testing—not a production-release certification. No TV variant was built or tested. No GitLab push, deployment, production addon/provider change, or live backend modification was made.

## Your requested changes

Checked means the app-side change is implemented. Phone/provider checks are listed separately and are not silently counted as complete.

- [x] **One release name and one metadata presentation.** Compact, detail and in-player source rows share normalized display data. Repeated filename/title lines and already-displayed size/quality/codec details are suppressed without collapsing genuinely different stream options.
- [x] **Live catalog and source handling.** Live discovery accepts supported channel/catalog types instead of assuming only `tv`; channel identity retains its originating addon, catalog and resource type. Resolution and channel switching use that type, retain request headers and MIME hints, and exclude unplayable placeholders.
- [x] **Extensionless Live recovery.** A bounded format probe uses the same scoped playback transport, handles HEAD-rejecting gateways with a small GET, rejects HTML/error responses, and cannot apply an old probe result to a newly selected channel. User-configured HTTP IPTV is permitted; normal HTTPS certificate validation remains enabled.
- [x] **TorBox cached resolution.** Cached readiness follows the documented status flags, exact file index/path survives parsing and resolution, ambiguous season-pack selection fails safely, and standard magnet hashes can enter the existing cached-debrid pipeline. Unresolved entries cannot launch playback or downloads. No owner TorBox account was queried.
- [x] **Compact, poster-free player Sources.** A single scroll area contains the small heading, addon/quality filters and source rows. Partial playback handoffs continue loading other addons; late results merge without replacing the complete list. Every loaded source remains reachable in the player rather than being silently cut to the detail picker's per-addon limit. Play and Download remain separate.
- [x] **Settings cleanup only where requested.** Removed the Settings-only Downloads shortcut, kept main Downloads navigation, removed only the obsolete install-counter wording, and hid manual Backup & Restore navigation in favor of Account sync. Existing optional telemetry controls remain.
- [x] **Opt-in encrypted cross-device configuration.** Supported integration keys and complete configured addon URLs—including credentials in paths, queries and user information—can be synced in an authenticated, passphrase-encrypted envelope bound to the account/profile. Ordinary snapshots do not contain those private URL components. Locked configurations stay disabled until unlocked; successful private restore reinstates the exact URL and intended enabled state.
- [x] **Safe startup improvement.** Fresh playback handoffs can start silent preparation before waiting on saved-position storage. Potentially stale Continue Watching URLs still wait for the existing refresh/seek path. Buffer/cache sizes, codec preferences and provider behavior were not aggressively changed. This is a removed ordering delay, not a measured phone speedup.
- [x] **Liquid Glass-inspired mobile polish.** Shared glass panes use restrained highlights and a legible tinted fill without blur/animation overhead. Shared controls have explicit minimum touch sizes and disabled-state treatment. Downloads uses matching glass action buttons; Wi-Fi-only is a clearly labeled top control above the list/empty state, with its existing setting and queue behavior preserved.
- [x] **Small extra:** the active source now has a clear **Playing** badge and selected semantics, so it is easier to recognize while browsing alternatives.
- [x] **Preserved the OnePlus audio path and native binaries.** The active renderer still directs Dolby/EAC3-family formats to the FFmpeg extension rather than the problematic hardware route.
- [ ] **Live-provider success, phone smoothness and OnePlus sound:** require the owner's actual phone/provider tests. Local fixtures cannot establish these outcomes.
- [ ] **FFmpeg 16 KiB rebuild:** remains blocked by missing exact source/build provenance and reliable device decode verification. No guessed decoder was substituted.

## Why the reported problems could persist

The earlier picker fix did not fully cover overlapping multiline provider payloads and every source-card mode. The new shared display model handles those cases, including repeated technical metadata.

Live had several independent app-side assumptions: restricted catalog types, hard-coded stream resource identity, incomplete propagation of format hints, and a less-compatible format-recovery transport. These are corrected locally. A provider can still fail because of authorization, expired links, network/CDN policy, unsupported media or its own response. Working in Nuvio TV does not by itself establish which of these applies to the owner's exact channel.

TorBox also needed response-contract and file-selection handling beyond the display fix. The implementation was checked against the [official TorBox API documentation](https://api-docs.torbox.app/) and [official torrent SDK documentation](https://github.com/TorBox-App/torbox-sdk-js/blob/main/documentation/services/TorrentsService.md); tests use isolated fixtures, not a live paid account.

## Validation

- **Mobile APK build:** passed.
- **Regression tests:** 201 passed across 42 suites; zero failures, errors or skipped tests.
- **Mobile lint:** zero errors/fatal findings; 113 warnings remain.
- **Integrity:** APK signature and 4-byte ZIP alignment verified; debug signer matches the delivered 0.11.4 APK. Source credential-pattern scan passed.
- **Native check:** intentionally still fails 16 KiB compatibility. Both packaged FFmpeg binaries match the original 0.11.4 source byte-for-byte.
- Build logs, dependency inventory, native evidence and validation summaries are included under `docs/` in the source ZIP.

Automated tests cover source-label duplication, compact landscape source scrolling and separate actions, complete progressive source merging, addon Live routing/headers, format-probe redirects and HTML rejection, cached torrent/file identity, encrypted credential envelopes, real-database addon URL redaction/restore, and Downloads control placement/accessibility. The inherited migration, backup, subtitle, network and library tests remain in the suite.

These are local JVM/Robolectric and loopback/mocked tests, not a physical-phone or production-provider test. Secret-pattern scanning is heuristic, not a proof that no possible secret exists. Lint warnings are not claimed resolved.

## The 31-item audit

“Implemented” includes fixes inherited from 0.11.4 and retained in this build. It does not mean all external acceptance tests are complete.

| # | Audit item | Delivery status / remaining check |
|---|---|---|
| 1 | Upgrade migration registration | Implemented; historical migration tests retained. Upgrade an installed phone without uninstalling. |
| 2 | Custom-list migration loss | Row-preserving migrations and regression tests retained; verify real list names/membership after upgrade. |
| 3 | Process-wide insecure TLS | Global trust-all override removed; normal TLS retained. Invalid certificates must fail. |
| 4 | Credentials in ordinary backups | Keystore-backed local secrets, OS-backup exclusions, private URL redaction and deliberate encrypted credential sync implemented. Two-device/backend checks remain. |
| 5 | Malformed/non-atomic restore | Strict validation, Room replacement transaction and ordinary-failure preference rollback retained; private URL rollback added. Sudden power loss across separate stores is not certified atomic. |
| 6 | Bundled addon configuration overwritten | Only known legacy origins migrate; arbitrary configured endpoints are retained at startup. Test restart with the owner's addons. |
| 7 | Duplicate source filename | Expanded normalization/shared presentation implemented and regression-covered. |
| 8 | Wrong torrent episode/file | File identity preserved; exact selection and ambiguous-pack rejection covered locally. Test both debrid services on real season packs. |
| 9 | Adaptive offline download | Safe rejection/labeling implemented. Complete offline HLS/DASH remains unsupported—not falsely marked complete. |
| 10 | Unsafe download resume | Range/validator/storage checks and interrupted-job handling retained. Test force-stop, changed files and offline playback. |
| 11 | Subtitle timing | Format/offset and title-reset fixes retained; transformations use background work. Test the owner's subtitle formats. |
| 12 | Header/failure route differences | Shared normalized headers and origin scoping retained; compatible bounded MIME recovery added. Real protected-source matrix remains. |
| 13 | M3U URL corruption | Actual request URL is separate from its comparison/cache key. Basic-auth/IPv6/slash-sensitive endpoint tests still need provider/device acceptance. |
| 14 | Silent trailer fallback | Structured split video/audio playback retained; current trailer-provider verification remains. |
| 15 | Profile library mixing | Replace-and-switch/recovery retained; local private URL recovery added. Real profile isolation/conflicts remain to be verified. |
| 16 | Incomplete backup coverage | Versioned lists/settings/library schema retained; encrypted integration/addon configuration added. Downloads, permissions and login sessions are deliberately not portable. |
| 17 | Token expiry/hidden sync errors | Serialized refresh/rotation and visible status retained. Live auth rotation, authorization, RLS and deletion are unverified. |
| 18 | Disabled-provider caches | Provider-derived cache invalidation retained, including after private configuration restore. |
| 19 | Catalog freshness/stale rows | Success-based refresh/pruning and known-good failure handling retained. |
| 20 | Lost partial search results | Independent provider budgets, cumulative results and query-associated UI retained. |
| 21 | Networking limits/cancellation | Bounded/cancellable shared addon/TMDB transport retained; not every third-party client was rewritten. |
| 22 | Character-based cache limit | UTF-8 byte caps and legacy BLOB-size pruning retained; regression-covered. |
| 23 | TMDB timeout/empty cast | Bounded lookup and nonempty-cast fallback retained. |
| 24 | Actor detail routing | Shared TMDB conversion/detail routing retained; live metadata acceptance remains. |
| 25 | Duplicate login while syncing | Authentication/sync disables resubmission; profile/auth/private import operations are serialized. |
| 26 | Phone accessibility | Responsive layouts, reduced motion and larger controls retained; Downloads/shared control tests added. TalkBack, 200% text and real touch/contrast testing remain. |
| 27 | Privacy copy | Bundled README/policy updated for actual backup rules, optional accounts/telemetry and encrypted private configuration. Public policy and retention settings were not deployed or backend-verified. |
| 28 | Mobile lint | See the fresh result above; warnings and physical acceptance are separate from lint. |
| 29 | Native compatibility/provenance | **Blocked:** inherited FFmpeg binaries remain 4 KiB-aligned and lack corresponding source/build provenance. Known audio path preserved; no replacement guessed. |
| 30 | Release checks/notices | Wrapper/dependency inventory, mobile gates, secret scanning and signing checks retained. Owner production signing, native provenance/licensing and 16 KiB runtime verification remain release blockers. |
| 31 | Website release selection | Bundled stable-mobile validation retained; no website/release deployment. Unpublished test APKs are not falsely advertised as a public stable release. |

## OnePlus 13R and FFmpeg: what is verified

Media3 is pinned to **1.4.1**. The active `PlavioAudioRenderersFactory` uses `NoHardwareDolbySelector` to exclude hardware MediaCodec selections for EAC3/JOC, AC3, DTS/DTS-HD and TrueHD and prefer the FFmpeg audio extension. Its output is PCM; this is not a promise of Atmos/passthrough output.

Both bundled ARM binaries contain exported AC3, EAC3, DTS, TrueHD and MLP decoder symbols. That shows compiled decoder code—not successful runtime decoding or correct phone/channel output. Both original binaries are preserved byte-for-byte, with their known audio-fix path intact. Their load segments remain aligned to **4 KiB**, not the required 16 KiB gate.

A safe rebuild needs the matching FFmpeg source commit/archive and patches; JNI/Media3 integration source; original decoder/configuration flags; Android NDK/Clang versions and per-ABI commands; and representative authorized EAC3/JOC/AC3/DTS/TrueHD samples with expected output. Then verify both ARM ABIs, packaging alignment, actual decode/channel output, and the OnePlus 13R plus a 16 KiB-page Android environment. The source ZIP contains the detailed provenance note and a read-only native inventory script. Installing a random newer decoder or changing Java buffering does not solve this safely.

## First tests on your phone

1. **Update without uninstalling.** Confirm version 0.11.5, launch, configured addons, watchlist, history and custom lists. The debug signer matches the earlier delivered debug APK; it is not the owner's production-release key. Do not uninstall an important installation merely to bypass a signer conflict.
2. **Sources and Live.** Compare duplicated labels on the same releases, open Sources in landscape, scroll to the last entry, change addon/quality filters and test Play versus Download separately. Try the exact channels that work in Nuvio; verify channel switching, headers, HTTP/HTTPS and extensionless HLS/DASH behavior.
3. **TorBox.** Use known cached movie and two different season-pack episodes. Confirm the requested episode plays and unresolved/error entries do not launch. No live-account success is claimed by the local tests.
4. **Audio and speed.** On the OnePlus 13R, try the previously silent high-quality EAC3/Dolby source first, then representative AC3/DTS/TrueHD and ordinary AAC. Check audible output, sync/channel behavior, startup, resume, source switching, seeking and PiP. Report whether slowness is startup, ongoing buffering or UI interaction.
5. **Encrypted cross-device sync.** Use this build on both devices. In Account, enable private configuration sync with a strong passphrase and finish a backup before switching devices. On the second device, restore the profile, then unlock with the same passphrase. Check exact addon configuration/enabled state and integration keys without re-entering them. A wrong passphrase must change nothing. Do not rely on older clients to preserve the new encrypted field; two-device conflicts and backend/RLS are not certified here.
6. **Downloads and UI.** Check the top Wi-Fi-only control, Wi-Fi loss/reconnection, existing pause/resume/play/delete actions, a progressive offline file, and an unsupported adaptive source. Inspect small-screen/landscape layout, enlarged text, TalkBack and glass contrast. No heavier buffering was introduced.

The release recommendation remains **owner mobile testing**, not broad production distribution, until the native, signing, live-provider and backend/device checks above are resolved.
