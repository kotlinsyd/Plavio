# Plavio compact stream picker

## Included source

This is the complete project based on GitLab `main` commit
`20ec53fa9b5f9b5ab5724c76ba1d3765f0ef502a` (Plavio mobile 0.11.3), with the compact
long-press Play stream-picker changes applied locally. Nothing was pushed or
deployed. This mobile-only archive includes shared/mobile app sources, native FFmpeg
libraries, website sources, resources, Gradle wrapper, and mobile unit tests.
The TV-only product flavor and app/src/tv overlay are excluded. Shared TV-aware
helpers remain because the mobile app imports them. Generated build
folders, local SDK configuration, caches, Git history, and private signing keys
are deliberately excluded.

## Picker changes

Long-press Play opens “Choose stream” with the entire poster visible rather than
cropped into a banner. Metadata, add-ons, quality choices, and compact stream
cards share one vertical list so they remain reachable on small or landscape
screens. Back, Close, and Android system Back dismiss the picker.

Add-ons are ordered All, PlavioHD, TMAddon, StAddon, then other responding
add-ons. Tabs reflect actual returned results, so an absent or non-responding
add-on is not advertised as having streams. Quality chips sit directly below
the add-on row and are built from the combined results, not just the selected
add-on. A quality filters streams across all add-ons; choosing an add-on narrows
that same quality further. “Any” removes only the quality constraint, while
“Clear filters” resets both constraints when a combination has no results.

4K, UHD, and 2160p are one 4K quality bucket, including lowercase aliases.
Other recognized resolutions include 1440p, 1080p, 720p, 480p, and 360p. Unknown
quality streams remain available under Any. New results can add more qualities
while the picker is open.

Each compact card keeps separate Download and Play actions. The existing
stream objects and download-confirmation/playback callbacks are reused; URL
headers, subtitles, debrid handling, and the actual player/download pipeline
were not replaced. Other source lists keep their existing non-compact layout.

## Existing source build fixes

The latest main player referenced `PlaybackRequest.mergeAudioUrl`, but the model
was missing that field. The optional nullable field has been restored with a
`null` default, preserving normal playback and the existing merged-audio player
path. Regression tests cover its default and copy behavior. Duplicate imports
were removed, and the referenced project ProGuard file is now included.

## Build and signing

Use JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and the included Gradle
8.10.2 wrapper. Set `ANDROID_HOME` or supply your own `local.properties`.

```sh
./gradlew :app:assembleMobileDebug :app:testMobileDebugUnitTest
```

The original project required a keystore at a developer-specific absolute path.
Debug builds now use Android's standard local debug key unless owner signing is
configured. Release builds are unsigned unless owner signing is configured.
Provide these in private `~/.gradle/gradle.properties` when needed:

```properties
PLAVIO_SIGNING_STORE=/absolute/path/to/your-existing-owner-key.keystore
PLAVIO_SIGNING_STORE_PASSWORD=your-store-password
PLAVIO_SIGNING_KEY_ALIAS=your-key-alias
PLAVIO_SIGNING_KEY_PASSWORD=your-key-password
```

Do not share or add the real values or keystore to the source archive. A locally
debug-signed APK cannot replace an installed owner-signed app. Use the matching
owner key to update without uninstalling or losing local app data.

## Verification

See MOBILE-BUILD-NOTES.md for the results from this mobile-only source package.
No TV build or TV test is part of this delivery's verification.

The inherited malformed-playlist test expectation follows the parser's existing
`tvg-name` precedence; the production playlist parser was not changed.
Robolectric Compose tests exercise the production picker with deterministic
fixtures and no live add-on dependencies. They do not prove that every remote
provider is online, nor replace real-device network playback/download testing.
