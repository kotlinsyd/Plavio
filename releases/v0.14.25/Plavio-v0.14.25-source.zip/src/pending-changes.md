# Pending changes for next Plavio release

Batched per Najam — do NOT build until he says "go".

## Home
- [ ] KEEP the tagline "Your streaming universe" (reversal of the earlier removal note).
- [ ] Home header: remove the app icon (looks dark/bad) — name "Plavio" text only.
- [ ] If possible: a network-speed dot next to the name — red = bad network,
      yellow = normal speed, green = good enough to stream 1080p+. Only if
      feasible without heavy data use; not a strict requirement.

## Player
- [ ] Controls were rejected ("looks very bad", doesn't match theme). Revert to
      the previous design: bottom strip centered, capsule type, ALL buttons
      inside (aspect, speed, subs, audio, sources, episodes) — restyled to match
      the app theme.
- [ ] Add a screen-rotate button (if easy to do).

## Addons
- [ ] Move the Addons tab into Settings (remove it from the bottom nav).
- [ ] Redesign addon management in the Nuvio style (never mention Nuvio): addon
      rows with logo, name, version, description, install/remove — same or better
      arrangement and features.

## Live tab
- [ ] Next to the "Live" title at the top: a red dot with white circle that
      signals live TV/streams.
- [ ] Remove the refresh icon there; add a search option limited to live
      channels only.

## Bottom nav
- [ ] All bottom nav buttons capsule-shaped, with proper width and length.
