# Plavio Cloud: public API configuration rejected

The installed public client configuration is rejected before account authentication. The supplied public `/auth/v1/settings` check returned HTTP 401 using the APK's client key, without an email, password or user session. This separates the reported failure from account-password validation. Resetting the password, uploading source, or retrying login cannot make this app key valid.

Local inspection of the exact 0.11.6 source confirms a legacy `anon` JWT, matching endpoint/project claims and a declared expiry in the future. JWT claims are unverified metadata: they do not prove a valid signature or current gateway acceptance. No full key or account data is reproduced here.

The evidence does **not** establish whether legacy keys were disabled, the key was superseded/invalidated by signing-secret rotation, the embedded signature is wrong, or another gateway configuration is rejecting it. Those are alternatives, not diagnosed facts. The Supabase connector's key metadata was not used; no claim that this particular key is active or disabled is made.

## Safe next step

The maintainer should privately verify the intended project's **Settings > API Keys**, compare the APK configuration with the project's currently accepted public client configuration, and prefer an existing active publishable key for a mobile app. Validate that configuration using only the public auth settings endpoint before rebuilding. The acceptance criterion is a successful HTTP response for the public configuration check, followed by an owner-controlled sign-in test on the rebuilt app. A public-settings success is not itself proof of account login or database permissions.

Do not put a `service_role` or secret key in the app, and do not change database/RLS policies to work around an API-key rejection. No key creation, rotation, enablement, backend change, account login or private data access was performed. This 0.11.7 candidate intentionally preserves the existing cloud endpoint and public key, so it does not claim to repair cloud login.

[Supabase's official key guide](https://supabase.com/docs/guides/getting-started/api-keys) distinguishes the app's API key from a user's Auth session, recommends publishable keys for mobile clients, and states that creating new keys does not itself disable legacy keys; disabling legacy keys is a separate dashboard action.
