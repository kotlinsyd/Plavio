package com.pulsestream.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.AUDIO_LANGUAGE_OPTIONS
import com.pulsestream.app.data.BUFFER_PRESETS
import com.pulsestream.app.data.DISK_CACHE_OPTIONS
import com.pulsestream.app.data.PlayerChoice
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.audioLanguageName
import com.pulsestream.app.data.bufferPresetName
import com.pulsestream.app.data.diskCacheName
import com.pulsestream.app.data.SUBTITLE_BG_OPTIONS
import com.pulsestream.app.data.SUBTITLE_COLOR_OPTIONS
import com.pulsestream.app.data.SUBTITLE_EDGE_OPTIONS
import com.pulsestream.app.data.SUBTITLE_LANGUAGE_OPTIONS
import com.pulsestream.app.data.SUBTITLE_SIZE_OPTIONS
import com.pulsestream.app.data.SUBTITLE_EDGE_COLOR_OPTIONS
import com.pulsestream.app.data.SUBTITLE_FONT_OPTIONS
import com.pulsestream.app.data.subtitleBgName
import com.pulsestream.app.data.subtitleColorName
import com.pulsestream.app.data.subtitleEdgeName
import com.pulsestream.app.data.subtitleLanguageName
import com.pulsestream.app.data.subtitleSizeName
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.tv.tvFocusRing
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

@Composable
fun PlaybackSettingsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    val settings = repository.settings
    var prePlayEnabled by remember { mutableStateOf(settings.prePlayEnabled) }
    var autoplay by remember { mutableStateOf(settings.autoplay) }
    var autoPlayNext by remember { mutableStateOf(settings.autoPlayNext) }
    var keepScreenOn by remember { mutableStateOf(settings.keepScreenOn) }
    var showSkip by remember { mutableStateOf(settings.showSkipButton) }
    var forceSeek by remember { mutableStateOf(settings.forceSeekAnyStream) }
    var pipEnabled by remember { mutableStateOf(settings.pipEnabled) }
    var audioLang by remember { mutableStateOf(settings.preferredAudioLanguage) }
    var audioLangPickerOpen by remember { mutableStateOf(false) }
    var bufferPresetOpen by remember { mutableStateOf(false) }
    var diskCacheOpen by remember { mutableStateOf(false) }
    var playerPickerOpen by remember { mutableStateOf(false) }
    var shuffleEpisodes by remember { mutableStateOf(settings.shuffleEpisodes) }
    // Engine group (mobile overhaul): the dual-engine settings.
    var enginePickerOpen by remember { mutableStateOf(false) }
    var autoFailover by remember { mutableStateOf(settings.autoEngineFailover) }
    var mpvHwdec by remember { mutableStateOf(settings.mpvHardwareDecoding) }
    var mpvYuv by remember { mutableStateOf(settings.mpvYuv420pFilter) }
    var engineUiTick by remember { mutableStateOf(0) }
    // Refresh key so the preferred-player subtitle updates after the dialog closes.
    var playerUiTick by remember { mutableStateOf(0) }
    // Refresh key so the buffer/disk-cache subtitles update after the dialogs close.
    var bufferUiTick by remember { mutableStateOf(0) }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Playback",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "How videos start, behave and sound while playing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }
            item(key = "player_group") {
                // Read inside the item so recomposition picks up dialog changes.
                playerUiTick
                bufferUiTick
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.PlayArrow,
                            title = "Autoplay",
                            subtitle = "Play the first source automatically",
                            checked = autoplay,
                            onCheckedChange = {
                                autoplay = it
                                settings.autoplay = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.SkipNext,
                            title = "Auto-play next episode",
                            subtitle = "Start the next episode when one finishes",
                            checked = autoPlayNext,
                            onCheckedChange = {
                                autoPlayNext = it
                                settings.autoPlayNext = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Shuffle,
                            title = "Shuffle episodes",
                            subtitle = "Auto-play picks a random next episode instead of the following one",
                            checked = shuffleEpisodes,
                            onCheckedChange = {
                                shuffleEpisodes = it
                                settings.shuffleEpisodes = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.BrightnessHigh,
                            title = "Keep screen on",
                            subtitle = "Prevent the screen from sleeping while playing",
                            checked = keepScreenOn,
                            onCheckedChange = {
                                keepScreenOn = it
                                settings.keepScreenOn = it
                            }
                        )
                    },
                    {
                        // PrePlay (item 13, v0.14.24): OFF by default
                        // at first ship — the owner's staged word.
                        SettingsToggleRow(
                            icon = Icons.Filled.FastForward,
                            title = "PrePlay",
                            subtitle = "Streams load in the background when you open a title, so play starts faster",
                            checked = prePlayEnabled,
                            onCheckedChange = {
                                prePlayEnabled = it
                                settings.prePlayEnabled = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.FastForward,
                            title = "Skip intro button",
                            subtitle = "Show a skip button for intros, recaps and outros",
                            checked = showSkip,
                            onCheckedChange = {
                                showSkip = it
                                settings.showSkipButton = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.SwapHoriz,
                            title = "Force seek on any stream",
                            subtitle = "Seek even on sources that normally can't — far jumps may take a moment and use extra data",
                            checked = forceSeek,
                            onCheckedChange = {
                                forceSeek = it
                                settings.forceSeekAnyStream = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.PictureInPicture,
                            title = "Picture-in-Picture",
                            subtitle = "Float the video when you leave the player",
                            checked = pipEnabled,
                            onCheckedChange = {
                                pipEnabled = it
                                settings.pipEnabled = it
                            }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.OpenInNew,
                            title = "Preferred player",
                            subtitle = "Currently: ${PlayerChoice.fromName(settings.preferredPlayer).label}",
                            onClick = { playerPickerOpen = true }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.Audiotrack,
                            title = "Preferred audio language",
                            subtitle = if (audioLang.isNullOrBlank()) {
                                "Not set \u2014 title's default audio is used"
                            } else {
                                "Auto-plays ${audioLanguageName(audioLang!!)} when available"
                            },
                            onClick = { audioLangPickerOpen = true }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.Speed,
                            title = "Buffer preset",
                            subtitle = "Currently: ${bufferPresetName(settings.bufferMinMs, settings.bufferMaxMs, settings.bufferForPlaybackMs)}",
                            onClick = { bufferPresetOpen = true }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.Storage,
                            title = "Disk cache",
                            subtitle = "Cache played media on device: ${diskCacheName(settings.diskCacheMb)}",
                            onClick = { diskCacheOpen = true }
                        )
                    }
                )
            }
            item(key = "engine_header") {
                SettingsSectionHeader("Engine")
            }
            item(key = "engine_group") {
                // Read inside the item so the engine subtitle refreshes
                // after the picker dialog closes.
                engineUiTick
                SettingsGroup(
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.SmartDisplay,
                            title = "Playback engine",
                            subtitle = "Currently: ${playbackEngineName(settings.playbackEngine)}",
                            onClick = { enginePickerOpen = true }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.SwapHoriz,
                            title = "Auto-switch engine on error",
                            subtitle = "If a stream fails, retry it once on the other engine at the same position",
                            checked = autoFailover,
                            onCheckedChange = {
                                autoFailover = it
                                settings.autoEngineFailover = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Memory,
                            title = "MPV hardware decoding",
                            subtitle = "Use the device's video chip in the MPV engine — faster and cooler",
                            checked = mpvHwdec,
                            onCheckedChange = {
                                mpvHwdec = it
                                settings.mpvHardwareDecoding = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Palette,
                            title = "MPV compatibility filter",
                            subtitle = "Convert video to yuv420p in the MPV engine — fixes odd colours on some devices",
                            checked = mpvYuv,
                            onCheckedChange = {
                                mpvYuv = it
                                settings.mpvYuv420pFilter = it
                            }
                        )
                    }
                )
            }
        }
    }

    if (audioLangPickerOpen) {
        AudioLanguagePickerDialog(
            initial = audioLang,
            onDismiss = { audioLangPickerOpen = false },
            onDone = { lang ->
                settings.preferredAudioLanguage = lang
                audioLang = lang
                audioLangPickerOpen = false
            }
        )
    }

    if (bufferPresetOpen) {
        BufferPresetDialog(
            settings = settings,
            onDismiss = { bufferPresetOpen = false },
            onDone = { bufferPresetOpen = false; bufferUiTick++ }
        )
    }

    if (diskCacheOpen) {
        DiskCacheDialog(
            settings = settings,
            onDismiss = { diskCacheOpen = false },
            onDone = { diskCacheOpen = false; bufferUiTick++ }
        )
    }

    if (playerPickerOpen) {
        PlayerChoiceDialog(
            settings = settings,
            onDismiss = { playerPickerOpen = false },
            onDone = { playerPickerOpen = false; playerUiTick++ }
        )
    }

    if (enginePickerOpen) {
        EnginePickerDialog(
            settings = settings,
            onDismiss = { enginePickerOpen = false },
            onDone = { enginePickerOpen = false; engineUiTick++ }
        )
    }
}

/** Display name for a stored playback-engine choice. */
fun playbackEngineName(engine: Int): String = when (engine) {
    1 -> "ExoPlayer"
    2 -> "MPV"
    else -> "Auto"
}

/**
 * Playback engine picker (mobile overhaul): Auto routes per stream
 * (HDR / Dolby Vision to ExoPlayer, anime to MPV, everything else to
 * ExoPlayer); the other two pin one engine for every stream.
 */
@Composable
fun EnginePickerDialog(
    settings: SettingsStore,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    var selected by remember { mutableStateOf(settings.playbackEngine) }
    val options = listOf(
        Triple(0, "Auto", "Recommended — HDR and Dolby Vision use ExoPlayer, anime uses MPV, the rest use ExoPlayer"),
        Triple(1, "ExoPlayer", "The standard engine for every stream"),
        Triple(2, "MPV", "The specialist engine for every stream it can play")
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback engine", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Two engines are built in. You can also switch engine mid-play from the player's top bar.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(options.size) { index ->
                        val (value, label, detail) = options[index]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = value }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == value,
                                onClick = { selected = value },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(label, color = TextPrimary)
                                Text(
                                    detail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                settings.playbackEngine = selected
                onDone()
            }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Buffer preset picker (Settings > Playback > Buffer & Cache): Low /
 * Balanced / Aggressive presets mapping to concrete ExoPlayer buffer
 * durations. Applies on the next player build (next title played).
 */
@Composable
fun BufferPresetDialog(
    settings: SettingsStore,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    var selected by remember {
        mutableStateOf(
            BUFFER_PRESETS.indexOfFirst {
                it.second == Triple(settings.bufferMinMs, settings.bufferMaxMs, settings.bufferForPlaybackMs)
            }.takeIf { it >= 0 }
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buffer preset", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "How much video is buffered ahead. Higher = fewer stalls on slow networks, more RAM used. Applies to the next title you play.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(BUFFER_PRESETS.size) { index ->
                        val (label, values) = BUFFER_PRESETS[index]
                        val (minMs, maxMs, forPlaybackMs) = values
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = index }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == index,
                                onClick = { selected = index },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(label, color = TextPrimary)
                                Text(
                                    "${minMs / 1000}s min · ${maxMs / 1000}s max · starts after ${forPlaybackMs / 1000.0} s",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val idx = selected
                if (idx != null && idx >= 0) {
                    val (_, values) = BUFFER_PRESETS[idx]
                    settings.bufferMinMs = values.first
                    settings.bufferMaxMs = values.second
                    settings.bufferForPlaybackMs = values.third
                }
                onDone()
            }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Disk cache picker (Settings > Playback > Buffer & Cache): caches played
 * media on device so re-watches don't re-download. Applies on the next
 * player build.
 */
@Composable
fun DiskCacheDialog(
    settings: SettingsStore,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    var selected by remember { mutableStateOf(settings.diskCacheMb) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Disk cache", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Keep played video on your device so re-watching doesn't download it again. Applies to the next title you play.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(DISK_CACHE_OPTIONS, key = { it.first }) { (mb, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = mb }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == mb,
                                onClick = { selected = mb },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(label, color = TextPrimary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                settings.diskCacheMb = selected
                onDone()
            }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Preferred-player picker (Settings > Playback): built-in Plavio player,
 * an external app via the system chooser, or ask every time.
 */
@Composable
fun PlayerChoiceDialog(
    settings: SettingsStore,
    onDismiss: () -> Unit,
    onDone: () -> Unit
) {
    var selected by remember {
        mutableStateOf(PlayerChoice.fromName(settings.preferredPlayer))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preferred player", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Which app plays your videos. External players open through Android's app chooser; some addons' streams may need their original headers, which only the built-in player guarantees.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(PlayerChoice.values(), key = { it.name }) { choice ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = choice }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == choice,
                                onClick = { selected = choice },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(choice.label, color = TextPrimary)
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    choice.blurb,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                settings.preferredPlayer = selected.name
                onDone()
            }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Ordered multi-select dialog for the preferred subtitle languages
 * (v0.14.14). The selection is a real priority list — no count cap:
 * languages are tried in the order shown (1st first). Tapping a
 * language adds it at the end or removes it; the arrow buttons in the
 * priority section move entries up/down.
 */
@Composable
fun SubtitleLanguagePickerDialog(
    initial: List<String>,
    onDismiss: () -> Unit,
    onDone: (List<String>) -> Unit
) {
    var selected by remember { mutableStateOf(initial) }

    fun move(code: String, delta: Int) {
        val idx = selected.indexOf(code)
        val target = idx + delta
        if (idx < 0 || target < 0 || target >= selected.size) return
        selected = selected.toMutableList().also {
            it.removeAt(idx)
            it.add(target, code)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preferred subtitle languages", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Matching subtitles turn on automatically in the player. " +
                        "Languages are tried in this order — your 1st choice wins.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    if (selected.isNotEmpty()) {
                        item(key = "priority_header") {
                            Text(
                                "YOUR ORDER",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        items(selected, key = { "sel_$it" }) { code ->
                            val position = selected.indexOf(code)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${position + 1}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = LocalPalette.current.accent,
                                    modifier = Modifier.width(24.dp)
                                )
                                Text(
                                    subtitleLanguageName(code),
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { move(code, -1) },
                                    enabled = position > 0,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.KeyboardArrowUp,
                                        contentDescription = "Move up",
                                        tint = if (position > 0) TextPrimary
                                        else TextSecondary.copy(alpha = 0.35f)
                                    )
                                }
                                IconButton(
                                    onClick = { move(code, +1) },
                                    enabled = position < selected.size - 1,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.KeyboardArrowDown,
                                        contentDescription = "Move down",
                                        tint = if (position < selected.size - 1) TextPrimary
                                        else TextSecondary.copy(alpha = 0.35f)
                                    )
                                }
                                IconButton(
                                    onClick = { selected = selected - code },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Close,
                                        contentDescription = "Remove",
                                        tint = TextSecondary
                                    )
                                }
                            }
                        }
                        item(key = "all_header") {
                            Text(
                                "ALL LANGUAGES",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                            )
                        }
                    }
                    items(SUBTITLE_LANGUAGE_OPTIONS, key = { it.first }) { (code, name) ->
                        val isSelected = code in selected
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selected =
                                        if (isSelected) selected - code else selected + code
                                }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = null,
                                colors = CheckboxDefaults.colors(
                                    checkedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(name, color = TextPrimary)
                            if (isSelected) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "#${selected.indexOf(code) + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = LocalPalette.current.accent
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(selected) }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/** Single-select dialog for the preferred audio language. */
@Composable
fun AudioLanguagePickerDialog(
    initial: String?,
    onDismiss: () -> Unit,
    onDone: (String?) -> Unit
) {
    var selected by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preferred audio language", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "If a title's audio tracks include this language, it plays in it automatically. Otherwise the title's default is used.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    item(key = "none") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = null }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == null,
                                onClick = { selected = null },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Not set", color = TextPrimary)
                        }
                    }
                    items(AUDIO_LANGUAGE_OPTIONS, key = { it.first }) { (code, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = code }
                                .tvFocusRing(RoundedCornerShape(10.dp))
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = selected == code,
                                onClick = { selected = code },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = LocalPalette.current.accent
                                )
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(name, color = TextPrimary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(selected) }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Subtitle styling dialog (Settings > Subtitles): the FULL style set —
 * the same stored values the player's Style rail edits (text color,
 * opacity, background, fine font size, bold, edge style, outline color,
 * bottom position) plus the font family — with a live preview.
 * Transactional: every change edits a DRAFT; "Done" persists it,
 * "Cancel" (or dismissing) throws it away. "System default" skips the
 * app's styling entirely so Android's Settings > Accessibility >
 * Captions preferences apply. Settings holds the global defaults;
 * per-title adjustments stay in the player's rail.
 */
@Composable
fun SubtitleStyleDialog(
    settings: SettingsStore,
    onDismiss: () -> Unit
) {
    var useSystem by remember { mutableStateOf(settings.useSystemCaptions) }
    var textColor by remember { mutableStateOf(settings.subtitleTextColor) }
    var bgColor by remember { mutableStateOf(settings.subtitleBackgroundColor) }
    var fontSizeSp by remember { mutableStateOf(settings.subtitleFontSizeSp) }
    var edgeType by remember { mutableStateOf(settings.subtitleEdgeType) }
    var bold by remember { mutableStateOf(settings.subtitleBold) }
    var edgeColor by remember { mutableStateOf(settings.subtitleEdgeColor) }
    var bottomOffset by remember { mutableStateOf(settings.subtitleBottomOffset) }
    var fontFamily by remember { mutableStateOf(settings.subtitleFontFamily) }

    fun confirm() {
        settings.useSystemCaptions = useSystem
        settings.subtitleTextColor = textColor
        settings.subtitleBackgroundColor = bgColor
        // Writing the sp value also keeps the legacy scale in sync.
        settings.subtitleFontSizeSp = fontSizeSp
        settings.subtitleEdgeType = edgeType
        settings.subtitleBold = bold
        settings.subtitleEdgeColor = edgeColor
        settings.subtitleBottomOffset = bottomOffset
        settings.subtitleFontFamily = fontFamily
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Subtitle appearance", color = TextPrimary) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // ---- System default ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { useSystem = !useSystem }
                        .tvFocusRing(RoundedCornerShape(10.dp))
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = useSystem,
                        onCheckedChange = null,
                        colors = CheckboxDefaults.colors(
                            checkedColor = LocalPalette.current.accent
                        )
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("System default", color = TextPrimary)
                        Text(
                            "Use Android's Settings > Accessibility > Captions",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))

                // The custom styling controls edit the draft only while
                // "System default" is off (dimmed + guarded when it is on).
                Column(
                    Modifier
                        .fillMaxWidth()
                        .alpha(if (useSystem) 0.4f else 1f)
                ) {
                    // ---- Live preview ----
                    SubtitlePreview(
                        textColor = textColor,
                        bgColor = bgColor,
                        sizeScale = fontSizeSp / 18f,
                        edgeType = edgeType,
                        bold = bold,
                        edgeColor = edgeColor,
                        fontFamilyIndex = fontFamily
                    )
                    Spacer(Modifier.height(12.dp))

                    // Colour picks keep the current opacity (the rail
                    // behaves the same way): match and merge by RGB.
                    Text("Text color", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    SwatchRow(
                        options = SUBTITLE_COLOR_OPTIONS,
                        selected = textColor or 0xFF000000.toInt(),
                        onSelect = {
                            if (!useSystem) {
                                textColor = (textColor and 0xFF000000.toInt()) or
                                    (it and 0x00FFFFFF)
                            }
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Text opacity", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    val opacityPct =
                        (android.graphics.Color.alpha(textColor) * 100 + 127) / 255
                    SubtitleStepperRow(
                        value = "$opacityPct%",
                        onMinus = {
                            if (!useSystem) {
                                val p = (opacityPct - 10).coerceIn(0, 100)
                                val a = (p * 255 + 50) / 100
                                textColor = (a shl 24) or (textColor and 0x00FFFFFF)
                            }
                        },
                        onPlus = {
                            if (!useSystem) {
                                val p = (opacityPct + 10).coerceIn(0, 100)
                                val a = (p * 255 + 50) / 100
                                textColor = (a shl 24) or (textColor and 0x00FFFFFF)
                            }
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Background", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    SwatchRow(
                        options = SUBTITLE_BG_OPTIONS,
                        selected = bgColor,
                        onSelect = { if (!useSystem) bgColor = it }
                    )
                    Spacer(Modifier.height(12.dp))

                    // Fine size stepper (12–40 sp), replacing the old
                    // 4 coarse presets — the same value the player's
                    // Style rail steps.
                    Text("Font size", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    SubtitleStepperRow(
                        value = "${fontSizeSp}sp",
                        onMinus = {
                            if (!useSystem) fontSizeSp = (fontSizeSp - 2).coerceIn(12, 40)
                        },
                        onPlus = {
                            if (!useSystem) fontSizeSp = (fontSizeSp + 2).coerceIn(12, 40)
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Bold", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    OptionChips(
                        options = listOf("Off", "On"),
                        selected = if (bold) "On" else "Off",
                        onSelect = { name -> if (!useSystem) bold = name == "On" }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Font", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    OptionChips(
                        options = SUBTITLE_FONT_OPTIONS.map { it.second },
                        selected = SUBTITLE_FONT_OPTIONS.find { it.first == fontFamily }?.second
                            ?: "System",
                        onSelect = { name ->
                            if (!useSystem) {
                                SUBTITLE_FONT_OPTIONS.find { it.second == name }?.let {
                                    fontFamily = it.first
                                }
                            }
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Edge style", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    OptionChips(
                        options = SUBTITLE_EDGE_OPTIONS.map { it.second },
                        selected = subtitleEdgeName(edgeType),
                        onSelect = { name ->
                            if (!useSystem) {
                                SUBTITLE_EDGE_OPTIONS.find { it.second == name }?.let {
                                    edgeType = it.first
                                }
                            }
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    // Picking an outline colour while the edge is off
                    // turns the outline on — same coupling as the rail.
                    Text("Outline color", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    SwatchRow(
                        options = SUBTITLE_EDGE_COLOR_OPTIONS,
                        selected = edgeColor,
                        onSelect = {
                            if (!useSystem) {
                                edgeColor = it
                                if (edgeType == 0) edgeType = 1
                            }
                        }
                    )
                    Spacer(Modifier.height(12.dp))

                    Text("Bottom position", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(6.dp))
                    SubtitleStepperRow(
                        value = "$bottomOffset",
                        onMinus = {
                            if (!useSystem) bottomOffset = (bottomOffset - 5).coerceIn(0, 200)
                        },
                        onPlus = {
                            if (!useSystem) bottomOffset = (bottomOffset + 5).coerceIn(0, 200)
                        }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { confirm() }) {
                Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/** Row of color swatches for the subtitle styling dialog. */
@Composable
fun SwatchRow(
    options: List<Pair<Int, String>>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
    ) {
        items(options.size) { i ->
            val (color, name) = options[i]
            val isSelected = color == selected
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(androidx.compose.ui.graphics.Color(color))
                    .clickable { onSelect(color) }
                    .tvFocusRing(androidx.compose.foundation.shape.CircleShape)
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) LocalPalette.current.accent
                        else androidx.compose.ui.graphics.Color.White.copy(alpha = 0.2f),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (name == "None") {
                    Text(
                        "✕",
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.6f),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}

/** Wrapping row of text chips for size / edge options. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OptionChips(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { name ->
            val isSelected = name == selected
            androidx.compose.material3.FilterChip(
                selected = isSelected,
                onClick = { onSelect(name) },
                label = { Text(name) },
                colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                    selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
                    selectedLabelColor = TextPrimary,
                    containerColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.06f),
                    labelColor = TextSecondary
                )
            )
        }
    }
}

/** −/value/+ stepper row used by the subtitle style dialog. */
@Composable
fun SubtitleStepperRow(
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.OutlinedButton(onClick = onMinus) { Text("−") }
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        androidx.compose.material3.OutlinedButton(onClick = onPlus) { Text("+") }
    }
}

/** Live subtitle preview that mirrors the chosen styling. */
@Composable
fun SubtitlePreview(
    textColor: Int,
    bgColor: Int,
    sizeScale: Float,
    edgeType: Int,
    bold: Boolean = false,
    edgeColor: Int = 0xFF000000.toInt(),
    fontFamilyIndex: Int = 0
) {
    val textCol = androidx.compose.ui.graphics.Color(textColor)
    val bgCol = androidx.compose.ui.graphics.Color(bgColor)
    val edgeCol = androidx.compose.ui.graphics.Color(edgeColor)
    val shadow = when (edgeType) {
        1 -> androidx.compose.ui.graphics.Shadow(
            color = edgeCol,
            offset = androidx.compose.ui.geometry.Offset(2f, 2f),
            blurRadius = 0f
        )
        2 -> androidx.compose.ui.graphics.Shadow(
            color = edgeCol.copy(alpha = 0.9f),
            offset = androidx.compose.ui.geometry.Offset(3f, 3f),
            blurRadius = 4f
        )
        3 -> androidx.compose.ui.graphics.Shadow(
            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.5f),
            offset = androidx.compose.ui.geometry.Offset(-2f, -2f),
            blurRadius = 1f
        )
        4 -> androidx.compose.ui.graphics.Shadow(
            color = edgeCol,
            offset = androidx.compose.ui.geometry.Offset(0f, 3f),
            blurRadius = 2f
        )
        else -> null
    }
    val previewFontFamily = when (fontFamilyIndex) {
        1 -> androidx.compose.ui.text.font.FontFamily.SansSerif
        2 -> androidx.compose.ui.text.font.FontFamily.Serif
        3 -> androidx.compose.ui.text.font.FontFamily.Monospace
        else -> androidx.compose.ui.text.font.FontFamily.Default
    }
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .background(androidx.compose.ui.graphics.Color.Black)
            .border(
                1.dp,
                androidx.compose.ui.graphics.Color.White.copy(alpha = 0.12f),
                androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "This is how subtitles will look",
            color = textCol,
            fontSize = (16 * sizeScale).sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
            style = MaterialTheme.typography.bodyLarge.copy(
                shadow = shadow,
                fontFamily = previewFontFamily
            ),
            modifier = Modifier
                .background(bgCol, androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
