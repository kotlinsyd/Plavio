package com.pulsestream.app.data.download

/** HTTP range and media-type rules kept pure so they can be unit tested. */
internal object DownloadProtocol {
    data class ContentRange(val start: Long, val endInclusive: Long, val total: Long?)

    private val RANGE = Regex("^bytes (\\d+)-(\\d+)/(\\d+|\\*)$", RegexOption.IGNORE_CASE)

    /** Checks payload + reserve without allowing signed-Long addition to wrap. */
    fun fitsWithReserve(availableBytes: Long, payloadBytes: Long, reserveBytes: Long): Boolean =
        availableBytes >= 0 && payloadBytes >= 0 && reserveBytes >= 0 &&
            payloadBytes <= availableBytes && reserveBytes <= availableBytes - payloadBytes

    fun parseContentRange(value: String?, requestedStart: Long): ContentRange? {
        if (requestedStart < 0) return null
        val match = RANGE.matchEntire(value?.trim() ?: return null) ?: return null
        val start = match.groupValues[1].toLongOrNull() ?: return null
        val end = match.groupValues[2].toLongOrNull() ?: return null
        val total = match.groupValues[3].takeUnless { it == "*" }?.toLongOrNull()
        if (start != requestedStart || end == Long.MAX_VALUE || end < start || (total != null && total <= end)) return null
        return ContentRange(start, end, total)
    }

    fun isAdaptive(url: String, contentType: String? = null): Boolean {
        val lowerUrl = url.lowercase()
        val type = contentType.orEmpty().substringBefore(';').trim().lowercase()
        return lowerUrl.contains(".m3u8") || lowerUrl.contains(".mpd") ||
            type in setOf(
                "application/vnd.apple.mpegurl",
                "application/x-mpegurl",
                "audio/mpegurl",
                "audio/x-mpegurl",
                "application/dash+xml"
            )
    }

    fun isHls(url: String): Boolean = url.lowercase().contains(".m3u8")

    fun isDash(url: String): Boolean = url.lowercase().contains(".mpd")

    /**
     * Adaptive check for a raw stream URL as it arrives from an addon
     * (possibly proxy-wrapped / percent-encoded). Mirrors the decode
     * step DownloadManager applies before the same test, so the UI's
     * "stream only" label and the download path never disagree.
     */
    fun isAdaptiveRaw(rawUrl: String): Boolean {
        val decoded = runCatching {
            java.net.URLDecoder.decode(
                rawUrl, java.nio.charset.StandardCharsets.UTF_8.name()
            )
        }.getOrDefault(rawUrl)
        return isAdaptive(decoded)
    }

    fun isUnsupportedPayload(prefix: ByteArray): Boolean {
        val text = prefix.toString(Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n').lowercase()
        return text.startsWith("#extm3u") || text.startsWith("<mpd") ||
            (text.startsWith("<?xml") && "<mpd" in text) || text.startsWith("<!doctype html") ||
            text.startsWith("<html") || text.startsWith("{\"") || text.startsWith("[{")
    }
    fun changedValidator(
        oldEtag: String?, oldLastModified: String?, newEtag: String?, newLastModified: String?
    ): Boolean = (oldEtag != null && newEtag != null && oldEtag != newEtag) ||
        (oldLastModified != null && newLastModified != null && oldLastModified != newLastModified)

    fun ifRange(etag: String?, lastModified: String?): String? =
        etag?.takeUnless { it.startsWith("W/", ignoreCase = true) } ?: lastModified

    // ------------------------------------------------------------------
    // Resume rules (v0.14.38, item 6). The owner's bug: pause + resume
    // restarted downloads from zero. The old code only trusted a
    // partial file when the server had sent an ETag/Last-Modified,
    // deleted segmented state whenever a resume probe failed, and
    // threw segment state away when CDN validators rotated. These
    // pure rules encode the fixed behaviour so it stays tested:
    // a partial file on disk is resume truth; identity is proven by
    // the 206 Content-Range total matching the known total (plus
    // If-Range whenever validators exist), never assumed.
    // ------------------------------------------------------------------

    /**
     * A saved segmented state may be reused when the sidecar total,
     * the on-disk file length and the fresh probe total all agree.
     * Validators are deliberately NOT part of this decision —
     * rotating CDN edges mint fresh ETags for the same bytes, and
     * per-segment If-Range + strict 206 checks still guard every
     * range actually fetched.
     */
    fun segmentStateReusable(savedTotal: Long, onDiskBytes: Long, probeTotal: Long): Boolean =
        savedTotal > 0 && savedTotal == probeTotal && onDiskBytes == probeTotal

    /**
     * A resume 206 is only safe to append when its Content-Range
     * total matches the total already known for this download (from
     * the DB row / sidecar). An unknown total on either side cannot
     * disprove identity, so it passes — the strict range parse and
     * If-Range discipline remain the guards there.
     */
    fun rangeTotalMatches(rangeTotal: Long?, knownTotal: Long): Boolean =
        rangeTotal == null || knownTotal <= 0L || rangeTotal == knownTotal

    /**
     * A paused/failed row with bytes on disk may be rebound to a
     * fresh URL for the same title (expired-link re-pick): the saved
     * byte offset then applies to the new URL, with identity
     * re-verified at resume time by [rangeTotalMatches].
     */
    fun canRebindPartial(status: String, onDiskBytes: Long): Boolean =
        (status == "PAUSED" || status == "FAILED") && onDiskBytes > 0L
}
