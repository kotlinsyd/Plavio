package com.pulsestream.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.PulseApp
import com.pulsestream.app.R
import com.pulsestream.app.data.ProfilesManager
import com.pulsestream.app.data.db.ProfileRow
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/** Preset avatars for profiles (the account section's preset set). */
object ProfileAvatars {
    val KEYS: List<String> = listOf(
        "man_glasses", "man_beard", "man_blond", "man_cap",
        "woman_bun", "woman_curly", "woman_hijab", "woman_longhair",
        "kid_boy", "kid_cap", "kid_curly", "kid_pigtails"
    )

    fun res(key: String): Int = when (key) {
        "man_beard" -> R.drawable.avatar_man_beard
        "man_blond" -> R.drawable.avatar_man_blond
        "man_cap" -> R.drawable.avatar_man_cap
        "woman_bun" -> R.drawable.avatar_woman_bun
        "woman_curly" -> R.drawable.avatar_woman_curly
        "woman_hijab" -> R.drawable.avatar_woman_hijab
        "woman_longhair" -> R.drawable.avatar_woman_longhair
        "kid_boy" -> R.drawable.avatar_kid_boy
        "kid_cap" -> R.drawable.avatar_kid_cap
        "kid_curly" -> R.drawable.avatar_kid_curly
        "kid_pigtails" -> R.drawable.avatar_kid_pigtails
        else -> R.drawable.avatar_man_glasses
    }
}

/**
 * Local profiles (v0.14.13, item 8): each profile has its own
 * watchlist, custom lists, favorites, statuses, watched marks and
 * Continue Watching/history; addons, settings and the signed-in
 * account stay global. Any profile can be made the DEFAULT — a
 * cold start opens into the default. Tapping a profile switches to
 * it (the app restarts so every list rebinds); the last profile
 * can't be deleted.
 */
@Composable
fun ProfilesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as PulseApp
    val manager = remember { ProfilesManager(app.database, app.settings) }
    val profiles by app.database.profileDao().observeAll()
        .collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val palette = LocalPalette.current
    val activeId = app.settings.activeProfileId
    val defaultId = app.settings.defaultProfileId

    var showCreate by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProfileRow?>(null) }
    var deleting by remember { mutableStateOf<ProfileRow?>(null) }

    GlowBackground {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary)
                }
                Text(
                    "Profiles",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            Text(
                "Each profile keeps its own library, lists, watched state and " +
                    "Continue Watching. The app opens into the default profile.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    ProfileRowCard(
                        profile = profile,
                        isActive = profile.id == activeId,
                        isDefault = profile.id == defaultId,
                        canDelete = profiles.size > 1,
                        onSwitch = {
                            if (profile.id != activeId) {
                                manager.switchTo(profile.id)
                                ProfilesManager.restartApp(context)
                            }
                        },
                        onEdit = { editing = profile },
                        onSetDefault = {
                            scope.launch { manager.setDefault(profile.id) }
                        },
                        onDelete = { deleting = profile }
                    )
                }
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .clickable { showCreate = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(palette.accent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Add, null, tint = palette.accent)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            "Add profile",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }

    if (showCreate) {
        ProfileEditDialog(
            title = "New profile",
            initialName = "",
            initialAvatar = ProfileAvatars.KEYS.first(),
            onDismiss = { showCreate = false },
            onSave = { name, avatar ->
                showCreate = false
                scope.launch { manager.create(name, avatar) }
            }
        )
    }
    editing?.let { profile ->
        ProfileEditDialog(
            title = "Edit profile",
            initialName = profile.name,
            initialAvatar = profile.avatarKey,
            onDismiss = { editing = null },
            onSave = { name, avatar ->
                editing = null
                scope.launch {
                    manager.rename(profile.id, name)
                    manager.setAvatar(profile.id, avatar)
                }
            }
        )
    }
    deleting?.let { profile ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete ${profile.name}?") },
            text = {
                Text(
                    "Their library, lists, watched state and Continue Watching " +
                        "are deleted too. This can't be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val wasActive = profile.id == activeId
                        deleting = null
                        scope.launch {
                            if (manager.delete(profile.id) && wasActive) {
                                ProfilesManager.restartApp(context)
                            }
                        }
                    }
                ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ProfileRowCard(
    profile: ProfileRow,
    isActive: Boolean,
    isDefault: Boolean,
    canDelete: Boolean,
    onSwitch: () -> Unit,
    onEdit: () -> Unit,
    onSetDefault: () -> Unit,
    onDelete: () -> Unit
) {
    val palette = LocalPalette.current
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .then(
                if (isActive) Modifier.border(1.5.dp, palette.accent, RoundedCornerShape(16.dp))
                else Modifier
            )
            .clickable(onClick = onSwitch)
            .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp)
    ) {
        Image(
            painter = painterResource(ProfileAvatars.res(profile.avatarKey)),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(48.dp).clip(CircleShape)
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                maxLines = 1
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isDefault) {
                    ProfileChip("Default", palette.accent)
                }
                if (isActive) {
                    ProfileChip("Active", palette.accent)
                } else {
                    Text(
                        "Tap to switch",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Filled.MoreVert, "Profile options", tint = TextSecondary)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Rename / change avatar") },
                    onClick = { menuOpen = false; onEdit() }
                )
                if (!isDefault) {
                    DropdownMenuItem(
                        text = { Text("Set as default") },
                        onClick = { menuOpen = false; onSetDefault() }
                    )
                }
                if (canDelete) {
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        onClick = { menuOpen = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileChip(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.18f), RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun ProfileEditDialog(
    title: String,
    initialName: String,
    initialAvatar: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var avatar by remember { mutableStateOf(initialAvatar) }
    val palette = LocalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(116.dp)
                ) {
                    items(ProfileAvatars.KEYS) { key ->
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .then(
                                    if (key == avatar) {
                                        Modifier.border(2.5.dp, palette.accent, CircleShape)
                                    } else Modifier
                                )
                                .clickable { avatar = key },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(ProfileAvatars.res(key)),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(44.dp).clip(CircleShape)
                            )
                            if (key == avatar) {
                                Icon(
                                    Icons.Filled.Check, null,
                                    tint = Color.White,
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(14.dp)
                                        .background(palette.accent, CircleShape)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, avatar) },
                enabled = name.isNotBlank()
            ) { Text("Save", color = palette.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}
