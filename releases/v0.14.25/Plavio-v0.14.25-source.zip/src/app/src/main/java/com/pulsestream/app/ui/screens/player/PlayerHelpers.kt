@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.pulsestream.app.ui.screens.player

import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import com.pulsestream.app.data.ResolvedSubtitle

/**
 * Format recovery accepts gateways that reject HEAD or hide playlist MIME types.
 * Uses the same TLS and credential-scoping rules as normal playback.
 */
internal fun probePlaybackContentType(url: String, headers: Map<String, String>): String? {
    return com.pulsestream.app.data.PlaybackContentProbe.probe(url, headers)
}

/** Start ExoPlayer's silent prepare before waiting on persisted resume progress. */
internal suspend fun preparePlayerBeforeSavedPositionLookup(
    preparePlayer: () -> Unit,
    loadSavedPosition: suspend () -> Long,
    prepareEarly: Boolean = true
): Long {
    if (prepareEarly) preparePlayer()
    return loadSavedPosition()
}

/** Transient on-screen feedback for gestures, speed, aspect and track changes. */
internal sealed interface PlayerIndicator {
    data class Volume(val percent: Int) : PlayerIndicator
    data class Brightness(val percent: Int) : PlayerIndicator

    /**
     * [subtext] (v0.14.16): the slide-seek readout's second line —
     * the landing time under the jump — null for the ±10s
     * double-tap seeks, which keep the single-line pill.
     */
    data class Seek(val text: String, val subtext: String? = null) : PlayerIndicator
    data class Speed(val label: String) : PlayerIndicator
    data class Message(val text: String) : PlayerIndicator
}

/**
 * Slide-seek jump label (v0.14.16, owner's order): while sliding
 * on the picture, the jump reads in plain units — "+12 min",
 * "−8 min", "+1 h 5 min", "+45s" under a minute — instead of a
 * bare clock delta.
 */
internal fun seekJumpLabel(deltaMs: Long): String {
    val sign = if (deltaMs >= 0) "+" else "−"
    val totalSec = kotlin.math.abs(deltaMs) / 1000
    return when {
        totalSec >= 3600 -> {
            val h = totalSec / 3600
            val m = (totalSec % 3600) / 60
            if (m == 0L) "$sign$h h" else "$sign$h h $m min"
        }
        totalSec >= 60 -> "$sign${totalSec / 60} min"
        else -> "$sign${totalSec}s"
    }
}

internal val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

internal fun speedLabel(s: Float): String =
    if (s == s.toInt().toFloat()) "${s.toInt()}x" else "${s}x"

/** Stable identity of a resolved subtitle list (cache files are reused across re-resolves). */
internal fun subtitleIdentity(list: List<ResolvedSubtitle>): String =
    list.joinToString("|") { it.file.absolutePath + "#" + it.mimeType }

internal fun formatMs(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/** ISO 639-2/B (and -1) codes seen in the wild → display names. */
internal val LANG_NAMES = mapOf(
    "eng" to "English", "en" to "English",
    "spa" to "Spanish", "es" to "Spanish",
    "fre" to "French", "fra" to "French", "fr" to "French",
    "deu" to "German", "ger" to "German", "de" to "German",
    "ita" to "Italian", "it" to "Italian",
    "por" to "Portuguese", "pob" to "Portuguese (BR)", "pt" to "Portuguese",
    "rus" to "Russian", "ru" to "Russian",
    "ara" to "Arabic", "ar" to "Arabic",
    "hin" to "Hindi", "hi" to "Hindi",
    "urd" to "Urdu", "ur" to "Urdu",
    "tur" to "Turkish", "tr" to "Turkish",
    "zho" to "Chinese", "chi" to "Chinese", "zh" to "Chinese",
    "jpn" to "Japanese", "ja" to "Japanese",
    "kor" to "Korean", "ko" to "Korean",
    "nld" to "Dutch", "dut" to "Dutch", "nl" to "Dutch",
    "swe" to "Swedish", "sv" to "Swedish",
    "nor" to "Norwegian", "nob" to "Norwegian", "no" to "Norwegian",
    "dan" to "Danish", "da" to "Danish",
    "fin" to "Finnish", "fi" to "Finnish",
    "pol" to "Polish", "pl" to "Polish",
    "ces" to "Czech", "cze" to "Czech", "cs" to "Czech",
    "slk" to "Slovak", "slo" to "Slovak", "sk" to "Slovak",
    "ron" to "Romanian", "rum" to "Romanian", "ro" to "Romanian",
    "ell" to "Greek", "gre" to "Greek", "el" to "Greek",
    "heb" to "Hebrew", "he" to "Hebrew",
    "tha" to "Thai", "th" to "Thai",
    "vie" to "Vietnamese", "vi" to "Vietnamese",
    "ind" to "Indonesian", "id" to "Indonesian",
    "msa" to "Malay", "may" to "Malay", "ms" to "Malay",
    "tam" to "Tamil", "ta" to "Tamil",
    "tel" to "Telugu", "te" to "Telugu",
    "ben" to "Bengali", "bn" to "Bengali",
    "mar" to "Marathi", "mr" to "Marathi",
    "pan" to "Punjabi", "pa" to "Punjabi",
    "guj" to "Gujarati", "gu" to "Gujarati",
    "ukr" to "Ukrainian", "uk" to "Ukrainian",
    "hun" to "Hungarian", "hu" to "Hungarian",
    "srp" to "Serbian", "sr" to "Serbian",
    "hrv" to "Croatian", "hr" to "Croatian",
    "bos" to "Bosnian", "ba" to "Bosnian",
    "slv" to "Slovenian", "sl" to "Slovenian",
    "bul" to "Bulgarian", "bg" to "Bulgarian",
    "cat" to "Catalan", "ca" to "Catalan"
)

internal fun displayLanguage(code: String?): String? {
    if (code.isNullOrBlank() || code == "und") return null
    return LANG_NAMES[code.lowercase()] ?: code.uppercase()
}

internal data class TrackOption(
    val group: TrackGroup,
    val trackIndex: Int,
    val label: String,
    val selected: Boolean
)

internal fun trackLabel(format: Format, fallbackIndex: Int): String {
    if (!format.label.isNullOrBlank()) return format.label!!
    return displayLanguage(format.language) ?: "Track ${fallbackIndex + 1}"
}

internal fun trackOptions(player: Player, type: Int): List<TrackOption> =
    player.currentTracks.groups
        .filter { it.type == type }
        .flatMapIndexed { gi, g ->
            (0 until g.length).map { i ->
                TrackOption(g.mediaTrackGroup, i, trackLabel(g.getTrackFormat(i), gi), g.isSelected)
            }
        }

internal fun hasSelectedTrack(player: Player, type: Int): Boolean =
    player.currentTracks.groups.any { it.type == type && it.isSelected }

/**
 * The identity by which a resolved (downloaded) subtitle is matched
 * back to the subtitle the user picked in the panel (v0.14.30).
 *
 * The panel lists the subtitle's URL as served; the resolver
 * downloads that URL and the published [ResolvedSubtitle] carries
 * the same [Subtitle] — but a bare `==` on the raw strings broke
 * (owner's note 3, v0.14.29): the same file can be represented with
 * different URL spellings on the two sides of the resolve step —
 * scheme/host casing, a default port, percent-encoded vs literal
 * characters, a trailing slash — above all for the built-in
 * PlavioSubs entries, whose listed URL is produced by the server
 * while the resolver's copy comes through the request/addon merge.
 * Every comparison then silently missed, a tap on an undownloaded
 * file parked in a "pending" branch that only fired if the resolver
 * later re-published that exact string, and the subtitle never
 * reached the player.
 *
 * The match key normalises the spelling differences that do not
 * change which file is meant: trim, scheme + host lower-cased,
 * default port dropped, percent-escapes decoded (UTF-8, invalid
 * escapes kept verbatim), duplicate slashes in the path collapsed,
 * one trailing slash dropped. Query strings are compared as-is
 * apart from escape decoding (they can carry file identity).
 */
internal fun subtitleMatchKey(url: String): String {
    val trimmed = url.trim()
    val schemeSep = trimmed.indexOf("://")
    if (schemeSep < 0) return percentDecodeSubtitleUrl(trimmed)
    val scheme = trimmed.substring(0, schemeSep).lowercase()
    val rest = trimmed.substring(schemeSep + 3)
    val authorityEnd = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
        .let { if (it < 0) rest.length else it }
    var authority = rest.substring(0, authorityEnd).lowercase()
    val defaultPort = when (scheme) {
        "http" -> ":80"
        "https" -> ":443"
        else -> null
    }
    if (defaultPort != null && authority.endsWith(defaultPort)) {
        authority = authority.dropLast(defaultPort.length)
    }
    var tail = rest.substring(authorityEnd)
    val hash = tail.indexOf('#')
    if (hash >= 0) tail = tail.substring(0, hash)
    val q = tail.indexOf('?')
    val rawPath = if (q >= 0) tail.substring(0, q) else tail
    val rawQuery = if (q >= 0) tail.substring(q + 1) else null
    var path = percentDecodeSubtitleUrl(rawPath)
    while (path.contains("//")) path = path.replace("//", "/")
    if (path.length > 1 && path.endsWith("/")) path = path.dropLast(1)
    val query = rawQuery?.let { percentDecodeSubtitleUrl(it) }
    return buildString {
        append(scheme)
        append("://")
        append(authority)
        append(path)
        if (query != null) {
            append('?')
            append(query)
        }
    }
}

/** UTF-8 percent-decoding for [subtitleMatchKey]; malformed escapes
 *  and raw '+' are kept verbatim ('+' is a literal in a path). */
private fun percentDecodeSubtitleUrl(s: String): String {
    if (!s.contains('%')) return s
    val bytes = java.io.ByteArrayOutputStream(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '%' && i + 2 <= s.length - 1) {
            val hex = s.substring(i + 1, i + 3)
            val v = hex.toIntOrNull(16)
            if (v != null) {
                bytes.write(v)
                i += 3
                continue
            }
        }
        bytes.write(c.toString().toByteArray(Charsets.UTF_8))
        i++
    }
    return String(bytes.toByteArray(), Charsets.UTF_8)
}

/**
 * Finds the resolved subtitle a panel pick refers to (v0.14.30):
 * an exact URL hit first (the historical behaviour, so nothing
 * that worked changes), then the [subtitleMatchKey] spelling-
 * tolerant match. Returns null only when the file genuinely has
 * not been downloaded yet — the caller then routes the pick
 * through the add-and-resolve path instead of parking it.
 */
internal fun findResolvedForPick(
    resolved: List<ResolvedSubtitle>,
    pickedUrl: String
): ResolvedSubtitle? {
    resolved.firstOrNull { it.sub.url == pickedUrl }?.let { return it }
    val key = subtitleMatchKey(pickedUrl)
    return resolved.firstOrNull { subtitleMatchKey(it.sub.url) == key }
}

/**
 * The panel's candidate files for one language, in panel order
 * (subtitle switch fix, 2026-11-09): the Step-1 language tap picks
 * from exactly this list, so what the language row promises and
 * what the Files step lists can never drift apart.
 */
internal fun subtitleCandidatesForLanguage(
    subs: List<com.pulsestream.app.data.Subtitle>,
    langCode: String
): List<com.pulsestream.app.data.Subtitle> =
    subs.filter { com.pulsestream.app.data.subtitleLangMatches(it.lang, langCode) }

/**
 * The subtitle SWITCH decision core (urgent fix, 2026-11-09 —
 * owner's device report on v0.14.31: Arabic selected in a previous
 * session kept rendering after he tapped English).
 *
 * Root causes this replaces:
 *  1. The Step-1 language tap applied nothing at all — it only
 *     navigated to the Files step, so "changing the language"
 *     changed nothing on screen.
 *  2. A file pick that was not downloaded yet parked in a pending
 *     slot whose only exit was "the file appears in a later
 *     publish". [resolveSubtitleFiles] drops download/sniff
 *     failures silently (null, no record), so a failed pick never
 *     appeared, the pending slot never cleared, the previously
 *     active subtitle kept rendering forever — and the tap had
 *     already announced "Subtitles: <lang>" as if it had worked.
 *     No downloading state and no failure state existed anywhere
 *     in the switch path.
 *
 * The tracker owns the pending pick by match key: [beginPick]
 * starts the visible downloading state; [activationFor] hands the
 * pick to the renderer the moment a publish contains it
 * (auto-apply); [resolveCycleFinished] closes a cycle that TRIED
 * the pick (it was in the cycle's input) without publishing it as
 * a visible failure — and drops the pending slot, so a later
 * unrelated publish can never resurrect a dead pick over the
 * user's newer choice. [markActivated] records what is actually
 * rendering; a fresh pick always outranks whatever was active or
 * remembered before it, because activation is only ever driven by
 * the pending slot, never by the remembered/default choice while
 * a pick is in flight.
 */
internal class SubtitlePickTracker {
    /** Match key of the pick waiting for its download/resolve. */
    var pendingKey: String? = null
        private set

    /** Human language label of the pending pick (for messages). */
    var pendingLabel: String? = null
        private set

    /** Language label of the last pick whose resolve failed. */
    var failedLabel: String? = null
        private set

    /** Match key of the subtitle actually rendering now. */
    var activeKey: String? = null
        private set

    /** True while a pick is waiting on its download/resolve. */
    val isDownloading: Boolean get() = pendingKey != null

    /** A fresh tap: the downloading state starts, any older
     *  failure message is retired, and this pick supersedes every
     *  earlier pending pick. */
    fun beginPick(sub: com.pulsestream.app.data.Subtitle, label: String) {
        pendingKey = subtitleMatchKey(sub.url)
        pendingLabel = label
        failedLabel = null
    }

    /** Off / superseded by a direct activation: no pending pick,
     *  no downloading state. The failure label is left alone —
     *  only a new pick or a successful activation retires it. */
    fun cancel() {
        pendingKey = null
        pendingLabel = null
    }

    /** [resolved] is now the rendered subtitle. If it is the
     *  pending pick, the switch completes (pending + downloading
     *  state clear). Any successful activation retires the failure
     *  label — something the user chose is on screen. */
    fun markActivated(resolved: ResolvedSubtitle) {
        val key = subtitleMatchKey(resolved.sub.url)
        activeKey = key
        if (key == pendingKey) cancel()
        failedLabel = null
    }

    /**
     * The resolved subtitle the pending pick should activate from
     * a freshly published list, or null while it is still missing.
     * Pure lookup — the caller activates and calls [markActivated].
     * A persisted/remembered subtitle elsewhere in the list is
     * never returned here: only the pending pick can activate.
     */
    fun activationFor(resolved: List<ResolvedSubtitle>): ResolvedSubtitle? {
        val key = pendingKey ?: return null
        return findResolvedForPick(resolved, key)
    }

    /**
     * A resolver cycle has finished publishing. If the cycle's
     * input included the pending pick but the published list does
     * not contain it, the download/resolve failed: surface the
     * failure ([failedLabel]) and drop the pending slot, so the
     * pick can never activate late over a newer choice. Cycles
     * that never attempted the pick (their input predates the tap)
     * change nothing — the pick is still downloading.
     */
    fun resolveCycleFinished(
        cycleInputs: List<com.pulsestream.app.data.Subtitle>,
        published: List<ResolvedSubtitle>
    ) {
        val key = pendingKey ?: return
        val attempted = cycleInputs.any { subtitleMatchKey(it.url) == key }
        if (!attempted) return
        if (findResolvedForPick(published, key) == null) {
            failedLabel = pendingLabel
            cancel()
        }
    }
}

/**
 * The subtitle Style card's SIZE row wording (v0.14.31, item 1):
 * the row showed the raw state object — the template
 * `"$fontSpState.value sp"` interpolates the MutableIntState
 * itself, printing `MutableIntState(value=19)@…` on the phone.
 * Both lines now come from these two pure functions of the Int
 * value, so no state object can ever reach the screen again.
 * The band boundaries are the ones the card has always used.
 */
internal fun subtitleSizeName(sp: Int): String = when (sp) {
    in 12..16 -> "Small"
    in 18..24 -> "Medium"
    in 26..32 -> "Large"
    else -> "Extra large"
}

/** The SIZE row's second line: the plain human size, e.g. "19 sp". */
internal fun subtitleSizeText(sp: Int): String = "$sp sp"

/**
 * The caption typeface the style application paints with
 * (v0.14.31, item 4): extracted verbatim from the player's
 * applySubtitleStyle so the Bold flag's path into the renderer
 * is unit-testable. Family "System" (0) with no bold keeps the
 * null typeface (renderer default), exactly as before; bold
 * wraps the family face in a BOLD create() so the caption
 * renderer's CaptionStyleCompat carries real weight.
 */
internal fun subtitleTypeface(family: Int, bold: Boolean): android.graphics.Typeface? {
    val baseTypeface = when (family) {
        1 -> android.graphics.Typeface.SANS_SERIF
        2 -> android.graphics.Typeface.SERIF
        3 -> android.graphics.Typeface.MONOSPACE
        else -> android.graphics.Typeface.DEFAULT
    }
    return when {
        bold -> android.graphics.Typeface.create(baseTypeface, android.graphics.Typeface.BOLD)
        family != 0 -> baseTypeface
        else -> null
    }
}

/** End of player helpers. */
