package com.pulsestream.app.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import com.pulsestream.app.ui.components.OrbitDots
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pulsestream.app.data.CatalogRow
import com.pulsestream.app.data.isPlayableLiveStreamUrl
import com.pulsestream.app.data.LIVE_SOURCE_RESOLUTION_TIMEOUT_MS
import com.pulsestream.app.data.liveResolutionFailureMessage
import com.pulsestream.app.data.liveResourceType
import com.pulsestream.app.data.MetaPreview
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.TvChannelRef
import com.pulsestream.app.ui.components.EmptyState
import com.pulsestream.app.ui.components.ErrorState
import com.pulsestream.app.ui.components.LoadingState
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.components.PosterCard
import com.pulsestream.app.ui.components.SectionTitle
import com.pulsestream.app.ui.tv.tvFocusRing
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.GlassWhite
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull

internal sealed interface LiveUiState {
    data object Loading : LiveUiState
    data class Content(
        val rows: List<CatalogRow>,
        val m3uRows: List<CatalogRow>,
        val playlists: List<String>,
        val m3uErrors: List<String> = emptyList()
    ) : LiveUiState
    data class Error(val message: String) : LiveUiState
    data object Empty : LiveUiState
}

internal class LiveViewModel(
    private val repository: com.pulsestream.app.data.StreamRepository
) : androidx.lifecycle.ViewModel() {
    var uiState: LiveUiState by mutableStateOf(LiveUiState.Loading)
        private set
    private var loadJob: Job? = null

    init {
        load()
    }

    fun load() {
        // init and ON_RESUME may happen together; never duplicate a refresh.
        if (loadJob?.isActive == true) return
        loadJob = viewModelScope.launch {
            try {
                val previous = uiState as? LiveUiState.Content
                val cached = repository.loadTvRowsCached()
                val playlists = repository.settings.m3uPlaylists
                if (cached.isNotEmpty()) {
                    uiState = LiveUiState.Content(cached, previous?.m3uRows.orEmpty(), playlists)
                } else if (previous == null) {
                    uiState = LiveUiState.Loading
                }
                val (rows, m3u) = coroutineScope {
                    val addonRows = async { repository.loadTvRows() }
                    val playlistRows = async { repository.loadM3uRows() }
                    addonRows.await() to playlistRows.await()
                }
                uiState = if (rows.isEmpty() && m3u.rows.isEmpty()) {
                    // A failed playlist must say so, not show the generic
                    // "no live TV" empty state.
                    if (m3u.errors.isNotEmpty()) LiveUiState.Error(m3u.errors.joinToString("\n"))
                    else LiveUiState.Empty
                } else {
                    LiveUiState.Content(rows, m3u.rows, playlists, m3u.errors)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) {
                val saved = uiState as? LiveUiState.Content
                uiState = if (saved != null) saved.copy(
                    m3uErrors = saved.m3uErrors + "Live refresh failed; showing saved channels. Retry to refresh."
                ) else LiveUiState.Error("Couldn't load live channels. Please retry.")
            }
        }
    }

    fun toggleFavorite(key: String) = repository.toggleLiveFavorite(key)
}

private fun channelKey(row: CatalogRow, meta: MetaPreview) = "${row.addonId}|${meta.id}"

/**
 * The Live tab: TV channels from addons + M3U playlists, with pinned
 * favorites, recently-watched channels, category chips that actually
 * filter, long-press to pin, and a top-right M3U import.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LiveScreen(
    onPlay: (PlaybackRequest) -> Unit,
    onGoToAddons: () -> Unit,
    repository: com.pulsestream.app.data.StreamRepository
) {
    val scope = rememberCoroutineScope()
    val vm: LiveViewModel = viewModel(factory = remember {
        object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                LiveViewModel(repository) as T
        }
    })
    var query by remember { mutableStateOf("") }
    var resolvingKey by remember { mutableStateOf<String?>(null) }
    var resolvingJob by remember { mutableStateOf<Job?>(null) }
    var resolveGeneration by remember { mutableIntStateOf(0) }
    var resolveError by remember { mutableStateOf<String?>(null) }
    var showSearch by remember { mutableStateOf(false) }
    var showM3uDialog by remember { mutableStateOf(false) }
    /** Selected category chip; null = All. */
    var category by remember { mutableStateOf<String?>(null) }
    /** Bumped to re-read favorites/recents after a toggle. */
    var favVersion by remember { mutableIntStateOf(0) }

    // Back clears the query AND closes search — never just one of them.
    BackHandler(enabled = showSearch) {
        query = ""
        showSearch = false
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) vm.load()
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    fun channelRef(row: CatalogRow, meta: MetaPreview) = TvChannelRef(
        addonId = row.addonId,
        metaId = meta.id,
        name = meta.name,
        poster = meta.poster,
        type = liveResourceType(meta.type, row.type),
        catalogId = row.catalogId
    )

    fun playChannel(row: CatalogRow, meta: MetaPreview, flatList: List<TvChannelRef>) {
        // Player zapping: hand over the whole visible list + this channel's
        // index BEFORE playing, so channel up/down has a valid list to work
        // from on the very first play.
        val idx = flatList.indexOfFirst { it.addonId == row.addonId && it.metaId == meta.id }
        repository.setTvZapList(flatList, if (idx >= 0) idx else 0)
        resolvingJob?.cancel()
        resolvingJob = null
        val generation = ++resolveGeneration
        resolvingKey = null
        resolveError = null
        if (row.addonId == "m3u") {
            // M3U: the channel id IS the stream URL — play it directly.
            // (No resolution step exists here, so this is as "after
            // successful playback start" as the Live tab can know.)
            repository.pushLiveRecent(channelKey(row, meta))
            favVersion++ // re-render recents row
            onPlay(
                PlaybackRequest(
                    streamUrl = meta.id,
                    title = meta.name,
                    poster = meta.poster,
                    type = "tv",
                    videoId = meta.id,
                    streamLabel = "LIVE"
                )
            )
            return
        }
        val key = channelKey(row, meta)
        resolvingKey = key
        val channel = channelRef(row, meta)
        resolvingJob = scope.launch {
            try {
                // FIX (2026-10-20): Collect streams from ALL addons, not just the first.
                // The old firstOrNull meant if the fastest addon returned dead URLs,
                // working streams from slower addons were never tried - causing the
                // "keep changing sources then can't play" symptom.
                val allStreams = mutableListOf<com.pulsestream.app.data.StreamItem>()
                val seenUrls = mutableSetOf<String>()
                // Bounded window: addons answer in parallel, so most arrive in a
                // few seconds; don't let one slow addon stall channel start.
                withTimeoutOrNull(8_000L) {
                    repository.liveStreamResultsFlow(channel).collect { result ->
                        result.streams.forEach { stream ->
                            if (isPlayableLiveStreamUrl(stream.url) && seenUrls.add(stream.url)) {
                                allStreams.add(stream)
                            }
                        }
                    }
                }
                if (generation != resolveGeneration) return@launch
                // Probe-rank: verified-alive streams first, so the first URL
                // handed to the player isn't a dead one that triggers the
                // source-cycling failover. Budget-bounded; unverified streams
                // stay in the list as failover candidates.
                val streams = com.pulsestream.app.data.StreamProber
                    .rankByProbe(allStreams, isTv = true)
                if (generation != resolveGeneration) return@launch
                val first = streams.firstOrNull()
                if (first == null) {
                    resolveError = "No playable stream found for \"${meta.name}\"."
                } else {
                    // Resolution succeeded — only now does the channel earn a
                    // place in Recently Watched; failed channels stay out.
                    repository.pushLiveRecent(key)
                    favVersion++ // re-render recents row
                    onPlay(
                        PlaybackRequest(
                            streamUrl = first.url,
                            headers = first.headers,
                            title = meta.name,
                            poster = meta.poster,
                            type = channel.type,
                            videoId = meta.id,
                            streamLabel = "LIVE",
                            sourceName = first.sourceName,
                            streams = streams,
                            mimeType = first.mimeType,
                            liveChannel = channel
                        )
                    )
                }
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (e: Exception) {
                if (generation == resolveGeneration) {
                    resolveError = liveResolutionFailureMessage(meta.name)
                }
            } finally {
                if (generation == resolveGeneration) {
                    resolvingJob = null
                    resolvingKey = null
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ---- Header ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LiveDot()
                Spacer(Modifier.width(8.dp))
                Text(
                    "Live TV",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showSearch = !showSearch }) {
                Icon(
                    if (showSearch) Icons.Filled.Close else Icons.Filled.Search,
                    "Search",
                    tint = TextSecondary
                )
            }
        }

        if (showSearch) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search live channels…") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(50)
            )
        }

        when (val state = vm.uiState) {
            is LiveUiState.Loading -> LoadingState("Finding live channels…")
            is LiveUiState.Error -> ErrorState(state.message, onRetry = { vm.load() })
            is LiveUiState.Empty -> EmptyState(
                title = "No live TV yet",
                message = "Plavio doesn't bundle any channels. Install a live TV addon " +
                    "with its manifest URL — or import an M3U playlist from the top-right " +
                    "button — and its channels will appear here.",
                actionLabel = "Add an addon",
                onAction = onGoToAddons
            )
            is LiveUiState.Content -> {
                val allRows = remember(state.rows, state.m3uRows) {
                    state.rows + state.m3uRows
                }
                val q = query.trim()
                val queryFiltered = remember(allRows, q) {
                    if (q.isBlank()) allRows
                    else allRows.map { row ->
                        row.copy(items = row.items.filter {
                            it.name.contains(q, ignoreCase = true)
                        })
                    }.filter { it.items.isNotEmpty() }
                }
                // Category chips derived from catalog names (e.g. M3U group-titles
                // like News/Sports/Movies/Kids); tapping one shows ONLY those rows.
                val categories = remember(queryFiltered) {
                    queryFiltered.map { it.catalogName }.distinct()
                }
                val visibleRows = remember(queryFiltered, category) {
                    if (category == null) queryFiltered
                    else queryFiltered.filter { it.catalogName == category }
                }
                // Favorites + recents, resolved against the loaded rows.
                val favorites = remember(allRows, favVersion) {
                    val keys = repository.settings.liveFavorites
                    allRows.flatMap { row ->
                        row.items.filter { channelKey(row, it) in keys }
                            .map { row to it }
                    }.distinctBy { (row, meta) -> channelKey(row, meta) }
                }
                val recents = remember(allRows, favVersion) {
                    val keys = repository.settings.liveRecent
                    keys.mapNotNull { key ->
                        allRows.firstNotNullOfOrNull { row ->
                            row.items.firstOrNull { channelKey(row, it) == key }
                                ?.let { row to it }
                        }
                    }.distinctBy { (row, meta) -> channelKey(row, meta) }
                }
                // Flat visible list for the player zapping handoff.
                val flatList = remember(visibleRows, favorites, recents) {
                    (favorites + recents + visibleRows.flatMap { row ->
                        row.items.map { row to it }
                    }).distinctBy { (row, meta) -> channelKey(row, meta) }
                        .map { (row, meta) -> channelRef(row, meta) }
                }

                @Composable
                fun ChannelCard(row: CatalogRow, meta: MetaPreview) {
                    val key = channelKey(row, meta)
                    val pinned = key in repository.settings.liveFavorites
                    val busy = resolvingKey == key
                    // Channel tile (v0.12.4 Sample C; resized v0.12.5):
                    // a logo tile + name below. v0.12.5 (owner's order):
                    // the tile now matches the Home catalog PosterCard
                    // footprint exactly — 128dp wide with a 180dp art
                    // box — because the old 132×76 landscape tile read
                    // far too small next to Home's cards. Channel art
                    // is wide logos, so it stays ContentScale.Fit,
                    // centered inside the taller box. The
                    // long-press lives ON the tile itself (an inner
                    // clickable under an outer combinedClickable would
                    // consume the press, which is why pinning once
                    // never fired).
                    Column(
                        modifier = Modifier
                            .width(128.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .focusable()
                            .tvFocusRing(RoundedCornerShape(14.dp))
                            .combinedClickable(
                                onClick = { playChannel(row, meta, flatList) },
                                onLongClick = { vm.toggleFavorite(key); favVersion++ }
                            )
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.06f))
                                .border(1.dp, GlassBorder, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            val art = meta.background ?: meta.logo ?: meta.poster
                            if (art != null) {
                                AsyncImage(
                                    model = art,
                                    contentDescription = meta.name,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(10.dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Text(
                                    meta.name.take(2).uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSecondary
                                )
                            }
                            if (pinned) {
                                Icon(
                                    Icons.Filled.Star, "Pinned",
                                    tint = Color(0xFFFFD54F),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(5.dp)
                                        .size(14.dp)
                                )
                            }
                            if (busy) {
                                OrbitDots(modifier = Modifier.padding(8.dp).size(32.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LiveDot()
                            Spacer(Modifier.width(5.dp))
                            Text(
                                meta.name,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                @Composable
                fun FeaturedChannelCard(row: CatalogRow, meta: MetaPreview) {
                    val key = channelKey(row, meta)
                    val busy = resolvingKey == key
                    // Sample C featured card (v0.12.4): one wide 16:9
                    // card for whatever is on now — tap plays through
                    // the same path as every channel tile; long-press
                    // pins/unpins like the tiles.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                            .focusable()
                            .tvFocusRing(RoundedCornerShape(18.dp))
                            .combinedClickable(
                                onClick = { playChannel(row, meta, flatList) },
                                onLongClick = { vm.toggleFavorite(key); favVersion++ }
                            )
                    ) {
                        val art = meta.background ?: meta.logo ?: meta.poster
                        if (art != null) {
                            AsyncImage(
                                model = art,
                                contentDescription = meta.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF14324A), Color(0xFF0B1A2C))
                                        )
                                    )
                            )
                        }
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = 0.78f)
                                        ),
                                        startY = 140f
                                    )
                                )
                        )
                        if (meta.logo != null && meta.logo != art) {
                            AsyncImage(
                                model = meta.logo,
                                contentDescription = null,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(12.dp)
                                    .height(26.dp)
                                    .widthIn(max = 110.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                        Column(
                            Modifier
                                .align(Alignment.BottomStart)
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LiveDot()
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "LIVE NOW",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        letterSpacing = 1.2.sp
                                    ),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = LocalPalette.current.accent
                                )
                                Text(
                                    "  ·  ${row.catalogName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.75f),
                                    maxLines = 1
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                meta.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            meta.description?.takeIf { it.isNotBlank() }?.let { desc ->
                                Text(
                                    desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.8f),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (busy) {
                            OrbitDots(modifier = Modifier.align(Alignment.Center).padding(8.dp).size(32.dp))
                        }
                    }
                }

                resolveError?.let { err ->
                    Text(
                        err,
                        color = Color(0xFFFF6B6B),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                // Failed playlists are named, not silently dropped.
                state.m3uErrors.forEach { err ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "⚠ $err",
                            color = Color(0xFFFFB74D),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { vm.load() }) {
                            Text("Retry", color = LocalPalette.current.accent)
                        }
                    }
                }
                // Featured channel (v0.12.4, Sample C): the first channel
                // of the first non-empty category — Sports preferred when
                // present — taken from the UNFILTERED browsing set. Shown
                // as the wide card at the top of the tab only while
                // browsing (no search text or category chip narrowing
                // the list).
                val featuredRow = remember(categories, visibleRows, query, category) {
                    val browsing = query.isBlank() && category == null
                    if (!browsing) null
                    else {
                        val sportsName = categories.firstOrNull {
                            it.equals("Sports", ignoreCase = true)
                        }
                        sportsName?.let { name ->
                            visibleRows.firstOrNull { it.catalogName == name }
                        } ?: visibleRows.firstOrNull()
                    }
                }
                val featuredChannel = featuredRow?.items?.firstOrNull()
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    // Extra bottom room so the last row scrolls clear of
                    // the floating dock (content now runs under it).
                    contentPadding = PaddingValues(bottom = 104.dp)
                ) {
                    // ---- Category chips ----
                    if (categories.size > 1 || (categories.size == 1 && category != null)) {
                        item(key = "live|chips") {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(bottom = 8.dp)
                            ) {
                                item(key = "chip|all") {
                                    FilterChip(
                                        selected = category == null,
                                        onClick = { category = null },
                                        label = { Text("All") },
                                        colors = chipColors()
                                    )
                                }
                                categories.forEach { cat ->
                                    item(key = "chip|$cat") {
                                        FilterChip(
                                            selected = category == cat,
                                            onClick = { category = if (category == cat) null else cat },
                                            label = { Text(cat) },
                                            colors = chipColors()
                                        )
                                    }
                                }
                            }
                        }
                    }
                    // ---- Pinned favorites ----
                    if (favorites.isNotEmpty()) {
                        item(key = "live|favs") {
                            SectionTitle("Pinned channels", "long-press any channel to pin")
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                itemsIndexed(
                                    favorites,
                                    key = { _, pair -> "fav|${channelKey(pair.first, pair.second)}" }
                                ) { _, (row, meta) -> ChannelCard(row, meta) }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                    // ---- Featured (Sample C) ----
                    if (featuredRow != null && featuredChannel != null) {
                        item(key = "live|featured") {
                            FeaturedChannelCard(featuredRow, featuredChannel)
                            Spacer(Modifier.height(14.dp))
                        }
                    }
                    // ---- Recently watched ----
                    if (recents.isNotEmpty()) {
                        item(key = "live|recent") {
                            SectionTitle("Recently watched", null)
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                itemsIndexed(
                                    recents,
                                    key = { _, pair -> "rec|${channelKey(pair.first, pair.second)}" }
                                ) { _, (row, meta) -> ChannelCard(row, meta) }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                    // ---- Channel rows ----
                    if (visibleRows.isEmpty() && (q.isNotBlank() || category != null)) {
                        item(key = "live|noresult") {
                            EmptyState(
                                title = "No channels found",
                                message = "Nothing matches this filter."
                            )
                        }
                    }
                    visibleRows.forEach { row ->
                        item(key = "live|${row.addonId}|${row.type}|${row.catalogId}") {
                            SectionTitle(row.catalogName, row.addonName)
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                itemsIndexed(
                                    row.items,
                                    key = { index, meta -> "live_${row.addonId}_${meta.id}_$index" }
                                ) { _, meta -> ChannelCard(row, meta) }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }

        if (showM3uDialog) {
            M3uImportDialog(
                playlists = (vm.uiState as? LiveUiState.Content)?.playlists ?: emptyList(),
                onDismiss = { showM3uDialog = false },
                onAdd = { url ->
                    // Belt-and-braces: addM3uPlaylist returns Result instead of
                    // throwing, but a throw here would still kill the dialog's
                    // coroutine — never let it escape.
                    try {
                        repository.addM3uPlaylist(url).also { result ->
                            if (result.isSuccess) vm.load()
                        }
                    } catch (e: Exception) {
                        Result.failure<Int>(e)
                    }
                },
                onRemove = { url ->
                    scope.launch {
                        repository.removeM3uPlaylist(url)
                        vm.load()
                    }
                }
            )
        }
    }
}

/**
 * M3U/IPTV playlist import dialog (top-right button of the Live tab).
 * The playlist is fetched + parsed immediately, so a bad URL fails here
 * with a readable error instead of silently adding nothing.
 */
@Composable
private fun M3uImportDialog(
    playlists: List<String>,
    onDismiss: () -> Unit,
    onAdd: suspend (String) -> Result<Int>,
    onRemove: (String) -> Unit
) {
    var url by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LocalPalette.current.panel,
        title = { Text("Import M3U playlist", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                if (success != null) {
                    Text(success!!, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text(
                        "Paste an M3U / IPTV playlist URL — its channels appear grouped " +
                            "in the Live tab and play in the Plavio player.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; error = null },
                        placeholder = { Text("https://…/playlist.m3u", color = TextSecondary) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LocalPalette.current.accent,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = LocalPalette.current.accent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (error != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            error!!,
                            color = Color(0xFFFF6B6B),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                if (playlists.isNotEmpty() && success == null) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Imported playlists",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(4.dp))
                    playlists.forEach { pl ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                runCatching { java.net.URI(pl).host ?: pl }.getOrDefault(pl),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onRemove(pl) }) {
                                Icon(
                                    Icons.Filled.Delete, "Remove playlist",
                                    tint = TextSecondary, modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (success == null) {
                TextButton(
                    onClick = {
                        val u = url.trim()
                        if (u.isBlank()) {
                            error = "Paste a playlist URL first."
                            return@TextButton
                        }
                        adding = true
                        error = null
                        scope.launch {
                            val result = onAdd(u)
                            adding = false
                            if (result.isSuccess) {
                                val count = result.getOrNull() ?: 0
                                success = "Imported $count channel${if (count == 1) "" else "s"} ✓"
                            } else {
                                error = result.exceptionOrNull()?.message
                                    ?: "Couldn't import that playlist."
                            }
                        }
                    },
                    enabled = !adding && url.isNotBlank()
                ) {
                    Text(
                        if (adding) "Importing…" else "Import",
                        color = LocalPalette.current.accent,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text("Done", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            if (success == null) {
                TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
            }
        }
    )
}

/** FilterChip colors matching the Plavio dark aesthetic. */
@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
    selectedLabelColor = TextPrimary,
    containerColor = GlassWhite,
    labelColor = TextSecondary,
    selectedLeadingIconColor = LocalPalette.current.accent
)

/** Live indicator: a mint-green dot with a white center, gently pulsing (owner's order 2026-10-22: green, following the app theme). */
@Composable
private fun LiveDot(modifier: Modifier = Modifier) {
    val reduced = com.pulsestream.app.data.rememberReducedMotion()
    val alpha = if (reduced) 1f else {
        val transition = rememberInfiniteTransition(label = "livedot")
        val animated by transition.animateFloat(initialValue = 0.55f, targetValue = 1f,
            animationSpec = infiniteRepeatable(animation = tween(1100, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
            label = "livedotAlpha")
        animated
    }
    Box(
        modifier.size(15.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(15.dp)
                .clip(CircleShape)
                .background(Color(0xFF3DDC97).copy(alpha = alpha))
        )
        Box(
            Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
