package com.pulsestream.app.ui.components

import android.content.Context
import android.graphics.BitmapFactory
import com.pulsestream.app.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.File

/**
 * Fusion style badges (v0.14.36, Settings → Streams → Fusion style
 * badges): the ONE home for the user's own formatter/badge sources.
 *
 * Up to [FusionBadgeSources.MAX_SOURCES] sources, each either a
 * badge-pack LINK or a PASTED Fusion-style JSON (the filters[] /
 * Xperience shape the shipped import already parses — see
 * [collectPackEntries]). Each source installs its badge artwork
 * into its own directory; rendering tries the sources in list
 * order, then the built-in Elite artwork, then the house chip
 * (priority: addon formatter > user's Fusion sources > Elite).
 *
 * This replaces the v0.14.21 single imported pack: a user who
 * already imported one finds it here as source #1 (kind LEGACY,
 * artwork directory unchanged) via [ensureFusionMigration] —
 * migrated, never wiped.
 */

enum class FusionSourceKind { URL, PASTE, LEGACY }

data class FusionBadgeSource(
    val id: String,
    val kind: FusionSourceKind,
    /** Shown on the source's card: the pack's declared name, else the link's host, else "Pasted JSON". */
    val label: String,
    /** The source link for URL sources; null for pasted / legacy sources. */
    val locator: String? = null,
    /** Canonical badge keys this source carries, as installed. */
    val badgeKeys: List<String> = emptyList(),
    /** Group count as parsed: declared groups when the pack declares them, else distinct key families. */
    val groupCount: Int = 0,
    val addedAt: Long = 0L
) {
    val badgeCount: Int get() = badgeKeys.size
}

/** Pure list + shape rules for Fusion sources — unit-tested directly. */
object FusionBadgeSources {
    const val MAX_SOURCES = 3
    const val LEGACY_SOURCE_ID = "legacy"

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * The stored form: a JSON array of flat objects. Written and
     * read by hand over JsonElement — this tree deliberately has
     * no serialization compiler plugin (see StremioParser's doc),
     * so no @Serializable anywhere.
     */
    fun encode(sources: List<FusionBadgeSource>): String =
        buildJsonArray {
            sources.forEach { s ->
                add(
                    buildJsonObject {
                        put("id", JsonPrimitive(s.id))
                        put("kind", JsonPrimitive(s.kind.name))
                        put("label", JsonPrimitive(s.label))
                        s.locator?.let { put("locator", JsonPrimitive(it)) }
                        put("badgeKeys", buildJsonArray { s.badgeKeys.forEach { add(JsonPrimitive(it)) } })
                        put("groupCount", JsonPrimitive(s.groupCount))
                        put("addedAt", JsonPrimitive(s.addedAt))
                    }
                )
            }
        }.toString()

    fun decode(raw: String?): List<FusionBadgeSource> {
        val text = raw?.takeIf { it.isNotBlank() } ?: return emptyList()
        val root = runCatching { json.parseToJsonElement(text) }.getOrNull()
            ?: return emptyList()
        val array = root as? JsonArray ?: return emptyList()
        return array.mapNotNull { el ->
            val obj = el as? JsonObject ?: return@mapNotNull null
            val id = obj.str("id")?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val kind = obj.str("kind")?.let { name ->
                runCatching { FusionSourceKind.valueOf(name) }.getOrNull()
            } ?: return@mapNotNull null
            val keys = (obj["badgeKeys"] as? JsonArray)
                ?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
                ?: emptyList()
            FusionBadgeSource(
                id = id,
                kind = kind,
                label = obj.str("label") ?: "",
                locator = obj.str("locator"),
                badgeKeys = keys,
                groupCount = (obj["groupCount"] as? JsonPrimitive)?.contentOrNull
                    ?.toIntOrNull() ?: 0,
                addedAt = (obj["addedAt"] as? JsonPrimitive)?.contentOrNull
                    ?.toLongOrNull() ?: 0L
            )
        }
    }

    /** Adds a source; null when the cap is hit or the id is taken. */
    fun add(sources: List<FusionBadgeSource>, source: FusionBadgeSource): List<FusionBadgeSource>? {
        if (sources.size >= MAX_SOURCES) return null
        if (sources.any { it.id == source.id }) return null
        return sources + source
    }

    fun remove(sources: List<FusionBadgeSource>, id: String): List<FusionBadgeSource> =
        sources.filterNot { it.id == id }

    /** Replaces a source in place, keeping its position in the priority order. */
    fun replace(sources: List<FusionBadgeSource>, source: FusionBadgeSource): List<FusionBadgeSource> =
        sources.map { if (it.id == source.id) source else it }

    /**
     * Which source dresses each badge key: the FIRST source in list
     * order that carries the key owns it; later sources only fill
     * keys the earlier ones lack.
     */
    fun keyOwners(sources: List<FusionBadgeSource>): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        sources.forEachIndexed { index, source ->
            source.badgeKeys.forEach { key -> if (key !in out) out[key] = index }
        }
        return out
    }

    /**
     * Group count for a source: the pack's declared group count
     * when it declares groups, else the number of distinct badge
     * families among the installed keys (res / src / codec / hdr /
     * audio / ch / lang / tag; atmos and remux are their own).
     */
    fun groupCountFor(declaredGroupCount: Int?, badgeKeys: Collection<String>): Int {
        if (declaredGroupCount != null && declaredGroupCount > 0) return declaredGroupCount
        return badgeKeys.map { key ->
            if (key == "atmos" || key == "remux") key else key.substringBefore('-')
        }.distinct().size
    }

    /** The migrated pre-v0.14.36 single imported pack, as source #1. */
    fun legacySource(packName: String, badgeKeys: List<String>, addedAt: Long): FusionBadgeSource =
        FusionBadgeSource(
            id = LEGACY_SOURCE_ID,
            kind = FusionSourceKind.LEGACY,
            label = packName.ifBlank { "Imported pack" },
            locator = null,
            badgeKeys = badgeKeys,
            groupCount = groupCountFor(null, badgeKeys),
            addedAt = addedAt
        )
}

/** Outcome of parsing a pasted Fusion pack JSON, before any download happens. */
sealed interface FusionPackParse {
    data class Valid(
        val packName: String?,
        val entries: Map<String, String>,
        val declaredGroupCount: Int?
    ) : FusionPackParse

    data class Invalid(val reason: String) : FusionPackParse
}

private fun JsonObject.str(key: String): String? =
    (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull

/** Mirrors BadgePackImport.collectFromJsonObject: name → image URL pairs, one walk into nested objects. */
private fun collectDirectEntries(obj: JsonObject, into: MutableMap<String, String>) {
    for ((key, value) in obj) {
        when (value) {
            is JsonPrimitive ->
                if (value.isString && value.content.startsWith("http")) into[key] = value.content
            is JsonObject -> collectDirectEntries(value, into)
            else -> Unit
        }
    }
}

/**
 * Parses a PASTED Fusion-style badge JSON (the filters[] shape, or
 * a direct name → image-URL map). Pure (kotlinx, no org.json), so
 * the paste path is unit-tested. A pack is valid only when it names
 * at least one badge streams actually use — garbage is rejected
 * here, before anything touches disk, so a bad paste can never
 * half-apply or disturb the sources already installed.
 */
fun parseFusionPackJson(text: String): FusionPackParse {
    val trimmed = text.trim()
    if (trimmed.isEmpty()) return FusionPackParse.Invalid("Paste the pack JSON first")
    val root = runCatching { Json.parseToJsonElement(trimmed) }.getOrNull()
        ?: return FusionPackParse.Invalid("That doesn't look like valid JSON")
    val obj = root as? JsonObject
        ?: return FusionPackParse.Invalid("That JSON isn't a badge pack")
    val entries = LinkedHashMap<String, String>()
    var declaredGroups: Int? = null
    val filters = obj["filters"] as? JsonArray
    if (filters != null) {
        val groupIds = mutableSetOf<String>()
        for (el in filters) {
            val f = el as? JsonObject ?: continue
            val name = f.str("name") ?: continue
            val url = f.str("imageURL") ?: f.str("imageUrl") ?: f.str("url") ?: continue
            if (url.startsWith("http")) entries[name] = url
            f.str("groupId")?.takeIf { it.isNotBlank() }?.let { groupIds += it }
        }
        val groups = obj["groups"] as? JsonArray
        declaredGroups = when {
            groups != null && groups.isNotEmpty() -> groups.size
            groupIds.isNotEmpty() -> groupIds.size
            else -> null
        }
    }
    collectDirectEntries(obj, entries)
    if (entries.isEmpty()) return FusionPackParse.Invalid("No badges found in that JSON")
    if (entries.keys.none { canonicalBadgeKey(it) != null }) {
        return FusionPackParse.Invalid("None of those badges match the badges streams use")
    }
    return FusionPackParse.Valid(obj.str("name")?.takeIf { it.isNotBlank() }, entries, declaredGroups)
}

// ---------------------------------------------------------------------------
// Storage: prefs hold the source list; each source owns a directory.
// ---------------------------------------------------------------------------

/** Artwork root for Fusion sources (the legacy source keeps the old imported dir). */
fun fusionRootDir(context: Context): File = File(context.filesDir, "badges/fusion")

fun fusionSourceDir(context: Context, sourceId: String): File =
    if (sourceId == FusionBadgeSources.LEGACY_SOURCE_ID) badgeImportedDir(context)
    else File(fusionRootDir(context), sourceId)

fun loadFusionSources(settings: SettingsStore): List<FusionBadgeSource> =
    FusionBadgeSources.decode(settings.fusionBadgeSourcesJson)

fun saveFusionSources(settings: SettingsStore, sources: List<FusionBadgeSource>) {
    settings.fusionBadgeSourcesJson =
        if (sources.isEmpty()) null else FusionBadgeSources.encode(sources)
}

/**
 * The source ids the badge renderer should dress from, in priority
 * order — prefs only, no Context. Before the persistent migration
 * has run (the user never opened the Fusion screen), a legacy
 * single pack still counts: its id resolves to the old imported
 * directory, so its badges keep dressing streams untouched.
 */
fun SettingsStore.fusionSourceIds(): List<String> {
    val sources = loadFusionSources(this)
    if (sources.isNotEmpty()) return sources.map { it.id }
    return if (importedBadgePackName.isNotBlank()) {
        listOf(FusionBadgeSources.LEGACY_SOURCE_ID)
    } else {
        emptyList()
    }
}

/**
 * One-time migration: a pre-v0.14.36 imported pack becomes Fusion
 * source #1 (kind LEGACY — its link was never stored, so it can't
 * be re-fetched, only previewed or deleted). The artwork directory
 * does not move. Idempotent: once the list exists this is a read.
 */
fun ensureFusionMigration(context: Context, settings: SettingsStore): List<FusionBadgeSource> {
    val existing = loadFusionSources(settings)
    if (existing.isNotEmpty()) return existing
    val legacyName = settings.importedBadgePackName
    if (legacyName.isBlank()) return existing
    val keys = badgeImportedDir(context).listFiles()
        ?.filter { it.isFile && it.name.endsWith(".png") }
        ?.map { it.name.removeSuffix(".png") }
        ?.sorted()
        ?: emptyList()
    val source = FusionBadgeSources.legacySource(legacyName, keys, System.currentTimeMillis())
    val list = listOf(source)
    saveFusionSources(settings, list)
    settings.importedBadgePackName = ""
    return list
}

/** Downloads + validates badge artwork into [targetDir], swapping atomically (the shipped import's discipline). */
private suspend fun installFusionEntries(
    targetDir: File,
    entries: Map<String, String>
): List<String> = withContext(Dispatchers.IO) {
    val staging = File(targetDir.parentFile, targetDir.name + "-staging")
    staging.deleteRecursively()
    staging.mkdirs()
    val installed = mutableListOf<String>()
    for ((rawName, imageUrl) in entries) {
        if (installed.size >= 96) break
        val key = canonicalBadgeKey(rawName) ?: continue
        if (key in installed) continue
        val bytes = httpGetBytes(imageUrl) ?: continue
        if (bytes.isEmpty() || bytes.size > 2_000_000) continue
        // Only real, decodable images land — a broken "badge" must
        // not shadow the Elite / house fallback.
        if (BitmapFactory.decodeByteArray(bytes, 0, bytes.size) == null) continue
        File(staging, "$key.png").writeBytes(bytes)
        installed += key
    }
    if (installed.isEmpty()) {
        staging.deleteRecursively()
        throw IllegalStateException("No usable badges could be downloaded from that source")
    }
    targetDir.deleteRecursively()
    staging.renameTo(targetDir)
    installed
}

private class ParsedFusionBody(
    val entries: Map<String, String>,
    val packName: String?,
    val declaredGroupCount: Int?
)

/** Link bodies ride the paste parser first, then the shipped import's wider shapes (listings, pages). */
private fun parseFusionBody(body: String, baseUrl: String): ParsedFusionBody =
    when (val parsed = parseFusionPackJson(body)) {
        is FusionPackParse.Valid ->
            ParsedFusionBody(parsed.entries, parsed.packName, parsed.declaredGroupCount)
        is FusionPackParse.Invalid -> {
            val entries = collectPackEntries(body, baseUrl)
            if (entries.isEmpty()) throw IllegalStateException(parsed.reason)
            val name = runCatching {
                org.json.JSONObject(body.trim()).optString("name").ifBlank { null }
            }.getOrNull()
            ParsedFusionBody(entries, name, null)
        }
    }

private fun newFusionSourceId(): String =
    "src-" + java.util.UUID.randomUUID().toString().take(8)

private fun fusionCapMessage(): String =
    "You can keep up to ${FusionBadgeSources.MAX_SOURCES} Fusion sources — delete one first"

/** Adds a badge-pack LINK as a new Fusion source (re-adding the same link updates that source in place). */
suspend fun addFusionSourceFromUrl(
    context: Context,
    settings: SettingsStore,
    rawUrl: String
): Result<FusionBadgeSource> = runCatching {
    val url = rawUrl.trim()
    require(url.startsWith("https://") || url.startsWith("http://")) {
        "That link doesn't look right"
    }
    val sources = ensureFusionMigration(context, settings)
    sources.firstOrNull { it.kind == FusionSourceKind.URL && it.locator == url }?.let {
        return updateFusionSource(context, settings, it.id)
    }
    require(sources.size < FusionBadgeSources.MAX_SOURCES) { fusionCapMessage() }
    val body = httpGetBytes(url)?.toString(Charsets.UTF_8)
        ?: throw IllegalStateException("Couldn't open that link")
    val parsed = parseFusionBody(body, url)
    val id = newFusionSourceId()
    val keys = installFusionEntries(fusionSourceDir(context, id), parsed.entries)
    val source = FusionBadgeSource(
        id = id,
        kind = FusionSourceKind.URL,
        label = parsed.packName ?: url.toHttpUrlOrNull()?.host ?: "Link",
        locator = url,
        badgeKeys = keys,
        groupCount = FusionBadgeSources.groupCountFor(parsed.declaredGroupCount, keys),
        addedAt = System.currentTimeMillis()
    )
    saveFusionSources(settings, FusionBadgeSources.add(sources, source) ?: sources)
    source
}

/**
 * Adds a PASTED Fusion pack JSON as a new Fusion source. The JSON
 * is fully parsed and validated first — a bad paste is rejected
 * with a plain reason and nothing on disk changes.
 */
suspend fun addFusionSourceFromText(
    context: Context,
    settings: SettingsStore,
    text: String
): Result<FusionBadgeSource> = runCatching {
    val parsed = when (val p = parseFusionPackJson(text)) {
        is FusionPackParse.Valid -> p
        is FusionPackParse.Invalid -> throw IllegalStateException(p.reason)
    }
    val sources = ensureFusionMigration(context, settings)
    require(sources.size < FusionBadgeSources.MAX_SOURCES) { fusionCapMessage() }
    val id = newFusionSourceId()
    val keys = installFusionEntries(fusionSourceDir(context, id), parsed.entries)
    val source = FusionBadgeSource(
        id = id,
        kind = FusionSourceKind.PASTE,
        label = parsed.packName ?: "Pasted JSON",
        locator = null,
        badgeKeys = keys,
        groupCount = FusionBadgeSources.groupCountFor(parsed.declaredGroupCount, keys),
        addedAt = System.currentTimeMillis()
    )
    saveFusionSources(settings, FusionBadgeSources.add(sources, source) ?: sources)
    source
}

/** Re-fetches a link source and reinstalls its badges in place; a failed update keeps the old badges. */
suspend fun updateFusionSource(
    context: Context,
    settings: SettingsStore,
    id: String
): Result<FusionBadgeSource> = runCatching {
    val sources = ensureFusionMigration(context, settings)
    val current = sources.firstOrNull { it.id == id }
        ?: throw IllegalStateException("That source is gone")
    val url = current.locator?.takeIf { current.kind == FusionSourceKind.URL }
        ?: throw IllegalStateException("Only link sources can be updated")
    val body = httpGetBytes(url)?.toString(Charsets.UTF_8)
        ?: throw IllegalStateException("Couldn't open that link")
    val parsed = parseFusionBody(body, url)
    val keys = installFusionEntries(fusionSourceDir(context, id), parsed.entries)
    val updated = current.copy(
        label = parsed.packName ?: current.label,
        badgeKeys = keys,
        groupCount = FusionBadgeSources.groupCountFor(parsed.declaredGroupCount, keys)
    )
    saveFusionSources(settings, FusionBadgeSources.replace(sources, updated))
    updated
}

/** Deletes a source and its artwork; returns the remaining list. */
suspend fun deleteFusionSource(
    context: Context,
    settings: SettingsStore,
    id: String
): List<FusionBadgeSource> = withContext(Dispatchers.IO) {
    val sources = ensureFusionMigration(context, settings)
    val remaining = FusionBadgeSources.remove(sources, id)
    saveFusionSources(settings, remaining)
    runCatching { fusionSourceDir(context, id).deleteRecursively() }
    if (id == FusionBadgeSources.LEGACY_SOURCE_ID) settings.importedBadgePackName = ""
    remaining
}
