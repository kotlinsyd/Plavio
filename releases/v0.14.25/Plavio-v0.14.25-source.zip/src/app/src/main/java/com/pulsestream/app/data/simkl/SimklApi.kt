package com.pulsestream.app.data.simkl

import com.pulsestream.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Raw HTTP client for the Simkl API (https://api.simkl.com).
 *
 * Login uses OAuth 2.0 Authorization Code + PKCE (v0.14.11), the
 * same shape as this app's Trakt login: app builds an authorize URL
 * -> user approves in the browser -> our callback page shows the
 * code -> user pastes it into the app -> POST /oauth2/token
 * exchanges it (no client secret).
 *
 * Why not the other flows: our client_id is registered as an
 * OAuth 2.0 app, so Simkl hard-refuses /oauth/pin for it
 * (HTTP 400 unauthorized_client: "use POST /oauth2/device instead"),
 * and the device grant it points to issues UNDER-SCOPED tokens —
 * reads worked but every sync write was refused with
 * 403 insufficient_scope (owner's v0.14.9 screenshot).
 *
 * v0.14.13 — the last missing piece: Simkl's developer page states
 * permissions are requested AT SIGN-IN, not at app registration:
 * "media:read is the default" and "media:write adds permission to
 * change them and includes read access." The authorize URL must
 * carry scope=media:write or every grant is read-only (the owner's
 * Connected Apps entry literally showed "Read only") and every
 * /sync write returns 403 insufficient_scope. The same page states
 * access tokens last 7 days and refresh tokens expire after 180
 * days, so AUTH V2 DOES issue a refresh token — it is stored and
 * used (see SimklManager) instead of forcing a weekly relink.
 */
class SimklApi {

    companion object {
        const val CLIENT_ID = "c1cbe532ad5f4224a0ffe1da154d321c7656ab23bd7f8bf45d77844fca42ad38"
        const val REDIRECT_URI = "https://www.plavio.site/simkl-callback.html"
        private const val BASE = "https://api.simkl.com"
        private const val AUTHORIZE_URL = "https://simkl.com/oauth2/authorize"
        private const val TOKEN_URL = "$BASE/oauth2/token"
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }

    /** Simkl refused the exchange; [message] is Simkl's own error text. */
    class AuthException(message: String) : Exception(message)

    /**
     * A library READ answered with an HTTP error; [code] carries
     * the status so callers can spot a 401 token rejection — the
     * read-side twin of [WriteResult.tokenRejected] (v0.14.41:
     * TrackingWrites' read safety net keys off this). It extends
     * IllegalStateException with the reads' long-standing
     * message, so existing catch behaviour is unchanged.
     */
    class ReadHttpException(val code: Int) :
        IllegalStateException("Simkl library failed (HTTP $code)")

    data class Pkce(val verifier: String, val challenge: String, val state: String)

    private val userAgent = "Plavio/${BuildConfig.VERSION_NAME}"

    /**
     * Simkl's current contract (api.simkl.org reference — client_id,
     * app-name and app-version are REQUIRED; the working Nuvio client
     * sends them the same way): the three ride as QUERY PARAMS on
     * every API call, on top of the Bearer + simkl-api-key headers.
     * Without them Simkl rejects even a fresh token's writes with
     * 401 user_token_failed (owner's v0.14.8 fresh reconnect proved
     * the token was never the problem). Any existing query params on
     * [url] are preserved.
     */
    private fun identified(url: String): String {
        val separator = if (url.contains('?')) "&" else "?"
        return url + separator +
            "client_id=$CLIENT_ID&app-name=Plavio&app-version=${BuildConfig.VERSION_NAME}"
    }

    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Generates a PKCE verifier/challenge pair plus a state token (mirrors TraktApi). */
    fun newPkce(): Pkce {
        val random = java.security.SecureRandom()
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
        val verifier = buildString {
            repeat(64) { append(chars[random.nextInt(chars.length)]) }
        }
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(verifier.toByteArray())
        val challenge = java.util.Base64.getUrlEncoder().withoutPadding()
            .encodeToString(digest)
        val state = buildString {
            repeat(16) { append(chars[random.nextInt(62)]) }
        }
        return Pkce(verifier, challenge, state)
    }

    /** The URL the user opens in a browser to approve Plavio. */
    fun authorizeUrl(pkce: Pkce): String {
        val params = listOf(
            "response_type" to "code",
            "client_id" to CLIENT_ID,
            "redirect_uri" to REDIRECT_URI,
            // Simkl grants media:read by default; media:write must be
            // requested here or the token can never write (v0.14.13).
            "scope" to "media:write",
            "code_challenge" to pkce.challenge,
            "code_challenge_method" to "S256",
            "state" to pkce.state
        ).joinToString("&") { (k, v) -> "$k=${java.net.URLEncoder.encode(v, "UTF-8")}" }
        return "$AUTHORIZE_URL?$params"
    }

    /** An access token plus the refresh token Simkl issued with it, when it did. */
    data class Tokens(val accessToken: String, val refreshToken: String?)

    /**
     * Exchanges the pasted authorization code for tokens.
     * No client secret (public client + PKCE). AUTH V2 issues a
     * refresh token alongside the access token (access: 7 days,
     * refresh: 180 days, per Simkl's developer page) — it rides back
     * in [Tokens.refreshToken] whenever the response carries one.
     *
     * On an HTTP error, Simkl's own `message` field (falling back to
     * `error`) is thrown as [AuthException] so the Link dialog can
     * show the user Simkl's words, not a guess. Genuine network
     * failures surface as IOException for the caller to tell apart.
     */
    suspend fun exchangeCode(code: String, verifier: String): Tokens {
        val body = JSONObject()
            .put("grant_type", "authorization_code")
            .put("code", code.trim())
            .put("redirect_uri", REDIRECT_URI)
            .put("client_id", CLIENT_ID)
            .put("code_verifier", verifier)
        return postToken(body)
    }

    /**
     * Trades a stored refresh token for a fresh token pair
     * (POST /oauth2/token, grant_type=refresh_token). Throws
     * [AuthException] with Simkl's own text on refusal.
     */
    suspend fun refreshAccessToken(refreshToken: String): Tokens {
        val body = JSONObject()
            .put("grant_type", "refresh_token")
            .put("refresh_token", refreshToken)
            .put("client_id", CLIENT_ID)
        return postToken(body)
    }

    private suspend fun postToken(body: JSONObject): Tokens = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(TOKEN_URL)
            .header("User-Agent", userAgent)
            .post(body.toString().toRequestBody(JSON))
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val json = runCatching { JSONObject(text) }.getOrNull()
                val message = json?.optString("message")?.takeIf { it.isNotBlank() }
                    ?: json?.optString("error")?.takeIf { it.isNotBlank() }
                    ?: "Simkl refused the token request (HTTP ${response.code})"
                throw AuthException(message)
            }
            val json = JSONObject(text)
            val token = json.optString("access_token")
            if (token.isBlank()) throw AuthException("Simkl's reply carried no access token.")
            Tokens(token, json.optString("refresh_token").takeIf { it.isNotBlank() })
        }
    }

    /** Fetch the linked account's display name. */
    suspend fun getUsername(token: String): String? = withContext(Dispatchers.IO) {
        val request = authedRequest(token, "$BASE/users/settings").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val bodyStr = response.body?.string() ?: return@withContext null
            val json = JSONObject(bodyStr)
            json.optJSONObject("user")?.optString("name", null)
        }
    }

    /**
     * Send a scrobble event. [action] is one of "start", "pause", "stop".
     * @return true if the server accepted it.
     */
    suspend fun scrobble(token: String, action: String, body: JSONObject): Boolean =
        withContext(Dispatchers.IO) {
            val request = authedRequest(token, "$BASE/scrobble/$action")
                .post(body.toString().toRequestBody(JSON))
                .build()
            client.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        }

    // ---- Library lists (library sync, issue #3) ----

    /** One Simkl library entry. [type] is "movie" or "series". */
    data class ListEntry(
        val type: String,
        val imdbId: String,
        val title: String,
        /** Release year when the caller knows it; 0 = unknown (omitted from write bodies). */
        val year: Int = 0,
        // v0.14.19 (all-lists display): reads no longer drop entries
        // without an IMDb id — they carry the best id Simkl gave
        // (TMDB, else Simkl's own) plus Simkl's poster, so the
        // Library displays everything the service returns.
        val tmdbId: Int? = null,
        val simklId: Long? = null,
        val poster: String? = null
    ) {
        /**
         * Best display/navigation identity: the IMDb id when present,
         * else a TMDB-native id (meta addons resolve those), else the
         * Simkl id (display-only, with Simkl's own title/poster).
         */
        val key: String
            get() = when {
                imdbId.startsWith("tt") -> imdbId
                tmdbId != null -> "tmdb:${if (type == "movie") "movie" else "tv"}:$tmdbId"
                simklId != null -> "simkl:$simklId"
                else -> imdbId
            }
    }

    /** Simkl image paths ride the fanart CDN unless already absolute. */
    private fun simklPoster(raw: String?): String? {
        val p = raw?.takeIf { it.isNotBlank() } ?: return null
        return if (p.startsWith("http")) p else "https://simkl.in/fanart/$p"
    }

    /**
     * v0.14.19: builds a [ListEntry] from one all-items/list node
     * WITHOUT the old IMDb-only drop — the entry survives on any
     * usable id (imdb → tmdb → simkl) and carries Simkl's poster.
     * Null only when the node carries no id at all. Consumers that
     * merge into IMDb-keyed stores filter on imdbId themselves.
     */
    private fun parseSimklEntry(item: JSONObject, node: JSONObject, type: String): ListEntry? {
        val ids = node.optJSONObject("ids")
        val imdb = ids?.optString("imdb")?.takeIf { it.startsWith("tt") }.orEmpty()
        val tmdb = ids?.optInt("tmdb", 0)?.takeIf { it > 0 }
        val simkl = ids?.optLong("simkl", 0L)?.takeIf { it > 0 }
        if (imdb.isEmpty() && tmdb == null && simkl == null) return null
        return ListEntry(
            type = type,
            imdbId = imdb,
            title = node.optString("title"),
            year = node.optInt("year", 0),
            tmdbId = tmdb,
            simklId = simkl,
            poster = simklPoster(node.optString("poster"))
                ?: simklPoster(item.optString("poster"))
        )
    }

    /**
     * The user's Simkl library — Plan to Watch + Watching only (Completed /
     * On Hold / Dropped are not "library" in Plavio's sense). Throws on
     * failure so the sync can tell "empty" from "unreachable".
     */
    suspend fun getAllItems(token: String): List<ListEntry> = withContext(Dispatchers.IO) {
        val request = authedRequest(token, "$BASE/sync/all-items").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw ReadHttpException(response.code)
            }
            val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
            val out = mutableListOf<ListEntry>()
            fun collect(section: String, type: String, nodeName: String) {
                val arr = root.optJSONArray(section) ?: return
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val status = item.optString("status")
                    if (status != "plantowatch" && status != "watching") continue
                    val node = item.optJSONObject(nodeName) ?: continue
                    parseSimklEntry(item, node, type)?.let { out += it }
                }
            }
            collect("movies", "movie", "movie")
            collect("shows", "series", "show")
            collect("anime", "series", "anime")
            out
        }
    }

    /** One show the user is currently watching on Simkl. */
    data class WatchingEntry(
        val imdbId: String,
        val title: String,
        val watchedEpisodes: Int?,
        val totalEpisodes: Int?,
        val lastWatchedAt: String?,
        // v0.14.19: same widening as ListEntry (see its key).
        val tmdbId: Int? = null,
        val simklId: Long? = null,
        val poster: String? = null
    ) {
        val key: String
            get() = when {
                imdbId.startsWith("tt") -> imdbId
                tmdbId != null -> "tmdb:tv:$tmdbId"
                simklId != null -> "simkl:$simklId"
                else -> imdbId
            }
    }

    /** Shows with Simkl status "watching" (the Library screen's Up Next input). */
    suspend fun getWatching(token: String): List<WatchingEntry> = withContext(Dispatchers.IO) {
        val request = authedRequest(token, "$BASE/sync/all-items").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw ReadHttpException(response.code)
            }
            val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
            val out = mutableListOf<WatchingEntry>()
            fun collect(section: String, nodeName: String) {
                val arr = root.optJSONArray(section) ?: return
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    if (item.optString("status") != "watching") continue
                    val node = item.optJSONObject(nodeName) ?: continue
                    val ids = node.optJSONObject("ids")
                    val imdb = ids?.optString("imdb")
                        ?.takeIf { it.startsWith("tt") }.orEmpty()
                    val tmdb = ids?.optInt("tmdb", 0)?.takeIf { it > 0 }
                    val simklId = ids?.optLong("simkl", 0L)?.takeIf { it > 0 }
                    if (imdb.isEmpty() && tmdb == null && simklId == null) continue
                    out += WatchingEntry(
                        imdbId = imdb,
                        title = node.optString("title"),
                        tmdbId = tmdb,
                        simklId = simklId,
                        poster = simklPoster(node.optString("poster"))
                            ?: simklPoster(item.optString("poster")),
                        watchedEpisodes = item.optInt("watched_episodes_count", -1).takeIf { it >= 0 },
                        totalEpisodes = item.optInt("total_episodes_count", -1).takeIf { it > 0 },
                        lastWatchedAt = item.optString("last_watched_at").takeIf { it.isNotBlank() }
                    )
                }
            }
            collect("shows", "show")
            collect("anime", "anime")
            out
        }
    }

    /** Plan-to-Watch items only (the Library screen's Simkl watchlist row). */
    suspend fun getPlanToWatch(token: String): List<ListEntry> = withContext(Dispatchers.IO) {
        val request = authedRequest(token, "$BASE/sync/all-items").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw ReadHttpException(response.code)
            }
            val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
            val out = mutableListOf<ListEntry>()
            fun collect(section: String, type: String, nodeName: String) {
                val arr = root.optJSONArray(section) ?: return
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    if (item.optString("status") != "plantowatch") continue
                    val node = item.optJSONObject(nodeName) ?: continue
                    parseSimklEntry(item, node, type)?.let { out += it }
                }
            }
            collect("movies", "movie", "movie")
            collect("shows", "series", "show")
            collect("anime", "series", "anime")
            out
        }
    }

    // ---- Phase 1 write layer (v0.14.6): statuses, history, results ----

    /** Simkl's five statuses — exactly one per title. */
    object Statuses {
        const val WATCHING = "watching"
        const val PLAN_TO_WATCH = "plantowatch"
        const val HOLD = "hold"
        const val COMPLETED = "completed"
        const val DROPPED = "dropped"
        val ALL = listOf(WATCHING, PLAN_TO_WATCH, HOLD, COMPLETED, DROPPED)
        fun label(status: String): String = when (status) {
            WATCHING -> "Watching"
            PLAN_TO_WATCH -> "Plan to Watch"
            HOLD -> "On Hold"
            COMPLETED -> "Completed"
            DROPPED -> "Dropped"
            else -> status
        }

        // Simkl is strict about write pacing (report §1): one shared
        // lock + >=1s between POSTs across every SimklApi instance.
        private val writeMutex = kotlinx.coroutines.sync.Mutex()
        private var lastWriteAtMs = 0L

        internal suspend fun <T> pacedWrite(block: suspend () -> T): T =
            writeMutex.withLock {
                val wait = 1000L - (System.currentTimeMillis() - lastWriteAtMs)
                if (wait > 0 && lastWriteAtMs > 0) kotlinx.coroutines.delay(wait)
                try {
                    block()
                } finally {
                    lastWriteAtMs = System.currentTimeMillis()
                }
            }
    }

    /**
     * Outcome of a write: ok + a message the UI can show as-is.
     * [authFailed] is set when Simkl answered 401/403 — the saved
     * token is unusable for writes; callers drop the stale link
     * state (v0.14.8, #9). Both dead-token shapes land here: 401
     * `user_token_failed` (token rejected outright — callers first
     * try one refresh + retry, v0.14.13) and 403
     * `insufficient_scope` (a read-only grant — before v0.14.13 the
     * authorize URL requested no scope, so Simkl's media:read
     * default applied; clearing forces the one-time relink through
     * the code+PKCE flow, which now asks for media:write).
     */
    data class WriteResult(
        val ok: Boolean,
        val message: String,
        val authFailed: Boolean = false,
        /**
         * True only for a 401 (user_token_failed): the access token
         * itself was rejected, so ONE refresh + retry is worth trying
         * before the link is given up on (v0.14.13). A 403
         * insufficient_scope is a scope problem, not an expiry —
         * refreshing cannot fix it, so it never sets this.
         */
        val tokenRejected: Boolean = false
    )

    /** A library entry WITH its Simkl status. */
    data class StatusEntry(
        val type: String, val imdbId: String, val title: String, val status: String,
        // v0.14.19: same widening as ListEntry (see its key).
        val tmdbId: Int? = null,
        val simklId: Long? = null,
        val poster: String? = null
    ) {
        val key: String
            get() = when {
                imdbId.startsWith("tt") -> imdbId
                tmdbId != null -> "tmdb:${if (type == "movie") "movie" else "tv"}:$tmdbId"
                simklId != null -> "simkl:$simklId"
                else -> imdbId
            }
    }

    /** Every library item with its status (all five). Throws on failure. */
    suspend fun getAllItemsWithStatus(token: String): List<StatusEntry> =
        withContext(Dispatchers.IO) {
            val request = authedRequest(token, "$BASE/sync/all-items").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw ReadHttpException(response.code)
                }
                val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
                val out = mutableListOf<StatusEntry>()
                fun collect(section: String, type: String, nodeName: String) {
                    val arr = root.optJSONArray(section) ?: return
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val status = item.optString("status")
                        if (status !in Statuses.ALL) continue
                        val node = item.optJSONObject(nodeName) ?: continue
                        val entry = parseSimklEntry(item, node, type) ?: continue
                        out += StatusEntry(
                            type, entry.imdbId, entry.title, status,
                            entry.tmdbId, entry.simklId, entry.poster
                        )
                    }
                }
                collect("movies", "movie", "movie")
                collect("shows", "series", "show")
                collect("anime", "series", "anime")
                out
            }
        }

    // ---- Custom lists (READ-ONLY — a hard Simkl API limitation) ----

    /** One of the user's own Simkl lists. */
    data class CustomListInfo(val id: Long, val name: String, val itemCount: Int)

    /**
     * Simkl custom lists are READ-ONLY through the API. Verified
     * against Simkl's official OpenAPI spec (api.simkl.org/openapi.json,
     * fetched 2026-10-27): the only list endpoints in the entire API
     * are GET /lists/user/{userId} and GET /lists/{id}, and the spec
     * says of the latter: "Reads only. Creating lists, editing them
     * and adding or removing items are done on the website and are
     * not yet part of the API." There is NO write endpoint for lists,
     * so app playlists cannot be pushed to Simkl as Simkl lists —
     * these calls implement the direction the API does support: the
     * user's Simkl lists appear in the app Library.
     *
     * Both endpoints are PRO/VIP-only: free accounts get HTTP 200
     * with {"error":"premium_only", ...} and no items array — treated
     * here as "no lists", so the Library simply doesn't show them.
     */

    /** The account's numeric user id (needed for the lists call) + plan. */
    suspend fun getAccountInfo(token: String): Pair<Long, String>? =
        withContext(Dispatchers.IO) {
            val request = authedRequest(token, "$BASE/users/settings").get().build()
            client.newCall(request).execute().use { response ->
                // A 401 is a token rejection, not "no account" —
                // surface it typed (v0.14.41) so the read safety
                // net can refresh + retry; other failures keep
                // the long-standing null.
                if (!response.isSuccessful) {
                    if (response.code == 401) throw ReadHttpException(401)
                    return@withContext null
                }
                val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
                val account = root.optJSONObject("account") ?: return@withContext null
                val id = account.optLong("id", 0L)
                if (id == 0L) null else id to account.optString("type")
            }
        }

    /** The user's custom lists (empty for free accounts / failures). */
    suspend fun getCustomLists(token: String): List<CustomListInfo> =
        withContext(Dispatchers.IO) {
            val account = getAccountInfo(token) ?: return@withContext emptyList()
            val request = authedRequest(token, "$BASE/lists/user/${account.first}").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    if (response.code == 401) throw ReadHttpException(401)
                    return@withContext emptyList()
                }
                val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
                if (root.optString("error") == "premium_only") return@withContext emptyList()
                val arr = root.optJSONArray("lists") ?: return@withContext emptyList()
                val out = mutableListOf<CustomListInfo>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optLong("id", 0L)
                    if (id == 0L) continue
                    out += CustomListInfo(
                        id = id,
                        name = o.optString("name").ifBlank { "Simkl list" },
                        itemCount = o.optJSONObject("counts")?.optInt("items", 0) ?: 0
                    )
                }
                out
            }
        }

    /**
     * One custom list's items. Since v0.14.19 they follow the same
     * widened rule as every other Simkl read: an item survives on
     * any usable id (imdb → tmdb → simkl) and displays with Simkl's
     * own title/poster when no addon can resolve it.
     */
    suspend fun getCustomListItems(token: String, listId: Long): List<ListEntry> =
        withContext(Dispatchers.IO) {
            val request = authedRequest(token, "$BASE/lists/$listId").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    if (response.code == 401) throw ReadHttpException(401)
                    return@withContext emptyList()
                }
                val root = JSONObject(response.body?.string().orEmpty().ifBlank { "{}" })
                if (root.optString("error") == "premium_only") return@withContext emptyList()
                val arr = root.optJSONArray("items") ?: return@withContext emptyList()
                val out = mutableListOf<ListEntry>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val type = when (o.optString("type")) {
                        "movie" -> "movie"
                        else -> "series" // "tv" / "anime" / "show"
                    }
                    parseSimklEntry(o, o, type)?.let { out += it }
                }
                out
            }
        }

    private fun simklErrorMessage(code: Int): String = when (code) {
        401, 403 -> "Simkl link expired — reconnect Simkl in Settings → Integrations."
        429 -> "Simkl is rate-limiting — wait a moment and try again."
        -1 -> "Couldn't reach Simkl. Check your connection and try again."
        else -> "Simkl didn't accept that (HTTP $code)."
    }

    /**
     * Failure message with Simkl's OWN error text appended (v0.14.8,
     * owner's #9): the API answers failures with a JSON body like
     * {"error":"user_token_failed","code":401} — surfacing that text
     * turns a guessing game ("link expired"?) into a diagnosis.
     *
     * v0.14.10: the base message keys off the parsed error string,
     * not just the HTTP code. 403 `insufficient_scope` is NOT an
     * expired link — it's a read-only grant, which can never write;
     * the honest message says so and asks for the one-time reconnect
     * through the code+PKCE flow (which requests media:write since
     * v0.14.13; the link itself is cleared either way — see
     * [WriteResult.authFailed]).
     */
    private fun simklFailureMessage(code: Int, bodyText: String): String {
        val said = runCatching {
            val root = JSONObject(bodyText)
            root.optString("error").ifBlank { root.optString("message") }
        }.getOrNull()?.takeIf { it.isNotBlank() }
        val base = when {
            code == 403 && said == "insufficient_scope" ->
                "Simkl link is missing the save permission — reconnect Simkl in Settings → Integrations."
            else -> simklErrorMessage(code)
        }
        return if (said != null) "$base (Simkl said: $said, HTTP $code)" else "$base (HTTP $code)"
    }

    private fun simklFailure(code: Int, bodyText: String): WriteResult =
        WriteResult(
            ok = false,
            message = simklFailureMessage(code, bodyText),
            authFailed = code == 401 || code == 403,
            tokenRejected = code == 401
        )

    private suspend fun postJsonResult(token: String, path: String, body: JSONObject): WriteResult =
        Statuses.pacedWrite {
            withContext(Dispatchers.IO) {
                val request = authedRequest(token, "$BASE$path")
                    .post(body.toString().toRequestBody(JSON)).build()
                try {
                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            WriteResult(true, "Done on Simkl.")
                        } else {
                            // Simkl's sync-write lock answers 400 with a
                            // rate_limit error — one retry after a pause
                            // instead of failing (report §1).
                            val text = runCatching { response.body?.string().orEmpty() }.getOrDefault("")
                            if (response.code == 400 && text.contains("rate_limit")) {
                                kotlinx.coroutines.delay(3000)
                                val retry = authedRequest(token, "$BASE$path")
                                    .post(body.toString().toRequestBody(JSON)).build()
                                client.newCall(retry).execute().use { second ->
                                    if (second.isSuccessful) WriteResult(true, "Done on Simkl.")
                                    else {
                                        val secondText = runCatching {
                                            second.body?.string().orEmpty()
                                        }.getOrDefault("")
                                        simklFailure(second.code, secondText)
                                    }
                                }
                            } else {
                                simklFailure(response.code, text)
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    WriteResult(false, simklErrorMessage(-1))
                }
            }
        }

    private fun entriesBody(entries: List<ListEntry>, status: String?): JSONObject {
        val movies = org.json.JSONArray()
        val shows = org.json.JSONArray()
        entries.forEach { e ->
            val obj = JSONObject().put("ids", JSONObject().put("imdb", e.imdbId))
            if (e.title.isNotBlank()) obj.put("title", e.title)
            if (e.year > 0) obj.put("year", e.year)
            // Verified contract (Trakt-Simkl research report, from the
            // working client): `to` rides PER ITEM —
            // {movies|shows: [{to: "watching", title, year, ids:{…}}]}.
            // A root-level `to` (the v0.14.9 reading) leaves every item
            // without a target list and Simkl answers 400 empty_field.
            // Remove calls (status == null) carry no `to` anywhere.
            if (status != null) obj.put("to", status)
            if (e.type == "movie") movies.put(obj) else shows.put(obj)
        }
        val body = JSONObject()
        if (movies.length() > 0) body.put("movies", movies)
        if (shows.length() > 0) body.put("shows", shows)
        return body
    }

    /**
     * Sets (or MOVES) titles to a Simkl status — one /sync/add-to-list
     * call per title set; each item carries its own `to`, title and
     * year, per Simkl's verified contract.
     */
    suspend fun setStatus(token: String, entries: List<ListEntry>, status: String): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to change.")
        val result = postJsonResult(token, "/sync/add-to-list", entriesBody(entries, status))
        return if (result.ok) {
            WriteResult(true, "Set to ${Statuses.label(status)} on Simkl.")
        } else result
    }

    /** Removes titles from the Simkl library entirely. */
    suspend fun removeFromLibrary(token: String, entries: List<ListEntry>): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to remove.")
        val result = postJsonResult(token, "/sync/remove-from-list", entriesBody(entries, null))
        return if (result.ok) WriteResult(true, "Removed from your Simkl library.") else result
    }

    /** One title (or show + episodes) for a /sync/history write. */
    data class HistoryItem(
        val type: String,
        val imdbId: String,
        val title: String,
        val episodes: List<Pair<Int, Int>> = emptyList()
    )

    private fun historyBody(items: List<HistoryItem>): JSONObject {
        val movies = org.json.JSONArray()
        val shows = org.json.JSONArray()
        for (item in items) {
            val ids = JSONObject().put("imdb", item.imdbId)
            if (item.type == "movie") {
                movies.put(JSONObject().put("title", item.title).put("ids", ids))
            } else {
                val obj = JSONObject().put("title", item.title).put("ids", ids)
                if (item.episodes.isNotEmpty()) {
                    val seasonsArr = org.json.JSONArray()
                    item.episodes.groupBy({ it.first }, { it.second }).forEach { (season, eps) ->
                        val epsArr = org.json.JSONArray()
                        eps.distinct().sorted().forEach { n ->
                            epsArr.put(JSONObject().put("number", n))
                        }
                        seasonsArr.put(JSONObject().put("number", season).put("episodes", epsArr))
                    }
                    obj.put("seasons", seasonsArr)
                }
                shows.put(obj)
            }
        }
        val body = JSONObject()
        if (movies.length() > 0) body.put("movies", movies)
        if (shows.length() > 0) body.put("shows", shows)
        return body
    }

    /** Marks titles/episodes watched on Simkl (POST /sync/history). */
    suspend fun markWatched(token: String, items: List<HistoryItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to mark.")
        val result = postJsonResult(token, "/sync/history", historyBody(items))
        return if (result.ok) WriteResult(true, "Marked watched on Simkl.") else result
    }

    /** Removes titles/episodes from Simkl watched history. */
    suspend fun unmarkWatched(token: String, items: List<HistoryItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to unmark.")
        val result = postJsonResult(token, "/sync/history/remove", historyBody(items))
        return if (result.ok) WriteResult(true, "Removed from your Simkl history.") else result
    }

    /** Adds entries to the Simkl library as Plan to Watch (= tracked on Simkl). Best-effort. */
    suspend fun addToList(token: String, entries: List<ListEntry>): Boolean =
        postList(token, "$BASE/sync/add-to-list", entries, withStatus = true)

    /** Removes entries from the Simkl library. Best-effort. */
    suspend fun removeFromList(token: String, entries: List<ListEntry>): Boolean =
        postList(token, "$BASE/sync/remove-from-list", entries, withStatus = false)

    private suspend fun postList(
        token: String,
        url: String,
        entries: List<ListEntry>,
        withStatus: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        if (entries.isEmpty()) return@withContext true
        // Same verified body as setStatus: per-item `to` ("plantowatch"
        // for adds), title and year riding on each item.
        val body = entriesBody(entries, if (withStatus) "plantowatch" else null)
        val request = authedRequest(token, url)
            .post(body.toString().toRequestBody(JSON))
            .build()
        try {
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (_: Exception) {
            false
        }
    }

    private fun authedRequest(token: String, url: String): Request.Builder =
        Request.Builder()
            .url(identified(url))
            .header("User-Agent", userAgent)
            .header("Accept", "application/json")
            .header("Authorization", "Bearer $token")
            .header("simkl-api-key", CLIENT_ID)
}
