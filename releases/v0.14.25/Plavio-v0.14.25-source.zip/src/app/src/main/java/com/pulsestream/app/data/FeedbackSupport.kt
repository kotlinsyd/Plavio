package com.pulsestream.app.data

import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Pure logic for the playback feedback reporter (v0.14.28): the app
 * tells PlavioHD which streams actually played and which died, so
 * source health is MEASURED from real playback instead of guessed
 * from probes. Server contract (PlavioHD v1.9.129):
 *
 *   POST {plaviohd-base}/feedback
 *   { v:1, token, titleId, source, url,
 *     outcome:"played"|"failed", failClass, playedSecs? }
 *
 * The token is a random per-install id that rotates daily — no
 * account, device, or user identifier ever leaves the app (see
 * [tokenFor]). The server fingerprints the URL host+path itself
 * (query stripped server-side); the app sends the URL as played.
 *
 * Everything here is free of Android/Media3 types so the unit tests
 * pin the exact rules the player uses: the error classifier, the
 * per-attempt state machine ([Tracker]), token rotation, and the
 * payload shape. The player seam (PlayerScreen) only extracts facts
 * and ticks the tracker; [PlavioFeedback] only transports.
 *
 * Classification honesty rule (owner's standing principle): a report
 * must never blame a link on a guess. When the evidence is ambiguous
 * the classifier prefers the USER-side classes (network_timeout /
 * no_connectivity / other) over the link-side ones (host_dead, http_*).
 */
object FeedbackSupport {

    // ---- failClass values (the server contract's enum) ----
    const val HTTP_403 = "http_403"
    const val HTTP_404 = "http_404"
    const val HTTP_410 = "http_410"
    const val HTTP_5XX = "http_5xx"
    const val HOST_DEAD = "host_dead"
    const val NETWORK_TIMEOUT = "network_timeout"
    const val NO_CONNECTIVITY = "no_connectivity"
    const val CANCELLED = "cancelled"
    const val DECODE_LOCAL = "decode_local"
    const val OTHER = "other"

    /** Player-error families, mapped from PlaybackException codes at
     *  the seam so this file never imports Media3. */
    enum class ErrorFamily {
        BAD_HTTP_STATUS, FILE_NOT_FOUND,
        NETWORK_CONNECTION_FAILED, NETWORK_TIMEOUT,
        DECODER, AUDIO_TRACK, PARSING,
        OTHER
    }

    /** Root-cause kinds found in the error's cause chain at the seam. */
    enum class CauseKind { TIMEOUT, DNS, CONNECT, SSL }

    /** The seam's extraction from a player error, before the tracker
     *  adds its own connectivity evidence. */
    data class RawError(
        val family: ErrorFamily,
        val httpStatus: Int?,
        val causeKinds: Set<CauseKind>
    )

    /** Everything the classifier needs, evidence included. */
    data class ErrorFacts(
        val family: ErrorFamily,
        val httpStatus: Int?,
        val causeKinds: Set<CauseKind>,
        /**
         * True when the device demonstrably has connectivity: some
         * host answered this session (another attempt played, a meta
         * fetch landed, or THIS attempt's own host already served
         * bytes). Only with this evidence may a connect failure be
         * blamed on the host (host_dead); without it the honest class
         * is no_connectivity.
         */
        val connectivityProven: Boolean
    )

    fun classify(facts: ErrorFacts): String = when (facts.family) {
        ErrorFamily.BAD_HTTP_STATUS -> when {
            facts.httpStatus == 403 -> HTTP_403
            facts.httpStatus == 404 -> HTTP_404
            facts.httpStatus == 410 -> HTTP_410
            facts.httpStatus != null && facts.httpStatus in 500..599 -> HTTP_5XX
            // A bad status we cannot name exactly is not evidence
            // against the link in any specific way.
            else -> OTHER
        }
        ErrorFamily.FILE_NOT_FOUND -> HTTP_404
        ErrorFamily.DECODER, ErrorFamily.AUDIO_TRACK, ErrorFamily.PARSING -> DECODE_LOCAL
        ErrorFamily.NETWORK_TIMEOUT -> NETWORK_TIMEOUT
        ErrorFamily.NETWORK_CONNECTION_FAILED -> when {
            CauseKind.TIMEOUT in facts.causeKinds -> NETWORK_TIMEOUT
            CauseKind.DNS in facts.causeKinds || CauseKind.CONNECT in facts.causeKinds ->
                if (facts.connectivityProven) HOST_DEAD else NO_CONNECTIVITY
            // SSL and unclassifiable IO failures carry no verdict
            // about the host; proven connectivity only removes the
            // "device is offline" reading.
            facts.connectivityProven -> OTHER
            else -> NO_CONNECTIVITY
        }
        ErrorFamily.OTHER -> when {
            CauseKind.TIMEOUT in facts.causeKinds -> NETWORK_TIMEOUT
            else -> OTHER
        }
    }

    /** Identity of one play attempt: the title, the source that
     *  served the stream, and the stream URL as played. */
    data class AttemptIdentity(
        val titleId: String,
        val source: String,
        val url: String
    )

    /** One outcome record for one attempt. */
    data class Outcome(
        val identity: AttemptIdentity,
        val played: Boolean,
        /** Null for a played outcome. */
        val failClass: String?,
        /** Whole seconds actually played; present when > 0. */
        val playedSecs: Int?
    )

    /**
     * Per-attempt outcome state machine. One instance lives for a
     * whole player-screen session; [beginAttempt] fences attempts.
     *
     * Volume discipline: each attempt emits AT MOST one "played" and
     * AT MOST one "failed" outcome, ever — the played record when
     * playback is proven, the failed record when the attempt dies.
     * (A stream that played 10 s and dies at 40 s therefore produces
     * exactly two records across its life: played, then failed with
     * playedSecs — the death is real data the server weighs, per the
     * contract's mid-playback-death rule. Repeated error callbacks,
     * rebuffers, and poll ticks can never multiply reports.)
     *
     * Outcomes leave through [sink]; a null sink (the first frames of
     * composition, before the screen wires it) drops them — feedback
     * must never block or backpressure playback.
     */
    class Tracker(
        private val playedThresholdMs: Long = 10_000,
        private val midPlaybackDeathSecs: Int = 30,
        private val shortContentPlayedSecs: Int = 3,
        private val maxTickDeltaMs: Long = 2_000
    ) {
        var sink: ((Outcome) -> Unit)? = null

        private inner class Attempt(val identity: AttemptIdentity) {
            var playedMs: Long = 0
            var sustainedMs: Long = 0
            var lastTickMs: Long? = null
            var playedSent = false
            var failedSent = false
            var endedClean = false
            val playedSecs: Int get() = (playedMs / 1000).toInt()
        }

        private var current: Attempt? = null
        private var sessionAnyPlaying = false
        private var networkProvenExternally = false
        private var stallFailoverMarked = false

        /** A non-playback network success this session (e.g. a meta
         *  fetch landed): evidence the device has connectivity. */
        fun markNetworkProven() {
            networkProvenExternally = true
        }

        /** The stall watchdog is about to fail over away from the
         *  current attempt: its end, when it comes, is a stall death
         *  (network_timeout), not a user cancellation. One-shot —
         *  consumed by the next attempt boundary. */
        fun markStallFailover() {
            stallFailoverMarked = true
        }

        /**
         * Starts a new attempt, settling the previous one first.
         * [identity] null = the new on-screen content is not
         * trackable (Live, trailer): the previous attempt still
         * settles, and nothing is tracked until the next non-null
         * identity.
         */
        fun beginAttempt(identity: AttemptIdentity?) {
            val stall = stallFailoverMarked
            stallFailoverMarked = false
            settleCurrent(stalled = stall)
            current = identity?.let { Attempt(it) }
        }

        /** The player screen is going away: settle the live attempt. */
        fun onScreenExit() {
            settleCurrent(stalled = false)
            current = null
        }

        /**
         * The poll loop's heartbeat (the player screen polls playing
         * state every 500–1000 ms). Accumulates REAL playing time
         * only — paused and buffering ticks add nothing — and emits
         * the "played" outcome the first time playing is sustained
         * for [playedThresholdMs] continuously.
         */
        fun onTick(isPlaying: Boolean, ended: Boolean, nowMs: Long) {
            val attempt = current ?: return
            if (ended) {
                onEnded(attempt)
                return
            }
            val last = attempt.lastTickMs
            attempt.lastTickMs = nowMs
            if (!isPlaying) {
                attempt.sustainedMs = 0
                return
            }
            sessionAnyPlaying = true
            val delta = if (last == null) 0L else (nowMs - last).coerceIn(0L, maxTickDeltaMs)
            attempt.playedMs += delta
            attempt.sustainedMs += delta
            if (!attempt.playedSent && attempt.sustainedMs >= playedThresholdMs) {
                attempt.playedSent = true
                emit(Outcome(attempt.identity, played = true, failClass = null, playedSecs = attempt.playedSecs))
            }
        }

        /** The attempt reached STATE_ENDED: it completed. A short
         *  item that genuinely played out still earns its "played"
         *  record even under the sustained threshold; an instant-end
         *  (a corpse host faking END) earns nothing. */
        private fun onEnded(attempt: Attempt) {
            if (attempt.endedClean) return
            attempt.endedClean = true
            if (!attempt.playedSent && !attempt.failedSent &&
                attempt.playedSecs >= shortContentPlayedSecs
            ) {
                attempt.playedSent = true
                emit(Outcome(attempt.identity, played = true, failClass = null, playedSecs = attempt.playedSecs))
            }
        }

        /**
         * A play attempt died with a player error (called at the
         * player's death points only — failover-triggering errors and
         * terminal errors; self-healed and end-of-episode errors
         * never reach here). Emits the single "failed" outcome for
         * the attempt, classified with the tracker's own connectivity
         * evidence.
         */
        fun onAttemptError(raw: RawError) {
            val attempt = current ?: return
            if (attempt.failedSent || attempt.endedClean) return
            attempt.failedSent = true
            val proven = networkProvenExternally || sessionAnyPlaying || attempt.playedMs > 0
            val failClass = classify(
                ErrorFacts(raw.family, raw.httpStatus, raw.causeKinds, connectivityProven = proven)
            )
            emit(
                Outcome(
                    attempt.identity,
                    played = false,
                    failClass = failClass,
                    playedSecs = attempt.playedSecs.takeIf { it > 0 }
                )
            )
        }

        /**
         * Settles the live attempt at a boundary (replaced or screen
         * exit). An attempt that already reported keeps its records
         * and gains nothing. An attempt that never played and never
         * errored was abandoned: [stalled] (watchdog failover) makes
         * it a network_timeout death; anything else is the user
         * backing out — cancelled. A played attempt abandoned quietly
         * (source switch, episode skip, exit) is NOT a failure — its
         * played record already told the story — unless a stall
         * failover ended it after real playback (≥ midPlaybackDeathSecs),
         * which is a genuine mid-playback death.
         */
        private fun settleCurrent(stalled: Boolean) {
            val attempt = current ?: return
            if (attempt.failedSent || attempt.endedClean) return
            if (attempt.playedSent) {
                if (stalled && attempt.playedSecs >= midPlaybackDeathSecs) {
                    attempt.failedSent = true
                    emit(
                        Outcome(
                            attempt.identity,
                            played = false,
                            failClass = NETWORK_TIMEOUT,
                            playedSecs = attempt.playedSecs
                        )
                    )
                }
                return
            }
            attempt.failedSent = true
            emit(
                Outcome(
                    attempt.identity,
                    played = false,
                    failClass = if (stalled) NETWORK_TIMEOUT else CANCELLED,
                    playedSecs = attempt.playedSecs.takeIf { it > 0 }
                )
            )
        }

        private fun emit(outcome: Outcome) {
            sink?.invoke(outcome)
        }
    }

    // ---- Token: random per-install id, rotating daily ----

    data class TokenDecision(
        val token: String,
        val epochDay: Long,
        /** True when the caller must persist (token, epochDay). */
        val changed: Boolean
    )

    /**
     * The token for [nowMs]: the stored one while it is still
     * today's; a fresh random one (from [newToken]) once the UTC day
     * rolls over, or when none is stored. The token is the ONLY
     * identifier the reporter sends — random, per-install, daily —
     * never an account, device, or hardware id.
     */
    fun tokenFor(
        storedToken: String?,
        storedEpochDay: Long,
        nowMs: Long,
        newToken: () -> String
    ): TokenDecision {
        val today = nowMs / 86_400_000L
        return if (!storedToken.isNullOrBlank() && storedEpochDay == today) {
            TokenDecision(storedToken, today, changed = false)
        } else {
            TokenDecision(newToken(), today, changed = true)
        }
    }

    // ---- Payload ----

    /** The exact wire body for one outcome (contract at the top). */
    fun payloadJson(token: String, outcome: Outcome): String = buildJsonObject {
        put("v", 1)
        put("token", token)
        put("titleId", outcome.identity.titleId)
        put("source", outcome.identity.source)
        put("url", outcome.identity.url)
        put("outcome", if (outcome.played) "played" else "failed")
        if (!outcome.played) put("failClass", outcome.failClass ?: OTHER)
        outcome.playedSecs?.let { put("playedSecs", it) }
    }.toString()
}
