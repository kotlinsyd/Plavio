package com.pulsestream.app.media

import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.mkv.MatroskaExtractor
import androidx.media3.extractor.text.DefaultSubtitleParserFactory
import com.pulsestream.app.media.mkv.TailSeekMatroskaExtractor

/**
 * v0.14.19: the stock [DefaultExtractorsFactory] set with ONE swap —
 * the Matroska extractor is Plavio's tail-cues fork
 * ([TailSeekMatroskaExtractor]), which recovers the Cues index from
 * the file tail for muxes whose head SeekHead doesn't reference it
 * (stock Media3 declares those files unseekable, and every seek is
 * then refused). Every other extractor is the stock instance,
 * untouched. The fork is constructed exactly as the stock factory
 * constructs MatroskaExtractor under its defaults
 * (DefaultSubtitleParserFactory, flags 0).
 */
class PlavioExtractorsFactory : ExtractorsFactory {

    override fun createExtractors(): Array<Extractor> {
        val defaults = DefaultExtractorsFactory().createExtractors()
        return Array(defaults.size) { i ->
            if (defaults[i] is MatroskaExtractor) {
                TailSeekMatroskaExtractor(DefaultSubtitleParserFactory(), 0)
            } else {
                defaults[i]
            }
        }
    }
}
