package com.pulsestream.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Appearance extras (v0.14.39, owner's A–H list 2026-11-02), provided
 * once at the app root from SettingsStore and read by the shared
 * components they govern. Every default reproduces the pre-.39
 * shipped behaviour, so the app looks identical until the user
 * changes an option in Settings → Appearance.
 *
 * Text size (item C) is NOT here — it rides LocalDensity's fontScale
 * at the root instead, so every sp in the app scales uniformly.
 */

/** Poster size scale (item B): 0.85 Small / 1 Medium / 1.18 Large. */
val LocalPosterScale = staticCompositionLocalOf { 1f }

/** Glass-card corner radius (item E): 28.dp Rounded / 8.dp Sharp. */
val LocalCardCorner = staticCompositionLocalOf { 28.dp }

/** Poster-card corner radius (item E): 16.dp Rounded / 4.dp Sharp. */
val LocalPosterCorner = staticCompositionLocalOf { 16.dp }

/** Row/list padding scale (item D): 0.78 Compact / 1 Comfortable. */
val LocalSpacingScale = staticCompositionLocalOf { 1f }

/** Reduced animations (item G): true damps crossfades/motion. */
val LocalReduceMotion = staticCompositionLocalOf { false }

/** Card corner pair for a SettingsStore.cardCorners value. */
fun cardCornersFor(setting: String): Pair<Dp, Dp> =
    if (setting == "Sharp") 8.dp to 4.dp else 28.dp to 16.dp
