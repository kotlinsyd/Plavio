package com.pulsestream.app.data.simkl

import android.os.SystemClock
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.scrobble.ScrobbleProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/**
 * Owns the Simkl link: token storage, authorization-code + PKCE
 * login (v0.14.11, mirroring TraktManager), and scrobble calls.
 * All network work happens on the caller's thread (call from IO).
 * Failures are swallowed — sync must never break playback.
 *
 * Implements [ScrobbleProvider] so the player's unified [com.pulsestream.app.data.scrobble.ScrobbleManager]
 * can fan scrobble events out to Simkl alongside other backends.
 */
class SimklManager(private val settings: SettingsStore) : ScrobbleProvider {

    override val name: String = "Simkl"
    override val isEnabled: Boolean get() = isLoggedIn

    private val api = SimklApi()
    private val scrobbleMutex = Mutex()
    private val refreshMutex = Mutex()
    private var lastScrobbleAt = 0L

    val isLoggedIn: Boolean get() = settings.simklToken != null
    val username: String? get() = settings.simklUsername

    // ---- Auth (OAuth2 authorization code + PKCE — mirrors Trakt) ----

    fun newPkce(): SimklApi.Pkce = api.newPkce()

    fun authorizeUrl(pkce: SimklApi.Pkce): String = api.authorizeUrl(pkce)

    /** Outcome of a code exchange, kept honest for the Link dialog. */
    sealed interface LoginOutcome {
        data object Ok : LoginOutcome
        /** Simkl answered with an HTTP error; [message] is Simkl's own text. */
        data class SimklError(val message: String) : LoginOutcome
        /** No answer at all — a genuine connection failure. */
        data object NetworkError : LoginOutcome
    }

    /** Exchanges the user-pasted code for tokens and stores the login. */
    suspend fun loginWithCode(code: String, verifier: String): LoginOutcome {
        val tokens = try {
            api.exchangeCode(code, verifier)
        } catch (e: SimklApi.AuthException) {
            return LoginOutcome.SimklError(e.message ?: "Simkl refused the code.")
        } catch (_: Exception) {
            return LoginOutcome.NetworkError
        }
        saveLogin(tokens, fetchUsername(tokens.accessToken))
        return LoginOutcome.Ok
    }

    /** What the user pasted into the Link dialog: a bare code, or the callback URL. */
    sealed interface PastedCode {
        data class Code(val value: String) : PastedCode
        /** The pasted callback URL's state does not match this linking attempt. */
        data object StateMismatch : PastedCode
        data object Empty : PastedCode
    }

    /**
     * Reads the authorization code out of the dialog input. A bare
     * code passes through as-is (the Trakt pattern); a pasted
     * callback URL is parsed for its `code`, and its `state` — when
     * the URL carries one — must match [expectedState] from the
     * authorize request that started this attempt.
     */
    fun codeFromPaste(pasted: String, expectedState: String): PastedCode {
        val input = pasted.trim()
        if (input.isEmpty()) return PastedCode.Empty
        if (!input.contains("code=")) return PastedCode.Code(input)
        val query = input.substringAfter('?', input)
        val params = query.split('&').mapNotNull { part ->
            val kv = part.split('=', limit = 2)
            if (kv.size == 2) {
                runCatching { java.net.URLDecoder.decode(kv[0], "UTF-8") }.getOrDefault(kv[0]) to
                    runCatching { java.net.URLDecoder.decode(kv[1], "UTF-8") }.getOrDefault(kv[1])
            } else null
        }.toMap()
        val state = params["state"]
        if (state != null && state != expectedState) return PastedCode.StateMismatch
        val code = params["code"]?.takeIf { it.isNotBlank() } ?: return PastedCode.Empty
        return PastedCode.Code(code)
    }

    fun saveLogin(tokens: SimklApi.Tokens, username: String?) {
        settings.simklToken = tokens.accessToken
        settings.simklRefreshToken = tokens.refreshToken
        settings.simklTokenIssuedAt = System.currentTimeMillis()
        settings.simklUsername = username
    }

    fun logout() {
        settings.simklToken = null
        settings.simklRefreshToken = null
        settings.simklTokenIssuedAt = 0L
        settings.simklUsername = null
    }

    // ---- Token lifetime (v0.14.13) ----
    // Simkl's developer page: access tokens last 7 days, refresh
    // tokens 180 days. Two safety nets keep the link alive without
    // bothering the user: a PROACTIVE refresh once the stored token
    // is over 6 days old, and a REACTIVE one — a caller whose write
    // was refused with 401 (user_token_failed) asks for one refresh
    // via [refreshStoredToken] and retries once before the link is
    // cleared (see TrackingWrites). When the grant carried no
    // refresh token, both nets quietly do nothing and the old
    // behaviour (clear + "expired — reconnect") stands.

    /**
     * A usable access token: the stored one, proactively refreshed
     * first when it is older than 6 days and a refresh token exists.
     * Null when not linked. A failed proactive refresh falls back to
     * the stored token — the reactive 401 path is the judge.
     */
    suspend fun validAccessToken(): String? {
        val token = settings.simklToken?.takeIf { it.isNotBlank() } ?: return null
        val issuedAt = settings.simklTokenIssuedAt
        val stale = issuedAt > 0L &&
            System.currentTimeMillis() - issuedAt > STALE_AFTER_MS
        if (!stale) return token
        return refreshStoredToken() ?: token
    }

    /**
     * ONE refresh attempt against the stored refresh token. On
     * success the new pair is stored and the new access token is
     * returned; null when there is no refresh token or Simkl refused.
     */
    suspend fun refreshStoredToken(): String? = refreshMutex.withLock {
        // Re-read inside the lock; another caller may have refreshed.
        val issuedAt = settings.simklTokenIssuedAt
        if (issuedAt > 0L && System.currentTimeMillis() - issuedAt < FRESH_ENOUGH_MS) {
            return@withLock settings.simklToken?.takeIf { it.isNotBlank() }
        }
        val refresh = settings.simklRefreshToken?.takeIf { it.isNotBlank() }
            ?: return@withLock null
        val tokens = try {
            api.refreshAccessToken(refresh)
        } catch (_: Exception) {
            return@withLock null
        }
        settings.simklToken = tokens.accessToken
        // Simkl may rotate the refresh token; keep the old one when
        // the reply carries none.
        if (!tokens.refreshToken.isNullOrBlank()) {
            settings.simklRefreshToken = tokens.refreshToken
        }
        settings.simklTokenIssuedAt = System.currentTimeMillis()
        tokens.accessToken
    }

    suspend fun fetchUsername(token: String): String? =
        try { api.getUsername(token) } catch (_: Exception) { null }

    // ---- Scrobble ----

    override suspend fun scrobbleStart(req: PlaybackRequest, posMs: Long, durMs: Long) =
        throttled("start", req, posMs, durMs)

    override suspend fun scrobblePause(req: PlaybackRequest, posMs: Long, durMs: Long) =
        throttled("pause", req, posMs, durMs)

    override suspend fun scrobbleStop(req: PlaybackRequest, posMs: Long, durMs: Long) =
        throttled("stop", req, posMs, durMs)

    /**
     * Simkl enforces one scrobble per user per ~20s (400 RATE_LIMIT on collision).
     * Non-critical events inside the window are dropped; "stop" waits it out so
     * the watch is never lost.
     */
    private suspend fun throttled(action: String, req: PlaybackRequest, posMs: Long, durMs: Long) {
        val token = validAccessToken() ?: return
        if (durMs <= 0) return
        scrobbleMutex.withLock {
            val waitMs = 21_000L - (SystemClock.elapsedRealtime() - lastScrobbleAt)
            if (waitMs > 0) {
                if (action != "stop") return
                delay(waitMs)
            }
            try {
                if (api.scrobble(token, action, scrobbleBody(req, posMs, durMs))) {
                    lastScrobbleAt = SystemClock.elapsedRealtime()
                }
            } catch (_: Exception) {
                // Telemetry must never crash playback.
            }
        }
    }

    private fun scrobbleBody(req: PlaybackRequest, posMs: Long, durMs: Long): JSONObject {
        val progress = (posMs.toDouble() / durMs.toDouble() * 100.0).coerceIn(0.0, 100.0)
        val ids = JSONObject().apply {
            req.imdbId?.takeIf { it.isNotBlank() }?.let { put("imdb", it) }
        }
        return JSONObject().apply {
            put("progress", progress)
            if (req.isMovie) {
                put("movie", JSONObject().put("title", req.title).put("ids", ids))
            } else {
                put("show", JSONObject().put("title", req.seriesName ?: req.title).put("ids", ids))
                put("episode", JSONObject().put("season", req.season).put("number", req.episode))
            }
        }
    }

    private companion object {
        /** Refresh proactively once the access token is this old (it dies at 7 days). */
        const val STALE_AFTER_MS = 6L * 24 * 60 * 60 * 1000

        /** A token issued this recently counts as just-refreshed inside the lock. */
        const val FRESH_ENOUGH_MS = 60_000L
    }
}
