package com.pulsestream.app.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.CustomListsRepository
import com.pulsestream.app.data.MdbListApi
import com.pulsestream.app.data.PlavioStatuses
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.TrackingWrites
import com.pulsestream.app.data.WatchedMarks
import com.pulsestream.app.data.db.CustomList
import com.pulsestream.app.data.db.FavoriteItem
import com.pulsestream.app.data.db.TitleStatusItem
import com.pulsestream.app.data.db.WatchlistItem
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Shared tracking state + actions for one title (v0.14.6, Phase 1):
 * the add-to-list sheet and the detail page's tracking section both
 * drive Trakt / Simkl / MDBList through here, so behaviour — and
 * error surfacing — is identical everywhere. Every write's outcome
 * lands in [lastOutcome] and is toasted by the caller.
 */
class TrackingUiState(
    val writes: TrackingWrites,
    val type: String,
    val metaId: String,
    val title: String,
    val year: Int?
) {
    var simklStatus by mutableStateOf<String?>(null)
    var traktInWatchlist by mutableStateOf<Boolean?>(null)
    var traktLists by mutableStateOf<List<TraktApi.TraktListInfo>>(emptyList())
    var traktContaining by mutableStateOf<Set<Int>>(emptySet())
    var mdbLists by mutableStateOf<List<MdbListApi.MdbListInfo>>(emptyList())
    var mdbContaining by mutableStateOf<Set<String>>(emptySet())
    var busy by mutableStateOf(false)
    var loaded by mutableStateOf(false)
    var lastOutcome by mutableStateOf<TrackingWrites.Outcome?>(null)

    suspend fun load() {
        if (writes.simklLinked) {
            simklStatus = writes.simklStatusOf(type, metaId)
        }
        if (writes.traktLinked) {
            traktInWatchlist = writes.traktInWatchlist(type, metaId)
            val lists = writes.traktLists()
            if (lists != null) {
                traktLists = lists
                traktContaining = writes.traktListsContaining(type, metaId, lists) ?: emptySet()
            }
        }
        val mdb = writes.mdbApi
        if (mdb != null) {
            val lists = runCatching { mdb.lists() }.getOrNull()
            if (lists != null) {
                mdbLists = lists
                val containing = mutableSetOf<String>()
                for (list in lists.take(10)) {
                    val items = runCatching { mdb.listItems(list.id) }.getOrNull()
                    if (items != null && items.any { it.type == type && it.imdbId == metaId }) {
                        containing += list.id
                    }
                }
                mdbContaining = containing
            }
        }
        loaded = true
    }
}

@Composable
fun rememberTrackingUiState(
    repository: StreamRepository,
    type: String,
    metaId: String,
    title: String,
    year: Int?
): TrackingUiState {
    val state = remember(metaId, type) {
        TrackingUiState(repository.trackingWrites(), type, metaId, title, year)
    }
    LaunchedEffect(state) { state.load() }
    return state
}

/**
 * Bottom sheet for a title (v0.14.6): the service sections from the
 * approved samples, in order — Simkl status chips, Trakt watchlist
 * + personal lists, MDBList lists with New List creation, then
 * PLAVIO (v0.14.10): Plavio's own five status chips, Watched and
 * Favorite toggles, and the local custom lists as "Your lists";
 * Remove from library sits at the bottom. Service sections appear
 * only for linked services; every write reports back visibly.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddToListSheet(
    listsRepository: CustomListsRepository,
    addonId: String,
    type: String,
    metaId: String,
    name: String,
    poster: String?,
    onDismiss: () -> Unit,
    repository: StreamRepository? = null,
    year: Int? = null,
    rating: String? = null
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val palette = LocalPalette.current
    val lists by listsRepository.lists.collectAsState(initial = emptyList())
    // Membership is matched on (type, metaId), NOT the full itemKey
    // (v0.14.11): the key's addonId segment depends on which addon
    // served the title when it was added, and the Library opens this
    // sheet with no addon at all — key-matching there always read
    // "not in any list", so the rows could only ever add, never
    // remove, and removal from Library was impossible.
    val containing by listsRepository.observeListsContainingMeta(type, metaId)
        .collectAsState(initial = emptyList())
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    val tracking = repository?.let {
        rememberTrackingUiState(it, type, metaId, name, year)
    }
    val watchedKeys by WatchedMarks.keys.collectAsState()
    val isWatched = WatchedMarks.movieKey(metaId) in watchedKeys
    val watchlistItems by (repository?.watchlist?.collectAsState(initial = emptyList<WatchlistItem>())
        ?: remember { mutableStateOf<List<WatchlistItem>>(emptyList()) })
    val libraryItem = watchlistItems.firstOrNull {
        it.type == type && it.metaId == metaId
    }
    // Plavio section state (v0.14.10): favorites + explicit statuses
    // from the local stores; the resolved status folds in watchlist
    // membership as Next to Watch (see PlavioStatuses).
    val favoriteItems by (repository?.favorites?.collectAsState(initial = emptyList<FavoriteItem>())
        ?: remember { mutableStateOf<List<FavoriteItem>>(emptyList()) })
    val favoriteItem = favoriteItems.firstOrNull {
        it.type == type && it.metaId == metaId
    }
    val statusItems by (repository?.titleStatuses?.collectAsState(initial = emptyList<TitleStatusItem>())
        ?: remember { mutableStateOf<List<TitleStatusItem>>(emptyList()) })

    fun toast(outcome: TrackingWrites.Outcome) {
        Toast.makeText(context, outcome.message, Toast.LENGTH_LONG).show()
    }

    fun runWrite(block: suspend () -> TrackingWrites.Outcome) {
        if (tracking == null || tracking.busy) return
        tracking.busy = true
        scope.launch {
            val outcome = runCatching { block() }
                .getOrElse { TrackingWrites.Outcome(false, "Something went wrong. Try again.") }
            tracking.busy = false
            tracking.lastOutcome = outcome
            toast(outcome)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, bottom = 32.dp)
        ) {
            // ---- Header (samples: poster thumb + title + meta line) ----
            item(key = "header") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SafePosterImage(
                        model = poster,
                        contentDescription = null,
                        modifier = Modifier
                            .size(width = 46.dp, height = 66.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary,
                            maxLines = 2
                        )
                        val metaLine = listOfNotNull(
                            year?.toString(),
                            if (type == "series") "Series" else "Movie",
                            rating?.let { "★ $it" }
                        ).joinToString(" · ")
                        if (metaLine.isNotBlank()) {
                            Text(
                                text = metaLine,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---- Share (v0.14.13, item 7): the title's deep link
            // through the system share sheet. The link opens this
            // title's detail page in Plavio
            // (plavio://title/<type>/<id>; the same route answers
            // https://plavio.site/t/<type>/<id>). ----
            item(key = "share") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.07f))
                        .clickable {
                            val link = "plavio://title/$type/$metaId"
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                // Intent.setType is fluent (returns Intent),
                                // so no synthetic property assignment.
                                setType("text/plain")
                                putExtra(android.content.Intent.EXTRA_SUBJECT, name)
                                putExtra(android.content.Intent.EXTRA_TEXT, "$name\n$link")
                            }
                            context.startActivity(
                                android.content.Intent.createChooser(send, "Share")
                            )
                            onDismiss()
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Icon(
                        Icons.Filled.Share,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "Share",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---- SIMKL: five status chips, single choice ----
            if (tracking != null && tracking.writes.simklLinked) {
                item(key = "simkl") {
                    TrackingSectionLabel("SIMKL")
                    FlowRow(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        SimklApi.Statuses.ALL.forEach { status ->
                            val selected = tracking.simklStatus == status
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selected) palette.accent
                                        else Color.White.copy(alpha = 0.07f)
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) palette.accent else Color.White.copy(alpha = 0.14f),
                                        RoundedCornerShape(50)
                                    )
                                    .clickable(enabled = !tracking.busy) {
                                        if (!selected) {
                                            runWrite {
                                                val outcome = tracking.writes.simklSetStatus(
                                                    type, metaId, name, status, year ?: 0
                                                )
                                                if (outcome.ok) tracking.simklStatus = status
                                                outcome
                                            }
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = SimklApi.Statuses.label(status),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) palette.accentText else TextPrimary
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
            }

            // ---- TRAKT: watchlist + personal lists ----
            if (tracking != null && tracking.writes.traktLinked) {
                item(key = "trakt") {
                    TrackingSectionLabel("TRAKT")
                    ServiceToggleRow(
                        title = "Watchlist",
                        checked = tracking.traktInWatchlist == true,
                        enabled = !tracking.busy && tracking.traktInWatchlist != null,
                        onToggle = { add ->
                            runWrite {
                                val outcome = tracking.writes.traktToggleWatchlist(type, metaId, name, add)
                                if (outcome.ok) tracking.traktInWatchlist = add
                                outcome
                            }
                        }
                    )
                    tracking.traktLists.forEach { list ->
                        ServiceToggleRow(
                            title = list.name,
                            checked = list.id in tracking.traktContaining,
                            enabled = !tracking.busy,
                            onToggle = { add ->
                                runWrite {
                                    val outcome = tracking.writes.traktToggleList(
                                        list, type, metaId, name, add
                                    )
                                    if (outcome.ok) {
                                        tracking.traktContaining =
                                            if (add) tracking.traktContaining + list.id
                                            else tracking.traktContaining - list.id
                                    }
                                    outcome
                                }
                            }
                        )
                    }
                    Spacer(Modifier.height(18.dp))
                }
            }

            // ---- MDBLIST: own lists + New List creation ----
            if (tracking != null && tracking.writes.mdbLinked) {
                item(key = "mdblist") {
                    TrackingSectionLabel("MDBLIST · YOUR OWN LISTS, SYNCED TO YOUR ACCOUNT")
                    tracking.mdbLists.forEach { list ->
                        ServiceToggleRow(
                            title = list.name,
                            checked = list.id in tracking.mdbContaining,
                            enabled = !tracking.busy,
                            onToggle = { add ->
                                runWrite {
                                    val mdb = tracking.writes.mdbApi
                                        ?: return@runWrite TrackingWrites.Outcome(false, "MDBList isn't linked.")
                                    val item = MdbListApi.MdbListItem(type, metaId, name)
                                    val result = if (add) {
                                        mdb.addItems(list.id, list.name, listOf(item))
                                    } else {
                                        mdb.removeItems(list.id, list.name, listOf(item))
                                    }
                                    if (result.ok) {
                                        tracking.mdbContaining =
                                            if (add) tracking.mdbContaining + list.id
                                            else tracking.mdbContaining - list.id
                                    }
                                    TrackingWrites.Outcome(result.ok, result.message)
                                }
                            }
                        )
                    }
                    var creatingMdb by remember { mutableStateOf(false) }
                    var mdbName by remember { mutableStateOf("") }
                    if (creatingMdb) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 6.dp)
                        ) {
                            OutlinedTextField(
                                value = mdbName,
                                onValueChange = { if (it.length <= 60) mdbName = it },
                                placeholder = { Text("List name", color = TextSecondary) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            TextButton(
                                onClick = {
                                    val listName = mdbName.trim()
                                    if (listName.isEmpty() || tracking.busy) return@TextButton
                                    tracking.busy = true
                                    scope.launch {
                                        val mdb = tracking.writes.mdbApi
                                        val outcome = if (mdb == null) {
                                            TrackingWrites.Outcome(false, "MDBList isn't linked.")
                                        } else {
                                            val created = runCatching { mdb.createList(listName) }
                                                .getOrElse {
                                                    MdbListApi.WriteResult(false, it.message ?: "Couldn't create the list.")
                                                }
                                            if (created.ok) {
                                                // Refetch so the new list appears,
                                                // then file this title into it.
                                                val fresh = runCatching { mdb.lists() }.getOrNull()
                                                if (fresh != null) {
                                                    tracking.mdbLists = fresh
                                                    val newList = fresh.firstOrNull {
                                                        it.name == listName && it.id !in tracking.mdbContaining
                                                    } ?: fresh.lastOrNull()
                                                    if (newList != null) {
                                                        val added = mdb.addItems(
                                                            newList.id, newList.name,
                                                            listOf(MdbListApi.MdbListItem(type, metaId, name))
                                                        )
                                                        if (added.ok) {
                                                            tracking.mdbContaining =
                                                                tracking.mdbContaining + newList.id
                                                        }
                                                    }
                                                }
                                            }
                                            TrackingWrites.Outcome(created.ok, created.message)
                                        }
                                        tracking.busy = false
                                        tracking.lastOutcome = outcome
                                        toast(outcome)
                                        if (outcome.ok) {
                                            creatingMdb = false
                                            mdbName = ""
                                        }
                                    }
                                },
                                enabled = mdbName.trim().isNotEmpty()
                            ) { Text("Create") }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.5.dp, palette.accent, RoundedCornerShape(14.dp))
                                .clickable(enabled = !tracking.busy) { creatingMdb = true }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+ New List",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = palette.accent
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
            }

            // ---- PLAVIO: own statuses + Watched/Favorite + lists ----
            // (v0.14.10, owner's "add options like Simkl has": five
            // status chips mirroring Simkl's, single-select, tapping
            // the active chip clears it; then the Watched and
            // Favorite toggles; the local custom lists live under
            // this section as "Your lists".)
            if (repository != null && tracking != null) {
                item(key = "plavio") {
                    TrackingSectionLabel("PLAVIO")
                    val explicitStatus = statusItems.firstOrNull {
                        it.type == type && it.metaId == metaId
                    }?.status
                    val resolvedStatus = PlavioStatuses.resolved(explicitStatus, libraryItem != null)
                    FlowRow(
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        PlavioStatuses.ALL.forEach { status ->
                            val selected = resolvedStatus == status
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selected) palette.accent
                                        else Color.White.copy(alpha = 0.07f)
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) palette.accent else Color.White.copy(alpha = 0.14f),
                                        RoundedCornerShape(50)
                                    )
                                    .clickable {
                                        scope.launch {
                                            repository.setPlavioStatus(
                                                addonId, type, metaId, name, poster,
                                                if (selected) null else status
                                            )
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = PlavioStatuses.label(status),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) palette.accentText else TextPrimary
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    ServiceToggleRow(
                        title = "Watched",
                        checked = isWatched,
                        enabled = !tracking.busy,
                        onToggle = { target ->
                            tracking.busy = true
                            scope.launch {
                                repository.setLocalWatched(metaId, 0, 0, target)
                                val outcomes = tracking.writes.markWatched(
                                    type, metaId, name, year, emptyList(), target
                                )
                                tracking.busy = false
                                val failed = outcomes.firstOrNull { !it.ok }
                                val message = when {
                                    failed != null -> failed.message
                                    outcomes.isNotEmpty() ->
                                        if (target) "Marked watched here and on your services."
                                        else "Removed the watched mark everywhere."
                                    else ->
                                        if (target) "Marked watched." else "Watched mark removed."
                                }
                                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                    ServiceToggleRow(
                        title = "Favorite",
                        checked = favoriteItem != null,
                        onToggle = {
                            scope.launch {
                                repository.toggleFavorite(addonId, type, metaId, name, poster)
                            }
                        }
                    )
                    Spacer(Modifier.height(18.dp))
                }
            }

            // ---- Your lists: local custom lists (inside the Plavio
            // section when it shows; the old standalone block when
            // the sheet was opened without a repository) ----
            item(key = "local_label") {
                TrackingSectionLabel(if (repository != null) "YOUR LISTS" else "ON THIS DEVICE")
            }
            if (lists.isEmpty() && !creating) {
                item(key = "local_empty") {
                    Text(
                        text = "You don't have any lists yet — create your first one below.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
            items(lists, key = { it.id }) { list ->
                ListToggleRow(
                    list = list,
                    listsRepository = listsRepository,
                    checked = list.id in containing,
                    onToggle = { isNowIn ->
                        scope.launch {
                            if (isNowIn) {
                                listsRepository.addToList(
                                    list.id, addonId, type, metaId, name, poster
                                )
                            } else {
                                listsRepository.removeFromListByMeta(list.id, type, metaId)
                            }
                        }
                    }
                )
            }
            item(key = "local_new") {
                Spacer(Modifier.height(8.dp))
                if (creating) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { if (it.length <= 60) newName = it },
                            placeholder = { Text("List name", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                scope.launch {
                                    val id = listsRepository.createList(newName)
                                    listsRepository.addToList(
                                        id, addonId, type, metaId, name, poster
                                    )
                                    newName = ""
                                    creating = false
                                }
                            },
                            enabled = newName.trim().isNotEmpty()
                        ) { Text("Create") }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { creating = true }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "New list",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = palette.accent
                        )
                    }
                }
            }

            // ---- Remove from library (the old standalone Mark as
            // watched row is gone in v0.14.10 — that action now lives
            // in the Plavio section as the Watched toggle) ----
            if (repository != null && tracking != null) {
                item(key = "actions") {
                    Spacer(Modifier.height(10.dp))
                    if (libraryItem != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch {
                                        repository.toggleWatchlist(
                                            libraryItem.addonId, libraryItem.type,
                                            libraryItem.metaId, libraryItem.name, libraryItem.poster
                                        )
                                    }
                                    onDismiss()
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.FormatListBulleted,
                                contentDescription = null,
                                tint = Color(0xFFF87171),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "Remove from library",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFFF87171)
                            )
                        }
                    }
                }
            }

            // ---- Write failure line (v0.14.9) ----
            // The toast alone truncates long failure text ("(Simkl
            // sai…"), so a failed write's COMPLETE message — HTTP code
            // and the service's own error included — also stays here,
            // under the sections, until the next write replaces it.
            // Shared by Simkl / Trakt / MDBList via lastOutcome.
            if (tracking != null) {
                val outcome = tracking.lastOutcome
                if (outcome != null && !outcome.ok) {
                    item(key = "write_error") {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = outcome.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFF87171),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrackingSectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = TextSecondary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

/** A service list row: name + trailing circle check (approved samples). */
@Composable
fun ServiceToggleRow(
    title: String,
    checked: Boolean,
    enabled: Boolean = true,
    onToggle: (Boolean) -> Unit
) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(14.dp))
            .clickable(enabled = enabled) { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (checked) palette.accent else Color.Transparent)
                .border(
                    1.5.dp,
                    if (checked) palette.accent else Color.White.copy(alpha = 0.45f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Added",
                    tint = palette.accentText,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun ListToggleRow(
    list: CustomList,
    listsRepository: CustomListsRepository,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val palette = LocalPalette.current
    val count by listsRepository.observeItemCount(list.id).collectAsState(initial = 0)
    // Card treatment mirrors ServiceToggleRow (v0.14.11): the state
    // must be obvious at a glance — a filled accent circle with a
    // check means "in this list; tap to remove", a hollow ring
    // means "not in it; tap to add".
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(14.dp))
            .clickable { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.FormatListBulleted,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = list.name,
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary
            )
            Text(
                text = "$count ${if (count == 1) "title" else "titles"}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (checked) palette.accent else Color.Transparent)
                .border(
                    1.5.dp,
                    if (checked) palette.accent else Color.White.copy(alpha = 0.45f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "In list — tap to remove",
                    tint = palette.accentText,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}
