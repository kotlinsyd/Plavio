package com.pulsestream.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.AppConfigSupport
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * The owner's one-shot announcement from the remote app config
 * (AppConfig), shown once per announcement id — the seen-id lives in
 * AppConfig's prefs, so dismissing here is permanent for that id and
 * a later launch never re-shows it. Rendered in the UpdateDialog
 * pattern (same AlertDialog shape, palette and container colour —
 * the locked Onyx theme is untouched); a null announcement (the
 * standing state) renders nothing at all.
 */
@Composable
fun AnnouncementPrompt(
    announcement: AppConfigSupport.Announcement?,
    onDismiss: () -> Unit
) {
    if (announcement != null) {
        AnnouncementDialog(announcement = announcement, onDismiss = onDismiss)
    }
}

/** Dismissible announcement popup; every dismissal path is the same
 *  "seen it" — there is nothing to confirm or install. */
@Composable
fun AnnouncementDialog(
    announcement: AppConfigSupport.Announcement,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                announcement.title,
                color = TextPrimary,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    announcement.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                        .verticalScroll(rememberScrollState())
                )
                Spacer(Modifier.height(8.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Got it", color = LocalPalette.current.accent)
            }
        },
        containerColor = Color(0xFF14141F)
    )
}
