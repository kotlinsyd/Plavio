package com.pulsestream.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import java.net.URI
import java.net.URLEncoder

/**
 * Pure logic for the remote app config (v0.14.28, owner's order
 * 2026-10-31: little server-driven updates without an APK — "give
 * little features update not app update"). The published document
 * lives at https://meta.plavio.site/app-config.json and is read by
 * [AppConfig]; everything testable about it lives here, free of
 * Android types: parsing, per-field validation, door resolution and
 * switch defaults.
 *
 * The prime directive: a config that is absent, unreachable, or
 * malformed changes NOTHING. The compiled-in defaults below reproduce
 * the pre-config behaviour exactly (the same first-party doors the
 * app shipped with), and every published field is independently
 * validated, so one bad field can never poison the others.
 *
 * Door priority, applied by the consumers: config → stored →
 * compiled default. A door field is therefore nullable in
 * [AppConfigData]: null means "the config did not (validly) set
 * this", and the consumer's stored tier (e.g. the installed addon's
 * own baseUrl) or the compiled default decides.
 */
object AppConfigSupport {

    /** Compiled-in doors: exactly the bases the app used before the
     *  config existed, so a silent config is a no-op. */
    const val DEFAULT_PMETA_DOOR = "https://meta.plavio.site"
    const val DEFAULT_PLAVIOHD_DOOR = "https://hd.plavio.site"
    const val DEFAULT_SEARCH_DOOR = "https://meta.plavio.site/search.json"

    /** Switch keys with a wired consumer today. The map stays generic
     *  on purpose — this is the seam future dormant features plug
     *  into: ship the feature compiled-in and off (or on), then flip
     *  it from the server without an APK. */
    const val SWITCH_WARM_TRIGGERS = "warmTriggers"
    const val SWITCH_SEARCH_INDEX = "searchIndex"
    const val SWITCH_FEEDBACK = "feedback"
    const val SWITCH_DEBRID = "debrid"

    /** One owner announcement. Shown once per [id] (see [AppConfig]);
     *  a null announcement in the config renders nothing. */
    data class Announcement(
        val id: String,
        val title: String,
        val body: String
    )

    /**
     * The config as published, after per-field validation. Also the
     * live state [AppConfig] holds: the last successfully parsed
     * document, or [EMPTY] when none has ever landed.
     */
    data class AppConfigData(
        /** Validated config-set doors; null = not (validly) set. */
        val pmetaDoor: String?,
        val plaviohdDoor: String?,
        val searchDoor: String?,
        val announcement: Announcement?,
        /** Oldest versionCode the owner still supports; 0 = no floor. */
        val minVersionCode: Int,
        /** Feature switches; only boolean values survive parsing. */
        val switches: Map<String, Boolean>
    )

    /** The no-config state: reproduces pre-config behaviour exactly. */
    val EMPTY = AppConfigData(
        pmetaDoor = null,
        plaviohdDoor = null,
        searchDoor = null,
        announcement = null,
        minVersionCode = 0,
        switches = emptyMap()
    )

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Parses a published config body, or null when the body is not a
     * JSON object at all (the caller then keeps its last-good state —
     * a garbage response can never clear a working config). Inside a
     * parseable object every field is validated independently: a bad
     * door drops only that door, a bad announcement drops only the
     * announcement. The "version" field is deliberately not gated on:
     * the schema evolves additively and every field stands on its
     * own validation, so a future version must not brick this reader.
     */
    fun parse(body: String): AppConfigData? {
        val root = try {
            json.parseToJsonElement(body).jsonObject
        } catch (_: Exception) {
            return null
        }
        val doors = root["doors"] as? JsonObject
        fun door(key: String): String? =
            (doors?.get(key) as? JsonPrimitive)?.contentOrNull?.let { validDoorOrNull(it) }
        return AppConfigData(
            pmetaDoor = door("pmeta"),
            plaviohdDoor = door("plaviohd"),
            searchDoor = door("search"),
            announcement = parseAnnouncement(root["announcement"]),
            minVersionCode = parseMinVersionCode(root["minVersionCode"]),
            switches = parseSwitches(root["switches"])
        )
    }

    private fun parseAnnouncement(element: kotlinx.serialization.json.JsonElement?): Announcement? {
        val obj = element as? JsonObject ?: return null
        fun field(key: String): String? =
            (obj[key] as? JsonPrimitive)?.contentOrNull?.trim()?.takeIf { it.isNotBlank() }
        val id = field("id") ?: return null
        val title = field("title") ?: return null
        val body = field("body") ?: return null
        return Announcement(id, title, body)
    }

    private fun parseMinVersionCode(element: kotlinx.serialization.json.JsonElement?): Int {
        val prim = element as? JsonPrimitive ?: return 0
        // Only a whole JSON number counts (a string "187" or 187.5 is
        // a publishing mistake, not a floor). isString is checked
        // explicitly: kotlinx's doubleOrNull also parses quoted
        // numeric content.
        if (prim.isString) return 0
        val value = prim.doubleOrNull ?: return 0
        if (value % 1.0 != 0.0) return 0
        return value.toInt().takeIf { it > 0 } ?: 0
    }

    private fun parseSwitches(element: kotlinx.serialization.json.JsonElement?): Map<String, Boolean> {
        val obj = element as? JsonObject ?: return emptyMap()
        return obj.entries.mapNotNull { (key, value) ->
            // A quoted "true" is a string, not a switch (booleanOrNull
            // alone would parse its content).
            (value as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull?.let { key to it }
        }.toMap()
    }

    /**
     * A door is accepted only when it is an https URL on our own
     * first-party hosts: *.plavio.site or the PMeta Vercel host. This
     * is what makes config-priority safe — a published (or tampered)
     * config can re-point the app between our own doors, never at a
     * third-party server. User-info and fragments are rejected (they
     * have no meaning in a base URL and only confuse URL joining).
     * The returned door is normalised: trimmed, no trailing slash.
     */
    fun validDoorOrNull(raw: String?): String? {
        val trimmed = raw?.trim()?.trimEnd('/') ?: return null
        if (trimmed.isEmpty()) return null
        val uri = try {
            URI(trimmed)
        } catch (_: Exception) {
            return null
        }
        if (!uri.scheme.equals("https", ignoreCase = true)) return null
        if (uri.userInfo != null || uri.fragment != null) return null
        val host = uri.host?.lowercase() ?: return null
        val allowed = host == "plavio.site" ||
            host.endsWith(".plavio.site") ||
            host == "plaviometa.vercel.app"
        return if (allowed) trimmed else null
    }

    /** PMeta door with priority applied: config → compiled default.
     *  (The stored tier for PMeta is the installed addon's own row;
     *  addon-driven calls keep following it — the door governs the
     *  first-party calls: preinstall/migration, /related, the keyless
     *  lane's provenance base, the UI install shortcuts.) */
    fun pmetaDoor(data: AppConfigData): String = data.pmetaDoor ?: DEFAULT_PMETA_DOOR

    /** Keyless-search door with priority applied: config → default. */
    fun searchDoor(data: AppConfigData): String = data.searchDoor ?: DEFAULT_SEARCH_DOOR

    /** The PMeta manifest URL under the effective PMeta door. */
    fun pmetaManifestUrl(data: AppConfigData): String = pmetaDoor(data) + "/manifest.json"

    /** Builds a keyless-search URL on [door] (the search door is a
     *  full endpoint, so the query joins with & when one is present). */
    fun searchUrl(door: String, query: String): String =
        door + (if (door.contains('?')) "&q=" else "?q=") + URLEncoder.encode(query, "UTF-8")

    /** A switch value, or [default] when the config never set it. */
    fun switchEnabled(data: AppConfigData, key: String, default: Boolean): Boolean =
        data.switches[key] ?: default
}
