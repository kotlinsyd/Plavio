package com.pulsestream.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Validate-on-save probes (P5, v0.14.22 — owner's requirement
 * 2026-10-31 06:36: "adding key and saving should give any signal of
 * correct or no").
 *
 * Each probe hits the LIGHTEST authenticated endpoint of its service
 * with the entered key and classifies the answer:
 *  - [WORKING]: the service accepted the key (HTTP 2xx).
 *  - [REJECTED]: the service answered but refused it (401/403 or any
 *    other HTTP error — the key, not the network, is the problem).
 *  - [UNREACHABLE]: no answer at all (offline/timeout) — the verdict is
 *    "couldn't check", never silently "working".
 * The verdict string is persisted in SettingsStore (*KeyStatus) and
 * shown on the Integrations rows, replacing every status that used to
 * be derived from non-blankness alone.
 */
object KeyValidation {
    const val WORKING = "working"
    const val REJECTED = "rejected"
    const val UNREACHABLE = "unreachable"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(16, TimeUnit.SECONDS)
        .build()

    private suspend fun probe(
        url: String,
        headers: Map<String, String> = emptyMap(),
        invalidKeyBodyMarker: String? = null
    ): String =
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder().url(url).get().apply {
                    header("Accept", "application/json")
                    headers.forEach { (k, v) -> header(k, v) }
                }.build()
                client.newCall(request).execute().use { resp ->
                    when {
                        resp.code in 200..299 -> WORKING
                        // A service that names the key as the problem
                        // in its body has rejected it, whatever the
                        // status code (MDBList answers 503 with
                        // "Invalid API key or Rate Limiter Reached!").
                        invalidKeyBodyMarker != null &&
                            resp.peekBody(512).string()
                                .contains(invalidKeyBodyMarker, ignoreCase = true) ->
                            REJECTED
                        // A client-side refusal (401/403, or any 4xx —
                        // MDBList's edge also answers 404 to a bad key)
                        // is the key's fault; a bare 5xx is the
                        // SERVICE's day, never proof a key is bad.
                        resp.code in 400..499 -> REJECTED
                        else -> UNREACHABLE
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                UNREACHABLE
            }
        }

    /**
     * TMDB: GET /3/configuration. Two credential shapes: the v3 API key
     * rides as api_key=; the v4 Read Access Token (a long eyJ... JWT —
     * the value TMDB's settings page shows most prominently) only works
     * as a Bearer header and 401s as a query value, so probing it the
     * v3 way marked good keys "rejected".
     */
    suspend fun tmdb(key: String): String {
        val trimmed = key.trim()
        return if (trimmed.startsWith("eyJ") || trimmed.length > 40) {
            probe(
                "https://api.themoviedb.org/3/configuration",
                headers = mapOf("Authorization" to "Bearer $trimmed")
            )
        } else {
            probe(
                "https://api.themoviedb.org/3/configuration?api_key=" +
                    URLEncoder.encode(trimmed, "UTF-8")
            )
        }
    }

    /** MDBList: the ratings endpoint for a staple IMDb id. */
    suspend fun mdblist(key: String): String =
        probe(
            "https://mdblist.com/api/?i=tt1375666&apikey=" +
                URLEncoder.encode(key, "UTF-8"),
            invalidKeyBodyMarker = "Invalid API key"
        )

    /** TorBox: GET /v1/api/user/me with the Bearer key. */
    suspend fun torbox(key: String): String =
        probe(
            "https://api.torbox.app/v1/api/user/me",
            mapOf("Authorization" to "Bearer $key")
        )

    /** Raw GET returning (HTTP code, body); null on any transport failure. */
    private suspend fun fetchBody(
        url: String,
        headers: Map<String, String> = emptyMap()
    ): Pair<Int, String>? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).get().apply {
                header("Accept", "application/json")
                headers.forEach { (k, v) -> header(k, v) }
            }.build()
            client.newCall(request).execute().use { resp ->
                resp.code to (resp.body?.string().orEmpty())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    /**
     * TorBox connect WITH the account (v0.14.24, item 4): the same
     * /user/me call as [torbox], but on success it also returns the
     * account label (email, plus plan when the service sends one) so
     * the connect flow can show WHICH account was connected. The
     * verdict keeps [probe]'s semantics; the label is null whenever
     * the verdict is not WORKING or the payload carries no email.
     */
    suspend fun torboxAccount(key: String): Pair<String, String?> {
        val (code, raw) = fetchBody(
            "https://api.torbox.app/v1/api/user/me",
            mapOf("Authorization" to "Bearer $key")
        ) ?: return UNREACHABLE to null
        val verdict = when (code) {
            in 200..299 -> WORKING
            in 400..499 -> REJECTED
            else -> UNREACHABLE
        }
        if (verdict != WORKING) return verdict to null
        val data = jsonOrNull(raw)?.optJSONObject("data")
        val email = data?.optString("email")?.takeIf { it.isNotBlank() }
            ?: return verdict to null
        val plan = listOf("plan", "premium_tier", "tier").firstNotNullOfOrNull { k ->
            data.opt(k)?.takeIf { it is String }?.let { it as String }?.takeIf { it.isNotBlank() }
        }
        return verdict to if (plan != null) "$email · $plan" else email
    }

    /** Real-Debrid: GET /rest/1.0/user with the Bearer token. */
    suspend fun realDebrid(key: String): String =
        probe(
            "https://api.real-debrid.com/rest/1.0/user",
            mapOf("Authorization" to "Bearer $key")
        )

    /**
     * Body-aware probe for the debrid providers whose APIs answer
     * business errors inside an HTTP-200 envelope (Premiumize,
     * AllDebrid, Debrid-Link, Offcloud): the HTTP code alone cannot
     * classify those, so [classify] receives the raw body. No usable
     * answer at all is UNREACHABLE, never "working".
     */
    private suspend fun probeWithBody(
        url: String,
        headers: Map<String, String> = emptyMap(),
        postForm: Map<String, String>? = null,
        classify: (httpCode: Int, rawBody: String) -> String
    ): String =
        withContext(Dispatchers.IO) {
            try {
                val builder = Request.Builder().url(url)
                builder.header("Accept", "application/json")
                headers.forEach { (k, v) -> builder.header(k, v) }
                if (postForm != null) {
                    val form = FormBody.Builder()
                    postForm.forEach { (k, v) -> form.add(k, v) }
                    builder.post(form.build())
                } else {
                    builder.get()
                }
                client.newCall(builder.build()).execute().use { resp ->
                    classify(resp.code, resp.body?.string().orEmpty())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                UNREACHABLE
            }
        }

    private fun jsonOrNull(raw: String): JSONObject? =
        try {
            JSONObject(raw)
        } catch (e: Exception) {
            null
        }

    /** Premiumize: GET /api/account/info — the envelope decides. */
    suspend fun premiumize(key: String): String =
        probeWithBody(
            "https://www.premiumize.me/api/account/info",
            mapOf("Authorization" to "Bearer $key")
        ) { code, raw ->
            val body = jsonOrNull(raw)
            when {
                body?.optString("status") == "success" -> WORKING
                code == 401 || code == 403 -> REJECTED
                body?.optString("code") in
                    setOf("authentication_failed", "permission_denied") -> REJECTED
                else -> UNREACHABLE
            }
        }

    /** AllDebrid: GET /v4/user — AUTH_* envelope codes are the key. */
    suspend fun allDebrid(key: String): String =
        probeWithBody(
            "https://api.alldebrid.com/v4/user",
            mapOf("Authorization" to "Bearer $key")
        ) { code, raw ->
            val body = jsonOrNull(raw)
            val errCode = body?.optJSONObject("error")?.optString("code").orEmpty()
            when {
                body?.optString("status") == "success" -> WORKING
                errCode.startsWith("AUTH_") -> REJECTED
                code in 400..499 -> REJECTED
                else -> UNREACHABLE
            }
        }

    /** Debrid-Link: GET /api/v2/account/infos — success flag + error code. */
    suspend fun debridLink(key: String): String =
        probeWithBody(
            "https://debrid-link.com/api/v2/account/infos",
            mapOf("Authorization" to "Bearer $key")
        ) { code, raw ->
            val body = jsonOrNull(raw)
            val err = body?.optString("error").orEmpty()
            when {
                body?.optBoolean("success") == true -> WORKING
                err in setOf(
                    "badToken", "hidedToken", "expired_token",
                    "unauthorized_client", "invalid_client", "access_denied"
                ) -> REJECTED
                code in 400..499 -> REJECTED
                else -> UNREACHABLE
            }
        }

    /** Offcloud: POST /api/cloud/history — an authenticated call
     *  answers a JSON array (possibly empty); a bad key answers
     *  `{"error":"NOAUTH"}`. */
    suspend fun offcloud(key: String): String =
        probeWithBody(
            "https://offcloud.com/api/cloud/history?apikey=" +
                URLEncoder.encode(key, "UTF-8"),
            postForm = emptyMap()
        ) { _, raw ->
            val body = jsonOrNull(raw)
            val err = body?.optString("error").orEmpty()
            when {
                err.equals("NOAUTH", ignoreCase = true) -> REJECTED
                err.isNotBlank() -> UNREACHABLE
                body != null -> WORKING
                raw.trimStart().startsWith("[") -> WORKING
                else -> UNREACHABLE
            }
        }
}
