package com.pulsestream.app.data

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Fire-and-forget transport for playback feedback (v0.14.28; server
 * contract PlavioHD v1.9.129 — see [FeedbackSupport]). One small POST
 * per attempt outcome to {plaviohd-base}/feedback, sent only after
 * the outcome is already known, from a background scope — it is
 * never on the playback path and can never delay, fail, or alter
 * playback:
 *
 *  - OkHttp async enqueue; the response is closed unread and every
 *    failure (offline, 404, a base that doesn't run the endpoint) is
 *    swallowed by design — reports are DROPPED when they can't be
 *    sent, never queued for later (the tracker holds at most the
 *    live attempt's state; there is no store-and-forward);
 *  - gated on the AppConfig "feedback" switch (default on) — the
 *    single choke point every report passes through;
 *  - the token is a random per-install UUID that rotates daily
 *    (persisted in this file's own prefs; [FeedbackSupport.tokenFor]
 *    owns the rule). No account, device, or hardware identifier is
 *    ever read, let alone sent.
 *
 * Deliberately NOT routed through [BoundedHttp] or the shared
 * clients, for the same reason as [PlavioWarm]: a report has no
 * answer the app needs and must never queue behind real traffic.
 */
internal object PlavioFeedback {

    private const val PREFS = "plavio_feedback"
    private const val KEY_TOKEN = "token"
    private const val KEY_TOKEN_DAY = "token_day"

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(6, TimeUnit.SECONDS)
        .build()

    /** Today's feedback token, generating + persisting a fresh one
     *  when the stored one has rolled past its day. */
    @Synchronized
    fun token(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val decision = FeedbackSupport.tokenFor(
            storedToken = prefs.getString(KEY_TOKEN, null),
            storedEpochDay = prefs.getLong(KEY_TOKEN_DAY, Long.MIN_VALUE),
            nowMs = System.currentTimeMillis()
        ) { UUID.randomUUID().toString() }
        if (decision.changed) {
            prefs.edit()
                .putString(KEY_TOKEN, decision.token)
                .putLong(KEY_TOKEN_DAY, decision.epochDay)
                .apply()
        }
        return decision.token
    }

    /**
     * Sends one outcome and returns immediately. A blank base (no
     * PlavioHD resolved) drops the report silently, exactly like a
     * failed send.
     */
    fun report(context: Context, baseUrl: String?, outcome: FeedbackSupport.Outcome) {
        if (!AppConfig.feedbackEnabled()) return
        val base = baseUrl?.trim()?.trimEnd('/')?.takeIf { it.isNotEmpty() } ?: return
        val request = try {
            Request.Builder()
                .url("$base/feedback")
                .post(FeedbackSupport.payloadJson(token(context), outcome).toRequestBody(JSON_MEDIA))
                .build()
        } catch (_: Exception) {
            return
        }
        try {
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // Swallowed by design: a lost report changes nothing.
                }

                override fun onResponse(call: Call, response: Response) {
                    response.close() // The body is intentionally never read.
                }
            })
        } catch (_: Exception) {
            // A report must never surface an error anywhere.
        }
    }

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
}
