package com.pulsestream.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Details
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Tv
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.MdbListApi
import com.pulsestream.app.data.MdbRatingsResolver
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StreamRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Integrations screen (v0.9.0+): third-party service connections.
 *
 * Hosts debrid integrations (TorBox, Real-Debrid): paste an API key and
 * torrent infoHash streams resolve to instant direct HTTP links.
 * Debrid-only — the app never downloads torrents itself.
 */
@Composable
fun IntegrationsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    val settings = repository.settings

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Integrations",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Connect third-party services to unlock extra features.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }

            // v0.14.26 (batch item 3): the whole page is FLAT and
            // section-wise — plain section headers, flat rows, NO
            // capsule cards anywhere on the page (the old
            // FoldedIntegration GlassCards and the DebridCard
            // editors are flat now; behaviour unchanged).
            item(key = "debrid_header") {
                SettingsSectionHeader("Debrid services")
            }

            item(key = "debrid_group") {
                var showTorboxDialog by remember { mutableStateOf(false) }
                var torboxTick by remember { mutableIntStateOf(0) }
                val torboxConfigured = remember(torboxTick) { !settings.torboxApiKey.isNullOrBlank() }
                var showRdDialog by remember { mutableStateOf(false) }
                var rdTick by remember { mutableIntStateOf(0) }
                val rdConfigured = remember(rdTick) { !settings.realDebridApiKey.isNullOrBlank() }
                var showPremiumizeDialog by remember { mutableStateOf(false) }
                var premiumizeTick by remember { mutableIntStateOf(0) }
                val premiumizeConfigured = remember(premiumizeTick) { !settings.premiumizeApiKey.isNullOrBlank() }
                var showAllDebridDialog by remember { mutableStateOf(false) }
                var allDebridTick by remember { mutableIntStateOf(0) }
                val allDebridConfigured = remember(allDebridTick) { !settings.allDebridApiKey.isNullOrBlank() }
                var showDebridLinkDialog by remember { mutableStateOf(false) }
                var debridLinkTick by remember { mutableIntStateOf(0) }
                val debridLinkConfigured = remember(debridLinkTick) { !settings.debridLinkApiKey.isNullOrBlank() }
                var showOffcloudDialog by remember { mutableStateOf(false) }
                var offcloudTick by remember { mutableIntStateOf(0) }
                val offcloudConfigured = remember(offcloudTick) { !settings.offcloudApiKey.isNullOrBlank() }
                SettingsGroup(
                    {
                        SettingsStaticRow(
                            icon = Icons.Filled.Bolt,
                            title = "TorBox",
                            subtitle = when (com.pulsestream.app.data.debrid.DebridSupport.accountState(torboxConfigured, settings.torboxKeyStatus)) {
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.ACTIVE ->
                                    settings.torboxAccountLabel?.let { "Connected — $it" } ?: "Connected"
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.INVALID -> "Key not accepted"
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.UNREACHABLE -> "Key saved — couldn't check"
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.NOT_CHECKED -> "API key saved — not checked"
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.CHECKING -> "Checking…"
                                com.pulsestream.app.data.debrid.DebridSupport.AccountState.NO_KEY -> "Add your API key for cached streams"
                            },
                            trailing = {
                                if (torboxConfigured) {
                                    Text(
                                        when (com.pulsestream.app.data.debrid.DebridSupport.accountState(torboxConfigured, settings.torboxKeyStatus)) {
                                            com.pulsestream.app.data.debrid.DebridSupport.AccountState.ACTIVE -> "Connected"
                                            com.pulsestream.app.data.debrid.DebridSupport.AccountState.INVALID -> "Wrong key"
                                            com.pulsestream.app.data.debrid.DebridSupport.AccountState.UNREACHABLE -> "Couldn't check"
                                            else -> "Saved"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = LocalPalette.current.accent
                                    )
                                } else {
                                    Icon(
                                        Icons.Filled.ChevronRight,
                                        contentDescription = "Configure TorBox",
                                        tint = TextSecondary
                                    )
                                }
                            },
                            onClick = { showTorboxDialog = true }
                        )
                    },
                    {
                        SettingsStaticRow(
                            icon = Icons.Filled.Bolt,
                            title = "Real-Debrid",
                            subtitle = if (rdConfigured) "Key saved — under testing, not active" else "Under testing — coming soon",
                            trailing = {
                                if (rdConfigured) {
                                    Text(
                                        "Under testing",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = LocalPalette.current.accent
                                    )
                                } else {
                                    Icon(
                                        Icons.Filled.ChevronRight,
                                        contentDescription = "Configure Real-Debrid",
                                        tint = TextSecondary
                                    )
                                }
                            },
                            onClick = { showRdDialog = true }
                        )
                    },
                    {
                        UnderTestingDebridRow(
                            title = "Premiumize",
                            state = com.pulsestream.app.data.debrid.DebridSupport.accountState(premiumizeConfigured, settings.premiumizeKeyStatus),
                            configured = premiumizeConfigured,
                            onClick = { showPremiumizeDialog = true }
                        )
                    },
                    {
                        UnderTestingDebridRow(
                            title = "AllDebrid",
                            state = com.pulsestream.app.data.debrid.DebridSupport.accountState(allDebridConfigured, settings.allDebridKeyStatus),
                            configured = allDebridConfigured,
                            onClick = { showAllDebridDialog = true }
                        )
                    },
                    {
                        UnderTestingDebridRow(
                            title = "Debrid-Link",
                            state = com.pulsestream.app.data.debrid.DebridSupport.accountState(debridLinkConfigured, settings.debridLinkKeyStatus),
                            configured = debridLinkConfigured,
                            onClick = { showDebridLinkDialog = true }
                        )
                    },
                    {
                        UnderTestingDebridRow(
                            title = "Offcloud",
                            state = com.pulsestream.app.data.debrid.DebridSupport.accountState(offcloudConfigured, settings.offcloudKeyStatus),
                            configured = offcloudConfigured,
                            onClick = { showOffcloudDialog = true }
                        )
                    }
                )
                if (showTorboxDialog) {
                    ApiKeyDialog(
                        title = "TorBox API Key",
                        keyLinkText = "Get your API key at torbox.app/settings",
                        keyLinkUrl = "https://torbox.app",
                        currentKey = settings.torboxApiKey,
                        enabled = true,
                        helpText = "Paste your TorBox API key and tap Save — the key is checked with TorBox as you save.",
                        onDisconnect = {
                            settings.torboxApiKey = null
                            settings.torboxKeyStatus = null
                            settings.torboxAccountLabel = null
                            torboxTick++
                        },
                        onSave = { settings.torboxApiKey = it; torboxTick++ },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.torbox(k) },
                        onSaveValidated = { k, v ->
                            settings.torboxApiKey = k
                            settings.torboxKeyStatus = v
                            torboxTick++
                        },
                        validateKeyWithAccount = { k ->
                            com.pulsestream.app.data.KeyValidation.torboxAccount(k)
                        },
                        onSaveAccount = { k, v, label ->
                            settings.torboxApiKey = k
                            settings.torboxKeyStatus = v
                            settings.torboxAccountLabel = label
                            torboxTick++
                        },
                        onDismiss = { showTorboxDialog = false }
                    )
                }
                if (showRdDialog) {
                    ApiKeyDialog(
                        title = "Real-Debrid API Key",
                        keyLinkText = "Get your API key at real-debrid.com/apitoken",
                        keyLinkUrl = "https://real-debrid.com",
                        currentKey = settings.realDebridApiKey,
                        enabled = false,
                        onDisconnect = {
                            settings.realDebridApiKey = null
                            settings.realDebridKeyStatus = null
                            rdTick++
                        },
                        onSave = { settings.realDebridApiKey = it; rdTick++ },
                        onDismiss = { showRdDialog = false }
                    )
                }
                if (showPremiumizeDialog) {
                    ApiKeyDialog(
                        title = "Premiumize API Key",
                        keyLinkText = "Get your API key at premiumize.me",
                        keyLinkUrl = "https://www.premiumize.me",
                        currentKey = settings.premiumizeApiKey,
                        enabled = true,
                        helpText = "Paste your Premiumize API key and tap Save — the key is checked with Premiumize as you save. Premiumize is under testing.",
                        onDisconnect = {
                            settings.premiumizeApiKey = null
                            settings.premiumizeKeyStatus = null
                            premiumizeTick++
                        },
                        onSave = { settings.premiumizeApiKey = it; premiumizeTick++ },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.premiumize(k) },
                        onSaveValidated = { k, v ->
                            settings.premiumizeApiKey = k
                            settings.premiumizeKeyStatus = v
                            premiumizeTick++
                        },
                        onDismiss = { showPremiumizeDialog = false }
                    )
                }
                if (showAllDebridDialog) {
                    ApiKeyDialog(
                        title = "AllDebrid API Key",
                        keyLinkText = "Get your API key at alldebrid.com",
                        keyLinkUrl = "https://alldebrid.com",
                        currentKey = settings.allDebridApiKey,
                        enabled = true,
                        helpText = "Paste your AllDebrid API key and tap Save — the key is checked with AllDebrid as you save. AllDebrid is under testing.",
                        onDisconnect = {
                            settings.allDebridApiKey = null
                            settings.allDebridKeyStatus = null
                            allDebridTick++
                        },
                        onSave = { settings.allDebridApiKey = it; allDebridTick++ },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.allDebrid(k) },
                        onSaveValidated = { k, v ->
                            settings.allDebridApiKey = k
                            settings.allDebridKeyStatus = v
                            allDebridTick++
                        },
                        onDismiss = { showAllDebridDialog = false }
                    )
                }
                if (showDebridLinkDialog) {
                    ApiKeyDialog(
                        title = "Debrid-Link API Key",
                        keyLinkText = "Get your API key at debrid-link.com",
                        keyLinkUrl = "https://debrid-link.com",
                        currentKey = settings.debridLinkApiKey,
                        enabled = true,
                        helpText = "Paste your Debrid-Link API token and tap Save — the token is checked with Debrid-Link as you save. Debrid-Link is under testing.",
                        onDisconnect = {
                            settings.debridLinkApiKey = null
                            settings.debridLinkKeyStatus = null
                            debridLinkTick++
                        },
                        onSave = { settings.debridLinkApiKey = it; debridLinkTick++ },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.debridLink(k) },
                        onSaveValidated = { k, v ->
                            settings.debridLinkApiKey = k
                            settings.debridLinkKeyStatus = v
                            debridLinkTick++
                        },
                        onDismiss = { showDebridLinkDialog = false }
                    )
                }
                if (showOffcloudDialog) {
                    ApiKeyDialog(
                        title = "Offcloud API Key",
                        keyLinkText = "Get your API key at offcloud.com",
                        keyLinkUrl = "https://offcloud.com",
                        currentKey = settings.offcloudApiKey,
                        enabled = true,
                        helpText = "Paste your Offcloud API key and tap Save — the key is checked with Offcloud as you save. Offcloud is under testing.",
                        onDisconnect = {
                            settings.offcloudApiKey = null
                            settings.offcloudKeyStatus = null
                            offcloudTick++
                        },
                        onSave = { settings.offcloudApiKey = it; offcloudTick++ },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.offcloud(k) },
                        onSaveValidated = { k, v ->
                            settings.offcloudApiKey = k
                            settings.offcloudKeyStatus = v
                            offcloudTick++
                        },
                        onDismiss = { showOffcloudDialog = false }
                    )
                }
            }

            item(key = "watch_sync_header") {
                SettingsSectionHeader("Tracking, lists & metadata")
            }

            // Each service is ONE folded entry (v0.14.6): tap to unfold,
            // every option lives inside — no separate screens.
            item(key = "fold_trakt") {
                FoldedIntegration(
                    icon = Icons.Filled.Sync,
                    title = "Trakt",
                    status = if (!settings.traktAccessToken.isNullOrBlank()) {
                        "Linked" + (settings.traktUsername?.let { " as $it" } ?: "")
                    } else "Watchlist, lists & watched marks"
                ) {
                    TraktFoldContent(settings = settings)
                }
            }

            item(key = "fold_simkl") {
                FoldedIntegration(
                    icon = Icons.Filled.CloudQueue,
                    title = "Simkl",
                    status = if (!settings.simklToken.isNullOrBlank()) {
                        "Linked" + (settings.simklUsername?.let { " as $it" } ?: "")
                    } else "Library in five statuses"
                ) {
                    SimklFoldContent(settings = settings)
                }
            }

            item(key = "fold_mdblist") {
                FoldedIntegration(
                    icon = Icons.Filled.FormatListBulleted,
                    title = "MDBList",
                    status = if (!settings.mdblistApiKey.isNullOrBlank()) "API key saved"
                    else "Ratings from everywhere + your lists"
                ) {
                    // Bumped on key save/remove so the ratings block
                    // below appears/disappears with the key.
                    var mdbKeyTick by remember { mutableIntStateOf(0) }
                    DebridCard(
                        title = "MDBList",
                        description = "Shows IMDb, Rotten Tomatoes, Metascore, Trakt and " +
                            "Letterboxd scores on the detail page, fills rating chips on " +
                            "posters, and brings your MDBList lists into the Library and " +
                            "the add-to-list sheet.",
                        keyLinkUrl = "https://mdblist.com/preferences",
                        keyLinkText = "Get your API key at mdblist.com/preferences",
                        currentKey = { settings.mdblistApiKey },
                        onSaveKey = {
                            settings.mdblistApiKey = it
                            if (it == null) settings.mdblistKeyStatus = null
                            mdbKeyTick++
                        },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.mdblist(k) },
                        onSaveValidated = { k, v ->
                            settings.mdblistApiKey = k
                            settings.mdblistKeyStatus = v
                        },
                        savedStatus = { settings.mdblistKeyStatus }
                    )
                    // Home card ratings (item 29, owner's order
                    // 2026-10-28): per-source switches for the small
                    // ratings strip on Home poster cards — shown only
                    // while a key is saved.
                    val mdbKey = remember(mdbKeyTick) { settings.mdblistApiKey }
                    if (!mdbKey.isNullOrBlank()) {
                        Spacer(Modifier.height(12.dp))
                        MdbHomeRatingsBlock(settings = settings, apiKey = mdbKey)
                    }
                }
            }

            item(key = "fold_tmdb") {
                FoldedIntegration(
                    icon = Icons.Filled.Movie,
                    title = "TMDB Enrichment",
                    status = when {
                        settings.tmdbApiKey.isNullOrBlank() -> "Fill gaps in any addon's details"
                        settings.tmdbKeyStatus == "rejected" -> "Wrong key — check it below"
                        settings.tmdbKeyStatus == "working" && settings.tmdbEnrichmentActive -> "Connected"
                        settings.tmdbKeyStatus == "working" -> "Connected — all parts off"
                        settings.tmdbEnrichmentActive -> "Key saved — not checked yet"
                        else -> "Key saved — all parts off"
                    }
                ) {
                    DebridCard(
                        title = "TMDB",
                        description = "Uses your own free TMDB key to fill whatever the " +
                            "serving addon is missing. The addon's own data always wins.",
                        keyLinkUrl = "https://www.themoviedb.org/settings/api",
                        keyLinkText = "Get a free API key at themoviedb.org",
                        currentKey = { settings.tmdbApiKey },
                        onSaveKey = {
                            settings.tmdbApiKey = it
                            if (it == null) settings.tmdbKeyStatus = null
                        },
                        validateKey = { k -> com.pulsestream.app.data.KeyValidation.tmdb(k) },
                        onSaveValidated = { k, v ->
                            settings.tmdbApiKey = k
                            settings.tmdbKeyStatus = v
                        },
                        savedStatus = { settings.tmdbKeyStatus }
                    )
                    Spacer(Modifier.height(12.dp))
                    SettingsGroup(
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.Image,
                                title = "Artwork",
                                subtitle = "Logo and backdrop when the addon has none",
                                checked = settings.tmdbEnrichArtwork,
                                onCheckedChange = { settings.tmdbEnrichArtwork = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.Info,
                                title = "Basic Info",
                                subtitle = "Overview, genres and score",
                                checked = settings.tmdbEnrichBasicInfo,
                                onCheckedChange = { settings.tmdbEnrichBasicInfo = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.Details,
                                title = "Details",
                                subtitle = "Runtime, year, country, status and age rating",
                                checked = settings.tmdbEnrichDetails,
                                onCheckedChange = { settings.tmdbEnrichDetails = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.People,
                                title = "Credits",
                                subtitle = "Cast names and photos",
                                checked = settings.tmdbEnrichCredits,
                                onCheckedChange = { settings.tmdbEnrichCredits = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.Business,
                                title = "Productions",
                                subtitle = "Production companies on the detail page",
                                checked = settings.tmdbEnrichProductions,
                                onCheckedChange = { settings.tmdbEnrichProductions = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.Tv,
                                title = "Networks",
                                subtitle = "The network a series airs on",
                                checked = settings.tmdbEnrichNetworks,
                                onCheckedChange = { settings.tmdbEnrichNetworks = it }
                            )
                        },
                        {
                            SettingsToggleRow(
                                icon = Icons.Filled.ListAlt,
                                title = "Episodes",
                                subtitle = "Episode titles, summaries and stills",
                                checked = settings.tmdbEnrichEpisodes,
                                onCheckedChange = { settings.tmdbEnrichEpisodes = it }
                            )
                        }
                    )
                }
            }

            item(key = "library_sync") {
                LibrarySyncRow(repository = repository)
            }

            item(key = "note") {
                // Flat note (v0.14.26, item 3): plain text under a
                // small header — no card on this page anymore.
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text(
                        "Note",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Cached torrents stream instantly without using download slots. " +
                            "When both are connected, TorBox is tried first, then Real-Debrid.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "⚠️ This feature is under development and testing, so you may experience issues. " +
                            "For any problem, please report it via Settings → Feedback, " +
                            "open an issue on GitHub, or reach out on our Discord channel.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

/**
 * One under-testing debrid provider row (native debrid layer,
 * v0.14.28): the honest account state from the validate-on-save
 * verdicts in the subtitle, the "Under testing" label in the
 * trailing slot — the Real-Debrid honesty pattern, shared by every
 * provider added after TorBox. A provider loses this row (and the
 * label) only on a real-account playback proof.
 */
@Composable
private fun UnderTestingDebridRow(
    title: String,
    state: com.pulsestream.app.data.debrid.DebridSupport.AccountState,
    configured: Boolean,
    onClick: () -> Unit
) {
    SettingsStaticRow(
        icon = Icons.Filled.Bolt,
        title = title,
        subtitle = when (state) {
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.ACTIVE -> "Connected — under testing"
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.INVALID -> "Key not accepted"
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.UNREACHABLE -> "Key saved — couldn't check"
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.NOT_CHECKED -> "API key saved — not checked"
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.CHECKING -> "Checking…"
            com.pulsestream.app.data.debrid.DebridSupport.AccountState.NO_KEY -> "Under testing — add your API key"
        },
        trailing = {
            if (configured) {
                Text(
                    "Under testing",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = LocalPalette.current.accent
                )
            } else {
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = "Configure $title",
                    tint = TextSecondary
                )
            }
        },
        onClick = onClick
    )
}

/**
 * One debrid service card: status indicator, password-masked API key field,
 * link to get a key, and plain Save / Remove buttons.
 */
@Composable
private fun DebridCard(
    title: String,
    description: String,
    keyLinkUrl: String,
    keyLinkText: String,
    currentKey: () -> String?,
    onSaveKey: (String?) -> Unit,
    modifier: Modifier = Modifier,
    tagLabel: String? = null,
    enabled: Boolean = true,
    // P5 (v0.14.22): validate-on-save — when both are supplied, Save
    // probes the service with the entered key and persists the key
    // together with its honest verdict via [onSaveValidated].
    validateKey: (suspend (String) -> String)? = null,
    onSaveValidated: ((String?, String?) -> Unit)? = null,
    savedStatus: () -> String? = { null }
) {
    val context = LocalContext.current
    val palette = LocalPalette.current

    // Bumped on save/remove so the "configured" state recomposes.
    var tick by remember { mutableIntStateOf(0) }
    val configured = remember(tick) { !currentKey().isNullOrBlank() }

    var keyInput by remember(tick) { mutableStateOf(currentKey() ?: "") }
    var showKey by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    val cardScope = rememberCoroutineScope()
    // Verdict flash (owner's order 2026-10-31): saving a key CHECKS it
    // and answers with a small message that disappears on its own —
    // "Connected ✓", "Wrong key", or "Couldn't check". Tone: 0 = ok,
    // 1 = wrong key, 2 = neutral. (The old persistent "Working" status
    // word is gone — a checked key is "Connected".)
    var flash by remember { mutableStateOf<Pair<String, Int>?>(null) }
    LaunchedEffect(flash) {
        if (flash != null) {
            delay(3500)
            flash = null
        }
    }

    // Flat since v0.14.26 (item 3): the key editor sits plainly on
    // the page with hairline dividers — no GlassCard shell.
    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Bolt,
                    contentDescription = null,
                    tint = palette.accent,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                if (tagLabel != null) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tagLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = palette.accent,
                        modifier = Modifier
                            .padding(start = 4.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(
                    // P5: the persisted probe verdict, never non-blankness.
                    when (savedStatus()) {
                        "working" -> "Connected"
                        "rejected" -> "Wrong key"
                        "unreachable" -> "Saved — couldn't check"
                        else -> if (configured) "Saved — not checked" else "Not connected"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (configured) palette.accent else TextSecondary
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = keyInput,
                onValueChange = {
                    keyInput = it
                    flash = null
                },
                label = { Text("$title API key") },
                placeholder = { Text(if (enabled) "Paste your API key" else "Under testing") },
                singleLine = true,
                enabled = enabled,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }, enabled = enabled) {
                        Icon(
                            if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (showKey) "Hide key" else "Show key",
                            tint = TextSecondary
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))

            TextButton(
                onClick = {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(keyLinkUrl))
                    )
                }
            ) {
                Text(keyLinkText)
                Spacer(Modifier.width(4.dp))
                Icon(
                    Icons.Filled.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.padding(start = 2.dp)
                )
            }
            Spacer(Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val newKey = keyInput.trim().ifBlank { null }
                        if (onSaveValidated != null && validateKey != null && newKey != null) {
                            checking = true
                            cardScope.launch {
                                val verdict = runCatching { validateKey(newKey) }
                                    .getOrDefault(com.pulsestream.app.data.KeyValidation.UNREACHABLE)
                                onSaveValidated(newKey, verdict)
                                checking = false
                                tick++
                                flash = when (verdict) {
                                    com.pulsestream.app.data.KeyValidation.WORKING ->
                                        "Connected ✓" to 0
                                    com.pulsestream.app.data.KeyValidation.REJECTED ->
                                        "Wrong key — not accepted" to 1
                                    else ->
                                        "Couldn't check the key — saved anyway" to 2
                                }
                            }
                        } else {
                            onSaveKey(newKey)
                            tick++
                            flash = "Saved ✓" to 0
                        }
                    },
                    enabled = enabled && !checking,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.accent
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (checking) "Checking…" else "Save")
                }
                if (configured) {
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = {
                            onSaveKey(null)
                            keyInput = ""
                            tick++
                            flash = "Key removed" to 2
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Remove")
                    }
                }
            }
            flash?.let { (text, tone) ->
                Spacer(Modifier.height(8.dp))
                Text(
                    text,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = when (tone) {
                        0 -> palette.accent
                        1 -> MaterialTheme.colorScheme.error
                        else -> TextSecondary
                    }
                )
            }
    }
}

/**
 * Simple API key input dialog, shown when tapping a service row.
 */
@Composable
private fun ApiKeyDialog(
    title: String,
    keyLinkText: String,
    keyLinkUrl: String,
    currentKey: String?,
    enabled: Boolean,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
    helpText: String? = null,
    // P5 (v0.14.22): validate-on-save, same contract as DebridCard.
    validateKey: (suspend (String) -> String)? = null,
    onSaveValidated: ((String, String) -> Unit)? = null,
    // Item 4 (v0.14.24): when supplied, the connect also fetches the
    // account label and a successful verdict reads "Connected ✓ —
    // <account>" before the dialog closes; [onSaveAccount] persists
    // key + verdict + label together.
    validateKeyWithAccount: (suspend (String) -> Pair<String, String?>)? = null,
    onSaveAccount: ((String, String, String?) -> Unit)? = null,
    // Disconnect (owner's order 2026-11-02, v0.14.39): when a key is
    // saved and this is supplied, the dialog offers a Disconnect
    // button (with the owner's approved confirm wording) that wipes
    // the stored key + its verdict. Previously the only removal path
    // was "clear the field and save" — there was no disconnect.
    serviceName: String = title.removeSuffix(" API Key"),
    onDisconnect: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var keyInput by remember { mutableStateOf(currentKey ?: "") }
    var showKey by remember { mutableStateOf(false) }
    var saveFailed by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    var showDisconnectConfirm by remember { mutableStateOf(false) }
    // Verdict shown inside the dialog after the check (owner's order
    // 2026-10-31): "Connected ✓" flashes and the dialog closes; a wrong
    // key stays open with its message so it can be fixed on the spot.
    var verdictMsg by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val dialogScope = rememberCoroutineScope()

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = TextPrimary) },
        text = {
            Column {
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it; saveFailed = false; verdictMsg = null },
                    label = { Text("API key") },
                    singleLine = true,
                    enabled = enabled,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }, enabled = enabled) {
                            Icon(
                                if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (showKey) "Hide key" else "Show key",
                                tint = TextSecondary
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                TextButton(
                    onClick = {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(keyLinkUrl))
                        )
                    }
                ) {
                        Text(keyLinkText, color = LocalPalette.current.accent)
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        Icons.Filled.OpenInNew,
                        contentDescription = null,
                        tint = LocalPalette.current.accent
                    )
                }
                if (helpText != null) {
                    Text(
                        helpText,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                if (onDisconnect != null && !currentKey.isNullOrBlank()) {
                    // Disconnect (v0.14.39): shown only while a key is
                    // actually saved. Not gated on [enabled] — a key
                    // saved under an under-testing provider must still
                    // be removable.
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { showDisconnectConfirm = true }) {
                        Text("Disconnect", color = Color(0xFFF87171))
                    }
                }
                if (saveFailed) {
                    Text(
                        "Could not save the API key securely. Please try again.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                verdictMsg?.let { (text, isError) ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isError) MaterialTheme.colorScheme.error
                            else LocalPalette.current.accent
                    )
                }
                if (!enabled) {
                    Text(
                        "Currently under testing — coming soon.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val entered = keyInput.trim()
                    if (validateKeyWithAccount != null && onSaveAccount != null && entered.isNotBlank()) {
                        // Item 4 (v0.14.24): verify + show the account.
                        checking = true
                        dialogScope.launch {
                            val (verdict, accountLabel) = runCatching { validateKeyWithAccount(entered) }
                                .getOrDefault(com.pulsestream.app.data.KeyValidation.UNREACHABLE to null)
                            checking = false
                            try {
                                onSaveAccount(entered, verdict, accountLabel)
                                when (verdict) {
                                    com.pulsestream.app.data.KeyValidation.WORKING -> {
                                        verdictMsg = (if (accountLabel != null) {
                                            "Connected ✓ — $accountLabel"
                                        } else {
                                            "Connected ✓"
                                        }) to false
                                        delay(1600)
                                        onDismiss()
                                    }
                                    com.pulsestream.app.data.KeyValidation.REJECTED -> {
                                        verdictMsg =
                                            "Wrong key — not accepted. Check it and try again." to true
                                    }
                                    else -> {
                                        verdictMsg =
                                            "Couldn't check the key — saved anyway" to false
                                        delay(1400)
                                        onDismiss()
                                    }
                                }
                            } catch (_: Exception) {
                                saveFailed = true
                            }
                        }
                    } else if (onSaveValidated != null && validateKey != null && entered.isNotBlank()) {
                        checking = true
                        dialogScope.launch {
                            val verdict = runCatching { validateKey(entered) }
                                .getOrDefault(com.pulsestream.app.data.KeyValidation.UNREACHABLE)
                            checking = false
                            try {
                                onSaveValidated(entered, verdict)
                                when (verdict) {
                                    com.pulsestream.app.data.KeyValidation.WORKING -> {
                                        verdictMsg = "Connected ✓" to false
                                        delay(1200)
                                        onDismiss()
                                    }
                                    com.pulsestream.app.data.KeyValidation.REJECTED -> {
                                        verdictMsg =
                                            "Wrong key — not accepted. Check it and try again." to true
                                    }
                                    else -> {
                                        verdictMsg =
                                            "Couldn't check the key — saved anyway" to false
                                        delay(1400)
                                        onDismiss()
                                    }
                                }
                            } catch (_: Exception) {
                                saveFailed = true
                            }
                        }
                    } else {
                        try {
                            onSave(entered)
                            onDismiss()
                        } catch (_: Exception) {
                            // Never expose the key or a storage exception in UI/logs.
                            saveFailed = true
                        }
                    }
                },
                enabled = enabled && !checking
            ) {
                Text(if (checking) "Checking…" else "Save", color = LocalPalette.current.accent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )

    // Disconnect confirm (v0.14.39, owner-approved wording): the key
    // is wiped (and its saved verdict cleared by the caller) only on
    // an explicit Disconnect tap here.
    if (showDisconnectConfirm && onDisconnect != null) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDisconnectConfirm = false },
            title = { Text("Disconnect $serviceName?", color = TextPrimary) },
            text = {
                Text(
                    "Your key will be removed from the app. You can add it again anytime.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDisconnectConfirm = false
                        onDisconnect()
                        onDismiss()
                    }
                ) { Text("Disconnect", color = Color(0xFFF87171)) }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

/**
 * Library sync row (issue #3): keeps the in-app library in sync with the
 * linked Trakt watchlist / Simkl library. Manual "Sync" tap, plus a quiet
 * auto-sync when this screen opens and the last run is over 15 minutes old.
 */
@Composable
private fun LibrarySyncRow(repository: StreamRepository) {
    val settings = repository.settings
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val linked = remember(tick) { repository.librarySyncLinked() }
    val lastResult = remember(tick) { settings.librarySyncLastResult }

    fun runSync() {
        if (busy || !linked) return
        busy = true
        scope.launch {
            runCatching { repository.syncLibraryWithServices() }
            busy = false
            tick++
        }
    }

    LaunchedEffect(Unit) {
        if (linked && System.currentTimeMillis() - settings.librarySyncLastAt > 15 * 60_000L) {
            runSync()
        }
    }

    SettingsStaticRow(
        icon = Icons.Filled.Sync,
        title = "Library sync",
        subtitle = when {
            !linked -> "Link Trakt or Simkl above to sync your library"
            busy -> "Syncing…"
            lastResult.isNotBlank() -> lastResult
            else -> "Keep this library in sync with Trakt and Simkl"
        },
        trailing = {
            if (linked) {
                Text(
                    if (busy) "…" else "Sync",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = LocalPalette.current.accent
                )
            } else {
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }
        },
        onClick = { runSync() }
    )
}

/**
 * One folded integration entry: a header row (icon tile, name,
 * status line, chevron) that unfolds its options inline. The
 * owner's rule: every option lives inside its entry — no separate
 * screens. FLAT since v0.14.26 (batch item 3): no capsule card —
 * the row sits plainly on the page under its section header with
 * a hairline divider, in the standard Settings row shape; the
 * expand behaviour is unchanged.
 */
@Composable
private fun FoldedIntegration(
    icon: ImageVector,
    title: String,
    status: String,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SettingsIconTile(icon, title)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = if (expanded) "Collapse $title" else "Expand $title",
                tint = TextSecondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(
                Modifier.padding(start = 20.dp, end = 20.dp, bottom = 12.dp)
            ) { content() }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .padding(start = 78.dp, end = 20.dp)
                .height(1.dp)
                .background(TextSecondary.copy(alpha = 0.16f))
        )
    }
}

/**
 * "Home card ratings" block inside the MDBList fold (item 29, owner's
 * order 2026-10-28): one switch per rating source MDBList provides
 * for this user — all on by default when a key is added, each one
 * switchable off. Only the enabled sources appear in the small strip
 * at the bottom of Home poster cards.
 *
 * The toggle list is driven by the sources MDBList has actually been
 * seen to return: on first composition a probe fetch for Inception
 * (tt1375666 — it carries nearly every source) seeds the known set,
 * and any source already resolved for a Home card joins it too. A
 * failed probe keeps whatever is already known.
 */
@Composable
private fun MdbHomeRatingsBlock(settings: SettingsStore, apiKey: String) {
    var knownSources by remember { mutableStateOf(settings.mdblistKnownSources) }
    var disabledSources by remember { mutableStateOf(settings.mdblistDisabledSources) }
    val resolverRatings by MdbRatingsResolver.ratings.collectAsState()

    fun unionKnown(found: Collection<String>) {
        if (found.isEmpty()) return
        val merged = settings.mdblistKnownSources + found
        if (merged != settings.mdblistKnownSources) {
            settings.mdblistKnownSources = merged
            knownSources = merged
        }
    }

    LaunchedEffect(apiKey) {
        val probed = runCatching { MdbListApi(apiKey).ratings("tt1375666") }.getOrNull()
        unionKnown(probed?.sources?.map { it.key }.orEmpty())
    }
    LaunchedEffect(resolverRatings) {
        unionKnown(resolverRatings.values.flatMap { ratings -> ratings.sources.map { it.key } })
    }

    Text(
        "Home card ratings",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = TextPrimary
    )
    Spacer(Modifier.height(6.dp))
    Text(
        "Shown small at the bottom of Home cards.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
    )
    // Stable display order: the familiar sources first, any others
    // MDBList adds later follow alphabetically.
    val sourceOrder = listOf(
        "imdb", "tmdb", "trakt", "letterboxd",
        "rt_critics", "rt_audience", "metacritic", "myanimelist"
    )
    val orderedKnown = knownSources.sortedWith(
        compareBy<String> { key ->
            sourceOrder.indexOf(key).let { if (it < 0) sourceOrder.size else it }
        }.thenBy { it }
    )
    if (orderedKnown.isEmpty()) {
        Spacer(Modifier.height(6.dp))
        Text(
            "Ratings will appear here after they're fetched",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    } else {
        orderedKnown.forEach { key ->
            SettingsToggleRow(
                icon = Icons.Filled.Star,
                title = MdbListApi.labelFor(key),
                subtitle = when (key) {
                    "imdb", "tmdb", "myanimelist" -> "Score out of 10"
                    "letterboxd" -> "Score out of 5"
                    "rt_critics", "rt_audience", "metacritic", "trakt" -> "Percent score"
                    else -> "Rating source"
                },
                checked = key !in disabledSources,
                onCheckedChange = { enabled ->
                    disabledSources =
                        if (enabled) disabledSources - key else disabledSources + key
                    settings.mdblistDisabledSources = disabledSources
                }
            )
        }
    }
}
