package com.pulsestream.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * TMDB API client for enriching cast data with photos and IDs.
 * Used when user has provided a TMDB API key in Integrations.
 */
object TmdbClient {
    private const val BASE = "https://api.themoviedb.org/3"
    private const val IMG_BASE = "https://image.tmdb.org/t/p/w185"
    
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * TMDB accepts two credential shapes: the classic 32-char v3 API key
     * (sent as the api_key= query param) and the v4 Read Access Token — a
     * long eyJ... JWT that must go in an Authorization: Bearer header.
     * Sent as a query value the v4 token 401s on every call, which is how
     * a linked key used to look "On" in Integrations while every TMDB
     * stage silently failed. Detect the shape and speak both.
     */
    private fun isBearerKey(apiKey: String): Boolean =
        apiKey.startsWith("eyJ") || apiKey.length > 40

    /** Strips the api_key= param for Bearer keys (it travels in the header). */
    private fun authed(url: String, apiKey: String): String =
        if (!isBearerKey(apiKey)) url
        else url.replace("api_key=$apiKey&", "").replace("?api_key=$apiKey", "")

    private fun authHeaders(apiKey: String): Map<String, String> =
        if (isBearerKey(apiKey)) {
            mapOf("Accept" to "application/json", "Authorization" to "Bearer $apiKey")
        } else {
            mapOf("Accept" to "application/json")
        }

    /** True when TMDB actually accepts the credential (either shape). */
    suspend fun validateKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        runCatching {
            BoundedHttp.get(
                authed("$BASE/configuration?api_key=$apiKey", apiKey),
                headers = authHeaders(apiKey)
            )
            true
        }.getOrDefault(false)
    }

    internal fun isFullyEnrichedCast(cast: List<CastMember>): Boolean =
        cast.isNotEmpty() && cast.all { it.photo != null && it.id > 0 }

    /**
     * Enrich cast members with TMDB photos and IDs.
     * Takes a Stremio/IMDb ID (resolved via /find) or a TMDB-native "tmdb:" id (used directly).
     * Only enriches members that lack photo or have id=0.
     */
    suspend fun enrichCast(
        apiKey: String,
        stremioId: String,
        mediaType: String, // "movie" or "series"
        cast: List<CastMember>
    ): List<CastMember> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext cast
        // Only enrich if needed
        if (isFullyEnrichedCast(cast)) return@withContext cast
        
        try {
            val tmdbType = if (mediaType == "series") "tv" else "movie"
            // TMDB-native ids ("tmdb:693134", "tmdb:movie:693134") carry the
            // TMDB id directly; the /find lookup only resolves IMDb ids and
            // returns nothing for them, which silently skipped enrichment.
            val tmdbId: Int? = if (stremioId.startsWith("tmdb:")) {
                stremioId.removePrefix("tmdb:").substringAfterLast(":").toIntOrNull()
            } else {
                // Resolve Stremio/IMDb ID to TMDB ID via find API
                val findUrl = "$BASE/find/$stremioId?api_key=$apiKey&external_source=imdb_id"
                val findResponse = BoundedHttp.get(authed(findUrl, apiKey), headers = authHeaders(apiKey))
                val findJson = json.parseToJsonElement(findResponse).jsonObject
                val results = findJson["${tmdbType}_results"]?.jsonArray
                results?.firstOrNull()?.jsonObject?.get("id")?.jsonPrimitive?.content?.toIntOrNull()
            }
            val resolvedTmdbId = tmdbId ?: return@withContext cast
            
            val url = "$BASE/$tmdbType/$resolvedTmdbId/credits?api_key=$apiKey"
            val response = BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
            val root = json.parseToJsonElement(response).jsonObject
            val tmdbCast = root["cast"]?.jsonArray ?: return@withContext cast
            
            val photoMap = mutableMapOf<String, Triple<Int, String?, String?>>()
            val tmdbFullCast = mutableListOf<CastMember>()
            for (el in tmdbCast) {
                val obj = el.jsonObject
                val name = obj["name"]?.jsonPrimitive?.content ?: continue
                val id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
                val profile = obj["profile_path"]?.jsonPrimitive?.content
                val photoUrl = if (profile != null) "$IMG_BASE$profile" else null
                val character = obj["character"]?.jsonPrimitive?.content
                photoMap[name.lowercase()] = Triple(id, photoUrl, character)
                // Build full cast list (up to 15) from TMDB
                if (tmdbFullCast.size < 15) {
                    tmdbFullCast.add(
                        CastMember(id = id, name = name, photo = photoUrl, character = character)
                    )
                }
            }
            
            // If addon provided few actors (< 5), use TMDB's full cast list instead
            if (cast.size < 5 && tmdbFullCast.isNotEmpty()) {
                return@withContext tmdbFullCast
            }
            
            cast.map { member ->
                val match = photoMap[member.name.lowercase()]
                if (match != null) {
                    member.copy(
                        id = if (member.id == 0) match.first else member.id,
                        photo = member.photo ?: match.second,
                        character = member.character ?: match.third
                    )
                } else member
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            cast // Return original on failure
        }
    }

    /**
     * Fetch actor details + filmography directly from TMDB.
     * Returns PersonDetail with movies/series lists.
     */
    suspend fun getPerson(
        apiKey: String,
        personId: Int
    ): PersonDetail? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || personId <= 0) return@withContext null
        try {
            // Person details
            val personUrl = "$BASE/person/$personId?api_key=$apiKey"
            val personResponse = BoundedHttp.get(authed(personUrl, apiKey), headers = authHeaders(apiKey))
            val personJson = json.parseToJsonElement(personResponse).jsonObject
            val name = personJson["name"]?.jsonPrimitive?.content ?: return@withContext null
            val profile = personJson["profile_path"]?.jsonPrimitive?.content
            val photo = if (profile != null) "https://image.tmdb.org/t/p/w185$profile" else null
            // Actor details (v0.14.40, item 14): the person payload
            // already carries these — contentOrNull throughout, so
            // a JSON null never becomes the literal text "null".
            val birthday = personJson["birthday"]?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }
            val deathday = personJson["deathday"]?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }
            val placeOfBirth = personJson["place_of_birth"]?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }
            val biography = personJson["biography"]?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }

            // Combined credits (movies + TV)
            val creditsUrl = "$BASE/person/$personId/combined_credits?api_key=$apiKey"
            val creditsResponse = BoundedHttp.get(authed(creditsUrl, apiKey), headers = authHeaders(apiKey))
            val creditsJson = json.parseToJsonElement(creditsResponse).jsonObject
            val castArray = creditsJson["cast"]?.jsonArray ?: return@withContext PersonDetail(
                id = personId, name = name, photo = photo,
                movies = emptyList(), series = emptyList(),
                birthday = birthday, deathday = deathday,
                placeOfBirth = placeOfBirth, biography = biography
            )

            val movies = mutableListOf<MetaPreview>()
            val series = mutableListOf<MetaPreview>()
            for (el in castArray) {
                val obj = el.jsonObject
                val mediaType = obj["media_type"]?.jsonPrimitive?.content ?: continue
                val id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
                val title = obj["title"]?.jsonPrimitive?.content
                    ?: obj["name"]?.jsonPrimitive?.content ?: continue
                val poster = obj["poster_path"]?.jsonPrimitive?.content
                val posterUrl = if (poster != null) "https://image.tmdb.org/t/p/w342$poster" else null
                // TMDB IDs need to be mapped back; use a tmdb: prefix so the app can resolve
                val metaId = "tmdb:$mediaType:$id"
                val item = MetaPreview(id = metaId, type = mediaType, name = title, poster = posterUrl)
                if (mediaType == "movie") movies.add(item) else series.add(item)
            }

            // "Known for" (v0.14.40, item 14): the two most
            // popular DISTINCT cast credits — the titles this
            // person is actually known for.
            val knownFor = castArray
                .mapNotNull { el ->
                    val obj = el.jsonObject
                    val title = obj["title"]?.jsonPrimitive?.contentOrNull
                        ?: obj["name"]?.jsonPrimitive?.contentOrNull
                        ?: return@mapNotNull null
                    val popularity = obj["popularity"]?.jsonPrimitive?.content
                        ?.toDoubleOrNull() ?: 0.0
                    title to popularity
                }
                .sortedByDescending { it.second }
                .map { it.first }
                .distinct()
                .take(2)
            PersonDetail(
                id = personId,
                name = name,
                photo = photo,
                movies = movies.take(20),
                series = series.take(20),
                birthday = birthday, deathday = deathday,
                placeOfBirth = placeOfBirth, biography = biography,
                knownFor = knownFor
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** One TMDB search hit carrying the ranking signals MetaPreview lacks. */
    data class TmdbSearchHit(
        val title: String,
        /** "movie" or "series" (mapped from TMDB's movie/tv). */
        val type: String,
        val year: Int?,
        val popularity: Double,
        val voteAverage: Double,
        val voteCount: Int
    )

    /**
     * Search TMDB and return popularity / vote data for ranking (v0.12.1).
     * Used by StreamRepository to order merged addon search results by
     * real popularity instead of relying on IMDb rating alone. Returns an
     * empty list on any failure — callers treat that as "no enrichment".
     */
    suspend fun searchWithPopularity(apiKey: String, query: String): List<TmdbSearchHit> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank() || query.trim().length < 2) return@withContext emptyList()
            try {
                val encoded = java.net.URLEncoder.encode(query.trim(), "UTF-8")
                val url = "$BASE/search/multi?api_key=$apiKey&query=$encoded&page=1&include_adult=false"
                val response = BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
                val root = json.parseToJsonElement(response).jsonObject
                val results = root["results"]?.jsonArray ?: return@withContext emptyList()
                val out = mutableListOf<TmdbSearchHit>()
                for (el in results.take(20)) {
                    val obj = el.jsonObject
                    val mediaType = obj["media_type"]?.jsonPrimitive?.content ?: continue
                    if (mediaType != "movie" && mediaType != "tv") continue
                    val title = obj["title"]?.jsonPrimitive?.content
                        ?: obj["name"]?.jsonPrimitive?.content ?: continue
                    val dateStr = obj["release_date"]?.jsonPrimitive?.content
                        ?: obj["first_air_date"]?.jsonPrimitive?.content
                    val year = dateStr?.take(4)?.toIntOrNull()
                    out.add(
                        TmdbSearchHit(
                            title = title,
                            type = if (mediaType == "movie") "movie" else "series",
                            year = year,
                            popularity = obj["popularity"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: 0.0,
                            voteAverage = obj["vote_average"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: 0.0,
                            voteCount = obj["vote_count"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
                        )
                    )
                }
                out
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { emptyList() }
        }

    /**
     * This week's trending movies + series (v0.12.4) — backs the Search
     * tab's "Popular right now" list. Ids use the same
     * "tmdb:<mediaType>:<id>" shape [search] produces, which the
     * detail-target resolver already understands. Empty on any failure.
     */
    suspend fun trending(apiKey: String, limit: Int = 10): List<MetaPreview> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext emptyList()
        try {
            val url = "$BASE/trending/all/week?api_key=$apiKey&language=en-US&page=1"
            val response = BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
            val root = json.parseToJsonElement(response).jsonObject
            val results = root["results"]?.jsonArray ?: return@withContext emptyList()
            val out = mutableListOf<MetaPreview>()
            for (el in results) {
                val obj = el.jsonObject
                val mediaType = obj["media_type"]?.jsonPrimitive?.content ?: continue
                if (mediaType != "movie" && mediaType != "tv") continue
                val id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
                val title = obj["title"]?.jsonPrimitive?.content
                    ?: obj["name"]?.jsonPrimitive?.content ?: continue
                val poster = obj["poster_path"]?.jsonPrimitive?.content
                val posterUrl = if (poster != null) "https://image.tmdb.org/t/p/w342$poster" else null
                val backdrop = obj["backdrop_path"]?.jsonPrimitive?.content
                val backdropUrl = if (backdrop != null) "https://image.tmdb.org/t/p/w780$backdrop" else null
                val dateStr = obj["release_date"]?.jsonPrimitive?.content
                    ?: obj["first_air_date"]?.jsonPrimitive?.content
                val year = dateStr?.take(4)?.toIntOrNull()?.toString()
                val type = if (mediaType == "movie") "movie" else "series"
                out.add(
                    MetaPreview(
                        id = "tmdb:$mediaType:$id", type = type, name = title,
                        poster = posterUrl, background = backdropUrl, releaseInfo = year,
                        originalLanguage = obj["original_language"]?.jsonPrimitive?.content
                    )
                )
                if (out.size >= limit) break
            }
            out
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { emptyList() }
    }

    /** Vote-count floors for Discover popular (v0.14.32): keeps
     *  the obscure tail out of the per-language popular lists. */
    internal const val DISCOVER_MOVIE_VOTE_FLOOR = 50
    internal const val DISCOVER_TV_VOTE_FLOOR = 20

    /** Pure URL builder for one Discover page (unit-tested). */
    internal fun discoverUrl(mediaType: String, language: String, voteFloor: Int): String {
        val lang = java.net.URLEncoder.encode(language.trim(), "UTF-8")
        return "$BASE/discover/$mediaType?include_adult=false&language=en-US&page=1" +
            "&sort_by=popularity.desc&with_original_language=$lang&vote_count.gte=$voteFloor"
    }

    /** Pure parser for one Discover response (unit-tested):
     *  (preview, popularity) pairs in served order. Mirrors
     *  [trending]'s preview shape exactly. */
    internal fun parseDiscoverResults(
        root: kotlinx.serialization.json.JsonObject,
        mediaType: String
    ): List<Pair<MetaPreview, Double>> {
        val results = root["results"]?.jsonArray ?: return emptyList()
        val out = mutableListOf<Pair<MetaPreview, Double>>()
        for (el in results) {
            val obj = el.jsonObject
            val id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
            val title = obj["title"]?.jsonPrimitive?.content
                ?: obj["name"]?.jsonPrimitive?.content ?: continue
            val poster = obj["poster_path"]?.jsonPrimitive?.content
            val backdrop = obj["backdrop_path"]?.jsonPrimitive?.content
            val dateStr = obj["release_date"]?.jsonPrimitive?.content
                ?: obj["first_air_date"]?.jsonPrimitive?.content
            val popularity = obj["popularity"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: 0.0
            out.add(
                MetaPreview(
                    id = "tmdb:$mediaType:$id",
                    type = if (mediaType == "movie") "movie" else "series",
                    name = title,
                    poster = if (poster != null) "https://image.tmdb.org/t/p/w342$poster" else null,
                    background = if (backdrop != null) "https://image.tmdb.org/t/p/w780$backdrop" else null,
                    releaseInfo = dateStr?.take(4)?.toIntOrNull()?.toString(),
                    originalLanguage = obj["original_language"]?.jsonPrimitive?.content
                ) to popularity
            )
        }
        return out
    }

    /**
     * Popular titles IN one original language (v0.14.32) — the
     * pipe behind the Search landing's "Popular" section: TMDB
     * Discover per language (movies + series, most popular first,
     * a sane vote-count floor), merged by popularity. Deliberately
     * NOT Similar: TMDB's similar graph for non-English titles is
     * broken (proven live 2026-11-09), Discover is the direct
     * route. Empty on any failure.
     */
    suspend fun discoverPopular(
        apiKey: String?,
        language: String,
        limit: Int = 40
    ): List<MetaPreview> = withContext(Dispatchers.IO) {
        if (apiKey.isNullOrBlank() || language.isBlank()) return@withContext emptyList()
        try {
            val scored = mutableListOf<Pair<MetaPreview, Double>>()
            for ((mediaType, floor) in listOf(
                "movie" to DISCOVER_MOVIE_VOTE_FLOOR,
                "tv" to DISCOVER_TV_VOTE_FLOOR
            )) {
                val url = authed(discoverUrl(mediaType, language, floor), apiKey)
                val response = BoundedHttp.get(url, headers = authHeaders(apiKey))
                scored += parseDiscoverResults(
                    json.parseToJsonElement(response).jsonObject, mediaType
                )
            }
            scored.sortedByDescending { it.second }.map { it.first }.take(limit)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { emptyList() }
    }

    /** The seven TMDB Enrichment toggles, snapshotted from settings. */
    data class EnrichToggles(
        val artwork: Boolean,
        val basicInfo: Boolean,
        val details: Boolean,
        val credits: Boolean,
        val productions: Boolean,
        val networks: Boolean,
        val episodes: Boolean
    )

    private fun tmdbImage(path: String?, size: String): String? =
        if (path.isNullOrBlank()) null else "https://image.tmdb.org/t/p/$size$path"

    private fun str(obj: kotlinx.serialization.json.JsonObject, key: String): String? =
        obj[key]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() }

    private fun formatRuntime(minutes: Int): String? = when {
        minutes <= 0 -> null
        minutes >= 60 -> "${minutes / 60}h ${minutes % 60}m"
        else -> "${minutes}m"
    }

    /** A meta resolved onto TMDB: numeric id + TMDB media type ("movie"/"tv"). */
    data class TmdbTarget(val tmdbId: Int, val tmdbType: String)

    /** Session memo of successful resolutions, keyed by addon id + title + year. */
    private val targetCache = java.util.concurrent.ConcurrentHashMap<String, TmdbTarget>()

    /**
     * Resolve ANY addon's meta onto TMDB (v0.14.16). Three routes, in
     * order: a TMDB-native `tmdb:` id is used directly; an IMDb tt id
     * (the meta's own id, or an `imdb_id` the addon sent alongside an
     * opaque id) goes through /find; anything else — e.g. CNCVerse's
     * `cnc:` payloads, which carry NEITHER — falls back to a title +
     * year search. The search route only accepts a confident match
     * (exact title, backed by the year when the meta carries one), so
     * a namesake can never pull the wrong title's cast/recs onto the
     * page. Null when nothing resolves.
     */
    suspend fun resolveTarget(apiKey: String, meta: MetaDetail): TmdbTarget? =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext null
            val cacheKey = "${meta.id}|${meta.name}|${meta.releaseInfo}"
            targetCache[cacheKey]?.let { return@withContext it }
            val resolved = try {
                resolveTargetUncached(apiKey, meta)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (resolved != null) targetCache[cacheKey] = resolved
            resolved
        }

    private suspend fun resolveTargetUncached(apiKey: String, meta: MetaDetail): TmdbTarget? {
        if (meta.id.startsWith("tmdb:")) {
            val parts = meta.id.removePrefix("tmdb:").split(":")
            val numeric = parts.lastOrNull()?.toIntOrNull()
            if (numeric != null) {
                val t = when (parts.getOrNull(0)?.lowercase()) {
                    "movie" -> "movie"
                    "tv", "series" -> "tv"
                    else -> if (meta.type == "series") "tv" else "movie"
                }
                return TmdbTarget(numeric, t)
            }
        }
        val preferred = if (meta.type == "series") "tv" else "movie"
        val imdbId = meta.id.takeIf { it.startsWith("tt") }
            ?: meta.imdbId?.takeIf { it.startsWith("tt") }
        if (imdbId != null) {
            val findJson = json.parseToJsonElement(
                BoundedHttp.get(
                    authed("$BASE/find/$imdbId?api_key=$apiKey&external_source=imdb_id", apiKey),
                    headers = authHeaders(apiKey)
                )
            ).jsonObject
            val order = if (preferred == "tv") listOf("tv", "movie") else listOf("movie", "tv")
            for (t in order) {
                val hit = findJson["${t}_results"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("id")?.jsonPrimitive?.content?.toIntOrNull()
                if (hit != null) return TmdbTarget(hit, t)
            }
        }
        val title = meta.name.trim()
        if (title.length < 2) return null
        val year = meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull()
        val encoded = java.net.URLEncoder.encode(title, "UTF-8")
        val root = json.parseToJsonElement(
            BoundedHttp.get(
                authed("$BASE/search/multi?api_key=$apiKey&query=$encoded&page=1&include_adult=false", apiKey),
                headers = authHeaders(apiKey)
            )
        ).jsonObject
        val results = root["results"]?.jsonArray ?: return null
        var best: TmdbTarget? = null
        var bestScore = -1
        for (el in results) {
            val obj = el.jsonObject
            val mediaType = obj["media_type"]?.jsonPrimitive?.content ?: continue
            if (mediaType != "movie" && mediaType != "tv") continue
            val hitId = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
            val hitTitle = obj["title"]?.jsonPrimitive?.content
                ?: obj["name"]?.jsonPrimitive?.content ?: continue
            val dateStr = obj["release_date"]?.jsonPrimitive?.content
                ?: obj["first_air_date"]?.jsonPrimitive?.content
            val hitYear = dateStr?.take(4)?.toIntOrNull()
            val titleNorm = hitTitle.trim().lowercase()
            val queryNorm = title.lowercase()
            var score = 0
            if (titleNorm == queryNorm) score += 4
            else if (titleNorm.contains(queryNorm) || queryNorm.contains(titleNorm)) score += 1
            if (year != null && hitYear == year) score += 3
            else if (year != null && hitYear != null && kotlin.math.abs(hitYear - year) == 1) score += 1
            if (mediaType == preferred) score += 1
            if (score > bestScore) {
                bestScore = score
                best = TmdbTarget(hitId, mediaType)
            }
        }
        val confident = if (year != null) bestScore >= 7 else bestScore >= 4
        return if (confident) best else null
    }

    /**
     * "More like this" from TMDB (v0.14.16): recommendations + similar
     * for the resolved title, as app metas with `tmdb:` ids (the
     * detail-target resolver routes those exactly like the actor
     * filmography's). Self excluded, deduped across both endpoints,
     * recommendations first. Empty when the title doesn't resolve or
     * TMDB has nothing — the caller then keeps the addon fallback.
     */
    suspend fun moreLikeThis(apiKey: String, meta: MetaDetail): List<MetaPreview> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext emptyList()
            try {
                val target = resolveTarget(apiKey, meta) ?: return@withContext emptyList()
                val out = LinkedHashMap<Int, MetaPreview>()
                for (endpoint in listOf("recommendations", "similar")) {
                    val url = "$BASE/${target.tmdbType}/${target.tmdbId}/$endpoint" +
                        "?api_key=$apiKey&language=en-US&page=1"
                    val root = runCatching {
                        json.parseToJsonElement(
                            BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
                        ).jsonObject
                    }.getOrNull() ?: continue
                    val results = root["results"]?.jsonArray ?: continue
                    for (el in results) {
                        val obj = el.jsonObject
                        val rid = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
                        if (rid == target.tmdbId || out.containsKey(rid)) continue
                        val title = obj["title"]?.jsonPrimitive?.content
                            ?: obj["name"]?.jsonPrimitive?.content ?: continue
                        val dateStr = obj["release_date"]?.jsonPrimitive?.content
                            ?: obj["first_air_date"]?.jsonPrimitive?.content
                        val vote = obj["vote_average"]?.jsonPrimitive?.content?.toDoubleOrNull()
                        out[rid] = MetaPreview(
                            id = "tmdb:${target.tmdbType}:$rid",
                            type = if (target.tmdbType == "movie") "movie" else "series",
                            name = title,
                            poster = tmdbImage(str(obj, "poster_path"), "w342"),
                            background = tmdbImage(str(obj, "backdrop_path"), "w780"),
                            releaseInfo = dateStr?.take(4),
                            imdbRating = vote?.takeIf { it > 0 }?.let { "%.1f".format(it) },
                            originalLanguage = str(obj, "original_language")
                        )
                        if (out.size >= 20) break
                    }
                    if (out.size >= 20) break
                }
                out.values.toList()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
        }

    /**
     * TMDB Enrichment (v0.14.6): fills a MetaDetail's gaps from TMDB,
     * per-toggle. Only MISSING pieces are filled — the serving addon's
     * own data always wins. One details call (credits + images appended)
     * plus one season call per season for the Episodes toggle. Any
     * failure returns the meta untouched.
     */
    suspend fun enrichMeta(
        apiKey: String,
        meta: MetaDetail,
        toggles: EnrichToggles
    ): MetaDetail = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext meta
        try {
            // Resolution (v0.14.16): tmdb:/tt ids as before, PLUS the
            // title + year route for opaque addon ids (CNCVerse `cnc:`)
            // that used to skip enrichment entirely — no cast photos,
            // no details, nothing.
            val target = resolveTarget(apiKey, meta) ?: return@withContext meta
            val tmdbType = target.tmdbType
            val id = target.tmdbId

            val url = "$BASE/$tmdbType/$id?api_key=$apiKey" +
                "&append_to_response=credits,images,release_dates,content_ratings" +
                "&include_image_language=en,null"
            val root = json.parseToJsonElement(
                BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
            ).jsonObject

            var out = meta

            if (toggles.artwork) {
                val images = root["images"]?.jsonObject
                val logo = images?.get("logos")?.jsonArray?.firstOrNull()?.jsonObject
                    ?.let { str(it, "file_path") }
                val backdrop = str(root, "backdrop_path")
                    ?: images?.get("backdrops")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.let { str(it, "file_path") }
                out = out.copy(
                    logo = out.logo ?: tmdbImage(logo, "w500"),
                    background = out.background ?: tmdbImage(backdrop, "w1280")
                )
            }
            if (toggles.basicInfo) {
                val vote = root["vote_average"]?.jsonPrimitive?.content?.toDoubleOrNull()
                val genres = root["genres"]?.jsonArray?.mapNotNull {
                    str(it.jsonObject, "name")
                } ?: emptyList()
                out = out.copy(
                    description = out.description?.takeIf { it.isNotBlank() }
                        ?: str(root, "overview"),
                    genres = if (out.genres.isEmpty()) genres else out.genres,
                    imdbRating = out.imdbRating?.takeIf { it.isNotBlank() }
                        ?: vote?.takeIf { it > 0 }?.let { "%.1f".format(it) },
                    // The vote also stands on its own as the TMDB
                    // rating (v0.14.18): the detail ratings row labels
                    // each score with its own service.
                    tmdbRating = out.tmdbRating
                        ?: vote?.takeIf { it > 0 }?.let { "%.1f".format(it) }
                )
            }
            if (toggles.details) {
                val runtimeMin = root["runtime"]?.jsonPrimitive?.content?.toIntOrNull()
                    ?: root["episode_run_time"]?.jsonArray?.firstOrNull()
                        ?.jsonPrimitive?.content?.toIntOrNull()
                val dateStr = str(root, "release_date") ?: str(root, "first_air_date")
                val country = root["production_countries"]?.jsonArray?.firstOrNull()
                    ?.jsonObject?.let { str(it, "name") }
                val cert = if (tmdbType == "movie") {
                    root["release_dates"]?.jsonObject?.get("results")?.jsonArray
                        ?.firstOrNull { str(it.jsonObject, "iso_3166_1") == "US" }
                        ?.jsonObject?.get("release_dates")?.jsonArray?.firstOrNull()
                        ?.jsonObject?.let { str(it, "certification") }
                } else {
                    root["content_ratings"]?.jsonObject?.get("results")?.jsonArray
                        ?.firstOrNull { str(it.jsonObject, "iso_3166_1") == "US" }
                        ?.jsonObject?.let { str(it, "rating") }
                }
                out = out.copy(
                    runtime = out.runtime ?: runtimeMin?.let { formatRuntime(it) },
                    releaseInfo = out.releaseInfo?.takeIf { it.isNotBlank() }
                        ?: dateStr?.take(4),
                    country = out.country ?: country,
                    status = out.status ?: str(root, "status"),
                    certification = out.certification ?: cert
                )
            }
            if (toggles.credits) {
                val tmdbCast = root["credits"]?.jsonObject?.get("cast")?.jsonArray
                    ?.take(15)?.mapNotNull { el ->
                        val obj = el.jsonObject
                        val name = str(obj, "name") ?: return@mapNotNull null
                        CastMember(
                            id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0,
                            name = name,
                            photo = tmdbImage(str(obj, "profile_path"), "w185"),
                            character = str(obj, "character")
                        )
                    } ?: emptyList()
                if (tmdbCast.isNotEmpty()) {
                    out = out.copy(
                        cast = when {
                            out.cast.isEmpty() -> tmdbCast
                            out.cast.size < 5 -> tmdbCast
                            else -> out.cast.map { member ->
                                val match = tmdbCast.firstOrNull {
                                    it.name.equals(member.name, ignoreCase = true)
                                }
                                if (match != null) member.copy(
                                    id = if (member.id == 0) match.id else member.id,
                                    photo = member.photo ?: match.photo,
                                    character = member.character ?: match.character
                                ) else member
                            }
                        }
                    )
                }
                // Crew (v0.14.18): the same credits payload carries
                // the crew — Director and Writing names for the
                // detail page's crew lines. The addon's own values
                // always win.
                val directors = root["credits"]?.jsonObject?.get("crew")?.jsonArray
                    ?.mapNotNull { el ->
                        val obj = el.jsonObject
                        if (str(obj, "job") == "Director") str(obj, "name") else null
                    }?.distinct()?.take(2) ?: emptyList()
                val writers = root["credits"]?.jsonObject?.get("crew")?.jsonArray
                    ?.mapNotNull { el ->
                        val obj = el.jsonObject
                        when (str(obj, "job")) {
                            "Writer", "Screenplay", "Story", "Novel" -> str(obj, "name")
                            else -> null
                        }
                    }?.distinct()?.take(3) ?: emptyList()
                out = out.copy(
                    director = out.director
                        ?: directors.takeIf { it.isNotEmpty() }?.joinToString(", "),
                    writer = out.writer
                        ?: writers.takeIf { it.isNotEmpty() }?.joinToString(", ")
                )
            }
            if (toggles.productions) {
                val companies = root["production_companies"]?.jsonArray
                    ?.mapNotNull { str(it.jsonObject, "name") }?.take(3) ?: emptyList()
                if (companies.isNotEmpty() && out.production == null) {
                    out = out.copy(production = companies.joinToString(", "))
                }
            }
            if (toggles.networks) {
                val networks = root["networks"]?.jsonArray
                    ?.mapNotNull { str(it.jsonObject, "name") }?.take(2) ?: emptyList()
                if (networks.isNotEmpty() && out.network.isNullOrBlank()) {
                    out = out.copy(network = networks.joinToString(", "))
                }
            }
            if (toggles.episodes && meta.type == "series" && out.videos.isNotEmpty()) {
                val seasons = out.videos.map { it.season }.distinct().take(6)
                var videos = out.videos
                var seasonPosters = out.seasonPosters
                for (season in seasons) {
                    val seasonUrl = "$BASE/tv/$id/season/$season?api_key=$apiKey"
                    val seasonJson = runCatching {
                        json.parseToJsonElement(
                            BoundedHttp.get(
                                authed(seasonUrl, apiKey),
                                headers = authHeaders(apiKey)
                            )
                        ).jsonObject
                    }.getOrNull() ?: continue
                    // Season poster (v0.14.18): the season payload
                    // already carries one — the detail page's season
                    // cards use it instead of repeating the series
                    // poster for every season.
                    tmdbImage(str(seasonJson, "poster_path"), "w342")?.let { posterUrl ->
                        seasonPosters = seasonPosters + (season to posterUrl)
                    }
                    val eps = seasonJson["episodes"]?.jsonArray ?: continue
                    val byNumber = eps.mapNotNull { el ->
                        val obj = el.jsonObject
                        val number = obj["episode_number"]?.jsonPrimitive?.content
                            ?.toIntOrNull() ?: return@mapNotNull null
                        number to obj
                    }.toMap()
                    videos = videos.map { video ->
                        if (video.season != season) return@map video
                        val ep = byNumber[video.episode] ?: return@map video
                        val genericTitle = video.title.isBlank() ||
                            video.title.matches(Regex("(?i)episode\\s+\\d+"))
                        video.copy(
                            title = if (genericTitle) {
                                str(ep, "name") ?: video.title
                            } else video.title,
                            overview = video.overview?.takeIf { it.isNotBlank() }
                                ?: str(ep, "overview"),
                            thumbnail = video.thumbnail
                                ?: tmdbImage(str(ep, "still_path"), "w300")
                        )
                    }
                }
                out = out.copy(videos = videos, seasonPosters = seasonPosters)
            }
            out
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            meta
        }
    }

    /**
     * Attach [searchWithPopularity] signals to [search] previews
     * (v0.14.27 primary search lane). Matching is by normalised title
     * + type, with the year as a disambiguator when both sides know
     * it — the two calls return the same page, so a hit that cannot
     * be matched confidently is simply left unattached.
     */
    internal fun attachPopularity(
        previews: List<MetaPreview>,
        hits: List<TmdbSearchHit>
    ): List<MetaPreview> {
        if (previews.isEmpty() || hits.isEmpty()) return previews
        fun norm(raw: String): String =
            raw.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")
        return previews.map { preview ->
            val year = preview.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull()
            val hit = hits.firstOrNull { candidate ->
                candidate.type == preview.type &&
                    norm(candidate.title) == norm(preview.name) &&
                    (candidate.year == null || year == null || candidate.year == year)
            } ?: return@map preview
            preview.copy(
                popularity = maxOf(preview.popularity, hit.popularity),
                imdbRating = preview.imdbRating?.takeIf { it.isNotBlank() }
                    ?: hit.voteAverage.takeIf { it > 0 }?.let {
                        String.format(java.util.Locale.US, "%.1f", it)
                    },
                releaseInfo = preview.releaseInfo?.takeIf { it.isNotBlank() }
                    ?: hit.year?.toString()
            )
        }
    }

    suspend fun search(apiKey: String, query: String): List<MetaPreview> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || query.trim().length < 2) return@withContext emptyList()
        try {
            val encoded = java.net.URLEncoder.encode(query.trim(), "UTF-8")
            val url = "$BASE/search/multi?api_key=$apiKey&query=$encoded&page=1&include_adult=false"
            val response = BoundedHttp.get(authed(url, apiKey), headers = authHeaders(apiKey))
            val root = json.parseToJsonElement(response).jsonObject
            val results = root["results"]?.jsonArray ?: return@withContext emptyList()
            val out = mutableListOf<MetaPreview>()
            for (el in results.take(20)) {
                val obj = el.jsonObject
                val mediaType = obj["media_type"]?.jsonPrimitive?.content ?: continue
                if (mediaType != "movie" && mediaType != "tv") continue
                val id = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: continue
                val title = obj["title"]?.jsonPrimitive?.content
                    ?: obj["name"]?.jsonPrimitive?.content ?: continue
                val poster = obj["poster_path"]?.jsonPrimitive?.content
                val posterUrl = if (poster != null) "https://image.tmdb.org/t/p/w342$poster" else null
                val backdrop = obj["backdrop_path"]?.jsonPrimitive?.content
                val backdropUrl = if (backdrop != null) "https://image.tmdb.org/t/p/w780$backdrop" else null
                val dateStr = obj["release_date"]?.jsonPrimitive?.content
                    ?: obj["first_air_date"]?.jsonPrimitive?.content
                val vote = obj["vote_average"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: 0.0
                val type = if (mediaType == "movie") "movie" else "series"
                out.add(
                    MetaPreview(
                        id = "tmdb:$mediaType:$id", type = type, name = title,
                        poster = posterUrl, background = backdropUrl,
                        description = obj["overview"]?.jsonPrimitive?.content,
                        releaseInfo = dateStr?.take(4)?.takeIf { it.length == 4 },
                        imdbRating = vote.takeIf { it > 0 }?.let {
                            String.format(java.util.Locale.US, "%.1f", it)
                        },
                        popularity = obj["popularity"]?.jsonPrimitive?.content
                            ?.toDoubleOrNull() ?: 0.0,
                        originalLanguage = obj["original_language"]?.jsonPrimitive?.content
                    )
                )
            }
            out
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { emptyList() }
    }

    // ------------------------------------------------------------------
    // Franchise collections (v0.14.38, item 8): the movie's TMDB
    // collection (belongs_to_collection) and its parts in release
    // order, for the Details-page collection row. Movies only — a
    // movie with no collection simply gets no row.
    // ------------------------------------------------------------------

    data class CollectionPart(
        val tmdbId: Int,
        val imdbId: String?,
        val title: String,
        val releaseDate: String?,
        val posterUrl: String?
    ) {
        val year: String? get() = releaseDate?.take(4)?.takeIf { it.length == 4 }
    }

    data class MovieCollection(
        val id: Int,
        val name: String,
        val parts: List<CollectionPart>
    )

    /**
     * Pure parse of a /collection/{id} response: parts in release
     * order (undated last, stable), poster URLs resolved. IMDb ids
     * are NOT in this payload — [movieCollection] enriches them.
     * Unit-tested.
     */
    internal fun parseCollection(raw: String): MovieCollection? {
        val root = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: return null
        val id = root["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: return null
        val name = root["name"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() } ?: return null
        val partsArr = root["parts"]?.jsonArray ?: return null
        val parts = partsArr.mapNotNull { el ->
            val obj = el.jsonObject
            val partId = obj["id"]?.jsonPrimitive?.content?.toIntOrNull() ?: return@mapNotNull null
            val title = obj["title"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            // contentOrNull, not content: for a JSON null, content
            // returns the literal string "null", which would turn a
            // missing date/poster into a bogus value.
            val date = obj["release_date"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            val poster = obj["poster_path"]?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w342$it" }
            CollectionPart(partId, null, title, date, poster)
        }
        if (parts.size < 2) return null
        val sorted = parts.sortedWith(compareBy({ it.releaseDate ?: "9999" }, { it.title }))
        return MovieCollection(id, name, sorted)
    }

    /**
     * Converts a collection served INSIDE the meta (PlavioMeta
     * v2.4.9, v0.14.40 item 9) into this client's shape, so the
     * Details collection row renders identically whichever lane
     * supplied it. Parts arrive in release order already; poster
     * paths get the same w342 CDN prefix [parseCollection] uses.
     */
    fun fromMetaCollection(collection: MetaCollection): MovieCollection =
        MovieCollection(
            id = collection.id,
            name = collection.name,
            parts = collection.parts.map { part ->
                CollectionPart(
                    tmdbId = part.tmdbId,
                    imdbId = part.imdbId,
                    title = part.title,
                    releaseDate = part.releaseDate,
                    posterUrl = part.posterPath?.let { "https://image.tmdb.org/t/p/w342$it" }
                )
            }
        )

    /** The TMDB collection for a movie id (Stremio/IMDb or tmdb: id), or null. */
    suspend fun movieCollection(apiKey: String, stremioId: String): MovieCollection? =
        withContext(Dispatchers.IO) {
            try {
                val tmdbId: Int? = if (stremioId.startsWith("tmdb:")) {
                    stremioId.removePrefix("tmdb:").substringAfterLast(":").toIntOrNull()
                } else {
                    val findUrl = "$BASE/find/$stremioId?api_key=<redacted>&external_source=imdb_id"
                    val findResponse = BoundedHttp.get(authed(findUrl, apiKey), headers = authHeaders(apiKey))
                    val findJson = json.parseToJsonElement(findResponse).jsonObject
                    findJson["movie_results"]?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("id")?.jsonPrimitive?.content?.toIntOrNull()
                }
                val movieId = tmdbId ?: return@withContext null
                val movieUrl = "$BASE/movie/$movieId?api_key=<redacted>"
                val movieJson = json.parseToJsonElement(
                    BoundedHttp.get(authed(movieUrl, apiKey), headers = authHeaders(apiKey))
                ).jsonObject
                val collectionId = movieJson["belongs_to_collection"]?.jsonObject
                    ?.get("id")?.jsonPrimitive?.content?.toIntOrNull()
                    ?: return@withContext null
                val collectionUrl = "$BASE/collection/$collectionId?api_key=<redacted>"
                val parsed = parseCollection(
                    BoundedHttp.get(authed(collectionUrl, apiKey), headers = authHeaders(apiKey))
                ) ?: return@withContext null
                // Enrich IMDb ids (watched/progress matching + opening
                // each part through the meta addons). Best-effort per
                // part: a failed lookup keeps the tmdb: id route.
                val enriched = parsed.parts.take(24).map { part ->
                    val imdb = runCatching {
                        val extUrl = "$BASE/movie/${part.tmdbId}/external_ids?api_key=<redacted>"
                        val extJson = json.parseToJsonElement(
                            BoundedHttp.get(authed(extUrl, apiKey), headers = authHeaders(apiKey))
                        ).jsonObject
                        extJson["imdb_id"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                    }.getOrNull()
                    if (imdb != null) part.copy(imdbId = imdb) else part
                }
                parsed.copy(parts = enriched)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { null }
        }
}
