package com.pulsestream.app.data

import android.content.Context
import com.pulsestream.app.data.notifications.EpisodeNotifyStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * One upcoming (not yet aired) episode of a series the user
 * follows — the next unaired episode of that series, built from
 * the serving meta's own episode release dates (generic meta
 * data, any addon). This is the v0.14.11 "Upcoming" list: it
 * lived inside the Library (a section in the on-device view
 * plus a dedicated view behind a button in the Plavio view)
 * until v0.14.38 folded it into the Up Next screen; v0.14.40
 * (owner's verdict, 2026-11-13) RESTORES the stable Library
 * surfaces and removes Up Next. The scan keeps the stable
 * rules and gains the owner's speed fixes: the last computed
 * list persists on disk and paints instantly on open, a rescan
 * is seeded with the shown entries so the list never visibly
 * shrinks while it refreshes, publishing stays incremental,
 * and the candidate union adds the Detail-page bell
 * subscriptions ([EpisodeNotifyStore.subscribed]) so a
 * bell-pressed series shows here with its date — the exact
 * behaviour the owner asked for.
 */
data class UpcomingEntry(
    val addonId: String,
    val metaId: String,
    val showName: String,
    val poster: String?,
    val season: Int,
    val episode: Int,
    val episodeTitle: String?,
    val airDate: LocalDate,
    val badge: String
)

object UpcomingSupport {

    /** One episode's air-date fact, the scan's unit of work. */
    data class EpDate(
        val season: Int,
        val episode: Int,
        val title: String?,
        val date: LocalDate
    )

    /** The day badge the Library has always shown (v0.14.11 rules). */
    fun badgeFor(today: LocalDate, date: LocalDate): String {
        val days = ChronoUnit.DAYS.between(today, date)
        return when {
            days == 1L -> "Tomorrow"
            days in 2..7 -> date.format(
                DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH)
            )
            else -> "in $days days"
        }
    }

    /** The soonest episode airing strictly after [today], or null. */
    fun pickNextEpisode(episodes: List<EpDate>, today: LocalDate): EpDate? =
        episodes.filter { it.date.isAfter(today) }.minByOrNull { it.date }

    /** Parse a meta video's `released` string into a date (null when unusable). */
    fun airDateOf(released: String?): LocalDate? {
        val raw = released?.take(10)?.takeIf { it.isNotBlank() } ?: return null
        return runCatching { LocalDate.parse(raw) }.getOrNull()
    }

    /** One series the scan will resolve: where it came from rides along. */
    private data class Candidate(
        val addonId: String,
        val metaId: String,
        val name: String
    )

    /**
     * The scan's candidate union: the followed-series union from
     * [StreamRepository.followedSeries] (on-device watchlist +
     * Trakt + Simkl, deduped by IMDb id) PLUS every series with
     * an explicit bell ON in [EpisodeNotifyStore] — the restore
     * rule the owner asked for ("press the bell and it shows in
     * the list"). Series only, `tt` ids only, capped at 30 like
     * the stable scan.
     */
    private suspend fun buildCandidates(
        repository: StreamRepository,
        context: Context
    ): List<Candidate> {
        val seen = LinkedHashMap<String, Candidate>()
        runCatching { repository.followedSeries() }
            .getOrDefault(emptyList())
            .filter { it.metaId.startsWith("tt") }
            .forEach { followed ->
                if (followed.metaId !in seen) {
                    seen[followed.metaId] =
                        Candidate(followed.addonId, followed.metaId, followed.name)
                }
            }
        runCatching { EpisodeNotifyStore(context).subscribed() }
            .getOrDefault(emptyMap())
            .forEach { (metaId, name) ->
                if (metaId.startsWith("tt") && metaId !in seen) {
                    seen[metaId] = Candidate("", metaId, name ?: "")
                }
            }
        return seen.values.take(30)
    }

    /**
     * The full Upcoming scan, restored v0.14.40 shape: each meta
     * through the repository's cache funnel (24 h disk meta
     * cache underneath), four lookups at a time, one entry per
     * series (its next unaired episode), soonest first.
     *
     * Progressive rules (the owner's speed fix):
     *  - [seed] is what is already on screen (the snapshot or
     *    the disk-persisted list). The working set starts from
     *    it, so the visible list NEVER shrinks while the scan
     *    runs: a series keeps its seeded row until its fresh
     *    meta lands — a failed lookup keeps the seeded row, a
     *    resolved series replaces its row (or drops it when it
     *    has no future episode left).
     *  - [onPublish] fires on EVERY resolution with the merged,
     *    sorted list — the section fills progressively.
     *  - Only the FINAL publish prunes rows whose series left
     *    the candidate union (unfollowed / bell removed).
     *  - The final list is persisted to disk for the next cold
     *    open ([loadPersisted]).
     */
    suspend fun scanUpcoming(
        repository: StreamRepository,
        context: Context,
        seed: List<UpcomingEntry>,
        onPublish: (List<UpcomingEntry>) -> Unit
    ): List<UpcomingEntry> {
        val today = LocalDate.now()
        val candidates = buildCandidates(repository, context)
        val candidateIds = candidates.map { it.metaId }.toSet()
        val working = LinkedHashMap<String, UpcomingEntry>()
        seed.filter { it.airDate.isAfter(today) }
            .forEach { working[it.metaId] = it.copy(badge = badgeFor(today, it.airDate)) }
        val publishLock = Any()
        fun publish(final: Boolean): List<UpcomingEntry> {
            val list = working.values
                .filter { !final || it.metaId in candidateIds }
                .sortedBy { it.airDate }
            onPublish(list)
            return list
        }
        if (candidates.isEmpty()) {
            val finalList = synchronized(publishLock) { publish(final = true) }
            savePersisted(context, finalList)
            return finalList
        }
        coroutineScope {
            val gate = Semaphore(4)
            candidates.map { cand ->
                async {
                    gate.withPermit {
                        val meta = runCatching {
                            repository.getMetaFromAny(
                                cand.addonId.takeIf { it.isNotBlank() },
                                "series",
                                cand.metaId
                            )
                        }.getOrNull() ?: return@withPermit
                        val episodes = meta.videos.mapNotNull { video ->
                            val date = airDateOf(video.released) ?: return@mapNotNull null
                            EpDate(
                                season = video.season,
                                episode = video.episode,
                                title = video.title.takeIf { it.isNotBlank() },
                                date = date
                            )
                        }
                        val next = pickNextEpisode(episodes, today)
                        synchronized(publishLock) {
                            if (next == null) {
                                working.remove(cand.metaId)
                            } else {
                                working[cand.metaId] = UpcomingEntry(
                                    addonId = cand.addonId,
                                    metaId = cand.metaId,
                                    showName = cand.name.ifBlank { meta.name },
                                    poster = meta.poster,
                                    season = next.season,
                                    episode = next.episode,
                                    episodeTitle = next.title,
                                    airDate = next.date,
                                    badge = badgeFor(today, next.date)
                                )
                            }
                            publish(final = false)
                        }
                    }
                }
            }.awaitAll()
        }
        val finalList = synchronized(publishLock) { publish(final = true) }
        savePersisted(context, finalList)
        return finalList
    }

    // ---------------------------------------------------------------
    // Disk persistence (the cold-open paint): the last computed
    // list as a small JSON file next to the app's other on-device
    // caches. Badges are NOT stored — they are recomputed against
    // today on load, and entries whose date has passed are
    // dropped, so a painted row is never a stale one.
    // ---------------------------------------------------------------

    private const val PERSIST_FILE = "upcoming_entries.json"

    private fun persistFile(context: Context): File =
        File(context.applicationContext.filesDir, PERSIST_FILE)

    /** The persisted list, display-ready (fresh badges, no past dates). */
    fun loadPersisted(context: Context): List<UpcomingEntry> {
        val today = LocalDate.now()
        return runCatching {
            val file = persistFile(context)
            if (!file.isFile) return emptyList()
            val rows = JSONArray(file.readText())
            val out = ArrayList<UpcomingEntry>(rows.length())
            for (i in 0 until rows.length()) {
                val obj = rows.optJSONObject(i) ?: continue
                val metaId = obj.optString("metaId").takeIf { it.isNotBlank() } ?: continue
                val date = runCatching { LocalDate.parse(obj.optString("airDate")) }
                    .getOrNull() ?: continue
                if (!date.isAfter(today)) continue
                out += UpcomingEntry(
                    addonId = obj.optString("addonId"),
                    metaId = metaId,
                    showName = obj.optString("showName"),
                    poster = obj.optString("poster").takeIf { it.isNotBlank() },
                    season = obj.optInt("season"),
                    episode = obj.optInt("episode"),
                    episodeTitle = obj.optString("episodeTitle").takeIf { it.isNotBlank() },
                    airDate = date,
                    badge = badgeFor(today, date)
                )
            }
            out.sortedBy { it.airDate }
        }.getOrDefault(emptyList())
    }

    /** Persist the final list (best-effort; a failed write costs nothing). */
    suspend fun savePersisted(context: Context, entries: List<UpcomingEntry>) {
        withContext(Dispatchers.IO) {
            runCatching {
                val rows = JSONArray()
                entries.forEach { entry ->
                    rows.put(
                        JSONObject()
                            .put("addonId", entry.addonId)
                            .put("metaId", entry.metaId)
                            .put("showName", entry.showName)
                            .put("poster", entry.poster ?: JSONObject.NULL)
                            .put("season", entry.season)
                            .put("episode", entry.episode)
                            .put("episodeTitle", entry.episodeTitle ?: JSONObject.NULL)
                            .put("airDate", entry.airDate.toString())
                    )
                }
                persistFile(context).writeText(rows.toString())
            }
        }
    }
}
