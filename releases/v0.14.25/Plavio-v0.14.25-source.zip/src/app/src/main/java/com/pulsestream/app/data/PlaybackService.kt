package com.pulsestream.app.data

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.pulsestream.app.MainActivity
import com.pulsestream.app.R

/**
 * Foreground playback service + media session (v0.14.13, item 6).
 *
 * Wraps the player PlayerScreen is already running (see
 * [PlaybackBridge]): the service owns NO player — it mirrors the
 * bridged one into a framework [MediaSession] and a lock-screen /
 * notification card with play/pause, seek and (in a series)
 * next-episode actions, and its foreground status + the player's
 * wake mode keep audio going when the app is backgrounded or the
 * screen turns off. PlayerScreen's ON_PAUSE handler skips its
 * pause-on-background while [PlaybackBridge.sessionActive] is set,
 * which is what makes background audio possible without touching
 * the player's own lifecycle, hard-cut swaps or resume arming.
 *
 * Framework session classes are used (no extra dependency): the
 * media3 session artifact isn't in the offline catalog.
 */
class PlaybackService : Service() {

    companion object {
        private const val CHANNEL_ID = "playback"
        private const val NOTIFICATION_ID = 4242
        private const val ACTION_TOGGLE = "com.pulsestream.app.playback.TOGGLE"
        private const val ACTION_NEXT = "com.pulsestream.app.playback.NEXT"

        fun start(context: Context) {
            val intent = Intent(context, PlaybackService::class.java)
            // PLAVIO-Z (v0.14.16): startForegroundService itself
            // throws ForegroundServiceStartNotAllowedException when
            // Android's background-start rules refuse — seen when an
            // episode direct-play fires this from a composition
            // effect mid activity transition, before the process
            // counts as foreground-eligible. The refusal degrades
            // to no service for this play (playback stays
            // in-activity; the next player rebuild retries the
            // start) — it must never crash the app.
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PlaybackService::class.java))
        }
    }

    private var session: MediaSession? = null
    private var attachedPlayer: ExoPlayer? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()
        override fun onPlaybackStateChanged(playbackState: Int) = refresh()
        override fun onMediaItemTransition(
            mediaItem: androidx.media3.common.MediaItem?,
            reason: Int
        ) = refresh()
    }

    private val bridgeListener: (ExoPlayer?) -> Unit = { newPlayer ->
        attachedPlayer?.removeListener(playerListener)
        attachedPlayer = newPlayer
        attachedPlayer?.addListener(playerListener)
        refresh()
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        // PLAVIO-1D (v0.14.28): promote to foreground FIRST, before
        // any session wiring. startForegroundService() opens a short
        // window in which startForeground() must be called; on
        // 0.14.23 the MediaSession/PendingIntent setup ran first, so
        // on a busy main thread (player + FFmpeg spin-up during an
        // activity transition) the promotion could land after the
        // window closed and Android killed the process with
        // ForegroundServiceDidNotStartInTimeException — the timeout
        // sibling of the PLAVIO-P/Z refusal family the v0.14.16 fix
        // covered. The starter notification is refreshed with the
        // full session styling by refresh() once wiring completes.
        if (!startForegroundCompat(buildNotification())) {
            // Android refused the promotion outright (see the
            // PLAVIO-P degrade below): never linger half-alive.
            stopSelf()
            return
        }
        val s = MediaSession(this, "PlavioPlayback")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() {
                PlaybackBridge.player?.play()
            }

            override fun onPause() {
                PlaybackBridge.player?.pause()
            }

            override fun onSeekTo(pos: Long) {
                PlaybackBridge.player?.seekTo(pos)
            }

            override fun onSkipToNext() {
                PlaybackBridge.playNext()
            }

            override fun onStop() {
                PlaybackBridge.player?.pause()
            }
        })
        s.setSessionActivity(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        session = s
        PlaybackBridge.sessionActive = true
        PlaybackBridge.setListener(bridgeListener)
        // Promotion already happened at the top of onCreate
        // (PLAVIO-1D); refresh() now swaps the starter notification
        // for the full session-styled one and publishes state.
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // PLAVIO-1D (v0.14.28): EVERY startForegroundService() call
        // opens a fresh promotion window — including repeat starts
        // on this already-running service (PlayerScreen re-starts
        // the service on each player rebuild). onStartCommand is
        // where that call lands, so re-assert the promotion here,
        // first thing: a manager.notify() from refresh() does NOT
        // satisfy the foreground contract, and a busy main thread
        // delaying this callback past the window is exactly how
        // 0.14.23 died with ForegroundServiceDidNotStartInTime.
        // Guarded like every other promotion call — a refusal here
        // must not kill the notification actions below.
        startForegroundCompat(buildNotification())
        when (intent?.action) {
            ACTION_TOGGLE -> {
                val p = PlaybackBridge.player
                if (p != null) {
                    if (p.isPlaying) p.pause() else p.play()
                }
            }
            ACTION_NEXT -> PlaybackBridge.playNext()
        }
        refresh()
        return START_STICKY
    }

    override fun onDestroy() {
        PlaybackBridge.sessionActive = false
        PlaybackBridge.setListener(null)
        attachedPlayer?.removeListener(playerListener)
        attachedPlayer = null
        session?.release()
        session = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, "Playback", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Now playing controls" }
        )
    }

    /**
     * Promote to foreground; returns false when Android refuses.
     *
     * PLAVIO-P (v0.14.16): the old shape ran the typed call under
     * runCatching but left the getOrElse fallback UNGUARDED — when
     * the typed call was refused with
     * ForegroundServiceStartNotAllowedException, the plain fallback
     * threw the same exception straight out of onCreate and the
     * framework wrapped it as RuntimeException "Unable to create
     * service". Both calls now sit under runCatching and the
     * caller degrades instead of dying.
     */
    private fun startForegroundCompat(notification: Notification): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val typed = runCatching {
                startForeground(
                    NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            }.isSuccess
            if (typed) return true
        }
        return runCatching { startForeground(NOTIFICATION_ID, notification) }.isSuccess
    }

    /** Push the bridged player's state into the session + notification. */
    private fun refresh() {
        val s = session ?: return
        val p = PlaybackBridge.player
        val state = when {
            p == null -> PlaybackState.STATE_NONE
            p.playbackState == Player.STATE_BUFFERING -> PlaybackState.STATE_BUFFERING
            p.playbackState == Player.STATE_ENDED -> PlaybackState.STATE_STOPPED
            p.isPlaying -> PlaybackState.STATE_PLAYING
            else -> PlaybackState.STATE_PAUSED
        }
        var actions = PlaybackState.ACTION_PLAY or
            PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SEEK_TO
        if (PlaybackBridge.hasNext) actions = actions or PlaybackState.ACTION_SKIP_TO_NEXT
        s.setPlaybackState(
            PlaybackState.Builder()
                .setState(state, p?.currentPosition?.coerceAtLeast(0) ?: 0L, 1f)
                .setActions(actions)
                .build()
        )
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, PlaybackBridge.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, PlaybackBridge.subtitle)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "Plavio")
                .putLong(
                    MediaMetadata.METADATA_KEY_DURATION,
                    p?.duration?.takeIf { it > 0 } ?: 0L
                )
                .build()
        )
        s.isActive = p != null
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val p = PlaybackBridge.player
        val playing = p?.isPlaying == true
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, PlaybackService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nextIntent = PendingIntent.getService(
            this, 2,
            Intent(this, PlaybackService::class.java).setAction(ACTION_NEXT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val style = Notification.MediaStyle()
            .setMediaSession(session?.sessionToken)
            .setShowActionsInCompactView(0)
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_pulse_logo)
            .setContentTitle(PlaybackBridge.title.ifBlank { "Plavio" })
            .setContentText(PlaybackBridge.subtitle)
            .setStyle(style)
            .setOngoing(playing)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    },
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .addAction(
                Notification.Action.Builder(
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    if (playing) "Pause" else "Play",
                    toggleIntent
                ).build()
            )
        if (PlaybackBridge.hasNext) {
            builder.addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_media_next, "Next episode", nextIntent
                ).build()
            )
        }
        return builder.build()
    }
}
