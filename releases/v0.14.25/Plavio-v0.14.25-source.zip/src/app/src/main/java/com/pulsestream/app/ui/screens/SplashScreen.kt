package com.pulsestream.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsestream.app.R
import com.pulsestream.app.ui.theme.LocalPalette
import kotlinx.coroutines.delay

/**
 * Launch splash — the big-brand way (v0.14.40, item 12; owner's
 * order 2026-11-13, corrected the same morning after he watched
 * the preview: "No icon, only plavio wordings with Play button in
 * O. And your streaming universe.").
 *
 * The composition is SETTLED from the very first frame — no video,
 * no poster, no black or half-built frames: the PLAVIO signature
 * wordmark WITH the play triangle in the O (the Plavio Web
 * derivative, `plavio_web_logo`) centred on the flat (3,3,3)
 * background, the tagline "Your streaming universe" fading in
 * beneath it, and a loader under the tagline for the whole
 * splash. There is NO Weave mark anywhere in the splash — the
 * owner's correction removed it from both this drawn splash and
 * the system splash (Theme.PulseStream.Splash: the flat
 * background with NO icon since v0.14.41).
 *
 * v0.14.41 (owner's amendment, 2026-11-13): the loader is no
 * longer the circular OrbitDots — it is CONNECTING DOTS, a
 * horizontal row of dots under the tagline that join up one by
 * one (a line grows from dot to dot in sequence, then the
 * sequence loops), in the SAME colour the orbit dots used: the
 * palette accent. Everything else is exactly the .40 splash.
 *
 * The old ExoPlayer HUG clip is retired from the mobile launch:
 * its asset (res/raw/splash_g_orbit_build.mp4) stays in the tree
 * untouched for any other use, and the wait-state poster no
 * longer exists in this flow at all.
 *
 * Exit rule (unchanged from the clip era): the splash leaves
 * only when BOTH hold — 3 seconds have elapsed since splash
 * start and the home feed is ready; the caller keeps the 8s
 * safety cap so a dead network can't trap the splash.
 */
@Composable
fun SplashScreen(feedReady: Boolean, onDone: () -> Unit) {
    var minTimeDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(3000)
        minTimeDone = true
    }
    LaunchedEffect(minTimeDone, feedReady) {
        if (minTimeDone && feedReady) onDone()
    }

    // Tagline fade: starts invisible, fades in over ~0.8s once
    // the wordmark has had its beat (~0.5s in).
    val taglineAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(500)
        taglineAlpha.animateTo(1f, animationSpec = tween(durationMillis = 800))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF030303))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-24).dp)
                .fillMaxWidth()
        ) {
            // The wordmark alone, settled from frame one: 65% of
            // the screen width, centred at the seat the settled
            // clip frame used (the column's slight upward offset
            // keeps the whole stack optically centred).
            Image(
                painter = painterResource(R.drawable.plavio_web_logo),
                contentDescription = "PLAVIO",
                modifier = Modifier.fillMaxWidth(0.65f)
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = "Your streaming universe",
                style = MaterialTheme.typography.bodyLarge,
                fontSize = 16.sp,
                letterSpacing = 1.5.sp,
                color = Color(0xFFC9C9D4),
                modifier = Modifier.alpha(taglineAlpha.value)
            )
            Spacer(Modifier.height(26.dp))
            ConnectingDots(modifier = Modifier.width(96.dp).height(16.dp))
        }
    }
}

/** How many dots the splash's connecting row carries. */
private const val CONNECTING_DOT_COUNT = 4

/**
 * Connecting dots (v0.14.41 — owner's amendment): a horizontal
 * row of dots that connect to each other one by one — a line
 * grows from the first dot to the second, the reached dot
 * lights, the line grows on to the next, and when the row is
 * complete the sequence rests, fades and loops. The colour is
 * exactly the OrbitDots colour it replaces — the palette
 * accent, with the same soft glow (accent at 0.28) around a lit
 * dot that the orbit's head dot carried. Reduced motion shows
 * the completed row, static.
 */
@Composable
private fun ConnectingDots(modifier: Modifier = Modifier) {
    val palette = LocalPalette.current
    val reduced = com.pulsestream.app.data.rememberReducedMotion()
    val color = palette.accent
    var progress by remember { mutableFloatStateOf(0f) }
    var fade by remember { mutableFloatStateOf(1f) }
    LaunchedEffect(reduced) {
        if (reduced) {
            progress = (CONNECTING_DOT_COUNT - 1).toFloat()
            fade = 1f
            return@LaunchedEffect
        }
        while (true) {
            val grow = Animatable(0f)
            grow.animateTo(
                (CONNECTING_DOT_COUNT - 1).toFloat(),
                animationSpec = tween(durationMillis = 1500, easing = LinearEasing)
            ) { progress = value }
            delay(600)
            val fadeOut = Animatable(1f)
            fadeOut.animateTo(
                0f,
                animationSpec = tween(durationMillis = 300)
            ) { fade = value }
            progress = 0f
            fade = 1f
        }
    }
    Canvas(modifier.graphicsLayer { alpha = fade }) {
        val cy = size.height / 2f
        val dotR = 3.2.dp.toPx()
        val startX = dotR * 2f
        val step = (size.width - startX * 2) / (CONNECTING_DOT_COUNT - 1)
        val lineWidth = 2.dp.toPx()
        // The faint full track, then the grown line over it.
        drawLine(
            color.copy(alpha = 0.18f),
            Offset(startX, cy),
            Offset(startX + step * (CONNECTING_DOT_COUNT - 1), cy),
            strokeWidth = lineWidth
        )
        for (i in 0 until CONNECTING_DOT_COUNT - 1) {
            val fraction = (progress - i).coerceIn(0f, 1f)
            if (fraction > 0f) {
                drawLine(
                    color,
                    Offset(startX + step * i, cy),
                    Offset(startX + step * (i + fraction), cy),
                    strokeWidth = lineWidth
                )
            }
        }
        for (i in 0 until CONNECTING_DOT_COUNT) {
            val center = Offset(startX + step * i, cy)
            if (progress >= i.toFloat()) {
                drawCircle(color.copy(alpha = 0.28f), radius = dotR * 1.9f, center = center)
                drawCircle(color, radius = dotR, center = center)
            } else {
                drawCircle(color.copy(alpha = 0.30f), radius = dotR, center = center)
            }
        }
    }
}
