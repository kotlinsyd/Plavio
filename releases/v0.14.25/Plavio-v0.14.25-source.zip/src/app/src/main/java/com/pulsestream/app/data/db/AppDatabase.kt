package com.pulsestream.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        InstalledAddon::class,
        PlaybackState::class,
        CatalogCache::class,
        WatchlistItem::class,
        SubtitleCache::class,
        DownloadItem::class,
        CustomList::class,
        CustomListItem::class,
        WatchedRecord::class,
        FavoriteItem::class,
        TitleStatusItem::class,
        MetaCacheEntry::class,
        ProfileRow::class
    ],
    version = 19,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun addonDao(): AddonDao
    abstract fun playbackDao(): PlaybackDao
    abstract fun catalogCacheDao(): CatalogCacheDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun subtitleCacheDao(): SubtitleCacheDao
    abstract fun downloadDao(): DownloadDao
    abstract fun customListDao(): CustomListDao
    abstract fun watchedDao(): WatchedDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun titleStatusDao(): TitleStatusDao
    abstract fun metaCacheDao(): MetaCacheDao
    abstract fun profileDao(): ProfileDao
}

/**
 * v1 → v2: add the `resources` column to the addons table so each addon
 * remembers which Stremio resources it provides (catalog / meta / stream).
 * v0.1.0 only accepted full addons, so the default is correct for existing rows.
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "ALTER TABLE addons ADD COLUMN resources TEXT NOT NULL DEFAULT 'catalog,meta,stream'"
        )
    }
}

/**
 * v2 → v3: new tables for catalog caching, the watchlist, and subtitle
 * search caching; a `preinstalled` flag on addons; IMDb/season/episode
 * columns on playback rows so Continue Watching keeps full context.
 */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS catalog_cache (
                `key` TEXT NOT NULL PRIMARY KEY,
                addonId TEXT NOT NULL,
                addonName TEXT NOT NULL,
                baseUrl TEXT NOT NULL,
                type TEXT NOT NULL,
                catalogId TEXT NOT NULL,
                catalogName TEXT NOT NULL,
                itemsJson TEXT NOT NULL,
                fetchedAt INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS watchlist (
                `key` TEXT NOT NULL PRIMARY KEY,
                addonId TEXT NOT NULL,
                type TEXT NOT NULL,
                metaId TEXT NOT NULL,
                name TEXT NOT NULL,
                poster TEXT,
                addedAt INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS subtitle_cache (
                `key` TEXT NOT NULL PRIMARY KEY,
                itemsJson TEXT NOT NULL,
                fetchedAt INTEGER NOT NULL
            )"""
        )
        db.execSQL("ALTER TABLE addons ADD COLUMN preinstalled INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE playback ADD COLUMN imdbId TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN season INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE playback ADD COLUMN episode INTEGER NOT NULL DEFAULT 0")
    }
}

/**
 * v3 → v4: per-addon `enabled` flag (user on/off switch) and `configurable`
 * flag (manifest behaviorHints — the addon ships a web configure page).
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE addons ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE addons ADD COLUMN configurable INTEGER NOT NULL DEFAULT 0")
    }
}

/**
 * v4 → v5: per-addon `showOnHome` flag — controls whether the addon's
 * catalogs appear on the Home screen (Settings > Home Catalogs).
 */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE addons ADD COLUMN showOnHome INTEGER NOT NULL DEFAULT 1")
    }
}

/**
 * v5 → v6: `logoUrl` on addons — the manifest logo, shown as the addon
 * icon in the redesigned Addons tab.
 */
val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE addons ADD COLUMN logoUrl TEXT NOT NULL DEFAULT ''")
    }
}

/**
 * v6 → v7: `sortOrder` (user-rearranged addon order) and `starred`
 * (priority addon flag) on addons.
 */
val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE addons ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE addons ADD COLUMN starred INTEGER NOT NULL DEFAULT 0")
    }
}

/**
 * v7 → v8: new `downloads` table for the offline downloader.
 */
val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS downloads (
                id TEXT NOT NULL PRIMARY KEY,
                url TEXT NOT NULL,
                title TEXT NOT NULL,
                fileName TEXT NOT NULL,
                filePath TEXT NOT NULL,
                totalBytes INTEGER NOT NULL DEFAULT -1,
                downloadedBytes INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'QUEUED',
                error TEXT,
                headersJson TEXT NOT NULL DEFAULT '{}',
                createdAt INTEGER NOT NULL,
                completedAt INTEGER
            )"""
        )
    }
}

/** Creates Room's exact custom-list schema and copies any recoverable legacy rows. */
private fun rebuildCustomListTables(db: SupportSQLiteDatabase) {
    fun columns(table: String): Set<String> {
        if (db.query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'").use { it.count == 0 }) return emptySet()
        return db.query("PRAGMA table_info(`$table`)").use { cursor ->
            buildSet { while (cursor.moveToNext()) add(cursor.getString(cursor.getColumnIndexOrThrow("name"))) }
        }
    }
    fun copyTable(table: String, required: List<String>, defaults: Map<String, String>) {
        val existing = columns(table)
        val backup = "${table}_migration_backup"
        db.execSQL("DROP TABLE IF EXISTS `$backup`")
        if (existing.isNotEmpty()) db.execSQL("ALTER TABLE `$table` RENAME TO `$backup`")
        when (table) {
            "custom_lists" -> db.execSQL("CREATE TABLE `custom_lists` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))")
            "custom_list_items" -> db.execSQL("CREATE TABLE `custom_list_items` (`listId` TEXT NOT NULL, `itemKey` TEXT NOT NULL, `addonId` TEXT NOT NULL, `type` TEXT NOT NULL, `metaId` TEXT NOT NULL, `name` TEXT NOT NULL, `poster` TEXT, `addedAt` INTEGER NOT NULL, PRIMARY KEY(`listId`, `itemKey`))")
        }
        if (existing.isNotEmpty()) {
            val usable = required.filter { it in existing || it in defaults }
            if (required.take(2).all { it in usable }) {
                val expr = usable.joinToString(",") { col -> if (col in existing) "`$col`" else defaults.getValue(col) }
                val cols = usable.joinToString(",") { "`$it`" }
                db.execSQL("INSERT OR IGNORE INTO `$table` ($cols) SELECT $expr FROM `$backup`")
            }
            db.execSQL("DROP TABLE IF EXISTS `$backup`")
        }
    }
    copyTable("custom_lists", listOf("id", "name", "createdAt"), mapOf("name" to "''", "createdAt" to "0"))
    copyTable("custom_list_items", listOf("listId", "itemKey", "addonId", "type", "metaId", "name", "poster", "addedAt"), mapOf("addonId" to "''", "type" to "''", "metaId" to "''", "name" to "''", "poster" to "NULL", "addedAt" to "0"))
}

/** v8 → v9: introduce custom lists without discarding any pre-existing recoverable tables. */
val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) = rebuildCustomListTables(db)
}

/** v9 → v10: normalize custom-list schema while preserving every compatible row. */
val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) = rebuildCustomListTables(db)
}

/** v10 → v11: normalize Room's exact schema and retain user list contents. */
val MIGRATION_10_11 = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) = rebuildCustomListTables(db)
}

/**
 * v14 → v15 (v0.14.8-test fix round):
 *  - playback gains the playing stream's identity (streamAddonId /
 *    streamName / streamTitle / streamQuality) so a Continue
 *    Watching resume re-selects the stream the user was watching —
 *    v0.14.7 saved only the URL as the row key, and a resume could
 *    land on the first stream instead (owner's device report) —
 *    plus the title's logo artwork for the CW card.
 *  - watchlist / favorites / title_statuses / custom_list_items
 *    gain a `logo` column (studio logo on poster tiles, notes item
 *    11), backfilled together with missing posters.
 */
val MIGRATION_14_15 = object : Migration(14, 15) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE playback ADD COLUMN streamAddonId TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN streamName TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN streamTitle TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN streamQuality TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN logo TEXT")
        db.execSQL("ALTER TABLE watchlist ADD COLUMN logo TEXT")
        db.execSQL("ALTER TABLE favorites ADD COLUMN logo TEXT")
        db.execSQL("ALTER TABLE title_statuses ADD COLUMN logo TEXT")
        db.execSQL("ALTER TABLE custom_list_items ADD COLUMN logo TEXT")
    }
}

/**
 * v15 → v16 (v0.14.9-test, notes items 13 + 16):
 *  - playback gains `episodeIdsJson` — the episode list persisted
 *    with the row, so a resumed series session knows its next
 *    episode without depending on a one-shot meta fetch.
 *  - playback gains `remoteProgressPct` + `importSource` for
 *    Continue Watching rows imported from Trakt/Simkl progress.
 */
val MIGRATION_15_16 = object : Migration(15, 16) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE playback ADD COLUMN episodeIdsJson TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN remoteProgressPct INTEGER")
        db.execSQL("ALTER TABLE playback ADD COLUMN importSource TEXT")
    }
}

/**
 * v13 → v14: series context on Continue Watching rows (seriesName /
 * episodeTitle / metaId on playback), so resuming an episode rebuilds
 * the full player context instead of series-level data only. Data
 * stays; old rows have nulls and the player re-fetches the meta to
 * fill them in.
 */
val MIGRATION_13_14 = object : Migration(13, 14) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE playback ADD COLUMN seriesName TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN episodeTitle TEXT")
        db.execSQL("ALTER TABLE playback ADD COLUMN metaId TEXT")
    }
}

/** v11 → v12: watched-history table for the WATCHED pill (v0.12.26). */
val MIGRATION_11_12 = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS watched (`key` TEXT NOT NULL, watchedAt INTEGER NOT NULL, PRIMARY KEY(`key`))")
    }
}

/**
 * v12 → v13 (v0.14.10): favorites + title_statuses tables for the
 * Plavio section of the hold sheet. Both start empty — existing
 * watchlist rows already read as the "Next to Watch" status, so no
 * data copy is needed.
 */
val MIGRATION_12_13 = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS favorites (
                `key` TEXT NOT NULL PRIMARY KEY,
                addonId TEXT NOT NULL,
                type TEXT NOT NULL,
                metaId TEXT NOT NULL,
                name TEXT NOT NULL,
                poster TEXT,
                addedAt INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS title_statuses (
                `key` TEXT NOT NULL PRIMARY KEY,
                addonId TEXT NOT NULL,
                type TEXT NOT NULL,
                metaId TEXT NOT NULL,
                name TEXT NOT NULL,
                poster TEXT,
                status TEXT NOT NULL,
                updatedAt INTEGER NOT NULL
            )"""
        )
    }
}

/**
 * v16 → v17 (owner's order, 2026-10-28): `downloads` gains
 * `posterUrl` + `posterPath` — a download saves its title's poster
 * image to a local file at start time so Downloads and Library
 * tiles show artwork fully offline. Existing rows keep nulls and
 * fall back to the placeholder tile.
 */
val MIGRATION_16_17 = object : Migration(16, 17) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE downloads ADD COLUMN posterUrl TEXT")
        db.execSQL("ALTER TABLE downloads ADD COLUMN posterPath TEXT")
    }
}

/**
 * v17 → v18 (v0.14.11): new `meta_cache` table — full series/movie
 * metas (artwork fields + episode list JSON) persisted to disk so
 * Library posters and the Upcoming section render from the last
 * known data instantly and refresh in the background, instead of
 * re-walking the meta addons from zero on every cold start. Pure
 * addition; starts empty and fills as metas resolve.
 */
val MIGRATION_17_18 = object : Migration(17, 18) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS meta_cache (
                `type` TEXT NOT NULL,
                `metaId` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `poster` TEXT,
                `background` TEXT,
                `logo` TEXT,
                `imdbRating` TEXT,
                `videosJson` TEXT NOT NULL,
                `fetchedAt` INTEGER NOT NULL,
                `servedByAddonId` TEXT,
                `extraJson` TEXT,
                PRIMARY KEY(`type`, `metaId`)
            )"""
        )
    }
}

/**
 * v18 → v19 (v0.14.13, item 8 — local profiles): a new global
 * `profiles` table plus a `profileId` column on the partitioned
 * tables (watchlist, favorites, title_statuses, custom_lists,
 * playback, watched). Every pre-existing row is stamped with the
 * first profile's id ('profile_default'), so an upgrading user's
 * library, lists, watched state and Continue Watching land in the
 * first profile — which is also the default — completely intact.
 * The five key-partitioned tables are recreated because their
 * primary key becomes (profileId, key): two profiles must be able
 * to hold the same title without colliding. custom_lists only
 * gains the column (its id is already a unique UUID).
 */
val MIGRATION_18_19 = object : Migration(18, 19) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `profiles` (
                `id` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `avatarKey` TEXT NOT NULL,
                `isDefault` INTEGER NOT NULL,
                `createdAt` INTEGER NOT NULL,
                PRIMARY KEY(`id`)
            )"""
        )
        db.execSQL(
            "INSERT OR IGNORE INTO `profiles` (`id`, `name`, `avatarKey`, `isDefault`, `createdAt`) " +
                "VALUES ('profile_default', 'Profile 1', 'man_glasses', 1, ${System.currentTimeMillis()})"
        )

        // watchlist
        db.execSQL("ALTER TABLE `watchlist` RENAME TO `watchlist_v18`")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `watchlist` (
                `key` TEXT NOT NULL,
                `addonId` TEXT NOT NULL,
                `type` TEXT NOT NULL,
                `metaId` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `poster` TEXT,
                `addedAt` INTEGER NOT NULL,
                `logo` TEXT,
                `profileId` TEXT NOT NULL DEFAULT 'profile_default',
                PRIMARY KEY(`profileId`, `key`)
            )"""
        )
        db.execSQL(
            "INSERT INTO `watchlist` (`key`, `addonId`, `type`, `metaId`, `name`, `poster`, `addedAt`, `logo`, `profileId`) " +
                "SELECT `key`, `addonId`, `type`, `metaId`, `name`, `poster`, `addedAt`, `logo`, 'profile_default' FROM `watchlist_v18`"
        )
        db.execSQL("DROP TABLE `watchlist_v18`")

        // favorites (same shape as watchlist)
        db.execSQL("ALTER TABLE `favorites` RENAME TO `favorites_v18`")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `favorites` (
                `key` TEXT NOT NULL,
                `addonId` TEXT NOT NULL,
                `type` TEXT NOT NULL,
                `metaId` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `poster` TEXT,
                `addedAt` INTEGER NOT NULL,
                `logo` TEXT,
                `profileId` TEXT NOT NULL DEFAULT 'profile_default',
                PRIMARY KEY(`profileId`, `key`)
            )"""
        )
        db.execSQL(
            "INSERT INTO `favorites` (`key`, `addonId`, `type`, `metaId`, `name`, `poster`, `addedAt`, `logo`, `profileId`) " +
                "SELECT `key`, `addonId`, `type`, `metaId`, `name`, `poster`, `addedAt`, `logo`, 'profile_default' FROM `favorites_v18`"
        )
        db.execSQL("DROP TABLE `favorites_v18`")

        // title_statuses
        db.execSQL("ALTER TABLE `title_statuses` RENAME TO `title_statuses_v18`")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `title_statuses` (
                `key` TEXT NOT NULL,
                `addonId` TEXT NOT NULL,
                `type` TEXT NOT NULL,
                `metaId` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `poster` TEXT,
                `status` TEXT NOT NULL,
                `updatedAt` INTEGER NOT NULL,
                `logo` TEXT,
                `profileId` TEXT NOT NULL DEFAULT 'profile_default',
                PRIMARY KEY(`profileId`, `key`)
            )"""
        )
        db.execSQL(
            "INSERT INTO `title_statuses` (`key`, `addonId`, `type`, `metaId`, `name`, `poster`, `status`, `updatedAt`, `logo`, `profileId`) " +
                "SELECT `key`, `addonId`, `type`, `metaId`, `name`, `poster`, `status`, `updatedAt`, `logo`, 'profile_default' FROM `title_statuses_v18`"
        )
        db.execSQL("DROP TABLE `title_statuses_v18`")

        // playback (Continue Watching / history)
        db.execSQL("ALTER TABLE `playback` RENAME TO `playback_v18`")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `playback` (
                `key` TEXT NOT NULL,
                `title` TEXT NOT NULL,
                `poster` TEXT,
                `videoId` TEXT NOT NULL,
                `streamUrl` TEXT NOT NULL,
                `positionMs` INTEGER NOT NULL,
                `durationMs` INTEGER NOT NULL,
                `imdbId` TEXT,
                `season` INTEGER NOT NULL,
                `episode` INTEGER NOT NULL,
                `seriesName` TEXT,
                `episodeTitle` TEXT,
                `metaId` TEXT,
                `streamAddonId` TEXT,
                `streamName` TEXT,
                `streamTitle` TEXT,
                `streamQuality` TEXT,
                `logo` TEXT,
                `updatedAt` INTEGER NOT NULL,
                `episodeIdsJson` TEXT,
                `remoteProgressPct` INTEGER,
                `importSource` TEXT,
                `profileId` TEXT NOT NULL DEFAULT 'profile_default',
                PRIMARY KEY(`profileId`, `key`)
            )"""
        )
        db.execSQL(
            "INSERT INTO `playback` (`key`, `title`, `poster`, `videoId`, `streamUrl`, `positionMs`, `durationMs`, `imdbId`, `season`, `episode`, `seriesName`, `episodeTitle`, `metaId`, `streamAddonId`, `streamName`, `streamTitle`, `streamQuality`, `logo`, `updatedAt`, `episodeIdsJson`, `remoteProgressPct`, `importSource`, `profileId`) " +
                "SELECT `key`, `title`, `poster`, `videoId`, `streamUrl`, `positionMs`, `durationMs`, `imdbId`, `season`, `episode`, `seriesName`, `episodeTitle`, `metaId`, `streamAddonId`, `streamName`, `streamTitle`, `streamQuality`, `logo`, `updatedAt`, `episodeIdsJson`, `remoteProgressPct`, `importSource`, 'profile_default' FROM `playback_v18`"
        )
        db.execSQL("DROP TABLE `playback_v18`")

        // watched (WATCHED pills)
        db.execSQL("ALTER TABLE `watched` RENAME TO `watched_v18`")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS `watched` (
                `key` TEXT NOT NULL,
                `watchedAt` INTEGER NOT NULL,
                `profileId` TEXT NOT NULL DEFAULT 'profile_default',
                PRIMARY KEY(`profileId`, `key`)
            )"""
        )
        db.execSQL(
            "INSERT INTO `watched` (`key`, `watchedAt`, `profileId`) " +
                "SELECT `key`, `watchedAt`, 'profile_default' FROM `watched_v18`"
        )
        db.execSQL("DROP TABLE `watched_v18`")

        // custom_lists: column only (id is already unique).
        db.execSQL("ALTER TABLE `custom_lists` ADD COLUMN `profileId` TEXT NOT NULL DEFAULT 'profile_default'")
    }
}
