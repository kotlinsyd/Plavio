package com.pulsestream.app.ui.components

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.pulsestream.app.data.VoiceSearchSupport
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Voice search mic for the Search bar (owner order 2026-10-31).
 *
 * ISOLATION CONTRACT — this composable can only ever do two things:
 * render a mic button, and (on a successful recognition) hand ONE
 * string to [onResult]. Every failure mode — no recognition service on
 * the device, permission denied or revoked, recognizer cancelled,
 * errored, or returning nothing — renders nothing or does nothing.
 * It holds no state that the search flow reads, writes no state the
 * search flow reads, and the result travels through the exact same
 * query state typed text uses.
 *
 * The mic renders ONLY when a speech-recognition activity resolves on
 * this device AND the RECORD_AUDIO permission isn't denied; otherwise
 * this composable emits nothing and the search bar is unchanged. The
 * permission is requested only when the user taps the mic (the
 * system's own prompt, nothing custom); a denial hides the mic for
 * good (per [VoiceSearchSupport.permissionState]).
 */
@Composable
fun VoiceSearchButton(onResult: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    // Does any speech-recognition activity exist on this device?
    val recognitionResolves = remember(context) {
        try {
            context.packageManager
                .queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0)
                .isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    fun permissionGranted(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(permissionGranted()) }
    var askedBefore by rememberSaveable { mutableStateOf(false) }
    val permissionState = VoiceSearchSupport.permissionState(granted, askedBefore)

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = VoiceSearchSupport.firstResult(
                result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS),
            )
            if (text != null) onResult(text)
        }
        // Cancel / error / no-match: nothing happens — the query and
        // the search stay exactly as they were.
    }

    fun launchSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        // The service resolved a moment ago; if it has vanished since,
        // swallowing here keeps the tap a no-op instead of a crash.
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            // no-op by design
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        askedBefore = true
        granted = isGranted
        if (isGranted) launchSpeech()
        // Denied: permissionState is now DENIED → the mic disappears.
    }

    if (!VoiceSearchSupport.micVisible(recognitionResolves, permissionState)) return

    IconButton(
        onClick = {
            // Re-read the real grant at tap time: a permission revoked
            // in Settings since composition flips the state to DENIED
            // and the mic removes itself instead of dead-ending.
            val nowGranted = permissionGranted()
            if (nowGranted != granted) {
                granted = nowGranted
                if (!nowGranted) {
                    askedBefore = true
                    return@IconButton
                }
            }
            when (VoiceSearchSupport.permissionState(granted, askedBefore)) {
                VoiceSearchSupport.PermissionState.GRANTED -> launchSpeech()
                VoiceSearchSupport.PermissionState.UNKNOWN ->
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                VoiceSearchSupport.PermissionState.DENIED -> Unit
            }
        },
        modifier = modifier,
    ) {
        Icon(Icons.Filled.Mic, contentDescription = "Voice search", tint = TextSecondary)
    }
}
