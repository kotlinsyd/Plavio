package com.pulsestream.app.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap

/**
 * Background studio-logo resolution for poster tiles and heroes
 * (notes items 14/15).
 *
 * The root cause it exists for: catalog items carry NO logo field
 * (verified live against PlavioMeta — a catalog entry is only
 * id/imdbRating/name/poster/type), so the v0.14.8 poster overlay
 * had nothing to draw on Home rails, Library service views and
 * Search. The logo only exists in the full meta. This resolver
 * fetches it in the BACKGROUND — from the serving addon's meta
 * endpoint first, any installed meta addon as fallback (wired in
 * PulseApp to StreamRepository.resolveLogoUrl) — and caches it
 * process-wide by "type|metaId". Tiles read the cache and repaint
 * when a logo lands; nothing ever waits on it, and a title with no
 * logo anywhere simply keeps its plain poster.
 *
 * Misses are remembered too (with a retry window), so a grid of
 * logo-less titles doesn't re-fetch on every recomposition.
 */
object LogoResolver {

    /** Resolved logos by "type|metaId" — observed by poster tiles. */
    private val _logos = MutableStateFlow<Map<String, String>>(emptyMap())
    val logos: StateFlow<Map<String, String>> = _logos.asStateFlow()

    /** Miss timestamps by the same key; retried after the window. */
    private val misses = ConcurrentHashMap<String, Long>()
    private val inFlight = ConcurrentHashMap.newKeySet<String>()
    private const val MISS_RETRY_MS = 10 * 60_000L

    /** The actual fetch, wired once by PulseApp. */
    @Volatile
    var fetcher: (suspend (addonId: String?, type: String, metaId: String) -> String?)? = null

    /**
     * Process-wide cap on concurrent meta walks (v0.14.17 lag fix,
     * audit cause 3): a cold Home used to queue dozens of full meta
     * fetches at once onto the shared IO pool and radio.
     */
    private val walkGate = Semaphore(3)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun key(type: String, metaId: String) = "$type|$metaId"

    /** A logo already resolved this process, or null. */
    fun cached(type: String, metaId: String): String? = _logos.value[key(type, metaId)]

    /** A logo handed to us by a full meta load (Detail, backfill) — free cache fill. */
    fun prime(type: String, metaId: String, logo: String?) {
        val url = logo?.takeIf { it.isNotBlank() } ?: return
        val k = key(type, metaId)
        if (_logos.value[k] != url) {
            _logos.update { it + (k to url) }
        }
    }

    /**
     * Ask for a title's logo in the background. Safe to call on
     * every composition: cached hits, in-flight requests and fresh
     * misses all no-op.
     */
    fun request(addonId: String?, type: String, metaId: String) {
        if (type.isBlank() || metaId.isBlank()) return
        val k = key(type, metaId)
        if (_logos.value.containsKey(k)) return
        val missedAt = misses[k]
        if (missedAt != null && System.currentTimeMillis() - missedAt < MISS_RETRY_MS) return
        if (!inFlight.add(k)) return
        val fetch = fetcher
        if (fetch == null) {
            inFlight.remove(k)
            return
        }
        scope.launch {
            try {
                walkGate.withPermit {
                    val url = runCatching { fetch(addonId, type, metaId) }.getOrNull()
                        ?.takeIf { it.isNotBlank() }
                    if (url != null) {
                        misses.remove(k)
                        _logos.update { it + (k to url) }
                    } else {
                        misses[k] = System.currentTimeMillis()
                    }
                }
            } finally {
                inFlight.remove(k)
            }
        }
    }
}
