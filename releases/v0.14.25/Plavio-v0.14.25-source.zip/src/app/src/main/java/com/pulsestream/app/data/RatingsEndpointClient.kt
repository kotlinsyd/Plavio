package com.pulsestream.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Universal ratings endpoint client (v0.14.20).
 *
 * GET https://meta.plavio.site/ratings/<ttId> — MDBList ratings for
 * a title, served by the PMeta Worker with the owner's key and cached
 * on the server for days. Used when a detail page's meta came from an
 * addon that doesn't carry MDBList fields, so every title can show
 * the full ratings row. Fail-soft: any problem returns null and the
 * page simply keeps the meta's own ratings.
 */
object RatingsEndpointClient {

    private const val BASE = "https://meta.plavio.site/ratings/"

    private val client = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .build()

    /** Raw response body for a tt id, or null on any failure. */
    suspend fun fetchBody(ttId: String): String? = withContext(Dispatchers.IO) {
        if (!ttId.startsWith("tt")) return@withContext null
        val request = Request.Builder()
            .url(BASE + ttId)
            .header("Accept", "application/json")
            .get()
            .build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.code in 200..299) response.body?.string() else null
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            null
        }
    }
}
