package com.pulsestream.app.data.notifications

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StremioApi
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.MIGRATION_1_2
import com.pulsestream.app.data.db.MIGRATION_2_3
import com.pulsestream.app.data.db.MIGRATION_3_4
import com.pulsestream.app.data.db.MIGRATION_4_5
import com.pulsestream.app.data.db.MIGRATION_5_6
import com.pulsestream.app.data.db.MIGRATION_6_7
import com.pulsestream.app.data.db.MIGRATION_7_8
import com.pulsestream.app.data.db.MIGRATION_12_13
import com.pulsestream.app.data.db.MIGRATION_13_14
import com.pulsestream.app.data.db.MIGRATION_14_15
import com.pulsestream.app.data.db.MIGRATION_15_16
import com.pulsestream.app.data.db.MIGRATION_16_17
import com.pulsestream.app.data.db.MIGRATION_17_18
import com.pulsestream.app.data.db.MIGRATION_18_19
import java.time.LocalDate

/**
 * Periodic background check for newly released movies (v0.14.14),
 * modelled on [EpisodeCheckWorker]: every
 * [MovieNotifications.CHECK_INTERVAL_HOURS] hours, for each movie in
 * the followed union (local watchlist + Trakt + Simkl, via
 * [StreamRepository.followedMovies]) resolve the meta through the
 * cache funnel and read its release date.
 *
 * Baseline-diff, exactly like episodes: the first sight of a movie
 * only records its release date (and whether that date was still in
 * the future). A notification fires only when a movie baselined as
 * FUTURE has since arrived — never for movies first seen already
 * released — so enabling the feature, or adding a back-catalogue
 * movie, can't flood. Movies whose meta carries no full release
 * date (year only) are skipped: there is no honest day to notify on.
 */
class MovieReleaseWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val settings = SettingsStore(ctx)
        if (!settings.movieNotifications) {
            MovieNotifications.cancel(ctx)
            return Result.success()
        }

        val dbFile = ctx.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) return Result.success()

        val db = runCatching {
            Room.databaseBuilder(ctx, AppDatabase::class.java, DB_NAME)
                // PLAVIO-17 (v0.14.28): WAL, matching the app
                // singleton's builder — see PulseApp.buildDatabase.
                .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
                .addMigrations(
                    MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5,
                    MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_12_13,
                    MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17,
                    MIGRATION_17_18, MIGRATION_18_19
                )
                .build()
        }.getOrNull() ?: return Result.success()

        // Hoisted so the finally can stop the repository's
        // collectors before db.close() (Kotlin: try-block
        // declarations are not visible in finally).
        var repoRef: StreamRepository? = null
        try {
            val tracker = MovieReleaseTracker(ctx)
            val repository = StreamRepository(db, StremioApi(), settings)
            repoRef = repository
            val today = runCatching { LocalDate.now() }.getOrNull()
                ?: return Result.success()
            val addonsById = runCatching { db.addonDao().getAll() }
                .getOrNull().orEmpty().associateBy { it.id }

            val movies = runCatching { repository.followedMovies() }
                .getOrDefault(emptyList())
            if (movies.isEmpty()) {
                tracker.prune(emptySet())
                return Result.success()
            }

            val keep = mutableSetOf<String>()
            for (item in movies) {
                keep.add(item.metaId)
                runCatching {
                    val hint = item.addonId.takeIf { it.isNotBlank() }
                        ?.let { addonsById[it]?.baseUrl }
                    val meta = repository.getMetaFromAny(hint, "movie", item.metaId)
                        ?: return@runCatching
                    val release = releaseDateOf(meta) ?: return@runCatching

                    if (tracker.baseline(item.metaId) == null) {
                        // First sight: baseline only, never notify.
                        val future = release.isAfter(today)
                        tracker.recordBaseline(item.metaId, release.toString(), future)
                        if (!future) {
                            // Already out when first seen: silent forever.
                            tracker.markNotified(item.metaId)
                        }
                    } else if (!tracker.wasNotified(item.metaId) &&
                        tracker.wasFutureAtBaseline(item.metaId) &&
                        !release.isAfter(today)
                    ) {
                        MovieNotifications.postMovieReleased(
                            ctx, item.addonId, item.metaId,
                            item.name.ifBlank { meta.name }
                        )
                        tracker.markNotified(item.metaId)
                    }
                }
            }
            tracker.prune(keep)
        } finally {
            // v0.14.19 (PLAVIO-K): stop the repository's collectors
            // before closing the DB they query.
            runCatching { repoRef?.shutdown() }
            runCatching { db.close() }
        }
        return Result.success()
    }

    /**
     * Full release date for a movie meta: releaseInfo first (PMeta /
     * Cinemeta carry "yyyy-MM-dd" there), else the single video's
     * released field. Year-only values return null.
     */
    private fun releaseDateOf(meta: com.pulsestream.app.data.MetaDetail): LocalDate? {
        parseDate(meta.releaseInfo)?.let { return it }
        return parseDate(meta.videos.firstOrNull()?.released)
    }

    private fun parseDate(raw: String?): LocalDate? {
        val s = raw?.trim()?.takeIf { it.length >= 10 } ?: return null
        return runCatching { LocalDate.parse(s.substring(0, 10)) }.getOrNull()
    }

    companion object {
        private const val DB_NAME = "pulse-stream.db"
    }
}
