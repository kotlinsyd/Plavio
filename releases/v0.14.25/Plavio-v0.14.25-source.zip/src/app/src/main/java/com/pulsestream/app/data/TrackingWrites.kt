package com.pulsestream.app.data

import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.data.trakt.TraktManager

/**
 * Provider write layer (v0.14.6, Phase 1 of the Trakt/Simkl research
 * report — the "TrackingWrites" model): the detail sheet, the Library
 * hold sheet and the detail page's tracking section all write through
 * here, so Trakt, Simkl (and MDBList lists, via [MdbListApi]) behave
 * identically everywhere.
 *
 * Rules (from the report):
 *  - Writes are REFUSED for titles with no IMDb id — the services
 *    fuzzy-match by title otherwise and can file the wrong title. The
 *    refusal is a visible message, never a silent skip.
 *  - Every write returns an [Outcome] with a user-readable message;
 *    the UI shows it. No silent failures anywhere.
 *  - Trakt adds are verified against the response's added/existing
 *    counts (see TraktApi).
 */
class TrackingWrites(private val settings: SettingsStore) {

    data class Outcome(val ok: Boolean, val message: String)

    private val traktApi = TraktApi()
    private val traktManager = TraktManager(settings)
    private val simklApi = SimklApi()
    private val simklManager = SimklManager(settings)

    val traktLinked: Boolean get() = !settings.traktAccessToken.isNullOrBlank()
    val simklLinked: Boolean get() = !settings.simklToken.isNullOrBlank()
    val mdbLinked: Boolean get() = settings.mdblistApiKey != null

    val mdbApi: MdbListApi? get() = settings.mdblistApiKey?.let { MdbListApi(it) }

    private fun imdbOf(metaId: String): String? =
        metaId.takeIf { it.startsWith("tt") }

    private fun noImdb(service: String) =
        Outcome(false, "This title has no IMDb id, so $service can't file it yet.")

    private suspend fun traktToken(): String? =
        if (traktLinked) runCatching { traktManager.validAccessToken() }.getOrNull() else null

    /**
     * Drops the dead Simkl link state: the cached username AND
     * the tokens are cleared (the same state SimklManager.logout
     * clears), so Integrations and the Library stop showing a
     * stale "Linked as …" and read as needs-reconnect instead.
     */
    private fun clearSimklLink() {
        settings.simklUsername = null
        settings.simklToken = null
        settings.simklRefreshToken = null
        settings.simklTokenIssuedAt = 0L
    }

    /**
     * Maps a Simkl write result to an Outcome. On an auth failure
     * (401/403 — Simkl rejected the saved token, v0.14.8 owner's #9)
     * the dead link state is dropped via [clearSimklLink].
     */
    private fun simklOutcome(result: SimklApi.WriteResult): Outcome {
        if (result.authFailed) {
            clearSimklLink()
        }
        return Outcome(result.ok, result.message)
    }

    /**
     * Runs a Simkl write with the token-lifetime safety net
     * (v0.14.13): the stored token goes through the proactive
     * staleness check first; if Simkl still rejects it with 401
     * (user_token_failed — see [SimklApi.WriteResult.tokenRejected]),
     * ONE refresh is attempted and the write retried ONCE with the
     * fresh token. Only when there is no refresh token or the
     * refresh fails does the result fall through to [simklOutcome],
     * which clears the link with the "expired — reconnect" message.
     */
    private suspend fun simklWrite(
        block: suspend (String) -> SimklApi.WriteResult
    ): Outcome {
        val token = simklManager.validAccessToken()
            ?: return Outcome(false, "Simkl isn't linked.")
        val first = runCatching { block(token) }
            .getOrElse { return Outcome(false, "Couldn't reach Simkl. Try again.") }
        if (first.tokenRejected) {
            val renewed = runCatching { simklManager.refreshStoredToken() }.getOrNull()
            if (renewed != null && renewed != token) {
                val second = runCatching { block(renewed) }
                    .getOrElse { return Outcome(false, "Couldn't reach Simkl. Try again.") }
                return simklOutcome(second)
            }
        }
        return simklOutcome(first)
    }

    /** A read was refused with 401 — Simkl rejected the access token itself. */
    private fun isSimklTokenRejection(error: Throwable?): Boolean =
        error is SimklApi.ReadHttpException && error.code == 401

    /** A read failed on auth grounds (401/403) — the link is dead. */
    private fun isSimklAuthFailure(error: Throwable?): Boolean =
        error is SimklApi.ReadHttpException && (error.code == 401 || error.code == 403)

    /**
     * Runs a Simkl READ with the same token-lifetime safety net
     * the writes got in v0.14.13 ([simklWrite]) — v0.14.41: reads
     * used to call the API bare, so a token Simkl rejected failed
     * silently FOREVER (the owner's empty Library tabs: the dead
     * token 401'd, the exception was swallowed, "Nothing here
     * yet" rendered over the failure). The net mirrors the write
     * path exactly: the stored token goes through the proactive
     * staleness check first; on a 401 rejection ONE refresh is
     * attempted and the read retried ONCE with the fresh token;
     * a second auth failure — or no fresh token mintable at all —
     * drops the dead link via [clearSimklLink], the same honesty
     * [simklOutcome] applies to writes. Any other failure
     * (offline, 5xx, parse) just returns null and keeps the link.
     * Null also when Simkl isn't linked.
     */
    private suspend fun <T> simklRead(block: suspend (String) -> T): T? {
        val token = simklManager.validAccessToken() ?: return null
        val first = runCatching { block(token) }
        if (first.isSuccess) return first.getOrNull()
        val error = first.exceptionOrNull()
        if (error is kotlinx.coroutines.CancellationException) throw error
        if (!isSimklTokenRejection(error)) return null
        val renewed = runCatching { simklManager.refreshStoredToken() }.getOrNull()
        if (renewed != null && renewed != token) {
            val second = runCatching { block(renewed) }
            if (second.isSuccess) return second.getOrNull()
            val secondError = second.exceptionOrNull()
            if (secondError is kotlinx.coroutines.CancellationException) throw secondError
            if (isSimklAuthFailure(secondError)) clearSimklLink()
            return null
        }
        clearSimklLink()
        return null
    }

    // ---- Simkl ----

    /** Current Simkl status of a title, or null when not on Simkl / not linked. */
    suspend fun simklStatusOf(type: String, metaId: String): String? {
        val imdb = imdbOf(metaId) ?: return null
        return simklRead { simklApi.getAllItemsWithStatus(it) }
            ?.firstOrNull { it.type == type && it.imdbId == imdb }?.status
    }

    /** Sets or MOVES a title's Simkl status (one call — Simkl semantics). */
    suspend fun simklSetStatus(
        type: String, metaId: String, title: String, status: String, year: Int = 0
    ): Outcome {
        if (!simklLinked) return Outcome(false, "Simkl isn't linked.")
        val imdb = imdbOf(metaId) ?: return noImdb("Simkl")
        return simklWrite { token ->
            simklApi.setStatus(token, listOf(SimklApi.ListEntry(type, imdb, title, year)), status)
        }
    }

    /** Removes a title from the Simkl library entirely. */
    suspend fun simklRemove(type: String, metaId: String, title: String, year: Int = 0): Outcome {
        if (!simklLinked) return Outcome(false, "Simkl isn't linked.")
        val imdb = imdbOf(metaId) ?: return noImdb("Simkl")
        return simklWrite { token ->
            simklApi.removeFromLibrary(token, listOf(SimklApi.ListEntry(type, imdb, title, year)))
        }
    }

    /** All Simkl items with statuses (Library sections). Null on failure. */
    suspend fun simklAllWithStatus(): List<SimklApi.StatusEntry>? =
        simklRead { simklApi.getAllItemsWithStatus(it) }

    /** Simkl Plan-to-Watch items (Library watchlist row). Null on failure. */
    suspend fun simklPlanToWatch(): List<SimklApi.ListEntry>? =
        simklRead { simklApi.getPlanToWatch(it) }

    /** Simkl currently-watching shows (Library Up Next input). Null on failure. */
    suspend fun simklWatching(): List<SimklApi.WatchingEntry>? =
        simklRead { simklApi.getWatching(it) }

    /**
     * The user's Simkl CUSTOM lists (Library sections). Read-only:
     * Simkl's API has no list write endpoints at all (see
     * [SimklApi.getCustomLists]), so this direction — Simkl lists
     * appearing in the app — is the only one that exists. Null on
     * failure; empty for free accounts (premium_only).
     */
    suspend fun simklCustomLists(): List<SimklApi.CustomListInfo>? =
        simklRead { simklApi.getCustomLists(it) }

    /** One Simkl custom list's items. Null on failure. */
    suspend fun simklCustomListItems(listId: Long): List<SimklApi.ListEntry>? =
        simklRead { simklApi.getCustomListItems(it, listId) }

    // ---- Trakt ----

    /** The user's personal Trakt lists. Null on failure / not linked. */
    suspend fun traktLists(): List<TraktApi.TraktListInfo>? {
        val token = traktToken() ?: return null
        return runCatching { traktApi.getLists(token) }.getOrNull()
    }

    /** True when the title sits in the Trakt watchlist. Null = unknown. */
    suspend fun traktInWatchlist(type: String, metaId: String): Boolean? {
        val token = traktToken() ?: return null
        val imdb = imdbOf(metaId) ?: return null
        return runCatching { traktApi.getWatchlist(token) }
            .getOrNull()?.any { it.type == type && it.imdbId == imdb }
    }

    /** Ids of the personal lists that contain this title. Null = unknown. */
    suspend fun traktListsContaining(
        type: String, metaId: String, lists: List<TraktApi.TraktListInfo>
    ): Set<Int>? {
        val token = traktToken() ?: return null
        val imdb = imdbOf(metaId) ?: return null
        val out = mutableSetOf<Int>()
        for (list in lists) {
            val items = runCatching { traktApi.getListItems(token, list.id) }.getOrNull()
                ?: return null
            if (items.any { it.type == type && it.imdbId == imdb }) out += list.id
        }
        return out
    }

    /** Items of one Trakt list (Library sections). Null on failure. */
    suspend fun traktListItems(listId: Int): List<TraktApi.WatchlistEntry>? {
        val token = traktToken() ?: return null
        return runCatching { traktApi.getListItems(token, listId) }.getOrNull()
    }

    /** The Trakt watchlist (Library section). Null on failure. */
    suspend fun traktWatchlist(): List<TraktApi.WatchlistEntry>? {
        val token = traktToken() ?: return null
        return runCatching { traktApi.getWatchlist(token) }.getOrNull()
    }

    /** The Trakt watched history (Library section, v0.14.19). Null on failure. */
    suspend fun traktWatchedHistory(): List<TraktApi.WatchlistEntry>? {
        val token = traktToken() ?: return null
        return runCatching { traktApi.getWatchedHistory(token) }.getOrNull()
    }

    suspend fun traktToggleWatchlist(
        type: String, metaId: String, title: String, add: Boolean
    ): Outcome {
        val token = traktToken() ?: return Outcome(false, "Trakt isn't linked.")
        val imdb = imdbOf(metaId) ?: return noImdb("Trakt")
        val entry = TraktApi.WatchlistEntry(type, imdb, title)
        val result = runCatching {
            if (add) traktApi.addToWatchlistVerified(token, listOf(entry))
            else traktApi.removeFromWatchlistVerified(token, listOf(entry))
        }.getOrElse { return Outcome(false, "Couldn't reach Trakt. Try again.") }
        return Outcome(result.ok, result.message)
    }

    /**
     * The user's own Trakt rating for a title (v0.14.40, item 11),
     * 1–10, or null when unrated / Trakt unlinked / unreachable.
     */
    suspend fun traktRatingOf(type: String, metaId: String): Int? {
        val token = traktToken() ?: return null
        val imdb = imdbOf(metaId) ?: return null
        return runCatching { traktApi.getRating(token, type, imdb) }.getOrNull()
    }

    /**
     * Push the user's own rating to Trakt (v0.14.40, item 11).
     * The on-device store is written by the caller FIRST — this
     * outcome only decides the row's "Synced to Trakt" label.
     */
    suspend fun traktSetRating(type: String, metaId: String, rating: Int): Outcome {
        val token = traktToken() ?: return Outcome(false, "Trakt isn't linked.")
        val imdb = imdbOf(metaId) ?: return noImdb("Trakt")
        val ok = runCatching { traktApi.addRating(token, type, imdb, rating) }
            .getOrElse { return Outcome(false, "Couldn't reach Trakt. Try again.") }
        return if (ok) Outcome(true, "Synced to Trakt")
        else Outcome(false, "Couldn't reach Trakt. Try again.")
    }

    suspend fun traktToggleList(
        list: TraktApi.TraktListInfo, type: String, metaId: String, title: String, add: Boolean
    ): Outcome {
        val token = traktToken() ?: return Outcome(false, "Trakt isn't linked.")
        val imdb = imdbOf(metaId) ?: return noImdb("Trakt")
        val entry = TraktApi.WatchlistEntry(type, imdb, title)
        val result = runCatching {
            if (add) traktApi.addToListItems(token, list.id, list.name, listOf(entry))
            else traktApi.removeFromListItems(token, list.id, list.name, listOf(entry))
        }.getOrElse { return Outcome(false, "Couldn't reach Trakt. Try again.") }
        return Outcome(result.ok, result.message)
    }

    // ---- Watched history (both services) ----

    /**
     * Pushes a watched mark to every linked service. [episodes] carries
     * (season, episode) pairs for series — batched into one call per
     * service. Returns one Outcome per service actually attempted
     * (empty when nothing is linked). Local marks are the caller's job.
     */
    suspend fun markWatched(
        type: String, metaId: String, title: String, year: Int?,
        episodes: List<Pair<Int, Int>>, watched: Boolean
    ): List<Outcome> {
        val imdb = imdbOf(metaId)
        val outcomes = mutableListOf<Outcome>()
        if (imdb == null) {
            if (traktLinked || simklLinked) {
                outcomes += Outcome(false, "This title has no IMDb id, so it can't be marked on Trakt/Simkl yet.")
            }
            return outcomes
        }
        traktToken()?.let { token ->
            val item = TraktApi.HistoryItem(type, imdb, title, year, episodes)
            val result = runCatching {
                if (watched) traktApi.markWatched(token, listOf(item))
                else traktApi.unmarkWatched(token, listOf(item))
            }.getOrElse { TraktApi.WriteResult(false, "Couldn't reach Trakt. Try again.") }
            outcomes += Outcome(result.ok, result.message)
        }
        if (simklLinked) {
            val item = SimklApi.HistoryItem(type, imdb, title, episodes)
            outcomes += simklWrite { token ->
                if (watched) simklApi.markWatched(token, listOf(item))
                else simklApi.unmarkWatched(token, listOf(item))
            }
        }
        return outcomes
    }
}
