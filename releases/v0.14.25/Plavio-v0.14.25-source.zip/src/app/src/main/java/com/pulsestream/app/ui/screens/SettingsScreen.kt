package com.pulsestream.app.ui.screens

import androidx.compose.material3.OutlinedButton
import com.pulsestream.app.ui.components.OrbitDots
import com.pulsestream.app.ui.components.ProfileAvatarImage
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.material3.SwitchColors
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsestream.app.BuildConfig
import com.pulsestream.app.R
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.cloud.PlavioAccountManager
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.update.UpdateChecker
import com.pulsestream.app.data.update.UpdateInfo
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.components.UpdatePrompt
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.AppTheme
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.LocalSpacingScale
import com.pulsestream.app.ui.theme.AccentTheme
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.GlassWhite
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.tv.tvFocusRing
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repository: StreamRepository,
    onThemeChanged: () -> Unit = {},
    onGoToAddons: () -> Unit = {},
    onGoToPlayback: () -> Unit = {},
    onGoToSubtitles: () -> Unit = {},
    onGoToAppearance: () -> Unit = {},
    onGoToStreams: () -> Unit = {},
    onGoToAbout: () -> Unit = {},
    onGoToFeedback: () -> Unit = {},
    onGoToAccount: () -> Unit = {},
    onGoToIntegrations: () -> Unit = {},
    onGoToDownloads: () -> Unit = {},
    onGoToNotifications: () -> Unit = {},
    onGoToHomeSwitch: () -> Unit = {},
    onGoToProfiles: () -> Unit = {},
    onGoToLicenses: () -> Unit = {},
    onGoToWhatsNew: () -> Unit = {},
    onGoToAdvanced: () -> Unit = {}
) {
    val settings = repository.settings
    val context = LocalContext.current

    // ---- Settings rebuild (v0.14.39) ----
    // Style law = the owner's approved settings sample (2026-11-12):
    // pure-black page, big header, filled search bar, FILLED
    // dark-grey cards (27,27,31) with icon tiles (56,56,63), a
    // hairline divider under every row except each card's last, and
    // the PLAVIO / "Made with ❤️ by Kotlinsyd" footer. Structure law = the
    // 2026-11-12 settings audit: ACCOUNT / GENERAL / PLAYBACK /
    // ABOUT / ADVANCED, every setting in exactly ONE home — the
    // root's old stray toggles moved to their single homes (Usage
    // counting + Crash reports → Advanced; Continue Watching
    // posters → Appearance; the motion control merged into
    // Appearance's Animations chips, audit D2). The sample's
    // "Supporters & Contributors" row is NOT here: no such screen
    // exists in the app, and a row is never pointed at nothing.
    var addonsHubSheetOpen by remember { mutableStateOf(false) }
    var settingsQuery by rememberSaveable { mutableStateOf("") }

    // Account identity for the Account & Sync row's subtitle — the
    // same sync manager the Account screen uses; this screen is
    // recreated on every visit, so the values are fresh each open.
    val plavioManager = remember { PlavioAccountManager(context, repository) }
    val plavioEmail = remember {
        if (PlavioAccountManager.isConfigured() && plavioManager.isSignedIn()) {
            plavioManager.accountEmail()
        } else {
            null
        }
    }
    val plavioLastSync = remember(plavioEmail) {
        if (plavioEmail != null) plavioManager.lastSyncTime() else null
    }
    val plavioUsername = remember(plavioEmail) {
        if (plavioEmail != null) plavioManager.accountUsername() else null
    }
    val profileUserName = remember { settings.profileUserName }
    val displayName = remember(profileUserName, plavioEmail, plavioUsername) {
        plavioUsername?.let { "@$it" }
            ?: profileUserName.takeIf { it.isNotBlank() }
            ?: plavioEmail?.let { deriveDisplayName(it) }
    }
    val installedAddons by repository.addons.collectAsState(initial = emptyList())
    val enabledAddons = remember(installedAddons) { installedAddons.count { it.enabled } }

    val accountSyncSubtitle = when {
        plavioEmail != null -> {
            val who = displayName ?: "Signed in"
            val sync = plavioLastSync?.let { "Synced · $it" } ?: "Backup & sync on"
            "$who · $sync"
        }
        else -> "Tap to sign in and enable backup & sync"
    }

    val accountRows = listOf(
        SettingsRootRow(
            icon = Icons.Filled.SwapHoriz,
            title = "Switch Profile",
            subtitle = "Change to a different profile",
            searchText = "switch profile profiles change user kids",
            onClick = onGoToProfiles
        ),
        SettingsRootRow(
            icon = Icons.Filled.CloudSync,
            title = "Account & Sync",
            subtitle = accountSyncSubtitle,
            searchText = "account sign in backup sync email username password",
            onClick = onGoToAccount
        ),
        SettingsRootRow(
            icon = Icons.Filled.Link,
            title = "Integrations",
            subtitle = "Debrid services, Trakt, Simkl and API keys",
            searchText = "integrations debrid trakt simkl api keys real-debrid premiumize torbox offcloud alldebrid debrid-link",
            onClick = onGoToIntegrations
        )
    )
    val generalRows = listOf(
        SettingsRootRow(
            icon = Icons.Filled.Contrast,
            title = stringResource(R.string.settings_appearance_title),
            subtitle = "Onyx theme and accent colour",
            searchText = "appearance accent colour onyx animations reduced motion posters text size spacing corners",
            onClick = onGoToAppearance
        ),
        SettingsRootRow(
            icon = Icons.Filled.Extension,
            title = "Addons & Catalogs",
            subtitle = "Install addons, pick Home catalogs",
            searchText = "addons catalogs home switch manage extensions install sources manifest",
            onClick = { addonsHubSheetOpen = true }
        ),
        SettingsRootRow(
            icon = Icons.Filled.Download,
            title = "Downloads",
            subtitle = "Movies and shows saved on this device",
            searchText = "downloads offline files storage wifi auto-download next episode downloaded",
            onClick = onGoToDownloads
        ),
        SettingsRootRow(
            icon = Icons.Filled.Notifications,
            title = "Notifications",
            subtitle = "New episodes, movies, updates and downloads",
            searchText = "notifications alerts new episode movies updates downloads permission bell",
            onClick = onGoToNotifications
        )
    )
    val playbackRows = listOf(
        SettingsRootRow(
            icon = Icons.Filled.PlayArrow,
            title = stringResource(R.string.settings_playback_title),
            subtitle = "Player, subtitles, PrePlay and auto-play",
            searchText = "playback autoplay next episode screen skip intro audio resume buffer preplay player",
            onClick = onGoToPlayback
        ),
        SettingsRootRow(
            icon = Icons.Filled.VideoLibrary,
            title = stringResource(R.string.settings_streams_title),
            subtitle = "Badges and Fusion style badges",
            searchText = "streams sources source limits quality order autoplay rule providers badges fusion",
            onClick = onGoToStreams
        ),
        SettingsRootRow(
            icon = Icons.Filled.ClosedCaption,
            title = stringResource(R.string.settings_subtitles_title),
            subtitle = "Style, languages and sources",
            searchText = "subtitles captions style font size colour background languages appearance timing",
            onClick = onGoToSubtitles
        )
    )
    val aboutRows = listOf(
        SettingsRootRow(
            icon = Icons.Filled.Info,
            title = stringResource(R.string.settings_about_title),
            subtitle = stringResource(R.string.settings_about_sub),
            searchText = "about version website updates app info check",
            onClick = onGoToAbout
        ),
        SettingsRootRow(
            icon = Icons.Filled.NewReleases,
            title = "What's New",
            subtitle = "What changed in v${BuildConfig.VERSION_NAME}",
            searchText = "whats new changelog update changes release notes",
            onClick = onGoToWhatsNew
        ),
        SettingsRootRow(
            icon = Icons.Filled.Policy,
            title = "Privacy Policy",
            subtitle = "How Plavio handles your data",
            searchText = "privacy policy legal data",
            onClick = {
                // Devices with no browser must not force-close.
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://plavio.site/privacy.html"))
                    )
                }
            }
        ),
        SettingsRootRow(
            icon = Icons.Filled.Book,
            title = "Licenses & Attribution",
            subtitle = "Open-source licenses and credits",
            searchText = "licenses attribution credits open source",
            onClick = onGoToLicenses
        ),
        SettingsRootRow(
            icon = Icons.Filled.Feedback,
            title = stringResource(R.string.settings_feedback_title),
            subtitle = stringResource(R.string.settings_feedback_sub),
            searchText = "feedback send bug report feature request support",
            onClick = onGoToFeedback
        )
    )
    val advancedRows = listOf(
        SettingsRootRow(
            icon = Icons.Filled.Tune,
            title = "Advanced",
            subtitle = "Usage counting and crash reports",
            searchText = "advanced usage counting crash reports sentry anonymous privacy data",
            onClick = onGoToAdvanced
        )
    )

    val normalizedQuery = settingsQuery.trim().lowercase()
    val allRows = accountRows + generalRows + playbackRows + aboutRows + advancedRows
    val visibleRows = if (normalizedQuery.isEmpty()) allRows
        else allRows.filter { row ->
            row.title.lowercase().contains(normalizedQuery) ||
                row.searchText.contains(normalizedQuery)
        }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            // Bottom padding ensures the floating nav capsule never
            // covers the footer (capsule ~80dp + nav ~32dp + margin).
            contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            item(key = "settings_header") {
                Text(
                    text = stringResource(R.string.settings_title),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
                )
            }
            item(key = "settings_search") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SettingsCardFill, RoundedCornerShape(14.dp))
                ) {
                    OutlinedTextField(
                        value = settingsQuery,
                        onValueChange = { settingsQuery = it },
                        placeholder = { Text("Search settings", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Filled.Search, null, tint = TextSecondary) },
                        trailingIcon = if (settingsQuery.isNotEmpty()) {
                            {
                                IconButton(onClick = { settingsQuery = "" }) {
                                    Icon(Icons.Filled.Close, "Clear search", tint = TextSecondary)
                                }
                            }
                        } else null,
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = LocalPalette.current.accent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (normalizedQuery.isEmpty()) {
                item(key = "account_header") { SettingsSectionHeader("Account") }
                item(key = "account_card") { SettingsRootCard(accountRows) }
                item(key = "general_header") { SettingsSectionHeader("General") }
                item(key = "general_card") { SettingsRootCard(generalRows) }
                item(key = "playback_header") { SettingsSectionHeader("Playback") }
                item(key = "playback_card") { SettingsRootCard(playbackRows) }
                item(key = "about_header") { SettingsSectionHeader("About") }
                item(key = "about_card") { SettingsRootCard(aboutRows) }
                item(key = "advanced_header") { SettingsSectionHeader("Advanced") }
                item(key = "advanced_card") { SettingsRootCard(advancedRows) }
            } else {
                if (visibleRows.isEmpty()) {
                    item(key = "no_settings_match") {
                        Text(
                            "No settings match \"${settingsQuery.trim()}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 32.dp, vertical = 24.dp)
                        )
                    }
                } else {
                    item(key = "search_results") { SettingsRootCard(visibleRows) }
                }
            }

            item(key = "credit") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 28.dp, bottom = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Footer logo (v0.14.40, owner's order
                    // 2026-11-13): the plain-text "PLAVIO" becomes
                    // the real mark — the signature wordmark with
                    // the play triangle in the O, the same
                    // derivative that fronts Plavio Web.
                    Image(
                        painter = painterResource(id = R.drawable.plavio_web_logo),
                        contentDescription = "PLAVIO",
                        modifier = Modifier.width(148.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        // Owner's exact words (2026-11-13, v0.14.42).
                        text = "Made with ❤️ by Kotlinsyd",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    // The Addons & Integrations popup card: a bottom sheet over
    // Settings holding Manage addons + Home Switch. (v0.14.39:
    // Integrations left the sheet — it is an ACCOUNT-card root row
    // now, per the audit's single-home map and the approved sample.)
    if (addonsHubSheetOpen) {
        AddonsHubSheet(
            repository = repository,
            installedCount = installedAddons.size,
            enabledCount = enabledAddons,
            onDismiss = { addonsHubSheetOpen = false },
            onGoToAddons = {
                addonsHubSheetOpen = false
                onGoToAddons()
            },
            onGoToHomeSwitch = {
                addonsHubSheetOpen = false
                onGoToHomeSwitch()
            }
        )
    }
}

/** Card fill of the rebuilt Settings root — rgb(27,27,31), from the approved sample. */
private val SettingsCardFill = Color(0xFF1B1B1F)

/** Icon-tile fill of the rebuilt Settings root — rgb(56,56,63), from the approved sample. */
private val SettingsTileFill = Color(0xFF38383F)

/** One row of the rebuilt Settings root: every root row is a navigation row. */
private data class SettingsRootRow(
    val icon: ImageVector,
    val title: String,
    val subtitle: String,
    /** Extra lowercase keywords the settings search matches against. */
    val searchText: String,
    val onClick: () -> Unit
)

/**
 * One filled card of the rebuilt root: rows stacked flush, a
 * hairline divider under every row except the card's last (the
 * approved sample's structure).
 */
@Composable
private fun SettingsRootCard(rows: List<SettingsRootRow>) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(SettingsCardFill, RoundedCornerShape(20.dp))
    ) {
        rows.forEachIndexed { index, row ->
            if (index > 0) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 74.dp, end = 16.dp)
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.07f))
                )
            }
            SettingsRootRowView(row)
        }
    }
}

@Composable
private fun SettingsRootRowView(row: SettingsRootRow) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = row.onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(SettingsTileFill, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(row.icon, contentDescription = row.title, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                row.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(Modifier.height(2.dp))
            Text(
                row.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Icon(
            Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = TextSecondary
        )
    }
}

/**
 * Addons & Integrations BOTTOM POPUP CARD: exactly two options —
 * **Manage addons → Home Switch**. (v0.14.39: Integrations moved
 * out to the ACCOUNT card of the rebuilt root — the audit's
 * single-home map; the sheet is the Addons & Integrations door for
 * addons themselves, nothing else.)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddonsHubSheet(
    repository: StreamRepository,
    installedCount: Int,
    enabledCount: Int,
    onDismiss: () -> Unit,
    onGoToAddons: () -> Unit,
    onGoToHomeSwitch: () -> Unit = {}
) {
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = androidx.compose.material3.rememberModalBottomSheetState(
            skipPartiallyExpanded = true
        ),
        containerColor = LocalPalette.current.background,
        dragHandle = { androidx.compose.material3.BottomSheetDefaults.DragHandle() }
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text(
                text = "Addons & Catalogs",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            SettingsGroup(
                {
                    SettingsNavRow(
                        icon = Icons.Filled.Extension,
                        title = stringResource(R.string.settings_addons_title),
                        subtitle = stringResource(
                            R.string.settings_addons_sub,
                            installedCount,
                            enabledCount
                        ),
                        onClick = onGoToAddons
                    )
                }
            )
            Spacer(Modifier.height(12.dp))
            // Home Switch: a folded NAV row — tapping it dismisses
            // this card and opens the dedicated Home Switch page;
            // the options live only there (owner's fold order).
            HomeSwitchSection(
                repository = repository,
                onNavigate = onGoToHomeSwitch
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}

/**
 * Display name for the Settings account card, derived from the account
 * email's local part ("syed.najam" → "Syed Najam") — the sync layer
 * exposes only the email address, so the name is derived at display
 * time and never stored.
 */
private fun deriveDisplayName(email: String): String =
    email.substringBefore('@')
        .split('.', '_', '-', '+')
        .filter { it.isNotBlank() }
        .joinToString(" ") { part -> part.replaceFirstChar { c -> c.uppercase() } }
        .ifBlank { email }

/**
 * True while rendering inside a [SettingsGroup]: the shared settings
 * rows drop their own card and sit flush in the group card — the Onyx
 * settings structure (one card per section, hairline dividers between
 * rows), matching the owner's reference screenshots (2026-10-25).
 */
val LocalSettingsGrouped = compositionLocalOf { false }

/**
 * One grouped settings card: rows stacked in a single flat-ish glass
 * card with hairline dividers between them (inset to the text column).
 */
@Composable
fun SettingsGroup(vararg rows: @Composable () -> Unit) {
    // Flat category style (v0.14.24, item 11): no card, no capsule —
    // the rows sit plainly on the page with hairline dividers,
    // under their category header. Every settings sub-screen groups
    // through here, so the whole Settings area shares the style.
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        CompositionLocalProvider(LocalSettingsGrouped provides true) {
            rows.forEachIndexed { index, row ->
                if (index > 0) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 74.dp, end = 16.dp)
                            .height(1.dp)
                            .background(TextSecondary.copy(alpha = 0.16f))
                    )
                }
                row()
            }
        }
    }
}

/** Switch colours: Onyx gets the reference look (white track, black thumb). */
@Composable
fun settingsSwitchColors(): SwitchColors =
    if (LocalPalette.current.appTheme == AppTheme.ONYX) {
        // The accent drives the small things (owner's order 2026-10-25):
        // the ON switch wears the chosen accent, thumb contrasts it.
        val onyxAccent = LocalPalette.current.accent
        SwitchDefaults.colors(
            checkedThumbColor = if (onyxAccent == Color.White) Color.Black else Color.White,
            checkedTrackColor = onyxAccent,
            uncheckedThumbColor = Color(0xFF8E8E93),
            uncheckedTrackColor = Color(0xFF2E2E30),
            checkedBorderColor = Color.Transparent,
            uncheckedBorderColor = Color.Transparent
        )
    } else {
        SwitchDefaults.colors(
            checkedThumbColor = LocalPalette.current.accent,
            checkedTrackColor = LocalPalette.current.accent.copy(alpha = 0.35f)
        )
    }

/** Small-caps section header, Pulse style. */
@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        ),
        color = TextSecondary,
        modifier = Modifier.padding(start = 20.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)
    )
}

/** Leading icon in a rounded glass tile. */
@Composable
fun SettingsIconTile(icon: ImageVector, contentDescription: String?) {
    if (LocalPalette.current.appTheme == AppTheme.ONYX) {
        // Onyx: flat charcoal tile, white glyph (owner's reference).
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(Color(0xFF2E2E30), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    } else {
        Box(
            modifier = Modifier
                .size(44.dp)
                .liquidGlass(RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription, tint = LocalPalette.current.accent, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    compact: Boolean = false
) {
    if (LocalSettingsGrouped.current) {
        SettingsToggleRowGrouped(icon, title, subtitle, checked, onCheckedChange, compact)
        return
    }
    GlassCard(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp),
        onClick = { onCheckedChange(!checked) }
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = settingsSwitchColors()
            )
        }
    }
}

/** Navigation row: icon tile + title/subtitle + chevron, opens a sub-screen. */
@Composable
fun SettingsNavRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    compact: Boolean = false,
    // Optional state colour for the subtitle (v0.14.27, batch N6):
    // rows whose subtitle IS a state (e.g. a permission that is not
    // granted) can flag it red; every other caller keeps the plain
    // secondary colour by default.
    subtitleColor: Color = TextSecondary
) {
    if (LocalSettingsGrouped.current) {
        SettingsNavRowGrouped(icon, title, subtitle, onClick, compact, subtitleColor)
        return
    }
    GlassCard(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp),
        onClick = onClick
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = subtitleColor
                )
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}

/** Non-interactive row (used for "coming soon" placeholders). */
@Composable
fun SettingsStaticRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
    dimmed: Boolean = false,
    onClick: (() -> Unit)? = null,
    compact: Boolean = false
) {
    if (LocalSettingsGrouped.current) {
        SettingsStaticRowGrouped(icon, title, subtitle, trailing, dimmed, onClick, compact)
        return
    }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp)
            .alpha(if (dimmed) 0.6f else 1f),
        onClick = onClick
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingsToggleRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    compact: Boolean
) {
    Box(Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = checked, onCheckedChange = onCheckedChange, colors = settingsSwitchColors())
        }
    }
}

@Composable
private fun SettingsNavRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    compact: Boolean,
    subtitleColor: Color = TextSecondary
) {
    Box(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = subtitleColor)
            }
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

@Composable
private fun SettingsStaticRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
    dimmed: Boolean,
    onClick: (() -> Unit)?,
    compact: Boolean
) {
    Box(
        Modifier
            .fillMaxWidth()
            .alpha(if (dimmed) 0.6f else 1f)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

/** Script font used for the "Najam Syyd" signature in About. */

@Composable
fun AboutCard() {
    val context = LocalContext.current
    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.mipmap.app_logo),
                contentDescription = "Plavio logo",
                modifier = Modifier.size(88.dp).clip(RoundedCornerShape(26.dp))
            )
            // Name + version text REMOVED (owner's order 2026-10-22):
            // the logo already says Plavio, and the updater card below
            // already shows the version — the pair only duplicated both.
            Spacer(Modifier.height(14.dp))
            Text(
                text = "A beautiful open-source streaming app with a built-in " +
                    "player. Add your favorite addons and enjoy your movies " +
                    "and shows in one glowing place.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable {
                        // Devices with no browser must not force-close.
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.plavio.site"))
                            )
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    Icons.Filled.Language,
                    contentDescription = null,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "plavio.site",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = LocalPalette.current.accent,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.Link,
                    contentDescription = null,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "Data: TMDB • Fanart.tv • MDBList • Cinemeta • OpenSubtitles • IntroDB",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** Settings > About > App Updater: auto-check toggle + manual update check. */
@Composable
fun AppUpdaterCard() {
    val appContext = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var updateInfo by remember { mutableStateOf<UpdateInfo?>(null) }

    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SettingsIconTile(Icons.Filled.SystemUpdate, "App updater")
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "App Updater",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "You're on v${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
            // The "Update available" auto-check toggle lives ONLY in
            // Settings → Notifications since v0.14.14 (owner's one-card
            // order) — this card keeps the version line and the manual
            // check button.
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    checking = true
                    status = null
                    scope.launch {
                        // Classified outcome: tell offline apart from
                        // up-to-date instead of "latest version" for all of it.
                        when (val result = UpdateChecker.checkNowDetailed(appContext)) {
                            is UpdateChecker.UpdateCheckResult.Update -> {
                                updateInfo = result.info
                            }
                            UpdateChecker.UpdateCheckResult.UpToDate -> {
                                status = "You're on the latest version."
                            }
                            UpdateChecker.UpdateCheckResult.Offline -> {
                                status = "Couldn't check — you're offline."
                            }
                            is UpdateChecker.UpdateCheckResult.Error -> {
                                status = "Couldn't check for updates: ${result.message}"
                            }
                        }
                        checking = false
                    }
                },
                enabled = !checking,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LocalPalette.current.accent.copy(alpha = 0.18f),
                    contentColor = LocalPalette.current.accent,
                    disabledContainerColor = LocalPalette.current.accent.copy(alpha = 0.08f)
                )
            ) {
                if (checking) {
                    OrbitDots(modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Checking…")
                } else {
                    Text("Check for update now")
                }
            }
            status?.let {
                Spacer(Modifier.height(8.dp))
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    UpdatePrompt(
        info = updateInfo,
        onDismiss = { updateInfo = null }
    )
}

/**
 * Icon-only social/community links, placed directly below the App Installs
 * counter. Icons only, no text labels (content descriptions for a11y).
 */
@Composable
private fun SocialIconRow() {
    val context = LocalContext.current
    val palette = LocalPalette.current
    val links = listOf(
        Triple(R.drawable.ic_discord, "Discord", "https://discord.gg/cwzHH3r9pa"),
        Triple(R.drawable.ic_github, "GitHub", "https://github.com/kotlinsyd/Plavio"),
        Triple(R.drawable.ic_gitlab, "GitLab", "https://gitlab.com/KotlinJS5/plavio"),
        Triple(R.drawable.ic_reddit, "Reddit", "https://www.reddit.com/r/Plavio/"),
    )
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        links.forEach { (iconRes, label, url) ->
            IconButton(
                onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                        )
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = palette.panel.copy(alpha = 0.7f),
                        shape = CircleShape
                    )
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = label,
                    // No tint — show icons in their native white for clean look
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
