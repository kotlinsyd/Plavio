package com.pulsestream.app.data.cloud

import org.json.JSONObject

/**
 * Safe, user-facing wording for account (Supabase) configuration and
 * auth failures.
 *
 * The rules that matter:
 * - A rejected app/API configuration is never reported as a password
 *   problem — the user cannot fix the app's own keys by retyping
 *   their password.
 * - Provider response bodies are never echoed to the user: they can
 *   carry backend details. Only a small set of known, benign provider
 *   messages is passed through or translated; everything else falls
 *   back to caller-supplied safe wording.
 */
object CloudAuthErrors {

    /**
     * Returns a short description of the configuration problem, or
     * null when the account backend configuration is usable: an
     * https endpoint that is not a documentation placeholder, and a
     * public key present.
     */
    fun configurationError(endpoint: String?, hasPublicKey: Boolean): String? {
        val url = endpoint?.trim().orEmpty()
        if (url.isBlank()) return "The account service is not configured in this build."
        if (!url.startsWith("https://", ignoreCase = true)) {
            return "The account service address is not secure (https required)."
        }
        if (url.contains("your-project", ignoreCase = true)) {
            return "The account service address is still a placeholder."
        }
        if (!hasPublicKey) return "The account service key is missing in this build."
        return null
    }

    /**
     * Maps an auth HTTP failure to safe display text. [body] is the
     * raw provider response; [fallback] is returned whenever nothing
     * specific and safe can be said.
     */
    fun responseMessage(code: Int, body: String?, fallback: String): String {
        // Status-only diagnoses first: these hold even with an empty
        // or unreadable body, and must never be misreported as a
        // credentials problem.
        if (code == 429) return "Too many attempts. Please wait a bit and try again."
        if (code == 503) return "The account service is temporarily unavailable. Please try again later."
        if (code == 404) return "The account endpoint was not found. Please try again later."

        val message = plainMessage(body)
        val haystack = listOfNotNull(message, body).joinToString(" ")

        if (code == 401 && haystack.contains("invalid api key", ignoreCase = true)) {
            return "The app's API configuration was rejected by the account server — " +
                "this is not an account password problem. Please update the app."
        }
        if (haystack.contains("email_not_confirmed", ignoreCase = true) ||
            haystack.contains("email not confirmed", ignoreCase = true)
        ) {
            return "Please verify your email first — check your inbox."
        }
        if (message != null) {
            when {
                message.contains("invalid login credentials", ignoreCase = true) -> return fallback
                message.contains("already registered", ignoreCase = true) ||
                    message.contains("already been registered", ignoreCase = true) ->
                    return "An account with this email already exists. Try signing in."
                message.contains("password should be at least", ignoreCase = true) -> return message
            }
        }
        return fallback
    }

    /** The provider's "message" only when it is a plain string; a structured or malformed body yields null. */
    private fun plainMessage(body: String?): String? {
        val text = body?.trim().orEmpty()
        if (!text.startsWith("{")) return null
        return try {
            val json = JSONObject(text)
            (json.opt("message") as? String)?.ifBlank { null }
                ?: (json.opt("msg") as? String)?.ifBlank { null }
                ?: (json.opt("error_description") as? String)?.ifBlank { null }
        } catch (e: Exception) {
            null
        }
    }
}
