package com.pulsestream.app.data

import android.animation.ValueAnimator
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Motion preference — ONE control, two historical stores (v0.14.39,
 * settings audit D2).
 *
 * Before this build there were two switches that could disagree:
 * Settings → Appearance's "Animations" chips wrote
 * [SettingsStore.animations] ("Full"/"Reduced"), while the old
 * Settings root's "Reduced motion" toggle wrote this object's
 * legacy `plavio_accessibility/reduced_motion` key. The audit's
 * rule: merge to a single control. The Appearance chips are the
 * surviving control; every write now funnels through
 * [setAnimationsMode] / [setReduced] here, which keep both stores
 * in step, so the pair can never drift again. [initialize] runs
 * the one-time migration: if EITHER store said "calm" at upgrade,
 * calm wins.
 */
object MotionPreferences {
    private val mutableReduced = MutableStateFlow(false)
    val reduced: StateFlow<Boolean> = mutableReduced

    private fun legacyPrefs(context: Context) =
        context.getSharedPreferences("plavio_accessibility", Context.MODE_PRIVATE)

    fun initialize(context: Context) {
        val legacy = legacyPrefs(context).getBoolean("reduced_motion", false)
        val store = SettingsStore(context)
        // Migration: a calm choice in either store wins, once.
        if (legacy && store.animations != "Reduced") {
            store.animations = "Reduced"
        }
        val merged = store.animations == "Reduced"
        if (merged != legacy) {
            legacyPrefs(context).edit().putBoolean("reduced_motion", merged).apply()
        }
        mutableReduced.value = merged
    }

    /** The single write path for the merged control. */
    fun setAnimationsMode(context: Context, mode: String) {
        val normalized = if (mode in ANIMATION_OPTIONS) mode else "Full"
        SettingsStore(context).animations = normalized
        val isReduced = normalized == "Reduced"
        legacyPrefs(context).edit().putBoolean("reduced_motion", isReduced).apply()
        mutableReduced.value = isReduced
    }

    fun setReduced(context: Context, value: Boolean) =
        setAnimationsMode(context, if (value) "Reduced" else "Full")

    fun animationsEnabled(): Boolean = !reduced.value && ValueAnimator.areAnimatorsEnabled()
}

@Composable
fun rememberReducedMotion(): Boolean {
    val reduced by MotionPreferences.reduced.collectAsState()
    return reduced || !ValueAnimator.areAnimatorsEnabled()
}
