package com.pulsestream.app.data

import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Fire-and-forget client for the PlavioHD /warm endpoint (v0.14.28;
 * server contract PlavioHD v1.9.128 — see [WarmSupport]).
 *
 * A warm call exists only to make the SERVER start filling a title
 * early; the response carries nothing the app needs, so:
 *
 *  - the request rides OkHttp's async enqueue — the calling thread or
 *    coroutine never waits for it, and no result ever comes back;
 *  - every outcome (any HTTP status, any transport failure) is
 *    swallowed by design;
 *  - timeouts are short: a warm that has not landed in a few seconds
 *    has missed its moment, and the title's own stream fetch will
 *    drive the same server fill anyway;
 *  - each target fires at most once per app session ([WarmLedger]).
 *
 * Deliberately NOT routed through [BoundedHttp]: that transport is
 * built for answers the app reads (bounded body, success required,
 * the shared 18 s profile and the process-wide permit pool). A warm
 * has no answer to read and must never queue behind real fetches.
 */
internal object PlavioWarm {

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(6, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val ledger = WarmLedger()

    /**
     * Asks the server at [baseUrl] to start caching [target] and
     * returns immediately. A null/blank base (PlavioHD not installed)
     * skips silently WITHOUT spending the session dedupe — if the
     * addon appears later in the session the title can still warm.
     */
    fun warm(baseUrl: String?, target: WarmSupport.WarmTarget) {
        val base = baseUrl?.trim()?.takeIf { it.isNotEmpty() } ?: return
        if (!ledger.markIfNew(target)) return
        val request = try {
            Request.Builder().url(WarmSupport.warmUrl(base, target)).get().build()
        } catch (_: Exception) {
            return
        }
        try {
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // Swallowed by design: a warm that fails changes nothing.
                }

                override fun onResponse(call: Call, response: Response) {
                    response.close() // The body is intentionally never read.
                }
            })
        } catch (_: Exception) {
            // A warm call must never surface an error anywhere.
        }
    }

    /**
     * Claims [key] (a settled search query's identity) for this
     * session: true exactly once, so a query's top results warm once
     * per session however often the search re-settles.
     */
    fun claimQuery(key: String): Boolean = ledger.markIfNew("query|$key")
}
