package com.pulsestream.app.data

import android.content.Context
import android.content.SharedPreferences

/**
 * The user's OWN ratings (v0.14.40, item 11): 1–10 stars, keyed
 * by the title's IMDb id (falling back to its meta id when no tt
 * id exists). This is the on-device floor: a rating set here
 * always sticks on this device, Trakt-connected or not. When
 * Trakt IS connected the same value is also pushed there (see
 * TrackingWrites.traktSetRating), and the caller labels it
 * "Synced to Trakt" only when that push succeeded.
 *
 * v0.14.41 (owner's pick): ratings are set from the END-OF-PLAY
 * prompt in the player — the Details row is gone. This store
 * also counts that prompt's per-title/episode skips.
 *
 * SharedPreferences, like EpisodeNotifyStore: tiny sync state, no
 * schema migration.
 */
class UserRatingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The user's rating for [key] (1–10), or 0 when unrated. */
    fun ratingFor(key: String): Int = prefs.getInt(key, 0).coerceIn(0, 10)

    /** Record (or clear, with 0) the user's rating for [key]. */
    fun setRating(key: String, rating: Int) {
        if (rating <= 0) {
            prefs.edit().remove(key).apply()
        } else {
            prefs.edit().putInt(key, rating.coerceIn(1, 10)).apply()
        }
    }

    // ---- End-of-play prompt dismissals (v0.14.41) ----
    // The rating prompt moved off Details to the end of playback
    // (owner's pick). Its keys are per title (movies) or per
    // EPISODE (series: "<showKey>:S<s>E<e>"): after two skips for
    // the same key the prompt stays quiet for that title/episode.
    // Stored under a prefix inside the same prefs file, so a
    // prompt key can never collide with a rating key.

    /** How many times the end-of-play prompt was skipped for [promptKey]. */
    fun promptSkipCount(promptKey: String): Int =
        prefs.getInt(SKIP_PREFIX + promptKey, 0).coerceAtLeast(0)

    /** Record one skip of the end-of-play prompt for [promptKey]. */
    fun notePromptSkip(promptKey: String) {
        prefs.edit()
            .putInt(SKIP_PREFIX + promptKey, promptSkipCount(promptKey) + 1)
            .apply()
    }

    private companion object {
        const val PREFS = "user_ratings"
        const val SKIP_PREFIX = "prompt_skips:"
    }
}
