package com.pulsestream.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * MDBList API client (v0.14.6) — the third tracking service, linked with
 * the user's own API key (Settings → Integrations).
 *
 * Powers: the detail page's hero ratings row, the IMDb
 * chip on poster cards, and the user's own lists in the Library and in
 * the add-to-list sheet — including creating NEW lists, the gap Trakt
 * and Simkl leave open (research report §1).
 *
 * Endpoints: https://mdblist.com/api/ — ratings via ?i=<imdb id>,
 * lists under /lists/. Every failure throws with a readable message;
 * callers surface it — nothing fails silently.
 */
class MdbListApi(private val apiKey: String) {

    companion object {
        private const val BASE = "https://mdblist.com/api"
        private val JSON = "application/json; charset=utf-8".toMediaType()

        /** The rating sources whose key/label pair is fixed (item 29, 2026-10-28). */
        private val KNOWN_KEYS = setOf(
            "imdb", "tmdb", "trakt", "letterboxd",
            "rt_critics", "rt_audience", "metacritic", "myanimelist"
        )

        /** Display label for a normalized source key (item 29, 2026-10-28). */
        fun labelFor(key: String): String = when (key) {
            "imdb" -> "IMDb"
            "tmdb" -> "TMDB"
            "trakt" -> "Trakt"
            "letterboxd" -> "Letterboxd"
            "rt_critics" -> "Rotten Tomatoes"
            "rt_audience" -> "RT Audience"
            "metacritic" -> "Metacritic"
            "myanimelist" -> "MyAnimeList"
            else -> key.replaceFirstChar { it.uppercase() }
        }

        /**
         * Normalized source identity for an API "source" string
         * (already lowercased by the caller). Unknown sources collapse
         * to their lowercase alphanumeric form.
         */
        private fun sourceKeyFor(source: String): String = when {
            source == "imdb" -> "imdb"
            source.contains("tomatoes") && source.contains("audience") -> "rt_audience"
            source.contains("tomatoes") || source.contains("rottentomatoes") -> "rt_critics"
            source.contains("metacritic") || source.contains("metascore") -> "metacritic"
            source == "trakt" -> "trakt"
            source.contains("letterboxd") -> "letterboxd"
            source.contains("themoviedb") || source.contains("tmdb") -> "tmdb"
            source.contains("myanimelist") -> "myanimelist"
            else -> source.filter { it.isLetterOrDigit() }
        }

        /** Label for one parsed entry: the fixed label for known keys, else the raw source title-cased. */
        private fun labelForSource(key: String, rawSource: String): String {
            if (key in KNOWN_KEYS) return labelFor(key)
            val titled = rawSource.split(Regex("[^A-Za-z0-9]+"))
                .filter { it.isNotEmpty() }
                .joinToString(" ") { word ->
                    word.lowercase().replaceFirstChar { it.uppercase() }
                }
            return titled.ifBlank { labelFor(key) }
        }

        /** Decimal text with trailing zeros trimmed: 8.70 → "8.7", 5.0 → "5". */
        private fun formatDecimal(value: Double): String {
            val raw = value.toString()
            return if (raw.contains('.')) raw.trimEnd('0').trimEnd('.') else raw
        }

        /** Letterboxd-scale text: one decimal when fractional (4.3), plain when whole (5). */
        private fun formatLetterboxd(value: Double): String =
            if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)

        /** Exactly one decimal: 8.0 → "8.0" (TMDB / MyAnimeList strip values). */
        private fun formatOneDecimal(value: Double): String = "%.1f".format(value)
    }

    /** One rating source exactly as MDBList returned it (item 29, 2026-10-28). */
    data class SourceRating(val key: String, val label: String, val text: String)

    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    data class Ratings(
        val imdb: Double? = null,
        val rtCritics: Int? = null,
        val rtAudience: Int? = null,
        val metascore: Int? = null,
        val trakt: Int? = null,
        val letterboxd: Double? = null,
        /**
         * EVERY source the API returned, in response order (item 29,
         * owner's order 2026-10-28) — including the ones with no typed
         * field above (TMDB, MyAnimeList, anything new MDBList adds).
         * Powers the small ratings strip on Home poster cards; the
         * typed fields keep serving the detail page as before.
         */
        val sources: List<SourceRating> = emptyList()
    ) {
        val isEmpty: Boolean
            get() = imdb == null && rtCritics == null && rtAudience == null &&
                metascore == null && trakt == null && letterboxd == null &&
                sources.isEmpty()
    }

    data class MdbListInfo(val id: String, val name: String, val itemCount: Int = -1)

    data class MdbListItem(val type: String, val imdbId: String, val title: String)

    data class WriteResult(val ok: Boolean, val message: String)

    private fun errorMessage(code: Int): String = when (code) {
        401, 403 -> "MDBList didn't accept that API key — check it in Settings → Integrations."
        429 -> "MDBList is rate-limiting — wait a moment and try again."
        -1 -> "Couldn't reach MDBList. Check your connection and try again."
        else -> "MDBList didn't accept that (HTTP $code)."
    }

    private suspend fun getText(path: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        val sep = if (path.contains('?')) "&" else "?"
        val request = Request.Builder()
            .url("$BASE$path${sep}apikey=$apiKey")
            .header("Accept", "application/json")
            .get()
            .build()
        try {
            client.newCall(request).execute().use { response ->
                response.code to (response.body?.string().orEmpty())
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            -1 to ""
        }
    }

    private suspend fun postJson(path: String, body: JSONObject): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            val sep = if (path.contains('?')) "&" else "?"
            val request = Request.Builder()
                .url("$BASE$path${sep}apikey=$apiKey")
                .header("Accept", "application/json")
                .post(body.toString().toRequestBody(JSON))
                .build()
            try {
                client.newCall(request).execute().use { response ->
                    response.code to (response.body?.string().orEmpty())
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                -1 to ""
            }
        }

    /** Ratings for one IMDb id. Null when MDBList has nothing for it. */
    suspend fun ratings(imdbId: String): Ratings? {
        if (!imdbId.startsWith("tt")) return null
        val (code, text) = getText("/?i=$imdbId")
        if (code !in 200..299) throw IllegalStateException(errorMessage(code))
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return null
        val arr = root.optJSONArray("ratings") ?: return null
        var out = Ratings()
        // Raw entries in response order for the sources strip (item
        // 29): (normalized key, original source string, raw value).
        val rawEntries = mutableListOf<Triple<String, String, Double>>()
        for (i in 0 until arr.length()) {
            val node = arr.optJSONObject(i) ?: continue
            val sourceRaw = node.optString("source")
            val source = sourceRaw.lowercase()
            // MDBList returns most values as JSON numbers, but some
            // sources arrive as strings — accept both, else the score
            // silently vanishes.
            val value: Number = when (val raw = node.opt("value")) {
                is Number -> raw
                is String -> raw.trim().toDoubleOrNull() ?: continue
                else -> continue
            }
            val sourceKey = sourceKeyFor(source)
            if (sourceKey.isNotEmpty()) {
                rawEntries += Triple(sourceKey, sourceRaw, value.toDouble())
            }
            out = when {
                source == "imdb" -> out.copy(imdb = value.toDouble())
                source.contains("tomatoes") && source.contains("audience") ->
                    out.copy(rtAudience = value.toInt())
                source.contains("tomatoes") || source.contains("rottentomatoes") ->
                    out.copy(rtCritics = value.toInt())
                source.contains("metacritic") || source.contains("metascore") -> {
                    // MDBList can carry TWO Metacritic-flavoured
                    // entries: the 0–100 Metascore and a 0–10-scale
                    // score. The old parser let the later entry win,
                    // so a 5.x overwrote the real Metascore and the
                    // detail page showed "Metascore 5" (v0.14.7).
                    // The 0–100 value is the Metascore: once one is
                    // held, a small-scale entry never replaces it.
                    val v = value.toInt()
                    val cur = out.metascore
                    out.copy(metascore = when {
                        cur == null -> v
                        cur >= 10 -> cur
                        v >= 10 -> v
                        else -> cur
                    })
                }
                source == "trakt" -> out.copy(trakt = value.toInt())
                source.contains("letterboxd") -> out.copy(letterboxd = value.toDouble())
                else -> out
            }
        }
        // Build the strip's source list from the FINAL typed values
        // wherever a typed field exists — so the Metacritic 0–100 vs
        // 0–10 disambiguation above applies here too and the
        // small-scale duplicate never reaches the strip. Untyped
        // sources (TMDB, MyAnimeList, unknowns) format their raw
        // value. First occurrence wins the position; duplicates of a
        // key are emitted once.
        val emitted = mutableSetOf<String>()
        val sources = mutableListOf<SourceRating>()
        for ((key, rawSource, rawValue) in rawEntries) {
            if (!emitted.add(key)) continue
            val text = when (key) {
                "imdb" -> out.imdb?.let { formatDecimal(it) }
                "rt_critics" -> out.rtCritics?.let { "$it%" }
                "rt_audience" -> out.rtAudience?.let { "$it%" }
                "metacritic" -> out.metascore?.let { "$it%" }
                "trakt" -> out.trakt?.let { "$it%" }
                "letterboxd" -> out.letterboxd?.let { formatLetterboxd(it) }
                "tmdb", "myanimelist" -> formatOneDecimal(rawValue)
                else -> formatDecimal(rawValue)
            } ?: continue
            sources += SourceRating(key, labelForSource(key, rawSource), text)
        }
        out = out.copy(sources = sources)
        return out.takeIf { !it.isEmpty }
    }

    /** The user's own MDBList lists. Throws on failure. */
    suspend fun lists(): List<MdbListInfo> {
        val (code, text) = getText("/lists/user")
        if (code !in 200..299) throw IllegalStateException(errorMessage(code))
        val nodes: List<JSONObject> = when {
            text.trimStart().startsWith("[") -> {
                val arr = JSONArray(text)
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            }
            else -> {
                val root = JSONObject(text)
                val arr = root.optJSONArray("lists") ?: root.optJSONArray("results")
                    ?: return emptyList()
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            }
        }
        return nodes.mapNotNull { node ->
            val id = node.optString("id").takeIf { it.isNotBlank() }
                ?: node.optInt("id", 0).takeIf { it > 0 }?.toString()
                ?: return@mapNotNull null
            MdbListInfo(
                id = id,
                name = node.optString("name", "List"),
                itemCount = node.optInt("item_count", node.optInt("items_count", -1))
            )
        }
    }

    /** Items of one list, IMDb-keyed. Throws on failure. */
    suspend fun listItems(listId: String): List<MdbListItem> {
        val (code, text) = getText("/lists/$listId/items")
        if (code !in 200..299) throw IllegalStateException(errorMessage(code))
        val nodes: List<JSONObject> = when {
            text.trimStart().startsWith("[") -> {
                val arr = JSONArray(text)
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            }
            else -> {
                val root = JSONObject(text)
                val arr = root.optJSONArray("items") ?: root.optJSONArray("results")
                    ?: return emptyList()
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            }
        }
        return nodes.mapNotNull { node ->
            val imdb = node.optString("imdb_id").takeIf { it.startsWith("tt") }
                ?: node.optJSONObject("ids")?.optString("imdb")?.takeIf { it.startsWith("tt") }
                ?: return@mapNotNull null
            val rawType = node.optString("mediatype", node.optString("type", "movie"))
            MdbListItem(
                type = if (rawType.contains("show") || rawType == "series" || rawType == "tv") "series" else "movie",
                imdbId = imdb,
                title = node.optString("title", node.optString("name", ""))
            )
        }
    }

    /** Creates a new list on the user's MDBList account. */
    suspend fun createList(name: String): WriteResult {
        val body = JSONObject().put("name", name.trim())
        val (code, text) = postJson("/lists/create", body)
        if (code !in 200..299) return WriteResult(false, errorMessage(code))
        val root = runCatching { JSONObject(text) }.getOrNull()
        val createdName = root?.optJSONObject("list")?.optString("name")
            ?: root?.optString("name")
        return WriteResult(true, "Created “${createdName ?: name.trim()}” on MDBList.")
    }

    private fun itemsBody(items: List<MdbListItem>): JSONObject {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject()
                    .put("imdb_id", item.imdbId)
                    .put("mediatype", if (item.type == "series") "show" else "movie")
            )
        }
        return JSONObject().put("items", arr)
    }

    suspend fun addItems(listId: String, listName: String, items: List<MdbListItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to add.")
        val (code, _) = postJson("/lists/$listId/items/add", itemsBody(items))
        return if (code in 200..299) WriteResult(true, "Added to “$listName” on MDBList.")
        else WriteResult(false, errorMessage(code))
    }

    suspend fun removeItems(listId: String, listName: String, items: List<MdbListItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to remove.")
        val (code, _) = postJson("/lists/$listId/items/remove", itemsBody(items))
        return if (code in 200..299) WriteResult(true, "Removed from “$listName” on MDBList.")
        else WriteResult(false, errorMessage(code))
    }
}
