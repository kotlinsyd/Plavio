package com.pulsestream.app.data

/**
 * Pure helpers for the PlavioHD warm triggers (v0.14.28, owner's
 * order 2026-10-31: "When someone searches a title, or someone clicks
 * on a catalog card title, it should start caching the title for
 * quick loading"). Server contract (PlavioHD v1.9.128):
 *
 *   GET {plavioHdBase}/warm/{type}/{imdbId}.json[?season=N&episode=M]
 *
 * type is movie|series, the id must be an IMDb tt id, and a series
 * ask without season/episode warms S01E01. The call is
 * fire-and-forget — the answer (or failure) means nothing to the app;
 * the point is only that the server starts its fill early.
 *
 * Everything here is free of Android and Room types so the unit tests
 * pin the exact rules the live triggers use: id/type validation, URL
 * shape, the settled-search top-N selection, and session dedupe.
 */
internal object WarmSupport {

    /** Manifest id of the public PlavioHD addon — the server that
     *  implements /warm. (The locked addon.plavio.site carries a
     *  different manifest id and is a different server; it must never
     *  be warmed.) */
    const val PLAVIOHD_MANIFEST_ID = "community.plaviohd"

    /** How many settled search results get warmed per query. */
    const val SEARCH_WARM_LIMIT = 5

    private val imdbIdPattern = Regex("^tt\\d+$")

    /** A title the server can be asked to warm. */
    data class WarmTarget(
        val type: String,
        val imdbId: String,
        val season: Int? = null,
        val episode: Int? = null
    ) {
        /**
         * Session-dedupe identity. For series the EFFECTIVE episode
         * is used — an omitted pair means S01E01 (the server default),
         * so the Detail-open warm (no pair) and the presented-episode
         * warm (explicit 1/1) are the same target and fire only once.
         */
        val key: String
            get() {
                val s = if (type == "series") season ?: 1 else 0
                val e = if (type == "series") episode ?: 1 else 0
                return "$type|$imdbId|$s|$e"
            }
    }

    /** Server warm type for an app-side type string, or null when the
     *  server has no warm route for it. Live "tv" rows never carry tt
     *  ids, so mapping "tv" to "series" only ever affects series metas
     *  that addons filed under the Stremio TV spelling. */
    fun warmType(type: String?): String? = when (type?.trim()?.lowercase()) {
        "movie" -> "movie"
        "series", "tv" -> "series"
        else -> null
    }

    /**
     * Builds a target from raw parts, or null when the title cannot be
     * warmed: no IMDb tt id (TMDB-only rows simply don't warm) or an
     * unmappable type. A season/episode pair is kept only when BOTH
     * are positive; a half or non-positive pair collapses to the
     * server default (S01E01) instead of producing a malformed ask,
     * and movies never carry a pair.
     */
    fun target(
        type: String?,
        imdbId: String?,
        season: Int? = null,
        episode: Int? = null
    ): WarmTarget? {
        val warmType = warmType(type) ?: return null
        val id = imdbId?.trim()?.lowercase()?.takeIf { imdbIdPattern.matches(it) }
            ?: return null
        val s = season?.takeIf { it > 0 }
        val e = episode?.takeIf { it > 0 }
        return if (warmType == "series" && s != null && e != null) {
            WarmTarget(warmType, id, s, e)
        } else {
            WarmTarget(warmType, id)
        }
    }

    /** The exact request URL for [target] under an addon [baseUrl]. */
    fun warmUrl(baseUrl: String, target: WarmTarget): String {
        val base = baseUrl.trim().trimEnd('/')
        val url = "$base/warm/${target.type}/${target.imdbId}.json"
        return if (target.season != null && target.episode != null) {
            "$url?season=${target.season}&episode=${target.episode}"
        } else {
            url
        }
    }

    /**
     * The settled-search selection: the first [limit] ranked survivors
     * that carry an IMDb tt id, in ranked order. TMDB-keyed and
     * opaque-addon-keyed rows are skipped (they cannot be warmed), and
     * duplicate tt ids collapse.
     */
    fun selectSearchTargets(
        results: List<CachedMeta>,
        limit: Int = SEARCH_WARM_LIMIT
    ): List<WarmTarget> {
        if (limit <= 0) return emptyList()
        val seen = HashSet<String>()
        val out = ArrayList<WarmTarget>(limit)
        for (item in results) {
            val target = target(item.meta.type, item.meta.id) ?: continue
            if (!seen.add(target.imdbId)) continue
            out += target
            if (out.size >= limit) break
        }
        return out
    }
}

/**
 * Session-scope dedupe for warm calls: each key warms at most once
 * per app process. Bounded, oldest-first eviction, so a long session
 * of episode browsing cannot grow it without limit. Deliberately NOT
 * persisted — a fresh process may warm again, and the server's own
 * in-flight fill dedupe makes a repeat harmless.
 */
internal class WarmLedger(private val maxEntries: Int = 512) {
    private val seen = LinkedHashSet<String>()

    /** True exactly once per key: the caller should fire the warm. */
    @Synchronized
    fun markIfNew(key: String): Boolean {
        if (!seen.add(key)) return false
        while (seen.size > maxEntries) {
            seen.remove(seen.iterator().next())
        }
        return true
    }

    fun markIfNew(target: WarmSupport.WarmTarget): Boolean = markIfNew(target.key)

    @Synchronized
    fun clear() = seen.clear()
}
