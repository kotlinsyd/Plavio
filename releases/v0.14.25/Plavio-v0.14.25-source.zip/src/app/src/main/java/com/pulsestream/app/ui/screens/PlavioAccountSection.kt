package com.pulsestream.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.cloud.PlavioAccountManager
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.OrbitDots
import com.pulsestream.app.ui.components.ProfileAvatarImage
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Plavio account section (owner's order + approved samples 2026-10-25):
 * email + password sign-in; the email code is only for password resets.
 * Since v0.14.6 this is the ONLY sign-in door — Google sign-in and
 * Drive sync were removed; this account syncs the same full backup.
 * Renders nothing until the backend is configured.
 */
@Composable
fun PlavioAccountSection(
    repository: StreamRepository,
    onChangePicture: () -> Unit = {},
    onAccountChanged: () -> Unit = {}
) {
    if (!PlavioAccountManager.isConfigured()) return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val manager = remember { PlavioAccountManager(context, repository) }
    val palette = LocalPalette.current

    var mode by remember {
        mutableStateOf(if (manager.isSignedIn()) Mode.SignedIn else Mode.SignIn)
    }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var showConfirm by rememberSaveable { mutableStateOf(false) }
    var showResetPassword by rememberSaveable { mutableStateOf(false) }
    var resetCode by remember { mutableStateOf("") }
    var resendIn by remember { mutableStateOf(0) }
    var refreshTick by remember { mutableStateOf(0) }
    // v0.14.19: the guarded Backup asks before an emptier local
    // payload may replace a fuller cloud backup.
    var confirmOverwrite by remember { mutableStateOf(false) }
    val signedEmail = remember(refreshTick) { manager.accountEmail() }.orEmpty()
    val accountUsername = remember(refreshTick) { manager.accountUsername() }
    val lastSync = remember(refreshTick) { manager.lastSyncTime() }
    // Sign-up username field (owner's order 2026-10-31, corrected same
    // evening: username only — no name field anywhere).
    var username by remember { mutableStateOf("") }

    LaunchedEffect(resendIn) {
        if (resendIn > 0) {
            delay(1000)
            resendIn--
        }
    }

    fun fail(e: Throwable) {
        busy = false
        error = e.message ?: "Something went wrong. Please try again."
    }

    // Keep the local profile copy in step with the account (the name /
    // username may have been set on another device).
    LaunchedEffect(mode) {
        if (mode == Mode.SignedIn) {
            manager.refreshProfile()
            refreshTick++
        }
    }

    fun afterAuth() {
        scope.launch {
            manager.syncAfterSignIn()
                .onSuccess { restored ->
                    busy = false
                    notice = null
                    mode = if (restored) Mode.WelcomeBack else Mode.SignedIn
                    refreshTick++
                    onAccountChanged()
                }
                .onFailure {
                    // The sign-in itself SUCCEEDED — only the restore /
                    // sync step failed. Never present that as a sign-in
                    // failure (owner's order 2026-10-31, his reinstall
                    // screenshot): land on the account screen with a
                    // plain notice instead of the form error.
                    busy = false
                    error = null
                    notice = "Signed in. Your cloud backup couldn't be restored, " +
                        "so nothing was imported — your next backup will replace it."
                    mode = Mode.SignedIn
                    refreshTick++
                    onAccountChanged()
                }
        }
    }

    if (mode == Mode.SignedIn) {
        // v0.14.19: manual Backup + Restore (owner's order
        // 2026-10-29). Backup runs the guarded upload — an emptier
        // local payload asks first (confirmOverwrite dialog below);
        // Restore pulls the cloud backup down and arms the
        // restore-verified flag inside the manager.
        fun runBackup(force: Boolean) {
            error = null
            busy = true
            scope.launch {
                when (val outcome = manager.backupNow(force = force)) {
                    is PlavioAccountManager.BackupOutcome.Uploaded -> {
                        busy = false
                        notice = "Backed up just now."
                        refreshTick++
                    }
                    is PlavioAccountManager.BackupOutcome.NeedsConfirmation -> {
                        busy = false
                        confirmOverwrite = true
                    }
                    is PlavioAccountManager.BackupOutcome.Failed -> {
                        busy = false
                        error = outcome.message
                    }
                }
            }
        }
        if (confirmOverwrite) {
            AlertDialog(
                onDismissRequest = { confirmOverwrite = false },
                title = { Text("Replace cloud backup?") },
                text = {
                    Text(
                        "This device has less saved than your cloud backup. " +
                            "Backing up now will replace the fuller cloud backup " +
                            "with this device's data."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        confirmOverwrite = false
                        runBackup(force = true)
                    }) { Text("Back up anyway") }
                },
                dismissButton = {
                    TextButton(onClick = { confirmOverwrite = false }) { Text("Cancel") }
                }
            )
        }
        PlavioSignedInC(
            repository = repository,
            busy = busy,
            signedEmail = signedEmail,
            accountUsername = accountUsername,
            onSaveProfile = { u ->
                error = null
                busy = true
                scope.launch {
                    manager.updateProfile(u)
                        .onSuccess {
                            busy = false
                            notice = "Profile saved."
                            refreshTick++
                        }
                        .onFailure { fail(it) }
                }
            },
            lastSync = lastSync,
            notice = notice,
            error = error,
            onBackup = { runBackup(force = false) },
            onRestore = {
                error = null
                busy = true
                scope.launch {
                    manager.restoreFromAccount()
                        .onSuccess { restored ->
                            busy = false
                            notice = if (restored) "Backup restored."
                                else "No cloud backup found yet."
                            refreshTick++
                            onAccountChanged()
                        }
                        .onFailure { fail(it) }
                }
            },
            onChangePassword = { newPassword, done ->
                error = null
                scope.launch {
                    manager.changePassword(newPassword)
                        .onSuccess { done(null) }
                        .onFailure { done(it.message) }
                }
            },
            onDeleteAccount = { password, done ->
                error = null
                scope.launch {
                    manager.deleteAccount(password)
                        .onSuccess {
                            done(null)
                            mode = Mode.SignIn
                            notice = "Your account and all its data were deleted."
                            refreshTick++
                            onAccountChanged()
                        }
                        .onFailure { done(it.message) }
                }
            },
            onSignOut = {
                scope.launch {
                    manager.signOut()
                    mode = Mode.SignIn
                    notice = null
                    refreshTick++
                    onAccountChanged()
                }
            },
            onChangePicture = onChangePicture
        )
        return
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (mode) {
                Mode.SignIn, Mode.Create -> {
                    Text(
                        if (mode == Mode.SignIn) "Welcome to Plavio" else "Create your account",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        if (mode == Mode.SignIn) {
                            "Sign in to sync your library, progress and addons on every device."
                        } else {
                            "We'll never share your email."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it.trim() },
                        label = { Text("Email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            PasswordVisibilityToggle(showPassword) { showPassword = !showPassword }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (mode == Mode.Create) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it.trim() },
                            label = { Text("Username") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = confirm,
                            onValueChange = { confirm = it },
                            label = { Text("Confirm password") },
                            singleLine = true,
                            visualTransformation = if (showConfirm) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingIcon = {
                                PasswordVisibilityToggle(showConfirm) { showConfirm = !showConfirm }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        PasswordRules(password)
                    }
                    if (mode == Mode.SignIn) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                            TextButton(
                                onClick = {
                                    error = null
                                    mode = Mode.ResetRequest
                                },
                                enabled = !busy
                            ) { Text("Forgot password?") }
                        }
                    }
                    Button(
                        onClick = {
                            error = null
                            notice = null
                            if (mode == Mode.SignIn) {
                                busy = true
                                scope.launch {
                                    manager.signIn(email, password)
                                        .onSuccess { afterAuth() }
                                        .onFailure { fail(it) }
                                }
                            } else {
                                when {
                                    password.length < 8 -> error = "Password needs at least 8 characters."
                                    password != confirm -> error = "Passwords don't match."
                                    else -> {
                                        busy = true
                                        scope.launch {
                                            manager.signUp(email, password, username)
                                                .onSuccess { sessionNow ->
                                                    if (sessionNow) {
                                                        afterAuth()
                                                    } else {
                                                        busy = false
                                                        mode = Mode.SignIn
                                                        notice = "Account created — check your email to confirm it, then sign in."
                                                    }
                                                }
                                                .onFailure { fail(it) }
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !busy && email.contains("@") && password.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (busy) {
                            OrbitDots(modifier = Modifier.size(20.dp))
                        } else {
                            Text(if (mode == Mode.SignIn) "Sign in" else "Create account")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (mode == Mode.SignIn) "New here?" else "Already have an account?",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        TextButton(
                            onClick = {
                                error = null
                                notice = null
                                mode = if (mode == Mode.SignIn) Mode.Create else Mode.SignIn
                            },
                            enabled = !busy
                        ) {
                            Text(if (mode == Mode.SignIn) "Create account" else "Sign in")
                        }
                    }
                    Text(
                        "Free forever. Your data stays yours.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Mode.ResetRequest -> {
                    Text(
                        "Reset password",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        "Enter your email and we'll email you a code.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it.trim() },
                        label = { Text("Email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            error = null
                            busy = true
                            scope.launch {
                                manager.requestPasswordReset(email)
                                    .onSuccess {
                                        busy = false
                                        resendIn = 60
                                        mode = Mode.ResetVerify
                                    }
                                    .onFailure { fail(it) }
                            }
                        },
                        enabled = !busy && email.contains("@"),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Sending…" else "Send code") }
                    TextButton(
                        onClick = { mode = Mode.SignIn },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Back to sign in") }
                }

                Mode.ResetVerify -> {
                    Text(
                        "Reset password",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        "We emailed a code to $email",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = resetCode,
                        onValueChange = { resetCode = it.filter { c -> c.isDigit() }.take(10) },
                        label = { Text("Code from email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("New password") },
                        singleLine = true,
                        visualTransformation = if (showResetPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            PasswordVisibilityToggle(showResetPassword) { showResetPassword = !showResetPassword }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            error = null
                            busy = true
                            scope.launch {
                                manager.verifyResetAndSetPassword(email, resetCode, password)
                                    .onSuccess {
                                        busy = false
                                        password = ""
                                        resetCode = ""
                                        mode = Mode.SignIn
                                        notice = "Password updated — sign in with your new password."
                                    }
                                    .onFailure { fail(it) }
                            }
                        },
                        enabled = !busy && resetCode.length >= 6 && password.length >= 8,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Saving…" else "Set new password") }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { mode = Mode.SignIn },
                            enabled = !busy
                        ) { Text("Back to sign in") }
                        TextButton(
                            onClick = {
                                error = null
                                scope.launch {
                                    manager.requestPasswordReset(email)
                                        .onSuccess { resendIn = 60 }
                                        .onFailure { error = it.message }
                                }
                            },
                            enabled = !busy && resendIn == 0
                        ) {
                            Text(if (resendIn > 0) "Resend code (0:${"%02d".format(resendIn)})" else "Resend code")
                        }
                    }
                    Text(
                        "Didn't get it? Check your spam folder.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Mode.SignedIn -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(palette.gradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                signedEmail.firstOrNull()?.uppercaseChar()?.toString() ?: "P",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Plavio account",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                signedEmail,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    Text(
                        if (lastSync != null) "Synced · $lastSync" else "Not synced yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Button(
                        onClick = {
                            error = null
                            busy = true
                            scope.launch {
                                manager.syncNow()
                                    .onSuccess {
                                        busy = false
                                        notice = "Synced just now."
                                        refreshTick++
                                    }
                                    .onFailure { fail(it) }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (busy) "Syncing…" else "Sync now")
                    }
                    Text(
                        "What syncs: Library, progress, addons, settings & keys",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    ChangePasswordBlock(
                        busy = busy,
                        onChange = { newPassword, done ->
                            error = null
                            scope.launch {
                                manager.changePassword(newPassword)
                                    .onSuccess { done(null) }
                                    .onFailure { done(it.message) }
                            }
                        }
                    )
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                manager.signOut()
                                mode = Mode.SignIn
                                notice = null
                                refreshTick++
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Sign out")
                    }
                }

                Mode.WelcomeBack -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Check,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Welcome back",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Text(
                        "Everything restored from your account:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    listOf(
                        "Library",
                        "Continue Watching progress",
                        "Addons with your settings",
                        "App settings & API keys"
                    ).forEach { line ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                tint = palette.accent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(line, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    }
                    Button(
                        onClick = { mode = Mode.SignedIn },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Start watching") }
                }
            }

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            notice?.let {
                Text(it, color = palette.accent, style = MaterialTheme.typography.bodySmall)
            }
            if (mode == Mode.SignIn || mode == Mode.Create) {
                Spacer(Modifier.height(2.dp))
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

private enum class Mode { SignIn, Create, ResetRequest, ResetVerify, SignedIn, WelcomeBack }

/** Eye toggle for password fields (same pattern as the API key fields). */
@Composable
private fun PasswordVisibilityToggle(visible: Boolean, onToggle: () -> Unit) {
    IconButton(onClick = onToggle) {
        Icon(
            if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
            contentDescription = if (visible) "Hide password" else "Show password",
            tint = TextSecondary
        )
    }
}

@Composable
private fun PasswordRules(password: String) {
    val rules = listOf(
        "8+ characters" to (password.length >= 8),
        "A number" to password.any { it.isDigit() },
        "A symbol" to password.any { !it.isLetterOrDigit() }
    )
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        rules.forEach { (label, ok) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = null,
                    tint = if (ok) LocalPalette.current.accent else TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    label,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (ok) TextPrimary else TextSecondary
                )
            }
        }
    }
}

@Composable
private fun ChangePasswordBlock(
    busy: Boolean,
    onChange: (String, (String?) -> Unit) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    var newPassword by remember { mutableStateOf("") }
    var showNewPassword by rememberSaveable { mutableStateOf(false) }
    var localBusy by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }
    var doneNote by remember { mutableStateOf(false) }
    if (!open) {
        TextButton(
            onClick = { open = true },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Change password") }
        if (doneNote) {
            Text(
                "Password changed.",
                style = MaterialTheme.typography.bodySmall,
                color = LocalPalette.current.accent
            )
        }
        return
    }
    OutlinedTextField(
        value = newPassword,
        onValueChange = { newPassword = it },
        label = { Text("New password") },
        singleLine = true,
        visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            PasswordVisibilityToggle(showNewPassword) { showNewPassword = !showNewPassword }
        },
        modifier = Modifier.fillMaxWidth()
    )
    Button(
        onClick = {
            localBusy = true
            localError = null
            onChange(newPassword) { err ->
                localBusy = false
                if (err == null) {
                    open = false
                    newPassword = ""
                    doneNote = true
                } else {
                    localError = err
                }
            }
        },
        enabled = !localBusy && newPassword.length >= 8,
        modifier = Modifier.fillMaxWidth()
    ) { Text(if (localBusy) "Saving…" else "Update password") }
    localError?.let {
        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

/**
 * Signed-in account area — Sample C "Clean List" (owner's pick
 * 2026-10-25), drawn in the Onyx language: centered identity with a
 * synced pill, then labeled groups of icon rows (the shared settings
 * group structure). Since v0.14.6 this is the only account door.
 */
@Composable
private fun PlavioSignedInC(
    repository: StreamRepository,
    busy: Boolean,
    signedEmail: String,
    accountUsername: String? = null,
    onSaveProfile: (String) -> Unit = {},
    lastSync: String?,
    notice: String?,
    error: String?,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onChangePassword: (String, (String?) -> Unit) -> Unit,
    onDeleteAccount: (String, (String?) -> Unit) -> Unit,
    onSignOut: () -> Unit,
    onChangePicture: () -> Unit
) {
    val palette = LocalPalette.current
    val settings = repository.settings
    val profileName = settings.profileUserName
    // Identity: the ACCOUNT username is the headline when one is set
    // (owner's report 2026-10-31 — it must replace the old name, not
    // sit under it); otherwise the device profile name.
    val displayName = accountUsername?.takeIf { it.isNotBlank() }?.let { "@$it" }
        ?: profileName
    var usernameDraft by remember(accountUsername) { mutableStateOf(accountUsername.orEmpty()) }
    var usernameOpen by remember { mutableStateOf(false) }
    // Sync controls (owner's orders 2026-10-29): silent auto-backup on
    // app open + per-category "What to sync" choices. Plain settings —
    // the backup builder reads the same flags, so these are real.
    var autoBackup by remember { mutableStateOf(settings.autoBackupEnabled) }
    var syncSettings by remember { mutableStateOf(settings.syncCatSettings) }
    var syncAddons by remember { mutableStateOf(settings.syncCatAddons) }
    var syncLibrary by remember { mutableStateOf(settings.syncCatLibrary) }
    var syncProgress by remember { mutableStateOf(settings.syncCatProgress) }
    var syncKeys by remember { mutableStateOf(settings.syncCatKeys) }
    var changeOpen by remember { mutableStateOf(false) }
    var newPassword by remember { mutableStateOf("") }
    var showNewPassword by rememberSaveable { mutableStateOf(false) }
    var pwBusy by remember { mutableStateOf(false) }
    var pwError by remember { mutableStateOf<String?>(null) }
    var pwDone by remember { mutableStateOf(false) }
    // Delete account (v0.14.27, batch N5): the row sits in the
    // More group under Sign out; its dialog is the whole
    // verification — re-enter the password, nothing else.
    var deleteOpen by remember { mutableStateOf(false) }
    var deletePassword by remember { mutableStateOf("") }
    var showDeletePassword by rememberSaveable { mutableStateOf(false) }
    var deleteBusy by remember { mutableStateOf(false) }
    var deleteError by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxWidth()) {
        // ---- Centered identity ----
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // v0.14.15: the header avatar IS the profile-picture door —
            // tapping it opens the picture chooser (system photo picker
            // or a preset avatar, saved via SettingsStore's profile
            // photo storage). There is no separate row for it.
            ProfileAvatarImage(
                avatarSetting = settings.profileAvatar,
                photoFile = settings.profilePhotoFile(),
                modifier = Modifier
                    .size(76.dp)
                    .clickable { onChangePicture() },
                placeholderLetter = (profileName.ifBlank { signedEmail })
                    .firstOrNull()?.uppercase()
            )
            Spacer(Modifier.height(10.dp))
            Text(
                displayName.ifBlank { "Plavio account" },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                signedEmail,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(Modifier.height(9.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(lerp(palette.panel, Color.White, 0.10f))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(palette.accent)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (lastSync != null) "Synced \u00b7 $lastSync" else "Not synced yet",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                }
            }
        }

        notice?.let {
            Text(
                it,
                color = palette.accent,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
        error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        // Username editing is a DIALOG behind the Username row below —
        // never an open form sitting on the screen (owner's correction
        // 2026-10-31: "even after creating it, still window is open to
        // edit, which is wrong").
        if (usernameOpen) {
            AlertDialog(
                onDismissRequest = { usernameOpen = false },
                title = { Text("Username") },
                text = {
                    OutlinedTextField(
                        value = usernameDraft,
                        onValueChange = { usernameDraft = it.trim() },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            usernameOpen = false
                            onSaveProfile(usernameDraft)
                        }
                    ) { Text("Save") }
                },
                dismissButton = {
                    TextButton(onClick = { usernameOpen = false }) { Text("Cancel") }
                }
            )
        }

        // Delete-account verification dialog (v0.14.27, batch N5):
        // one tap on the row, then ONLY the password stands between
        // the user and the wipe — no email round-trip, no extra
        // steps (owner's order 2026-11-07).
        if (deleteOpen) {
            AlertDialog(
                onDismissRequest = { if (!deleteBusy) deleteOpen = false },
                title = { Text("Delete account") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "This deletes your Plavio account, your cloud backup, and " +
                                "everything saved on this device — library, progress, " +
                                "addons, settings, keys and downloads. This cannot be undone.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        OutlinedTextField(
                            value = deletePassword,
                            onValueChange = { deletePassword = it },
                            label = { Text("Your password") },
                            singleLine = true,
                            visualTransformation = if (showDeletePassword) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password
                            ),
                            trailingIcon = {
                                PasswordVisibilityToggle(showDeletePassword) {
                                    showDeletePassword = !showDeletePassword
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        deleteError?.let {
                            Text(
                                it,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            deleteBusy = true
                            deleteError = null
                            onDeleteAccount(deletePassword) { err ->
                                deleteBusy = false
                                if (err == null) {
                                    deleteOpen = false
                                    deletePassword = ""
                                } else {
                                    deleteError = err
                                }
                            }
                        },
                        enabled = !deleteBusy && deletePassword.isNotEmpty()
                    ) {
                        Text(
                            if (deleteBusy) "Deleting…" else "Delete everything",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { deleteOpen = false },
                        enabled = !deleteBusy
                    ) { Text("Cancel") }
                }
            )
        }

        // ---- Plavio account group ----
        SettingsSectionHeader("Plavio account")
        SettingsGroup(
            {
                SettingsNavRow(
                    icon = Icons.Filled.AlternateEmail,
                    title = "Username",
                    subtitle = accountUsername?.takeIf { it.isNotBlank() }
                        ?.let { "@$it" } ?: "Add a username",
                    onClick = { usernameOpen = true }
                )
            },
            {
                SettingsNavRow(
                    icon = Icons.Filled.CloudUpload,
                    title = if (busy) "Backing up\u2026" else "Backup",
                    subtitle = if (lastSync != null) "Last backed up $lastSync" else "Upload your library, progress & settings",
                    onClick = onBackup
                )
            },
            {
                SettingsNavRow(
                    icon = Icons.Filled.CloudDownload,
                    title = if (busy) "Restoring\u2026" else "Restore",
                    subtitle = "Bring back the backup saved in your account",
                    onClick = onRestore
                )
            },
            {
                SettingsToggleRow(
                    icon = Icons.Filled.Sync,
                    title = "Auto backup",
                    subtitle = "Back up silently when the app opens",
                    checked = autoBackup,
                    onCheckedChange = { autoBackup = it; settings.autoBackupEnabled = it }
                )
            },
            {
                SettingsNavRow(
                    icon = Icons.Filled.Lock,
                    title = "Change password",
                    subtitle = if (pwDone) "Password changed" else "Keep your account secure",
                    onClick = { changeOpen = !changeOpen }
                )
            }
        )

        // ---- What to sync group ----
        SettingsSectionHeader("What to sync")
        SettingsGroup(
            {
                SettingsToggleRow(
                    icon = Icons.Filled.VideoLibrary,
                    title = "Library & lists",
                    subtitle = "Watchlist, favorites & custom lists",
                    checked = syncLibrary,
                    onCheckedChange = { syncLibrary = it; settings.syncCatLibrary = it }
                )
            },
            {
                SettingsToggleRow(
                    icon = Icons.Filled.Schedule,
                    title = "Watch progress & history",
                    subtitle = "Continue Watching and playback progress",
                    checked = syncProgress,
                    onCheckedChange = { syncProgress = it; settings.syncCatProgress = it }
                )
            },
            {
                SettingsToggleRow(
                    icon = Icons.Filled.Extension,
                    title = "Addons",
                    subtitle = "Installed addons with their configurations",
                    checked = syncAddons,
                    onCheckedChange = { syncAddons = it; settings.syncCatAddons = it }
                )
            },
            {
                SettingsToggleRow(
                    icon = Icons.Filled.Lock,
                    title = "Keys & accounts",
                    subtitle = "TMDB, MDBList, debrid, Trakt & Simkl",
                    checked = syncKeys,
                    onCheckedChange = { syncKeys = it; settings.syncCatKeys = it }
                )
            },
            {
                SettingsToggleRow(
                    icon = Icons.Filled.Settings,
                    title = "App settings",
                    subtitle = "Preferences, appearance & playback options",
                    checked = syncSettings,
                    onCheckedChange = { syncSettings = it; settings.syncCatSettings = it }
                )
            }
        )

        if (changeOpen) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("New password") },
                        singleLine = true,
                        visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            PasswordVisibilityToggle(showNewPassword) { showNewPassword = !showNewPassword }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            pwBusy = true
                            pwError = null
                            onChangePassword(newPassword) { err ->
                                pwBusy = false
                                if (err == null) {
                                    changeOpen = false
                                    newPassword = ""
                                    pwDone = true
                                } else {
                                    pwError = err
                                }
                            }
                        },
                        enabled = !pwBusy && newPassword.length >= 8,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (pwBusy) "Saving\u2026" else "Update password") }
                    pwError?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // ---- More group ----
        // v0.14.15 (owner corrections): NO Profiles row here — Profiles
        // live ONLY behind the Account & Sync top-right corner button.
        // NO "Profile picture" row either — the avatar at the top of
        // this screen is tappable and opens the picture chooser (system
        // photo picker / preset avatars) via onChangePicture.
        SettingsSectionHeader("More")
        SettingsGroup(
            {
                // Sign out — bespoke red row (same grouped geometry).
                Box(Modifier.fillMaxWidth().clickable { onSignOut() }) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color(0xFFF43F5E).copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.Logout,
                                contentDescription = null,
                                tint = Color(0xFFFB7185),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            "Sign out",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFB7185)
                        )
                    }
                }
            },
            {
                // Delete account (v0.14.27, batch N5) — same red-row
                // geometry as Sign out, directly under it. One tap
                // opens the password dialog above; the wipe itself
                // runs in PlavioAccountManager.deleteAccount.
                Box(
                    Modifier.fillMaxWidth().clickable {
                        deleteError = null
                        deletePassword = ""
                        deleteOpen = true
                    }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color(0xFFF43F5E).copy(alpha = 0.14f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = null,
                                tint = Color(0xFFFB7185),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            "Delete account",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFB7185)
                        )
                    }
                }
            }
        )
    }
}
