package com.pulsestream.app.data

/**
 * The language plan for the Search landing's "Popular" section
 * (v0.14.32, owner-locked): how many of the [total] slots each
 * language gets, following the proportions of the user's own
 * search history — [languages] is the original language of each
 * title he searched, most recent first. Floors first, then the
 * leftover goes by largest fractional remainder (ties keep
 * recency order); every language present earns at least one slot
 * when there is room. Keys keep first-seen (recency) order.
 * Pure — unit-tested.
 */
internal fun popularLanguagePlan(languages: List<String>, total: Int): Map<String, Int> {
    if (languages.isEmpty() || total <= 0) return emptyMap()
    val counts = LinkedHashMap<String, Int>()
    for (raw in languages) {
        val lang = raw.trim().lowercase()
        if (lang.isEmpty()) continue
        counts[lang] = (counts[lang] ?: 0) + 1
    }
    if (counts.isEmpty()) return emptyMap()
    val n = counts.values.sum()
    val plan = LinkedHashMap<String, Int>()
    var assigned = 0
    for ((lang, count) in counts) {
        val quota = count * total / n
        plan[lang] = quota
        assigned += quota
    }
    var leftover = total - assigned
    val byRemainder = counts.keys.sortedByDescending { lang ->
        (counts.getValue(lang) * total) % n
    }
    var i = 0
    while (leftover > 0 && byRemainder.isNotEmpty()) {
        val lang = byRemainder[i % byRemainder.size]
        plan[lang] = plan.getValue(lang) + 1
        leftover--
        i++
    }
    // Every present language gets at least one slot when there is
    // room — a single Hindi search in an English week still shows.
    if (total >= counts.size) {
        for (lang in counts.keys) {
            if (plan.getValue(lang) == 0) {
                val donor = plan.maxByOrNull { it.value }?.key ?: break
                if (plan.getValue(donor) <= 1) break
                plan[donor] = plan.getValue(donor) - 1
                plan[lang] = 1
            }
        }
    }
    return plan
}

/**
 * Merges per-language Discover lists into one "Popular" grid
 * (v0.14.32): round-robin across languages in plan order, each
 * contributing up to its [plan] quota; ids are deduped across the
 * whole grid and against [excludeIds] (the "You May Like This"
 * grid above it). When a language runs dry before its quota, its
 * leftover slots flow to the languages that still have titles.
 * Pure — unit-tested.
 */
internal fun mixPopularByLanguage(
    perLanguage: Map<String, List<MetaPreview>>,
    plan: Map<String, Int>,
    excludeIds: Set<String>,
    limit: Int
): List<MetaPreview> {
    if (limit <= 0 || plan.isEmpty()) return emptyList()
    val seen = HashSet(excludeIds)
    val out = ArrayList<MetaPreview>()
    val pointers = HashMap<String, Int>()
    val taken = HashMap<String, Int>()

    fun next(lang: String): MetaPreview? {
        val list = perLanguage[lang].orEmpty()
        var i = pointers[lang] ?: 0
        while (i < list.size) {
            val item = list[i]
            i++
            if (seen.add(item.id)) {
                pointers[lang] = i
                return item
            }
        }
        pointers[lang] = i
        return null
    }

    // Phase 1: round-robin within quotas.
    var progressed = true
    while (out.size < limit && progressed) {
        progressed = false
        for (lang in plan.keys) {
            if (out.size >= limit) break
            if ((taken[lang] ?: 0) >= plan.getValue(lang)) continue
            val item = next(lang) ?: continue
            out.add(item)
            taken[lang] = (taken[lang] ?: 0) + 1
            progressed = true
        }
    }
    // Phase 2: a language that ran dry leaves its quota
    // shortfall behind; ONLY that shortfall flows to the
    // languages that still have titles — the plan's total is
    // never exceeded.
    var shortfall = plan.values.sum() - out.size
    progressed = true
    while (shortfall > 0 && out.size < limit && progressed) {
        progressed = false
        for (lang in plan.keys) {
            if (shortfall <= 0 || out.size >= limit) break
            val item = next(lang) ?: continue
            out.add(item)
            shortfall--
            progressed = true
        }
    }
    return out
}
