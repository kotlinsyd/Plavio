package com.pulsestream.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.AUTOPLAY_QUALITY_OPTIONS
import com.pulsestream.app.data.AUTOPLAY_SIZE_OPTIONS
import com.pulsestream.app.data.QUALITY_ORDER_OPTIONS
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.autoplaySizeName
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.FusionBadgeSource
import com.pulsestream.app.ui.components.FusionBadgeSources
import com.pulsestream.app.ui.components.FusionSourceKind
import com.pulsestream.app.ui.components.addFusionSourceFromText
import com.pulsestream.app.ui.components.addFusionSourceFromUrl
import com.pulsestream.app.ui.components.badgeKeyLabel
import com.pulsestream.app.ui.components.deleteFusionSource
import com.pulsestream.app.ui.components.ensureFusionMigration
import com.pulsestream.app.ui.components.fusionSourceDir
import com.pulsestream.app.ui.components.loadFusionSources
import com.pulsestream.app.ui.components.updateFusionSource
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.tv.tvFocusRing

/**
 * Settings > Streams (v0.8.31+): how the stream picker lists sources and
 * how the Play button auto-picks a stream.
 */
@Composable
fun StreamsSettingsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    val settings = repository.settings
    var qualityOrder by remember { mutableStateOf(settings.qualityOrder) }
    var autoplay by remember { mutableStateOf(settings.streamAutoplay) }
    var autoplayQuality by remember { mutableStateOf(settings.autoplayQuality) }
    var autoplayMaxSize by remember { mutableStateOf(settings.autoplayMaxSizeGb) }
    var qualityPickerOpen by remember { mutableStateOf(false) }
    var sizePickerOpen by remember { mutableStateOf(false) }
    // v0.14.36 (item 3): the "Badge style" picker is GONE — Elite is
    // the built-in dressing and applies automatically whenever no
    // user formatter exists; it is never a choice. The user's own
    // formatters live in ONE home: the Fusion style badges screen
    // (link imports + pasted JSON, up to three sources). The old
    // standalone Import pack row moved inside it too — no doubles.
    var fusionSources by remember { mutableStateOf(loadFusionSources(settings)) }
    var fusionOpen by remember { mutableStateOf(false) }

    if (fusionOpen) {
        FusionBadgesDialog(
            settings = settings,
            onDismiss = { fusionOpen = false },
            onSourcesChanged = { fusionSources = it }
        )
    }

    if (qualityPickerOpen) {
        SingleSelectDialog(
            title = "Preferred quality",
            options = AUTOPLAY_QUALITY_OPTIONS,
            selected = autoplayQuality,
            onDismiss = { qualityPickerOpen = false },
            onSelect = {
                autoplayQuality = it
                settings.autoplayQuality = it
                qualityPickerOpen = false
            }
        )
    }
    if (sizePickerOpen) {
        SingleSelectDialog(
            title = "Max file size",
            options = AUTOPLAY_SIZE_OPTIONS.map { it.second },
            selected = autoplaySizeName(autoplayMaxSize),
            onDismiss = { sizePickerOpen = false },
            onSelect = { label ->
                val gb = AUTOPLAY_SIZE_OPTIONS.find { it.second == label }?.first ?: 0
                autoplayMaxSize = gb
                settings.autoplayMaxSizeGb = gb
                sizePickerOpen = false
            }
        )
    }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Streams",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "How sources are listed, ordered and auto-picked.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }

            // (The "Streams per source" cap card was removed by the
            // owner's order 2026-10-27 — no stream limits anymore.)

            // Sources dressing (Sample 1, v0.14.6): how stream cards
            // and addon tabs look in both Sources surfaces.
            item(key = "dressingHeader") {
                SettingsSectionHeader("Source list look")
            }
            item(key = "fusionBadges") {
                // v0.14.36 (item 3): ONE row for user formatters —
                // the Fusion style badges screen (sources, preview,
                // add by link, add by paste). No badge-style picker:
                // with no sources here, built-in Elite dresses the
                // streams on its own.
                val sourceCount = fusionSources.size
                val legacyPending = sourceCount == 0 &&
                    settings.importedBadgePackName.isNotBlank()
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 5.dp),
                    onClick = { fusionOpen = true }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SettingsIconTile(Icons.Filled.Label, "Fusion style badges")
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Fusion style badges",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                when {
                                    sourceCount > 0 ->
                                        "On — $sourceCount source" +
                                            (if (sourceCount == 1) "" else "s") +
                                            " dressing your streams"
                                    legacyPending ->
                                        "On — your imported pack dresses your streams"
                                    else ->
                                        "Off — the built-in Elite style dresses your streams"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Text(
                            "Open",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalPalette.current.accent
                        )
                    }
                }
            }
            item(key = "capsuleGroupsHeader") {
                SettingsSectionHeader("Badge details")
            }
            item(key = "capsuleGroupResolution") {
                var on by remember { mutableStateOf(settings.streamCapsuleGroupResolution) }
                SettingsToggleRow(
                    icon = Icons.Filled.HighQuality,
                    title = "Resolution & quality",
                    subtitle = "2160p, 1080p and the 4K UHD tag",
                    checked = on,
                    onCheckedChange = {
                        on = it
                        settings.streamCapsuleGroupResolution = it
                    }
                )
            }
            item(key = "capsuleGroupHdr") {
                var on by remember { mutableStateOf(settings.streamCapsuleGroupHdr) }
                SettingsToggleRow(
                    icon = Icons.Filled.Label,
                    title = "HDR",
                    subtitle = "HDR, HDR10, HDR10+ and Dolby Vision marks",
                    checked = on,
                    onCheckedChange = {
                        on = it
                        settings.streamCapsuleGroupHdr = it
                    }
                )
            }
            item(key = "capsuleGroupAudio") {
                var on by remember { mutableStateOf(settings.streamCapsuleGroupAudio) }
                SettingsToggleRow(
                    icon = Icons.Filled.Audiotrack,
                    title = "Audio",
                    subtitle = "Audio codec, Atmos and channel layout",
                    checked = on,
                    onCheckedChange = {
                        on = it
                        settings.streamCapsuleGroupAudio = it
                    }
                )
            }
            item(key = "capsuleGroupLanguages") {
                var on by remember { mutableStateOf(settings.streamCapsuleGroupLanguages) }
                SettingsToggleRow(
                    icon = Icons.Filled.Language,
                    title = "Languages",
                    subtitle = "The audio languages named in the release",
                    checked = on,
                    onCheckedChange = {
                        on = it
                        settings.streamCapsuleGroupLanguages = it
                    }
                )
            }
            item(key = "capsuleGroupSourceCodec") {
                var on by remember { mutableStateOf(settings.streamCapsuleGroupSourceCodec) }
                SettingsToggleRow(
                    icon = Icons.Filled.Movie,
                    title = "Source & codec",
                    subtitle = "BluRay, WEB-DL, HEVC, x264 and friends",
                    checked = on,
                    onCheckedChange = {
                        on = it
                        settings.streamCapsuleGroupSourceCodec = it
                    }
                )
            }
            item(key = "capsuleGroupSize") {
                // The Size group IS the old "Size badges" switch — same
                // stored preference, new home among the badge details.
                var sizeBadges by remember { mutableStateOf(settings.streamSizeBadges) }
                SettingsToggleRow(
                    icon = Icons.Filled.Storage,
                    title = "Size",
                    subtitle = "Show a stream's file size on its card, when it has one",
                    checked = sizeBadges,
                    onCheckedChange = {
                        sizeBadges = it
                        settings.streamSizeBadges = it
                    }
                )
            }
            item(key = "dressingBadgePos") {
                var badgeTop by remember { mutableStateOf(settings.streamBadgeTop) }
                val dressingPalette = LocalPalette.current
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SettingsIconTile(Icons.Filled.VerticalAlignBottom, "Badge position")
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Badge position",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Which corner of the stream card the size badge sits on",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        listOf(false to "Bottom", true to "Top").forEach { (isTop, label) ->
                            val selected = badgeTop == isTop
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selected) dressingPalette.accent
                                        else Color.White.copy(alpha = 0.07f)
                                    )
                                    .clickable {
                                        badgeTop = isTop
                                        settings.streamBadgeTop = isTop
                                    }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    label,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) dressingPalette.accentText else TextPrimary
                                )
                            }
                            Spacer(Modifier.width(6.dp))
                        }
                    }
                }
            }
            item(key = "dressingLogos") {
                var addonLogos by remember { mutableStateOf(settings.streamAddonLogos) }
                SettingsToggleRow(
                    icon = Icons.Filled.Image,
                    title = "Addon logos",
                    subtitle = "Show each addon's logo on its Sources tab",
                    checked = addonLogos,
                    onCheckedChange = {
                        addonLogos = it
                        settings.streamAddonLogos = it
                    }
                )
            }

            item(key = "qualityOrderHeader") {
                SettingsSectionHeader("Quality order")
            }
            itemsIndexed(qualityOrder, key = { _, q -> q }) { index, quality ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.width(28.dp)
                        )
                        Icon(
                            Icons.Filled.HighQuality,
                            contentDescription = null,
                            tint = LocalPalette.current.accent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = quality,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                if (index > 0) {
                                    qualityOrder = qualityOrder.toMutableList().also {
                                        val t = it[index - 1]; it[index - 1] = it[index]; it[index] = t
                                    }
                                    settings.qualityOrder = qualityOrder
                                }
                            },
                            enabled = index > 0
                        ) {
                            Icon(Icons.Filled.ArrowUpward, "Move up", tint = TextPrimary)
                        }
                        IconButton(
                            onClick = {
                                if (index < qualityOrder.size - 1) {
                                    qualityOrder = qualityOrder.toMutableList().also {
                                        val t = it[index + 1]; it[index + 1] = it[index]; it[index] = t
                                    }
                                    settings.qualityOrder = qualityOrder
                                }
                            },
                            enabled = index < qualityOrder.size - 1
                        ) {
                            Icon(Icons.Filled.ArrowDownward, "Move down", tint = TextPrimary)
                        }
                    }
                }
            }
            item(key = "qualityOrderNote") {
                Text(
                    "Top = highest priority in the stream list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }

            item(key = "autoplayHeader") {
                SettingsSectionHeader("Autoplay")
            }
            item(key = "autoplay") {
                SettingsToggleRow(
                    icon = Icons.Filled.PlayArrow,
                    title = "Autoplay by rule",
                    subtitle = "Play picks the stream matching your quality and size rule",
                    checked = autoplay,
                    onCheckedChange = {
                        autoplay = it
                        settings.streamAutoplay = it
                    }
                )
            }
            item(key = "autoplayQuality") {
                val enabled = autoplay
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 5.dp)
                        .alpha(if (enabled) 1f else 0.45f),
                    onClick = { if (enabled) qualityPickerOpen = true }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SettingsIconTile(Icons.Filled.Sort, "Preferred quality")
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Preferred quality",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                if (autoplayQuality == "Auto") "Follow the quality order above"
                                else "Prefer $autoplayQuality streams",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Text(
                            autoplayQuality,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalPalette.current.accent
                        )
                    }
                }
            }
            item(key = "autoplaySize") {
                val enabled = autoplay
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 5.dp)
                        .alpha(if (enabled) 1f else 0.45f),
                    onClick = { if (enabled) sizePickerOpen = true }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SettingsIconTile(Icons.Filled.Storage, "Max file size")
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Max file size",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Skip streams bigger than this when auto-playing",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Text(
                            autoplaySizeName(autoplayMaxSize),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = LocalPalette.current.accent
                        )
                    }
                }
            }
            item(key = "autoplayNote") {
                Text(
                    "The source list button next to Play always opens the full stream list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * Fusion style badges screen (v0.14.36, item 3): the ONE home for
 * the user's own badge formatters. Up to three sources — badge-pack
 * links and pasted Fusion-style JSON — each listed as its own card
 * with its state, its badge and group counts, a preview of the
 * badges it carries, and (for links) an in-place update. A source
 * dresses streams ahead of the built-in Elite; badges a source
 * lacks fall back to Elite. A pack imported before this screen
 * existed appears here as source #1 (migrated, not wiped).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FusionBadgesDialog(
    settings: com.pulsestream.app.data.SettingsStore,
    onDismiss: () -> Unit,
    onSourcesChanged: (List<FusionBadgeSource>) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sources by remember { mutableStateOf(loadFusionSources(settings)) }
    var working by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var link by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<FusionBadgeSource?>(null) }

    fun applySources(next: List<FusionBadgeSource>) {
        sources = next
        onSourcesChanged(next)
    }

    LaunchedEffect(Unit) {
        // One-time migration of a pre-v0.14.36 single imported pack.
        working = true
        val migrated = withContext(Dispatchers.IO) {
            ensureFusionMigration(context, settings)
        }
        applySources(migrated)
        working = false
    }

    if (preview != null) {
        val src = preview!!
        AlertDialog(
            onDismissRequest = { preview = null },
            title = { Text(src.label, color = TextPrimary) },
            text = {
                Column {
                    Text(
                        "${src.badgeCount} badges · ${src.groupCount} groups",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                        item {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                src.badgeKeys.forEach { key ->
                                    FusionPreviewBadge(src.id, key)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { preview = null }) {
                    Text("Close", color = LocalPalette.current.accent)
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = { if (!working) onDismiss() },
        title = { Text("Fusion style badges", color = TextPrimary) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 540.dp)) {
                item(key = "intro") {
                    Text(
                        "Your own badge dressing for stream cards, from up to " +
                            "${FusionBadgeSources.MAX_SOURCES} sources. A formatter from " +
                            "an addon still wins; badges a source doesn't have fall " +
                            "back to the built-in Elite ones.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                itemsIndexed(sources, key = { _, s -> s.id }) { _, source ->
                    FusionSourceCard(
                        source = source,
                        working = working,
                        onPreview = { preview = source },
                        onUpdate = {
                            working = true
                            status = null
                            scope.launch {
                                updateFusionSource(context, settings, source.id)
                                    .onSuccess {
                                        applySources(loadFusionSources(settings))
                                        status = "Updated ${it.label} — ${it.badgeCount} badges"
                                    }
                                    .onFailure {
                                        status = it.message ?: "Couldn't update that source"
                                    }
                                working = false
                            }
                        },
                        onDelete = {
                            working = true
                            status = null
                            scope.launch {
                                val remaining = deleteFusionSource(context, settings, source.id)
                                applySources(remaining)
                                if (preview?.id == source.id) preview = null
                                status = "Removed ${source.label}"
                                working = false
                            }
                        }
                    )
                }
                if (sources.size >= FusionBadgeSources.MAX_SOURCES) {
                    item(key = "cap") {
                        Text(
                            "Three sources is the limit — delete one to add another.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                } else {
                    item(key = "addLink") {
                        Column(Modifier.padding(top = 10.dp)) {
                            Text(
                                "Add from a link",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = link,
                                onValueChange = { link = it; status = null },
                                label = { Text("Badge pack link") },
                                singleLine = true,
                                enabled = !working,
                                modifier = Modifier.fillMaxWidth()
                            )
                            TextButton(
                                enabled = !working && link.isNotBlank(),
                                onClick = {
                                    working = true
                                    status = null
                                    scope.launch {
                                        addFusionSourceFromUrl(context, settings, link)
                                            .onSuccess {
                                                applySources(loadFusionSources(settings))
                                                link = ""
                                                status = "Added ${it.label} — ${it.badgeCount} badges"
                                            }
                                            .onFailure {
                                                status = it.message ?: "Couldn't add that link"
                                            }
                                        working = false
                                    }
                                }
                            ) {
                                Text("Add link", color = LocalPalette.current.accent)
                            }
                        }
                    }
                    item(key = "addPaste") {
                        Column(Modifier.padding(top = 6.dp)) {
                            Text(
                                "Add pasted JSON",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = pasted,
                                onValueChange = { pasted = it; status = null },
                                label = { Text("Fusion pack JSON") },
                                minLines = 3,
                                maxLines = 6,
                                enabled = !working,
                                modifier = Modifier.fillMaxWidth()
                            )
                            TextButton(
                                enabled = !working && pasted.isNotBlank(),
                                onClick = {
                                    working = true
                                    status = null
                                    scope.launch {
                                        addFusionSourceFromText(context, settings, pasted)
                                            .onSuccess {
                                                applySources(loadFusionSources(settings))
                                                pasted = ""
                                                status = "Added ${it.label} — ${it.badgeCount} badges"
                                            }
                                            .onFailure {
                                                status = it.message ?: "That JSON couldn't be used"
                                            }
                                        working = false
                                    }
                                }
                            ) {
                                Text("Add pasted JSON", color = LocalPalette.current.accent)
                            }
                        }
                    }
                }
                item(key = "status") {
                    Column {
                        status?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                it,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        if (working) {
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = LocalPalette.current.accent,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "Working…",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !working, onClick = onDismiss) {
                Text("Done", color = LocalPalette.current.accent)
            }
        }
    )
}

/** One Fusion source's card: label, kind, state, counts, and its actions. */
@Composable
private fun FusionSourceCard(
    source: FusionBadgeSource,
    working: Boolean,
    onPreview: () -> Unit,
    onUpdate: () -> Unit,
    onDelete: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        source.label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        when (source.kind) {
                            FusionSourceKind.URL -> "From a link"
                            FusionSourceKind.PASTE -> "Pasted JSON"
                            FusionSourceKind.LEGACY -> "Imported pack"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Text(
                    "Active",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = LocalPalette.current.accent
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "${source.badgeCount} badges · ${source.groupCount} groups",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Row {
                TextButton(enabled = !working, onClick = onPreview) {
                    Text("Preview", color = LocalPalette.current.accent)
                }
                if (source.kind == FusionSourceKind.URL) {
                    TextButton(enabled = !working, onClick = onUpdate) {
                        Text("Update", color = LocalPalette.current.accent)
                    }
                }
                TextButton(enabled = !working, onClick = onDelete) {
                    Text("Delete", color = TextSecondary)
                }
            }
        }
    }
}

/** One badge in a source preview: its artwork (when installed) over its plain name. */
@Composable
private fun FusionPreviewBadge(sourceId: String, key: String) {
    val context = LocalContext.current
    val bitmap = remember(sourceId, key) {
        runCatching {
            val file = java.io.File(fusionSourceDir(context, sourceId), "$key.png")
            if (file.isFile) {
                android.graphics.BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
            } else {
                null
            }
        }.getOrNull()
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (bitmap != null) {
            androidx.compose.foundation.Image(
                bitmap,
                contentDescription = null,
                modifier = Modifier.height(22.dp)
            )
        } else {
            Box(Modifier.size(22.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(
            badgeKeyLabel(key),
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

/** Single-select AlertDialog used by the Streams settings pickers. */
@Composable
private fun SingleSelectDialog(
    title: String,
    options: List<String>,
    selected: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = TextPrimary) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                itemsIndexed(options) { _, option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(option) }
                            .tvFocusRing(RoundedCornerShape(10.dp))
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        RadioButton(
                            selected = option == selected,
                            onClick = { onSelect(option) },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = LocalPalette.current.accent
                            )
                        )
                        Text(option, color = TextPrimary)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = LocalPalette.current.accent)
            }
        }
    )
}
