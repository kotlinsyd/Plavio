package com.pulsestream.app.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.cloud.PlavioAccountManager
import com.pulsestream.app.ui.components.PRESET_AVATARS
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Account screen (v0.14.6): the Plavio account is the only door.
 * Google sign-in + Drive sync were removed by the owner's order
 * (2026-10-26) — the Plavio account (email + password) syncs the
 * same full backup. Signed out, the profile header sits at the TOP
 * (owner's order 2026-10-26) above the sign-in section.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {},
    onGoToProfiles: () -> Unit = {},
    onGoToBackup: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var refreshTick by remember { mutableStateOf(0) }
    // (v0.14.39, audit D4: the dead username dialog that used to sit
    // here was removed — nothing ever opened it. The ONE live
    // username editor is PlavioAccountSection's, below.)
    val profileName = remember(refreshTick) { repository.settings.profileUserName }

    val plavioSignedIn = remember(refreshTick) {
        PlavioAccountManager.isConfigured() &&
            PlavioAccountManager(context, repository).isSignedIn()
    }

    val avatarSetting = remember(refreshTick) { repository.settings.profileAvatar }
    var showPicker by remember { mutableStateOf(false) }

    // System photo picker for the profile picture (no permission needed):
    // the chosen photo is cropped square and stored on the device.
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                error = null
                val saved = withContext(Dispatchers.IO) {
                    saveProfilePhoto(context, uri, repository.settings)
                }
                if (saved) {
                    repository.settings.profileAvatar = "photo"
                    message = "Profile picture updated."
                } else {
                    error = "Couldn't use that photo."
                }
                busy = false
                refreshTick++
            }
        }
    }

    GlowBackground {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Account & Sync") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        // Profiles live in the top-right corner
                        // (owner's order 2026-10-29) — no separate
                        // tile. Profiles are local, so this shows in
                        // both signed-out and signed-in states.
                        IconButton(onClick = onGoToProfiles) {
                            Icon(Icons.Filled.Groups, contentDescription = "Profiles")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                error?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
                message?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }

                // Signed-out header (owner's order 2026-10-29): before
                // sign-in there is no profile to edit, so the Plavio
                // logo (Weave mark) sits in the picture place at the TOP
                // of the screen (owner's order 2026-10-26), above the
                // sign-in card — no Change picture, no Set Username.
                // Signed in, the Plavio section below renders its own
                // centered identity with picture/username editing.
                if (!plavioSignedIn) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Image(
                            painter = painterResource(com.pulsestream.app.R.drawable.weave_mark),
                            contentDescription = null,
                            modifier = Modifier.size(88.dp)
                        )
                        Text(
                            profileName.ifBlank { "Your account" },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            // v0.14.25 (item 6): explicit colour —
                            // without it this Text fell back to the
                            // material3 LocalContentColor default
                            // (black) and rendered near-invisible on
                            // the dark canvas. The theme now provides
                            // a sane default too; this stays explicit.
                            color = TextPrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Plavio account (2026-10-25): email + password account
                // with full sync — the only door since v0.14.6.
                // Renders nothing until the backend is configured.
                PlavioAccountSection(
                    repository = repository,
                    onChangePicture = { showPicker = true },
                    onAccountChanged = { refreshTick++ }
                )

                // v0.14.25 (item 6): this page must never be the empty
                // black shell the owner screenshotted — when the
                // account backend is not configured in the build, the
                // section above renders nothing, so the page says so
                // plainly instead of going blank.
                if (!PlavioAccountManager.isConfigured()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "Plavio account",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            "Sign-in and cloud sync are not switched on in this build. " +
                                "Everything on this device keeps working — and the file " +
                                "backup below does not need an account.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                // v0.14.26 (batch item 9): the "Tracking & sync"
                // block is REMOVED from this page — Trakt/Simkl
                // live ONLY in Integrations (Tracking, lists &
                // metadata), per the owner's NO DOUBLES rule. This
                // page keeps exactly the sign-in block above and
                // Backup & restore below.

                // Backup & restore (item 6): the file backup screen
                // existed but had no door anywhere; this row is it.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onGoToBackup)
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.FileUpload,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Backup & restore",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            "Save everything to a file, or bring a backup back",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }

                if (showPicker) {
                    AlertDialog(
                        onDismissRequest = { showPicker = false },
                        title = { Text("Choose picture") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        showPicker = false
                                        photoPicker.launch(
                                            PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        Icons.Filled.PhotoLibrary,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text("Use my photo")
                                }
                                Text(
                                    "OR PICK AN AVATAR",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(4),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.heightIn(max = 290.dp)
                                ) {
                                    items(PRESET_AVATARS) { preset ->
                                        Image(
                                            painter = painterResource(preset.resId),
                                            contentDescription = preset.label,
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    repository.settings.profileAvatar = "preset:${preset.id}"
                                                    showPicker = false
                                                    refreshTick++
                                                },
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                                if (avatarSetting.isNotBlank()) {
                                    TextButton(
                                        onClick = {
                                            repository.settings.profileAvatar = ""
                                            repository.settings.deleteProfilePhoto()
                                            showPicker = false
                                            refreshTick++
                                        }
                                    ) { Text("Remove picture") }
                                }
                            }
                        },
                        confirmButton = {},
                        dismissButton = {
                            TextButton(onClick = { showPicker = false }) { Text("Cancel") }
                        }
                    )
                }

            }
        }
    }
}

/**
 * Stores a picked gallery photo as the profile picture: center-cropped
 * to a square, scaled to at most 512px, saved as JPEG in app-private
 * storage (SettingsStore.profilePhotoFile). Returns false on any failure.
 */
private fun saveProfilePhoto(context: android.content.Context, uri: Uri, settings: SettingsStore): Boolean =
    runCatching {
        val source = context.contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input)
        } ?: return false
        val side = minOf(source.width, source.height)
        val cropped = Bitmap.createBitmap(
            source, (source.width - side) / 2, (source.height - side) / 2, side, side
        )
        val scaled = if (side > 512) Bitmap.createScaledBitmap(cropped, 512, 512, true) else cropped
        val out = java.io.ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
        settings.writeProfilePhoto(out.toByteArray())
        true
    }.getOrDefault(false)
