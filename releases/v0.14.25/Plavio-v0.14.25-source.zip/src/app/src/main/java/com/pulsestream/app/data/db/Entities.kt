package com.pulsestream.app.data.db

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Local profiles (v0.14.13, item 8): the partitioned tables
 * (watchlist, favorites, title_statuses, custom_lists, playback,
 * watched) stamp every row with a profileId. [CurrentProfile] is
 * the process-wide active profile, set once at app start from
 * SettingsStore and again on a profile switch (which restarts the
 * app, so DAO flows never have to re-bind mid-session). DAO read
 * methods default their profileId parameter to it — that one
 * default is what partitions the whole app without touching the
 * hundreds of call sites.
 */
object CurrentProfile {
    @Volatile
    var id: String = Profiles.DEFAULT_ID
}

/** Profile constants shared by the DB layer, settings and UI. */
object Profiles {
    const val DEFAULT_ID = "profile_default"
    const val DEFAULT_NAME = "Profile 1"
    const val DEFAULT_AVATAR = "man_glasses"
}

/** One local profile (v0.14.13). Global table — never partitioned. */
@Entity(tableName = "profiles")
data class ProfileRow(
    @PrimaryKey val id: String,
    val name: String,
    val avatarKey: String,
    val isDefault: Boolean,
    val createdAt: Long
)

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<ProfileRow>>

    @Query("SELECT * FROM profiles ORDER BY createdAt ASC")
    suspend fun getAll(): List<ProfileRow>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProfileRow?

    @Query("SELECT * FROM profiles WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefault(): ProfileRow?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: ProfileRow)

    @Query("UPDATE profiles SET isDefault = 0")
    suspend fun clearDefaults()

    @Query("UPDATE profiles SET isDefault = 1 WHERE id = :id")
    suspend fun markDefault(id: String)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Entity(tableName = "addons")
data class InstalledAddon(
    @PrimaryKey val id: String,
    val name: String,
    val version: String,
    val description: String,
    val baseUrl: String,
    val types: String,
    /** Comma-separated manifest resources, e.g. "catalog,meta,stream". Added in DB v2. */
    val resources: String = "catalog,meta,stream",
    /** True when this addon was installed automatically by the app (PlavioHD, PlavioMeta). Added in DB v3. */
    val preinstalled: Boolean = false,
    /** User-facing on/off switch. Disabled addons are excluded from catalogs, metadata, streams and subtitle search. Added in DB v4. */
    val enabled: Boolean = true,
    /** Manifest behaviorHints.configurable — the addon has a web configure page. Added in DB v4. */
    val configurable: Boolean = false,
    /** Whether this addon's catalogs appear on the Home screen. Added in DB v5. */
    val showOnHome: Boolean = true,
    /** Manifest logo URL for the addon icon. Added in DB v6. */
    val logoUrl: String = "",
    /** Manual ordering position (user-rearranged). Added in DB v7. */
    val sortOrder: Int = 0,
    /** Starred addons get priority for catalogs, fetching and playback. Added in DB v7. */
    val starred: Boolean = false,
    val addedAt: Long
) {
    val resourceSet: Set<String>
        get() = resources.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    val hasCatalog: Boolean get() = "catalog" in resourceSet
    val hasMeta: Boolean get() = "meta" in resourceSet
    val hasStream: Boolean get() = "stream" in resourceSet
    val hasSubtitles: Boolean get() = "subtitles" in resourceSet
}

@Dao
interface AddonDao {
    @Query("SELECT * FROM addons ORDER BY sortOrder ASC, addedAt ASC")
    fun observeAll(): Flow<List<InstalledAddon>>

    @Query("SELECT * FROM addons ORDER BY sortOrder ASC, addedAt ASC")
    suspend fun getAll(): List<InstalledAddon>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(addon: InstalledAddon)

    @Query("UPDATE addons SET showOnHome = :show WHERE id = :id")
    suspend fun setShowOnHome(id: String, show: Boolean)

    @Query("DELETE FROM addons WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM addons")
    suspend fun clearAll()
}

@Entity(tableName = "playback", primaryKeys = ["profileId", "key"])
data class PlaybackState(
    val key: String,
    val title: String,
    val poster: String?,
    val videoId: String,
    val streamUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    /** IMDb id + season/episode so Continue Watching can offer skip-segments and subtitle search. Added in DB v3. */
    val imdbId: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    /**
     * Series context for resume, added in DB v14. Without these, a
     * Continue Watching resume rebuilt the player with series-level
     * data only — the episode title in the header, the Episodes
     * button and autoplay-next all went missing (owner's screenshot
     * report 2026-10-27). Null on rows saved before v14; the player
     * re-fetches the meta to fill them in.
     */
    val seriesName: String? = null,
    val episodeTitle: String? = null,
    val metaId: String? = null,
    /**
     * Which stream was actually playing, added in DB v15 (owner's
     * device report on v0.14.7-test: a Continue Watching resume
     * re-picked the FIRST stream instead of the one he had chosen —
     * the 7th in Sources). The row key is the stream URL, but saves
     * from a source switch and from pause/dispose race, and addon
     * URLs rotate; the resume now matches on this identity: addon id
     * + the stream's display title (fingerprint) + quality lane,
     * falling back to the exact URL. Null on pre-v15 rows.
     */
    val streamAddonId: String? = null,
    val streamName: String? = null,
    val streamTitle: String? = null,
    val streamQuality: String? = null,
    /** Official studio logo artwork for the title (item 11), shown on the CW card. */
    val logo: String? = null,
    val updatedAt: Long,
    /**
     * The series' episode list, persisted with the playback row
     * (DB v16, notes item 16): JSON array of {"id","s","e","t"}
     * objects. A Continue Watching resume used to rebuild the
     * player with NO episode list, so autoplay-next and the
     * next-episode suggestion silently never fired in resumed
     * sessions — the only repair was one fragile meta fetch. With
     * the list saved at play time, a resume knows the next episode
     * with no fetch at all. Null on pre-v16 rows and movies.
     */
    val episodeIdsJson: String? = null,
    /**
     * Synced progress percent (0-100) for rows IMPORTED into
     * Continue Watching from Trakt/Simkl (DB v16, notes item 13)
     * when the title's runtime was unknown, so no absolute
     * position could be computed. The player seeks to this
     * fraction of the real duration once it is known. Null on
     * locally-played rows.
     */
    val remoteProgressPct: Int? = null,
    /**
     * "trakt" / "simkl" for rows imported by the Continue Watching
     * import (notes item 13); null for rows the local player saved.
     * Imported rows carry no stream identity — a resume resolves
     * streams fresh and takes the normal auto-pick.
     */
    val importSource: String? = null,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

@Dao
interface PlaybackDao {
    @Query("SELECT * FROM playback WHERE profileId = :profileId ORDER BY updatedAt DESC LIMIT 20")
    fun observeRecent(profileId: String = CurrentProfile.id): Flow<List<PlaybackState>>

    @Query("SELECT * FROM playback WHERE profileId = :profileId AND `key` = :key LIMIT 1")
    suspend fun getByKey(key: String, profileId: String = CurrentProfile.id): PlaybackState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: PlaybackState)

    @Query("DELETE FROM playback WHERE profileId = :profileId AND `key` = :key")
    suspend fun deleteByKey(key: String, profileId: String = CurrentProfile.id)

    @Query("SELECT * FROM playback WHERE profileId = :profileId")
    suspend fun getAll(profileId: String = CurrentProfile.id): List<PlaybackState>

    @Query("DELETE FROM playback WHERE profileId = :profileId")
    suspend fun clearAll(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM playback WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: String)
}

/** Cached catalog rows (per addon + type + catalog id) so Home renders instantly. Added in DB v3. */
@Entity(tableName = "catalog_cache")
data class CatalogCache(
    @PrimaryKey val key: String,
    val addonId: String,
    val addonName: String,
    val baseUrl: String,
    val type: String,
    val catalogId: String,
    val catalogName: String,
    val itemsJson: String,
    val fetchedAt: Long
)

@Dao
interface CatalogCacheDao {
    @Query("SELECT * FROM catalog_cache")
    suspend fun getAll(): List<CatalogCache>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rows: List<CatalogCache>)

    @Query("DELETE FROM catalog_cache WHERE addonId NOT IN (:ids)")
    suspend fun pruneExcept(ids: List<String>)

    @Query("DELETE FROM catalog_cache")
    suspend fun clearAll()

    @Query("DELETE FROM catalog_cache WHERE `key` = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM catalog_cache WHERE addonId = :addonId")
    suspend fun deleteByAddonId(addonId: String)

    /**
     * Drops rows whose JSON exceeds SQLite's ~2MB CursorWindow limit —
     * reading one would crash with SQLiteBlobTooBigException.
     */
    @Query("DELETE FROM catalog_cache WHERE length(CAST(itemsJson AS BLOB)) > :maxBytes")
    suspend fun pruneOversized(maxBytes: Int): Int

    /**
     * Drops every cached M3U row of one playlist (exact stored baseUrl).
     * Callers pass both the raw and the normalized URL to cover playlists
     * stored by older builds.
     */
    @Query("DELETE FROM catalog_cache WHERE addonId = 'm3u' AND baseUrl = :baseUrl")
    suspend fun deleteM3uPlaylist(baseUrl: String)
}

/** User's watchlist — titles bookmarked for later. Added in DB v3. */
@Entity(tableName = "watchlist", primaryKeys = ["profileId", "key"])
data class WatchlistItem(
    val key: String,
    val addonId: String,
    val type: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    val addedAt: Long,
    /** Studio logo artwork (DB v15); backfilled with the poster when a sync path stored none. */
    val logo: String? = null,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist WHERE profileId = :profileId ORDER BY addedAt DESC")
    fun observeAll(profileId: String = CurrentProfile.id): Flow<List<WatchlistItem>>

    @Query("SELECT * FROM watchlist WHERE profileId = :profileId AND `key` = :key LIMIT 1")
    fun observeByKey(key: String, profileId: String = CurrentProfile.id): Flow<WatchlistItem?>

    @Query("SELECT * FROM watchlist WHERE profileId = :profileId AND `key` = :key LIMIT 1")
    suspend fun getByKey(key: String, profileId: String = CurrentProfile.id): WatchlistItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchlistItem)

    @Query("DELETE FROM watchlist WHERE profileId = :profileId AND `key` = :key")
    suspend fun deleteByKey(key: String, profileId: String = CurrentProfile.id)

    @Query("SELECT * FROM watchlist WHERE profileId = :profileId")
    suspend fun getAll(profileId: String = CurrentProfile.id): List<WatchlistItem>

    @Query("DELETE FROM watchlist WHERE profileId = :profileId")
    suspend fun clearAll(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM watchlist WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: String)
}

/**
 * User's favorites — titles the user starred in the Plavio section
 * of the hold sheet. Same row shape as the watchlist; added in
 * DB v13 (v0.14.10).
 */
@Entity(tableName = "favorites", primaryKeys = ["profileId", "key"])
data class FavoriteItem(
    val key: String,
    val addonId: String,
    val type: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    val addedAt: Long,
    /** Studio logo artwork (DB v15); see WatchlistItem.logo. */
    val logo: String? = null,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites WHERE profileId = :profileId ORDER BY addedAt DESC")
    fun observeAll(profileId: String = CurrentProfile.id): Flow<List<FavoriteItem>>

    @Query("SELECT * FROM favorites WHERE profileId = :profileId AND `key` = :key LIMIT 1")
    suspend fun getByKey(key: String, profileId: String = CurrentProfile.id): FavoriteItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: FavoriteItem)

    @Query("DELETE FROM favorites WHERE profileId = :profileId AND `key` = :key")
    suspend fun deleteByKey(key: String, profileId: String = CurrentProfile.id)

    @Query("SELECT * FROM favorites WHERE profileId = :profileId")
    suspend fun getAll(profileId: String = CurrentProfile.id): List<FavoriteItem>

    @Query("DELETE FROM favorites WHERE profileId = :profileId")
    suspend fun clearAll(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM favorites WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: String)
}

/**
 * Plavio's own per-title statuses (v0.14.10): at most one row per
 * title, carrying one of watching / hold / completed / dropped.
 * "Next to Watch" deliberately has NO row here — it is backed by
 * the watchlist table itself (watchlist membership resolves to
 * Next to Watch; an explicit row here wins over that membership).
 * See PlavioStatuses.resolved.
 */
@Entity(tableName = "title_statuses", primaryKeys = ["profileId", "key"])
data class TitleStatusItem(
    val key: String,
    val addonId: String,
    val type: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    val status: String,
    val updatedAt: Long,
    /** Studio logo artwork (DB v15); see WatchlistItem.logo. */
    val logo: String? = null,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

@Dao
interface TitleStatusDao {
    @Query("SELECT * FROM title_statuses WHERE profileId = :profileId ORDER BY updatedAt DESC")
    fun observeAll(profileId: String = CurrentProfile.id): Flow<List<TitleStatusItem>>

    @Query("SELECT * FROM title_statuses WHERE profileId = :profileId AND `key` = :key LIMIT 1")
    suspend fun getByKey(key: String, profileId: String = CurrentProfile.id): TitleStatusItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: TitleStatusItem)

    @Query("DELETE FROM title_statuses WHERE profileId = :profileId AND `key` = :key")
    suspend fun deleteByKey(key: String, profileId: String = CurrentProfile.id)

    @Query("SELECT * FROM title_statuses WHERE profileId = :profileId")
    suspend fun getAll(profileId: String = CurrentProfile.id): List<TitleStatusItem>

    @Query("DELETE FROM title_statuses WHERE profileId = :profileId")
    suspend fun clearAll(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM title_statuses WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: String)
}

/** User-created custom lists — named collections beyond the flat watchlist. Added in DB v9. */
@Entity(tableName = "custom_lists")
data class CustomList(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

/**
 * Items inside a custom list. itemKey mirrors the watchlist key format
 * ("addonId|type|metaId"). addonId is stored (not in the original spec) so
 * tapping an item can navigate back to its detail screen.
 * Added in DB v9.
 */
@Entity(
    tableName = "custom_list_items",
    primaryKeys = ["listId", "itemKey"]
)
data class CustomListItem(
    val listId: String,
    val itemKey: String,
    val addonId: String,
    val type: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    val addedAt: Long,
    /** Studio logo artwork (DB v15); see WatchlistItem.logo. */
    val logo: String? = null
)

@Dao
interface CustomListDao {
    @Query("SELECT * FROM custom_lists WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun observeLists(profileId: String = CurrentProfile.id): Flow<List<CustomList>>

    @Query("SELECT * FROM custom_lists WHERE profileId = :profileId ORDER BY createdAt DESC")
    suspend fun getLists(profileId: String = CurrentProfile.id): List<CustomList>

    @Query("SELECT * FROM custom_lists WHERE id = :id LIMIT 1")
    suspend fun getList(id: String): CustomList?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertList(list: CustomList)

    @Query("UPDATE custom_lists SET name = :name WHERE id = :id")
    suspend fun renameList(id: String, name: String)

    @Query("DELETE FROM custom_lists WHERE id = :id")
    suspend fun deleteList(id: String)

    @Query("DELETE FROM custom_lists WHERE profileId = :profileId")
    suspend fun clearLists(profileId: String = CurrentProfile.id)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLists(lists: List<CustomList>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<CustomListItem>)

    @Query("SELECT * FROM custom_list_items WHERE listId IN (SELECT id FROM custom_lists WHERE profileId = :profileId) ORDER BY addedAt DESC")
    suspend fun getAllItems(profileId: String = CurrentProfile.id): List<CustomListItem>

    @Query("DELETE FROM custom_list_items WHERE listId IN (SELECT id FROM custom_lists WHERE profileId = :profileId)")
    suspend fun clearAllItems(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM custom_list_items WHERE listId IN (SELECT id FROM custom_lists WHERE profileId = :profileId)")
    suspend fun deleteItemsForProfile(profileId: String)

    @Query("DELETE FROM custom_lists WHERE profileId = :profileId")
    suspend fun deleteListsForProfile(profileId: String)

    @Query("SELECT * FROM custom_list_items WHERE listId = :listId ORDER BY addedAt DESC")
    fun observeItems(listId: String): Flow<List<CustomListItem>>

    @Query("SELECT listId FROM custom_list_items WHERE itemKey = :itemKey AND listId IN (SELECT id FROM custom_lists WHERE profileId = :profileId)")
    fun observeListsContaining(itemKey: String, profileId: String = CurrentProfile.id): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addItem(item: CustomListItem)

    @Query("DELETE FROM custom_list_items WHERE listId = :listId AND itemKey = :itemKey")
    suspend fun removeItem(listId: String, itemKey: String)

    /**
     * Membership by title identity alone (v0.14.11). The itemKey's
     * addonId segment records which addon served the title when it
     * was added; the same title reached through a different addon
     * (or the Library, which opens the sheet with no addon) carries
     * a different key for the SAME membership. Matching on
     * (type, metaId) keeps the sheet's in-list state truthful
     * everywhere.
     */
    @Query("SELECT listId FROM custom_list_items WHERE type = :type AND metaId = :metaId AND listId IN (SELECT id FROM custom_lists WHERE profileId = :profileId)")
    fun observeListsContainingMeta(type: String, metaId: String, profileId: String = CurrentProfile.id): Flow<List<String>>

    @Query("DELETE FROM custom_list_items WHERE listId = :listId AND type = :type AND metaId = :metaId")
    suspend fun removeItemByMeta(listId: String, type: String, metaId: String)

    @Query("DELETE FROM custom_list_items WHERE listId = :listId")
    suspend fun deleteItemsByList(listId: String)

    @Query("SELECT COUNT(*) FROM custom_list_items WHERE listId = :listId")
    fun observeItemCount(listId: String): Flow<Int>
}

/** Briefly-cached subtitle search results (per type + IMDb id). Added in DB v3. */
@Entity(tableName = "subtitle_cache")
data class SubtitleCache(
    @PrimaryKey val key: String,
    val itemsJson: String,
    val fetchedAt: Long
)

@Dao
interface SubtitleCacheDao {
    @Query("DELETE FROM subtitle_cache")
    suspend fun clearAll()
    @Query("SELECT * FROM subtitle_cache WHERE `key` = :key LIMIT 1")
    suspend fun getByKey(key: String): SubtitleCache?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: SubtitleCache)
}

/**
 * Full series/movie meta persisted to disk (DB v18, v0.14.11):
 * one row per (type, metaId) holding the artwork fields the
 * Library renders plus the episode list as JSON, written through
 * by StreamRepository.getMetaFromAny. Before this table the app
 * held full metas in memory only — every cold start re-walked the
 * meta addons from zero, which is why Library posters and the
 * Upcoming section arrived late or never (owner's report,
 * 2026-10-29). [extraJson] carries the remaining MetaDetail
 * fields (synopsis, genres, cast, trailers, detail facts) so a
 * cache hit never strips the Detail page's Summary/cast.
 */
@Entity(tableName = "meta_cache", primaryKeys = ["type", "metaId"])
data class MetaCacheEntry(
    val type: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    val background: String?,
    val logo: String?,
    val imdbRating: String?,
    /** Episode list JSON (StremioParser Video fields, incl. released). */
    val videosJson: String,
    val fetchedAt: Long,
    /** Addon that served this meta (provenance/hint only). */
    val servedByAddonId: String?,
    /** Remaining MetaDetail fields as JSON (see class doc). */
    val extraJson: String?
)

@Dao
interface MetaCacheDao {
    @Query("SELECT * FROM meta_cache WHERE type = :type AND metaId = :metaId LIMIT 1")
    suspend fun get(type: String, metaId: String): MetaCacheEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: MetaCacheEntry)

    @Query("SELECT COUNT(*) FROM meta_cache")
    suspend fun count(): Int

    /** LRU-style size guard: drop the oldest-fetched rows. */
    @Query(
        "DELETE FROM meta_cache WHERE rowid IN " +
            "(SELECT rowid FROM meta_cache ORDER BY fetchedAt ASC LIMIT :n)"
    )
    suspend fun evictOldest(n: Int): Int

    @Query("DELETE FROM meta_cache")
    suspend fun clearAll()
}

/** Offline download tracking. Added in DB v8. */
@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey val id: String,
    val url: String,
    val title: String,
    val fileName: String,
    val filePath: String,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    /** QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELLED */
    val status: String = "QUEUED",
    val error: String? = null,
    val headersJson: String = "{}",
    val createdAt: Long,
    val completedAt: Long? = null,
    /**
     * The title's poster URL and its locally saved copy (DB v17,
     * owner's order 2026-10-28): when a download starts, the poster
     * image is fetched once and stored on disk ([posterPath]) so
     * Downloads/Library tiles show artwork fully offline. Null on
     * rows created before v17 and on downloads started without a
     * poster in scope.
     */
    val posterUrl: String? = null,
    val posterPath: String? = null
)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    suspend fun getAll(): List<DownloadItem>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadItem?

    @Query("SELECT * FROM downloads WHERE url = :url AND status != 'CANCELLED' LIMIT 1")
    suspend fun getByUrl(url: String): DownloadItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: DownloadItem)

    @Query("UPDATE downloads SET downloadedBytes = :bytes, status = :status WHERE id = :id")
    suspend fun updateProgress(id: String, bytes: Long, status: String)

    @Query("UPDATE downloads SET status = :status, error = :error WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, error: String? = null)

    /** Poster URL + local poster file for a download (DB v17, 2026-10-28). */
    @Query("UPDATE downloads SET posterUrl = :url, posterPath = :path WHERE id = :id")
    suspend fun updatePoster(id: String, url: String?, path: String?)

    @Query("UPDATE downloads SET status = 'COMPLETED', downloadedBytes = totalBytes, completedAt = :completedAt WHERE id = :id")
    suspend fun markCompleted(id: String, completedAt: Long)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'DOWNLOADING', 'PAUSED') ORDER BY createdAt ASC")
    suspend fun getActive(): List<DownloadItem>
}

/** One row per watched movie / episode (drives the WATCHED pill). Added in DB v12. */
@Entity(tableName = "watched", primaryKeys = ["profileId", "key"])
data class WatchedRecord(
    val key: String,
    val watchedAt: Long,
    /** Owning local profile (DB v19, item 8). See [CurrentProfile]. */
    @ColumnInfo(defaultValue = "'profile_default'")
    val profileId: String = CurrentProfile.id
)

@Dao
interface WatchedDao {
    @Query("SELECT `key` FROM watched WHERE profileId = :profileId")
    fun observeKeys(profileId: String = CurrentProfile.id): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: WatchedRecord)

    @Query("SELECT * FROM watched WHERE profileId = :profileId ORDER BY watchedAt DESC")
    suspend fun getAll(profileId: String = CurrentProfile.id): List<WatchedRecord>

    @Query("DELETE FROM watched WHERE profileId = :profileId AND `key` = :key")
    suspend fun deleteByKey(key: String, profileId: String = CurrentProfile.id)

    @Query("DELETE FROM watched WHERE profileId = :profileId")
    suspend fun clearAll(profileId: String = CurrentProfile.id)

    @Query("DELETE FROM watched WHERE profileId = :profileId")
    suspend fun deleteForProfile(profileId: String)
}
