package com.pulsestream.app.data

import androidx.media3.exoplayer.ExoPlayer

/**
 * Hand-off point between PlayerScreen and [PlaybackService]
 * (v0.14.13, item 6). PlayerScreen owns the player instances (it
 * rebuilds them on source/episode switches); every time the active
 * player or the playing title changes it re-attaches here, and the
 * foreground service mirrors THAT player into the media session +
 * lock-screen notification. The service never creates or releases
 * players — PlayerScreen's lifecycle is untouched, including the
 * hard-cut source swap and the resume-arming logic.
 */
object PlaybackBridge {

    @Volatile
    var player: ExoPlayer? = null
        private set

    @Volatile
    var title: String = ""
        private set

    @Volatile
    var subtitle: String = ""
        private set

    @Volatile
    var hasNext: Boolean = false
        private set

    /** True while the foreground playback service (and its session) is live. */
    @Volatile
    var sessionActive: Boolean = false

    private var nextAction: (() -> Unit)? = null

    @Volatile
    private var listener: ((ExoPlayer?) -> Unit)? = null

    fun attach(
        player: ExoPlayer,
        title: String,
        subtitle: String,
        hasNext: Boolean,
        onNext: () -> Unit
    ) {
        this.player = player
        this.title = title
        this.subtitle = subtitle
        this.hasNext = hasNext
        this.nextAction = onNext
        listener?.invoke(player)
    }

    /** Detach when [player] is no longer the screen's active player. */
    fun detach(player: ExoPlayer) {
        if (this.player === player) {
            this.player = null
            this.hasNext = false
            this.nextAction = null
            listener?.invoke(null)
        }
    }

    /** Detach whatever is attached (PlayerScreen is gone). */
    fun detachAll() {
        player = null
        hasNext = false
        nextAction = null
        listener?.invoke(null)
    }

    fun playNext() {
        nextAction?.invoke()
    }

    fun setListener(l: ((ExoPlayer?) -> Unit)?) {
        listener = l
        l?.invoke(player)
    }
}
