package com.pulsestream.app.data

import android.os.SystemClock
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.TimeUnit

/**
 * "Plavio Pick": background-probes stream URLs to find the best working one.
 *
 * Each http(s) candidate gets a HEAD request (falling back to a 1KB ranged GET
 * when HEAD is rejected); a 2xx/206 response counts as working and the
 * time-to-first-byte is recorded. Non-HTTP URLs (magnet:, etc.) are skipped.
 * Candidates are scored by resolution first, speed second.
 */
object StreamProber {

    private const val CONNECT_TIMEOUT_MS = 4000
    private const val READ_TIMEOUT_MS = 4000
    // v0.14.17 lag fix (audit cause 1): the fresh-probe budget drops
    // 24 -> 12 — verdict reuse (below) means a restarted run only
    // pays for genuinely new URLs, so a smaller wave still covers a
    // full merged list across restarts.
    private const val MAX_PROBES = 12
    private const val MAX_PARALLEL = 4
    private const val OVERALL_TIMEOUT_MS = 25_000L

    // How long a session verdict stays reusable by findBest: inside
    // the window a restarted probe run skips the network entirely
    // for that URL (ALIVE verdicts re-enter the pick with their
    // recorded TTFB/resolution; DEAD ones are skipped outright).
    private const val VERDICT_REUSE_MS = 10 * 60_000L

    // Second-chance probe (stream-skip investigation, 2026-10-27):
    // the 8 s call cap makes slow-but-playable streams invisible to
    // the pick (4 of 24 playable streams in the probe run answered
    // only at 11.6–14.1 s). Timed-out candidates at the top quality
    // ranks get ONE re-probe with a ~14 s budget before the pick is
    // finalised.
    private const val SECOND_CHANCE_CONNECT_MS = 5000
    private const val SECOND_CHANCE_READ_MS = 9000
    private const val SECOND_CHANCE_MAX = 4
    private const val SECOND_CHANCE_OVERALL_MS = 16_000L

    private data class Probe(val stream: StreamItem, val ttfbMs: Long, val resolution: Int)

    // ---- Session verdicts (stream-skip fixes 1 + 3) ----
    //
    // Every probe outcome is remembered for the process session so
    // the PLAYER can use what the prober already proved: candidates
    // verified alive fail over first, prober-proven corpses last
    // (and free — they don't consume the failover cap), and a host
    // whose streams all probed dead gets a short stall budget.

    enum class Verdict { ALIVE, DEAD }

    private val urlVerdicts = java.util.concurrent.ConcurrentHashMap<String, Verdict>()
    /** When each verdict was earned (elapsedRealtime) — drives reuse. */
    private val verdictAtMs = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** Recorded (TTFB, resolution) for ALIVE verdicts, for reuse. */
    private val aliveProbeInfo = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, Int>>()
    private val hostAlive = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val hostDeadCounts =
        java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.atomic.AtomicInteger>()

    private fun hostOf(url: String): String? =
        runCatching { java.net.URI(url).host }.getOrNull()?.lowercase()

    private fun recordVerdict(url: String, alive: Boolean, ttfbMs: Long? = null, resolution: Int = 0) {
        urlVerdicts[url] = if (alive) Verdict.ALIVE else Verdict.DEAD
        verdictAtMs[url] = SystemClock.elapsedRealtime()
        if (alive && ttfbMs != null) {
            aliveProbeInfo[url] = ttfbMs to resolution
        } else if (!alive) {
            aliveProbeInfo.remove(url)
        }
        val host = hostOf(url) ?: return
        if (alive) {
            hostAlive += host
        } else {
            hostDeadCounts.computeIfAbsent(host) {
                java.util.concurrent.atomic.AtomicInteger(0)
            }.incrementAndGet()
        }
    }

    /** The session verdict for one stream URL, if it was probed. */
    fun verdictOf(url: String): Verdict? = urlVerdicts[url]

    /** True when the prober already proved this stream dead this session. */
    fun isKnownDead(url: String): Boolean = urlVerdicts[url] == Verdict.DEAD

    /** Failover ordering rank: verified alive 0, unprobed 1, proven dead 2. */
    fun failoverRank(url: String): Int = when (urlVerdicts[url]) {
        Verdict.ALIVE -> 0
        Verdict.DEAD -> 2
        null -> 1
    }

    /**
     * True when this stream's HOST looks dead this session: at
     * least two of its streams probed dead and none probed alive.
     * (One dead URL proves nothing about the host — healthy hosts
     * serve dead links too, and slow hosts answer late.)
     */
    fun hostMarkedDead(url: String): Boolean {
        val host = hostOf(url) ?: return false
        if (host in hostAlive) return false
        return (hostDeadCounts[host]?.get() ?: 0) >= 2
    }

    /**
     * Returns the best working stream, or null when nothing verifiable answered.
     * Runs fully on Dispatchers.IO; safe to call from a ViewModel scope.
     *
     * Uses [PlaybackHeaders.buildPlaybackHeaders] so probing sends exactly
     * what the player will send — no more "healthy in probe, fails in player".
     */
    /** File size in GB parsed from a stream's labels, or null. */
    private fun sizeGbOf(stream: StreamItem): Double? {
        val label = "${stream.title.orEmpty()} ${stream.name.orEmpty()} ${stream.filename.orEmpty()}"
        val m = Regex("(\\d+(?:\\.\\d+)?)\\s*(GB|MB)", RegexOption.IGNORE_CASE).find(label)
            ?: return stream.videoSize?.let { it.toDouble() / 1_000_000_000.0 }
        val v = m.groupValues[1].toDoubleOrNull() ?: return null
        return if (m.groupValues[2].equals("GB", true)) v else v / 1024.0
    }

    /** Loose language match (name/ISO-3 folds to ISO-1 stem compare). */
    private fun languageMatches(stream: StreamItem, preferred: String?): Boolean {
        val pref = preferred?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: return false
        val lang = stream.audioLanguage?.trim()?.lowercase()?.takeIf { it.isNotBlank() }
            ?: return false
        if (lang == pref) return true
        val names = mapOf(
            "hindi" to "hi", "english" to "en", "urdu" to "ur", "arabic" to "ar",
            "spanish" to "es", "french" to "fr", "german" to "de", "turkish" to "tr",
            "korean" to "ko", "japanese" to "ja", "tamil" to "ta", "telugu" to "te",
            "bengali" to "bn", "punjabi" to "pa", "malayalam" to "ml",
            "marathi" to "mr", "russian" to "ru", "italian" to "it",
            "portuguese" to "pt", "indonesian" to "id", "thai" to "th",
            "vietnamese" to "vi", "persian" to "fa", "farsi" to "fa"
        )
        val a = names[lang] ?: if (lang.length >= 2) lang.take(2) else lang
        val b = names[pref] ?: if (pref.length >= 2) pref.take(2) else pref
        return a == b
    }

    /**
     * P6 (v0.14.22): the probe path now honours the SAME settings as
     * the autoplay rule — [maxSizeGb] (soft cap: known-oversize files
     * leave the pool unless nothing else remains), [explicitQuality]
     * (a set bucket restricts the pool to that bucket when any
     * candidate carries it), and [preferredLanguage] (preferred-audio
     * files win inside their resolution tier). Previously findBest
     * ignored the size cap entirely and took the highest resolution
     * alive whenever a bucket was set.
     */
    suspend fun findBest(
        streams: List<StreamItem>,
        isTv: Boolean = false,
        qualityCap: String? = null,
        maxSizeGb: Int = 0,
        explicitQuality: String? = null,
        preferredLanguage: String? = null
    ): StreamItem? = withContext(Dispatchers.IO) {
        var httpStreams = streams
            .filter { it.url.startsWith("http://") || it.url.startsWith("https://") }
        if (httpStreams.isEmpty()) return@withContext null
        if (maxSizeGb > 0) {
            val withinSize = httpStreams.filter { s ->
                sizeGbOf(s)?.let { it <= maxSizeGb } ?: true
            }
            // Soft cap, same as pickAutoplayStream: only narrow the
            // pool when something survives the narrowing.
            if (withinSize.isNotEmpty() && withinSize.size < httpStreams.size) {
                httpStreams = withinSize
            }
        }
        if (explicitQuality != null) {
            val bucketRank = qualityRank(explicitQuality)
            val inBucket = httpStreams.filter { resolutionScore(it) == bucketRank }
            if (inBucket.isNotEmpty()) httpStreams = inBucket
        }

        // Verdict-aware partitioning (v0.14.17 lag fix, audit cause
        // 1a): URLs with a fresh session verdict never touch the
        // network again — ALIVE ones re-enter the results with their
        // recorded TTFB/resolution, DEAD ones drop out entirely.
        // Only genuinely unknown (or stale-verdict) URLs are probed,
        // capped at MAX_PROBES.
        val nowMs = SystemClock.elapsedRealtime()
        val reused = ArrayList<Probe>()
        val toProbe = ArrayList<StreamItem>()
        for (s in httpStreams) {
            val at = verdictAtMs[s.url]
            val verdict = urlVerdicts[s.url]
            if (at != null && verdict != null && nowMs - at < VERDICT_REUSE_MS) {
                when (verdict) {
                    Verdict.DEAD -> Unit // skip: already proven dead
                    Verdict.ALIVE -> {
                        val info = aliveProbeInfo[s.url]
                        reused += Probe(s, info?.first ?: 0L, info?.second ?: resolutionScore(s))
                    }
                }
            } else {
                toProbe += s
            }
        }
        val candidates = toProbe.take(MAX_PROBES)

        val firstPass = if (candidates.isEmpty()) emptyList() else withTimeoutOrNull(OVERALL_TIMEOUT_MS) {
            coroutineScope {
                val gate = Semaphore(MAX_PARALLEL)
                candidates.map { stream ->
                    async {
                        gate.acquire()
                        try {
                            probeDetailed(stream, isTv, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS)
                        } finally {
                            gate.release()
                        }
                    }
                }.awaitAll()
            }
        }
        var results = reused + (firstPass?.mapNotNull { it.probe } ?: emptyList())

        // Second chance for slow starters (see the constants above):
        // candidates that TIMED OUT — not hard failures — at a
        // quality rank that could still win the pick get one
        // longer-budget re-probe. Runs after the main pass with its
        // own bounded window; a resurrected stream joins the results
        // (and its verdict flips to ALIVE for the player).
        // v0.14.17 lag fix (audit cause 1c): the round is skipped
        // entirely when an ALIVE result already exists at the timed
        // -out candidates' top quality rank — it could never win the
        // pick, so the extra ~14 s of network work buys nothing.
        val timedOut = firstPass.orEmpty()
            .filter { it.probe == null && it.timedOut }
            .map { it.stream }
        val topTimedOutRank = timedOut.maxOfOrNull { resolutionScore(it) } ?: -1
        val hasSameQualityAlive = results.any { it.resolution >= topTimedOutRank }
        if (timedOut.isNotEmpty() && !hasSameQualityAlive) {
            val bestAliveRank = results.maxOfOrNull { it.resolution } ?: 0
            val retry = timedOut
                .filter { resolutionScore(it) >= bestAliveRank }
                .sortedByDescending { resolutionScore(it) }
                .take(SECOND_CHANCE_MAX)
            if (retry.isNotEmpty()) {
                val second = withTimeoutOrNull(SECOND_CHANCE_OVERALL_MS) {
                    coroutineScope {
                        val gate = Semaphore(2)
                        retry.map { stream ->
                            async {
                                gate.acquire()
                                try {
                                    probeDetailed(
                                        stream, isTv,
                                        SECOND_CHANCE_CONNECT_MS, SECOND_CHANCE_READ_MS
                                    ).probe
                                } finally {
                                    gate.release()
                                }
                            }
                        }.awaitAll().filterNotNull()
                    }
                } ?: emptyList()
                results = results + second
            }
        }

        // Adaptive pick (user's order 2026-10-20, Netflix/YouTube style): when a
        // quality cap is given, prefer the highest resolution AT or BELOW the cap
        // (fastest first); only if every working stream exceeds the cap, take the
        // lowest one above it. Without a cap, legacy behavior: highest resolution.
        val capScore = when (qualityCap) {
            "2160p" -> 4; "1080p" -> 3; "720p" -> 2; "480p" -> 1; else -> null
        }
        val sorted = if (capScore != null) {
            results.sortedWith(
                compareBy<Probe> { if (it.resolution <= capScore) 0 else 1 }
                    .thenByDescending { if (it.resolution <= capScore) it.resolution else -it.resolution }
                    .thenBy { it.ttfbMs }
            )
        } else {
            results.sortedWith(compareByDescending<Probe> { it.resolution }.thenBy { it.ttfbMs })
        }
        // P6: language tier — inside each resolution tier, a file in
        // the preferred audio language wins (stable partition per tier).
        val tiered = if (preferredLanguage.isNullOrBlank()) sorted else {
            val out = ArrayList<Probe>(sorted.size)
            var i = 0
            while (i < sorted.size) {
                var j = i
                while (j < sorted.size && sorted[j].resolution == sorted[i].resolution) j++
                val group = sorted.subList(i, j)
                out += group.filter { languageMatches(it.stream, preferredLanguage) }
                out += group.filter { !languageMatches(it.stream, preferredLanguage) }
                i = j
            }
            out
        }
        tiered.firstOrNull()?.stream
    }

    /**
     * One probe's outcome: the successful [probe], or a failure —
     * [timedOut] separates a slow / no-answer host (eligible for
     * the second-chance re-probe) from a hard failure (an HTTP error
     * status was received, or the connection was refused).
     */
    private data class ProbeOutcome(
        val stream: StreamItem,
        val probe: Probe?,
        val timedOut: Boolean
    )

    private fun probeOne(stream: StreamItem, isTv: Boolean): Probe? =
        probeDetailed(stream, isTv, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS).probe

    private fun probeDetailed(
        stream: StreamItem, isTv: Boolean, connectMs: Int, readMs: Int
    ): ProbeOutcome {
        var timedOut = false
        val onError: (Exception) -> Unit = { e ->
            // SocketTimeoutException (and OkHttp's call timeout)
            // both surface as InterruptedIOException.
            if (e is java.io.InterruptedIOException) timedOut = true
        }
        val headers = PlaybackHeaders.buildPlaybackHeaders(stream.headers, isTv)
        // Match playback's redirect and credential-scoping behavior. A sensitive
        // header is retained on same-origin redirects and stripped cross-origin.
        val client = PlaybackHttp.client(stream.url).newBuilder()
            .connectTimeout(connectMs.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(readMs.toLong(), TimeUnit.MILLISECONDS)
            .callTimeout((connectMs + readMs).toLong(), TimeUnit.MILLISECONDS)
            .build()
        // HEAD reachability is not enough: require a media MIME, or verify a
        // bounded ranged body before considering an opaque/incorrect response playable.
        val head = headResult(client, stream, headers, onError)
        val evidence = head?.takeIf { it.second }?.first
            ?: rangedGetTtfb(client, stream, headers, onError)
        recordVerdict(stream.url, evidence != null, evidence, resolutionScore(stream))
        return ProbeOutcome(
            stream,
            evidence?.let { Probe(stream, it, resolutionScore(stream)) },
            timedOut && evidence == null
        )
    }

    /** Pair of HEAD latency and whether its response explicitly identifies media. */
    private fun headResult(
        client: OkHttpClient,
        stream: StreamItem,
        headers: Map<String, String>,
        onError: (Exception) -> Unit = {}
    ): Pair<Long, Boolean>? {
        return try {
            val start = SystemClock.elapsedRealtime()
            val request = Request.Builder().url(stream.url).apply {
                headers.forEach { (key, value) -> header(key, value) }
            }.head().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful && response.code != 206) return null
                val type = response.header("Content-Type").orEmpty().substringBefore(';').lowercase()
                val media = type.startsWith("video/") || type.startsWith("audio/") ||
                    type in setOf("application/vnd.apple.mpegurl", "application/x-mpegurl", "application/dash+xml")
                (SystemClock.elapsedRealtime() - start) to media
            }
        } catch (e: Exception) {
            onError(e)
            null
        }
    }

    /** Returns time-to-first-byte in ms when a 1KB ranged GET succeeds, else null. */
    private fun rangedGetTtfb(
        client: OkHttpClient,
        stream: StreamItem,
        headers: Map<String, String>,
        onError: (Exception) -> Unit = {}
    ): Long? {
        return try {
            val start = SystemClock.elapsedRealtime()
            val request = Request.Builder().url(stream.url).apply {
                headers.forEach { (key, value) -> header(key, value) }
                header("Range", "bytes=0-1023")
            }.get().build()
            client.newCall(request).execute().use { response ->
                // Touch only a short prefix so TTFB is real and probing remains bounded.
                if (!response.isSuccessful && response.code != 206) return null
                val bytes = ByteArray(256)
                val count = response.body?.byteStream()?.read(bytes) ?: -1
                val type = response.header("Content-Type").orEmpty().substringBefore(';').lowercase()
                val prefix = if (count > 0) String(bytes, 0, count, Charsets.ISO_8859_1).trimStart().lowercase() else ""
                val looksHtml = prefix.startsWith("<!doctype html") || prefix.startsWith("<html") || prefix.startsWith("{")
                val looksMedia = type.startsWith("video/") || type.startsWith("audio/") ||
                    type in setOf("application/vnd.apple.mpegurl", "application/x-mpegurl", "application/dash+xml")
                if (count > 0 && !looksHtml && (looksMedia || type == "application/octet-stream" || prefix.startsWith("#extm3u")))
                    SystemClock.elapsedRealtime() - start else null
            }
        } catch (e: Exception) {
            onError(e)
            null
        }
    }

    /** Rough resolution rank parsed from the stream's title/name labels. */
    private fun resolutionScore(stream: StreamItem): Int {
        val label = "${stream.title.orEmpty()} ${stream.name.orEmpty()}".lowercase()
        return when {
            "2160" in label || "4k" in label -> 4
            "1080" in label -> 3
            "720" in label -> 2
            "480" in label -> 1
            else -> 0
        }
    }

    /** Quality rank of a stream: 4=2160p, 3=1080p, 2=720p, 1=480p, 0=unknown. */
    fun qualityRank(stream: StreamItem): Int = resolutionScore(stream)

    /** Quality rank of a cap label like "1080p"; unknown labels rank 0. */
    fun qualityRank(label: String): Int = when (label.trim().lowercase()) {
        "2160p", "4k", "uhd" -> 4
        "1080p" -> 3
        "720p" -> 2
        "480p" -> 1
        else -> 0
    }

    /**
     * Orders streams for Live TV: verified-reachable first (fastest TTFB),
     * then everything not yet verified, in original order.
     * Budget-bounded ([deadlineMs]) — whatever is verified in time goes first
     * and playback start never stalls on probing. Unprobed streams are kept
     * after as failover candidates.
     */
    suspend fun rankByProbe(
        streams: List<StreamItem>,
        isTv: Boolean = false,
        deadlineMs: Long = 6_000L
    ): List<StreamItem> = withContext(Dispatchers.IO) {
        val candidates = streams
            .filter { it.url.startsWith("http://") || it.url.startsWith("https://") }
            .take(12)
        if (candidates.isEmpty()) return@withContext streams
        val alive = mutableListOf<Probe>()
        try {
            withTimeout(deadlineMs) {
                coroutineScope {
                    val gate = Semaphore(4)
                    val deferreds = candidates.map { stream ->
                        async { gate.withPermit { probeOne(stream, isTv) } }
                    }
                    deferreds.forEach { d -> d.await()?.let { alive.add(it) } }
                }
            }
        } catch (_: TimeoutCancellationException) {
            // Partial results stand — the verified ones still go first.
        }
        val ordered = alive.sortedBy { it.ttfbMs }.map { it.stream }
        val aliveUrls = ordered.map { it.url }.toSet()
        ordered + streams.filter { it.url !in aliveUrls }
    }
}
