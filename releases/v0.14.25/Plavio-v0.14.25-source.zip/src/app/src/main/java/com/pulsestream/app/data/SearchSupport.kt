package com.pulsestream.app.data

import kotlin.math.abs
import kotlin.math.min

/**
 * Pure search-pipeline helpers for the app-owned search stage
 * (v0.14.27). Keeping merge / rank / cache-seed / typo logic free of
 * Android and Room types lets the unit tests exercise the exact rules
 * the live Search screen uses.
 */
internal object SearchSupport {
    /** Synthetic addon id for keyless primary results from PMeta /search.json. */
    const val PRIMARY_ADDON_ID = "plavio-primary-search"

    /** Synthetic addon id for primary results from the user's own TMDB key. */
    const val TMDB_ADDON_ID = "plavio-tmdb-search"

    /**
     * The ONLY display name Plavio's own search machinery ever shows
     * (owner's rule 2026-10-31): whichever engine serves a row behind
     * the scenes — the keyed TMDB lane, the keyless first-party
     * endpoint, any future engine — the user sees "Plavio Search".
     * Both primary lanes are built with this name; third-party addon
     * rows keep their own addon's name.
     */
    const val PRIMARY_SEARCH_NAME = "Plavio Search"

    /**
     * The keyless lane's search door as last published by the remote
     * app config ([AppConfig] pushes its validated config-set door
     * here). Null — the standing state: no config yet, config
     * unreachable, field unset — keeps the compiled-in first-party
     * constant. Set ONLY by AppConfig; the value is re-validated at
     * this seam too, so nothing unvalidated can ever steer the lane.
     * Tests reset it to null.
     */
    @Volatile
    var searchDoorOverride: String? = null

    /**
     * Keyless primary-lane URL. The base is a first-party door —
     * the remote config's validated search door when one is
     * published, else the compiled-in constant — deliberately NOT
     * read from any installed addon's stored baseUrl and NOT gated
     * on the PMeta addon being installed or enabled: the lane must
     * fire even when the user has removed PMeta (owner's hard
     * requirement 2026-10-31: "People can remove PMeta, they can
     * remove key, but our search should work"). The only inputs are
     * the door and the query itself, so no registry state can couple
     * into it.
     */
    fun keylessSearchUrl(query: String): String {
        val door = searchDoorOverride?.let { AppConfigSupport.validDoorOrNull(it) }
            ?: AppConfigSupport.DEFAULT_SEARCH_DOOR
        return AppConfigSupport.searchUrl(door, query)
    }

    fun isPrimary(result: CachedMeta): Boolean =
        result.addonId == PRIMARY_ADDON_ID || result.addonId == TMDB_ADDON_ID

    private val yearPattern = Regex("(?<!\\d)(18\\d{2}|19\\d{2}|20\\d{2})(?!\\d)")

    /** Lowercase, punctuation-stripped title/query form. */
    fun normalize(raw: String): String =
        raw.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim().replace(Regex("\\s+"), " ")

    fun yearOf(releaseInfo: String?): Int? =
        releaseInfo?.let { yearPattern.find(it)?.value?.toIntOrNull() }

    /**
     * Parsed rating, or null when there is none. A 0.0 is NO rating
     * (TMDB vote_average 0 = zero votes; MDBList likewise reports 0.0
     * for unrated titles) — treating it as a real rating made unrated
     * rows count as "anchored" and rendered a "★ 0.0" badge on device.
     */
    fun ratingOf(imdbRating: String?): Double? =
        imdbRating?.substringBefore('/')?.trim()?.toDoubleOrNull()?.takeIf { it > 0.0 && it <= 10.0 }

    private fun mappedType(type: String): String = when (type.lowercase()) {
        "tv", "series" -> "series"
        else -> type.lowercase()
    }

    /**
     * Canonical identity for union merging. IMDb ids are global; TMDB
     * ids are canonicalised across the `tmdb:movie:`, `tmdb:tv:` and
     * bare `tmdb:` spellings (media type included — TMDB movie and TV
     * id spaces overlap numerically). Every other id is only unique
     * inside its own addon, so the addon stays part of the key.
     */
    fun identityKey(result: CachedMeta): String {
        val id = result.meta.id.trim().lowercase()
        if (id.startsWith("tt")) return "tt|$id"
        if (id.startsWith("tmdb:")) {
            val parts = id.removePrefix("tmdb:").split(":").filter { it.isNotBlank() }
            val numeric = parts.lastOrNull()?.toIntOrNull()
            if (numeric != null) {
                val media = when (parts.firstOrNull()) {
                    "movie" -> "movie"
                    "tv", "series" -> "series"
                    else -> mappedType(result.meta.type)
                }
                return "tmdb|$media|$numeric"
            }
        }
        return "addon|${result.addonId}|${mappedType(result.meta.type)}|$id"
    }

    /** [primary]'s fields win; blank fields are filled from [fallback]. */
    private fun fillMeta(primary: MetaPreview, fallback: MetaPreview): MetaPreview =
        primary.copy(
            poster = primary.poster?.takeIf { it.isNotBlank() } ?: fallback.poster,
            background = primary.background?.takeIf { it.isNotBlank() } ?: fallback.background,
            logo = primary.logo?.takeIf { it.isNotBlank() } ?: fallback.logo,
            description = primary.description?.takeIf { it.isNotBlank() } ?: fallback.description,
            releaseInfo = primary.releaseInfo?.takeIf { it.isNotBlank() } ?: fallback.releaseInfo,
            imdbRating = primary.imdbRating?.takeIf { it.isNotBlank() } ?: fallback.imdbRating,
            genres = primary.genres.ifEmpty { fallback.genres },
            popularity = maxOf(primary.popularity, fallback.popularity)
        )

    /**
     * Union by canonical identity: no lane can discard another lane's
     * rows. Primary copies come first in the map, so on an identity
     * collision the merged row keeps the primary lane's identity and
     * fields (blanks filled from the floor copy).
     */
    fun mergeByIdentity(
        primary: List<CachedMeta>,
        floor: List<CachedMeta>
    ): List<CachedMeta> {
        if (primary.isEmpty()) return floor
        if (floor.isEmpty()) return primary
        val byIdentity = LinkedHashMap<String, CachedMeta>()
        for (item in primary) byIdentity.putIfAbsent(identityKey(item), item)
        for (item in floor) {
            val key = identityKey(item)
            val existing = byIdentity[key]
            if (existing == null) {
                byIdentity[key] = item
            } else if (isPrimary(existing)) {
                byIdentity[key] = existing.copy(meta = fillMeta(existing.meta, item.meta))
            }
        }
        return byIdentity.values.toList()
    }

    private fun mergeGroup(
        candidates: List<CachedMeta>,
        addonRank: (CachedMeta) -> Int
    ): CachedMeta {
        val ordered = candidates.sortedWith(
            compareBy<CachedMeta> { if (isPrimary(it)) 0 else 1 }
                .thenBy { addonRank(it) }
                .thenByDescending { ratingOf(it.meta.imdbRating) ?: -1.0 }
                .thenByDescending { yearOf(it.meta.releaseInfo) ?: 0 }
        )
        val base = ordered.first()
        var merged = base.meta
        for (other in ordered.drop(1)) {
            merged = fillMeta(merged, other.meta)
        }
        return base.copy(meta = merged)
    }

    /** A deduped row carrying at least one signal that identifies it
     *  as a distinct work: a primary-lane origin, a known year, a TMDB
     *  popularity signal, or an IMDb rating. */
    private fun isAnchored(result: CachedMeta): Boolean =
        isPrimary(result) || result.meta.popularity > 0.0 ||
            yearOf(result.meta.releaseInfo) != null ||
            ratingOf(result.meta.imdbRating) != null

    /** A deduped row with NO identifying signal at all: not from the
     *  primary lane, no year, no rating, no popularity — nothing that
     *  distinguishes it from a same-named work beyond the bare title. */
    private fun isBare(result: CachedMeta): Boolean =
        !isPrimary(result) && result.meta.popularity == 0.0 &&
            yearOf(result.meta.releaseInfo) == null &&
            ratingOf(result.meta.imdbRating) == null

    /**
     * Cross-type namesake reconciliation (v0.14.28, the MobLand ghost).
     * Catalog type is a hard partition in the collapse above, so a
     * year-less namesake filed under the OTHER type can never join its
     * group: Cinemeta's movie search answers "MobLand" with an obscure
     * year-less, rating-less movie row (tt15379560) beside the hit 2025
     * series, and the grid showed both. When a normalised title has
     * exactly ONE anchored row and every other row for that title is
     * bare AND of a different type, the bare rows fold into the
     * anchored row (anchored fields win; popularity takes the max) —
     * they carry no evidence of being a separate work. Anything with a
     * year, a rating, a popularity signal, or a second anchored
     * namesake (a real same-name movie AND series) is left untouched.
     */
    private fun foldBareNamesakes(rows: List<CachedMeta>): List<CachedMeta> {
        if (rows.size < 2) return rows
        val byName = LinkedHashMap<String, MutableList<Int>>()
        rows.forEachIndexed { index, item ->
            byName.getOrPut(normalize(item.meta.name)) { mutableListOf() }.add(index)
        }
        if (byName.values.all { it.size == 1 }) return rows
        val removed = BooleanArray(rows.size)
        val replaced = HashMap<Int, CachedMeta>()
        for ((_, indices) in byName) {
            if (indices.size < 2) continue
            val anchored = indices.filter { isAnchored(rows[it]) }
            if (anchored.size != 1) continue
            val anchorIndex = anchored.single()
            val anchor = rows[anchorIndex]
            var merged = anchor
            var foldedAny = false
            for (index in indices) {
                if (index == anchorIndex) continue
                val other = rows[index]
                if (!isBare(other)) continue
                if (mappedType(other.meta.type) == mappedType(anchor.meta.type)) continue
                merged = merged.copy(meta = fillMeta(merged.meta, other.meta))
                removed[index] = true
                foldedAny = true
            }
            if (foldedAny) replaced[anchorIndex] = merged
        }
        if (replaced.isEmpty()) return rows
        return rows.mapIndexedNotNull { index, item ->
            if (removed[index]) null else replaced[index] ?: item
        }
    }

    /**
     * Ranking + cross-lane title collapse. Same title/type rows from
     * several lanes collapse into one row per distinct known year
     * (remakes stay separate; year-less copies join the newest bucket),
     * with primary-lane fields winning the merged row. Ordering is
     * match tier (exact > prefix > contains > other), then TMDB
     * popularity, then IMDb rating, then year, then addon preference.
     */
    fun rank(
        results: List<CachedMeta>,
        query: String,
        addonRank: (CachedMeta) -> Int = { 2 }
    ): List<CachedMeta> {
        if (results.isEmpty()) return results
        val q = normalize(query)
        val groups = LinkedHashMap<Pair<String, String>, MutableList<CachedMeta>>()
        for (item in results) {
            groups.getOrPut(normalize(item.meta.name) to mappedType(item.meta.type)) { mutableListOf() }
                .add(item)
        }
        val deduped = ArrayList<CachedMeta>(groups.size)
        for ((_, group) in groups) {
            if (group.size == 1) {
                deduped += group[0]
                continue
            }
            val byYear = group.groupBy { yearOf(it.meta.releaseInfo) }
            val knownYears = byYear.keys.filterNotNull().sorted()
            if (knownYears.size <= 1) {
                deduped += mergeGroup(group, addonRank)
            } else {
                knownYears.forEachIndexed { index, year ->
                    val yearless: List<CachedMeta> =
                        if (index == knownYears.lastIndex) byYear[null].orEmpty() else emptyList()
                    deduped += mergeGroup(byYear[year].orEmpty() + yearless, addonRank)
                }
            }
        }

        fun matchTier(name: String): Int {
            val n = normalize(name)
            return when {
                q.isEmpty() -> 2
                n == q -> 0
                n.startsWith(q) -> 1
                n.contains(q) -> 2
                else -> 3
            }
        }

        return foldBareNamesakes(deduped).sortedWith(
            compareBy<CachedMeta> { matchTier(it.meta.name) }
                .thenByDescending { it.meta.popularity }
                .thenByDescending { ratingOf(it.meta.imdbRating) ?: -1.0 }
                .thenByDescending { yearOf(it.meta.releaseInfo) ?: 0 }
                .thenBy { addonRank(it) }
        )
    }

    /** One session-scope query-cache entry (ranked final union). */
    data class QueryCacheEntry(
        val scope: String,
        val typeKey: String,
        val query: String,
        val storedAtMs: Long,
        val results: List<CachedMeta>
    )

    /**
     * Instant-display seed from the query cache: an exact hit replays
     * whole; otherwise the closest prefix-relative entry (one query a
     * prefix of the other) contributes only rows still relevant to the
     * new query. The fresh search always runs behind the seed — the
     * seed never becomes the final answer on its own.
     */
    fun cacheSeed(
        entries: Collection<QueryCacheEntry>,
        scope: String,
        typeKey: String,
        query: String,
        nowMs: Long,
        ttlMs: Long
    ): List<CachedMeta> {
        val q = normalize(query)
        if (q.isEmpty()) return emptyList()
        val fresh = entries.filter {
            it.scope == scope && it.typeKey == typeKey && nowMs - it.storedAtMs in 0..ttlMs
        }
        fresh.firstOrNull { it.query == q }?.let { return it.results }
        val related = fresh.filter { entry ->
            entry.query.startsWith(q) || q.startsWith(entry.query)
        }
        val selected = related.maxWithOrNull(
            compareBy<QueryCacheEntry> { commonPrefixLength(it.query, q) }
                .thenBy { -abs(it.query.length - q.length) }
        ) ?: return emptyList()
        return selected.results.filter { item ->
            val title = normalize(item.meta.name)
            title.contains(q) || q.contains(title) || title.startsWith(q) || q.startsWith(title)
        }
    }

    private fun commonPrefixLength(a: String, b: String): Int {
        var i = 0
        while (i < min(a.length, b.length) && a[i] == b[i]) i++
        return i
    }

    /**
     * The single bounded typo-correction candidate, or null. Covers:
     * (1) punctuation/spacing normalisation ("Dune: Part-Three" →
     * "dune part three"); (2) one edit-distance-1 replacement of the
     * longest query word (≥4 chars, same first letter), where the
     * replacement word comes from [dictionaryTitles] — the titles the
     * app has actually seen (local catalogue + floor/cache rows), so
     * the "best" variant is a real title word, never a fabricated
     * guess. Does NOT cover: multi-word typos, errors in short words,
     * or corrections with no nearby real title word on record.
     */
    fun correctionCandidate(query: String, dictionaryTitles: Collection<String>): String? {
        val normalized = normalize(query)
        if (normalized.length < 4) return null
        if (normalized != query.trim().lowercase()) return normalized
        val words = normalized.split(" ").filter { it.isNotBlank() }
        val longest = words.maxByOrNull { it.length } ?: return null
        if (longest.length < 4) return null
        val dictionaryWords = dictionaryTitles
            .flatMap { normalize(it).split(" ") }
            .filter { it.length >= 3 }
            .toSet()
        val best = dictionaryWords
            .filter { it != longest && it.firstOrNull() == longest.firstOrNull() }
            .map { it to editDistance(longest, it) }
            .filter { it.second == 1 }
            .minWithOrNull(compareBy<Pair<String, Int>> { it.second }.thenBy { abs(it.first.length - longest.length) })
            ?.first ?: return null
        return words.joinToString(" ") { if (it == longest) best else it }
    }

    /** Levenshtein distance with an adjacent transposition costing 1. */
    internal fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (abs(a.length - b.length) > 2) return abs(a.length - b.length)
        val rows = a.length + 1
        val cols = b.length + 1
        val dist = Array(rows) { IntArray(cols) }
        for (i in 0 until rows) dist[i][0] = i
        for (j in 0 until cols) dist[0][j] = j
        for (i in 1 until rows) {
            for (j in 1 until cols) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var best = min(
                    min(dist[i - 1][j] + 1, dist[i][j - 1] + 1),
                    dist[i - 1][j - 1] + cost
                )
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    best = min(best, dist[i - 2][j - 2] + 1)
                }
                dist[i][j] = best
            }
        }
        return dist[a.length][b.length]
    }
}
