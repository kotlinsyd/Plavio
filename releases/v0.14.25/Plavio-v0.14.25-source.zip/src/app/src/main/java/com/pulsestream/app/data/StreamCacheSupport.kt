package com.pulsestream.app.data

/**
 * Pure rules for the session stream-result cache (v0.14.36, defect 1:
 * addon formatter styles never synced without a reinstall).
 *
 * The cache in [StreamRepository] holds MERGED STREAM PAYLOADS —
 * the exact name/title text a formatter composed. It exists for two
 * display purposes only: painting the last-known list instantly while
 * a fresh fetch replaces it (progressive loading), and the PrePlay
 * pocket. It must never be the final answer to a fetch that asked
 * for fresh data, and it must never outlive the configuration that
 * produced it:
 *
 *  - The seed paint window is SHORT ([SEED_TTL_MS]). The constant
 *    this replaces was 3 hours, contradicting the cache's own
 *    documented intent ("entries live a few minutes") — a formatter
 *    change on the server stayed invisible behind hours-old text.
 *  - Consumers that settle on an emission (the player's background
 *    pool refresh, the credential refresh, the Continue Watching
 *    fresh-URL pass) pass seedFromCache = false: their first
 *    emission is then real network data, never this store.
 *  - Every addon lifecycle event (add / refresh / remove /
 *    enable / disable) clears the cache through
 *    StreamRepository.invalidateAddonCaches, so the Addons page's
 *    quiet auto-refresh — which already revalidates manifests,
 *    logos and versions — now busts stale stream payloads too.
 */
object StreamCacheSupport {

    /**
     * How long a cached merged result may be painted as the seed of
     * a new collect. Five minutes — the same freshness window the
     * PrePlay pocket itself uses (PREPLAY_FRESH_MS): beyond it a
     * reopen starts from the loading state and the network answer,
     * not from text an old configuration produced.
     */
    const val SEED_TTL_MS: Long = 5L * 60L * 1000L

    /** True when the entry is young enough to paint as a seed. */
    fun isSeedFresh(cachedAtMs: Long, nowMs: Long, ttlMs: Long = SEED_TTL_MS): Boolean =
        cachedAtMs > 0L && nowMs - cachedAtMs < ttlMs

    /**
     * The one seed decision every collect makes: emit the cached
     * entry first only when the caller allows the seed AND the
     * entry is still inside its paint window.
     */
    fun shouldEmitSeed(cachedAtMs: Long?, nowMs: Long, seedFromCache: Boolean): Boolean =
        seedFromCache && cachedAtMs != null && isSeedFresh(cachedAtMs, nowMs)
}
