package com.pulsestream.app.data.notifications

import android.content.Context
import android.content.SharedPreferences

/**
 * Per-series episode-notification choices (v0.14.13, item 2 — the
 * detail page's bell). Stores ONLY the user's EXPLICIT choices,
 * keyed by series meta id (IMDb tt id):
 *
 *  - explicit ON  -> the series is subscribed: the background
 *    checker scans it even when it sits in no followed list, and
 *    the show's name is kept alongside so a notification can be
 *    titled before any meta resolves.
 *  - explicit OFF -> the series is muted: followed or not, the
 *    checker skips it.
 *  - no entry     -> the default rule applies: followed series
 *    notify, others don't (computed live in DetailScreen and in
 *    EpisodeCheckWorker from StreamRepository.followedSeries).
 *
 * SharedPreferences, like [EpisodeTracker]: tiny sync state that
 * must be readable from the worker without a schema migration.
 */
class EpisodeNotifyStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The user's explicit choice for a series, or null when never touched. */
    fun explicitChoice(metaId: String): Boolean? {
        if (!prefs.contains(choiceKey(metaId))) return null
        return prefs.getBoolean(choiceKey(metaId), false)
    }

    /** Record an explicit bell tap. [name] is kept for subscribed series. */
    fun setChoice(metaId: String, on: Boolean, name: String?) {
        prefs.edit().apply {
            putBoolean(choiceKey(metaId), on)
            if (on && !name.isNullOrBlank()) putString(nameKey(metaId), name)
            if (!on) remove(nameKey(metaId))
        }.apply()
    }

    /** Series with an explicit ON: meta id -> remembered show name (may be null). */
    fun subscribed(): Map<String, String?> {
        val out = LinkedHashMap<String, String?>()
        for ((key, value) in prefs.all) {
            if (!key.startsWith(CHOICE_PREFIX) || value != true) continue
            val metaId = key.removePrefix(CHOICE_PREFIX)
            out[metaId] = prefs.getString(nameKey(metaId), null)
        }
        return out
    }

    companion object {
        private const val PREFS = "pulse_episode_notify"
        private const val CHOICE_PREFIX = "choice_"
        private const val NAME_PREFIX = "name_"

        private fun choiceKey(metaId: String): String = "$CHOICE_PREFIX$metaId"
        private fun nameKey(metaId: String): String = "$NAME_PREFIX$metaId"
    }
}
