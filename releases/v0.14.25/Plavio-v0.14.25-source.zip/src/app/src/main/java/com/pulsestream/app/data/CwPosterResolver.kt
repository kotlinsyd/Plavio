package com.pulsestream.app.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap

/**
 * Background title-poster resolution for Continue Watching tiles in
 * Poster artwork mode (notes item 35, Discord request the owner
 * approved 2026-10-28).
 *
 * A locally played episode row saves its SCENE still (the episode
 * thumbnail) as the tile art; the title's poster lives only in the
 * series meta. This resolver fetches it in the BACKGROUND — from the
 * serving addon's meta endpoint first, any installed meta addon as
 * fallback (wired in PulseApp to StreamRepository.resolvePosterUrl,
 * the same route LogoResolver uses) — and caches it process-wide by
 * "type|metaId". Tiles read the cache and repaint when a poster
 * lands; nothing ever waits on it, and a title with no poster
 * anywhere simply keeps its saved scene art.
 *
 * Misses are remembered too (with a retry window), so a rail of
 * poster-less titles doesn't re-fetch on every recomposition.
 * Mirrors [LogoResolver] deliberately — same discipline, new field.
 */
object CwPosterResolver {

    /** Resolved posters by "type|metaId" — observed by CW tiles. */
    private val _posters = MutableStateFlow<Map<String, String>>(emptyMap())
    val posters: StateFlow<Map<String, String>> = _posters.asStateFlow()

    /** Miss timestamps by the same key; retried after the window. */
    private val misses = ConcurrentHashMap<String, Long>()
    private val inFlight = ConcurrentHashMap.newKeySet<String>()
    private const val MISS_RETRY_MS = 10 * 60_000L

    /** The actual fetch, wired once by PulseApp. */
    @Volatile
    var fetcher: (suspend (addonId: String?, type: String, metaId: String) -> String?)? = null

    /** Process-wide cap on concurrent meta walks (v0.14.17 lag fix). */
    private val walkGate = Semaphore(3)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun key(type: String, metaId: String) = "$type|$metaId"

    /** A poster already resolved this process, or null. */
    fun cached(type: String, metaId: String): String? = _posters.value[key(type, metaId)]

    /** A poster handed to us by a full meta load — free cache fill. */
    fun prime(type: String, metaId: String, poster: String?) {
        val url = poster?.takeIf { it.isNotBlank() } ?: return
        val k = key(type, metaId)
        if (_posters.value[k] != url) {
            _posters.update { it + (k to url) }
        }
    }

    /**
     * Ask for a title's poster in the background. Safe to call on
     * every composition: cached hits, in-flight requests and fresh
     * misses all no-op.
     */
    fun request(addonId: String?, type: String, metaId: String) {
        if (type.isBlank() || metaId.isBlank()) return
        val k = key(type, metaId)
        if (_posters.value.containsKey(k)) return
        val missedAt = misses[k]
        if (missedAt != null && System.currentTimeMillis() - missedAt < MISS_RETRY_MS) return
        if (!inFlight.add(k)) return
        val fetch = fetcher
        if (fetch == null) {
            inFlight.remove(k)
            return
        }
        scope.launch {
            try {
                walkGate.withPermit {
                    val url = runCatching { fetch(addonId, type, metaId) }.getOrNull()
                        ?.takeIf { it.isNotBlank() }
                    if (url != null) {
                        misses.remove(k)
                        _posters.update { it + (k to url) }
                    } else {
                        misses[k] = System.currentTimeMillis()
                    }
                }
            } finally {
                inFlight.remove(k)
            }
        }
    }
}
