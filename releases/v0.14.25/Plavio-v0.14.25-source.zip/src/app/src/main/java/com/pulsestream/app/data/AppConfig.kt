package com.pulsestream.app.data

import android.content.Context
import android.content.SharedPreferences
import com.pulsestream.app.BuildConfig
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The remote app config reader (v0.14.28, owner's order 2026-10-31:
 * little server-driven updates without an APK). Fetches
 * https://meta.plavio.site/app-config.json — doors, one announcement,
 * a minimum-version floor, feature switches — and holds the last-good
 * copy. Pure parse/validation lives in [AppConfigSupport]; this file
 * is only transport, persistence and state.
 *
 * Fire-and-forget by construction, mirroring [PlavioWarm] and
 * AppStats: [start] is called once from PulseApp.onCreate, loads the
 * persisted last-good synchronously (SharedPreferences are
 * memory-cached after first read — SettingsStore already reads prefs
 * in onCreate), then refreshes on this object's OWN IO scope. Startup
 * never waits on the network, no caller ever suspends on the config,
 * and every failure mode — offline, 404, garbage body, a config that
 * has not been published yet — silently keeps the previous state.
 * Before the first successful fetch the state is
 * [AppConfigSupport.EMPTY], whose compiled-in defaults reproduce the
 * pre-config behaviour exactly.
 */
object AppConfig {

    const val CONFIG_URL = "https://meta.plavio.site/app-config.json"

    private const val PREFS = "plavio_app_config"
    private const val KEY_LAST_GOOD = "last_good_json"
    private const val KEY_ANNOUNCEMENT_SEEN = "announcement_seen_id"
    private const val MAX_BODY_BYTES = 64 * 1024

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ ->
            // A config failure must never surface anywhere.
        }
    )
    private val started = AtomicBoolean(false)

    private val _state = MutableStateFlow(AppConfigSupport.EMPTY)

    /** The live config: last-good at startup, refreshed in the
     *  background. Compose observes this for the announcement and the
     *  minimum-version floor. */
    val state: StateFlow<AppConfigSupport.AppConfigData> = _state.asStateFlow()

    fun current(): AppConfigSupport.AppConfigData = _state.value

    /** Effective PMeta door (config → compiled default). */
    fun pmetaDoor(): String = AppConfigSupport.pmetaDoor(current())

    /** Effective PMeta manifest URL under [pmetaDoor]. */
    fun pmetaManifestUrl(): String = AppConfigSupport.pmetaManifestUrl(current())

    fun switchEnabled(key: String, default: Boolean): Boolean =
        AppConfigSupport.switchEnabled(current(), key, default)

    /** Warm triggers (search-settle + Detail-open /warm pings).
     *  Default ON: a config that never mentions the switch keeps the
     *  behaviour the feature shipped with. */
    fun warmTriggersEnabled(): Boolean =
        switchEnabled(AppConfigSupport.SWITCH_WARM_TRIGGERS, default = true)

    /**
     * Reserved accessor for the published searchIndex switch: the
     * keyless lane's index behaviour is decided server-side (PMeta
     * consults the index when IT serves the lane), so nothing app-side
     * consumes this yet — the accessor exists so the day a client
     * behaviour hangs off it, the seam is already here. Search itself
     * is NEVER gated on it: our search must work keyless, PMeta-less,
     * config-less (owner's hard requirement 2026-10-31).
     */
    fun searchIndexEnabled(): Boolean =
        switchEnabled(AppConfigSupport.SWITCH_SEARCH_INDEX, default = true)

    /** Playback feedback reporter (PlavioFeedback). Default ON: a
     *  config that never mentions the switch keeps the behaviour the
     *  feature shipped with; the owner can silence every report from
     *  the server without an APK. */
    fun feedbackEnabled(): Boolean =
        switchEnabled(AppConfigSupport.SWITCH_FEEDBACK, default = true)

    /** Native debrid layer (DebridService). Default ON: a config that
     *  never mentions the switch keeps the behaviour the feature
     *  shipped with. When OFF, infohash/magnet rows behave exactly as
     *  they did before debrid existed — listed, labelled
     *  debrid-required, never resolved, never autoplayed. */
    fun debridEnabled(): Boolean =
        switchEnabled(AppConfigSupport.SWITCH_DEBRID, default = true)

    /**
     * Entry point, called once from PulseApp.onCreate. Loads the
     * last-good config from prefs, pushes its search door into
     * [SearchSupport], then refreshes in the background. Idempotent
     * and non-blocking; every step failure-isolated.
     */
    fun start(context: Context) {
        if (!started.compareAndSet(false, true)) return
        val appContext = context.applicationContext
        runCatching {
            prefs(appContext).getString(KEY_LAST_GOOD, null)
                ?.let { AppConfigSupport.parse(it) }
                ?.let { apply(it) }
        }
        scope.launch { runCatching { refresh(appContext) } }
    }

    private fun apply(data: AppConfigSupport.AppConfigData) {
        _state.value = data
        // The keyless search lane reads its door from SearchSupport
        // (a pure seam the unit tests pin); push the validated
        // config-set door there. Null restores the compiled default.
        SearchSupport.searchDoorOverride = data.searchDoor
    }

    /** One refresh attempt. Only a body that parses replaces the
     *  last-good copy — garbage is dropped, never persisted. */
    private fun refresh(context: Context) {
        val body = fetch() ?: return
        val parsed = AppConfigSupport.parse(body) ?: return
        prefs(context).edit().putString(KEY_LAST_GOOD, body).apply()
        apply(parsed)
    }

    /** Blocking fetch on the IO scope (UpdateChecker's transport
     *  shape: HttpURLConnection, hard timeouts, size cap). Null on
     *  any failure. */
    private fun fetch(): String? {
        val conn = (URL(CONFIG_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            setRequestProperty("User-Agent", "Plavio/${BuildConfig.VERSION_NAME}")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (conn.responseCode != 200) return null
            if (conn.contentLengthLong > MAX_BODY_BYTES) return null
            conn.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (output.size() + n > MAX_BODY_BYTES) return null
                    output.write(buffer, 0, n)
                }
                output.toString(Charsets.UTF_8.name())
            }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- Announcement seen-state (show once per id) ----

    fun seenAnnouncementId(context: Context): String? =
        prefs(context).getString(KEY_ANNOUNCEMENT_SEEN, null)

    fun markAnnouncementSeen(context: Context, id: String) {
        prefs(context).edit().putString(KEY_ANNOUNCEMENT_SEEN, id).apply()
    }

    /** The current announcement when the user has not seen this id
     *  yet; null renders nothing (Compose additionally re-checks via
     *  [seenAnnouncementId] so dismissal is instant). */
    fun pendingAnnouncement(context: Context): AppConfigSupport.Announcement? =
        current().announcement?.takeIf { it.id != seenAnnouncementId(context) }
}
