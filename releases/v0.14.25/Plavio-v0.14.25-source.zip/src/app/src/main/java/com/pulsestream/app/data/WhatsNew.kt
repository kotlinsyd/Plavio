package com.pulsestream.app.data

/**
 * What's New (v0.14.39, owner approved 2026-11-12): one small card
 * after an update — 2–3 plain lines about what changed — shown ONCE
 * per version (first open after the update), plus a permanent door
 * in Settings → About. Pure logic so the show/stamp rules unit-test
 * without Android.
 */
object WhatsNew {

    data class Entry(
        val versionCode: Int,
        val versionName: String,
        val lines: List<String>
    )

    /** Newest first. Only versions with something user-visible get an entry. */
    val entries: List<Entry> = listOf(
        Entry(
            versionCode = 223,
            versionName = "0.14.39",
            lines = listOf(
                "Settings has a new layout — one home for every setting, nothing doubled.",
                "Auto-download next episode is in Downloads — the next episode queues itself when one ends.",
                "Upcoming now lives inside Up Next — one door for what to watch next.",
                "Follow actors from their page and see their new titles on Home.",
                "The player loading screen keeps the details line under the status again."
            )
        )
    )

    fun entryFor(versionCode: Int): Entry? = entries.firstOrNull { it.versionCode == versionCode }

    /**
     * Auto-show rule: an entry exists for the RUNNING version, the
     * user has updated since the last stamp (current > lastSeen),
     * and this is not a fresh install (lastSeen == 0 is stamped
     * silently instead — nobody needs a tour of their first version).
     */
    fun shouldShow(lastSeenCode: Int, currentCode: Int): Boolean =
        lastSeenCode != 0 && currentCode > lastSeenCode && entryFor(currentCode) != null
}
