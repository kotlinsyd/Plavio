package com.pulsestream.app.ui.screens.player

import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.StreamResult
import com.pulsestream.app.data.Subtitle
import com.pulsestream.app.data.isPlayableLiveStreamUrl
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Only recover a mobile Live source that never became playable after a bounded startup window. */
internal const val MOBILE_LIVE_STARTUP_TIMEOUT_MS = 30_000L

internal fun shouldFailoverStalledLiveStartup(
    isLive: Boolean,
    isTv: Boolean,
    playWhenReady: Boolean,
    hasEverPlayed: Boolean,
    isBuffering: Boolean,
    elapsedMs: Long,
    timeoutMs: Long = MOBILE_LIVE_STARTUP_TIMEOUT_MS
): Boolean = isLive && !isTv && playWhenReady && !hasEverPlayed && isBuffering &&
    elapsedMs >= timeoutMs

/** Paused or ready time cannot exhaust the active startup-buffering budget. */
internal fun liveStartupWaitingSince(
    previousMs: Long?,
    nowMs: Long,
    playWhenReady: Boolean,
    isBuffering: Boolean
): Long? = if (playWhenReady && isBuffering) previousMs ?: nowMs else null

/** Different Live candidates have independent sliding windows, not VOD offsets. */
internal fun seekToPlaybackStart(
    isMobileLive: Boolean,
    startAtMs: Long,
    seekToPosition: (Long) -> Unit,
    seekToDefaultPosition: () -> Unit
) {
    if (isMobileLive) seekToDefaultPosition() else seekToPosition(startAtMs)
}


/** A separate bounded timeout for a Live stream that played successfully, then stalled. */
internal const val MOBILE_LIVE_REBUFFER_TIMEOUT_MS = 20_000L

internal fun shouldFailoverStalledLiveRebuffer(
    isLive: Boolean,
    isTv: Boolean,
    playWhenReady: Boolean,
    hasEverPlayed: Boolean,
    isBuffering: Boolean,
    elapsedMs: Long,
    timeoutMs: Long = MOBILE_LIVE_REBUFFER_TIMEOUT_MS
): Boolean = isLive && !isTv && playWhenReady && hasEverPlayed && isBuffering && elapsedMs >= timeoutMs


/** VOD startup: a source that never becomes playable within the window fails over. */
internal const val VOD_STARTUP_STALL_TIMEOUT_MS = 45_000L

/** VOD mid-play: buffering with no position progress for this long fails over. */
internal const val VOD_REBUFFER_STALL_TIMEOUT_MS = 60_000L

/**
 * VOD startup (v0.14.14, item 7 — the same two-part model the TV
 * build uses; patience widened by the owner's source-switch rule,
 * v0.14.24 item 14: the player never moves on until it is 100%
 * sure the source will not give a stream): a source gets at most
 * this long, in total trying time, to produce its first frame.
 * Only when this whole window is exhausted is the source treated
 * as proven dead.
 */
internal const val VOD_STARTUP_FIRST_FRAME_TIMEOUT_MS = 90_000L

/**
 * VOD startup, early-dead arm: if literally no data has arrived
 * for this long (the player's buffered position never advanced —
 * zero bytes, not merely slow bytes), the source is dead on
 * arrival. Widened with the same v0.14.24 item-14 rule: a full
 * minute of absolute silence is the proof, anything less keeps
 * waiting on the same source.
 */
internal const val VOD_STARTUP_NO_DATA_TIMEOUT_MS = 60_000L

/**
 * The startup half of the TV model: fail over when EITHER the
 * accumulated trying time reaches the first-frame deadline OR the
 * no-data stretch reaches the early-dead window. Trying time is
 * accumulated by the caller only while the player is actually
 * trying (playWhenReady) — paused time burns neither clock. Once
 * the stream has played, this rule never fires: mid-play stalls
 * stay on [shouldFailoverStalledVod]'s rebuffer budget, untouched.
 */
internal fun shouldFailoverVodStartup(
    isLive: Boolean,
    playWhenReady: Boolean,
    hasEverPlayed: Boolean,
    tryingElapsedMs: Long,
    noDataElapsedMs: Long,
    firstFrameTimeoutMs: Long = VOD_STARTUP_FIRST_FRAME_TIMEOUT_MS,
    noDataTimeoutMs: Long = VOD_STARTUP_NO_DATA_TIMEOUT_MS
): Boolean {
    if (isLive || !playWhenReady || hasEverPlayed) return false
    return tryingElapsedMs >= firstFrameTimeoutMs || noDataElapsedMs >= noDataTimeoutMs
}

/**
 * VOD stall rule (owner's player round, 2026-10-23; widened by the player
 * audit 2026-10-27, finding 4): a movie/episode source that never starts,
 * or freezes with NO position progress — hosts that ignore range requests
 * behave exactly like this — fails over to the next source instead of
 * spinning forever. Progress, not buffering alone, is the signal, so a
 * slow-but-alive connection is never interrupted: the caller measures
 * `elapsedMs` as continuous ZERO-progress time (any forward movement of
 * the playhead resets it), and the budgets above are deliberately generous
 * so a trickling CDN on weak Wi-Fi is given time to recover before the
 * source is abandoned.
 */
internal fun shouldFailoverStalledVod(
    isLive: Boolean,
    playWhenReady: Boolean,
    hasEverPlayed: Boolean,
    isBuffering: Boolean,
    positionProgressed: Boolean,
    elapsedMs: Long,
    startupTimeoutMs: Long = VOD_STARTUP_STALL_TIMEOUT_MS,
    rebufferTimeoutMs: Long = VOD_REBUFFER_STALL_TIMEOUT_MS
): Boolean {
    if (isLive || !playWhenReady || !isBuffering || positionProgressed) return false
    val budget = if (hasEverPlayed) rebufferTimeoutMs else startupTimeoutMs
    return elapsedMs >= budget
}

/**
 * Budget for ONE collect pass of a pending auto-pick (v0.14.26). Must
 * exceed the repository's own per-leg budget — the first-party
 * (PlavioHD) leg alone may legitimately hold 45 s while a cold fill
 * lands — plus the flow's debrid tail, so a pass ends because the
 * loader SETTLED, not because the player gave up first.
 */
internal const val PENDING_AUTOPICK_PASS_BUDGET_MS = 60_000L

/** A resolved pending auto-pick: the winner plus the set it was picked from. */
internal data class PendingPick(
    val stream: StreamItem,
    val streams: List<StreamItem>,
    val subtitles: List<Subtitle>
)

/**
 * The Watch Now TAP path's wait (v0.14.26 — owner's player-fault
 * verdict, 2026-10-31): resolves a pending auto-pick with the SAME
 * settle semantics as the Detail loader, whose press-and-hold sheet
 * was proven on device. The old player resolver capped the whole
 * wait at 30 s — less than the repository's 45 s first-party leg
 * budget — and, under the default prober pick, only fell back to the
 * first playable stream once the flow had fully completed, which the
 * 30 s cap made unreachable; late streams were therefore reported as
 * "No stream available" while the fill was still running.
 *
 * Governing start rule (owner's spec, 2026-10-31): playback starts
 * with the FIRST playable stream [pickWinner] returns — the resume
 * match, the Settings > Streams rule via the shared autoplay-rule
 * ordering, or a probe-verified pick. The wait never holds a pick
 * hostage to the complete list; the background load keeps filling
 * the Sources/failover pool behind playback (the player's own
 * background refresh), and a pick that fails in playback fails over
 * to the next available stream as usual.
 *
 * Settle rule: a pass collects the shared stream flow to completion
 * (or [passBudgetMs]); if it ends with zero playable streams, ONE
 * confirmation collect runs — the exact rule the Detail loader uses
 * before its "No stream available" state. Null is returned ONLY when
 * the confirmation pass also ends empty, or the screen is disposed:
 * a final state. Streams in hand with no pick are never a "no
 * streams" verdict — once the loader settles (or the pass budget
 * expires), the first playable stream in hand is the pick.
 */
internal suspend fun awaitPendingAutoPick(
    initialStreams: List<StreamItem>,
    initialSubtitles: List<Subtitle>,
    openCollect: () -> Flow<StreamResult>,
    pickWinner: suspend (playable: List<StreamItem>) -> StreamItem?,
    isDisposed: () -> Boolean,
    passBudgetMs: Long = PENDING_AUTOPICK_PASS_BUDGET_MS,
    pollMs: Long = 250L,
    confirmationDelayMs: Long = 1_500L
): PendingPick? {
    var latest: List<StreamItem> = initialStreams
    var latestSubs: List<Subtitle> = initialSubtitles
    for (pass in 0..1) {
        if (isDisposed()) return null
        if (pass > 0) delay(confirmationDelayMs)
        var flowDone = false
        val winner = coroutineScope {
            val collectJob = launch {
                try {
                    openCollect().collect { result ->
                        if (result.streams.isNotEmpty()) {
                            latest = result.streams
                            latestSubs = result.subtitles
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // A failed collect is a settled collect: the pass
                    // verdict is taken with whatever is in hand.
                }
                flowDone = true
            }
            try {
                withTimeoutOrNull(passBudgetMs) {
                    var picked: StreamItem? = null
                    while (!isDisposed() && picked == null) {
                        val playable = latest.filter { isPlayableLiveStreamUrl(it.url) }
                        if (playable.isNotEmpty()) {
                            picked = pickWinner(playable)
                            // Loader settled with streams in hand but
                            // no pick (e.g. every probe unproven): the
                            // first playable is the pick — the sheet
                            // path plays these same rows on tap, and
                            // playback failover covers a dead one.
                            if (picked == null && flowDone) picked = playable.first()
                        } else if (flowDone) {
                            break
                        }
                        if (picked == null) delay(pollMs)
                    }
                    picked
                }
            } finally {
                collectJob.cancel()
            }
        }
        if (winner != null) return PendingPick(winner, latest, latestSubs)
        if (isDisposed()) return null
        // Pass budget expired with streams in hand but no pick: the
        // set in hand is a playable answer, never "no streams".
        val inHand = latest.filter { isPlayableLiveStreamUrl(it.url) }
        if (inHand.isNotEmpty()) return PendingPick(inHand.first(), latest, latestSubs)
        // Zero playable at the end of the pass: loop runs the single
        // confirmation collect; after it, null is the final verdict.
    }
    return null
}
