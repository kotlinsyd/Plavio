package com.pulsestream.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.ui.components.EmptyState
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.PosterCard
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * "View all" grid for a Home catalog row. The row's items are handed over
 * in-memory via [repository.pendingCatalog] (same pattern as pendingPlayback).
 */
@Composable
fun CatalogScreen(
    repository: com.pulsestream.app.data.StreamRepository,
    listsRepository: com.pulsestream.app.data.CustomListsRepository,
    onBack: () -> Unit,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    catalogAddonId: String? = null,
    catalogType: String? = null,
    catalogCatalogId: String? = null
) {
    // R5(i) (v0.14.23): the in-memory handoff dies with the process.
    // When it is missing (or for a different row), re-derive the row
    // from the repository using the route args, falling back to the
    // persisted row identity.
    val catalogState = androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(repository.pendingCatalog)
    }
    val catalog = catalogState.value
    // Item 10 (v0.14.24): endless catalogs. The handed-over row is
    // page 0; when the grid nears the end, the next page is fetched
    // through the protocol's `skip` extra and appended (deduped by
    // meta id). Paging stops when a page adds nothing new — catalogs
    // that don't paginate either lack the extra (repository returns
    // empty) or repeat page 0 (dedup ⇒ nothing new).
    val pageItemsState = androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<List<com.pulsestream.app.data.MetaPreview>>(emptyList())
    }
    var loadingMore by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(false)
    }
    var noMorePages by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(false)
    }
    val totalItemCount = (catalog?.items?.size ?: 0) + pageItemsState.value.size
    androidx.compose.runtime.LaunchedEffect(catalog?.addonId, catalog?.type, catalog?.catalogId) {
        if (catalog != null) {
            pageItemsState.value = emptyList()
            loadingMore = false
            noMorePages = false
        }
    }
    val gridState = androidx.compose.runtime.remember { androidx.compose.foundation.lazy.grid.LazyGridState() }
    androidx.compose.runtime.LaunchedEffect(gridState) {
        androidx.compose.runtime.snapshotFlow {
            gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        }.collect { lastVisible ->
            val row = catalog ?: return@collect
            if (lastVisible < 0 || loadingMore || noMorePages) return@collect
            val total = row.items.size + pageItemsState.value.size
            if (lastVisible < total - 6) return@collect
            loadingMore = true
            try {
                val page = repository.fetchCatalogNextPage(row, total)
                val known = (row.items + pageItemsState.value).map { it.id }.toSet()
                val fresh = page.filterNot { it.id in known }
                if (fresh.isEmpty()) {
                    noMorePages = true
                } else {
                    val current = pageItemsState.value
                    pageItemsState.value = current + fresh.filterNot { f ->
                        current.any { it.id == f.id }
                    }
                }
            } finally {
                loadingMore = false
            }
        }
    }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val identity = if (catalogAddonId != null && catalogType != null && catalogCatalogId != null) {
            Triple(catalogAddonId, catalogType, catalogCatalogId)
        } else {
            repository.persistedPendingCatalogIdentity()?.let {
                Triple(it.addonId, it.type, it.catalogId)
            }
        }
        val current = catalogState.value
        if (identity != null &&
            (current == null || current.addonId != identity.first ||
                current.type != identity.second || current.catalogId != identity.third)
        ) {
            repository.rederivePendingCatalog(identity.first, identity.second, identity.third)
                ?.let { catalogState.value = it }
        }
    }
    // Press & hold opens the unified sheet directly (fix #6).
    var sheetTarget by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<com.pulsestream.app.data.MetaPreview?>(null)
    }
    GlowBackground {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        text = catalog?.catalogName ?: "Catalog",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    if (catalog != null) {
                        Text(
                            text = catalog.addonName,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
            if (catalog == null || catalog.items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        title = "Nothing here",
                        message = "This catalog came back empty.",
                        actionLabel = "Go back",
                        onAction = onBack
                    )
                }
            } else {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(140.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(
                        catalog.items + pageItemsState.value,
                        key = { index, meta -> "cat_${meta.id}_$index" }
                    ) { _, meta ->
                        PosterCard(
                            meta = meta,
                            onClick = {
                                onOpenDetail(catalog.addonId, meta.type, meta.id)
                            },
                            onLongClick = { sheetTarget = meta }
                        )
                    }
                    if (loadingMore) {
                        item {
                            Box(
                                Modifier.fillMaxWidth().padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Loading more…",
                                    color = TextSecondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                // totalItemCount keeps the paging window honest for
                // short first pages (single screen of posters).
                @Suppress("UNUSED_EXPRESSION")
                totalItemCount
            }
        }
        sheetTarget?.let { meta ->
            com.pulsestream.app.ui.components.AddToListSheet(
                listsRepository = listsRepository,
                addonId = catalog?.addonId ?: "",
                type = meta.type,
                metaId = meta.id,
                name = meta.name,
                poster = meta.poster,
                onDismiss = { sheetTarget = null },
                repository = repository,
                year = meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
                rating = meta.imdbRating
            )
        }
    }
}
