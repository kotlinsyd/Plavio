package com.pulsestream.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.withFrameMillis
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.ui.theme.AppPalette
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.LocalSpacingScale
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.tv.tvFocusRing

// ---------------------------------------------------------------------------
// Stream metadata parsing
// ---------------------------------------------------------------------------

/** Human-readable bits extracted from a stream's title/name. */
data class ParsedStreamInfo(
    val quality: String? = null,
    val source: String? = null,
    val codec: String? = null,
    val audio: String? = null,
    val size: String? = null
)

private val QUALITY_RE = Regex("""\b(2160p|1440p|1080p|720p|480p|360p)\b""", RegexOption.IGNORE_CASE)
// Bare "2160" with no p suffix (v0.14.21): formatter text often prints
// the resolution as a bare number ("… 2160 WEB-DL …") — it is the 4K
// rung all the same.
private val BARE_2160_RE = Regex("""\b2160\b(?!p)""", RegexOption.IGNORE_CASE)
private val FOUR_K_RE = Regex("""\b(4K|UHD)\b""", RegexOption.IGNORE_CASE)
// Named quality labels (AIOStreams-style formatters print these instead of
// numeric tags): FHD = 1080p, HD = 720p, SD = 480p. Word boundaries keep
// HDRip / HDCAM / HDTV from matching the bare HD rule.
private val FHD_RE = Regex("""\bFHD\b""", RegexOption.IGNORE_CASE)
private val HD_RE = Regex("""\bHD\b""", RegexOption.IGNORE_CASE)
private val SD_RE = Regex("""\bSD\b""", RegexOption.IGNORE_CASE)
private val SOURCE_RE =
    Regex("""\b(Blu[-\s]?Ray|BDRip|BRRip|WEB[-\s]?DL|WEBRip|HDRip|HDTC|HDCAM|HDTS|DVDRip|HDTV|\bTS\b|CAM)\b""", RegexOption.IGNORE_CASE)
private val CODEC_RE = Regex("""\b(x265|HEVC|x264|AVC|AV1|VP9)\b""", RegexOption.IGNORE_CASE)
private val AUDIO_RE = Regex(
    """\b(Atmos|DTS[-\s]?HD(?:\s?MA)?|TrueHD|DTS|DD\+?(?:\s?[57]\.1)?|Dolby(?:\s?Digital)?|AAC(?:\s?5\.1)?)\b""",
    RegexOption.IGNORE_CASE
)
private val SIZE_RE = Regex("""(\d+(?:\.\d+)?\s?(?:GB|MB))""", RegexOption.IGNORE_CASE)
// Precompiled once (v0.14.17 lag fix): these used to be constructed
// fresh inside parseStreamInfo / streamFacts / streamSizeGb on
// every call — several Regex compilations per stream per parse.
private val WHITESPACE_DASH_RE = Regex("""[-\s]+""")
private val WHITESPACE_RUN_RE = Regex("""\s+""")
private val VERSION_TOKEN_RE = Regex("""V\d{1,2}""")
private val TOKEN_SPLIT_RE = Regex("""[._\s]+""")
private val SIZE_VALUE_RE = Regex("""([\d.]+)\s*(GB|MB)""", RegexOption.IGNORE_CASE)
private val TRAILING_QUALITY_RE =
    Regex("""\s+\b(2160p|1440p|1080p|720p|480p|360p|4K|UHD)\b.*$""", RegexOption.IGNORE_CASE)

/** Scans a stream's title/name for quality, source, codec, audio and size tags. */
fun parseStreamInfo(stream: StreamItem): ParsedStreamInfo {
    val haystack = listOfNotNull(stream.title, stream.name).joinToString("\n")
    if (haystack.isBlank()) return ParsedStreamInfo()
    val quality = FOUR_K_RE.find(haystack)?.value?.uppercase()
        ?: QUALITY_RE.find(haystack)?.value?.lowercase()
        ?: if (BARE_2160_RE.containsMatchIn(haystack)) "2160p"
        else if (FHD_RE.containsMatchIn(haystack)) "1080p"
        else if (HD_RE.containsMatchIn(haystack)) "720p"
        else if (SD_RE.containsMatchIn(haystack)) "480p"
        else null
    val source = SOURCE_RE.find(haystack)?.value
        ?.replace(WHITESPACE_DASH_RE, "-")?.uppercase()
        ?.replace("BLU-RAY", "BluRay")?.replace("WEB-DL", "WEB-DL")
    val codec = CODEC_RE.find(haystack)?.value?.uppercase()
    val audio = AUDIO_RE.find(haystack)?.value
        ?.replace(WHITESPACE_RUN_RE, " ")?.trim()
        ?.let { a ->
            when {
                a.equals("Atmos", ignoreCase = true) -> "Atmos"
                a.startsWith("DTS", ignoreCase = true) -> a.uppercase().replace(" ", "")
                a.startsWith("DD", ignoreCase = true) -> a.uppercase().replace(" ", "")
                a.startsWith("Dolby", ignoreCase = true) -> "Dolby"
                else -> a.uppercase()
            }
        }
    val size = SIZE_RE.find(haystack)?.value?.uppercase()?.replace(" ", "")
        ?.let { s -> s.dropLast(2) + " " + s.takeLast(2) }
    return ParsedStreamInfo(quality, source, codec, audio, size)
}

// ---------------------------------------------------------------------------
// Parse-once cache (v0.14.17 lag fix, audit cause 2)
//
// The Sources pipeline used to re-run the full regex parse of every
// stream on every progressive list emission — three full-list passes
// inside composition, a re-parse per sort comparison, and ~60–100
// regex ops per card. Parse results are pure functions of a stream's
// text fields, so each distinct stream is now parsed ONCE per
// process and every consumer (sort keys, quality filters, cards)
// reads the cached value. Keyed by URL, guarded by a signature of
// the exact fields the parsers read (a debrid-resolved row that
// replaces a placeholder under the same URL re-parses, as it must).
// ---------------------------------------------------------------------------

/** Content signature of everything the stream parsers read. */
private fun streamParseSignature(s: StreamItem): String =
    listOfNotNull(s.title, s.name, s.filename, s.sourceName)
        .joinToString("\u0001") + "\u0001" + (s.videoSize ?: -1L)

private class StreamParseCache<T>(private val compute: (StreamItem) -> T) {
    private val entries = java.util.concurrent.ConcurrentHashMap<String, Pair<String, T>>()

    operator fun get(stream: StreamItem): T {
        val signature = streamParseSignature(stream)
        val hit = entries[stream.url]
        if (hit != null && hit.first == signature) return hit.second
        val value = compute(stream)
        // Bounded: a pathological session simply restarts the cache.
        if (entries.size > 4096) entries.clear()
        entries[stream.url] = signature to value
        return value
    }
}

private val streamInfoParseCache = StreamParseCache { parseStreamInfo(it) }
private val streamFactsParseCache = StreamParseCache { computeStreamFacts(it, true) }

/** [parseStreamInfo] through the parse-once cache. */
fun cachedStreamInfo(stream: StreamItem): ParsedStreamInfo = streamInfoParseCache[stream]

/** Canonical filter bucket for a parsed quality label; unknown labels have no filter bucket. */
fun normalizeStreamQuality(quality: String?): String? {
    val value = quality?.trim()?.lowercase()?.replace(" ", "") ?: return null
    return when (value) {
        "4k", "uhd", "2160p" -> "4K"
        "fhd" -> "1080p"
        "hd" -> "720p"
        "sd" -> "480p"
        "1440p", "1080p", "720p", "480p", "360p" -> value
        else -> null
    }
}

private val STREAM_QUALITY_ORDER = listOf("4K", "1440p", "1080p", "720p", "480p", "360p")

/** Qualities currently represented in [streams], regardless of source or preference caps. */
fun availableStreamQualities(streams: List<StreamItem>): List<String> =
    streams.mapNotNull { normalizeStreamQuality(cachedStreamInfo(it).quality) }
        .distinct()
        .sortedBy { STREAM_QUALITY_ORDER.indexOf(it).let { index -> if (index < 0) Int.MAX_VALUE else index } }

/** Applies a canonical quality bucket across the whole combined list, retaining every matching addon. */
fun filterStreamsByQuality(streams: List<StreamItem>, quality: String?): List<StreamItem> {
    val bucket = normalizeStreamQuality(quality) ?: return streams
    return streams.filter { normalizeStreamQuality(cachedStreamInfo(it).quality) == bucket }
}

/** Compare display labels after case/spacing/punctuation normalization, retaining original text. */
private fun comparableStreamLabel(value: String): String =
    value.lowercase().filter { it.isLetterOrDigit() }

private fun streamLinesEquivalent(first: String, second: String): Boolean {
    val firstLabel = comparableStreamLabel(first)
    val secondLabel = comparableStreamLabel(second)
    if (firstLabel == secondLabel) return true
    val firstQuality = normalizeStreamQuality(first)
    val secondQuality = normalizeStreamQuality(second)
    return firstQuality != null && firstQuality == secondQuality
}

/** Combine addon title/name while removing repeated and less-informative overlapping lines. */
fun streamDisplayName(title: String?, name: String?, fallbackUrl: String = ""): String {
    val t = title?.trim().orEmpty()
    val n = name?.trim().orEmpty()
    if (t.isBlank() && n.isBlank()) {
        return fallbackUrl.substringAfter("://").substringBefore("/").take(48)
    }

    val lines = mutableListOf<String>()
    (listOf(t, n).filter { it.isNotBlank() }.flatMap { field ->
        field.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
    }).forEach { candidate ->
        val candidateLabel = comparableStreamLabel(candidate)
        if (candidateLabel.isEmpty()) return@forEach
        val overlaps = lines.indices.filter { index ->
            val existingLabel = comparableStreamLabel(lines[index])
            streamLinesEquivalent(lines[index], candidate) ||
                (existingLabel.isNotEmpty() &&
                    (existingLabel.contains(candidateLabel) || candidateLabel.contains(existingLabel)))
        }
        if (overlaps.isEmpty()) {
            lines += candidate
        } else {
            val richer = overlaps.filter { index ->
                comparableStreamLabel(lines[index]).length < candidateLabel.length
            }
            if (richer.isNotEmpty()) {
                val insertionIndex = richer.minOrNull()!!
                richer.asReversed().forEach { index -> lines.removeAt(index) }
                lines.add(insertionIndex.coerceAtMost(lines.size), candidate)
            }
        }
    }
    return lines.joinToString("\n").ifBlank {
        fallbackUrl.substringAfter("://").substringBefore("/").take(48)
    }
}

/**
 * True when [stream]'s text was composed by an ADDON-SIDE formatter
 * the user selected in that addon (v0.14.28, owner's formatter-first
 * priority rule: priority 1 of 3 — the formatter governs, app badges
 * never re-dress it). There is no marker field in the stream
 * protocol, so the detection is structural, against the shapes a
 * formatter render actually takes versus the Default composition
 * (name = "<Provider> <quality>", title = an optional filename line
 * over ONE details line, never more than two lines, no emoji, no
 * " • " / " | " separators).
 *
 * v0.14.29 widening (owner's "free it like Nuvio" order — the
 * 0.14.28 check missed whole formatter families and the cards then
 * re-dressed their text as a house row):
 *  - 3+ text lines across name+title (every PlavioHD preset renders
 *    3+ description lines; Default never exceeds 2), or
 *  - a line led by one of the formatter emoji (the preset/custom
 *    dialects lead their lines with them), or
 *  - a " • " or " | " separator in EITHER field (v0.14.28 looked at
 *    the name only; AIOStreams-style templates put their separators
 *    in the description); " · " (U+00B7, Tamtaro's separator) counts
 *    in the name, and in the title only alongside a formatter glyph
 *    — it is also the Default details line's own separator, so a
 *    bare " · " title must stay on the house path, or
 *  - bracket-token density: 2+ "[TOKEN]" groups across name+title
 *    (Fusion-style and AIOStreams-style rows carry their formatting
 *    as bracketed tokens on one or two lines, no emoji at all; a
 *    Default row carries at most one leading "[tag]"), or
 *  - a specs-pattern line: a line holding 2+ DISTINCT spec tokens
 *    (resolution / source / codec / HDR family) that is not a
 *    dotted filename (no video extension, fewer than 3 dots) —
 *    the no-emoji presets' plain specs lines (e.g. Torrentio
 *    Minimalist's "2160p BluRay x265"). A Default details line
 *    holds a single spec token, and its filename line is dotted,
 *    so Default rows stay on the house path exactly as before.
 * Pure and side-effect free, so it is unit-tested directly.
 */
private val FORMATTER_LINE_LEADS = listOf(
    "🌀", "⚡", "🧩", "❄️", "🧊", "🎬", "💎", "📺", "📡", "🍿",
    "🏷️", "🎞️", "💾", "🎧", "💬", "🛰️", "⚙️", "📦", "🔊", "📝", "📶",
    // v0.14.33: the GDrive-family and Tamtaro preset dialects —
    // live rows from those presets were missed and re-dressed as
    // plain house rows (🧿/💿/🌎 MinimalisticGDrive, 🔍 GDrive,
    // ✎/⛉ Tamtaro).
    "🧿", "💿", "🌎", "🔍", "✎", "⛉"
)

private val FORMATTER_BRACKET_TOKEN_RE = Regex("""\[[A-Za-z0-9][A-Za-z0-9+._ -]{0,24}\]""")

private val FORMATTER_SPEC_TOKENS = listOf(
    Regex("""\b(?:2160p|1440p|1080p|720p|480p|360p)\b""", RegexOption.IGNORE_CASE),
    Regex("""\b(?:4K|UHD)\b"""),
    Regex("""\b(?:BluRay|BDRip|BRRip|WEB-DL|WEBRip|HDTV|REMUX)\b""", RegexOption.IGNORE_CASE),
    Regex("""\b(?:HDR10\+|HDR10|HDR|DV|Dolby Vision)\b"""),
    Regex("""\b(?:x265|x264|HEVC|AV1|H\.?265|H\.?264)\b""", RegexOption.IGNORE_CASE),
    Regex("""\b(?:Atmos|TrueHD|DTS-HD|DTS|DDP|DD\+|EAC3|AC3)\b""", RegexOption.IGNORE_CASE)
)

/** A non-filename line carrying 2+ distinct spec-token families. */
private fun isSpecsPatternLine(line: String): Boolean {
    if (STREAM_EXT_RE.containsMatchIn(line)) return false
    if (line.count { it == '.' } >= 3) return false
    return FORMATTER_SPEC_TOKENS.count { it.containsMatchIn(line) } >= 2
}

fun isAddonFormatted(stream: StreamItem): Boolean {
    val name = stream.name?.trim().orEmpty()
    val title = stream.title?.trim().orEmpty()
    val lines = listOf(name, title).filter { it.isNotBlank() }
        .flatMap { field -> field.lineSequence().map { it.trim() }.filter { it.isNotEmpty() } }
    if (lines.size >= 3) return true
    if (lines.any { line -> FORMATTER_LINE_LEADS.any { line.startsWith(it) } }) return true
    if (name.contains(" • ") || name.contains(" | ") || name.contains(" · ") ||
        title.contains(" • ") || title.contains(" | ")
    ) return true
    // " · " (U+00B7) is Tamtaro's separator — but it is ALSO the
    // separator inside the PlavioHD Default details line
    // ("2160p · Hindi · 5.1 · 8.2 GB"), so in the TITLE it counts
    // only when a formatter glyph appears somewhere in the row
    // (Tamtaro titles carry ✎/⛉); a bare " · " title stays on
    // the house path exactly as before.
    if (title.contains(" · ") &&
        lines.any { line -> FORMATTER_LINE_LEADS.any { line.contains(it) } }
    ) return true
    if (FORMATTER_BRACKET_TOKEN_RE.findAll("$name\n$title").count() >= 2) return true
    // A specs-pattern line counts only in the TITLE (the field
    // formatters compose their spec lines into) and only when it
    // adds text the name does not already carry: a Default name
    // like "Addon 1080p BluRay" over a filename title is a house
    // row, not a formatter row, and a name repeated as the title
    // must not flip itself.
    val nameLineSet = name.lineSequence().map { it.trim() }
        .filter { it.isNotEmpty() }.toSet()
    if (title.lineSequence().map { it.trim() }
            .filter { it.isNotEmpty() }
            .any { it !in nameLineSet && isSpecsPatternLine(it) }
    ) return true
    return false
}

/**
 * The stream's text EXACTLY as the addon composed it (v0.14.29):
 * the name block followed by the title/description block, every
 * line verbatim, in the addon's own order — no dedupe, no
 * line-dropping, no cleaning (the v0.14.28 raw branch re-composed
 * through [streamDisplayName], whose containment dedupe dropped
 * formatter lines that overlapped each other). The only concession:
 * when name and title are byte-identical the text prints once —
 * printing the same block twice is a duplication bug, not fidelity.
 */
fun addonFormattedText(stream: StreamItem): String {
    val name = stream.name?.trim().orEmpty()
    val title = stream.title?.trim().orEmpty()
    if (name.isBlank()) return title
    if (title.isBlank() || title == name) return name
    return name + "\n" + title
}

/** Best one-line label for a stream card headline. */
fun streamHeadline(stream: StreamItem): String {
    // Prefer name (e.g. "2160p · HDHub") — it includes the provider.
    // Fall back to title's first line, then URL host.
    if (!stream.name.isNullOrBlank()) return stream.name!!
    val firstLine = stream.title?.lineSequence()
        ?.map { it.trim() }?.firstOrNull { it.isNotBlank() }
    if (!firstLine.isNullOrBlank()) return firstLine
    return stream.url.substringAfter("://").substringBefore("/").take(48)
}

/** One authoritative set of labels for a compact source-picker card. */
data class StreamDisplayModel(
    val headline: String,
    val provider: String?,
    val metadata: List<String>
)

/** Keeps parsed details out of the chips when the full filename already shows them. */
fun streamDisplayModel(stream: StreamItem): StreamDisplayModel {
    val headline = streamDisplayName(stream.title, stream.name, stream.url)
    val normalizedHeadline = comparableStreamLabel(headline)
    val providerLabel = stream.sourceName?.takeIf { it.isNotBlank() } ?: stream.addonKey()
    val visibleProvider = providerLabel.takeUnless {
        normalizedHeadline.contains(comparableStreamLabel(it))
    }
    val info = cachedStreamInfo(stream)
    val headlineQuality = FOUR_K_RE.find(headline)?.value
        ?: QUALITY_RE.find(headline)?.value
    val representedQuality = normalizeStreamQuality(headlineQuality)
    val details = listOfNotNull(
        info.quality?.uppercase(), info.codec?.uppercase(), info.audio, info.size, info.source
    ).distinct()
    val visibleDetails = details.filterNot {
        (normalizeStreamQuality(it) != null && normalizeStreamQuality(it) == representedQuality) ||
            normalizedHeadline.contains(comparableStreamLabel(it))
    }
    return StreamDisplayModel(headline, visibleProvider, visibleDetails)
}

/** Addon grouping key for tabs. */
fun StreamItem.addonKey(): String = sourceName?.takeIf { it.isNotBlank() }
    ?: name?.takeIf { it.isNotBlank() } ?: "Unknown"

// ---------------------------------------------------------------------------
// Stream-card facts (v0.14.10, owner's stream-cards cleanup; name rule
// refined in v0.14.11): parse the raw scene/P2P release title into a
// clean title line + liquid-glass capsule facts. Since v0.14.11 the
// name line shows ONLY title + year (episode codes stay — they are
// part of a title's identity); every parsed fact token lives in the
// capsules instead of being repeated in the name.
// ---------------------------------------------------------------------------

/** Fact families on a stream card; Settings → Streams toggles each one. */
enum class StreamFactGroup { RESOLUTION, HDR, AUDIO, LANGUAGES, SOURCE_CODEC, SIZE }

/** Style + per-group visibility for the stream-card badge row. */
data class StreamCapsuleConfig(
    val style: BadgeStyle = BadgeStyle.ELITE,
    /**
     * The user's Fusion badge source ids, in priority order
     * (v0.14.36) — consulted only when [style] is IMPORTED. Empty
     * (and ELITE) everywhere else.
     */
    val fusionSourceIds: List<String> = emptyList(),
    val showResolution: Boolean = true,
    val showHdr: Boolean = true,
    val showAudio: Boolean = true,
    val showLanguages: Boolean = true,
    val showSourceCodec: Boolean = true,
    val showSize: Boolean = true
) {
    fun shows(group: StreamFactGroup): Boolean = when (group) {
        StreamFactGroup.RESOLUTION -> showResolution
        StreamFactGroup.HDR -> showHdr
        StreamFactGroup.AUDIO -> showAudio
        StreamFactGroup.LANGUAGES -> showLanguages
        StreamFactGroup.SOURCE_CODEC -> showSourceCodec
        StreamFactGroup.SIZE -> showSize
    }
}

/**
 * Builds the badge config from the user's Streams settings.
 * v0.14.36: the style is DERIVED (see [resolveBadgeStyle]) — the
 * user's Fusion sources win when any exist, otherwise built-in
 * Elite applies automatically; the retired picker's stored value
 * no longer decides anything.
 */
fun com.pulsestream.app.data.SettingsStore.streamCapsuleConfig(): StreamCapsuleConfig {
    val fusionIds = fusionSourceIds()
    return StreamCapsuleConfig(
        style = resolveBadgeStyle(fusionIds.isNotEmpty()),
        fusionSourceIds = fusionIds,
        showResolution = streamCapsuleGroupResolution,
        showHdr = streamCapsuleGroupHdr,
        showAudio = streamCapsuleGroupAudio,
        showLanguages = streamCapsuleGroupLanguages,
        showSourceCodec = streamCapsuleGroupSourceCodec,
        showSize = streamSizeBadges
    )
}

/**
 * Item 5 (v0.14.24): the uniform parsed fact line — every stream row
 * renders the same shape regardless of which addon or formatter
 * wrote its text: "Quality · Source · Codec · Audio · Size", built
 * from the group parts (each group omitted when absent). Our quality
 * sort and badge styles are untouched; this is presentation only —
 * the same facts the capsules show, as one consistent line.
 */
fun uniformFactLine(facts: StreamFacts): String {
    val parts = mutableListOf<String>()
    facts.groupParts(StreamFactGroup.RESOLUTION).joinToString(" · ")
        .takeIf { it.isNotBlank() }?.let { parts += it }
    facts.groupParts(StreamFactGroup.SOURCE_CODEC).joinToString(" · ")
        .takeIf { it.isNotBlank() }?.let { parts += it }
    facts.groupParts(StreamFactGroup.AUDIO).joinToString(" · ")
        .takeIf { it.isNotBlank() }?.let { parts += it }
    facts.groupParts(StreamFactGroup.SIZE).joinToString(" · ")
        .takeIf { it.isNotBlank() }?.let { parts += it }
    return parts.joinToString(" · ")
}

/** Everything a cleaned-up stream card shows, parsed from the raw title. */
data class StreamFacts(
    val displayName: String,
    val quality: String? = null,
    /** "4K UHD" tag — the name carries UHD, or 2160p from a BluRay-class source. */
    val qualityTag: String? = null,
    val sourceType: String? = null,
    val remux: Boolean = false,
    /** HDR formats, short forms: HDR / HDR10 / HDR10+ / DV. */
    val hdrFormats: List<String> = emptyList(),
    /** HDR formats, display forms: DV spells out to "Dolby Vision". */
    val hdrFormatsFull: List<String> = emptyList(),
    val audioCodec: String? = null,
    val atmos: Boolean = false,
    val channels: String? = null,
    val languages: List<String> = emptyList(),
    val languageCodes: List<String> = emptyList(),
    val codec: String? = null,
    /** "10bit" when the release is 10-bit. */
    val bitDepth: String? = null,
    val version: String? = null,
    val size: String? = null,
    val providerLine: String? = null
) {
    /** True when the title yielded at least one capsule-worthy fact. */
    val hasFacts: Boolean
        get() = quality != null || qualityTag != null || sourceType != null || remux ||
            hdrFormats.isNotEmpty() || audioCodec != null || atmos || channels != null ||
            languages.isNotEmpty() || codec != null || bitDepth != null ||
            version != null || size != null

    /**
     * Short-form parts of one group, in display order, for the Grouped
     * style: codec and bit depth glue together ("HEVC 10bit") and
     * languages ride as CODES.
     */
    fun groupParts(group: StreamFactGroup): List<String> =
        when (group) {
            StreamFactGroup.RESOLUTION -> listOfNotNull(quality, qualityTag)
            StreamFactGroup.HDR -> hdrFormats
            StreamFactGroup.AUDIO ->
                listOfNotNull(audioCodec, if (atmos) "Atmos" else null, channels)
            StreamFactGroup.LANGUAGES -> languageCodes
            StreamFactGroup.SOURCE_CODEC -> {
                val codecGlued = codec?.let { c ->
                    if (bitDepth != null) "$c $bitDepth" else c
                }
                listOfNotNull(sourceType, if (remux) "REMUX" else null, codecGlued, version)
            }
            StreamFactGroup.SIZE -> listOfNotNull(size)
        }

    /** Grouped style: one "a · b · c" string per visible non-empty group. */
    fun groupedCapsules(config: StreamCapsuleConfig): List<Pair<StreamFactGroup, String>> =
        StreamFactGroup.entries.mapNotNull { group ->
            if (!config.shows(group)) return@mapNotNull null
            val parts = groupParts(group)
            if (parts.isEmpty()) null else group to parts.joinToString(" · ")
        }
}

/** Soft category tints for the Grouped glass style (owner's colour map). */
fun StreamFactGroup.capsuleTint(): Color = when (this) {
    StreamFactGroup.RESOLUTION -> Color(0xFF8B5CF6) // violet
    StreamFactGroup.HDR -> Color(0xFFFFC400) // gold
    StreamFactGroup.AUDIO -> Color(0xFF4ADE80) // green
    StreamFactGroup.LANGUAGES -> Color(0xFFFB7185) // rose
    StreamFactGroup.SOURCE_CODEC -> Color(0xFF60A5FA) // blue
    StreamFactGroup.SIZE -> Color(0xFFFB923C) // orange
}

private val YEAR_TOKEN_RE = Regex("""^(19|20)\d{2}$""")
private val EPISODE_TOKEN_RE = Regex("""^S\d{1,2}E\d{1,3}$""", RegexOption.IGNORE_CASE)
private val VERSION_TAG_RE = Regex("""\b(V\d{1,2}|PROPER|REPACK)\b""", RegexOption.IGNORE_CASE)

/** Whole words that are release facts/junk, never title words worth keeping. */
private val STREAM_FACT_WORDS = setOf(
    "2160P", "1440P", "1080P", "720P", "480P", "360P", "4K", "UHD", "FHD",
    "HD", "SD", "HQ", "ORG", "CLEAN", "PROPER", "REPACK",
    // v0.14.12 capsule facts: HDR family, audio family, misc release tags.
    "HDR", "HDR10", "DV", "DOVI", "REMUX", "FLAC", "OPUS", "EAC3", "AC3",
    "ATMOS", "TRUEHD", "DTS", "10BIT"
)

/** Language name → code, for the Grouped / Labelled capsule styles. */
private val STREAM_LANGUAGE_CODES = mapOf(
    "Hindi" to "HI", "Telugu" to "TE", "Tamil" to "TA", "Malayalam" to "ML",
    "Kannada" to "KN", "Bengali" to "BN", "Punjabi" to "PA", "Marathi" to "MR",
    "Gujarati" to "GU", "Odia" to "OR", "Assamese" to "AS", "Urdu" to "UR",
    "English" to "EN", "Arabic" to "AR", "Spanish" to "ES", "French" to "FR",
    "German" to "DE", "Italian" to "IT", "Portuguese" to "PT", "Russian" to "RU",
    "Ukrainian" to "UK", "Polish" to "PL", "Turkish" to "TR", "Persian" to "FA",
    "Korean" to "KO", "Japanese" to "JA", "Chinese" to "ZH", "Thai" to "TH",
    "Vietnamese" to "VI", "Indonesian" to "ID", "Dutch" to "NL", "Swedish" to "SV"
)

// HDR / extended-audio probes over the raw title (v0.14.12). Word
// boundaries keep HDRip / DVDRip from tripping the HDR / DV rules.
private val HDR10_PLUS_RE = Regex("""HDR10\+|HDR10PLUS""", RegexOption.IGNORE_CASE)
private val HDR10_RE = Regex("""\bHDR10\b""", RegexOption.IGNORE_CASE)
private val HDR_GENERIC_RE = Regex("""\bHDR\b""", RegexOption.IGNORE_CASE)
private val DOLBY_VISION_RE =
    Regex("""\bDV\b|\bDoVi\b|Dolby[\s._-]?Vision""", RegexOption.IGNORE_CASE)
private val DTS_HD_RE = Regex("""DTS[-\s.]?HD""", RegexOption.IGNORE_CASE)
private val TRUEHD_RE = Regex("""TrueHD|True[.\s]HD""", RegexOption.IGNORE_CASE)
private val EAC3_RE =
    Regex("""EAC3|E-AC-3|DDP|DD\+|Dolby[\s.]?Digital[\s.]?Plus""", RegexOption.IGNORE_CASE)
private val AC3_RE = Regex("""\bAC3\b""", RegexOption.IGNORE_CASE)
private val DTS_RE = Regex("""\bDTS\b""", RegexOption.IGNORE_CASE)
private val DD_RE = Regex("""\bDD\b""", RegexOption.IGNORE_CASE)
private val AAC_TOKEN_RE = Regex("""\bAAC\b""", RegexOption.IGNORE_CASE)
private val FLAC_RE = Regex("""\bFLAC\b""", RegexOption.IGNORE_CASE)
private val OPUS_RE = Regex("""\bOpus\b""", RegexOption.IGNORE_CASE)
private val ATMOS_RE = Regex("""\bAtmos\b""", RegexOption.IGNORE_CASE)
// Channel layout, standalone ("...DDP.5.1...") or glued ("DDP5.1");
// the lookahead keeps bare file sizes ("5.1 GB") from matching.
private val CHANNELS_RE =
    Regex("""(?:^|[^0-9.])(2\.0|5\.1|6\.1|7\.1)(?![0-9]|\s?(GB|MB|TB))""", RegexOption.IGNORE_CASE)
private val BIT_DEPTH_RE = Regex("""\b10[-\s]?bit\b""", RegexOption.IGNORE_CASE)
private val REMUX_RE = Regex("""\bREMUX\b|\bBDREMUX\b""", RegexOption.IGNORE_CASE)

/**
 * True when [token] (one dot/underscore-separated piece of a release
 * name) carries a fact the capsules already show — quality, source,
 * codec, audio, a language, a version tag — or is release junk.
 * Hyphen-glued tokens ("Hindi-Telugu", "x264-HDHub4u", "V2-HDTC")
 * count when any part or the whole matches.
 */
private fun isStreamFactToken(token: String): Boolean {
    val parts = token.split('-')
    val partIsFact = parts.any { part ->
        val p = part.uppercase()
        p in STREAM_FACT_WORDS ||
            VERSION_TOKEN_RE.matches(p) ||
            STREAM_LANGUAGES.any { it.equals(part, ignoreCase = true) }
    }
    return partIsFact || SOURCE_RE.containsMatchIn(token) ||
        CODEC_RE.containsMatchIn(token) || AUDIO_RE.containsMatchIn(token)
}

/**
 * The fully-clean name line (v0.14.11): "Title (Year)", or
 * "Title S01E05" for episodes — every fact token stripped, no
 * extension. Returns null when the stem yields no parseable title
 * anchored by a year, an episode code, or at least one fact token;
 * the caller then keeps the previous cleaned-filename rendering.
 */
private fun cleanStreamTitle(stem: String): String? {
    val tokens = stem.split(TOKEN_SPLIT_RE).filter { it.isNotBlank() }
    if (tokens.isEmpty()) return null
    val title = mutableListOf<String>()
    var year: String? = null
    var episode: String? = null
    var stoppedAtFact = false
    var i = 0
    while (i < tokens.size) {
        val tok = tokens[i]
        when {
            YEAR_TOKEN_RE.matches(tok) -> {
                year = tok
                // An episode code right after the year stays in the name too.
                tokens.getOrNull(i + 1)?.takeIf { EPISODE_TOKEN_RE.matches(it) }
                    ?.let { episode = it.uppercase() }
                break
            }
            EPISODE_TOKEN_RE.matches(tok) -> {
                episode = tok.uppercase()
                break
            }
            isStreamFactToken(tok) -> {
                stoppedAtFact = true
                break
            }
            else -> {
                title += tok
                i++
            }
        }
    }
    if (title.isEmpty()) return null
    if (year == null && episode == null && !stoppedAtFact) return null
    return buildString {
        append(title.joinToString(" "))
        year?.let { append(" (").append(it).append(")") }
        episode?.let { append(" ").append(it) }
    }
}

private val STREAM_EXT_RE =
    Regex("""\.(mkv|mp4|avi|mov|webm|m4v|wmv|ts|m2ts)$""", RegexOption.IGNORE_CASE)
private val LEADING_BRACKETS_RE = Regex("""^(\[[^\]]*\]\s*)+""")
private val BRACKET_CONTENT_RE = Regex("""\[([^\]]+)\]""")

/** Audio languages commonly named in release titles, longest names first. */
private val STREAM_LANGUAGES = listOf(
    "Hindi", "Telugu", "Tamil", "Malayalam", "Kannada", "Bengali", "Punjabi",
    "Marathi", "Gujarati", "Odia", "Assamese", "Urdu", "English", "Arabic",
    "Spanish", "French", "German", "Italian", "Portuguese", "Russian",
    "Ukrainian", "Polish", "Turkish", "Persian", "Korean", "Japanese",
    "Chinese", "Thai", "Vietnamese", "Indonesian", "Dutch", "Swedish"
)

/**
 * Per-language probes, compiled ONCE (v0.14.17 lag fix): the old
 * parseStreamLanguages built 33 fresh Regex objects on every call,
 * and it runs once per stream card.
 */
private val STREAM_LANGUAGE_RES: List<Pair<String, Regex>> = STREAM_LANGUAGES.map { lang ->
    lang to Regex("""(?<![A-Za-z])${Regex.escape(lang)}(?![A-Za-z])""", RegexOption.IGNORE_CASE)
}

/**
 * ISO 639-2 language codes → language name (v0.14.21). Addon
 * formatter text often prints languages as bare codes ("HIN-ENG",
 * "[TAM]") instead of full names; an all-uppercase three-letter
 * token in the title is matched against this map.
 */
private val STREAM_LANGUAGE_ISO2 = mapOf(
    "HIN" to "Hindi", "ENG" to "English", "TAM" to "Tamil",
    "TEL" to "Telugu", "MAL" to "Malayalam", "KAN" to "Kannada",
    "BEN" to "Bengali", "PAN" to "Punjabi", "MAR" to "Marathi",
    "URD" to "Urdu", "GUJ" to "Gujarati", "ORI" to "Odia",
    "ASM" to "Assamese", "ARA" to "Arabic", "SPA" to "Spanish",
    "FRA" to "French", "FRE" to "French", "DEU" to "German",
    "GER" to "German", "ITA" to "Italian", "POR" to "Portuguese",
    "RUS" to "Russian", "UKR" to "Ukrainian", "POL" to "Polish",
    "TUR" to "Turkish", "FAS" to "Persian", "PER" to "Persian",
    "KOR" to "Korean", "JPN" to "Japanese", "ZHO" to "Chinese",
    "CHI" to "Chinese", "THA" to "Thai", "VIE" to "Vietnamese",
    "IND" to "Indonesian", "NLD" to "Dutch", "DUT" to "Dutch",
    "SWE" to "Swedish"
)

private val ISO2_TOKEN_RE = Regex("""(?<![A-Za-z])([A-Z]{3})(?![A-Za-z])""")

/**
 * Flag emoji → language name (v0.14.21): formatter text also marks
 * languages with country flags. India reads as Hindi (the desi
 * default every formatter means by it); Sri Lanka as Tamil.
 */
private val FLAG_LANGUAGE_BY_COUNTRY = mapOf(
    "IN" to "Hindi", "US" to "English", "GB" to "English",
    "ES" to "Spanish", "MX" to "Spanish", "FR" to "French",
    "DE" to "German", "IT" to "Italian", "PT" to "Portuguese",
    "BR" to "Portuguese", "RU" to "Russian", "JP" to "Japanese",
    "KR" to "Korean", "CN" to "Chinese", "TW" to "Chinese",
    "TR" to "Turkish", "SA" to "Arabic", "AE" to "Arabic",
    "EG" to "Arabic", "PK" to "Urdu", "BD" to "Bengali",
    "LK" to "Tamil", "ID" to "Indonesian", "TH" to "Thai",
    "VN" to "Vietnamese", "NL" to "Dutch", "PL" to "Polish",
    "UA" to "Ukrainian", "IR" to "Persian", "SE" to "Swedish"
)

/** (language, char index) for every flag emoji pair in [raw]. */
private fun flagLanguageHits(raw: String): List<Pair<String, Int>> {
    val out = mutableListOf<Pair<String, Int>>()
    var i = 0
    while (i < raw.length) {
        val cp = Character.codePointAt(raw, i)
        if (cp in 0x1F1E6..0x1F1FF && i + 1 < raw.length) {
            val cp2 = Character.codePointAt(raw, i + Character.charCount(cp))
            if (cp2 in 0x1F1E6..0x1F1FF) {
                val country = buildString {
                    append('A' + (cp - 0x1F1E6))
                    append('A' + (cp2 - 0x1F1E6))
                }
                FLAG_LANGUAGE_BY_COUNTRY[country]?.let { out += it to i }
                i += Character.charCount(cp) + Character.charCount(cp2)
                continue
            }
        }
        i += Character.charCount(cp)
    }
    return out
}

/**
 * Languages in [raw], in the order the title declares them: full
 * names, ISO 639-2 codes and flag emoji all count (v0.14.21) — the
 * addon's own formatted text is what the badges dress.
 */
fun parseStreamLanguages(raw: String): List<String> {
    val hits = mutableListOf<Pair<String, Int>>()
    for ((lang, re) in STREAM_LANGUAGE_RES) {
        re.find(raw)?.let { hits += lang to it.range.first }
    }
    for (match in ISO2_TOKEN_RE.findAll(raw)) {
        STREAM_LANGUAGE_ISO2[match.value]?.let { hits += it to match.range.first }
    }
    hits += flagLanguageHits(raw)
    return hits.sortedBy { it.second }.map { it.first }.distinct()
}

/** Display form for a parsed source tag: HDTC / WEB-DL / WEBRip / BluRay / HDRip… */
private fun streamSourceDisplay(raw: String): String {
    val u = raw.uppercase().replace(WHITESPACE_DASH_RE, "-")
    return when {
        u.contains("BLU") || u == "BDRIP" -> "BluRay"
        u.startsWith("WEB") && u.contains("DL") -> "WEB-DL"
        u == "WEBRIP" -> "WEBRip"
        u == "BRRIP" -> "BRRip"
        u == "HDRIP" -> "HDRip"
        u == "DVDRIP" -> "DVDRip"
        else -> u
    }
}

/** Bytes (behaviorHints videoSize) formatted the way titles print size. */
private fun formatStreamBytes(bytes: Long): String =
    if (bytes >= 1_073_741_824L) {
        String.format(java.util.Locale.US, "%.2f GB", bytes / 1_073_741_824.0)
    } else {
        String.format(java.util.Locale.US, "%.1f MB", bytes / 1_048_576.0)
    }

/**
 * Parses [stream]'s raw release title into card facts.
 *
 * The filename line is the title/name line that ends in a video extension
 * once its leading bracket groups ("[FSLv2] [💾 15.69 GB]") are stripped.
 * Since v0.14.11 its display form is [cleanStreamTitle] — title + year
 * only, facts removed — and only stems that don't parse keep the older
 * dots-to-spaces form with the extension kept. [showSize] is the Settings → Streams size
 * toggle: it governs the size capsule (the old corner badge is gone, so the
 * size now appears exactly once, inside the capsule row). When nothing
 * parseable is found, [StreamFacts.hasFacts] is false and the card renders
 * the raw title exactly as before.
 */
/**
 * Card facts for [stream] (v0.14.17): the showSize=true result —
 * the only variant the cards render — comes from the parse-once
 * cache; other callers compute directly.
 */
fun streamFacts(stream: StreamItem, showSize: Boolean): StreamFacts =
    if (showSize) streamFactsParseCache[stream] else computeStreamFacts(stream, showSize)

private fun computeStreamFacts(stream: StreamItem, showSize: Boolean): StreamFacts {
    val info = cachedStreamInfo(stream)
    val rawLines = listOfNotNull(stream.filename, stream.title, stream.name)
        .flatMap { field ->
            field.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }
    val stripped = rawLines.map { it.replace(LEADING_BRACKETS_RE, "").trim() }
    val filenameLine = stripped.firstOrNull { STREAM_EXT_RE.containsMatchIn(it) }
        ?: stripped.filter { line ->
            // A bare size line ("6.06 GB") is a fact for the capsules,
            // never a filename (v0.14.23, owner's screenshot: on rows
            // whose release name carried no dots it won this fallback
            // and the card showed the size as its heading).
            !SIZE_RE.matches(line) && line.count { c -> c == '.' } >= 3
        }
            .maxByOrNull { it.length }
    val displayName = filenameLine?.let { line ->
        var ext = STREAM_EXT_RE.find(line)?.value?.lowercase()
        // Trailing-spaces prose filenames ("… DD 5.1 English .mkv",
        // seen on hubcloud rows): the extension search below only
        // counts when it ends the line, so drop the unspaced remnant
        // and re-find it, or the card keeps the dotted release stem.
        var stemLine = line
        if (ext == null && line.contains(" .")) {
            val trimmed = line.replace(Regex("""\s+(\.[A-Za-z0-9]{2,4})$"""), "$1")
            STREAM_EXT_RE.find(trimmed)?.let { found ->
                ext = found.value.lowercase()
                stemLine = trimmed
            }
        }
        val stem = if (ext != null) stemLine.dropLast(ext.length) else stemLine
        // v0.14.11: the name line is title + year only ("Street
        // Fighter (2026)") whenever the stem parses that far; the
        // facts it drops live in the capsules. Unparseable stems
        // keep the v0.14.10 cleaned-filename rendering.
        cleanStreamTitle(stem) ?: run {
            val spaced = stem.replace('.', ' ').replace('_', ' ')
                .replace(WHITESPACE_RUN_RE, " ").trim()
            if (ext != null && spaced.isNotBlank()) spaced + ext else spaced
        }
    }?.takeIf { it.isNotBlank() }
        ?: streamDisplayName(stream.title, stream.name, stream.url)

    // Provider line: the title's leading bracket tag ("[FSLv2]") plus the
    // addon label, "FSLv2 · HdHub" style.
    val rawAll = listOfNotNull(stream.filename, stream.title, stream.name).joinToString("\n")
    val bracketTag = BRACKET_CONTENT_RE.findAll(rawAll)
        .map { it.groupValues[1].trim() }
        .firstOrNull { tag ->
            tag.isNotBlank() && tag.length <= 24 &&
                !SIZE_RE.containsMatchIn(tag) && !tag.contains("💾")
        }
    val addonLabel = stream.sourceName?.takeIf { it.isNotBlank() }
        ?: stream.name?.takeIf { n ->
            n.isNotBlank() && n.length <= 40 && !STREAM_EXT_RE.containsMatchIn(n) &&
                !n.contains('.')
        }?.let { n ->
            // Drop a trailing quality tag ("HdHub 1080p" -> "HdHub").
            n.replace(TRAILING_QUALITY_RE, "").trim().ifBlank { null }
        }
    val providerLine = listOfNotNull(bracketTag, addonLabel)
        .distinctBy { it.lowercase() }
        .joinToString(" · ").ifBlank { null }

    val qualityNorm = when (val q = info.quality) {
        null -> null
        else -> if (q.equals("4K", true) || q.equals("UHD", true)) "2160p" else q.lowercase()
    }
    val sourceDisp = info.source?.let { streamSourceDisplay(it) }
    val remuxFound = REMUX_RE.containsMatchIn(rawAll)
    val bluRayClass = sourceDisp in setOf("BluRay", "BDRip", "BRRip") || remuxFound
    // "4K UHD" tag: the name says UHD (or 4K), or it's a 2160p rip from
    // a UHD/BluRay-class source. A plain 1080p never earns the tag.
    val qualityTag = when {
        FOUR_K_RE.containsMatchIn(rawAll) -> "4K UHD"
        qualityNorm == "2160p" && bluRayClass -> "4K UHD"
        else -> null
    }
    // HDR formats, strongest form first; DV rides last ("HDR10+ · DV").
    val hdrShort = mutableListOf<String>()
    val hdrFull = mutableListOf<String>()
    when {
        HDR10_PLUS_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR10+"; hdrFull += "HDR10+"
        }
        HDR10_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR10"; hdrFull += "HDR10"
        }
        HDR_GENERIC_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR"; hdrFull += "HDR"
        }
    }
    if (DOLBY_VISION_RE.containsMatchIn(rawAll)) {
        hdrShort += "DV"; hdrFull += "Dolby Vision"
    }
    // Audio: codec by precedence (DTS-HD before DTS, DDP family before
    // DD), plus the Atmos flag and the channel layout.
    val audioCodec = when {
        DTS_HD_RE.containsMatchIn(rawAll) -> "DTS-HD"
        TRUEHD_RE.containsMatchIn(rawAll) -> "TrueHD"
        EAC3_RE.containsMatchIn(rawAll) -> "DDP"
        AC3_RE.containsMatchIn(rawAll) -> "AC3"
        DTS_RE.containsMatchIn(rawAll) -> "DTS"
        DD_RE.containsMatchIn(rawAll) -> "DD"
        AAC_TOKEN_RE.containsMatchIn(rawAll) -> "AAC"
        FLAC_RE.containsMatchIn(rawAll) -> "FLAC"
        OPUS_RE.containsMatchIn(rawAll) -> "Opus"
        else -> null
    }
    val languageNames = parseStreamLanguages(rawAll)
    return StreamFacts(
        displayName = displayName,
        quality = qualityNorm,
        qualityTag = qualityTag,
        sourceType = sourceDisp,
        remux = remuxFound,
        hdrFormats = hdrShort,
        hdrFormatsFull = hdrFull,
        audioCodec = audioCodec,
        atmos = ATMOS_RE.containsMatchIn(rawAll),
        channels = CHANNELS_RE.find(rawAll)?.groupValues?.get(1),
        languages = languageNames,
        languageCodes = languageNames.mapNotNull { STREAM_LANGUAGE_CODES[it] },
        codec = when (val c = info.codec) {
            null -> null
            else -> if (c.startsWith("X", true)) c.lowercase() else c.uppercase()
        },
        bitDepth = if (BIT_DEPTH_RE.containsMatchIn(rawAll)) "10bit" else null,
        version = VERSION_TAG_RE.find(rawAll)?.value?.uppercase(),
        size = if (showSize) {
            info.size ?: stream.videoSize?.takeIf { it > 0 }?.let { formatStreamBytes(it) }
        } else null,
        providerLine = providerLine
    )
}

// ---------------------------------------------------------------------------
// Stream preference sorting (Settings > Streams, v0.8.31+)
// ---------------------------------------------------------------------------

/**
 * Canonical quality bucket for sort priority: "2160p" / "1080p" / "720p" /
 * "480p", or "" when the stream carries no recognizable quality tag.
 */
fun canonicalStreamQuality(stream: StreamItem): String {
    val q = cachedStreamInfo(stream).quality ?: return ""
    return when {
        q.contains("2160") || q.equals("4K", ignoreCase = true) || q.equals("UHD", ignoreCase = true) -> "2160p"
        q.contains("1080") -> "1080p"
        q.contains("720") -> "720p"
        q.contains("480") -> "480p"
        else -> ""
    }
}

/**
 * File size in GB parsed from the stream info ("9.92 GB" / "430.3 MB").
 * Null when the stream carries no size tag.
 */
fun streamSizeGb(stream: StreamItem): Double? {
    val s = cachedStreamInfo(stream).size ?: return null
    val m = SIZE_VALUE_RE.find(s) ?: return null
    val v = m.groupValues[1].toDoubleOrNull() ?: return null
    return if (m.groupValues[2].equals("GB", ignoreCase = true)) v else v / 1024.0
}

/**
 * Applies the user's stream preferences to a raw stream list:
 * quality priority — sorted by [SettingsStore.qualityOrder], top first.
 * The sort is stable: within the same quality bucket the original
 * (star-priority) order is preserved. Unknown-quality streams sink last.
 *
 * There is deliberately NO per-source cap (owner's order 2026-10-27:
 * "we don't need to limit streams, it's better to have more and
 * more") — every stream an addon returns is shown, in both Sources
 * surfaces, so the detail sheet and the player always agree.
 */
/** Precomputed sort key for [applyStreamPreferences] (v0.14.17). */
private data class PreferenceSortKey(
    val stream: StreamItem,
    val debridRank: Int,
    val qualityIdx: Int,
    val index: Int
)

fun applyStreamPreferences(
    streams: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore
): List<StreamItem> {
    val order = settings.qualityOrder
    // Debrid priority (owner's order 2026-10-31): debrid-resolved
    // (cached) streams sort FIRST so they display first and play
    // first — TorBox ahead of the other providers (DebridSupport
    // rank). The legacy ⚡/TorBox addon-row heuristic stays as a
    // fallback rank for rows the native layer did not resolve.
    val torboxLinked = !settings.torboxApiKey.isNullOrBlank()
    // v0.14.17 lag fix (audit cause 2): the sort keys are computed
    // ONCE per stream up front — the quality half reads the
    // parse-once cache — instead of the comparator re-parsing every
    // title on every comparison (~2,000 full parses to sort 149
    // streams, on the main thread, per list emission). The explicit
    // index tiebreak reproduces the old comparator's stable order
    // exactly: TorBox first, then quality-priority order, original
    // (star-priority) order inside a bucket.
    val keyed = streams.mapIndexed { index, s ->
        val idx = order.indexOf(canonicalStreamQuality(s))
        val nativeRank = com.pulsestream.app.data.debrid.DebridSupport.debridRank(s)
        PreferenceSortKey(
            stream = s,
            debridRank = if (nativeRank == 7 && torboxLinked && ((s.title?.contains("⚡") == true) || (s.name?.contains("⚡") == true) || (s.sourceName?.contains("TorBox", ignoreCase = true) == true))) 6 else nativeRank,
            qualityIdx = if (idx >= 0) idx else Int.MAX_VALUE,
            index = index
        )
    }
    return keyed.sortedWith(
        compareBy<PreferenceSortKey> { it.debridRank }
            .thenBy { it.qualityIdx }
            .thenBy { it.index }
    ).map { it.stream }
}

// ---- P6 (v0.14.22): language awareness for the picker ----
// Common language names -> ISO 639-1, for matching an addon's
// free-form audioLanguage ("Hindi", "hin", "hi") against the
// Settings preference (an ISO code or a name).
private val LANGUAGE_NAME_TO_ISO = mapOf(
    "hindi" to "hi", "english" to "en", "urdu" to "ur", "arabic" to "ar",
    "spanish" to "es", "french" to "fr", "german" to "de", "turkish" to "tr",
    "korean" to "ko", "japanese" to "ja", "tamil" to "ta", "telugu" to "te",
    "bengali" to "bn", "punjabi" to "pa", "malayalam" to "ml",
    "marathi" to "mr", "russian" to "ru", "italian" to "it",
    "portuguese" to "pt", "indonesian" to "id", "thai" to "th",
    "vietnamese" to "vi", "persian" to "fa", "farsi" to "fa"
)

private fun normalizeLanguageCode(raw: String?): String? {
    val v = raw?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: return null
    LANGUAGE_NAME_TO_ISO[v]?.let { return it }
    // ISO 639-2 (3 letters, e.g. "hin"/"eng") folds to 639-1 by its
    // bibliographic stem for the common cases handled above; anything
    // else compares on its first two letters.
    return if (v.length >= 2) v.take(2) else v
}

// ISO 639-1 -> ISO 639-2 codes for the languages above, so a release
// title token like "hin" also names the language (v0.14.14, item 8).
private val LANGUAGE_ISO1_TO_ISO2 = mapOf(
    "hi" to "hin", "en" to "eng", "ur" to "urd", "ar" to "ara",
    "es" to "spa", "fr" to "fra", "de" to "deu", "tr" to "tur",
    "ko" to "kor", "ja" to "jpn", "ta" to "tam", "te" to "tel",
    "bn" to "ben", "pa" to "pan", "ml" to "mal", "mr" to "mar",
    "ru" to "rus", "it" to "ita", "pt" to "por", "id" to "ind",
    "th" to "tha", "vi" to "vie", "fa" to "fas"
)

private val LANGUAGE_TOKEN_SPLIT = Regex("[^a-z0-9]+")

/**
 * True when [stream] is in the preferred language. Two signals:
 *  1. the addon-declared audio language matches (the original P6 rule);
 *  2. (v0.14.14, item 8) the stream's title/name EXPLICITLY names the
 *     language — its full name ("Hindi"), ISO 639-1 ("hi") or 639-2
 *     ("hin") code as a whole token in the release text. Most addons
 *     declare no audioLanguage, so without signal 2 the Settings
 *     language preference rarely bit. "Dual"/"multi" audio counts ONLY
 *     when the language itself is named — a bare "Dual Audio" label
 *     never matches anything.
 */
fun streamMatchesPreferredLanguage(
    stream: StreamItem,
    settings: com.pulsestream.app.data.SettingsStore
): Boolean {
    val pref = normalizeLanguageCode(settings.preferredAudioLanguage) ?: return false
    normalizeLanguageCode(stream.audioLanguage)?.let { if (it == pref) return true }
    val name = LANGUAGE_NAME_TO_ISO.entries.firstOrNull { it.value == pref }?.key
    val tokens = buildSet {
        name?.let { add(it) }
        add(pref)
        LANGUAGE_ISO1_TO_ISO2[pref]?.let { add(it) }
    }
    val text = "${stream.title.orEmpty()} ${stream.name.orEmpty()}".lowercase()
    if (text.isBlank()) return false
    val words = text.split(LANGUAGE_TOKEN_SPLIT).filter { it.isNotBlank() }.toHashSet()
    return tokens.any { it in words }
}

/**
 * Language-first WITHIN quality (P6): a stable partition applied per
 * quality bucket of an already quality-sorted list — a preferred-
 * language file jumps ahead of same-quality files only, never across
 * the quality/size rules (step down before up stays the picker's law).
 */
fun preferLanguageWithinQuality(
    sorted: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore
): List<StreamItem> {
    if (settings.preferredAudioLanguage.isNullOrBlank()) return sorted
    if (sorted.none { streamMatchesPreferredLanguage(it, settings) }) return sorted
    val out = ArrayList<StreamItem>(sorted.size)
    var i = 0
    while (i < sorted.size) {
        val q = canonicalStreamQuality(sorted[i])
        var j = i
        while (j < sorted.size && canonicalStreamQuality(sorted[j]) == q) j++
        val group = sorted.subList(i, j)
        out += group.filter { streamMatchesPreferredLanguage(it, settings) }
        out += group.filter { !streamMatchesPreferredLanguage(it, settings) }
        i = j
    }
    return out
}

/**
 * The autoplay rule as an ORDERING (P6): quality priority (explicit
 * bucket first, else quality-order), with the language tier applied
 * inside each bucket. Shared by [pickAutoplayStream] and the player's
 * failover walk, so every path that picks a stream honours the same
 * settings.
 *
 * Owner's 2 autoplay rules (2026-11-02, v0.14.39 audit):
 *  1. A streams rule set in Settings rules the pick — the explicit
 *     autoplay-quality bucket first, else the user's quality order;
 *     the size limit is applied by [pickAutoplayStream] on top.
 *  2. With NO rule set, autoplay plays the best stream at the
 *     highest quality possible — the default quality order is
 *     highest-first, so rule 2 is the same ordering with defaults.
 * "Auto" therefore now means exactly what its Settings label says —
 * "Follow the quality order above". The adaptive device/network cap
 * (2026-10-20) used to override BOTH rules whenever quality sat on
 * "Auto" (a fresh install on a 720p phone could never autoplay a
 * 4K stream, and a user's custom quality order was ignored); it no
 * longer touches stream picking. It still governs the in-player
 * "Auto" track selection and download defaults, which are separate
 * features and stay untouched.
 */
fun orderByAutoplayRules(
    streams: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore
): List<StreamItem> {
    val playable = streams.filter { !it.url.startsWith("infohash:") }
    if (playable.isEmpty()) return emptyList()
    val order = settings.qualityOrder
    val prefQ = settings.autoplayQuality
    val sorted = playable.sortedWith(compareBy { s ->
        val q = canonicalStreamQuality(s)
        when {
            prefQ != "Auto" && q == prefQ -> -1
            else -> order.indexOf(q).takeIf { it >= 0 } ?: Int.MAX_VALUE
        }
    })
    val tiered = preferDebridWithinQuality(preferLanguageWithinQuality(sorted, settings))
    // Smart Picks tier (owner's order 2026-11-02): with a debrid
    // attached, the debrid tier above is the WHOLE rule — debrid
    // gets always priority. Only when NO debrid is attached do the
    // server-flagged Smart Picks lead inside their quality groups.
    return if (com.pulsestream.app.data.debrid.DebridSupport.isActive(settings)) tiered
    else preferSmartPicksWithinQuality(tiered)
}

/**
 * Debrid tier (owner's order 2026-10-31): within each quality group
 * of the autoplay ordering, debrid-resolved (cached) rows come
 * first — TorBox ahead of the other providers — so autoplay plays a
 * cached stream whenever one matches the quality/language rules.
 * The group order itself (the settings rule) is untouched, and the
 * sort is stable, so the language tier inside a group survives for
 * rows of equal debrid rank.
 */
fun preferDebridWithinQuality(streams: List<StreamItem>): List<StreamItem> {
    if (streams.size < 2) return streams
    val out = ArrayList<StreamItem>(streams.size)
    var i = 0
    while (i < streams.size) {
        val q = canonicalStreamQuality(streams[i])
        var j = i + 1
        while (j < streams.size && canonicalStreamQuality(streams[j]) == q) j++
        out += streams.subList(i, j).sortedBy {
            com.pulsestream.app.data.debrid.DebridSupport.debridRank(it)
        }
        i = j
    }
    return out
}

/**
 * Smart Picks tier (owner's order 2026-11-02): the same stable
 * partition shape as the debrid/language tiers — inside each
 * quality group of the autoplay ordering, server-flagged Smart
 * Picks (StreamItem.plavioPick: links PlavioHD has itself
 * playback-verified) come first, so with no debrid attached
 * autoplay plays a recommended stream whenever one matches the
 * quality rules. Applied by [orderByAutoplayRules] ONLY when no
 * debrid is attached; with a debrid attached the debrid tier is
 * the whole rule and this partition never runs. The group order
 * itself (the settings rule) is untouched and the sort is stable,
 * so the language tier inside a group survives.
 */
fun preferSmartPicksWithinQuality(streams: List<StreamItem>): List<StreamItem> {
    if (streams.size < 2) return streams
    if (streams.none { it.plavioPick }) return streams
    val out = ArrayList<StreamItem>(streams.size)
    var i = 0
    while (i < streams.size) {
        val q = canonicalStreamQuality(streams[i])
        var j = i + 1
        while (j < streams.size && canonicalStreamQuality(streams[j]) == q) j++
        val group = streams.subList(i, j)
        out += group.filter { it.plavioPick }
        out += group.filter { !it.plavioPick }
        i = j
    }
    return out
}

/**
 * Picks the autoplay stream under the Settings > Streams rule:
 * quality priority (preferred quality jumps first when set to a specific
 * bucket), then the size limit. Falls back to the first stream when nothing
 * matches, so autoplay never dead-ends on an empty pick.
 */
fun pickAutoplayStream(
    streams: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore
): StreamItem? {
    // Filter out unresolved infohash: placeholders - only pick playable URLs.
    // Debrid resolution replaces these with real HTTP links asynchronously.
    if (streams.none { !it.url.startsWith("infohash:") }) return null
    val maxGb = settings.autoplayMaxSizeGb

    // P6: the ordering (quality + language tier) lives in
    // orderByAutoplayRules so the probe path and failover share it;
    // this pick then applies the size limit on top of that order.
    val sorted = orderByAutoplayRules(streams, settings)
    return sorted.firstOrNull { s ->
        maxGb <= 0 || (streamSizeGb(s)?.let { it <= maxGb } ?: true)
    } ?: sorted.firstOrNull()
}

/**
 * Season-download quality pick (v0.14.42, owner's order
 * 2026-11-13): the user picked ONE quality for the whole season;
 * this is the per-episode half of that promise. Within the
 * autoplay ordering (quality/language/debrid tiers intact), take
 * the best stream AT the picked quality; an episode that lacks it
 * steps DOWN through the lower buckets in order — never up as
 * long as anything at or below the pick exists. Only when the
 * episode has NOTHING at or below the pick does the closest
 * bucket above it answer (the alternative would be silently
 * dropping the episode from a download the user asked for). The
 * Settings size cap applies inside each bucket exactly as in
 * [pickAutoplayStream]. Streams with no readable quality label
 * are the last resort, through the plain autoplay pick.
 */
fun pickStreamAtQuality(
    streams: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore,
    targetQuality: String
): StreamItem? {
    val target = normalizeStreamQuality(targetQuality)
        ?: return pickAutoplayStream(streams, settings)
    val ordered = orderByAutoplayRules(streams, settings)
    if (ordered.isEmpty()) return null
    val maxGb = settings.autoplayMaxSizeGb
    fun firstIn(bucket: String): StreamItem? {
        val group = ordered.filter {
            normalizeStreamQuality(cachedStreamInfo(it).quality) == bucket
        }
        if (group.isEmpty()) return null
        return group.firstOrNull { s ->
            maxGb <= 0 || (streamSizeGb(s)?.let { it <= maxGb } ?: true)
        } ?: group.first()
    }
    firstIn(target)?.let { return it }
    val idx = STREAM_QUALITY_ORDER.indexOf(target)
    if (idx >= 0) {
        // Step DOWN only: every lower bucket, best first.
        for (i in idx + 1 until STREAM_QUALITY_ORDER.size) {
            firstIn(STREAM_QUALITY_ORDER[i])?.let { return it }
        }
        // Nothing at or below the pick: the closest bucket above
        // (lowest first) rather than a silently missing episode.
        for (i in idx - 1 downTo 0) {
            firstIn(STREAM_QUALITY_ORDER[i])?.let { return it }
        }
    }
    return pickAutoplayStream(streams, settings)
}

// ---------------------------------------------------------------------------
// Addon tabs + state
// ---------------------------------------------------------------------------

const val STREAM_TAB_ALL = "__all__"

data class StreamTab(
    val key: String,
    val label: String,
    val count: Int,
    /** Manifest logo of the addon behind this tab (Sample 1 dressing). */
    val logo: String? = null
)

@Stable
class StreamBrowserState(
    val tabs: List<StreamTab>,
    val selectedTab: String,
    val filtered: List<StreamItem>,
    val onSelectTab: (String) -> Unit,
    // Quality filter (user's order): dynamic pills, only shown qualities.
    val qualities: List<String>,
    val selectedQuality: String?,
    val onSelectQuality: (String?) -> Unit,
    // Sources dressing (Sample 1, v0.14.6): Settings → Streams toggles.
    val showAddonLogos: Boolean = true,
    val showSizeBadges: Boolean = true,
    val sizeBadgeTop: Boolean = false,
    // Capsule style + group toggles (v0.14.12).
    val capsuleConfig: StreamCapsuleConfig = StreamCapsuleConfig()
    // NOTE (v0.14.14, item 5): the v0.14.39 "Recommended" FILTER chip
    // is gone — the owner's correction: Recommended is a TAG on the
    // qualifying rows themselves (see recommendedStreamUrls), never a
    // button or filter.
)

@Composable
fun rememberStreamBrowserState(
    streams: List<StreamItem>,
    settings: com.pulsestream.app.data.SettingsStore? = null,
    addonLogos: Map<String, String> = emptyMap()
): StreamBrowserState {
    // Every surface shows the complete loaded set — no per-source cap.
    val ordered = remember(streams, settings?.qualityOrder) {
        if (settings != null) applyStreamPreferences(streams, settings) else streams
    }
    // Saveable: the addon tab the user picked survives rotation. A stale
    // key (tab gone after the stream list changed) falls back to "All".
    var selectedTab by rememberSaveable { mutableStateOf(STREAM_TAB_ALL) }
    // Quality filter: null = All qualities. Dynamic — only qualities present
    // in the current stream list get a pill (user's order).
    var selectedQuality by rememberSaveable { mutableStateOf<String?>(null) }
    val tabs = remember(ordered, addonLogos) {
        val groups = ordered.groupBy { it.addonKey() }
        buildList {
            add(StreamTab(STREAM_TAB_ALL, "All", ordered.size))
            groups.entries.sortedByDescending { it.value.size }.forEach { (key, list) ->
                add(StreamTab(key, key, list.size, logo = addonLogos[key]))
            }
        }
    }
    // Base choices on all fresh combined results, not the possibly capped
    // display list. This keeps every quality discoverable in the picker.
    val qualities = remember(streams) { availableStreamQualities(streams) }
    val safeTab = if (tabs.any { it.key == selectedTab }) selectedTab else STREAM_TAB_ALL
    val normalizedSelection = normalizeStreamQuality(selectedQuality)
    val safeQuality = normalizedSelection?.takeIf { it in qualities }
    val filtered = remember(ordered, safeTab, safeQuality) {
        var list = if (safeTab == STREAM_TAB_ALL) ordered
        else ordered.filter { it.addonKey() == safeTab }
        list = filterStreamsByQuality(list, safeQuality)
        list
    }
    val showAddonLogos = settings?.streamAddonLogos ?: true
    val showSizeBadges = settings?.streamSizeBadges ?: true
    val sizeBadgeTop = settings?.streamBadgeTop ?: false
    val capsuleConfig = settings?.streamCapsuleConfig() ?: StreamCapsuleConfig()
    return remember(
        tabs, safeTab, filtered, qualities, safeQuality,
        showAddonLogos, showSizeBadges, sizeBadgeTop, capsuleConfig
    ) {
        StreamBrowserState(
            tabs, safeTab, filtered, { selectedTab = it }, qualities, safeQuality,
            { selectedQuality = normalizeStreamQuality(it) },
            showAddonLogos, showSizeBadges, sizeBadgeTop, capsuleConfig
        )
    }
}

/**
 * Sources-panel header capsule (owner's order 2026-10-27): the total
 * number of streams loaded so far, in a frosted capsule at the top of
 * the panel. While more addons are still answering it carries the
 * app's orbit loader and a "loading" label, so the user can see the
 * list is still growing; tapping the capsule force-refreshes —
 * re-queries every addon and pulls anything the first pass missed.
 * Shared by BOTH Sources surfaces (detail sheet + in-player sheet)
 * so they behave identically and end with the same complete set.
 */
@Composable
fun StreamCountCapsule(
    total: Int,
    loading: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPalette.current
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, GlassBorder, RoundedCornerShape(50))
            .clickable { onRefresh() }
            .tvFocusRing(RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        if (loading) {
            OrbitDots(modifier = Modifier.size(16.dp))
        }
        Text(
            text = if (loading) "$total streams · loading" else "$total streams",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1
        )
        Icon(
            // v0.14.32 (owner's pick): the refresh glyph is now
            // Sync — two arrows chasing in a circle. Same button,
            // same place, same behaviour.
            Icons.Filled.Sync,
            contentDescription = "Reload sources",
            tint = if (loading) TextSecondary else palette.accent,
            modifier = Modifier.size(15.dp)
        )
    }
}

/** The two locked verdicts of the sources timer capsule. */
enum class SourcesTimerMood { ROCKET, STEADY }

/**
 * The verdict line (owner-locked, v0.14.32): under 10 seconds is
 * a Rocket; 10 seconds and over is Steady. Positive-only — the
 * joke lands on the wait, never on the user.
 */
fun sourcesTimerMood(elapsedMs: Long): SourcesTimerMood =
    if (elapsedMs < 10_000L) SourcesTimerMood.ROCKET else SourcesTimerMood.STEADY

/** "2.3s" — tenths, floored, no locale separators. */
fun formatSourcesElapsed(elapsedMs: Long): String {
    val tenths = (elapsedMs.coerceAtLeast(0L) / 100L).toInt()
    return "${tenths / 10}.${tenths % 10}s"
}

/** The live counting line shown while streams are still loading. */
fun sourcesTimerLoadingText(elapsedMs: Long): String =
    "⏱ Loading… ${formatSourcesElapsed(elapsedMs)}"

/** The locked verdict line: time + ONE word. */
fun sourcesTimerDoneText(elapsedMs: Long): String =
    when (sourcesTimerMood(elapsedMs)) {
        SourcesTimerMood.ROCKET -> "🚀 ${formatSourcesElapsed(elapsedMs)} · Rocket!"
        SourcesTimerMood.STEADY -> "😌 ${formatSourcesElapsed(elapsedMs)} · Steady!"
    }

/**
 * Load-timer state for one Sources surface (v0.14.32): starts on
 * the loading rising edge, ticks with the frame clock, and locks
 * its final time on the falling edge. A surface that is already
 * loaded when it opens (the PrePlay pocket) locks at ~0 and reads
 * as a Rocket — it WAS instant.
 */
class SourcesLoadTimerState {
    var startMs by mutableStateOf<Long?>(null)
    var finalMs by mutableStateOf<Long?>(null)
    var nowMs by mutableStateOf(0L)

    /** True once a load has finished and the verdict is locked. */
    val done: Boolean get() = finalMs != null

    /** Live elapsed while counting; the locked time once done. */
    val elapsedMs: Long
        get() = finalMs ?: startMs?.let { (nowMs - it).coerceAtLeast(0L) } ?: 0L
}

/** Remembers and drives a [SourcesLoadTimerState] for [loading]. */
@Composable
fun rememberSourcesLoadTimer(loading: Boolean): SourcesLoadTimerState {
    val state = remember { SourcesLoadTimerState() }
    LaunchedEffect(loading) {
        if (loading) {
            // A fresh load — the first ever, or a refresh after a
            // finished one (finalMs set) — restarts the clock.
            if (state.startMs == null || state.finalMs != null) {
                val t = withFrameMillis { it }
                state.startMs = t
                state.nowMs = t
            }
            state.finalMs = null
            while (true) {
                state.nowMs = withFrameMillis { it }
            }
        } else {
            state.finalMs = state.startMs
                ?.let { (state.nowMs - it).coerceAtLeast(0L) } ?: 0L
        }
    }
    return state
}

/**
 * Sources timer capsule (owner-locked sample, v0.14.32): a small
 * capsule at the top of the Sources sheet beside the count
 * capsule. While streams load it counts live ("⏱ Loading… 3.2s");
 * when loading finishes it locks to the time + one word
 * ("🚀 2.3s · Rocket!" / "😌 14.5s · Steady!"). Display-only.
 */
@Composable
fun SourcesTimerCapsule(state: SourcesLoadTimerState, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, GlassBorder, RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (state.done) {
                sourcesTimerDoneText(state.elapsedMs)
            } else {
                sourcesTimerLoadingText(state.elapsedMs)
            },
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1
        )
    }
}

/**
 * An addon tab's logo (Sample 1): the manifest logo as a small round
 * image, or a letter tile with the addon's initial when it has none.
 */
@Composable
fun TabLogoOrLetter(name: String, logo: String?, size: androidx.compose.ui.unit.Dp = 18.dp) {
    if (!logo.isNullOrBlank()) {
        SafePosterImage(
            model = logo,
            contentDescription = null,
            modifier = Modifier
                .size(size)
                .clip(CircleShape),
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = name.trim().firstOrNull()?.uppercase() ?: "?",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}

@Composable
fun AddonTabs(state: StreamBrowserState, modifier: Modifier = Modifier, compact: Boolean = false) {
    if (!compact && state.tabs.size <= 2) return // Preserve the original non-compact behavior.
    val palette = LocalPalette.current
    val tabs = if (compact) state.tabs.sortedBy { tab ->
        when {
            tab.key == STREAM_TAB_ALL -> 0
            tab.label.equals("PlavioHD", ignoreCase = true) -> 1
            tab.label.equals("TMAddon", ignoreCase = true) -> 2
            tab.label.equals("StAddon", ignoreCase = true) -> 3
            else -> 4
        }
    } else state.tabs
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp),
        horizontalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)
    ) {
        items(tabs, key = { it.key }) { tab ->
            val selected = tab.key == state.selectedTab
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected && compact) palette.accent
                        else if (selected) palette.accent.copy(alpha = 0.22f)
                        else Color.White.copy(alpha = 0.06f)
                    )
                    .border(
                        1.dp,
                        if (selected) palette.accent else GlassBorder,
                        RoundedCornerShape(50)
                    )
                    .clickable(role = Role.Tab) { state.onSelectTab(tab.key) }
                    .semantics { this.selected = selected }
                    .tvFocusRing(RoundedCornerShape(50))
                    .padding(horizontal = if (compact) 11.dp else 14.dp, vertical = if (compact) 6.dp else 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Sample 1 dressing: the addon's own logo on its tab
                    // (letter tile when the manifest has none). The All
                    // tab never carries one.
                    if (state.showAddonLogos && tab.key != STREAM_TAB_ALL) {
                        TabLogoOrLetter(name = tab.label, logo = tab.logo)
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        text = if (compact) tab.label else "${tab.label} • ${tab.count}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected && compact) Color.Black else if (selected) TextPrimary else TextSecondary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * Quality filter pills (user's order): only qualities present in the stream
 * list get a pill. Tapping one filters across ALL addons.
 * (v0.14.14, item 5: the v0.14.39 "Recommended" pill that sat between
 * Any and the qualities is REMOVED — Recommended is a row tag now,
 * never a filter.)
 */
@Composable
fun QualityPills(state: StreamBrowserState, modifier: Modifier = Modifier, compact: Boolean = false) {
    if (state.qualities.isEmpty()) return
    if (!compact && state.qualities.size <= 1) return
    val palette = LocalPalette.current
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp),
        horizontalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)
    ) {
        item(key = "quality_all") {
            // "Any" reads selected only when no quality is filtered.
            val selected = state.selectedQuality == null
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected && compact) palette.accent
                        else if (selected) palette.accent.copy(alpha = 0.22f)
                        else Color.White.copy(alpha = 0.06f)
                    )
                    .border(
                        1.dp,
                        if (selected) palette.accent else GlassBorder,
                        RoundedCornerShape(50)
                    )
                    .clickable(role = Role.RadioButton) {
                        state.onSelectQuality(null)
                    }
                    .semantics { this.selected = selected }
                    .tvFocusRing(RoundedCornerShape(50))
                    .padding(horizontal = if (compact) 11.dp else 14.dp, vertical = if (compact) 6.dp else 8.dp)
            ) {
                Text(
                    text = if (compact) "Any" else "All",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected && compact) Color.Black else if (selected) TextPrimary else TextSecondary,
                    maxLines = 1
                )
            }
        }
        items(state.qualities, key = { "quality_$it" }) { quality ->
            val selected = state.selectedQuality == quality
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected && compact) palette.accent
                        else if (selected) palette.accent.copy(alpha = 0.22f)
                        else Color.White.copy(alpha = 0.06f)
                    )
                    .border(
                        1.dp,
                        if (selected) palette.accent else GlassBorder,
                        RoundedCornerShape(50)
                    )
                    .clickable(role = Role.RadioButton) { state.onSelectQuality(if (selected) null else quality) }
                    .semantics { this.selected = selected }
                    .tvFocusRing(RoundedCornerShape(50))
                    .padding(horizontal = if (compact) 11.dp else 14.dp, vertical = if (compact) 6.dp else 8.dp)
            ) {
                Text(
                    text = quality.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected && compact) Color.Black else if (selected) TextPrimary else TextSecondary,
                    maxLines = 1
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Stream rows
// ---------------------------------------------------------------------------

/**
 * One fact capsule on a cleaned-up stream card (v0.14.10, owner's design
 * condition): BEAUTIFUL LIQUID GLASS — the app's frosted liquid-glass
 * recipe (the same treatment as the bottom dock and the glass chips:
 * translucent blurred fill, soft light border, gentle top highlight),
 * never a flat pill. [tint] (v0.14.12) lays the SOFT category tint over
 * the glass: a gentle wash of the colour inside, the rim in the colour,
 * white text on top.
 */
@Composable
fun StreamFactCapsule(text: String, modifier: Modifier = Modifier, tint: Color? = null) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .liquidGlass(shape, frost = 0.12f)
            .then(
                if (tint != null) {
                    Modifier
                        .background(tint.copy(alpha = 0.13f), shape)
                        .border(1.dp, tint.copy(alpha = 0.55f), shape)
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1
        )
    }
}

/**
 * The wrapping badge row under a cleaned stream filename, rendered in
 * the user's chosen style (Settings → Streams → Badge style). Delegates
 * to [BadgeStrip] in StreamBadges.kt; all five styles read the same
 * parsed facts and obey the same group toggles.
 */
@Composable
fun StreamFactCapsules(
    facts: StreamFacts,
    config: StreamCapsuleConfig = StreamCapsuleConfig(),
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    extra: (@Composable () -> Unit)? = null
) {
    BadgeStrip(facts, config, modifier, trailing, extra)
}

/**
 * v0.14.13 (item 5): adaptive streams are no longer blanket-labelled
 * "Stream only" — HLS has a working segment engine and DASH joins it
 * in this build, so both card variants offer the download action for
 * every stream. What genuinely can't be saved (live manifests,
 * SAMPLE-AES HLS, DRM DASH) is only knowable once the manifest is
 * fetched, so the honesty now lives where the fact is known: the
 * download confirm dialog and the engine's own error on the row.
 */

/**
 * Green tag naming the debrid service that cached a resolved row
 * ("TorBox Cached", "Real-Debrid Cached", ...) — Sample B's tag
 * style (owner's pick 2026-10-31: whole Sample B; wording = the
 * service name, per his follow-up order).
 */
@Composable
private fun DebridCachedTag(label: String) {
    Text(
        label,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFF4ADE80),
        letterSpacing = 0.4.sp,
        modifier = Modifier
            .background(Color(0xFF4ADE80).copy(alpha = 0.14f), RoundedCornerShape(999.dp))
            .border(1.dp, Color(0xFF4ADE80).copy(alpha = 0.35f), RoundedCornerShape(999.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/** How many rows per title may carry the ★ RECOMMENDED tag. */
const val MAX_RECOMMENDED_TAGS = 4

/**
 * The streams that earn the ★ RECOMMENDED row tag (v0.14.14, item 5 —
 * the owner's correction: a TAG on the rows themselves, not a button
 * and not a filter chip). All criteria required:
 *  - served by the PlavioHD addon (the same identity test the tab
 *    ordering uses);
 *  - quality 720p or better (prober quality rank);
 *  - seekable — the host is not flagged unseekable;
 *  - not proven dead: the prober verdict for the URL is ALIVE or not
 *    yet known — a DEAD verdict disqualifies.
 * At most [MAX_RECOMMENDED_TAGS] per title, best candidates first:
 * server-flagged Smart Picks (PlavioHD's own playback-verified rows)
 * lead, then prober-ALIVE rows, then higher quality, then larger
 * size. Returns the winning URLs (row identity in the lists).
 */
fun recommendedStreamUrls(streams: List<StreamItem>): Set<String> {
    val candidates = streams.filter { s ->
        s.addonKey().equals("PlavioHD", ignoreCase = true) &&
            com.pulsestream.app.data.StreamProber.qualityRank(s) >=
                com.pulsestream.app.data.StreamProber.qualityRank("720p") &&
            !com.pulsestream.app.data.isUnseekableStreamUrl(s.url) &&
            !s.url.startsWith("infohash:", true) &&
            !s.url.startsWith("magnet:", true) &&
            com.pulsestream.app.data.StreamProber.verdictOf(s.url) !=
                com.pulsestream.app.data.StreamProber.Verdict.DEAD
    }
    if (candidates.isEmpty()) return emptySet()
    return candidates.sortedWith(
        compareByDescending<StreamItem> { it.plavioPick }
            .thenBy {
                if (com.pulsestream.app.data.StreamProber.verdictOf(it.url) ==
                    com.pulsestream.app.data.StreamProber.Verdict.ALIVE
                ) 0 else 1
            }
            .thenByDescending { com.pulsestream.app.data.StreamProber.qualityRank(it) }
            .thenByDescending { streamSizeGb(it) ?: 0.0 }
    ).take(MAX_RECOMMENDED_TAGS).map { it.url }.toSet()
}

/**
 * Smart Pick badge, style B (owner's pick 2026-11-02, replacing the
 * Smart Picks box): a small green OUTLINE chip — "★ RECOMMENDED" in
 * bold #22C55E — that rides IN the stream row's badge row, right
 * after the quality/size capsules. Since v0.14.14 (item 5) it marks
 * the rows chosen by [recommendedStreamUrls] (PlavioHD, 720p+,
 * seekable, not prober-dead, at most 4 per title) instead of every
 * server-flagged row. It is independent of the debrid cached tag: a
 * row that is BOTH cached and recommended shows both markers.
 */
@Composable
private fun SmartPickBadge() {
    val green = Color(0xFF22C55E)
    Text(
        "★ RECOMMENDED",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = green,
        letterSpacing = 0.4.sp,
        maxLines = 1,
        modifier = Modifier
            .border(1.dp, green, RoundedCornerShape(999.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/**
 * "Instant play" section header (Sample B): shown above the
 * debrid-resolved group, which the ordering pins to the top of the
 * list — a bolt, the title, and whose cache the streams sit on.
 */
@Composable
private fun InstantPlayHeader(streams: List<StreamItem>) {
    val names = remember(streams) {
        streams.mapNotNull {
            com.pulsestream.app.data.debrid.DebridSupport.cachedLabel(it)
        }.map { it.removeSuffix(" Cached") }.distinct()
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.FlashOn, contentDescription = null,
            tint = Color(0xFF4ADE80), modifier = Modifier.size(17.dp)
        )
        Spacer(Modifier.width(7.dp))
        Text(
            "Instant play",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Spacer(Modifier.weight(1f))
        Text(
            if (names.size == 1) "Cached on ${names[0]} — plays right away"
            else "Cached streams — play right away",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

/**
 * Single stream row: the full title/filename line, the badge row (with
 * the download capsule riding last in it), and the provider line.
 * Tapping the card plays; there is no separate play button (v0.14.14).
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun StreamCard(
    stream: StreamItem,
    selected: Boolean = false,
    onClick: () -> Unit,
    onDownload: ((StreamItem) -> Unit)? = null,
    compact: Boolean = false,
    showSizeBadge: Boolean = false,
    sizeBadgeTop: Boolean = false,
    capsuleConfig: StreamCapsuleConfig = StreamCapsuleConfig(),
    // ★ RECOMMENDED row tag (v0.14.14, item 5): computed per list by
    // recommendedStreamUrls and passed down — the card never decides
    // on its own, so the per-title cap of 4 holds.
    recommended: Boolean = false
) {
    val palette = LocalPalette.current
    val unresolvedTorrent = stream.url.startsWith("infohash:", true) || stream.url.startsWith("magnet:", true)
    // Cleaned-up card facts (v0.14.10): cleaned filename + capsules +
    // provider line. Since v0.14.12 the capsule row renders in the
    // user's chosen style under [capsuleConfig] (its Size toggle — the
    // old Settings "Size badges" switch — governs the size item); the
    // old corner badge is gone, so the size appears exactly once.
    // sizeBadgeTop no longer applies.
    // v0.14.29 (formatter-free): detection runs BEFORE any fact
    // parsing — a formatted row never feeds streamFacts at all (the
    // 0.14.28 order let computeStreamFacts eat the formatter's own
    // emoji/specs lines as a fake "filename line" and clean the row
    // into a house row). Formatted rows render [addonFormattedText]
    // verbatim; unformatted rows take the exact pre-0.14.29 path.
    val addonFormatted = remember(stream) { isAddonFormatted(stream) }
    val facts = remember(stream) {
        if (addonFormatted) StreamFacts(displayName = "") else streamFacts(stream, true)
    }
    val display = remember(stream) {
        if (addonFormatted) {
            StreamDisplayModel(addonFormattedText(stream), null, emptyList())
        } else {
            streamDisplayModel(stream)
        }
    }
    // Fallback: no parseable facts -> the raw title, exactly as before.
    val fullName = display.headline
    val debridCached = com.pulsestream.app.data.debrid.DebridSupport.isResolved(stream)
    val shape = RoundedCornerShape(20.dp)
    // v0.14.13 (item 5): HLS and DASH streams are downloadable —
    // no more adaptive blanket ban (see the note above).
    // The download action rides LAST in the badge row (v0.14.14),
    // dressed by the active badge style.
    val downloadTrailing: (@Composable () -> Unit)? = onDownload?.let { dl ->
        {
            StreamDownloadCapsule(
                style = capsuleConfig.style,
                enabled = !unresolvedTorrent
            ) { dl(stream) }
        }
    }
    // ★ RECOMMENDED tag (v0.14.14, item 5): rides in the badge row
    // after the quality/size capsules on the rows the list-level
    // recommendedStreamUrls picked.
    val pickBadge: (@Composable () -> Unit)? = if (recommended) {
        { SmartPickBadge() }
    } else null

    if (compact) {
        CompactStreamCard(
            stream = stream,
            selected = selected,
            display = display,
            onClick = onClick,
            onDownload = onDownload,
            showSizeBadge = showSizeBadge,
            sizeBadgeTop = sizeBadgeTop,
            capsuleConfig = capsuleConfig,
            recommended = recommended
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            // Layout spacing (v0.14.39, appearance item D) also
            // breathes the stream rows: 6.dp vertical at Comfortable
            // (the shipped value), tighter under Compact.
            .padding(horizontal = 16.dp, vertical = 6.dp * LocalSpacingScale.current)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(shape)
                .then(
                    if (selected) Modifier.border(1.5.dp, palette.accent, shape)
                    else Modifier
                )
                .clickable(enabled = !unresolvedTorrent, onClick = onClick)
                .tvFocusRing(shape)
                .padding(20.dp)
        ) {
            if (addonFormatted) {
                // Priority 1 (v0.14.28, freed v0.14.29): addon
                // formatter output renders VERBATIM \u2014 the full
                // formatted text exactly as the addon composed it
                // (name + title blocks, no dedupe/recompose), no
                // badge capsules and no uniform fact line
                // re-dressing it. The card grows with the content:
                // no line cap, no fixed row height. Only the
                // download capsule and the RECOMMENDED tag ride below.
                Text(
                    text = fullName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    lineHeight = 24.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                if (debridCached) {
                    Spacer(Modifier.height(8.dp))
                    DebridCachedTag(
                        com.pulsestream.app.data.debrid.DebridSupport.cachedLabel(stream) ?: "Debrid Cached"
                    )
                }
                if (downloadTrailing != null || pickBadge != null) {
                    Spacer(Modifier.height(8.dp))
                    StreamFactCapsules(
                        StreamFacts(displayName = ""),
                        capsuleConfig,
                        trailing = downloadTrailing,
                        extra = pickBadge
                    )
                }
            } else             if (facts.hasFacts) {
                // Cleaned filename on top (max 2 lines, extension kept),
                // the capsule row under it, then the provider line.
                Text(
                    text = facts.displayName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    lineHeight = 24.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
                if (debridCached) {
                    Spacer(Modifier.height(8.dp))
                    DebridCachedTag(
                        com.pulsestream.app.data.debrid.DebridSupport.cachedLabel(stream) ?: "Debrid Cached"
                    )
                }
                Spacer(Modifier.height(8.dp))
                StreamFactCapsules(facts, capsuleConfig, trailing = downloadTrailing, extra = pickBadge)
                // Item 5 (v0.14.24): uniform parsed fact line.
                val factLine = uniformFactLine(facts)
                if (factLine.isNotBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(
                        text = factLine,
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                facts.providerLine?.let { provider ->
                    Spacer(Modifier.height(7.dp))
                    Text(
                        text = provider,
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                // Title — full name, bigger text (user's order). The
                // title/filename line is the whole row content; the
                // download capsule still rides under it when present.
                Text(
                    text = fullName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    lineHeight = 24.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                if (downloadTrailing != null || pickBadge != null) {
                    Spacer(Modifier.height(8.dp))
                    StreamFactCapsules(facts, capsuleConfig, trailing = downloadTrailing, extra = pickBadge)
                }
            }
            if (!unresolvedTorrent && com.pulsestream.app.data.isUnseekableStreamUrl(stream.url)) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Seeking not supported by this host",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFF59E0B)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CompactStreamCard(
    stream: StreamItem,
    selected: Boolean,
    display: StreamDisplayModel,
    onClick: () -> Unit,
    onDownload: ((StreamItem) -> Unit)?,
    showSizeBadge: Boolean = false,
    sizeBadgeTop: Boolean = false,
    capsuleConfig: StreamCapsuleConfig = StreamCapsuleConfig(),
    recommended: Boolean = false
) {
    val palette = LocalPalette.current
    val shape = RoundedCornerShape(14.dp)
    val unresolvedTorrent = stream.url.startsWith("infohash:", true) || stream.url.startsWith("magnet:", true)
    // Cleaned-up card facts (v0.14.10): the capsule row renders in the
    // user's chosen style under [capsuleConfig] (v0.14.12); its Size
    // toggle governs the size item; the old corner badge is gone, so
    // the size appears exactly once.
    // sizeBadgeTop no longer applies.
    val debridCached = com.pulsestream.app.data.debrid.DebridSupport.isResolved(stream)
    // v0.14.29: same formatter-free order as the full card — detect
    // first, skip fact parsing entirely for formatted rows.
    val addonFormatted = remember(stream) { isAddonFormatted(stream) }
    val facts = remember(stream) {
        if (addonFormatted) StreamFacts(displayName = "") else streamFacts(stream, true)
    }
    // v0.14.13 (item 5): HLS and DASH streams are downloadable —
    // no more adaptive blanket ban (see the note above StreamCard).
    // The download action rides LAST in the badge row (v0.14.14),
    // dressed by the active badge style.
    val downloadTrailing: (@Composable () -> Unit)? = onDownload?.let { dl ->
        {
            StreamDownloadCapsule(
                style = capsuleConfig.style,
                enabled = !unresolvedTorrent
            ) { dl(stream) }
        }
    }
    // ★ RECOMMENDED tag (v0.14.14, item 5): same rule as the full
    // card — the list-level pick, passed down.
    val pickBadge: (@Composable () -> Unit)? = if (recommended) {
        { SmartPickBadge() }
    } else null
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 3.dp)
    ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (selected) palette.accent else GlassBorder, shape)
            .background(Color.White.copy(alpha = 0.025f), shape)
            .semantics { this.selected = selected }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).clickable(enabled = !unresolvedTorrent, onClick = onClick).tvFocusRing(shape)) {
            if (addonFormatted) {
                // Priority 1 (v0.14.28, freed v0.14.29): same
                // verbatim rule as the full card \u2014 formatter
                // text stands exactly as composed (passed in as
                // display.headline), no line cap, so the compact
                // row wraps to the full content height.
                Text(
                    text = display.headline,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    lineHeight = 19.sp
                )
                if (debridCached) {
                    Spacer(Modifier.height(6.dp))
                    DebridCachedTag(
                        com.pulsestream.app.data.debrid.DebridSupport.cachedLabel(stream) ?: "Debrid Cached"
                    )
                }
                if (downloadTrailing != null || pickBadge != null) {
                    Spacer(Modifier.height(6.dp))
                    StreamFactCapsules(
                        StreamFacts(displayName = ""),
                        capsuleConfig,
                        trailing = downloadTrailing,
                        extra = pickBadge
                    )
                }
            } else             if (facts.hasFacts) {
                // Cleaned filename (max 2 lines, extension kept), the
                // liquid-glass capsule row, then the provider line.
                Text(
                    text = facts.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    lineHeight = 19.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (debridCached) {
                    Spacer(Modifier.height(6.dp))
                    DebridCachedTag(
                        com.pulsestream.app.data.debrid.DebridSupport.cachedLabel(stream) ?: "Debrid Cached"
                    )
                }
                Spacer(Modifier.height(6.dp))
                StreamFactCapsules(facts, capsuleConfig, trailing = downloadTrailing, extra = pickBadge)
                // Item 5 (v0.14.24): the uniform parsed fact line
                // under the capsules — same shape on every row.
                val factLine = uniformFactLine(facts)
                if (factLine.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = factLine,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                facts.providerLine?.let { provider ->
                    Spacer(Modifier.height(5.dp))
                    Text(
                        text = provider,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                // Fallback: no parseable facts -> raw title, as before;
                // the download capsule still rides under it when present.
                Text(
                    text = display.headline,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    lineHeight = 19.sp
                )
                if (downloadTrailing != null || pickBadge != null) {
                    Spacer(Modifier.height(6.dp))
                    StreamFactCapsules(facts, capsuleConfig, trailing = downloadTrailing, extra = pickBadge)
                }
            }
            if (unresolvedTorrent) {
                Text("Torrent source · cached debrid link required", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            if (!unresolvedTorrent && com.pulsestream.app.data.isUnseekableStreamUrl(stream.url)) {
                Text("Seeking not supported by this host", style = MaterialTheme.typography.labelSmall, color = Color(0xFFF59E0B))
            }
            // The "Playing" state stays as PLAIN TEXT only — no chip
            // background/border, no decoration on stream rows.
            if (selected) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Playing",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = palette.accent
                )
            }
        }
        // No trailing button column (v0.14.14): tapping the card plays
        // it, and the download action rides in the badge row above.
    }
    }
}

// ---------------------------------------------------------------------------
// Smart Picks presentation (owner's pick 2026-11-02, v0.14.38): no box —
// qualifying rows carry the ★ RECOMMENDED badge in their badge row
// (see SmartPickBadge / recommendedStreamUrls above; since v0.14.14
// the tag set is computed per list, capped at 4). Autoplay still
// prefers picks (see preferSmartPicksWithinQuality in the ordering
// section).
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// List-level rendering: container adapts to the chosen style
// ---------------------------------------------------------------------------

/**
 * LazyColumn keys for stream rows (v0.14.17 lag fix, audit cause 2):
 * the old "${index}_${url}" key shifted for EVERY row whenever a
 * progressive emission inserted a stream, so Compose discarded and
 * re-created cards en masse mid-scroll. Keys are now derived from
 * the stream itself; only true duplicates (same URL + infoHash)
 * get an occurrence suffix, which insertions elsewhere never move.
 */
private fun streamListKeys(streams: List<StreamItem>): List<String> {
    val seen = HashMap<String, Int>()
    return streams.map { s ->
        val base = s.url + "|" + (s.infoHash ?: "")
        val n = seen.getOrDefault(base, 0)
        seen[base] = n + 1
        if (n == 0) base else "$base#$n"
    }
}

/**
 * Stream list: one clean layout — title/filename rows only.
 */
@Composable
fun StreamList(
    streams: List<StreamItem>,
    onPick: (StreamItem) -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    selectedUrl: String? = null,
    onDownload: ((StreamItem) -> Unit)? = null,
    compact: Boolean = false,
    showSizeBadge: Boolean = false,
    sizeBadgeTop: Boolean = false,
    capsuleConfig: StreamCapsuleConfig = StreamCapsuleConfig()
) {
    val keys = remember(streams) { streamListKeys(streams) }
    // ★ RECOMMENDED tags for this list (v0.14.14, item 5).
    val recommendedUrls = remember(streams) { recommendedStreamUrls(streams) }
    LazyColumn(
        modifier = modifier,
        contentPadding = contentPadding
    ) {
        if (streams.firstOrNull()?.let {
                com.pulsestream.app.data.debrid.DebridSupport.isResolved(it)
            } == true
        ) {
            item(key = "instant_play_header") { InstantPlayHeader(streams) }
        }
        itemsIndexed(streams, key = { index, _ -> keys[index] }) { _, stream ->
            StreamCard(
                stream = stream,
                selected = stream.url == selectedUrl,
                onClick = { onPick(stream) },
                onDownload = onDownload,
                compact = compact,
                showSizeBadge = showSizeBadge,
                sizeBadgeTop = sizeBadgeTop,
                capsuleConfig = capsuleConfig,
                recommended = stream.url in recommendedUrls
            )
        }
    }
}

/**
 * LazyListScope variant for stream sections nested inside another LazyColumn
 * (e.g. the detail screen's inline sources).
 */
fun LazyListScope.streamListItems(
    streams: List<StreamItem>,
    onPick: (StreamItem) -> Unit,
    selectedUrl: String? = null,
    onDownload: ((StreamItem) -> Unit)? = null,
    compact: Boolean = false,
    showSizeBadge: Boolean = false,
    sizeBadgeTop: Boolean = false,
    capsuleConfig: StreamCapsuleConfig = StreamCapsuleConfig()
) {
    val keys = streamListKeys(streams)
    // ★ RECOMMENDED tags for this section (v0.14.14, item 5). No
    // remember here — LazyListScope content is not a composable
    // receiver; the computation is a cheap filter/sort.
    val recommendedUrls = recommendedStreamUrls(streams)
    if (streams.firstOrNull()?.let {
            com.pulsestream.app.data.debrid.DebridSupport.isResolved(it)
        } == true
    ) {
        item(key = "instant_play_header") { InstantPlayHeader(streams) }
    }
    itemsIndexed(streams, key = { index, _ -> keys[index] }) { _, stream ->
        StreamCard(
            stream = stream,
            selected = stream.url == selectedUrl,
            onClick = { onPick(stream) },
            onDownload = onDownload,
            compact = compact,
            showSizeBadge = showSizeBadge,
            sizeBadgeTop = sizeBadgeTop,
            capsuleConfig = capsuleConfig,
            recommended = stream.url in recommendedUrls
        )
    }
}
