package com.pulsestream.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Settings → Advanced (v0.14.39 rebuild): the single home of the
 * two privacy toggles that used to sit loose on the Settings root —
 * Anonymous usage counting and Crash reports (audit map §4:
 * ADVANCED card). Nothing else lives here; reduced motion is NOT
 * here (its single home is Appearance's Animations chips, D2).
 */
@Composable
fun AdvancedSettingsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val settings = repository.settings
    var telemetryEnabled by remember {
        mutableStateOf(com.pulsestream.app.data.AppStats.enabled(context))
    }
    var sentryEnabled by remember { mutableStateOf(settings.sentryEnabled) }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Advanced",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Usage counting and crash reports.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }
            item(key = "advanced_toggles") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Info,
                            title = "Usage counting",
                            subtitle = "Count installs and active users — a random ID only, no personal data",
                            checked = telemetryEnabled,
                            onCheckedChange = {
                                com.pulsestream.app.data.AppStats.setEnabled(context, it)
                                telemetryEnabled = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.BugReport,
                            title = "Crash reports",
                            subtitle = "Send an anonymous report when the app crashes, so bugs get fixed",
                            checked = sentryEnabled,
                            onCheckedChange = {
                                settings.sentryEnabled = it
                                com.pulsestream.app.data.CrashReports.apply(context, it)
                                sentryEnabled = it
                            }
                        )
                    }
                )
            }
        }
    }
}
