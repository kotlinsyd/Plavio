package com.pulsestream.app.data

import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.PlaybackState
import com.pulsestream.app.data.db.TitleStatusItem
import com.pulsestream.app.data.db.WatchlistItem
import com.pulsestream.app.data.db.WatchedRecord
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.data.trakt.TraktManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Keeps the in-app library (the watchlist) in sync with the user's Trakt
 * watchlist and Simkl library — GitHub issue #3 ("manageable library").
 *
 * Three-way merge against the key set stored after the last successful
 * sync (SettingsStore.librarySyncedKeys, keys are "type|imdbId"):
 *  - a title present anywhere ends up everywhere (local + both services);
 *  - a title that was synced before but is now gone from the local
 *    library, or gone from every linked service, is removed everywhere —
 *    that's how "delete it in Plavio" (or on Trakt/Simkl) propagates.
 * Adding a title to a service is also how it gets tracked there: Trakt
 * watchlist, Simkl "Plan to Watch".
 *
 * Only IMDb-keyed movies/series take part. Anything else in the local
 * library is left completely alone. A linked service that fails to answer
 * aborts the whole sync untouched — a hiccup can never delete anything.
 */
class LibrarySyncManager(
    private val db: AppDatabase,
    private val settings: SettingsStore
) {
    private val traktApi = TraktApi()
    private val traktManager = TraktManager(settings)
    private val simklApi = SimklApi()
    private val simklManager = SimklManager(settings)

    fun isLinked(): Boolean =
        !settings.traktAccessToken.isNullOrBlank() || !settings.simklToken.isNullOrBlank()

    data class SyncOutcome(val text: String)

    private data class RemoteTitle(val title: String, val source: String)

    /**
     * P2 (v0.14.22): the 6 h gate timestamp is stamped ONLY on a
     * completed sync ([completed] = true) — a failed or partial run no
     * longer consumes its window, so the next launch retries instead of
     * waiting out 6 h on a failure.
     */
    private fun finish(text: String, completed: Boolean = false): SyncOutcome {
        if (completed) settings.librarySyncLastAt = System.currentTimeMillis()
        settings.librarySyncLastResult = text
        return SyncOutcome(text)
    }

    suspend fun sync(): SyncOutcome = withContext(Dispatchers.IO) {

        val traktToken =
            if (!settings.traktAccessToken.isNullOrBlank()) traktManager.validAccessToken() else null
        // Proactively refreshed when the stored token is near its
        // 7-day expiry (v0.14.13), mirroring the Trakt token above.
        val simklToken =
            if (!settings.simklToken.isNullOrBlank()) simklManager.validAccessToken() else null
        if (traktToken == null && simklToken == null) {
            return@withContext finish("Link Trakt or Simkl to sync your library")
        }

        // Local library, IMDb-keyed movies/series only.
        val local = LinkedHashMap<String, WatchlistItem>()
        for (item in db.watchlistDao().getAll()) {
            if ((item.type == "movie" || item.type == "series") && item.metaId.startsWith("tt")) {
                local.putIfAbsent("${item.type}|${item.metaId}", item)
            }
        }

        // Remotes (P2, v0.14.22): each service is fetched INDEPENDENTLY.
        // One service failing no longer starves the other: the healthy
        // service still syncs, but the run becomes adds-only (deletions
        // are skipped entirely) so a hiccup can still never delete
        // anything. Only when EVERY linked service fails does the sync
        // abort untouched, as before.
        var traktFailed = false
        val traktRemote: Map<String, RemoteTitle>? = if (traktToken != null) {
            val fetched = runCatching { traktApi.getWatchlist(traktToken) }.getOrNull()
                // v0.14.19: the merge store is IMDb-keyed — reads now
                // also return tmdb/trakt-keyed entries (display-only);
                // they never enter the merge.
                ?.filter { it.imdbId.startsWith("tt") }
                ?.associate { "${it.type}|${it.imdbId}" to RemoteTitle(it.title, "trakt") }
            if (fetched == null) traktFailed = true
            fetched
        } else null
        var simklFailed = false
        val simklRemote: Map<String, RemoteTitle>? = if (simklToken != null) {
            val fetched = runCatching { simklApi.getAllItems(simklToken) }.getOrNull()
                ?.filter { it.imdbId.startsWith("tt") }
                ?.associate { "${it.type}|${it.imdbId}" to RemoteTitle(it.title, "simkl") }
            if (fetched == null) simklFailed = true
            fetched
        } else null
        if (traktFailed && simklFailed) {
            return@withContext finish("Sync failed — neither service answered. Nothing changed.")
        }
        val partialFailure = traktFailed || simklFailed

        val remotes = listOfNotNull(traktRemote, simklRemote)
        val remoteUnion = remotes.fold(emptySet<String>()) { acc, m -> acc + m.keys }
        val titles = HashMap<String, RemoteTitle>()
        remotes.forEach { titles.putAll(it) }

        val base = settings.librarySyncedKeys
        // Adds-only under a partial failure: with one service's view
        // missing, absence proves nothing, so nothing is deleted.
        val deleted = if (partialFailure) emptySet() else
            base.filter { key -> key !in local.keys || key !in remoteUnion }.toSet()
        val desired = (local.keys + remoteUnion) - deleted

        // Local writes.
        var addedLocal = 0
        for (key in desired - local.keys) {
            val remote = titles[key] ?: continue
            val (type, imdb) = key.split("|", limit = 2)
            db.watchlistDao().upsert(
                WatchlistItem(
                    key = "${remote.source}|$type|$imdb",
                    addonId = remote.source,
                    type = type,
                    metaId = imdb,
                    name = remote.title.ifBlank { imdb },
                    poster = null,
                    addedAt = System.currentTimeMillis()
                )
            )
            addedLocal++
        }
        var removedLocal = 0
        for (key in local.keys - desired) {
            local[key]?.let { db.watchlistDao().deleteByKey(it.key) }
            removedLocal++
        }

        // Simkl status pull-apply (owner's ask, 2026-10-27): the
        // merge above only carries plan-to-watch / watching into the
        // watchlist. A status set on Simkl itself — completed, on
        // hold, dropped, watching — must also SHOW in Plavio, the
        // same way it does when he connects Simkl in other apps.
        // Apply Simkl's full status list to the local Plavio status
        // store (rows owned by this sync carry addonId "simkl"), and
        // a completed movie earns the local watched mark, so the
        // WATCHED pill follows. Local-first safety: a status the
        // user set inside Plavio (a row owned by any other addon id)
        // is never overwritten, and nothing is ever deleted here —
        // absence from Simkl's list is not a deletion signal.
        // Best-effort: a failure here never aborts the sync.
        if (simklToken != null && simklRemote != null) {
            runCatching {
                val all = simklApi.getAllItemsWithStatus(simklToken)
                val localByTitle = db.titleStatusDao().getAll()
                    .groupBy { "${it.type}|${it.metaId}" }
                for (entry in all) {
                    // IMDb-keyed store — non-tt entries are display-only (v0.14.19).
                    if (!entry.imdbId.startsWith("tt")) continue
                    val mapped = when (entry.status) {
                        SimklApi.Statuses.WATCHING -> PlavioStatuses.WATCHING
                        SimklApi.Statuses.HOLD -> PlavioStatuses.HOLD
                        SimklApi.Statuses.COMPLETED -> PlavioStatuses.COMPLETED
                        SimklApi.Statuses.DROPPED -> PlavioStatuses.DROPPED
                        else -> null // plantowatch rides the watchlist merge above
                    } ?: continue
                    val existing = localByTitle["${entry.type}|${entry.imdbId}"].orEmpty()
                    if (existing.any { it.addonId != "simkl" }) continue
                    val key = "simkl|${entry.type}|${entry.imdbId}"
                    val current = existing.firstOrNull { it.key == key }
                    if (current?.status != mapped) {
                        db.titleStatusDao().upsert(
                            TitleStatusItem(
                                key = key,
                                addonId = "simkl",
                                type = entry.type,
                                metaId = entry.imdbId,
                                name = current?.name ?: entry.title.ifBlank { entry.imdbId },
                                poster = current?.poster,
                                status = mapped,
                                updatedAt = System.currentTimeMillis(),
                                logo = current?.logo
                            )
                        )
                    }
                    if (entry.status == SimklApi.Statuses.COMPLETED && entry.type == "movie") {
                        db.watchedDao().upsert(
                            WatchedRecord(
                                WatchedMarks.movieKey(entry.imdbId),
                                System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        }

        // Continue Watching import (owner's ask, 2026-10-27 —
        // notes item 13): progress used to flow only OUT of Plavio
        // (his MobLand watched here appeared in Nuvio, but what he
        // watched in Nuvio never came back). Import paused progress
        // from Trakt (exact positions) and in-progress shows from
        // Simkl (episode level) into the local Continue Watching
        // store. Strictly additive and local-first: an existing
        // local row always wins, watched/finished titles are
        // skipped, and entries the user removed by hand are not
        // resurrected by older progress. Best-effort — a failure
        // here never aborts the sync.
        runCatching { importContinueWatching(traktToken, simklToken) }

        // Service writes.
        var pushFailed = false
        if (traktToken != null && traktRemote != null) {
            val adds = (desired - traktRemote.keys).map { key ->
                val (type, imdb) = key.split("|", limit = 2)
                TraktApi.WatchlistEntry(type, imdb, titles[key]?.title ?: local[key]?.name ?: "")
            }
            val removes = (traktRemote.keys - desired).map { key ->
                val (type, imdb) = key.split("|", limit = 2)
                TraktApi.WatchlistEntry(type, imdb, "")
            }
            if (!traktApi.addToWatchlist(traktToken, adds)) pushFailed = true
            if (!traktApi.removeFromWatchlist(traktToken, removes)) pushFailed = true
        }
        if (simklToken != null && simklRemote != null) {
            val adds = (desired - simklRemote.keys).map { key ->
                val (type, imdb) = key.split("|", limit = 2)
                SimklApi.ListEntry(type, imdb, titles[key]?.title ?: local[key]?.name ?: "")
            }
            val removes = (simklRemote.keys - desired).map { key ->
                val (type, imdb) = key.split("|", limit = 2)
                SimklApi.ListEntry(type, imdb, "")
            }
            if (!simklApi.addToList(simklToken, adds)) pushFailed = true
            if (!simklApi.removeFromList(simklToken, removes)) pushFailed = true
        }

        if (pushFailed) {
            // Keep the old merge base: the next sync re-derives the same
            // changes and retries the failed pushes.
            return@withContext finish("Synced here — a service update failed, will retry.")
        }

        if (!partialFailure) settings.librarySyncedKeys = desired
        val services = listOfNotNull(
            if (traktRemote != null) "Trakt" else null,
            if (simklRemote != null) "Simkl" else null
        ).joinToString(" + ")
        finish(
            "Synced with $services · ${desired.size} titles" +
                (if (addedLocal > 0) " · $addedLocal added here" else "") +
                (if (partialFailure) " · one service didn't answer — adds only, will retry" else ""),
            completed = !partialFailure
        )
    }

    // ---- Continue Watching import (notes item 13) ----

    private val stremioApi = StremioApi()

    /**
     * The Continue Watching identity, mirroring
     * StreamRepository.playbackIdentity. MUST stay formula-identical
     * to StreamRepository.playbackIdentity
     * (canonical tt keying, 2026-11-02): import-vs-local dedupe,
     * stale-import pruning and dismissal keys all share that key
     * space, so a title played in Plavio and also reported by
     * Trakt/Simkl collapses to the local row under either formula.
     */
    private fun cwIdentity(season: Int, episode: Int, imdbId: String?, videoId: String): String {
        val ttId = imdbId?.takeIf { it.startsWith("tt") }
        return when {
            (season > 0 || episode > 0) && ttId != null ->
                "ep|$ttId|$season|$episode"
            ttId != null -> "tt|$ttId"
            else -> "id|$videoId"
        }
    }

    private fun cwIdentityOf(row: PlaybackState): String =
        cwIdentity(row.season, row.episode, row.imdbId, row.videoId)

    /** First meta any installed meta addon gives for a title; prefers one with videos when asked. */
    private suspend fun metaFromAddons(type: String, id: String, needVideos: Boolean): MetaDetail? {
        val addons = runCatching { db.addonDao().getAll() }.getOrDefault(emptyList())
            .filter { it.enabled && "meta" in it.resourceSet }
        var first: MetaDetail? = null
        for (addon in addons) {
            val meta = withTimeoutOrNull(10_000) {
                runCatching { stremioApi.fetchMeta(addon.baseUrl, type, id) }.getOrNull()
            } ?: continue
            if (first == null) first = meta
            if (!needVideos || meta.videos.isNotEmpty()) return meta
        }
        return first
    }

    /** "142 min" / "1h 45m" / "2h" → minutes, or null when unparseable. */
    private fun runtimeMinutes(runtime: String?): Long? {
        if (runtime.isNullOrBlank()) return null
        val nums = Regex("\\d+").findAll(runtime).map { it.value.toLong() }.toList()
        if (nums.isEmpty()) return null
        val hasHours = runtime.contains('h', ignoreCase = true)
        return when {
            hasHours && nums.size >= 2 -> nums[0] * 60 + nums[1]
            hasHours -> nums[0] * 60
            else -> nums[0]
        }
    }

    private suspend fun importContinueWatching(traktToken: String?, simklToken: String?) {
        val now = System.currentTimeMillis()
        val existing = db.playbackDao().getAll()
        val localIdentities = existing.filter { it.importSource == null }
            .map { cwIdentityOf(it) }.toSet()
        val watchedKeys = db.watchedDao().getAll().map { it.key }.toSet()
        val dismissed = settings.cwDismissedIdentities
        val rows = mutableListOf<PlaybackState>()
        // Identities each source CURRENTLY reports in progress —
        // used to prune that source's stale imports below. Null =
        // the fetch failed, prune nothing for that source.
        var traktLiveIds: Set<String>? = null
        var simklLiveIds: Set<String>? = null

        if (traktToken != null) {
            val entries = runCatching { traktApi.getPlaybackProgress(traktToken) }.getOrNull()
            if (entries != null) {
                traktLiveIds = entries.map {
                    val videoId = if (it.type == "movie") it.imdbId
                        else "${it.imdbId}:${it.season}:${it.episode}"
                    cwIdentity(it.season, it.episode, it.imdbId, videoId)
                }.toSet()
                for (e in entries.sortedByDescending { it.pausedAtMs }.take(20)) {
                    // Effectively finished or barely started — the
                    // same spirit as the local save rules.
                    if (e.progressPct >= 90 || e.progressPct < 1) continue
                    val videoId = if (e.type == "movie") e.imdbId
                        else "${e.imdbId}:${e.season}:${e.episode}"
                    val identity = cwIdentity(e.season, e.episode, e.imdbId, videoId)
                    if (identity in localIdentities) continue // local play wins
                    val watchedKey = if (e.type == "movie") {
                        WatchedMarks.movieKey(e.imdbId)
                    } else {
                        WatchedMarks.episodeKey(e.imdbId, e.season, e.episode)
                    }
                    if (watchedKey in watchedKeys) continue // already finished here
                    val dismissedAt = dismissed[identity]
                    if (dismissedAt != null && e.pausedAtMs <= dismissedAt) continue
                    val meta = metaFromAddons(e.type, e.imdbId, needVideos = false)
                    val durationMs = runtimeMinutes(meta?.runtime)?.let { it * 60_000L } ?: 0L
                    rows += PlaybackState(
                        key = "import|trakt|$videoId",
                        title = if (e.type == "movie") {
                            e.title.ifBlank { meta?.name ?: e.imdbId }
                        } else {
                            "${e.title} S${e.season}E${e.episode}"
                        },
                        poster = meta?.poster,
                        videoId = videoId,
                        streamUrl = "",
                        positionMs = if (durationMs > 0) durationMs * e.progressPct / 100 else 0L,
                        durationMs = durationMs,
                        imdbId = e.imdbId,
                        season = e.season,
                        episode = e.episode,
                        seriesName = if (e.type == "series") e.title else null,
                        episodeTitle = e.episodeTitle,
                        metaId = e.imdbId,
                        logo = meta?.logo,
                        updatedAt = if (e.pausedAtMs > 0) e.pausedAtMs else now,
                        episodeIdsJson = if (e.type == "series") {
                            encodeEpisodeIds(meta?.videos.orEmpty())
                        } else null,
                        remoteProgressPct = if (durationMs > 0) null else e.progressPct,
                        importSource = "trakt"
                    )
                }
            }
        }

        if (simklToken != null) {
            val watching = runCatching { simklApi.getWatching(simklToken) }.getOrNull()
            if (watching != null) {
                val live = mutableSetOf<String>()
                for (e in watching.sortedByDescending { it.lastWatchedAt ?: "" }.take(10)) {
                    val watchedCount = e.watchedEpisodes ?: continue
                    if (watchedCount <= 0) continue
                    if (e.totalEpisodes != null && watchedCount >= e.totalEpisodes) continue
                    // Simkl tracks watched EPISODES, not positions:
                    // the resume target is the next unwatched one,
                    // which needs the series' episode list.
                    val meta = metaFromAddons("series", e.imdbId, needVideos = true) ?: continue
                    val videos = meta.videos
                        .filter { it.season > 0 }
                        .sortedWith(compareBy({ it.season }, { it.episode }))
                    val next = videos.getOrNull(watchedCount) ?: continue
                    val identity = cwIdentity(next.season, next.episode, e.imdbId, next.id)
                    live += identity
                    if (identity in localIdentities) continue
                    if (WatchedMarks.episodeKey(e.imdbId, next.season, next.episode) in watchedKeys) {
                        continue
                    }
                    val lastMs = e.lastWatchedAt?.let {
                        runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrNull()
                    } ?: 0L
                    val dismissedAt = dismissed[identity]
                    if (dismissedAt != null && lastMs <= dismissedAt) continue
                    rows += PlaybackState(
                        key = "import|simkl|${next.id}",
                        title = "${e.title.ifBlank { meta.name }} S${next.season}E${next.episode}",
                        poster = next.thumbnail ?: meta.poster,
                        videoId = next.id,
                        streamUrl = "",
                        positionMs = 0L,
                        durationMs = 0L,
                        imdbId = e.imdbId,
                        season = next.season,
                        episode = next.episode,
                        seriesName = e.title.ifBlank { meta.name },
                        episodeTitle = next.title,
                        metaId = e.imdbId,
                        logo = meta.logo,
                        updatedAt = if (lastMs > 0) lastMs else now,
                        episodeIdsJson = encodeEpisodeIds(meta.videos),
                        remoteProgressPct = null,
                        importSource = "simkl"
                    )
                }
                simklLiveIds = live
            }
        }

        for (row in rows.take(20)) {
            db.playbackDao().upsert(row)
        }
        // Prune imports the source no longer reports in progress
        // (finished or removed over there). Local rows are never
        // touched — only rows this import itself created.
        val fresh = db.playbackDao().getAll()
        for (row in fresh) {
            val liveIds = when (row.importSource) {
                "trakt" -> traktLiveIds
                "simkl" -> simklLiveIds
                else -> null
            } ?: continue
            if (cwIdentityOf(row) !in liveIds) {
                db.playbackDao().deleteByKey(row.key)
            }
        }
    }
}
