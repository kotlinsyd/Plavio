package com.pulsestream.app.data

import com.pulsestream.app.data.db.InstalledAddon
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/**
 * Addon identity (v0.14.36, defect 2): when is an incoming addon
 * "the same addon" as an installed one?
 *
 * Identity = manifest id + base ORIGIN, normalised. The URL's path
 * and query are configuration spellings, not identity: the same
 * addon legitimately arrives as a plain host URL, a /u/<code>/
 * permanent link, a /c/<token>/ link, a urlencoded-config URL, or
 * with a trailing slash / http instead of https — all one addon,
 * one installed row, updated in place.
 *
 * Before this, [StreamRepository.addAddonFromUrl] matched on the
 * manifest id alone and silently replaced the row (a bare URL could
 * clobber a configured one with no word to the user), the bundle
 * import deduped on the raw normalised URL string (so a respelled
 * URL sailed past its skip check), and the installed list had no
 * read-time dedupe at all. All three now share this one definition.
 *
 * Pure and side-effect free, so it is unit-tested directly.
 */
object AddonIdentity {

    /**
     * Normalised origin of an addon base URL: "https://host" or
     * "https://host:port". http and https are the same origin family
     * (a spelling variant, not a different addon); the host is
     * lowercased by the URL parser; default ports (80/443) drop out;
     * a non-default port stays part of the identity. Null when the
     * value doesn't parse as an HTTP(S) URL at all.
     */
    fun originOf(baseUrl: String): String? {
        var raw = baseUrl.trim()
        if (raw.isEmpty()) return null
        if (!raw.startsWith("http://", ignoreCase = true) &&
            !raw.startsWith("https://", ignoreCase = true)
        ) {
            raw = "https://$raw"
        }
        val url = raw.toHttpUrlOrNull() ?: return null
        val portPart = when (url.port) {
            80, 443 -> ""
            else -> ":${url.port}"
        }
        return "https://${url.host}$portPart"
    }

    /**
     * The identity key for a (manifest id, base URL) pair, or null
     * when either half is unusable. Ids compare case-insensitively:
     * manifest ids are lowercase by convention, and a case wobble
     * must not fork one addon into two rows.
     */
    fun key(manifestId: String, baseUrl: String): String? {
        val id = manifestId.trim().lowercase()
        if (id.isEmpty()) return null
        val origin = originOf(baseUrl) ?: return null
        return "$id|$origin"
    }

    /** Identity key for an installed row; unparseable URLs fall back to the bare id. */
    fun keyOf(addon: InstalledAddon): String =
        key(addon.id, addon.baseUrl) ?: "id:${addon.id.trim().lowercase()}"

    /**
     * The installed row an incoming (manifest id, base URL) refers
     * to, or null when it is genuinely new. An exact identity match
     * wins. Otherwise a row carrying the same manifest id still
     * matches: the addons table's primary key IS the manifest id, so
     * an install under that id can only ever land on that row —
     * calling it a fresh install would lie to the user while the
     * write clobbers it anyway.
     */
    fun findMatch(
        installed: List<InstalledAddon>,
        manifestId: String,
        baseUrl: String
    ): InstalledAddon? {
        val wanted = key(manifestId, baseUrl)
        if (wanted != null) {
            installed.firstOrNull { keyOf(it) == wanted }?.let { return it }
        }
        val id = manifestId.trim().lowercase()
        if (id.isEmpty()) return null
        return installed.firstOrNull { it.id.trim().lowercase() == id }
    }

    /**
     * Read-time safety net: collapse rows that share one identity,
     * keeping the FIRST in list order (the DAO serves sortOrder /
     * addedAt order, so the row the user sees on top is the one
     * that survives). Distinct identities are never merged.
     */
    fun dedupeInstalled(addons: List<InstalledAddon>): List<InstalledAddon> =
        addons.distinctBy { keyOf(it) }
}
