package com.pulsestream.app.ui.screens

/** Optional release-year bounds for search results. Unknown years match only [ANY]. */
enum class SearchYearFilter(val label: String) {
    ANY("Any year"),
    FROM_2020("2020+"),
    YEARS_2010S("2010s"),
    BEFORE_2010("Before 2010")
}

/** Optional IMDb rating threshold. Unknown ratings match only [ANY]. */
enum class SearchRatingFilter(val label: String) {
    ANY("Any rating"),
    AT_LEAST_7("7+"),
    AT_LEAST_8("8+")
}

private val releaseYearPattern = Regex("(?<!\\d)(18\\d{2}|19\\d{2}|20\\d{2}|2100)(?!\\d)")
private val ratingPattern = Regex("(?<!\\d)(\\d{1,2}(?:[.,]\\d+)?)(?!\\d)")

/** Extract a plausible four-digit year from common releaseInfo forms (year or ISO date). */
fun parseSearchReleaseYear(releaseInfo: String?): Int? {
    val raw = releaseInfo?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    return releaseYearPattern.find(raw)?.value?.toIntOrNull()
}

/** Parse a 0–10 IMDb value, allowing labels and decimal-comma metadata; invalid values are unknown. */
fun parseSearchImdbRating(imdbRating: String?): Double? {
    val raw = imdbRating?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    val value = ratingPattern.find(raw)?.groupValues?.getOrNull(1)
        ?.replace(',', '.')?.toDoubleOrNull() ?: return null
    return value.takeIf { it in 0.0..10.0 }
}

fun matchesSearchRefinement(
    releaseInfo: String?,
    imdbRating: String?,
    yearFilter: SearchYearFilter = SearchYearFilter.ANY,
    ratingFilter: SearchRatingFilter = SearchRatingFilter.ANY
): Boolean {
    val yearMatches = when (yearFilter) {
        SearchYearFilter.ANY -> true
        SearchYearFilter.FROM_2020 -> parseSearchReleaseYear(releaseInfo)?.let { it >= 2020 } ?: false
        SearchYearFilter.YEARS_2010S -> parseSearchReleaseYear(releaseInfo)?.let { it in 2010..2019 } ?: false
        SearchYearFilter.BEFORE_2010 -> parseSearchReleaseYear(releaseInfo)?.let { it < 2010 } ?: false
    }
    val ratingMatches = when (ratingFilter) {
        SearchRatingFilter.ANY -> true
        SearchRatingFilter.AT_LEAST_7 -> parseSearchImdbRating(imdbRating)?.let { it >= 7.0 } ?: false
        SearchRatingFilter.AT_LEAST_8 -> parseSearchImdbRating(imdbRating)?.let { it >= 8.0 } ?: false
    }
    return yearMatches && ratingMatches
}

/** Filter arbitrary result wrappers without changing their order or requiring UI/framework dependencies. */
fun <T> filterSearchRefinements(
    items: List<T>,
    yearFilter: SearchYearFilter = SearchYearFilter.ANY,
    ratingFilter: SearchRatingFilter = SearchRatingFilter.ANY,
    releaseInfo: (T) -> String?,
    imdbRating: (T) -> String?
): List<T> = items.filter {
    matchesSearchRefinement(releaseInfo(it), imdbRating(it), yearFilter, ratingFilter)
}

/**
 * One grouped-results shelf (v0.14.35, owner's approved sample
 * 2026-11-09): search results land on a Movies shelf and a Series
 * shelf instead of one mixed grid. [title] is the header the shelf
 * renders under.
 */
enum class SearchResultShelf(val title: String) {
    MOVIES("Movies"),
    SERIES("Series")
}

/**
 * Which shelf a result belongs on, from its addon type. "series"
 * and "tv" are the episode-bearing types in practice (Stremio's
 * series type is "series"; addons also publish shows as "tv", and
 * the app normalises raw "tv" to series elsewhere — MdbListApi).
 * MetaPreview carries no episode list, so type is the only
 * episode-bearing signal at this layer: every other value —
 * "movie", unknown/custom types, blank, null — folds onto the
 * Movies shelf. Case/whitespace-insensitive.
 */
fun searchResultShelf(type: String?): SearchResultShelf =
    when (type?.trim()?.lowercase()) {
        "series", "tv" -> SearchResultShelf.SERIES
        else -> SearchResultShelf.MOVIES
    }

/**
 * Split results into their shelves for the grouped results view:
 * a stable partition — each shelf keeps the results' existing
 * ranking order, filtered by shelf — Movies first, then Series.
 * A shelf with no results is omitted entirely (no header, no
 * empty shelf renders). No item is dropped: every input item
 * lands on exactly one shelf.
 */
fun <T> groupSearchResults(
    items: List<T>,
    type: (T) -> String?
): List<Pair<SearchResultShelf, List<T>>> {
    if (items.isEmpty()) return emptyList()
    val movies = ArrayList<T>()
    val series = ArrayList<T>()
    for (item in items) {
        when (searchResultShelf(type(item))) {
            SearchResultShelf.MOVIES -> movies.add(item)
            SearchResultShelf.SERIES -> series.add(item)
        }
    }
    return listOfNotNull(
        movies.takeIf { it.isNotEmpty() }?.let { SearchResultShelf.MOVIES to it },
        series.takeIf { it.isNotEmpty() }?.let { SearchResultShelf.SERIES to it }
    )
}
