package com.pulsestream.app.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.pulsestream.app.data.StreamRepository

/**
 * Home Switch row (v0.14.29 — owner's fold order, restated
 * 2026-11-07 and 2026-11-09): inside Addons & Integrations this
 * is ONE folded row — icon, "Home Switch", the current pick,
 * chevron — and tapping it NAVIGATES to the Home Switch page.
 * The options themselves live only on that page (HomeSwitchScreen);
 * nothing expands in place here, and there are no doubles.
 *
 * (History: v0.14.26 folded the switches inside this row, expanded
 * in place; the owner superseded that twice — a tap opens the
 * dedicated page.)
 */
@Composable
fun HomeSwitchSection(
    repository: StreamRepository,
    onNavigate: () -> Unit = {}
) {
    var homeChoices by remember {
        mutableStateOf<List<StreamRepository.HomeCatalogChoice>>(emptyList())
    }
    var homeProviderId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        homeChoices = runCatching { repository.homeCatalogChoices() }
            .getOrDefault(emptyList())
        homeProviderId = runCatching { repository.homeMetaProviderId() }
            .getOrNull()
    }
    val currentName = homeChoices.firstOrNull { it.addonId == homeProviderId }?.addonName
    SettingsGroup(
        {
            SettingsNavRow(
                icon = Icons.Filled.Home,
                title = "Home Switch",
                subtitle = currentName?.let { "Home provider: $it" }
                    ?: "Choose which addon fills Home",
                onClick = onNavigate
            )
        }
    )
}
