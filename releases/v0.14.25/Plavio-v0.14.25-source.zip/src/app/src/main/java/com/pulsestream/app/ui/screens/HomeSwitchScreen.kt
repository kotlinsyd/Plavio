package com.pulsestream.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Home Switch page (v0.14.29 — owner's fold order, restated
 * 2026-11-07 and 2026-11-09): the Addons & Integrations card's
 * "Home Switch" row NAVIGATES here; the home-source options live
 * on this page ONLY (no doubles — the in-card expansion of
 * v0.14.26/v0.14.27 is gone). The options and their behaviour are
 * unchanged from the folded section they replace:
 *
 * Each option is a catalog addon with an on/off switch. Turning
 * one ON makes it the home catalog provider (the same stored pick
 * the hold-Home picker writes); turning the active one OFF clears
 * the pick, so Home falls back to the default provider instead of
 * an empty screen. One setting, one home.
 */
@Composable
fun HomeSwitchScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    var homeChoices by remember {
        mutableStateOf<List<StreamRepository.HomeCatalogChoice>>(emptyList())
    }
    var homeProviderId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        homeChoices = runCatching { repository.homeCatalogChoices() }
            .getOrDefault(emptyList())
        homeProviderId = runCatching { repository.homeMetaProviderId() }
            .getOrNull()
    }

    fun applyPick(choice: StreamRepository.HomeCatalogChoice, wantOn: Boolean) {
        repository.settings.homeMetaProviderAddonId =
            if (wantOn) choice.addonId else null
        homeProviderId = if (wantOn) {
            choice.addonId
        } else {
            homeChoices.firstOrNull { it.addonId != choice.addonId }?.addonId
        }
        HomeCatalogSignal.requestReload()
    }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Home Switch",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Text(
                        "The addon switched on here fills your Home screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 52.dp, top = 2.dp)
                    )
                }
            }
            item(key = "options") {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    if (homeChoices.isEmpty()) {
                        Text(
                            "No catalog addons yet — install one from Manage addons and it will appear here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        homeChoices.forEach { choice ->
                            val isOn = choice.addonId == homeProviderId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { applyPick(choice, !isOn) }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        choice.addonName,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isOn) TextPrimary else TextSecondary
                                    )
                                    Text(
                                        "${choice.catalogs.size} catalogs" +
                                            if (isOn) " · Home provider" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                Switch(
                                    checked = isOn,
                                    onCheckedChange = { wantOn ->
                                        applyPick(choice, wantOn)
                                    },
                                    colors = settingsSwitchColors()
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
