package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.MetaDetail
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.Video
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Shared episode-download machinery (moved out of DetailScreen in
 * v0.14.39 so the player can use it too — the auto-download trigger
 * and "Download season" must queue an episode in EXACTLY the same
 * way: same stream pick, same engine rules).
 */

data class PlaybackIds(
    val imdbId: String?,
    val season: Int,
    val episode: Int,
    val isMovie: Boolean
)

/**
 * Cinemeta ids are IMDb ids ("tt1234567"); series episode ids look like
 * "tt1234567:1:2". Everything downstream (IntroDB, subtitle search) wants
 * the bare IMDb id plus season/episode.
 */
fun resolvePlaybackIds(meta: MetaDetail, video: Video?): PlaybackIds {
    val vid = video?.id ?: meta.id
    // v0.14.19: for TMDB-native metas the raw split yields the garbage
    // id "tmdb" — prefer the meta's real tt id when it carries one.
    val imdbId = vid.substringBefore(":").takeIf { it.startsWith("tt") }
        ?: meta.imdbId?.takeIf { it.startsWith("tt") }
        ?: meta.defaultVideoId?.takeIf { it.startsWith("tt") }
        ?: vid.substringBefore(":")
    return PlaybackIds(
        imdbId = imdbId,
        season = video?.season ?: 0,
        episode = video?.episode ?: 0,
        isMovie = meta.type == "movie"
    )
}

/**
 * The episode's streams resolved to the settled (non-provisional)
 * answer, or null when no answer lands inside the budget.
 * Extracted from [queueEpisodeDownload] in v0.14.42 so Download
 * season can resolve every episode ONCE, offer the qualities
 * those answers carry, and then queue from the same answers —
 * no second probing pass, no parallel pipeline.
 */
suspend fun resolveEpisodeStreams(
    repository: StreamRepository,
    meta: MetaDetail,
    video: Video
): com.pulsestream.app.data.StreamResult? = withTimeoutOrNull(90_000) {
    var last: com.pulsestream.app.data.StreamResult? = null
    repository.streamResultsFlow(meta.type, video.id, seedFromCache = false)
        .collect { result ->
            // A "filling" emission is provisional (PlavioHD is
            // still filling server-side): keep waiting for the
            // settled answer, like the player pool does.
            if (!result.filling || last == null) last = result
        }
    last
}

/**
 * Start one episode's download from an already-resolved answer.
 * [targetQuality] (v0.14.42) is the season-wide quality the user
 * picked in the Download season picker — the pick then goes
 * through [com.pulsestream.app.ui.components.pickStreamAtQuality]
 * (exact bucket, else step DOWN); null keeps the user's own
 * playback pick. Returns false when nothing downloadable answers.
 */
suspend fun startEpisodeDownload(
    repository: StreamRepository,
    context: android.content.Context,
    meta: MetaDetail,
    video: Video,
    settled: com.pulsestream.app.data.StreamResult,
    targetQuality: String? = null
): Boolean {
    val pick = if (targetQuality != null) {
        com.pulsestream.app.ui.components.pickStreamAtQuality(
            settled.streams, repository.settings, targetQuality
        )
    } else {
        com.pulsestream.app.ui.components.pickAutoplayStream(
            settled.streams, repository.settings
        )
    } ?: return false
    if (pick.url.startsWith("infohash:")) return false
    com.pulsestream.app.data.download.DownloadManager.get(context).startDownload(
        url = pick.url,
        title = pick.title?.takeIf { it.isNotBlank() }
            ?: pick.name?.takeIf { it.isNotBlank() }
            ?: "${meta.name} — S${video.season}E${video.episode} ${video.title}".trim(),
        headers = pick.headers,
        posterUrl = meta.poster,
        type = meta.type,
        imdbId = resolvePlaybackIds(meta, video).imdbId,
        bundledSubtitles = settled.subtitles,
        subtitleSearch = { t, i -> repository.searchSubtitles(t, i) }
    )
    return true
}

/**
 * One episode of a download queue (v0.14.38, item 7): resolve the
 * episode's streams to the settled (non-provisional) answer, pick
 * exactly the stream the user's own playback rules would pick
 * ([com.pulsestream.app.ui.components.pickAutoplayStream] — quality
 * order + size cap from Settings → Streams), and start it as an
 * individual download through the same entry point the
 * single-episode download uses, so Wi-Fi-only, storage checks and
 * the item-6 resume all apply unchanged. Episodes with no
 * downloadable stream are skipped (returns false), never fatal.
 */
suspend fun queueEpisodeDownload(
    repository: StreamRepository,
    context: android.content.Context,
    meta: MetaDetail,
    video: Video,
    targetQuality: String? = null
): Boolean {
    val settled = resolveEpisodeStreams(repository, meta, video) ?: return false
    return startEpisodeDownload(repository, context, meta, video, settled, targetQuality)
}

/**
 * Auto-download next episode (v0.14.39, owner approved 2026-11-12):
 * when an episode finishes in the player and the switch is on, the
 * NEXT episode is queued through [queueEpisodeDownload] — same
 * pick rules, same Wi-Fi-only/storage behaviour. Silent by design:
 * any failure (no meta, no episode, no stream) simply queues
 * nothing.
 */
object AutoDownloadNext {

    /** The (season, episode) entry of [meta]'s video list, or null. */
    fun findEpisode(meta: MetaDetail, season: Int, episode: Int): Video? =
        meta.videos.firstOrNull { it.season == season && it.episode == episode }

    suspend fun queue(
        repository: StreamRepository,
        context: android.content.Context,
        seriesKey: String,
        nextSeason: Int,
        nextEpisode: Int
    ): Boolean = runCatching {
        val meta = repository.getMetaFromAny(null, "series", seriesKey, requireVideos = true)
            ?: return false
        val video = findEpisode(meta, nextSeason, nextEpisode) ?: return false
        queueEpisodeDownload(repository, context, meta, video)
    }.getOrDefault(false)
}
