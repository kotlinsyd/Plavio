package com.pulsestream.app.data.cloud

import android.content.Context
import android.util.Log
import com.pulsestream.app.BuildConfig
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StreamRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Plavio account (owner's order 2026-10-25): email + password sign-in on
 * Supabase Auth, with the full app backup (the same payload the Google
 * Drive sync carries — library, progress, addons, settings and API keys)
 * stored in a per-user row guarded by row-level security.
 *
 * Email codes are used ONLY for password reset (recover -> verify OTP ->
 * set new password). Google Drive stays available as a second door.
 *
 * The feature hides itself until the backend is configured at build
 * time (PLAVIO_SUPABASE_URL / PLAVIO_SUPABASE_ANON_KEY).
 */
class PlavioAccountManager(
    context: Context,
    private val repository: StreamRepository
) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "PlavioAccount"
        private const val PREFS = "plavio_account"
        private const val KEY_ACCESS = "access_token"
        private const val KEY_REFRESH = "refresh_token"
        private const val KEY_EXPIRES = "expires_at"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_EMAIL = "email"
        private const val KEY_USERNAME = "account_username"
        private const val KEY_LAST_SYNC = "last_sync"
        /**
         * v0.14.19 sync guard: set once this install has verified the
         * cloud state — a successful restore, a verified no-cloud-row
         * check, or a user-confirmed overwrite. Until then no backup
         * path may upload (2026-10-29 incident: a fresh install's thin
         * state silently overwrote the full cloud row on auto-backup).
         * Cleared with the rest of the prefs on sign-out.
         */
        private const val KEY_RESTORE_VERIFIED = "restore_verified"
        private const val TOKEN_KEY_ALIAS = "plavio_account_token_key"

        fun isConfigured(): Boolean =
            CloudAuthErrors.configurationError(
                BuildConfig.PLAVIO_SUPABASE_URL,
                BuildConfig.PLAVIO_SUPABASE_ANON_KEY.isNotBlank()
            ) == null
    }

    fun isSignedIn(): Boolean = prefs.getString(KEY_ACCESS, null) != null &&
        prefs.getString(KEY_USER_ID, null) != null

    // ---- P18 (v0.14.22): session tokens encrypted at rest ----
    // Access/refresh tokens were plain SharedPreferences while API keys
    // got the Keystore treatment. They now ride the same AES/GCM
    // Keystore scheme (own alias); values written by older builds
    // (no "enc1:" prefix) still read back as legacy plaintext and are
    // re-encrypted on the next saveSession.
    private fun tokenKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(TOKEN_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = javax.crypto.KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
        )
        generator.init(
            KeyGenParameterSpec.Builder(
                TOKEN_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build()
        )
        return generator.generateKey()
    }

    private fun encToken(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, tokenKey())
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return "enc1:" + Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decToken(stored: String?): String? {
        if (stored == null) return null
        if (!stored.startsWith("enc1:")) return stored // legacy plaintext
        return runCatching {
            val bytes = Base64.decode(stored.removePrefix("enc1:"), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, tokenKey(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
        }.getOrNull()
    }

    private fun storedAccess(): String? = decToken(prefs.getString(KEY_ACCESS, null))
    private fun storedRefresh(): String? = decToken(prefs.getString(KEY_REFRESH, null))

    /** True when an auto-backup is due (configured + signed in + on). */
    fun autoBackupDue(): Boolean =
        isConfigured() && isSignedIn() && repository.settings.autoBackupEnabled

    fun accountEmail(): String? = prefs.getString(KEY_EMAIL, null)

    /** Username from the account profile (Supabase user_metadata), if set. */
    fun accountUsername(): String? = prefs.getString(KEY_USERNAME, null)?.takeIf { it.isNotBlank() }

    fun lastSyncTime(): String? = prefs.getLong(KEY_LAST_SYNC, 0L).takeIf { it > 0 }?.let {
        SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(it))
    }

    // ------------------------------------------------------------------
    // Auth
    // ------------------------------------------------------------------

    /** Returns true when a session was issued immediately (no email confirmation pending). */
    suspend fun signUp(
        email: String,
        password: String,
        username: String = ""
    ): Result<Boolean> = authCall {
        val body = JSONObject().put("email", email).put("password", password)
        // Account profile (owner's order 2026-10-31, corrected same
        // evening): USERNAME ONLY — no name. It rides the sign-up as
        // user_metadata; the account is email + password, the username
        // simply travels with it to every device.
        val data = JSONObject()
        sanitizeUsername(username)?.let { data.put("username", it) }
        if (data.length() > 0) body.put("data", data)
        val resp = post("/auth/v1/signup", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        val json = resp.json ?: throw AuthException("Unexpected response from the account server.")
        if (json.has("access_token")) {
            saveSession(json, email)
            true
        } else {
            false
        }
    }

    suspend fun signIn(email: String, password: String): Result<Unit> = authCall {
        val body = JSONObject().put("email", email).put("password", password)
        val resp = post("/auth/v1/token?grant_type=password", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        val json = resp.json ?: throw AuthException("Unexpected response from the account server.")
        saveSession(json, email)
    }

    /** Username shape: lowercase letters, digits, dot, underscore, dash. */
    private fun sanitizeUsername(raw: String): String? =
        raw.trim().lowercase().filter { it.isLetterOrDigit() || it in "._-" }
            .take(24).takeIf { it.isNotBlank() }

    /**
     * Best-effort profile refresh from the account server (GET
     * /auth/v1/user): keeps the local name/username in step with the
     * account when they were set on another device. Never fails the
     * caller — a profile hiccup must not touch sign-in or sync.
     */
    suspend fun refreshProfile() {
        if (!isSignedIn()) return
        runCatching {
            withFreshToken { token ->
                val resp = get("/auth/v1/user", accessToken = token)
                if (resp.code in 200..299) storeProfile(resp.json)
            }
        }
    }

    /** Sets the account's username (PUT /auth/v1/user user_metadata). */
    suspend fun updateProfile(username: String): Result<Unit> = authCall {
        val data = JSONObject()
            // Username only (owner's correction 2026-10-31); name is
            // explicitly cleared — an early test build saved one.
            .put("name", "")
            .put("username", sanitizeUsername(username) ?: "")
        val body = JSONObject().put("data", data)
        withFreshToken { token ->
            val resp = put("/auth/v1/user", body, accessToken = token)
            if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
            storeProfile(resp.json)
        }
    }

    suspend fun signOut() {
        val token = storedAccess()
        if (token != null) {
            runCatching { post("/auth/v1/logout", JSONObject(), accessToken = token) }
        }
        prefs.edit().clear().apply()
    }

    /** Sends the 6-digit reset code email. */
    suspend fun requestPasswordReset(email: String): Result<Unit> = authCall {
        val body = JSONObject().put("email", email)
        val resp = post("/auth/v1/recover", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
    }

    /** Verifies the reset code and sets the new password. Ends signed out. */
    suspend fun verifyResetAndSetPassword(email: String, code: String, newPassword: String): Result<Unit> = authCall {
        val body = JSONObject().put("email", email).put("token", code).put("type", "recovery")
        val resp = post("/auth/v1/verify", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        val json = resp.json ?: throw AuthException("Unexpected response from the account server.")
        val recoveryToken = json.optString("access_token")
            .ifBlank { throw AuthException("The reset code was not accepted.") }
        val update = JSONObject().put("password", newPassword)
        val resp2 = put("/auth/v1/user", update, accessToken = recoveryToken)
        if (resp2.code !in 200..299) throw AuthException(errorMessage(resp2.json, resp2.code))
        runCatching { post("/auth/v1/logout", JSONObject(), accessToken = recoveryToken) }
    }

    suspend fun changePassword(newPassword: String): Result<Unit> = authCall {
        withFreshToken { token ->
            val body = JSONObject().put("password", newPassword)
            val resp = put("/auth/v1/user", body, accessToken = token)
            if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        }
    }

    /**
     * Delete account (v0.14.27, batch N5 — owner's order 2026-11-07):
     * the ONLY verification is the password, re-entered in Account.
     * The flow, in order:
     * (1) the password is proven with a fresh password grant — a
     *     wrong password stops everything, nothing is deleted;
     * (2) the account's cloud backup row is deleted (the account's
     *     only server-side data);
     * (3) the account itself is deleted on the auth server
     *     (the auth service's self-delete for the signed-in user);
     * (4) this device is wiped — library database, settings + keys,
     *     search history, downloads, profile photo — and the local
     *     session is cleared.
     * If (2) lands and (3) refuses, the error says exactly that and
     * a retry finishes the job (step 2 is then a no-op delete).
     */
    suspend fun deleteAccount(password: String): Result<Unit> = authCall {
        val email = accountEmail() ?: throw AuthException("Not signed in.")
        val body = JSONObject().put("email", email).put("password", password)
        val resp = post("/auth/v1/token?grant_type=password", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        val json = resp.json ?: throw AuthException("Unexpected response from the account server.")
        val freshToken = json.optString("access_token")
            .ifBlank { throw AuthException("The password was not accepted.") }
        val uid = json.optJSONObject("user")?.optString("id")?.takeIf { it.isNotBlank() }
            ?: prefs.getString(KEY_USER_ID, null)
            ?: throw AuthException("Not signed in.")
        val delRow = delete("/rest/v1/account_backups?user_id=eq.$uid", freshToken)
        if (delRow.code !in 200..299) throw AuthException(errorMessage(delRow.json, delRow.code))
        val delUser = delete("/auth/v1/user", freshToken)
        if (delUser.code !in 200..299) {
            throw AuthException(
                "Your cloud data was deleted, but the account itself could not be removed: " +
                    errorMessage(delUser.json, delUser.code) + " Please try again."
            )
        }
        repository.wipeLocalData()
        com.pulsestream.app.data.SearchHistory.clear(appContext)
        runCatching {
            val ext = appContext.getExternalFilesDir(null)
            if (ext != null) {
                java.io.File(ext, "downloads").deleteRecursively()
                java.io.File(ext, "posters").deleteRecursively()
            }
        }
        prefs.edit().clear().apply()
    }

    // ------------------------------------------------------------------
    // Sync (same payload as the Google Drive backup)
    // ------------------------------------------------------------------

    /** Outcome of a guarded backup attempt (v0.14.19). */
    sealed class BackupOutcome {
        data object Uploaded : BackupOutcome()
        /** Local payload is emptier than the cloud row — held back pending user confirmation. */
        data object NeedsConfirmation : BackupOutcome()
        data class Failed(val message: String) : BackupOutcome()
    }

    private fun isRestoreVerified(): Boolean = prefs.getBoolean(KEY_RESTORE_VERIFIED, false)

    private fun markRestoreVerified() {
        prefs.edit().putBoolean(KEY_RESTORE_VERIFIED, true).apply()
    }

    /**
     * Rough size of a backup payload: the total number of entries
     * across its top-level sections (arrays count their items,
     * objects their keys). Only ever compared against another
     * payload's score — never shown to the user.
     */
    private fun payloadRichness(payload: String): Int = runCatching {
        val root = JSONObject(payload)
        var total = 0
        val keys = root.keys()
        while (keys.hasNext()) {
            total += when (val value = root.opt(keys.next())) {
                is org.json.JSONArray -> value.length()
                is JSONObject -> value.length()
                is String -> if (value.isBlank()) 0 else 1
                else -> 1
            }
        }
        total
    }.getOrDefault(0)

    /** The account row's current payload, or null when no row exists. */
    /** The cloud row's payload exactly as stored (null = no row yet). */
    private suspend fun fetchRawCloudPayload(token: String): String? {
        val uid = prefs.getString(KEY_USER_ID, null)
            ?: throw AuthException("Not signed in.")
        val resp = get(
            "/rest/v1/account_backups?select=payload&user_id=eq.$uid",
            accessToken = token
        )
        if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        return resp.jsonArray?.optJSONObject(0)?.optString("payload")?.takeIf { it.isNotBlank() }
    }

    private suspend fun fetchCloudPayload(token: String): String? =
        fetchRawCloudPayload(token)?.let { unwrapCloudPayload(it) }

    /**
     * SIMPLIFIED (owner's order 2026-10-31 — "make it simple, its not
     * that big data, just free keys"): backups are stored PLAIN in the
     * user's own account row; the login is the protection. Rows sealed
     * by v0.14.22–v0.14.28 builds (P18 device-key encryption) still
     * decrypt here on the device that made them; a sealed row this
     * device cannot read returns null — callers treat it as unreadable
     * (restore skips it, the guarded backup asks before replacing it)
     * instead of failing sign-in with a raw error.
     */
    private fun unwrapCloudPayload(raw: String): String? {
        if (!raw.startsWith(com.pulsestream.app.data.SettingsStore.CLOUD_ENC_PREFIX)) return raw
        return repository.settings.decryptFromCloud(raw)
    }

    private suspend fun uploadPayload(payload: String) {
        // Plain payload (owner's simplification order 2026-10-31) — no
        // client-side encryption, so any signed-in device can restore.
        val storedPayload = payload
        withFreshToken { token ->
            val uid = prefs.getString(KEY_USER_ID, null)
                ?: throw AuthException("Not signed in.")
            val body = JSONObject()
                .put("user_id", uid)
                .put("payload", storedPayload)
                .put("updated_at", isoNow())
            val resp = post(
                "/rest/v1/account_backups", body, accessToken = token,
                extraHeaders = mapOf("Prefer" to "resolution=merge-duplicates,return=minimal")
            )
            if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
        }
        prefs.edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).apply()
    }

    private suspend fun buildLocalPayload(): String {
        // The backup carries exactly the categories the user left on in
        // "What to sync" (Account & Sync) — all on by default, keys
        // included (owner's order: sign-in restores everything). The raw
        // configured addon URLs ride along so restores re-attach them.
        val categories = repository.settings.syncEnabledCategories()
        return repository.exportBackupJson(
            enabledCategories = categories,
            includePrivateAddonUrls = categories.contains("addons")
        ).getOrThrow()
    }

    /**
     * Guarded backup (v0.14.19, owner's order 2026-10-29): before
     * uploading, the existing cloud payload is fetched and compared —
     * an emptier local payload NEVER overwrites a fuller cloud row
     * without the user's confirmation ([force] after the account
     * section's confirm dialog). A verified check also arms the
     * restore-verified flag that unlocks auto-backup.
     */
    suspend fun backupNow(force: Boolean = false): BackupOutcome =
        // v0.14.20 fix: backupNow is called straight from the account
        // UI's coroutine (Main thread), and unlike its sibling entry
        // points — syncNow()/restoreFromAccount(), which ride
        // authCall's IO switch — it performed its OkHttp calls on the
        // caller's thread. The guard's first network call therefore
        // died with NetworkOnMainThreadException (whose message is
        // null, surfacing as the generic "Something went wrong") and
        // neither the upload nor the NeedsConfirmation dialog could
        // ever be reached from the Backup button. The whole guarded
        // backup now runs on IO regardless of the caller.
        withContext(Dispatchers.IO) { backupNowGuarded(force) }

    private suspend fun backupNowGuarded(force: Boolean): BackupOutcome {
        return try {
            val payload = buildLocalPayload()
            var needsConfirmation = false
            withFreshToken { token ->
                val raw = fetchRawCloudPayload(token)
                val cloud = raw?.let { unwrapCloudPayload(it) }
                when {
                    raw == null -> markRestoreVerified()
                    // A legacy sealed row this device cannot read: its
                    // richness is unknowable, so replacing it asks first
                    // (the confirm dialog) unless forced.
                    cloud == null ->
                        if (!force) needsConfirmation = true else markRestoreVerified()
                    !force && payloadRichness(payload) < payloadRichness(cloud) ->
                        needsConfirmation = true
                    else -> markRestoreVerified()
                }
            }
            if (needsConfirmation) return BackupOutcome.NeedsConfirmation
            uploadPayload(payload)
            BackupOutcome.Uploaded
        } catch (e: Exception) {
            // Keep the failure diagnosable: the user sees the message,
            // the log keeps the exception class + stack.
            Log.e(TAG, "backupNow failed", e)
            BackupOutcome.Failed(e.message ?: "Something went wrong. Please try again.")
        }
    }

    /** Uploads the current app backup into the account row (guarded — see [backupNow]). */
    suspend fun syncNow(): Result<Unit> = authCall {
        when (val outcome = backupNow()) {
            is BackupOutcome.Uploaded -> Unit
            is BackupOutcome.NeedsConfirmation -> throw AuthException(
                "This device has less saved than your cloud backup — upload held back. " +
                    "Restore first, or confirm the overwrite from the Backup button."
            )
            is BackupOutcome.Failed -> throw AuthException(outcome.message)
        }
    }

    /** True when a cloud backup existed (and was imported). */
    suspend fun restoreFromAccount(): Result<Boolean> = authCall {
        var restored = false
        withFreshToken { token ->
            val uid = prefs.getString(KEY_USER_ID, null)
                ?: throw AuthException("Not signed in.")
            val resp = get(
                "/rest/v1/account_backups?select=payload,updated_at&user_id=eq.$uid",
                accessToken = token
            )
            if (resp.code !in 200..299) throw AuthException(errorMessage(resp.json, resp.code))
            val rows = resp.jsonArray
            val rawPayload = rows?.optJSONObject(0)?.optString("payload")?.takeIf { it.isNotBlank() }
            if (rawPayload != null) {
                // An unreadable legacy sealed row is skipped, not an
                // error: sign-in still succeeds, and the guarded backup
                // path offers to replace the row (with confirmation).
                val plain = unwrapCloudPayload(rawPayload)
                if (plain != null) {
                    repository.importBackupJson(plain).getOrThrow()
                    restored = true
                }
            }
        }
        // A completed restore verifies this install against the cloud
        // state — backups may flow again from here on.
        if (restored) markRestoreVerified()
        restored
    }

    /**
     * Post-sign-in flow: restore the account backup when one exists;
     * otherwise upload the current device state as the first backup.
     */
    suspend fun syncAfterSignIn(): Result<Boolean> = authCall {
        val restored = restoreFromAccount().getOrThrow()
        if (!restored) syncNow().getOrThrow()
        restored
    }

    /**
     * Silent auto-backup (owner's order 2026-10-29): called shortly after
     * app open; uploads the current backup with no UI and no toast when
     * signed in and the Auto backup toggle (Account & Sync) is on.
     * Returns true when a backup was uploaded; any failure is swallowed
     * (false) and simply retried on the next app open.
     */
    suspend fun autoBackup(): Boolean {
        val settings = repository.settings
        if (!isConfigured() || !isSignedIn()) {
            settings.autoBackupLastState = "not-due"
            return false
        }
        if (!settings.autoBackupEnabled) {
            settings.autoBackupLastState = "not-due"
            return false
        }
        settings.autoBackupPending = true
        if (!isRestoreVerified()) {
            // v0.14.19 guard: an install that has never restored (or
            // verified the cloud state) must not auto-upload. Probe
            // the cloud row WITHOUT importing or uploading:
            //  - no cloud row → verified; this device is the source.
            //  - local at least as full as cloud → verified; upload.
            //  - cloud fuller → stay silent; the user's Restore (or a
            //    confirmed manual Backup) settles it. Retried next open.
            val local = runCatching { buildLocalPayload() }.getOrNull() ?: run {
                settings.autoBackupLastState = "failed: couldn't build the backup"
                return false
            }
            val cloud = try {
                var probed: String? = null
                var probeOk = false
                withFreshToken { token ->
                    probed = fetchCloudPayload(token)
                    probeOk = true
                }
                if (!probeOk) {
                    settings.autoBackupLastState = "failed: couldn't verify the cloud backup"
                    return false
                }
                probed
            } catch (e: Exception) {
                settings.autoBackupLastState = "failed: couldn't verify the cloud backup"
                return false
            }
            when {
                cloud == null -> markRestoreVerified()
                payloadRichness(local) >= payloadRichness(cloud) -> markRestoreVerified()
                else -> {
                    // Held by the restore-verified guard — now VISIBLE
                    // (persisted state + log), not a silent false.
                    settings.autoBackupLastState =
                        "held-by-guard: cloud backup is fuller — restore it or confirm a backup"
                    Log.i(TAG, "autoBackup held by restore-verified guard")
                    return false
                }
            }
        }
        val ok = syncNow().isSuccess
        if (ok) {
            settings.autoBackupPending = false
            settings.autoBackupLastState = "backed-up"
        } else {
            settings.autoBackupLastState = "failed: upload didn't complete"
        }
        return ok
    }

    // ------------------------------------------------------------------
    // HTTP plumbing
    // ------------------------------------------------------------------

    private class AuthException(message: String) : Exception(message)

    private data class Resp(val code: Int, val json: JSONObject?, val jsonArray: org.json.JSONArray?)

    private fun baseRequest(path: String, accessToken: String?): Request.Builder =
        Request.Builder()
            .url(BuildConfig.PLAVIO_SUPABASE_URL.trimEnd('/') + path)
            .header("apikey", BuildConfig.PLAVIO_SUPABASE_ANON_KEY)
            .header("Authorization", "Bearer ${accessToken ?: BuildConfig.PLAVIO_SUPABASE_ANON_KEY}")
            .header("Content-Type", "application/json")

    private fun execute(req: Request): Resp {
        val text = client.newCall(req).execute().use { r ->
            r.code to (r.body?.string().orEmpty())
        }
        val (code, body) = text
        val trimmed = body.trim()
        return Resp(
            code,
            runCatching { JSONObject(trimmed) }.getOrNull(),
            runCatching { org.json.JSONArray(trimmed) }.getOrNull()
        )
    }

    private fun post(path: String, body: JSONObject, accessToken: String?, extraHeaders: Map<String, String> = emptyMap()): Resp {
        val builder = baseRequest(path, accessToken)
        extraHeaders.forEach { (k, v) -> builder.header(k, v) }
        return execute(builder.post(body.toString().toRequestBody("application/json".toMediaType())).build())
    }

    private fun put(path: String, body: JSONObject, accessToken: String?): Resp =
        execute(baseRequest(path, accessToken).put(body.toString().toRequestBody("application/json".toMediaType())).build())

    private fun get(path: String, accessToken: String?): Resp =
        execute(baseRequest(path, accessToken).get().build())

    private fun delete(path: String, accessToken: String?): Resp =
        execute(baseRequest(path, accessToken).delete().build())

    private fun errorMessage(json: JSONObject?, code: Int): String {
        val raw = json?.optString("msg")?.ifBlank { null }
            ?: json?.optString("message")?.ifBlank { null }
            ?: json?.optString("error_description")?.ifBlank { null }
            ?: json?.optString("error")?.ifBlank { null }
        // Wrong credentials keep their plain wording here —
        // CloudAuthErrors deliberately hands that case back to the
        // caller's fallback.
        if (raw?.contains("Invalid login credentials", ignoreCase = true) == true) {
            return "Wrong email or password."
        }
        // Everything else goes through the safe mapper: provider
        // bodies are never echoed raw to the user, a rejected API
        // configuration is never blamed on the password, and
        // 404/429/503 get their own honest wording.
        return CloudAuthErrors.responseMessage(
            code,
            json?.toString(),
            "Account server error ($code). Please try again."
        )
    }

    private fun saveSession(json: JSONObject, email: String) {
        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        val expiresIn = json.optLong("expires_in", 3600)
        val userId = json.optJSONObject("user")?.optString("id").orEmpty()
        if (access.isBlank() || userId.isBlank()) throw AuthException("Unexpected sign-in response.")
        prefs.edit()
            .putString(KEY_ACCESS, encToken(access))
            .putString(KEY_REFRESH, encToken(refresh))
            .putLong(KEY_EXPIRES, System.currentTimeMillis() + expiresIn * 1000)
            .putString(KEY_USER_ID, userId)
            .putString(KEY_EMAIL, json.optJSONObject("user")?.optString("email")?.ifBlank { null } ?: email)
            .apply()
        storeProfile(json.optJSONObject("user"))
    }

    /** Persists name/username from a Supabase user object's user_metadata. */
    private fun storeProfile(user: JSONObject?) {
        val meta = user?.optJSONObject("user_metadata") ?: return
        val edit = prefs.edit()
        meta.optString("username").takeIf { it.isNotBlank() }?.let { edit.putString(KEY_USERNAME, it) }
        edit.apply()
    }

    /** Runs [block] with a valid access token, refreshing (and retrying once on 401). */
    private suspend fun withFreshToken(block: suspend (String) -> Unit) {
        var token = storedAccess()
            ?: throw AuthException("Not signed in.")
        val expires = prefs.getLong(KEY_EXPIRES, 0L)
        if (System.currentTimeMillis() > expires - 60_000) {
            refreshSession()
            token = storedAccess() ?: throw AuthException("Session expired.")
        }
        try {
            block(token)
        } catch (e: AuthException) {
            if (e.message?.contains("401") == true) {
                refreshSession()
                val fresh = storedAccess() ?: throw e
                block(fresh)
            } else throw e
        }
    }

    private suspend fun refreshSession() {
        val refresh = storedRefresh()
            ?: throw AuthException("Session expired. Please sign in again.")
        val body = JSONObject().put("refresh_token", refresh)
        val resp = post("/auth/v1/token?grant_type=refresh_token", body, accessToken = null)
        if (resp.code !in 200..299) throw AuthException("Session expired. Please sign in again.")
        val json = resp.json ?: throw AuthException("Session expired. Please sign in again.")
        saveSession(json, prefs.getString(KEY_EMAIL, "").orEmpty())
    }

    private fun isoNow(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }.format(Date())

    private suspend fun <T> authCall(block: suspend () -> T): Result<T> =
        withContext(Dispatchers.IO) {
            try {
                Result.success(block())
            } catch (e: AuthException) {
                Result.failure(Exception(e.message))
            } catch (e: Exception) {
                Result.failure(Exception(e.message ?: "Something went wrong. Please try again."))
            }
        }
}
