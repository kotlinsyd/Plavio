package com.pulsestream.app.data.trakt

import com.pulsestream.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/**
 * Raw HTTP client for the Trakt API (https://api.trakt.tv).
 * Uses OAuth 2.0 Authorization Code flow with PKCE (no client secret):
 * app builds an authorize URL -> user approves in the browser ->
 * our callback page shows the code -> user pastes it into the app ->
 * POST /oauth/token exchanges it for tokens.
 */
class TraktApi {

    companion object {
        const val CLIENT_ID = "2j7KBLNBFVZG5qs6afdPGxbWyb23_93tX0aopgiDGSY"
        const val REDIRECT_URI = "https://www.plavio.site/trakt-callback.html"
        private const val AUTHORIZE_URL = "https://trakt.tv/oauth/authorize"
        private const val TOKEN_URL = "https://api.trakt.tv/oauth/token"
        private const val API_BASE = "https://api.trakt.tv"
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }

    private val userAgent = "Plavio/${BuildConfig.VERSION_NAME}"

    data class Pkce(val verifier: String, val challenge: String, val state: String)

    data class Tokens(
        val accessToken: String,
        val refreshToken: String,
        val expiresInSec: Long
    )

    /**
     * The refresh grant was REJECTED by Trakt's server (HTTP
     * 400/401 — an invalid or revoked grant), as opposed to a
     * transient failure (offline, timeout, 5xx). Callers must
     * treat this as a dead link (v0.14.41): TraktManager flags
     * the link expired so the UI can say so honestly, while
     * transient failures keep the stored tokens and retry later.
     * The message matches the generic refresh failure's, so
     * existing catch-by-type behaviour is unchanged.
     */
    class RefreshRejectedException(val code: Int) :
        IllegalStateException("Trakt refresh failed (HTTP $code)")

    private val client = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Generates a PKCE verifier/challenge pair plus a state token. */
    fun newPkce(): Pkce {
        val random = SecureRandom()
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
        val verifier = buildString {
            repeat(64) { append(chars[random.nextInt(chars.length)]) }
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray())
        val challenge = base64Url(digest)
        val state = buildString {
            repeat(16) { append(chars[random.nextInt(62)]) }
        }
        return Pkce(verifier, challenge, state)
    }

    /** The URL the user opens in a browser to approve Plavio. */
    fun authorizeUrl(pkce: Pkce): String {
        val params = listOf(
            "response_type" to "code",
            "client_id" to CLIENT_ID,
            "redirect_uri" to REDIRECT_URI,
            "state" to pkce.state,
            "code_challenge" to pkce.challenge,
            "code_challenge_method" to "S256"
        ).joinToString("&") { (k, v) -> "$k=${java.net.URLEncoder.encode(v, "UTF-8")}" }
        return "$AUTHORIZE_URL?$params"
    }

    /** Exchanges the pasted authorization code for tokens. */
    suspend fun exchangeCode(code: String, verifier: String): Tokens = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("code", code.trim())
            .put("client_id", CLIENT_ID)
            .put("redirect_uri", REDIRECT_URI)
            .put("grant_type", "authorization_code")
            .put("code_verifier", verifier)
            .toString()
            .toRequestBody(JSON)
        val request = Request.Builder()
            .url(TOKEN_URL)
            .header("User-Agent", userAgent)
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("Trakt code exchange failed (HTTP ${response.code})")
            val json = JSONObject(text)
            Tokens(
                accessToken = json.getString("access_token"),
                refreshToken = json.getString("refresh_token"),
                expiresInSec = json.optLong("expires_in", 7_776_000L)
            )
        }
    }

    /** Refreshes an expired access token. */
    suspend fun refreshToken(refreshToken: String): Tokens = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("refresh_token", refreshToken)
            .put("client_id", CLIENT_ID)
            .put("redirect_uri", REDIRECT_URI)
            .put("grant_type", "refresh_token")
            .toString()
            .toRequestBody(JSON)
        val request = Request.Builder()
            .url(TOKEN_URL)
            .header("User-Agent", userAgent)
            .post(body)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                // 400 (invalid_grant) / 401: the server rejected
                // the grant itself — distinct from a transient
                // failure, and the only refresh outcome that may
                // mark the link expired.
                if (response.code == 400 || response.code == 401) {
                    throw RefreshRejectedException(response.code)
                }
                throw IllegalStateException("Trakt refresh failed (HTTP ${response.code})")
            }
            val json = JSONObject(text)
            Tokens(
                accessToken = json.getString("access_token"),
                refreshToken = json.optString("refresh_token", refreshToken),
                expiresInSec = json.optLong("expires_in", 7_776_000L)
            )
        }
    }

    /** Returns the Trakt username for the linked account, or null. */
    suspend fun getUsername(accessToken: String): String? = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$API_BASE/users/settings")
            .header("User-Agent", userAgent)
            .header("trakt-api-version", "2")
            .header("trakt-api-key", CLIENT_ID)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val text = response.body?.string().orEmpty()
            JSONObject(text).optJSONObject("user")?.optString("username")?.takeIf { it.isNotBlank() }
        }
    }

    /**
     * Sends a scrobble event (start/pause/stop).
     * Returns true on success; false on auth failure (caller should refresh/unlink).
     */
    suspend fun scrobble(accessToken: String, action: String, body: JSONObject): ScrobbleResult =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("$API_BASE/scrobble/$action")
                .header("User-Agent", userAgent)
                .header("trakt-api-version", "2")
                .header("trakt-api-key", CLIENT_ID)
                .header("Authorization", "Bearer $accessToken")
                .post(body.toString().toRequestBody(JSON))
                .build()
            try {
                client.newCall(request).execute().use { response ->
                    when {
                        response.isSuccessful -> ScrobbleResult.Ok
                        response.code == 401 -> ScrobbleResult.Unauthorized
                        else -> ScrobbleResult.Failed
                    }
                }
            } catch (_: Exception) {
                ScrobbleResult.Failed
            }
        }

    enum class ScrobbleResult { Ok, Unauthorized, Failed }

    // ---- Watchlist (library sync, issue #3) ----

    /** One Trakt watchlist entry, IMDb-keyed. [type] is "movie" or "series". */
    data class WatchlistEntry(
        val type: String,
        val imdbId: String,
        val title: String,
        // v0.14.19 (all-lists display): reads no longer drop entries
        // without an IMDb id — they carry the best id Trakt gave
        // (TMDB, else Trakt's own), so the Library displays
        // everything the service returns.
        val tmdbId: Int? = null,
        val traktId: Int = 0
    ) {
        /** Best display/navigation identity (imdb → tmdb → trakt). */
        val key: String
            get() = when {
                imdbId.startsWith("tt") -> imdbId
                tmdbId != null -> "tmdb:${if (type == "movie") "movie" else "tv"}:$tmdbId"
                traktId > 0 -> "trakt:$traktId"
                else -> imdbId
            }
    }

    /**
     * v0.14.19: builds a [WatchlistEntry] from one Trakt movie/show
     * node WITHOUT the old IMDb-only drop — the entry survives on
     * any usable id. Null only when the node carries no id at all.
     * Consumers merging into IMDb-keyed stores filter on imdbId.
     */
    private fun parseWatchlistNode(type: String, node: JSONObject): WatchlistEntry? {
        val ids = node.optJSONObject("ids")
        val imdb = ids?.optString("imdb")?.takeIf { it.startsWith("tt") }.orEmpty()
        val tmdb = ids?.optInt("tmdb", 0)?.takeIf { it > 0 }
        val trakt = ids?.optInt("trakt", 0) ?: 0
        if (imdb.isEmpty() && tmdb == null && trakt <= 0) return null
        return WatchlistEntry(type, imdb, node.optString("title"), tmdb, trakt)
    }

    /**
     * The user's Trakt watched history (movies + shows), newest
     * first, deduped by title. Throws on failure.
     */
    suspend fun getWatchedHistory(accessToken: String, limit: Int = 100): List<WatchlistEntry> {
        val out = mutableListOf<WatchlistEntry>()
        val seen = mutableSetOf<String>()
        val sections = listOf(
            Triple("movies", "movie", "movie"),
            Triple("shows", "show", "series")
        )
        for ((path, nodeName, type) in sections) {
            val (code, text) = getJson(accessToken, "/users/me/history/$path?page=1&limit=$limit")
            if (code !in 200..299) throw IllegalStateException(traktErrorMessage(code))
            val arr = org.json.JSONArray(text.ifBlank { "[]" })
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                // Episode-shaped entries still carry the show node.
                val node = item.optJSONObject(nodeName) ?: item.optJSONObject("show") ?: continue
                val entry = parseWatchlistNode(type, node) ?: continue
                if (seen.add(entry.key)) out += entry
            }
        }
        return out
    }

    private fun authed(accessToken: String): Request.Builder = Request.Builder()
        .header("User-Agent", userAgent)
        .header("trakt-api-version", "2")
        .header("trakt-api-key", CLIENT_ID)
        .header("Authorization", "Bearer $accessToken")

    /** The user's whole Trakt watchlist (movies + shows). Throws on failure. */
    suspend fun getWatchlist(accessToken: String): List<WatchlistEntry> = withContext(Dispatchers.IO) {
        val out = mutableListOf<WatchlistEntry>()
        val sections = listOf(
            Triple("movies", "movie", "movie"),
            Triple("shows", "series", "show")
        )
        for ((path, type, nodeName) in sections) {
            val request = authed(accessToken).url("$API_BASE/users/me/watchlist/$path").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("Trakt watchlist failed (HTTP ${response.code})")
                }
                val arr = org.json.JSONArray(response.body?.string().orEmpty().ifBlank { "[]" })
                for (i in 0 until arr.length()) {
                    val node = arr.optJSONObject(i)?.optJSONObject(nodeName) ?: continue
                    parseWatchlistNode(type, node)?.let { out += it }
                }
            }
        }
        out
    }

    /** Adds entries to the Trakt watchlist. Best-effort. */
    suspend fun addToWatchlist(accessToken: String, entries: List<WatchlistEntry>): Boolean =
        syncWatchlist(accessToken, "watchlist", entries)

    /**
     * The user's own rating (1–10) for one title from Trakt's
     * /sync/ratings (v0.14.40, item 11), or null when unrated.
     * Throws on HTTP failure — callers fail soft.
     */
    suspend fun getRating(accessToken: String, type: String, imdbId: String): Int? =
        withContext(Dispatchers.IO) {
            val path = if (type == "movie") "movies" else "shows"
            val nodeName = if (type == "movie") "movie" else "show"
            val request = authed(accessToken).url("$API_BASE/sync/ratings/$path").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("Trakt ratings failed (HTTP ${response.code})")
                }
                val arr = org.json.JSONArray(response.body?.string().orEmpty().ifBlank { "[]" })
                for (i in 0 until arr.length()) {
                    val entry = arr.optJSONObject(i) ?: continue
                    val node = entry.optJSONObject(nodeName) ?: continue
                    val ids = node.optJSONObject("ids") ?: continue
                    if (ids.optString("imdb") == imdbId) {
                        return@withContext entry.optInt("rating").takeIf { it in 1..10 }
                    }
                }
                null
            }
        }

    /**
     * Push the user's own rating to Trakt (POST /sync/ratings,
     * v0.14.40 item 11). Best-effort like [syncWatchlist].
     */
    suspend fun addRating(accessToken: String, type: String, imdbId: String, rating: Int): Boolean =
        withContext(Dispatchers.IO) {
            val item = JSONObject()
                .put("rating", rating.coerceIn(1, 10))
                .put("ids", JSONObject().put("imdb", imdbId))
            val body = JSONObject()
                .put(if (type == "movie") "movies" else "shows", org.json.JSONArray().put(item))
            val request = authed(accessToken).url("$API_BASE/sync/ratings")
                .post(body.toString().toRequestBody(JSON)).build()
            try {
                client.newCall(request).execute().use { it.isSuccessful }
            } catch (_: Exception) {
                false
            }
        }

    /** Removes entries from the Trakt watchlist. Best-effort. */
    suspend fun removeFromWatchlist(accessToken: String, entries: List<WatchlistEntry>): Boolean =
        syncWatchlist(accessToken, "watchlist/remove", entries)

    private suspend fun syncWatchlist(
        accessToken: String,
        path: String,
        entries: List<WatchlistEntry>
    ): Boolean = withContext(Dispatchers.IO) {
        if (entries.isEmpty()) return@withContext true
        val movies = org.json.JSONArray()
        val shows = org.json.JSONArray()
        entries.forEach { e ->
            val obj = JSONObject().put("ids", JSONObject().put("imdb", e.imdbId))
            if (e.type == "movie") movies.put(obj) else shows.put(obj)
        }
        val body = JSONObject()
        if (movies.length() > 0) body.put("movies", movies)
        if (shows.length() > 0) body.put("shows", shows)
        val request = authed(accessToken).url("$API_BASE/sync/$path")
            .post(body.toString().toRequestBody(JSON)).build()
        try {
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * One in-progress item from Trakt's playback sync (GET
     * /sync/playback): something the user PAUSED mid-way in any
     * Trakt-connected app — exactly what Plavio's Continue
     * Watching import reads (notes item 13). [progressPct] is the
     * percent watched (0-100); [pausedAtMs] is when it was paused.
     * Episodes are keyed by the SHOW's IMDb id plus season/episode.
     */
    data class PlaybackEntry(
        val type: String, // "movie" or "series"
        val imdbId: String,
        val title: String,
        val episodeTitle: String?,
        val season: Int,
        val episode: Int,
        val progressPct: Int,
        val pausedAtMs: Long
    )

    /** Everything the user has paused mid-playback on Trakt. Throws on failure. */
    suspend fun getPlaybackProgress(accessToken: String): List<PlaybackEntry> =
        withContext(Dispatchers.IO) {
            val (code, text) = getJson(accessToken, "/sync/playback")
            if (code !in 200..299) {
                throw IllegalStateException("Trakt playback failed (HTTP $code)")
            }
            val arr = org.json.JSONArray(text.ifBlank { "[]" })
            val out = mutableListOf<PlaybackEntry>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val pct = item.optDouble("progress", -1.0)
                if (pct < 0) continue
                val pausedAtMs = runCatching {
                    java.time.Instant.parse(item.optString("paused_at")).toEpochMilli()
                }.getOrDefault(0L)
                when (item.optString("type")) {
                    "movie" -> {
                        val movie = item.optJSONObject("movie") ?: continue
                        val imdb = movie.optJSONObject("ids")?.optString("imdb")
                            ?.takeIf { it.startsWith("tt") } ?: continue
                        out += PlaybackEntry(
                            type = "movie", imdbId = imdb,
                            title = movie.optString("title"),
                            episodeTitle = null, season = 0, episode = 0,
                            progressPct = pct.toInt().coerceIn(0, 100),
                            pausedAtMs = pausedAtMs
                        )
                    }
                    "episode" -> {
                        val show = item.optJSONObject("show") ?: continue
                        val ep = item.optJSONObject("episode") ?: continue
                        val imdb = show.optJSONObject("ids")?.optString("imdb")
                            ?.takeIf { it.startsWith("tt") } ?: continue
                        out += PlaybackEntry(
                            type = "series", imdbId = imdb,
                            title = show.optString("title"),
                            episodeTitle = ep.optString("title").takeIf { it.isNotBlank() },
                            season = ep.optInt("season"), episode = ep.optInt("number"),
                            progressPct = pct.toInt().coerceIn(0, 100),
                            pausedAtMs = pausedAtMs
                        )
                    }
                }
            }
            out
        }

    /** One show the user is mid-way through, with the next episode to watch. */
    data class UpNextEntry(
        val imdbId: String,
        val title: String,
        val lastSeason: Int,
        val lastEpisode: Int,
        val nextSeason: Int,
        val nextEpisode: Int,
        val nextTitle: String?,
        val watchedCount: Int,
        val airedCount: Int,
        val lastWatchedAtMs: Long
    )

    private data class NextEp(val season: Int, val episode: Int, val title: String?, val airedTotal: Int)

    /**
     * "Up next" from Trakt watched progress: shows with at least one
     * watched episode and a later aired episode still unwatched.
     * sync/watched/shows gives the watched sets; each candidate show's
     * episode list is then checked for the first aired unwatched one.
     * Per-show failures are skipped — one bad show never sinks the list.
     */
    suspend fun getUpNext(accessToken: String, limit: Int = 12): List<UpNextEntry> =
        withContext(Dispatchers.IO) {
            val request = authed(accessToken).url("$API_BASE/sync/watched/shows").get().build()
            data class Candidate(
                val imdb: String, val title: String,
                val watched: Set<Pair<Int, Int>>, val lastMs: Long
            )
            val candidates = mutableListOf<Candidate>()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("Trakt watched failed (HTTP ${response.code})")
                }
                val arr = org.json.JSONArray(response.body?.string().orEmpty().ifBlank { "[]" })
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val show = item.optJSONObject("show") ?: continue
                    val imdb = show.optJSONObject("ids")?.optString("imdb")
                        ?.takeIf { it.startsWith("tt") } ?: continue
                    val lastMs = runCatching {
                        java.time.Instant.parse(item.optString("last_watched_at")).toEpochMilli()
                    }.getOrDefault(0L)
                    val watched = mutableSetOf<Pair<Int, Int>>()
                    val seasons = item.optJSONArray("seasons")
                    if (seasons != null) for (s in 0 until seasons.length()) {
                        val season = seasons.optJSONObject(s) ?: continue
                        val sNum = season.optInt("number")
                        if (sNum == 0) continue
                        val eps = season.optJSONArray("episodes")
                        if (eps != null) for (e in 0 until eps.length()) {
                            val ep = eps.optJSONObject(e) ?: continue
                            watched += sNum to ep.optInt("number")
                        }
                    }
                    if (watched.isNotEmpty()) {
                        candidates += Candidate(imdb, show.optString("title"), watched, lastMs)
                    }
                }
            }
            val out = mutableListOf<UpNextEntry>()
            for (c in candidates.sortedByDescending { it.lastMs }.take(limit)) {
                val next = runCatching { nextAiredEpisode(accessToken, c.imdb, c.watched) }
                    .getOrNull() ?: continue
                val last = c.watched.maxWith(compareBy({ it.first }, { it.second }))
                out += UpNextEntry(
                    imdbId = c.imdb, title = c.title,
                    lastSeason = last.first, lastEpisode = last.second,
                    nextSeason = next.season, nextEpisode = next.episode,
                    nextTitle = next.title,
                    watchedCount = c.watched.size, airedCount = next.airedTotal,
                    lastWatchedAtMs = c.lastMs
                )
            }
            out
        }

    /** First aired episode (season >= 1) not in [watched], plus the aired total. */
    private fun nextAiredEpisode(
        accessToken: String, imdb: String, watched: Set<Pair<Int, Int>>
    ): NextEp? {
        val request = authed(accessToken)
            .url("$API_BASE/shows/$imdb/seasons?extended=episodes").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val arr = org.json.JSONArray(response.body?.string().orEmpty().ifBlank { "[]" })
            var aired = 0
            var found: NextEp? = null
            for (s in 0 until arr.length()) {
                val season = arr.optJSONObject(s) ?: continue
                val sNum = season.optInt("number")
                if (sNum == 0) continue
                val eps = season.optJSONArray("episodes") ?: continue
                for (e in 0 until eps.length()) {
                    val ep = eps.optJSONObject(e) ?: continue
                    if (ep.optString("first_aired").isBlank()) continue
                    aired++
                    val key = sNum to ep.optInt("number")
                    if (found == null && key !in watched) {
                        found = NextEp(
                            key.first, key.second,
                            ep.optString("title").takeIf { it.isNotBlank() }, 0
                        )
                    }
                }
            }
            val f = found ?: return null
            return NextEp(f.season, f.episode, f.title, aired)
        }
    }

    // ---- Phase 1 write layer (v0.14.6): verified writes, personal
    // lists, watched history. Every call returns a [WriteResult] with a
    // user-readable message — failures are NEVER silent (report §2.6).

    /** Outcome of a write: ok + a message the UI can show as-is. */
    data class WriteResult(val ok: Boolean, val message: String)

    /** One of the user's personal Trakt lists. */
    data class TraktListInfo(val id: Int, val name: String, val itemCount: Int)

    /** A title (or a show + episode set) for a /sync/history write. */
    data class HistoryItem(
        val type: String, // "movie" or "series"
        val imdbId: String,
        val title: String,
        val year: Int? = null,
        /** (season, episode) pairs for series; batched into one call. */
        val episodes: List<Pair<Int, Int>> = emptyList()
    )

    private fun traktErrorMessage(code: Int): String = when (code) {
        401, 403 -> "Trakt link expired — reconnect Trakt in Settings → Integrations."
        404 -> "That list doesn't exist on Trakt any more."
        420 -> "Trakt list limit reached."
        429 -> "Trakt is rate-limiting — wait a moment and try again."
        else -> "Trakt didn't accept that (HTTP $code)."
    }

    /** POSTs a JSON body to a Trakt path; returns (HTTP code, parsed body). */
    private suspend fun postJson(
        accessToken: String, path: String, body: JSONObject
    ): Pair<Int, JSONObject?> = withContext(Dispatchers.IO) {
        val request = authed(accessToken).url("$API_BASE$path")
            .post(body.toString().toRequestBody(JSON)).build()
        try {
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                val json = runCatching { JSONObject(text) }.getOrNull()
                response.code to json
            }
        } catch (e: Exception) {
            -1 to null
        }
    }

    private suspend fun getJson(accessToken: String, path: String): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            val request = authed(accessToken).url("$API_BASE$path").get().build()
            try {
                client.newCall(request).execute().use { response ->
                    response.code to (response.body?.string().orEmpty())
                }
            } catch (e: Exception) {
                -1 to ""
            }
        }

    private fun titleBody(e: WatchlistEntry): JSONObject {
        val obj = JSONObject()
            .put("title", e.title)
            .put("ids", JSONObject().put("imdb", e.imdbId))
        return obj
    }

    private fun listBody(entries: List<WatchlistEntry>): JSONObject {
        val movies = org.json.JSONArray()
        val shows = org.json.JSONArray()
        entries.forEach { e -> if (e.type == "movie") movies.put(titleBody(e)) else shows.put(titleBody(e)) }
        val body = JSONObject()
        if (movies.length() > 0) body.put("movies", movies)
        if (shows.length() > 0) body.put("shows", shows)
        return body
    }

    /**
     * Verified watchlist add: Trakt answers with added/existing counts;
     * 0 added AND 0 existing means the write did not land (Nuvio's rule).
     */
    suspend fun addToWatchlistVerified(
        accessToken: String, entries: List<WatchlistEntry>
    ): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to add.")
        val (code, json) = postJson(accessToken, "/sync/watchlist", listBody(entries))
        if (code !in 200..299) return WriteResult(false, traktErrorMessage(code))
        val added = json?.optJSONObject("added")
        val existing = json?.optJSONObject("existing")
        val addedCount = (added?.optInt("movies") ?: 0) + (added?.optInt("shows") ?: 0)
        val existingCount = (existing?.optInt("movies") ?: 0) + (existing?.optInt("shows") ?: 0)
        return if (addedCount + existingCount >= entries.size || addedCount > 0) {
            WriteResult(true, "Added to your Trakt watchlist.")
        } else {
            WriteResult(false, "Trakt didn't add that — it may not have matched the title.")
        }
    }

    /** Verified watchlist remove (same count check, inverted fields). */
    suspend fun removeFromWatchlistVerified(
        accessToken: String, entries: List<WatchlistEntry>
    ): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to remove.")
        val (code, _) = postJson(accessToken, "/sync/watchlist/remove", listBody(entries))
        return if (code in 200..299) WriteResult(true, "Removed from your Trakt watchlist.")
        else WriteResult(false, traktErrorMessage(code))
    }

    /** The user's personal Trakt lists. Throws on failure. */
    suspend fun getLists(accessToken: String): List<TraktListInfo> {
        val (code, text) = getJson(accessToken, "/users/me/lists")
        if (code !in 200..299) throw IllegalStateException(traktErrorMessage(code))
        val arr = org.json.JSONArray(text.ifBlank { "[]" })
        val out = mutableListOf<TraktListInfo>()
        for (i in 0 until arr.length()) {
            val node = arr.optJSONObject(i) ?: continue
            val ids = node.optJSONObject("ids") ?: continue
            val id = ids.optInt("trakt", 0).takeIf { it > 0 } ?: node.optInt("id", 0)
            if (id <= 0) continue
            out += TraktListInfo(id, node.optString("name", "List"), node.optInt("item_count", 0))
        }
        return out
    }

    /** Items of one personal list. Throws on failure. */
    suspend fun getListItems(accessToken: String, listId: Int): List<WatchlistEntry> {
        val (code, text) = getJson(accessToken, "/users/me/lists/$listId/items")
        if (code !in 200..299) throw IllegalStateException(traktErrorMessage(code))
        val arr = org.json.JSONArray(text.ifBlank { "[]" })
        val out = mutableListOf<WatchlistEntry>()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val type = item.optString("type")
            val nodeName = when (type) { "movie" -> "movie"; "show" -> "show"; else -> continue }
            val node = item.optJSONObject(nodeName) ?: continue
            parseWatchlistNode(
                if (type == "movie") "movie" else "series", node
            )?.let { out += it }
        }
        return out
    }

    /** Adds items to a personal list (verified by the added counts). */
    suspend fun addToListItems(
        accessToken: String, listId: Int, listName: String, entries: List<WatchlistEntry>
    ): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to add.")
        val (code, json) = postJson(accessToken, "/users/me/lists/$listId/items", listBody(entries))
        if (code !in 200..299) return WriteResult(false, traktErrorMessage(code))
        val added = json?.optJSONObject("added")
        val addedCount = (added?.optInt("movies") ?: 0) + (added?.optInt("shows") ?: 0)
        val existing = json?.optJSONObject("existing")
        val existingCount = (existing?.optInt("movies") ?: 0) + (existing?.optInt("shows") ?: 0)
        return if (addedCount > 0 || existingCount >= entries.size) {
            WriteResult(true, "Added to “$listName” on Trakt.")
        } else {
            WriteResult(false, "Trakt didn't add that to “$listName”.")
        }
    }

    /** Removes items from a personal list. */
    suspend fun removeFromListItems(
        accessToken: String, listId: Int, listName: String, entries: List<WatchlistEntry>
    ): WriteResult {
        if (entries.isEmpty()) return WriteResult(true, "Nothing to remove.")
        val (code, _) = postJson(accessToken, "/users/me/lists/$listId/items/remove", listBody(entries))
        return if (code in 200..299) WriteResult(true, "Removed from “$listName” on Trakt.")
        else WriteResult(false, traktErrorMessage(code))
    }

    private fun historyBody(items: List<HistoryItem>): JSONObject {
        val movies = org.json.JSONArray()
        val shows = org.json.JSONArray()
        for (item in items) {
            val ids = JSONObject().put("imdb", item.imdbId)
            if (item.type == "movie") {
                val obj = JSONObject().put("title", item.title).put("ids", ids)
                item.year?.let { obj.put("year", it) }
                movies.put(obj)
            } else {
                val obj = JSONObject().put("title", item.title).put("ids", ids)
                item.year?.let { obj.put("year", it) }
                if (item.episodes.isNotEmpty()) {
                    val seasonsArr = org.json.JSONArray()
                    item.episodes.groupBy({ it.first }, { it.second }).forEach { (season, eps) ->
                        val epsArr = org.json.JSONArray()
                        eps.distinct().sorted().forEach { n ->
                            epsArr.put(JSONObject().put("number", n))
                        }
                        seasonsArr.put(JSONObject().put("number", season).put("episodes", epsArr))
                    }
                    obj.put("seasons", seasonsArr)
                }
                shows.put(obj)
            }
        }
        val body = JSONObject()
        if (movies.length() > 0) body.put("movies", movies)
        if (shows.length() > 0) body.put("shows", shows)
        return body
    }

    /** Marks titles/episodes watched on Trakt (POST /sync/history). */
    suspend fun markWatched(accessToken: String, items: List<HistoryItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to mark.")
        val (code, _) = postJson(accessToken, "/sync/history", historyBody(items))
        return if (code in 200..299) WriteResult(true, "Marked watched on Trakt.")
        else WriteResult(false, traktErrorMessage(code))
    }

    /** Removes titles/episodes from Trakt watched history. */
    suspend fun unmarkWatched(accessToken: String, items: List<HistoryItem>): WriteResult {
        if (items.isEmpty()) return WriteResult(true, "Nothing to unmark.")
        val (code, _) = postJson(accessToken, "/sync/history/remove", historyBody(items))
        return if (code in 200..299) WriteResult(true, "Removed from your Trakt history.")
        else WriteResult(false, traktErrorMessage(code))
    }

    private fun base64Url(bytes: ByteArray): String =
        java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
}
