package com.pulsestream.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.notifications.EpisodeNotifications
import com.pulsestream.app.data.notifications.MovieNotifications
import com.pulsestream.app.data.update.UpdateChecker
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Settings → Notifications (v0.14.14): EVERY alert the app can send is
 * controlled on this one screen and nowhere else (owner's order
 * 2026-10-29). The toggles are the existing stores, single-homed:
 *  - "Update available"  → UpdateChecker auto-check (moved out of About)
 *  - "New episodes"      → SettingsStore.episodeNotifications (moved
 *    out of the old Content section; master switch for the per-series
 *    bell, which stays on series pages)
 *  - "New movie releases"→ SettingsStore.movieNotifications (new)
 *  - "Download finished" → SettingsStore.downloadFinishedNotifications (new)
 */
@Composable
fun NotificationsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {}
) {
    val settings = repository.settings
    val context = LocalContext.current
    val appContext = context.applicationContext

    var permissionGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted = granted }

    var updateAvailable by remember {
        mutableStateOf(UpdateChecker.isAutoCheckEnabled(appContext))
    }
    var episodeNotifs by remember { mutableStateOf(settings.episodeNotifications) }
    var movieNotifs by remember { mutableStateOf(settings.movieNotifications) }
    var downloadDone by remember { mutableStateOf(settings.downloadFinishedNotifications) }

    fun requestPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && !permissionGranted) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Notifications",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
            }

            // ---- Permission status row: granted → opens Android's
            // app notification settings; not granted → tapping asks.
            // v0.14.27 (batch N6 — owner's order 2026-11-07): while
            // the permission is NOT allowed the state line shows RED,
            // so nobody has to guess whether they already gave it;
            // once allowed it returns to the normal colour. ----
            item(key = "permission") {
                SettingsGroup(
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.VerifiedUser,
                            title = "Notifications permission",
                            subtitle = if (permissionGranted) {
                                "Allowed — manage in Android settings"
                            } else {
                                "Not allowed — tap to allow alerts"
                            },
                            subtitleColor = if (permissionGranted) {
                                TextSecondary
                            } else {
                                MaterialTheme.colorScheme.error
                            },
                            onClick = {
                                if (permissionGranted) {
                                    runCatching {
                                        context.startActivity(
                                            Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
                                                .putExtra(
                                                    AndroidSettings.EXTRA_APP_PACKAGE,
                                                    context.packageName
                                                )
                                        )
                                    }
                                } else {
                                    requestPermissionIfNeeded()
                                }
                            }
                        )
                    }
                )
            }

            item(key = "app_header") { SettingsSectionHeader("App") }
            item(key = "app_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.SystemUpdate,
                            title = "Update available",
                            subtitle = "When a new Plavio version is ready",
                            checked = updateAvailable,
                            onCheckedChange = { enabled ->
                                updateAvailable = enabled
                                UpdateChecker.setAutoCheckEnabled(appContext, enabled)
                            },
                            compact = false
                        )
                    }
                )
            }

            item(key = "series_header") { SettingsSectionHeader("Series") }
            item(key = "series_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Notifications,
                            title = "New episodes",
                            subtitle = "For series you follow — the bell on each series page picks which ones.",
                            checked = episodeNotifs,
                            onCheckedChange = { enabled ->
                                settings.episodeNotifications = enabled
                                episodeNotifs = enabled
                                if (enabled) {
                                    EpisodeNotifications.ensureScheduled(context)
                                    requestPermissionIfNeeded()
                                } else {
                                    EpisodeNotifications.cancel(context)
                                }
                            },
                            compact = false
                        )
                    }
                )
            }

            item(key = "movies_header") { SettingsSectionHeader("Movies") }
            item(key = "movies_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Movie,
                            title = "New movie releases",
                            subtitle = "When a watchlisted movie is released",
                            checked = movieNotifs,
                            onCheckedChange = { enabled ->
                                settings.movieNotifications = enabled
                                movieNotifs = enabled
                                if (enabled) {
                                    MovieNotifications.ensureScheduled(context)
                                    requestPermissionIfNeeded()
                                } else {
                                    MovieNotifications.cancel(context)
                                }
                            },
                            compact = false
                        )
                    }
                )
            }

            item(key = "downloads_header") { SettingsSectionHeader("Downloads") }
            item(key = "downloads_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Download,
                            title = "Download finished",
                            subtitle = "Notify when a download completes",
                            checked = downloadDone,
                            onCheckedChange = { enabled ->
                                settings.downloadFinishedNotifications = enabled
                                downloadDone = enabled
                                if (enabled) requestPermissionIfNeeded()
                            },
                            compact = false
                        )
                    }
                )
            }

            item(key = "footer") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Text(
                        "Every alert Plavio can send is controlled here — " +
                            "turn a category off and its alerts stop everywhere.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
