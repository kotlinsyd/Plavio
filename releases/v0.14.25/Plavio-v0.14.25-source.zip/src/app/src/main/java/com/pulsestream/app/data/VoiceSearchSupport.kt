package com.pulsestream.app.data

/**
 * Voice search — pure seams (owner order 2026-10-31, "add if it's not
 * break our app"). The feature is built so a voice failure can NEVER
 * reach the search flow:
 *
 *  - Recognition is the SYSTEM's (RecognizerIntent) — no audio pipeline,
 *    no models, no server in this app; the recognizer app does the
 *    listening under its own UI.
 *  - The mic renders only when [micVisible] says so: a recognition
 *    activity must actually resolve on the device AND the RECORD_AUDIO
 *    permission must not be in the DENIED state. When it doesn't
 *    render, the search bar is exactly today's bar.
 *  - The hand-off is one pure function ([firstResult]): the recognised
 *    text is written into the SAME query state typed text uses, and
 *    from there the identical debounce/settle/warm pipeline runs.
 *    Cancel, error, and no-match all produce null here, and null means
 *    "leave the query untouched".
 */
public object VoiceSearchSupport {

    /** Where the RECORD_AUDIO permission stands, from the UI's view. */
    public enum class PermissionState {
        /** Never asked (or status unknown): show the mic; tapping asks. */
        UNKNOWN,

        /** Granted: show the mic; tapping launches the recognizer. */
        GRANTED,

        /** Asked and refused, or granted then revoked: mic disappears. */
        DENIED,
    }

    /**
     * The availability gate. Both conditions are required; either one
     * failing hides the mic and leaves typed search completely alone.
     */
    public fun micVisible(recognitionResolves: Boolean, permission: PermissionState): Boolean =
        recognitionResolves && permission != PermissionState.DENIED

    /** Derive the UI permission state from the two facts the UI knows. */
    public fun permissionState(granted: Boolean, askedBefore: Boolean): PermissionState = when {
        granted -> PermissionState.GRANTED
        askedBefore -> PermissionState.DENIED
        else -> PermissionState.UNKNOWN
    }

    /**
     * The result hand-off: the first non-blank recognition candidate,
     * trimmed — or null when there is nothing usable (no match, empty
     * result, recognizer error surfaces as no data at the seam). Null
     * ALWAYS means the caller leaves the current query untouched.
     */
    public fun firstResult(results: List<String>?): String? =
        results?.firstOrNull { it.isNotBlank() }?.trim()?.takeIf { it.isNotEmpty() }
}
