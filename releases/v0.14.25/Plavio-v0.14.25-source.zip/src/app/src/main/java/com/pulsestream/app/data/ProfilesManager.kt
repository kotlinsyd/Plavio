package com.pulsestream.app.data

import android.content.Context
import android.content.Intent
import com.pulsestream.app.MainActivity
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.CurrentProfile
import com.pulsestream.app.data.db.ProfileRow
import com.pulsestream.app.data.db.Profiles
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Local profiles (v0.14.13, item 8): create / rename / delete /
 * set-default / switch for the profiles that partition the library
 * tables (see [CurrentProfile]).
 *
 * Rules:
 *  - Addons, global settings and the signed-in Plavio account are
 *    NOT per-profile; watchlist, favorites, statuses, custom lists,
 *    watched marks and playback (Continue Watching + history) are.
 *  - The app COLD-OPENS into the default profile: PulseApp seeds
 *    [SettingsStore.activeProfileId] from the default on a fresh
 *    process (a manual switch lasts for the session via the same
 *    setting; the default is what a cold start returns to — see
 *    [applyColdStartProfile]).
 *  - Switching restarts the app process so every DAO flow rebinds
 *    to the new profile — no half-switched screens.
 *  - The last profile can't be deleted; deleting the default moves
 *    the default flag to the oldest remaining profile.
 */
class ProfilesManager(
    private val db: AppDatabase,
    private val settings: SettingsStore
) {

    /** Insert the first profile if the table is empty; repair flags. */
    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        val dao = db.profileDao()
        val all = dao.getAll()
        if (all.isEmpty()) {
            dao.upsert(
                ProfileRow(
                    id = Profiles.DEFAULT_ID,
                    name = Profiles.DEFAULT_NAME,
                    avatarKey = Profiles.DEFAULT_AVATAR,
                    isDefault = true,
                    createdAt = System.currentTimeMillis()
                )
            )
            settings.defaultProfileId = Profiles.DEFAULT_ID
            return@withContext
        }
        // Keep SettingsStore and the table's default flag in agreement.
        val flagged = all.firstOrNull { it.isDefault }
        val settingsDefault = all.firstOrNull { it.id == settings.defaultProfileId }
        when {
            settingsDefault != null && flagged?.id != settingsDefault.id -> {
                dao.clearDefaults()
                dao.markDefault(settingsDefault.id)
            }
            flagged == null -> {
                val target = settingsDefault ?: all.first()
                dao.markDefault(target.id)
                settings.defaultProfileId = target.id
            }
            else -> settings.defaultProfileId = flagged.id
        }
        // A stale active id (profile deleted elsewhere) falls back to default.
        if (all.none { it.id == settings.activeProfileId }) {
            settings.activeProfileId = settings.defaultProfileId
            CurrentProfile.id = settings.defaultProfileId
        }
    }

    /**
     * Cold start rule: a fresh process opens into the DEFAULT
     * profile (the owner's spec — "the app cold-opens into the
     * default profile"). The one exception is a manual switch: it
     * restarts the app to rebind every DAO flow, and the restart
     * consumes the one-shot pending-switch flag so the switch
     * lands; the NEXT cold start returns to the default. Called
     * from PulseApp before the repository is built.
     */
    fun applyColdStartProfile() {
        val pending = settings.pendingSwitchProfileId
        if (pending.isNotBlank()) {
            settings.pendingSwitchProfileId = ""
            settings.activeProfileId = pending
            CurrentProfile.id = pending
        } else {
            settings.activeProfileId = settings.defaultProfileId
            CurrentProfile.id = settings.defaultProfileId
        }
    }

    suspend fun create(name: String, avatarKey: String): ProfileRow = withContext(Dispatchers.IO) {
        val row = ProfileRow(
            id = "profile_" + UUID.randomUUID().toString().replace("-", "").take(16),
            name = name.trim().ifBlank { "Profile" },
            avatarKey = avatarKey,
            isDefault = false,
            createdAt = System.currentTimeMillis()
        )
        db.profileDao().upsert(row)
        row
    }

    suspend fun rename(id: String, name: String) = withContext(Dispatchers.IO) {
        val dao = db.profileDao()
        val row = dao.getById(id) ?: return@withContext
        dao.upsert(row.copy(name = name.trim().ifBlank { row.name }))
    }

    suspend fun setAvatar(id: String, avatarKey: String) = withContext(Dispatchers.IO) {
        val dao = db.profileDao()
        val row = dao.getById(id) ?: return@withContext
        dao.upsert(row.copy(avatarKey = avatarKey))
    }

    /** Any profile can be made the default (owner's spec). */
    suspend fun setDefault(id: String) = withContext(Dispatchers.IO) {
        val dao = db.profileDao()
        if (dao.getById(id) == null) return@withContext
        dao.clearDefaults()
        dao.markDefault(id)
        settings.defaultProfileId = id
    }

    /**
     * Delete a profile AND its partitioned rows. Returns false when
     * it's the last profile (refused) or doesn't exist. When the
     * deleted profile was the default, the oldest remaining profile
     * becomes default; when it was active, the caller restarts into
     * the default.
     */
    suspend fun delete(id: String): Boolean = withContext(Dispatchers.IO) {
        val dao = db.profileDao()
        val all = dao.getAll()
        if (all.size <= 1 || all.none { it.id == id }) return@withContext false
        db.watchlistDao().deleteForProfile(id)
        db.favoriteDao().deleteForProfile(id)
        db.titleStatusDao().deleteForProfile(id)
        db.playbackDao().deleteForProfile(id)
        db.watchedDao().deleteForProfile(id)
        db.customListDao().deleteItemsForProfile(id)
        db.customListDao().deleteListsForProfile(id)
        dao.deleteById(id)
        val remaining = dao.getAll()
        if (settings.defaultProfileId == id) {
            val next = remaining.first()
            dao.clearDefaults()
            dao.markDefault(next.id)
            settings.defaultProfileId = next.id
        }
        if (settings.activeProfileId == id) {
            settings.activeProfileId = settings.defaultProfileId
            CurrentProfile.id = settings.defaultProfileId
        }
        true
    }

    /**
     * Switch the active profile: recorded as a one-shot pending
     * switch (consumed by the restart's cold start) plus the live
     * process state. The caller restarts the app via [restartApp].
     */
    fun switchTo(id: String) {
        settings.pendingSwitchProfileId = id
        settings.activeProfileId = id
        CurrentProfile.id = id
    }

    companion object {
        /**
         * Full process restart into the (new) active/default profile.
         * DAO flows bind their profileId when they are created, so a
         * clean process is the only honest switch.
         */
        fun restartApp(context: Context) {
            val intent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            context.startActivity(intent)
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
