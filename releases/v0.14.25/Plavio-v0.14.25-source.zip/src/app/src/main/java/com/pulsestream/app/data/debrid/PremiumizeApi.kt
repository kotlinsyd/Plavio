package com.pulsestream.app.data.debrid

import com.pulsestream.app.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Raw HTTP client for the Premiumize API (https://www.premiumize.me/api).
 *
 * Debrid-only usage, cache-first by construction:
 *  1. checkCached(magnet) via POST /cache/check — parallel `response`
 *     array, one boolean per requested item.
 *  2. Only on a hit: POST /transfer/directdl with the magnet — this
 *     generates direct links for the torrent's files WITHOUT storing
 *     anything in the user's cloud, so a resolve never adds, polls,
 *     or litters the account.
 *
 * API shape (official docs, premiumize.me/api): every response is a
 * JSON envelope `{status: "success"|"error", message, code}` and the
 * HTTP status stays 200 for business errors — the envelope decides.
 * Auth uses the documented Bearer header.
 */
class PremiumizeApi(private val apiKey: String) {

    companion object {
        private const val BASE = "https://www.premiumize.me/api"

        /** Parse a /cache/check response: true iff our item (index 0)
         *  is cached. Throws on an error envelope. */
        internal fun parseCacheCheck(json: JSONObject): Boolean {
            requireSuccess(json)
            val response = json.optJSONArray("response")
                ?: throw PremiumizeException("Premiumize cache/check: missing response array")
            return response.length() > 0 && response.optBoolean(0, false)
        }

        /** Parse a /transfer/directdl response into its file list. */
        internal fun parseDirectDlFiles(json: JSONObject): List<DirectDlFile> {
            requireSuccess(json)
            val content = json.optJSONArray("content")
                ?: throw PremiumizeException("Premiumize directdl: missing content array")
            return (0 until content.length()).mapNotNull { i ->
                val entry = content.optJSONObject(i) ?: return@mapNotNull null
                val link = entry.optString("link").takeIf { it.isNotBlank() }
                    ?: return@mapNotNull null
                DirectDlFile(
                    name = entry.optString("path"),
                    size = entry.optLong("size", 0L),
                    link = link,
                    sourceIndex = i
                )
            }
        }

        /** Parse a /account/info response. */
        internal fun parseAccount(json: JSONObject): PremiumizeAccount {
            requireSuccess(json)
            return PremiumizeAccount(
                customerId = json.optString("customer_id").takeIf { it.isNotBlank() },
                premiumUntil = if (json.isNull("premium_until")) null else json.optLong("premium_until")
            )
        }

        private fun requireSuccess(json: JSONObject) {
            if (json.optString("status") == "success") return
            val code = json.optString("code")
            throw PremiumizeException(
                json.optString("message").ifBlank { "Premiumize request failed" },
                isAuthError = code == "authentication_failed" || code == "permission_denied"
            )
        }
    }

    /** One file of a directdl listing: [name] is the slash-joined
     *  path inside the source, [link] its direct download URL. */
    data class DirectDlFile(
        val name: String,
        val size: Long,
        val link: String,
        /** Zero-based position in the response's content array. */
        val sourceIndex: Int
    )

    data class PremiumizeAccount(val customerId: String?, val premiumUntil: Long?)

    private val userAgent = "Plavio/${BuildConfig.VERSION_NAME}"

    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun postForm(path: String, form: FormBody): JSONObject {
        val request = Request.Builder()
            .url("$BASE$path")
            .header("Authorization", "Bearer $apiKey")
            .header("User-Agent", userAgent)
            .post(form)
            .build()
        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw PremiumizeException(
                    "Premiumize request failed (HTTP ${response.code})",
                    isAuthError = response.code == 401 || response.code == 403
                )
            }
            return try {
                JSONObject(bodyStr)
            } catch (e: Exception) {
                throw PremiumizeException("Premiumize returned an unreadable response")
            }
        }
    }

    private fun get(path: String): JSONObject {
        val request = Request.Builder()
            .url("$BASE$path")
            .header("Authorization", "Bearer $apiKey")
            .header("User-Agent", userAgent)
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw PremiumizeException(
                    "Premiumize request failed (HTTP ${response.code})",
                    isAuthError = response.code == 401 || response.code == 403
                )
            }
            return try {
                JSONObject(bodyStr)
            } catch (e: Exception) {
                throw PremiumizeException("Premiumize returned an unreadable response")
            }
        }
    }

    /** Is this magnet already in Premiumize's cache? */
    suspend fun checkCached(magnet: String): Boolean = withContext(Dispatchers.IO) {
        val form = FormBody.Builder().add("items[]", magnet).build()
        parseCacheCheck(postForm("/cache/check", form))
    }

    /** Direct download links for every file of a cached magnet. */
    suspend fun directDlFiles(magnet: String): List<DirectDlFile> = withContext(Dispatchers.IO) {
        val form = FormBody.Builder().add("src", magnet).build()
        parseDirectDlFiles(postForm("/transfer/directdl", form))
    }

    /** Account snapshot from GET /account/info — the endpoint the
     *  validate-on-save probe also uses. */
    suspend fun fetchAccount(): PremiumizeAccount = withContext(Dispatchers.IO) {
        parseAccount(get("/account/info"))
    }

    /**
     * Full resolve with detailed result: infoHash → DebridResolveResult.
     * Cache-only: a magnet Premiumize hasn't cached is NotCached and
     * nothing is ever added to the account.
     */
    suspend fun resolveCachedDetailed(
        infoHash: String,
        fileIdx: Int? = null,
        filePath: String? = null
    ): DebridResolveResult = withContext(Dispatchers.IO) {
        try {
            val magnet = "magnet:?xt=urn:btih:$infoHash"
            if (!checkCached(magnet)) return@withContext DebridResolveResult.NotCached
            val files = directDlFiles(magnet)
            val entry = DebridFileSelection.select(
                files.map {
                    DebridFileSelection.FileEntry(name = it.name, size = it.size, sourceIndex = it.sourceIndex)
                },
                fileIdx, filePath
            ) ?: return@withContext DebridResolveResult.Error(noFileMessage(fileIdx, filePath))
            val chosen = files.first { it.sourceIndex == entry.sourceIndex }
            DebridResolveResult.Resolved(chosen.link)
        } catch (e: CancellationException) {
            throw e
        } catch (e: PremiumizeException) {
            DebridResolveResult.Error(e.message ?: "Unknown Premiumize error", e.isAuthError)
        } catch (e: Exception) {
            DebridResolveResult.Error("Network error: ${e.message}")
        }
    }

    private fun noFileMessage(fileIdx: Int?, filePath: String?): String =
        if (fileIdx != null || !filePath.isNullOrBlank()) "Requested torrent file was not found"
        else "No playable files found in torrent"
}

/** Premiumize API failure; [isAuthError] marks key/account refusals. */
class PremiumizeException(message: String, val isAuthError: Boolean = false) : Exception(message)
