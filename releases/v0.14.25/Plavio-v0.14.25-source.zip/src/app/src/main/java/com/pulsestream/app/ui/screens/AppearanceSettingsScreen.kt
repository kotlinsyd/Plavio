package com.pulsestream.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.ANIMATION_OPTIONS
import com.pulsestream.app.data.CARD_CORNER_OPTIONS
import com.pulsestream.app.data.LAYOUT_SPACING_OPTIONS
import com.pulsestream.app.data.POSTER_SIZE_OPTIONS
import com.pulsestream.app.data.TEXT_SIZE_OPTIONS
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.AccentTheme
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.tv.tvFocusRing

@Composable
fun AppearanceSettingsScreen(
    repository: StreamRepository,
    onThemeChanged: () -> Unit = {},
    onBack: () -> Unit = {}
) {
    val settings = repository.settings
    val context = androidx.compose.ui.platform.LocalContext.current
    var accentName by remember { mutableStateOf(settings.accentName) }
    // Appearance extras (v0.14.39, owner's A–H list).
    var posterSize by remember { mutableStateOf(settings.posterSize) }
    var textSize by remember { mutableStateOf(settings.textSize) }
    var layoutSpacing by remember { mutableStateOf(settings.layoutSpacing) }
    var cardCorners by remember { mutableStateOf(settings.cardCorners) }
    var animationMode by remember {
        mutableStateOf(if (settings.reduceAnimations) "Reduced" else "Full")
    }
    var startupAnimation by remember { mutableStateOf(settings.startupAnimation) }
    var dockGlassBlur by remember { mutableStateOf(settings.dockGlassBlur) }
    // Continue Watching posters moved here from the Settings root
    // (v0.14.39 rebuild): an appearance choice belongs with the
    // other appearance choices — single home, here.
    var cwArtworkPoster by remember { mutableStateOf(settings.cwArtworkPoster) }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Appearance",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Pick your accent colour, sizes and more.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }
            item(key = "accent") {
                // Accent circles (owner's order 2026-10-25, from his
                // reference): one card, solid colour circles in rows of
                // three, the selected one ringed with a check — the ONLY
                // appearance choice now that Onyx is permanent.
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        AccentTheme.values().toList().chunked(3).forEach { rowThemes ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                rowThemes.forEach { theme ->
                                    val selected = theme.name == accentName
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            modifier = Modifier
                                                .size(58.dp)
                                                .clip(RoundedCornerShape(50))
                                                .background(theme.swatchBrush)
                                                .border(
                                                    if (selected) 2.5.dp else 1.dp,
                                                    if (selected) theme.primary else GlassBorder,
                                                    RoundedCornerShape(50)
                                                )
                                                .clickable {
                                                    accentName = theme.name
                                                    settings.accentName = theme.name
                                                    onThemeChanged()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (selected) {
                                                Icon(
                                                    Icons.Filled.Check,
                                                    contentDescription = "${theme.label} selected",
                                                    tint = if (theme == AccentTheme.WHITE ||
                                                        theme == AccentTheme.AMBER ||
                                                        theme == AccentTheme.EMERALD ||
                                                        theme == AccentTheme.LIME ||
                                                        theme == AccentTheme.TEAL ||
                                                        theme == AccentTheme.FUCHSIA ||
                                                        theme == AccentTheme.CORAL
                                                    ) Color.Black else Color.White,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = theme.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selected) TextPrimary else TextSecondary
                                        )
                                        Spacer(Modifier.height(3.dp))
                                        Box(
                                            Modifier
                                                .width(26.dp)
                                                .height(3.dp)
                                                .clip(RoundedCornerShape(50))
                                                .background(theme.primary)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Appearance extras (v0.14.39, owner's A–H list): sizes,
            // corners and motion. Every default = the pre-.39 shipped
            // behaviour; every change persists and re-fires
            // onThemeChanged so the root providers re-read live.
            item(key = "appearance_sizes") {
                Spacer(Modifier.height(14.dp))
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 16.dp)
                    ) {
                        Text("Poster size", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        OptionChips(
                            options = POSTER_SIZE_OPTIONS,
                            selected = posterSize,
                            onSelect = { name ->
                                posterSize = name
                                settings.posterSize = name
                                onThemeChanged()
                            }
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Text size", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        OptionChips(
                            options = TEXT_SIZE_OPTIONS,
                            selected = textSize,
                            onSelect = { name ->
                                textSize = name
                                settings.textSize = name
                                onThemeChanged()
                            }
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Layout spacing", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        OptionChips(
                            options = LAYOUT_SPACING_OPTIONS,
                            selected = layoutSpacing,
                            onSelect = { name ->
                                layoutSpacing = name
                                settings.layoutSpacing = name
                                onThemeChanged()
                            }
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Card corners", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        OptionChips(
                            options = CARD_CORNER_OPTIONS,
                            selected = cardCorners,
                            onSelect = { name ->
                                cardCorners = name
                                settings.cardCorners = name
                                onThemeChanged()
                            }
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Animations", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        OptionChips(
                            options = ANIMATION_OPTIONS,
                            selected = animationMode,
                            onSelect = { name ->
                                animationMode = name
                                // v0.14.39 (audit D2): the chips are
                                // the ONE motion control — the write
                                // funnels through MotionPreferences so
                                // the legacy reduced-motion store can
                                // never disagree with this one again.
                                com.pulsestream.app.data.MotionPreferences
                                    .setAnimationsMode(context, name)
                                onThemeChanged()
                            }
                        )
                    }
                }
            }
            item(key = "appearance_toggles") {
                Spacer(Modifier.height(10.dp))
                SettingsToggleRow(
                    icon = Icons.Filled.Movie,
                    title = "Startup animation",
                    subtitle = if (startupAnimation) "The Plavio clip plays when the app opens"
                    else "Skipped — the app opens straight to Home",
                    checked = startupAnimation,
                    onCheckedChange = { on ->
                        startupAnimation = on
                        settings.startupAnimation = on
                        onThemeChanged()
                    }
                )
                SettingsToggleRow(
                    icon = Icons.Filled.BlurOn,
                    title = "Dock glass blur",
                    subtitle = if (dockGlassBlur) "The bottom dock blurs what's behind it"
                    else "Solid dark dock, no blur",
                    checked = dockGlassBlur,
                    onCheckedChange = { on ->
                        dockGlassBlur = on
                        settings.dockGlassBlur = on
                        onThemeChanged()
                    }
                )
                SettingsToggleRow(
                    icon = Icons.Filled.Movie,
                    title = "Continue Watching posters",
                    subtitle = if (cwArtworkPoster) "Rows show the title's poster art"
                    else "Rows show a frame from where you stopped",
                    checked = cwArtworkPoster,
                    onCheckedChange = { on ->
                        cwArtworkPoster = on
                        settings.cwArtworkPoster = on
                        onThemeChanged()
                    }
                )
            }

        }
    }
}

