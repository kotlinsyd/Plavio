package com.pulsestream.app.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Background MDBList ratings resolution for Home poster cards
 * (item 29, owner's order 2026-10-28).
 *
 * Mirrors [LogoResolver]: tiles ask for a title's ratings and keep
 * painting; the strip simply appears when the data lands — Home
 * paint never blocks on MDBList. Only titles whose id is an IMDb id
 * are fetched, and only while the user has an MDBList key saved:
 * no key, nothing is fetched and nothing changes anywhere.
 *
 * Serve order per title: the in-memory map → the disk cache in
 * SettingsStore (entries younger than 7 days) → a background fetch
 * through the repository (wired in PulseApp). Fetched ratings are
 * written back to the disk cache (capped at ~400 entries, oldest
 * evicted) so the strip survives restarts without re-fetching.
 * Misses are remembered for 30 minutes so a rail of unrated titles
 * doesn't re-fetch on every recomposition.
 */
object MdbRatingsResolver {

    /** Resolved ratings by IMDb id — observed by Home poster cards. */
    private val _ratings = MutableStateFlow<Map<String, MdbListApi.Ratings>>(emptyMap())
    val ratings: StateFlow<Map<String, MdbListApi.Ratings>> = _ratings.asStateFlow()

    /** Miss timestamps by IMDb id; retried after the window. */
    private val misses = ConcurrentHashMap<String, Long>()
    private val inFlight = ConcurrentHashMap.newKeySet<String>()
    private const val MISS_RETRY_MS = 30 * 60_000L
    private const val CACHE_TTL_MS = 7 * 24 * 3600_000L
    private const val CACHE_MAX_ENTRIES = 400

    /** The actual fetch (StreamRepository.mdbRatings), wired once by PulseApp. */
    @Volatile
    var fetcher: (suspend (String) -> MdbListApi.Ratings?)? = null

    /** The app's settings, wired once by PulseApp (key check + disk cache). */
    @Volatile
    var settings: SettingsStore? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * The disk cache parsed once into memory (IMDb id → fetch epoch
     * millis to ratings). Parsing a ~400-entry JSON blob on every
     * card would hitch Home; afterwards lookups are plain map reads
     * and writes update this copy alongside the persisted JSON.
     */
    private val diskLock = Any()
    private var diskCache: MutableMap<String, Pair<Long, MdbListApi.Ratings>>? = null

    /** Ratings already resolved this process, or null. */
    fun cached(imdbId: String): MdbListApi.Ratings? = _ratings.value[imdbId]

    /**
     * Ask for a title's MDBList ratings in the background. Safe to
     * call on every composition: cached hits, fresh disk entries,
     * in-flight requests and fresh misses all no-op.
     */
    fun request(imdbId: String) {
        if (!imdbId.startsWith("tt")) return
        val store = settings ?: return
        if (store.mdblistApiKey.isNullOrBlank()) return
        if (_ratings.value.containsKey(imdbId)) return
        diskCached(imdbId)?.let { hit ->
            _ratings.update { if (it.containsKey(imdbId)) it else it + (imdbId to hit) }
            return
        }
        val missedAt = misses[imdbId]
        if (missedAt != null && System.currentTimeMillis() - missedAt < MISS_RETRY_MS) return
        if (!inFlight.add(imdbId)) return
        val fetch = fetcher
        if (fetch == null) {
            inFlight.remove(imdbId)
            return
        }
        scope.launch {
            try {
                val fetched = runCatching { fetch(imdbId) }.getOrNull()
                    ?.takeIf { !it.isEmpty }
                if (fetched != null) {
                    misses.remove(imdbId)
                    _ratings.update { it + (imdbId to fetched) }
                    persistDisk(imdbId, fetched)
                } else {
                    misses[imdbId] = System.currentTimeMillis()
                }
            } finally {
                inFlight.remove(imdbId)
            }
        }
    }

    /** A fresh-enough disk entry for [imdbId], or null. */
    private fun diskCached(imdbId: String): MdbListApi.Ratings? {
        val entry = loadDiskCache()[imdbId] ?: return null
        return entry.second.takeIf {
            System.currentTimeMillis() - entry.first < CACHE_TTL_MS
        }
    }

    /** Parses the persisted cache JSON once; later calls reuse the copy. */
    private fun loadDiskCache(): Map<String, Pair<Long, MdbListApi.Ratings>> {
        diskCache?.let { return it }
        synchronized(diskLock) {
            diskCache?.let { return it }
            val parsed = mutableMapOf<String, Pair<Long, MdbListApi.Ratings>>()
            val json = settings?.mdblistRatingsCacheJson
            if (json != null) runCatching {
                val root = JSONObject(json)
                val ids = root.keys()
                while (ids.hasNext()) {
                    val id = ids.next()
                    val node = root.optJSONObject(id) ?: continue
                    val arr = node.optJSONArray("sources") ?: continue
                    val sources = (0 until arr.length()).mapNotNull { i ->
                        val triple = arr.optJSONArray(i) ?: return@mapNotNull null
                        val key = triple.optString(0)
                        if (key.isBlank()) null
                        else MdbListApi.SourceRating(
                            key = key,
                            label = triple.optString(1),
                            text = triple.optString(2)
                        )
                    }
                    if (sources.isNotEmpty()) {
                        // Disk-restored entries carry sources only —
                        // the strip needs nothing else; typed fields
                        // stay null here (the detail page fetches its
                        // own full ratings through the repository).
                        parsed[id] = node.optLong("ts") to MdbListApi.Ratings(sources = sources)
                    }
                }
            }
            diskCache = parsed
            return parsed
        }
    }

    /**
     * Best-effort disk write: adds/replaces one entry, evicts the
     * oldest beyond the cap, and persists the whole cache as
     * imdbId → {ts, sources:[[key,label,text],...]}. Synchronized
     * and failure-swallowing — a cache write must never break a card.
     */
    private fun persistDisk(imdbId: String, ratings: MdbListApi.Ratings) {
        val store = settings ?: return
        synchronized(diskLock) {
            runCatching {
                val cache = loadDiskCache().toMutableMap()
                cache[imdbId] = System.currentTimeMillis() to ratings
                val trimmed = if (cache.size > CACHE_MAX_ENTRIES) {
                    cache.entries.sortedBy { it.value.first }
                        .takeLast(CACHE_MAX_ENTRIES)
                        .associate { it.key to it.value }
                } else cache
                val root = JSONObject()
                for ((id, entry) in trimmed) {
                    val sources = JSONArray()
                    entry.second.sources.forEach { source ->
                        sources.put(
                            JSONArray().put(source.key).put(source.label).put(source.text)
                        )
                    }
                    root.put(
                        id,
                        JSONObject().put("ts", entry.first).put("sources", sources)
                    )
                }
                store.mdblistRatingsCacheJson = root.toString()
                diskCache = trimmed.toMutableMap()
            }
        }
    }
}
