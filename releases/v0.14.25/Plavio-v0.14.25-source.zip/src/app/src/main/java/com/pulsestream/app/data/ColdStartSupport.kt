package com.pulsestream.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray

/**
 * Cold-start pure seams (v0.14.35) — the testable logic behind the
 * cold-start fix lives here, out of the repository's coroutine/DB
 * machinery:
 *
 *  - [homeServableAddonIds] / [isHomeServable]: THE one definition
 *    of "rows Home can paint from the cache" (provider gate +
 *    per-catalog visibility + non-TV + non-empty). The splash gate
 *    and Home's cached read used to disagree — the splash certified
 *    "warm" on any row (TV included) while Home's stricter read
 *    found nothing, and Home then waited on a full network refresh.
 *  - [homeFetchPlan]: the Home refresh's fetch order — non-TV
 *    catalogs only (Live TV rows are the Live tab's own path), the
 *    selected meta provider's catalogs first.
 *  - [ManifestCodec]: AddonManifest <-> JSON, for persisting
 *    manifests across cold starts under the same 6 h TTL the
 *    in-memory cache always had.
 */
object ColdStartSupport {

    /** One cached catalog row, reduced to what servability depends on. */
    data class CachedRowInfo(
        val addonId: String,
        val type: String,
        val catalogId: String,
        val itemCount: Int
    )

    /**
     * Resolves Home's provider from CACHED rows exactly the way the
     * cached read does: candidates are enabled addons holding at
     * least one non-TV row with items; the stored pick wins when it
     * is still a candidate, else the best-ranked candidate
     * ([providerOrder] = index in the preference-sorted candidate
     * list, lower is better). Null when there are no candidates —
     * callers then skip the gate.
     */
    fun resolveCachedProviderId(
        rows: List<CachedRowInfo>,
        enabledAddonIds: Set<String>,
        storedProviderId: String?,
        providerOrder: (String) -> Int
    ): String? {
        val candidates = rows
            .filter { it.type != "tv" && it.itemCount > 0 && it.addonId in enabledAddonIds }
            .map { it.addonId }
            .distinct()
        if (candidates.isEmpty()) return null
        if (storedProviderId != null && storedProviderId in candidates) return storedProviderId
        return candidates.minByOrNull { providerOrder(it) }
    }

    /**
     * True when [row] is one Home can actually paint from the cache:
     * enabled addon, non-TV, non-empty, the resolved provider's row
     * (when a provider exists), and visible per the Home picker.
     * [isVisible] receives (addonId, catalogId, type).
     */
    fun isHomeServable(
        row: CachedRowInfo,
        enabledAddonIds: Set<String>,
        providerId: String?,
        isVisible: (addonId: String, catalogId: String, type: String) -> Boolean
    ): Boolean =
        row.addonId in enabledAddonIds &&
            row.type != "tv" &&
            row.itemCount > 0 &&
            (providerId == null || row.addonId == providerId) &&
            isVisible(row.addonId, row.catalogId, row.type)

    /** One catalog the Home refresh should fetch. */
    data class FetchEntry(val addonId: String, val type: String, val catalogId: String)

    /**
     * The Home refresh fetch plan: every non-TV catalog of every
     * catalog-bearing manifest, the provider's catalogs first (stable
     * order otherwise — install order in, manifest order within an
     * addon). TV catalogs are excluded: Home discards them on sight,
     * and fetching the Live addon's ~16 TV catalogs on every cold
     * start was pure waste — the Live tab has its own load path.
     * Per-catalog Home visibility is NOT applied here (hidden
     * catalogs still need their manifest keys recorded so their
     * cached rows aren't pruned as obsolete); the fetch loop skips
     * them at fetch time.
     */
    fun homeFetchPlan(
        manifests: List<Pair<String, AddonManifest>>,
        providerId: String?
    ): List<FetchEntry> =
        manifests
            .filter { (_, manifest) -> "catalog" in manifest.resources }
            .sortedBy { (addonId, _) -> if (addonId == providerId) 0 else 1 }
            .flatMap { (addonId, manifest) ->
                manifest.catalogs
                    .filter { it.type != "tv" }
                    .map { FetchEntry(addonId, it.type, it.id) }
            }

    /**
     * Progress-emission batching for the refresh: emit as soon as a
     * PROVIDER row lands (that is what Home can paint), otherwise
     * every [PROGRESS_EMIT_BATCH] rows so the merge stays cheap.
     */
    fun progressEmissionDue(newProviderRows: Int, rowsSinceEmission: Int): Boolean =
        newProviderRows > 0 || rowsSinceEmission >= PROGRESS_EMIT_BATCH

    const val PROGRESS_EMIT_BATCH = 4

    /**
     * Owner's skeleton budget (2026-11-10): "3 to 5 seconds are
     * enough for skeleton loading." Past this, a Home that still has
     * zero rows paints ANY paintable cached rows instead of holding
     * the skeleton.
     */
    const val HOME_SKELETON_FALLBACK_MS = 5_000L
}

/**
 * AddonManifest -> JSON for the persisted manifest store. Decode
 * rides [StremioParser.parseManifest], so a persisted manifest reads
 * back with exactly the semantics of a freshly fetched one. The
 * encoding mirrors what the parser reads: extra entries are written
 * as {name} objects, with the genre entry carrying its options.
 */
object ManifestCodec {

    fun encode(manifest: AddonManifest): String {
        val root = buildJsonObject {
            put("id", manifest.id)
            put("name", manifest.name)
            put("version", manifest.version)
            put("description", manifest.description)
            if (manifest.logo != null) put("logo", manifest.logo)
            putJsonArray("types") { manifest.types.forEach { add(it) } }
            putJsonArray("resources") { manifest.resources.forEach { add(it) } }
            putJsonArray("catalogs") {
                for (catalog in manifest.catalogs) {
                    addJsonObject {
                        put("type", catalog.type)
                        put("id", catalog.id)
                        put("name", catalog.name)
                        val names = catalog.extra.ifEmpty {
                            if (catalog.genreOptions.isNotEmpty()) listOf("genre") else emptyList()
                        }
                        if (names.isNotEmpty()) {
                            putJsonArray("extra") {
                                for (name in names) {
                                    addJsonObject {
                                        put("name", name)
                                        if (name.equals("genre", ignoreCase = true) &&
                                            catalog.genreOptions.isNotEmpty()
                                        ) {
                                            putJsonArray("options") {
                                                catalog.genreOptions.forEach { add(it) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (manifest.configurable) {
                put("behaviorHints", buildJsonObject { put("configurable", true) })
            }
        }
        return root.toString()
    }

    /** Decode via the network parser — identical semantics, or null when unparseable. */
    fun decode(json: String): AddonManifest? =
        try {
            StremioParser.parseManifest(json)
        } catch (_: Exception) {
            null
        }
}

/**
 * The persisted manifest store's wire format: one JSON object
 * mapping baseUrl -> {"ts": fetchedAt, "manifest": "<encoded>"}.
 * Pure encode/decode so the store's shape is unit-pinned; a corrupt
 * or missing store decodes to empty (it just costs one cold fetch).
 */
object ManifestStoreCodec {

    private val json = Json { ignoreUnknownKeys = true }

    fun encodeStore(entries: Map<String, Pair<Long, AddonManifest>>): String {
        val root = buildJsonObject {
            for ((baseUrl, entry) in entries) {
                put(
                    baseUrl,
                    buildJsonObject {
                        put("ts", entry.first)
                        put("manifest", ManifestCodec.encode(entry.second))
                    }
                )
            }
        }
        return root.toString()
    }

    fun decodeStore(text: String?): Map<String, Pair<Long, AddonManifest>> {
        if (text.isNullOrBlank()) return emptyMap()
        val root = try {
            json.parseToJsonElement(text) as? JsonObject ?: return emptyMap()
        } catch (_: Exception) {
            return emptyMap()
        }
        val out = mutableMapOf<String, Pair<Long, AddonManifest>>()
        for ((baseUrl, el) in root) {
            val entry = el as? JsonObject ?: continue
            val manifest = entry["manifest"]?.jsonPrimitive?.contentOrNull
                ?.let { ManifestCodec.decode(it) } ?: continue
            val ts = entry["ts"]?.jsonPrimitive?.longOrNull ?: 0L
            out[baseUrl] = ts to manifest
        }
        return out
    }
}
