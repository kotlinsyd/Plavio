package com.pulsestream.app.ui.screens

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Home hero title logo — pins the display rule behind the bare
 * (no glass back) hero logo.
 *
 * Owner device verdict on v0.14.33 (2026-11-09): the Details
 * hero logo fix landed, but the HOME hero still showed the
 * transparent title logo ("THE ODYSSEY") inside the visible
 * SafePosterImage wash rectangle — Home renders its hero logo
 * at a separate call site. HomeHeroTitleLogo now draws the
 * artwork through a plain AsyncImage (no wash Box, no panel,
 * full brightness) and decides artwork-vs-text through
 * [heroLogoShown]: artwork only when a logo URL exists and its
 * load has not failed; a failed load falls back to the styled
 * title text, the same rule the Details hero applies.
 */
class HomeHeroLogoTest {

    @Test
    fun `no logo resolved yet shows the title text`() {
        assertFalse(heroLogoShown(logo = null, loadFailed = false))
    }

    @Test
    fun `blank logo url shows the title text`() {
        assertFalse(heroLogoShown(logo = "", loadFailed = false))
        assertFalse(heroLogoShown(logo = "   ", loadFailed = false))
    }

    @Test
    fun `resolved logo shows the bare artwork`() {
        assertTrue(
            heroLogoShown(
                logo = "https://image.tmdb.org/t/p/w500/logo.png",
                loadFailed = false
            )
        )
    }

    @Test
    fun `failed logo load falls back to the title text`() {
        assertFalse(
            heroLogoShown(
                logo = "https://image.tmdb.org/t/p/w500/logo.png",
                loadFailed = true
            )
        )
    }
}
