package com.pulsestream.app.data.debrid

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Premiumize response parsing against recorded-shape fixtures from
 * the official API docs (premiumize.me/api). No live account — the
 * parsers are pure; the HTTP shell is not exercised here.
 */
class PremiumizeApiTest {

    @Test
    fun cacheCheck_hitAndMiss() {
        assertTrue(
            PremiumizeApi.parseCacheCheck(
                JSONObject("""{"status":"success","response":[true],"filename":["Movie.2024.mkv"],"filesize":[1234567]}""")
            )
        )
        assertFalse(
            PremiumizeApi.parseCacheCheck(
                JSONObject("""{"status":"success","response":[false],"filename":[null],"filesize":[null]}""")
            )
        )
    }

    @Test
    fun cacheCheck_authErrorIsFlagged() {
        try {
            PremiumizeApi.parseCacheCheck(
                JSONObject("""{"status":"error","message":"Authentication failed","code":"authentication_failed"}""")
            )
            fail("expected PremiumizeException")
        } catch (e: PremiumizeException) {
            assertTrue(e.isAuthError)
        }
    }

    @Test
    fun cacheCheck_businessErrorIsNotAuth() {
        try {
            PremiumizeApi.parseCacheCheck(
                JSONObject("""{"status":"error","message":"Rate limit reached","code":"rate_limit"}""")
            )
            fail("expected PremiumizeException")
        } catch (e: PremiumizeException) {
            assertFalse(e.isAuthError)
        }
    }

    @Test
    fun directDl_contentFiles() {
        val files = PremiumizeApi.parseDirectDlFiles(
            JSONObject(
                """{"status":"success","content":[
                    {"path":"Movie.2024/Movie.2024.mkv","size":"2000","link":"https://dl.premiumize.me/1"},
                    {"path":"Movie.2024/subs.srt","size":"50","link":"https://dl.premiumize.me/2"}
                ]}"""
            )
        )
        assertEquals(2, files.size)
        assertEquals("Movie.2024/Movie.2024.mkv", files[0].name)
        assertEquals(2000L, files[0].size)
        assertEquals(0, files[0].sourceIndex)
        assertEquals("https://dl.premiumize.me/1", files[0].link)
        assertEquals(1, files[1].sourceIndex)
    }

    @Test
    fun account_premiumUntilNullForFree() {
        val pro = PremiumizeApi.parseAccount(
            JSONObject("""{"status":"success","customer_id":123,"premium_until":1893456000}""")
        )
        assertEquals("123", pro.customerId)
        assertEquals(1893456000L, pro.premiumUntil)

        val free = PremiumizeApi.parseAccount(
            JSONObject("""{"status":"success","customer_id":124,"premium_until":null}""")
        )
        assertNull(free.premiumUntil)
    }
}
