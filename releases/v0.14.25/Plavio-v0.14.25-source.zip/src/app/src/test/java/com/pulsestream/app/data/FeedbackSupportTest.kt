package com.pulsestream.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Playback feedback — the classifier mapping (error → failClass),
 * the per-attempt state machine, token rotation, and payload shape.
 * The honesty rule under test: ambiguous evidence resolves to the
 * user-side classes, never to blaming the link.
 */
class FeedbackSupportTest {

    private fun facts(
        family: FeedbackSupport.ErrorFamily,
        httpStatus: Int? = null,
        kinds: Set<FeedbackSupport.CauseKind> = emptySet(),
        proven: Boolean = false
    ) = FeedbackSupport.ErrorFacts(family, httpStatus, kinds, proven)

    // ---------- classifier ----------

    @Test
    fun `http statuses map exactly, unnamed statuses stay other`() {
        val fam = FeedbackSupport.ErrorFamily.BAD_HTTP_STATUS
        assertEquals("http_403", FeedbackSupport.classify(facts(fam, 403)))
        assertEquals("http_404", FeedbackSupport.classify(facts(fam, 404)))
        assertEquals("http_410", FeedbackSupport.classify(facts(fam, 410)))
        assertEquals("http_5xx", FeedbackSupport.classify(facts(fam, 500)))
        assertEquals("http_5xx", FeedbackSupport.classify(facts(fam, 503)))
        assertEquals("other", FeedbackSupport.classify(facts(fam, 418)))
        assertEquals("other", FeedbackSupport.classify(facts(fam, 301)))
        assertEquals("other", FeedbackSupport.classify(facts(fam, null)))
        assertEquals(
            "http_404",
            FeedbackSupport.classify(facts(FeedbackSupport.ErrorFamily.FILE_NOT_FOUND))
        )
    }

    @Test
    fun `decoder audio and parsing families are decode_local`() {
        for (fam in listOf(
            FeedbackSupport.ErrorFamily.DECODER,
            FeedbackSupport.ErrorFamily.AUDIO_TRACK,
            FeedbackSupport.ErrorFamily.PARSING
        )) {
            assertEquals("decode_local", FeedbackSupport.classify(facts(fam)))
        }
    }

    @Test
    fun `connect failure blames the host only with connectivity evidence`() {
        val fam = FeedbackSupport.ErrorFamily.NETWORK_CONNECTION_FAILED
        val dns = setOf(FeedbackSupport.CauseKind.DNS)
        val connect = setOf(FeedbackSupport.CauseKind.CONNECT)
        assertEquals("host_dead", FeedbackSupport.classify(facts(fam, kinds = dns, proven = true)))
        assertEquals("no_connectivity", FeedbackSupport.classify(facts(fam, kinds = dns, proven = false)))
        assertEquals("host_dead", FeedbackSupport.classify(facts(fam, kinds = connect, proven = true)))
        assertEquals("no_connectivity", FeedbackSupport.classify(facts(fam, kinds = connect, proven = false)))
        // A timeout anywhere in the chain outranks the connect reading.
        assertEquals(
            "network_timeout",
            FeedbackSupport.classify(
                facts(fam, kinds = dns + FeedbackSupport.CauseKind.TIMEOUT, proven = true)
            )
        )
        // Unclassifiable IO: proven connectivity only clears the offline reading.
        assertEquals("other", FeedbackSupport.classify(facts(fam, proven = true)))
        assertEquals("no_connectivity", FeedbackSupport.classify(facts(fam, proven = false)))
        // The timeout family and stray timeouts elsewhere.
        assertEquals(
            "network_timeout",
            FeedbackSupport.classify(facts(FeedbackSupport.ErrorFamily.NETWORK_TIMEOUT))
        )
        assertEquals(
            "network_timeout",
            FeedbackSupport.classify(
                facts(FeedbackSupport.ErrorFamily.OTHER, kinds = setOf(FeedbackSupport.CauseKind.TIMEOUT))
            )
        )
        assertEquals("other", FeedbackSupport.classify(facts(FeedbackSupport.ErrorFamily.OTHER)))
    }

    // ---------- tracker ----------

    private val idA = FeedbackSupport.AttemptIdentity("tt0000001", "PlavioHD", "https://h1.example/a.mp4")
    private val idB = FeedbackSupport.AttemptIdentity("tt0000001", "PlavioHD", "https://h2.example/b.mp4")

    private fun trackerWith(outcomes: MutableList<FeedbackSupport.Outcome>): FeedbackSupport.Tracker {
        val tracker = FeedbackSupport.Tracker()
        tracker.sink = { outcomes += it }
        return tracker
    }

    /** Plays an attempt for [seconds] of wall-clock ticks at 500 ms. */
    private fun playFor(tracker: FeedbackSupport.Tracker, fromMs: Long, seconds: Int): Long {
        var t = fromMs
        val steps = seconds * 2
        // The first tick only stamps the clock (delta 0 by design).
        tracker.onTick(isPlaying = true, ended = false, nowMs = t)
        repeat(steps) {
            t += 500
            tracker.onTick(isPlaying = true, ended = false, nowMs = t)
        }
        return t
    }

    @Test
    fun `played fires once at ten sustained seconds`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        val t = playFor(tracker, 0, 12)
        assertEquals(1, outcomes.size)
        assertTrue(outcomes[0].played)
        assertNull(outcomes[0].failClass)
        assertTrue((outcomes[0].playedSecs ?: 0) >= 10)
        // More playing never re-fires it.
        playFor(tracker, t, 10)
        assertEquals(1, outcomes.size)
    }

    @Test
    fun `a pause resets the sustained run but not total played time`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        var t = playFor(tracker, 0, 9)
        // One buffering tick breaks the sustained run.
        t += 500
        tracker.onTick(isPlaying = false, ended = false, nowMs = t)
        t = playFor(tracker, t, 9)
        assertTrue(outcomes.isEmpty())
        // One more sustained second crosses the threshold; the total
        // played seconds include the first run too.
        playFor(tracker, t, 1)
        assertEquals(1, outcomes.size)
        assertTrue(outcomes[0].played)
        assertTrue((outcomes[0].playedSecs ?: 0) >= 19)
    }

    @Test
    fun `failover honesty - the failure and the later success both report`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.onAttemptError(
            FeedbackSupport.RawError(
                FeedbackSupport.ErrorFamily.BAD_HTTP_STATUS, 403, emptySet()
            )
        )
        // A second error callback for the same attempt adds nothing.
        tracker.onAttemptError(
            FeedbackSupport.RawError(
                FeedbackSupport.ErrorFamily.BAD_HTTP_STATUS, 403, emptySet()
            )
        )
        tracker.beginAttempt(idB)
        playFor(tracker, 0, 11)
        assertEquals(2, outcomes.size)
        assertFalse(outcomes[0].played)
        assertEquals("http_403", outcomes[0].failClass)
        assertEquals(idA, outcomes[0].identity)
        assertTrue(outcomes[1].played)
        assertEquals(idB, outcomes[1].identity)
    }

    @Test
    fun `mid-playback death after thirty seconds reports failed with playedSecs`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        playFor(tracker, 0, 35)
        tracker.onAttemptError(
            FeedbackSupport.RawError(
                FeedbackSupport.ErrorFamily.NETWORK_CONNECTION_FAILED,
                null,
                setOf(FeedbackSupport.CauseKind.CONNECT)
            )
        )
        assertEquals(2, outcomes.size)
        assertTrue(outcomes[0].played)
        assertFalse(outcomes[1].played)
        assertEquals("host_dead", outcomes[1].failClass) // its own host answered for 35 s first
        assertTrue((outcomes[1].playedSecs ?: 0) >= 30)
    }

    @Test
    fun `exit before playing is cancelled, exit after playing is silent`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.onTick(isPlaying = false, ended = false, nowMs = 0)
        tracker.onScreenExit()
        assertEquals(1, outcomes.size)
        assertEquals("cancelled", outcomes[0].failClass)

        outcomes.clear()
        val tracker2 = trackerWith(outcomes)
        tracker2.beginAttempt(idA)
        playFor(tracker2, 0, 12)
        tracker2.onScreenExit()
        assertEquals(1, outcomes.size) // only the played record
        assertTrue(outcomes[0].played)
    }

    @Test
    fun `manual source switch before playing settles the old attempt as cancelled`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.beginAttempt(idB)
        assertEquals(1, outcomes.size)
        assertEquals("cancelled", outcomes[0].failClass)
        assertEquals(idA, outcomes[0].identity)
    }

    @Test
    fun `stall failover settles as network_timeout, never cancelled`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.markStallFailover()
        tracker.beginAttempt(idB)
        assertEquals(1, outcomes.size)
        assertEquals("network_timeout", outcomes[0].failClass)
        // The mark is one-shot: the next unplayed attempt settles as
        // a plain cancellation again.
        tracker.beginAttempt(idA)
        assertEquals(2, outcomes.size)
        assertEquals("cancelled", outcomes[1].failClass)
    }

    @Test
    fun `stall after long playback is a mid-playback death`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        playFor(tracker, 0, 35)
        tracker.markStallFailover()
        tracker.beginAttempt(idB)
        assertEquals(2, outcomes.size)
        assertTrue(outcomes[0].played)
        assertEquals("network_timeout", outcomes[1].failClass)
        assertTrue((outcomes[1].playedSecs ?: 0) >= 30)
    }

    @Test
    fun `short content that plays out earns played, an instant end earns nothing`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        val t = playFor(tracker, 0, 5)
        tracker.onTick(isPlaying = false, ended = true, nowMs = t + 500)
        assertEquals(1, outcomes.size)
        assertTrue(outcomes[0].played)
        assertEquals(5, outcomes[0].playedSecs)
        // After a clean end, exit adds nothing.
        tracker.onScreenExit()
        assertEquals(1, outcomes.size)

        outcomes.clear()
        val tracker2 = trackerWith(outcomes)
        tracker2.beginAttempt(idA)
        tracker2.onTick(isPlaying = true, ended = false, nowMs = 0)
        tracker2.onTick(isPlaying = false, ended = true, nowMs = 500)
        assertTrue(outcomes.isEmpty())
    }

    @Test
    fun `untracked content settles the previous attempt and stays silent`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.beginAttempt(null) // Live / trailer takes the screen
        assertEquals(1, outcomes.size)
        assertEquals("cancelled", outcomes[0].failClass)
        // Ticks and errors with no live attempt are no-ops.
        tracker.onTick(isPlaying = true, ended = false, nowMs = 0)
        tracker.onAttemptError(
            FeedbackSupport.RawError(FeedbackSupport.ErrorFamily.OTHER, null, emptySet())
        )
        tracker.onScreenExit()
        assertEquals(1, outcomes.size)
    }

    @Test
    fun `first attempt connect failure without any evidence is no_connectivity`() {
        val outcomes = mutableListOf<FeedbackSupport.Outcome>()
        val tracker = trackerWith(outcomes)
        tracker.beginAttempt(idA)
        tracker.onAttemptError(
            FeedbackSupport.RawError(
                FeedbackSupport.ErrorFamily.NETWORK_CONNECTION_FAILED,
                null,
                setOf(FeedbackSupport.CauseKind.CONNECT)
            )
        )
        assertEquals("no_connectivity", outcomes[0].failClass)
        // …but a network success elsewhere in the session proves the
        // device is online, and the same failure becomes host_dead.
        val outcomes2 = mutableListOf<FeedbackSupport.Outcome>()
        val tracker2 = trackerWith(outcomes2)
        tracker2.markNetworkProven()
        tracker2.beginAttempt(idA)
        tracker2.onAttemptError(
            FeedbackSupport.RawError(
                FeedbackSupport.ErrorFamily.NETWORK_CONNECTION_FAILED,
                null,
                setOf(FeedbackSupport.CauseKind.CONNECT)
            )
        )
        assertEquals("host_dead", outcomes2[0].failClass)
    }

    // ---------- token ----------

    @Test
    fun `token rotates on the UTC day boundary only`() {
        var generated = 0
        val newToken = { generated++; "tok-$generated" }
        val dayMs = 86_400_000L
        val first = FeedbackSupport.tokenFor(null, Long.MIN_VALUE, nowMs = 5 * dayMs + 1000, newToken)
        assertTrue(first.changed)
        assertEquals("tok-1", first.token)
        assertEquals(5L, first.epochDay)
        // Same day: the stored token is reused, nothing generated.
        val sameDay = FeedbackSupport.tokenFor(first.token, first.epochDay, nowMs = 6 * dayMs - 1, newToken)
        assertFalse(sameDay.changed)
        assertEquals("tok-1", sameDay.token)
        assertEquals(1, generated)
        // Next day: rotation.
        val nextDay = FeedbackSupport.tokenFor(first.token, first.epochDay, nowMs = 6 * dayMs, newToken)
        assertTrue(nextDay.changed)
        assertEquals("tok-2", nextDay.token)
        // A blank stored token is treated as none.
        assertTrue(FeedbackSupport.tokenFor("  ", 6L, nowMs = 6 * dayMs, newToken).changed)
    }

    // ---------- payload ----------

    @Test
    fun `payload shape matches the contract`() {
        val played = FeedbackSupport.payloadJson(
            "tok",
            FeedbackSupport.Outcome(idA, played = true, failClass = null, playedSecs = 42)
        )
        val playedObj = Json.parseToJsonElement(played).jsonObject
        assertEquals("1", playedObj["v"]!!.jsonPrimitive.content)
        assertEquals("tok", playedObj["token"]!!.jsonPrimitive.content)
        assertEquals("tt0000001", playedObj["titleId"]!!.jsonPrimitive.content)
        assertEquals("PlavioHD", playedObj["source"]!!.jsonPrimitive.content)
        assertEquals("https://h1.example/a.mp4", playedObj["url"]!!.jsonPrimitive.content)
        assertEquals("played", playedObj["outcome"]!!.jsonPrimitive.content)
        assertNull(playedObj["failClass"])
        assertEquals("42", playedObj["playedSecs"]!!.jsonPrimitive.content)

        val failed = FeedbackSupport.payloadJson(
            "tok",
            FeedbackSupport.Outcome(idA, played = false, failClass = "http_403", playedSecs = null)
        )
        val failedObj = Json.parseToJsonElement(failed).jsonObject
        assertEquals("failed", failedObj["outcome"]!!.jsonPrimitive.content)
        assertEquals("http_403", failedObj["failClass"]!!.jsonPrimitive.content)
        assertNull(failedObj["playedSecs"])
    }
}
