package com.pulsestream.app.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import com.pulsestream.app.ui.theme.PulseStreamTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * v0.14.33 (item 4): the Style panel's EDGE/BOLD row must never
 * squeeze its labels. Owner's device verdict on v0.14.32: in the
 * landscape split column (~200dp) the even chip split gave each
 * chip ~96dp — "BOLD" wrapped letter-by-letter (B/O/L stacked)
 * and the edge value truncated to "Outl…".
 *
 * These tests MEASURE the laid-out text bounds: a one-line label
 * is far wider than it is tall; a letter-stacked label is taller
 * than wide. The row is exercised at the landscape column width
 * (stacked arrangement) and at a portrait width (side-by-side).
 */
@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class, sdk = [35])
class SubEdgeBoldRowTest {

    @get:Rule val composeRule = createComposeRule()

    private fun setRow(widthDp: Int, edgeName: String) {
        composeRule.setContent {
            PulseStreamTheme {
                Box(Modifier.width(widthDp.dp)) {
                    SubEdgeBoldRow(
                        edgeName = edgeName,
                        boldChecked = true,
                        onCycleEdge = {},
                        onToggleBold = {}
                    )
                }
            }
        }
    }

    private fun assertSingleLine(text: String, minWidthToHeight: Float) {
        val bounds = composeRule.onNodeWithText(text)
            .fetchSemanticsNode().boundsInRoot
        assertTrue(
            "'$text' must be one full line (w=${bounds.width}, h=${bounds.height})",
            bounds.width > bounds.height * minWidthToHeight
        )
    }

    @Test
    fun `landscape column width — labels never squeeze`() {
        setRow(200, "Outline")
        // The crushed BOLD was a TALL narrow stack: w < h. Fixed:
        // one line, wider than tall.
        assertSingleLine("BOLD", 1.0f)
        assertSingleLine("Outline", 2.0f)
        assertSingleLine("On", 1.0f)
    }

    @Test
    fun `landscape column width — longest edge value fits whole`() {
        setRow(200, "Depressed")
        assertSingleLine("Depressed", 2.0f)
        assertSingleLine("BOLD", 1.0f)
    }

    @Test
    fun `portrait width — side by side, labels never squeeze`() {
        setRow(340, "Outline")
        assertSingleLine("BOLD", 1.0f)
        assertSingleLine("Outline", 2.0f)
    }
}
