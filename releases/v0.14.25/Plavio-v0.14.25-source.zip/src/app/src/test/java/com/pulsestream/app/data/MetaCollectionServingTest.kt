package com.pulsestream.app.data

import android.app.Application
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Franchise row regression (v0.14.42): the owner's phone showed NO
 * collection row for John Wick even though PlavioMeta serves the
 * collection inside the meta and his TMDB key is saved. Root cause
 * was the disk meta cache codec dropping the field (see
 * StreamRepository.encodeMetaCacheRow); these tests pin the whole
 * serving chain with the REAL payload PlavioMeta returns for
 * tt4425200 (verified live 2026-11-13): parse → row model →
 * meta-cache blob round-trip. (Robolectric runner: the blob codec
 * uses the framework's org.json, like the repository itself.)
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class MetaCollectionServingTest {

    /** The exact collection PlavioMeta serves inside the tt4425200 meta. */
    private val realMetaJson = """
        {"meta":{
          "id":"tt4425200",
          "type":"movie",
          "name":"John Wick: Chapter 2",
          "poster":"https://image.tmdb.org/t/p/w500/hXWBc0ioZP3cN4zCu6SN3YHXZVO.jpg",
          "collection":{"id":404609,"name":"John Wick Collection","parts":[
            {"id":245891,"imdb_id":"tt2911666","title":"John Wick","release_date":"2014-10-16","poster_path":"/wXqWR7dHncNRbxoEGybEy7QTe9h.jpg"},
            {"id":324552,"imdb_id":"tt4425200","title":"John Wick: Chapter 2","release_date":"2017-02-08","poster_path":"/hXWBc0ioZP3cN4zCu6SN3YHXZVO.jpg"},
            {"id":458156,"imdb_id":"tt6146586","title":"John Wick: Chapter 3 - Parabellum","release_date":"2019-05-15","poster_path":"/ziEuG1essDuWuC5lpWUaw1uXY2O.jpg"},
            {"id":603692,"imdb_id":"tt10366206","title":"John Wick: Chapter 4","release_date":"2023-03-21","poster_path":"/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg"}
          ]}
        }}
    """.trimIndent()

    @Test
    fun realPlavioMetaPayloadParsesIntoACollection() {
        val meta = StremioParser.parseMeta(realMetaJson, "movie")
        assertNotNull(meta)
        val collection = meta!!.collection
        assertNotNull("the in-meta collection must survive parsing", collection)
        collection!!
        assertEquals(404609, collection.id)
        assertEquals("John Wick Collection", collection.name)
        // Release order as served, IMDb ids and raw poster paths intact.
        assertEquals(
            listOf("tt2911666", "tt4425200", "tt6146586", "tt10366206"),
            collection.parts.map { it.imdbId }
        )
        assertEquals(
            listOf(245891, 324552, 458156, 603692),
            collection.parts.map { it.tmdbId }
        )
        assertEquals("/wXqWR7dHncNRbxoEGybEy7QTe9h.jpg", collection.parts.first().posterPath)
        assertEquals("2017-02-08", collection.parts[1].releaseDate)
    }

    @Test
    fun parsedCollectionBuildsTheRowModel() {
        val meta = StremioParser.parseMeta(realMetaJson, "movie")!!
        val row = TmdbClient.fromMetaCollection(meta.collection!!)
        assertEquals("John Wick Collection", row.name)
        assertEquals(4, row.parts.size)
        // Posters resolved against the TMDB image CDN (w342, the
        // same prefix the TMDB-chain parse uses), IMDb ids carried
        // through so a tap can open each part's own Details.
        assertEquals(
            "https://image.tmdb.org/t/p/w342/wXqWR7dHncNRbxoEGybEy7QTe9h.jpg",
            row.parts.first().posterUrl
        )
        assertEquals("tt4425200", row.parts[1].imdbId)
        assertEquals("2014", row.parts.first().year)
    }

    @Test
    fun collectionSurvivesTheMetaCacheBlobRoundTrip() {
        val meta = StremioParser.parseMeta(realMetaJson, "movie")!!
        val original = meta.collection!!
        val blob = StreamRepository.encodeMetaCollectionBlob(original)
        val restored = StreamRepository.decodeMetaCollectionBlob(blob)
        assertEquals(original, restored)
    }

    @Test
    fun blobDecodeRejectsNonFranchises() {
        val single = StreamRepository.encodeMetaCollectionBlob(
            MetaCollection(1, "Solo", listOf(MetaCollectionPart(2, "tt0000002", "Only")))
        )
        assertNull(StreamRepository.decodeMetaCollectionBlob(single))
        assertNull(
            StreamRepository.decodeMetaCollectionBlob(
                org.json.JSONObject("""{"id":0,"name":"","parts":[]}""")
            )
        )
    }

    @Test
    fun codecMarkerSeparatesLegacyRowsFromCurrentOnes() {
        assertTrue(StreamRepository.metaCacheExtraHasCurrentCodec("""{"cv":2}"""))
        assertFalse(StreamRepository.metaCacheExtraHasCurrentCodec("""{"cv":1}"""))
        assertFalse(StreamRepository.metaCacheExtraHasCurrentCodec("""{}"""))
        assertFalse(StreamRepository.metaCacheExtraHasCurrentCodec(null))
        assertFalse(StreamRepository.metaCacheExtraHasCurrentCodec("not json"))
    }

    @Test
    fun metaWithoutCollectionParsesWithNull() {
        val meta = StremioParser.parseMeta(
            """{"meta":{"id":"tt1375666","type":"movie","name":"Inception"}}""",
            "movie"
        )
        assertNotNull(meta)
        assertNull(meta!!.collection)
    }
}
