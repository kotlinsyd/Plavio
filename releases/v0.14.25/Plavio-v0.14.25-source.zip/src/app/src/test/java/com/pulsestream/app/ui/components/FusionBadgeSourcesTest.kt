package com.pulsestream.app.ui.components

import com.pulsestream.app.data.StreamItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.36 (item 3): Fusion style badge sources — the paste parser,
 * the three-source list rules, and the dressing priority seam.
 * Elite is never a choice: with no user sources the derived style
 * is ELITE; with any source it is the user's dressing; and an
 * addon's own formatter output still outranks both (the detector
 * contract itself is pinned by BadgeEliteOnlyTest).
 */
class FusionBadgeSourcesTest {

    private val fusionJson = """
        {
          "name": "My Fusion Pack",
          "groups": [{"id": "res"}, {"id": "audio"}],
          "filters": [
            {"name": "4K", "imageURL": "https://cdn.test/4k.png", "groupId": "res"},
            {"name": "1080p", "imageURL": "https://cdn.test/1080p.png", "groupId": "res"},
            {"name": "Atmos", "imageURL": "https://cdn.test/atmos.png", "groupId": "audio"},
            {"name": "Netflix", "imageURL": "https://cdn.test/nf.png", "groupId": "res"}
          ]
        }
    """.trimIndent()

    @Test
    fun `valid Fusion JSON applies with name entries and declared groups`() {
        val parsed = parseFusionPackJson(fusionJson)
        val valid = parsed as FusionPackParse.Valid
        assertEquals("My Fusion Pack", valid.packName)
        assertEquals(2, valid.declaredGroupCount)
        assertEquals("https://cdn.test/4k.png", valid.entries["4K"])
        assertEquals("https://cdn.test/atmos.png", valid.entries["Atmos"])
        // Unkeyable names may ride along; install skips them.
        assertEquals("https://cdn.test/nf.png", valid.entries["Netflix"])
    }

    @Test
    fun `group ids stand in when no groups array is declared`() {
        val json = """
            {"filters": [
              {"name": "4K", "imageURL": "https://cdn.test/4k.png", "groupId": "res"},
              {"name": "Atmos", "imageURL": "https://cdn.test/a.png", "groupId": "audio"},
              {"name": "DV", "imageURL": "https://cdn.test/dv.png", "groupId": "hdr"}
            ]}
        """.trimIndent()
        val valid = parseFusionPackJson(json) as FusionPackParse.Valid
        assertEquals(3, valid.declaredGroupCount)
        assertNull(valid.packName)
    }

    @Test
    fun `direct name to url map applies`() {
        val json = """{"1080p": "https://cdn.test/1080p.png", "BluRay": "https://cdn.test/br.png"}"""
        val valid = parseFusionPackJson(json) as FusionPackParse.Valid
        assertEquals(2, valid.entries.size)
        assertNull(valid.declaredGroupCount)
    }

    @Test
    fun `garbage pastes are rejected with a plain reason`() {
        assertTrue(parseFusionPackJson("") is FusionPackParse.Invalid)
        assertTrue(parseFusionPackJson("   ") is FusionPackParse.Invalid)
        assertTrue(parseFusionPackJson("not json at all") is FusionPackParse.Invalid)
        assertTrue(parseFusionPackJson("[1,2,3]") is FusionPackParse.Invalid)
        assertTrue(parseFusionPackJson("{}") is FusionPackParse.Invalid)
        assertTrue(parseFusionPackJson("""{"name": "Empty"}""") is FusionPackParse.Invalid)
        // Parses, has entries, but none of them is a badge streams use.
        val unkeyable = parseFusionPackJson(
            """{"Netflix": "https://cdn.test/nf.png", "IMAX": "https://cdn.test/imax.png"}"""
        )
        assertTrue(unkeyable is FusionPackParse.Invalid)
    }

    private fun source(id: String, keys: List<String>) = FusionBadgeSource(
        id = id, kind = FusionSourceKind.URL, label = id,
        locator = "https://$id.test/pack.json", badgeKeys = keys,
        groupCount = 1, addedAt = 1L
    )

    @Test
    fun `three sources max - add refuses a fourth, remove frees the slot`() {
        val a = source("a", listOf("res-2160p"))
        val b = source("b", listOf("res-1080p"))
        val c = source("c", listOf("atmos"))
        val d = source("d", listOf("hdr-dv"))
        val three = FusionBadgeSources.add(
            FusionBadgeSources.add(
                FusionBadgeSources.add(emptyList(), a)!!, b
            )!!, c
        )!!
        assertEquals(3, three.size)
        assertNull(FusionBadgeSources.add(three, d))
        // A duplicate id is refused too.
        assertNull(FusionBadgeSources.add(three, a))
        val freed = FusionBadgeSources.remove(three, "b")
        assertEquals(listOf(a, c), freed)
        assertEquals(listOf(a, c, d), FusionBadgeSources.add(freed, d))
    }

    @Test
    fun `replace keeps the source in its priority slot`() {
        val a = source("a", listOf("res-2160p"))
        val b = source("b", listOf("res-1080p"))
        val b2 = b.copy(badgeKeys = listOf("res-720p"), groupCount = 4)
        assertEquals(listOf(a, b2), FusionBadgeSources.replace(listOf(a, b), b2))
    }

    @Test
    fun `first source in list order owns each badge key`() {
        val owners = FusionBadgeSources.keyOwners(
            listOf(
                source("a", listOf("res-2160p", "atmos")),
                source("b", listOf("res-2160p", "hdr-dv")),
                source("c", listOf("atmos"))
            )
        )
        assertEquals(0, owners["res-2160p"])
        assertEquals(0, owners["atmos"])
        assertEquals(1, owners["hdr-dv"])
        assertEquals(3, owners.size)
    }

    @Test
    fun `group count falls back to distinct key families`() {
        assertEquals(
            3,
            FusionBadgeSources.groupCountFor(
                null, listOf("res-2160p", "res-1080p", "atmos", "audio-ddp", "audio-51")
            )
        )
        assertEquals(5, FusionBadgeSources.groupCountFor(5, listOf("res-2160p")))
        assertEquals(0, FusionBadgeSources.groupCountFor(null, emptyList()))
    }

    @Test
    fun `source list survives an encode decode round trip`() {
        val list = listOf(
            source("a", listOf("res-2160p")),
            FusionBadgeSource(
                id = "src-x", kind = FusionSourceKind.PASTE, label = "Pasted JSON",
                locator = null, badgeKeys = listOf("hdr-dv"), groupCount = 1, addedAt = 7L
            )
        )
        assertEquals(list, FusionBadgeSources.decode(FusionBadgeSources.encode(list)))
        assertEquals(emptyList<FusionBadgeSource>(), FusionBadgeSources.decode(null))
        assertEquals(emptyList<FusionBadgeSource>(), FusionBadgeSources.decode("garbage"))
        assertEquals(emptyList<FusionBadgeSource>(), FusionBadgeSources.decode(""))
    }

    @Test
    fun `legacy pack becomes source one`() {
        val legacy = FusionBadgeSources.legacySource(
            "Old Pack", listOf("res-2160p", "atmos"), addedAt = 3L
        )
        assertEquals(FusionBadgeSources.LEGACY_SOURCE_ID, legacy.id)
        assertEquals(FusionSourceKind.LEGACY, legacy.kind)
        assertEquals("Old Pack", legacy.label)
        assertNull(legacy.locator)
        assertEquals(2, legacy.badgeCount)
        assertEquals(
            "Imported pack",
            FusionBadgeSources.legacySource("", emptyList(), 0L).label
        )
    }

    @Test
    fun `clearing all sources returns the dressing to built-in Elite`() {
        assertEquals(BadgeStyle.ELITE, resolveBadgeStyle(fusionActive = false))
        assertEquals(BadgeStyle.IMPORTED, resolveBadgeStyle(fusionActive = true))
        // Elite is the only built-in — it is applied, never picked.
        assertEquals(listOf(BadgeStyle.ELITE), BadgeStyle.builtIns)
    }

    @Test
    fun `addon formatter output still outranks user dressing`() {
        // The priority seam: whatever Fusion sources exist, an
        // addon-formatted row is detected as formatter-shaped and
        // rendered raw (BadgeEliteOnlyTest pins the detector; the
        // render branch in StreamBrowser keys off this same call).
        val formatted = StreamItem(
            url = "https://example.test/x.mkv",
            name = "🌀 Plavio ❄️ 4K • HDHub4u",
            title = "🍿 Movie\n🎞️ 2160p • WEB-DL\n🛰️ Source: PlavioHD • HDHub4u\n💾 8.2 GB",
            sourceName = "PlavioHD"
        )
        assertTrue(isAddonFormatted(formatted))
    }
}
