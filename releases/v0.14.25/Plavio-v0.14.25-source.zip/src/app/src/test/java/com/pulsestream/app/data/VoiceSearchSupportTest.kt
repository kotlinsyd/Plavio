package com.pulsestream.app.data

import com.pulsestream.app.data.VoiceSearchSupport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Voice search seams (owner order 2026-10-31). The whole feature is
 * gated by these pure functions: if they hold, a voice failure can
 * never reach the typed search flow — the mic either renders and
 * hands over a clean string, or it might as well not exist.
 */
class VoiceSearchSupportTest {

    @Test
    fun micShowsOnlyWhenRecognitionResolvesAndPermissionNotDenied() {
        assertTrue(VoiceSearchSupport.micVisible(true, VoiceSearchSupport.PermissionState.GRANTED))
        assertTrue(VoiceSearchSupport.micVisible(true, VoiceSearchSupport.PermissionState.UNKNOWN))
        // No recognition service on the device → no mic, ever.
        assertFalse(VoiceSearchSupport.micVisible(false, VoiceSearchSupport.PermissionState.GRANTED))
        assertFalse(VoiceSearchSupport.micVisible(false, VoiceSearchSupport.PermissionState.UNKNOWN))
        // Denied (or revoked) → no mic, even with a service present.
        assertFalse(VoiceSearchSupport.micVisible(true, VoiceSearchSupport.PermissionState.DENIED))
        assertFalse(VoiceSearchSupport.micVisible(false, VoiceSearchSupport.PermissionState.DENIED))
    }

    @Test
    fun permissionStateDerivation() {
        assertEquals(
            VoiceSearchSupport.PermissionState.GRANTED,
            VoiceSearchSupport.permissionState(granted = true, askedBefore = false),
        )
        assertEquals(
            VoiceSearchSupport.PermissionState.GRANTED,
            VoiceSearchSupport.permissionState(granted = true, askedBefore = true),
        )
        // Never asked: UNKNOWN (tap will ask).
        assertEquals(
            VoiceSearchSupport.PermissionState.UNKNOWN,
            VoiceSearchSupport.permissionState(granted = false, askedBefore = false),
        )
        // Asked and refused — or granted once and later revoked: DENIED.
        assertEquals(
            VoiceSearchSupport.PermissionState.DENIED,
            VoiceSearchSupport.permissionState(granted = false, askedBefore = true),
        )
    }

    @Test
    fun firstResultPicksFirstUsableCandidateTrimmed() {
        assertEquals("mobland", VoiceSearchSupport.firstResult(listOf("mobland")))
        assertEquals("mob land", VoiceSearchSupport.firstResult(listOf("  mob land  ", "mobland")))
        // Blank candidates are skipped for a usable later one.
        assertEquals("dune", VoiceSearchSupport.firstResult(listOf("", "  ", "dune")))
    }

    @Test
    fun firstResultNullMeansLeaveTheQueryUntouched() {
        assertNull(VoiceSearchSupport.firstResult(null))
        assertNull(VoiceSearchSupport.firstResult(emptyList()))
        assertNull(VoiceSearchSupport.firstResult(listOf("", "   ")))
    }
}
