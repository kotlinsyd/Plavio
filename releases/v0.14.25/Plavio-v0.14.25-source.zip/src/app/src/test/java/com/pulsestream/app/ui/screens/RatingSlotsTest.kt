package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.MetaDetail
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.31 (item 6, ratings row S2): pins [ratingSlots] — the
 * locked slot rule the redesigned row renders. Exactly five
 * slots, priority IMDb, TMDB, Trakt, RT, Metacritic; a missing
 * one lets the next in line slide in (RT Audience, then
 * Letterboxd, then MDBList). Numbers keep today's format; TMDB's
 * 0–10 vote renders on the 0–100 scale as it always has.
 */
class RatingSlotsTest {

    private fun meta(
        imdb: String? = null,
        tmdb: String? = null,
        trakt: String? = null,
        rt: String? = null,
        metacritic: String? = null,
        rtAudience: String? = null,
        letterboxd: String? = null,
        mdblist: String? = null
    ) = MetaDetail(
        id = "tt0000000", type = "movie", name = "Fixture",
        imdbRating = imdb, tmdbRating = tmdb, traktRating = trakt,
        rtRating = rt, metacriticRating = metacritic,
        rtAudienceRating = rtAudience, letterboxdRating = letterboxd,
        mdblistRating = mdblist
    )

    private fun sources(slots: List<RatingSlot>) = slots.map { it.source }

    @Test
    fun `all eight present fills the locked five in priority order`() {
        val slots = ratingSlots(
            meta(imdb = "9.1", tmdb = "8.9", trakt = "89", rt = "94",
                metacritic = "85", rtAudience = "94", letterboxd = "4.5",
                mdblist = "84")
        )
        assertEquals(5, slots.size)
        assertEquals(
            listOf(RatingSource.IMDB, RatingSource.TMDB, RatingSource.TRAKT,
                RatingSource.RT, RatingSource.METACRITIC),
            sources(slots)
        )
        assertEquals(listOf("9.1", "89", "89", "94", "85"), slots.map { it.value })
    }

    @Test
    fun `missing tmdb slides rt audience in (the owner's Dark Knight case)`() {
        val slots = ratingSlots(
            meta(imdb = "9.1", trakt = "89", rt = "94",
                metacritic = "85", rtAudience = "94")
        )
        assertEquals(
            listOf(RatingSource.IMDB, RatingSource.TRAKT, RatingSource.RT,
                RatingSource.METACRITIC, RatingSource.RT_AUDIENCE),
            sources(slots)
        )
        assertEquals(listOf("9.1", "89", "94", "85", "94"), slots.map { it.value })
    }

    @Test
    fun `slide-in order is rt audience then letterboxd then mdblist`() {
        val slots = ratingSlots(
            meta(imdb = "8.0", letterboxd = "4.2", mdblist = "80",
                rtAudience = "91")
        )
        assertEquals(
            listOf(RatingSource.IMDB, RatingSource.RT_AUDIENCE,
                RatingSource.LETTERBOXD, RatingSource.MDBLIST),
            sources(slots)
        )
    }

    @Test
    fun `numbers keep today's format, never a percent sign`() {
        val slots = ratingSlots(meta(rt = "94", trakt = "89"))
        assertTrue(slots.all { !it.value.contains("%") })
        assertEquals("94", slots.first { it.source == RatingSource.RT }.value)
    }

    @Test
    fun `tmdb vote renders on the 0-100 scale as before`() {
        val slots = ratingSlots(meta(tmdb = "8.9"))
        assertEquals("89", slots.single().value)
        // An unparseable vote passes through as served (old behaviour).
        val raw = ratingSlots(meta(tmdb = "N/A"))
        assertEquals("N/A", raw.single().value)
    }

    @Test
    fun `blank ratings have no slot and empty meta yields no row`() {
        assertTrue(ratingSlots(meta()).isEmpty())
        assertTrue(ratingSlots(meta(imdb = " ", rt = "")).isEmpty())
        val slots = ratingSlots(meta(imdb = "7.4", rt = " "))
        assertEquals(listOf(RatingSource.IMDB), sources(slots))
    }

    @Test
    fun `every source carries its own icon and the wide marks are tmdb and letterboxd`() {
        // v0.14.32: the icons are the OFFICIAL brand marks. The
        // official IMDb mark is square; TMDB and Letterboxd are
        // the wide ones by nature.
        val icons = RatingSource.values().map { it.iconRes }
        assertEquals(icons.size, icons.toSet().size)
        assertTrue(RatingSource.TMDB.wide)
        assertTrue(RatingSource.LETTERBOXD.wide)
        assertTrue(
            RatingSource.values().all {
                it == RatingSource.TMDB || it == RatingSource.LETTERBOXD || !it.wide
            }
        )
    }

    // ---- v0.14.32: size + auto-fit rules (owner-locked) ----

    private fun fiveSlots() = ratingSlots(
        meta(imdb = "9.1", tmdb = "8.9", trakt = "89", rt = "94", metacritic = "85")
    )

    @Test
    fun `icon height is 18dp and nothing draws wider than 32dp`() {
        RatingSource.values().forEach { source ->
            val (w, h) = source.iconSizeDp()
            assertTrue("height of $source", h <= RATING_ICON_HEIGHT_DP + 0.001f)
            assertTrue("width of $source", w <= RATING_ICON_MAX_WIDTH_DP + 0.001f)
        }
        // Square marks draw at the full 18dp height.
        assertEquals(18f to 18f, RatingSource.IMDB.iconSizeDp())
        // Letterboxd is the widest mark: it caps at 32dp wide
        // and shrinks in height to stay whole.
        val (lw, lh) = RatingSource.LETTERBOXD.iconSizeDp()
        assertEquals(RATING_ICON_MAX_WIDTH_DP, lw, 0.01f)
        assertTrue(lh < RATING_ICON_HEIGHT_DP)
        // Natural proportion is never distorted.
        RatingSource.values().forEach { source ->
            val (w, h) = source.iconSizeDp()
            assertEquals(source.aspect, w / h, 0.01f)
        }
    }

    @Test
    fun `all five fit on a normal phone width`() {
        assertEquals(5, ratingFitCount(fiveSlots(), 320f))
    }

    @Test
    fun `tight width drops from the end of the slot order`() {
        val slots = fiveSlots()
        // The five icons (18 + 25 + 18 + 18 + 18) plus four 16dp
        // gaps need ~161dp in total; 150dp fits only four.
        assertEquals(4, ratingFitCount(slots, 150f))
        assertEquals(
            listOf(RatingSource.IMDB, RatingSource.TMDB, RatingSource.TRAKT, RatingSource.RT),
            sources(slots.take(ratingFitCount(slots, 150f)))
        )
        // 120dp fits only three.
        assertEquals(3, ratingFitCount(slots, 120f))
    }

    @Test
    fun `fit count never exceeds the slots and zero when nothing fits`() {
        val slots = fiveSlots()
        assertEquals(5, ratingFitCount(slots, 10_000f))
        assertEquals(0, ratingFitCount(slots, 4f))
        assertEquals(0, ratingFitCount(emptyList(), 320f))
    }
}
