package com.pulsestream.app.ui.screens.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.36 (item 4 + owner's amendment): the loading overlay's
 * title name. The title LOGO shows clear (no wash/shade/panel —
 * the seam decides show/fallback only; the overlay renders it as
 * a plain image) in the heroes' size language; the styled title
 * text is the fallback, including on load failure. And the
 * breathing moved: the heartbeat animates the NAME, the backdrop
 * poster is static — with the lub-dub curve itself untouched.
 */
class PlayerLoadingLogoTest {

    @Test
    fun `logo shows only when a logo exists and has not failed`() {
        assertTrue(playerLoadingLogoShown("https://cdn.test/logo.png", loadFailed = false))
        assertFalse(playerLoadingLogoShown(null, loadFailed = false))
        assertFalse(playerLoadingLogoShown("", loadFailed = false))
        assertFalse(playerLoadingLogoShown("   ", loadFailed = false))
        // A failed load falls back to the styled title text.
        assertFalse(playerLoadingLogoShown("https://cdn.test/logo.png", loadFailed = true))
    }

    @Test
    fun `logo size matches the heroes`() {
        assertEquals(76, LOADING_LOGO_HEIGHT_DP)
        assertEquals(300, LOADING_LOGO_MAX_WIDTH_DP)
    }

    @Test
    fun `the backdrop never breathes`() {
        // Whatever the heartbeat is doing, the poster scale is 1f.
        assertEquals(1f, playerLoadingBackdropScale(1f))
        assertEquals(1f, playerLoadingBackdropScale(1.028f))
        assertEquals(1f, playerLoadingBackdropScale(1.040f))
        assertEquals(1f, playerLoadingBackdropScale(0.99f))
    }

    @Test
    fun `the name carries the beat unchanged`() {
        assertEquals(1f, playerLoadingNameScale(1f))
        assertEquals(1.028f, playerLoadingNameScale(1.028f))
        assertEquals(1.040f, playerLoadingNameScale(1.040f))
        assertEquals(1.010f, playerLoadingNameScale(1.010f))
    }

    @Test
    fun `the lub-dub curve itself is untouched`() {
        assertEquals(3200, HEARTBEAT_CYCLE_MS)
        assertEquals(1.028f, HEARTBEAT_KEYFRAMES.first { it.first == 224 }.second)
        assertEquals(1.040f, HEARTBEAT_KEYFRAMES.first { it.first == 704 }.second)
        assertEquals(1.040f, HEARTBEAT_KEYFRAMES.maxOf { it.second })
        assertEquals(1.000f, HEARTBEAT_KEYFRAMES.first().second)
        assertEquals(1.000f, HEARTBEAT_KEYFRAMES.last().second)
    }
}
