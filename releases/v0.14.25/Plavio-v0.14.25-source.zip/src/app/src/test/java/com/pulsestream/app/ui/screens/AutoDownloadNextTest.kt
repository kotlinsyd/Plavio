package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.MetaDetail
import com.pulsestream.app.data.Video
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * v0.14.39 (Auto-download next episode): pins the episode finder
 * the player's end-of-episode trigger resolves through — exact
 * (season, episode) match out of the series meta's video list,
 * nothing when the episode is absent.
 */
class AutoDownloadNextTest {

    private fun seriesMeta() = MetaDetail(
        id = "tt0903747", type = "series", name = "Fixture Show",
        videos = listOf(
            Video(id = "tt0903747:1:1", title = "Pilot", season = 1, episode = 1),
            Video(id = "tt0903747:1:2", title = "Second", season = 1, episode = 2),
            Video(id = "tt0903747:2:1", title = "Return", season = 2, episode = 1)
        )
    )

    @Test
    fun `finds the exact next episode`() {
        val found = AutoDownloadNext.findEpisode(seriesMeta(), season = 1, episode = 2)
        assertEquals("tt0903747:1:2", found?.id)
    }

    @Test
    fun `finds the season opener after a finale`() {
        val found = AutoDownloadNext.findEpisode(seriesMeta(), season = 2, episode = 1)
        assertEquals("Return", found?.title)
    }

    @Test
    fun `missing episode resolves to nothing`() {
        assertNull(AutoDownloadNext.findEpisode(seriesMeta(), season = 3, episode = 1))
        assertNull(AutoDownloadNext.findEpisode(seriesMeta(), season = 0, episode = 0))
    }
}
