package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

/**
 * v0.14.39 (Upcoming fold): pins the pure rules of the Upcoming
 * list that moved from the Library into the Up Next screen — the
 * day badge, the next-unaired-episode pick, and the air-date
 * parse. The scan itself rides the repository and is not unit
 * tested here.
 */
class UpcomingSupportTest {

    private val today: LocalDate = LocalDate.of(2026, 11, 13) // a Friday

    private fun ep(season: Int, episode: Int, date: LocalDate, title: String? = null) =
        UpcomingSupport.EpDate(season, episode, title, date)

    @Test
    fun `badge for tomorrow says Tomorrow`() {
        assertEquals("Tomorrow", UpcomingSupport.badgeFor(today, today.plusDays(1)))
    }

    @Test
    fun `badge inside a week shows the weekday and date`() {
        // 2026-11-16 is a Monday, 3 days out.
        assertEquals("Mon 16 Nov", UpcomingSupport.badgeFor(today, today.plusDays(3)))
        // 7 days out still uses the weekday form.
        assertEquals("Fri 20 Nov", UpcomingSupport.badgeFor(today, today.plusDays(7)))
    }

    @Test
    fun `badge beyond a week counts the days`() {
        assertEquals("in 8 days", UpcomingSupport.badgeFor(today, today.plusDays(8)))
        assertEquals("in 30 days", UpcomingSupport.badgeFor(today, today.plusDays(30)))
    }

    @Test
    fun `next episode is the soonest strictly after today`() {
        val eps = listOf(
            ep(1, 1, today.minusDays(7)),
            ep(1, 2, today),
            ep(1, 3, today.plusDays(10)),
            ep(1, 4, today.plusDays(3))
        )
        val next = UpcomingSupport.pickNextEpisode(eps, today)
        assertEquals(4, next?.episode)
        assertEquals(today.plusDays(3), next?.date)
    }

    @Test
    fun `no future episode means no pick`() {
        val eps = listOf(ep(1, 1, today.minusDays(1)), ep(1, 2, today))
        assertNull(UpcomingSupport.pickNextEpisode(eps, today))
        assertNull(UpcomingSupport.pickNextEpisode(emptyList(), today))
    }

    @Test
    fun `air date parses the first ten chars of released`() {
        assertEquals(
            LocalDate.of(2026, 12, 1),
            UpcomingSupport.airDateOf("2026-12-01T20:00:00.000Z")
        )
        assertEquals(LocalDate.of(2026, 1, 5), UpcomingSupport.airDateOf("2026-01-05"))
    }

    @Test
    fun `air date rejects blank and garbage`() {
        assertNull(UpcomingSupport.airDateOf(null))
        assertNull(UpcomingSupport.airDateOf(""))
        assertNull(UpcomingSupport.airDateOf("not-a-date"))
        assertNull(UpcomingSupport.airDateOf("2026-13-40"))
    }
}
