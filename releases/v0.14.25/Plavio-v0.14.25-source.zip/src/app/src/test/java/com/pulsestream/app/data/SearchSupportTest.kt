package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchSupportTest {

    private fun meta(
        id: String,
        name: String,
        type: String = "movie",
        year: String? = null,
        rating: String? = null,
        popularity: Double = 0.0,
        poster: String? = null,
        background: String? = null
    ) = MetaPreview(
        id = id, type = type, name = name, poster = poster, background = background,
        releaseInfo = year, imdbRating = rating, popularity = popularity
    )

    private fun cm(addonId: String, meta: MetaPreview) =
        CachedMeta(addonId = addonId, addonName = addonId, baseUrl = "", meta = meta)

    @Test
    fun `empty primary never discards the floor and empty floor never discards the primary`() {
        val floor = listOf(cm("addon-a", meta("tt1", "Babes", year = "2024")))
        assertEquals(floor, SearchSupport.mergeByIdentity(emptyList(), floor))
        val primary = listOf(
            cm(SearchSupport.PRIMARY_ADDON_ID, meta("tt2", "Dune", year = "2021", popularity = 48.0))
        )
        assertEquals(primary, SearchSupport.mergeByIdentity(primary, emptyList()))
    }

    @Test
    fun `union keeps floor-only rows and primary fields win an identity collision`() {
        val primary = listOf(
            cm(
                SearchSupport.PRIMARY_ADDON_ID,
                meta("tt1160419", "Dune", year = "2021", rating = "7.8", popularity = 48.0, poster = "primary-poster")
            )
        )
        val floor = listOf(
            cm(
                "addon-a",
                meta("tt1160419", "Dune", year = "2021", rating = "8.0", poster = "floor-poster", background = "floor-bg")
            ),
            cm("addon-a", meta("tt999", "Floor Only Title", year = "1999"))
        )
        val merged = SearchSupport.mergeByIdentity(primary, floor)
        assertEquals(2, merged.size)
        val dune = merged.first { it.meta.id == "tt1160419" }
        assertEquals(SearchSupport.PRIMARY_ADDON_ID, dune.addonId)
        assertEquals("primary-poster", dune.meta.poster)
        assertEquals("7.8", dune.meta.imdbRating)
        // A field the primary lacks is filled from the floor copy.
        assertEquals("floor-bg", dune.meta.background)
        assertEquals(48.0, dune.meta.popularity, 0.001)
        assertTrue(merged.any { it.meta.id == "tt999" })
    }

    @Test
    fun `tmdb identity canonicalises across id spellings`() {
        val primary = listOf(
            cm(SearchSupport.TMDB_ADDON_ID, meta("tmdb:tv:1399", "Game of Thrones", type = "series", popularity = 90.0))
        )
        val floor = listOf(
            cm("addon-a", meta("tmdb:1399", "Game of Thrones", type = "series", poster = "floor-poster"))
        )
        val merged = SearchSupport.mergeByIdentity(primary, floor)
        assertEquals(1, merged.size)
        assertEquals("floor-poster", merged.single().meta.poster)
        assertEquals(90.0, merged.single().meta.popularity, 0.001)
    }

    @Test
    fun `popularity breaks an exact-title tie before imdb rating`() {
        val obscureShort = cm(
            "addon-a",
            meta("tt12451788", "Dune", year = "2020", rating = "9.5", popularity = 1.9)
        )
        val famous = cm(
            SearchSupport.PRIMARY_ADDON_ID,
            meta("tt1160419", "Dune", year = "2021", rating = "7.8", popularity = 48.4)
        )
        val ranked = SearchSupport.rank(listOf(obscureShort, famous), "Dune")
        assertEquals(listOf("2021", "2020"), ranked.map { it.meta.releaseInfo })
    }

    @Test
    fun `match tier still beats popularity`() {
        val exactLowPopularity = cm("addon-a", meta("tt1", "Dune", year = "1984", popularity = 15.0))
        val prefixHighPopularity = cm(
            SearchSupport.PRIMARY_ADDON_ID,
            meta("tt2", "Dune: Part Two", year = "2024", popularity = 72.0)
        )
        val ranked = SearchSupport.rank(listOf(prefixHighPopularity, exactLowPopularity), "Dune")
        assertEquals("Dune", ranked.first().meta.name)
    }

    @Test
    fun `same title and year from two lanes collapses to one primary-led row`() {
        val primary = cm(
            SearchSupport.PRIMARY_ADDON_ID,
            meta("tt21276958", "Babes", year = "2024", popularity = 6.5, poster = "primary-poster")
        )
        val floor = cm(
            "addon-a",
            meta("tt21276958", "Babes", year = "2024", rating = "6.0", poster = "floor-poster", background = "floor-bg")
        )
        val ranked = SearchSupport.rank(listOf(floor, primary), "Babes")
        assertEquals(1, ranked.size)
        assertEquals("primary-poster", ranked.single().meta.poster)
        assertEquals("floor-bg", ranked.single().meta.background)
        assertEquals(6.5, ranked.single().meta.popularity, 0.001)
    }

    @Test
    fun `remakes with conflicting years are never merged`() {
        val original = cm("addon-a", meta("tt0070511", "Papillon", year = "1973", popularity = 7.5))
        val remake = cm("addon-a", meta("tt5093026", "Papillon", year = "2017", popularity = 7.1))
        val ranked = SearchSupport.rank(listOf(remake, original), "Papillon")
        assertEquals(2, ranked.size)
        assertEquals("1973", ranked.first().meta.releaseInfo)
    }

    @Test
    fun `exact cache entry seeds whole and prefix relative seeds only relevant rows`() {
        val now = 100_000L
        val babeResults = listOf(
            cm("addon-a", meta("tt0112431", "Babe", year = "1995")),
            cm("addon-a", meta("tt21276958", "Babes", year = "2024")),
            cm("addon-a", meta("tt000", "Unrelated", year = "2000"))
        )
        val entries = listOf(
            SearchSupport.QueryCacheEntry("scope", "all", "babe", now, babeResults)
        )
        val exact = SearchSupport.cacheSeed(entries, "scope", "all", "Babe", now, 60_000L)
        assertEquals(3, exact.size)
        val prefix = SearchSupport.cacheSeed(entries, "scope", "all", "Babes", now, 60_000L)
        // Prefix-relative seed: rows still relevant to "Babes" (the
        // prefix title "Babe" and "Babes" itself); the unrelated row
        // from the shorter query's page is not carried over.
        assertEquals(listOf("Babe", "Babes"), prefix.map { it.meta.name })
        val stale = SearchSupport.cacheSeed(entries, "scope", "all", "Babes", now + 120_000L, 60_000L)
        assertTrue(stale.isEmpty())
        val otherScope = SearchSupport.cacheSeed(entries, "other", "all", "Babes", now, 60_000L)
        assertTrue(otherScope.isEmpty())
    }

    @Test
    fun `correction candidate normalises punctuation and spacing`() {
        assertEquals(
            "dune part three",
            SearchSupport.correctionCandidate("Dune:  Part-Three", emptyList())
        )
    }

    @Test
    fun `correction candidate uses one edit distance one dictionary word`() {
        assertEquals(
            "babes",
            SearchSupport.correctionCandidate("Bebes", listOf("Babes", "Babies"))
        )
        // No nearby real title word on record -> no fabricated guess.
        assertNull(SearchSupport.correctionCandidate("Bebes", listOf("Completely Different")))
        // Short queries are out of scope.
        assertNull(SearchSupport.correctionCandidate("Be", listOf("Babes")))
    }

    @Test
    fun `edit distance counts substitution and transposition as one`() {
        assertEquals(1, SearchSupport.editDistance("bebes", "babes"))
        assertEquals(1, SearchSupport.editDistance("dune", "duen"))
        assertEquals(0, SearchSupport.editDistance("dune", "dune"))
        assertTrue(SearchSupport.editDistance("bebes", "completely") > 1)
    }

    // ---- MobLand (device evidence, 2026-10-31) ----------------------
    // Keyed device lanes for query "MobLand", as actually shaped:
    // TMDB primary (tmdb:tv:247718, 2025, 8.6, pop 314.1); Cinemeta
    // series/top (tt31510819, "2025-", no rating); PMeta floor catalog
    // (tt31510819, 2025, 8.6, pop 314.1); Cinemeta movie/top ALSO
    // returns a yearless namesake movie (tt15379560, no rating, no
    // popularity — a different work with no discriminating signal).

    private fun mobLandSeriesPrimary() = cm(
        SearchSupport.TMDB_ADDON_ID,
        meta(
            "tmdb:tv:247718", "MobLand", type = "series", year = "2025",
            rating = "8.6", popularity = 314.1, poster = "tmdb-poster"
        )
    )

    private fun mobLandCinemetaSeries() = cm(
        "com.linvo.cinemeta",
        meta("tt31510819", "MobLand", type = "series", year = "2025-", poster = "amazon-poster")
    )

    private fun mobLandPmetaFloor() = cm(
        "com.plavio.catalogs",
        meta(
            "tt31510819", "MobLand", type = "series", year = "2025",
            rating = "8.6", popularity = 314.1, poster = "pmeta-poster"
        )
    )

    private fun mobLandGhostMovie() = cm(
        "com.linvo.cinemeta",
        meta("tt15379560", "MobLand", type = "movie", poster = "ghost-poster")
    )

    private fun mobLand2023Control() = cm(
        "com.plavio.catalogs",
        meta("tt20424130", "Mob Land", type = "movie", year = "2023", rating = "5.5", poster = "travolta-poster")
    )

    private fun rankedUnion(
        primary: List<CachedMeta>,
        floor: List<CachedMeta>,
        query: String
    ): List<CachedMeta> =
        SearchSupport.rank(SearchSupport.mergeByIdentity(primary, floor), query)

    @Test
    fun `mobland tmdb lane and tt lane collapse to one primary led card`() {
        val ranked = rankedUnion(
            listOf(mobLandSeriesPrimary()),
            listOf(mobLandCinemetaSeries(), mobLandPmetaFloor()),
            "MobLand"
        )
        assertEquals(1, ranked.size)
        val card = ranked.single()
        assertEquals(SearchSupport.TMDB_ADDON_ID, card.addonId)
        assertEquals("tmdb-poster", card.meta.poster)
        assertEquals("8.6", card.meta.imdbRating)
        assertEquals(314.1, card.meta.popularity, 0.001)
    }

    @Test
    fun `mobland full device set folds the signalless yearless namesake and keeps mob land 2023 separate`() {
        val ranked = rankedUnion(
            listOf(mobLandSeriesPrimary()),
            listOf(
                mobLandCinemetaSeries(), mobLandPmetaFloor(),
                mobLandGhostMovie(), mobLand2023Control()
            ),
            "MobLand"
        )
        // One "MobLand" card (the series, primary-led) + the distinct
        // "Mob Land" (2023) control. The yearless movie namesake has no
        // year, no rating and no popularity — nothing that identifies
        // it as a separate work — so it folds into the anchored card.
        assertEquals(2, ranked.size)
        val series = ranked.first { it.meta.name == "MobLand" }
        assertEquals(SearchSupport.TMDB_ADDON_ID, series.addonId)
        assertEquals("tmdb-poster", series.meta.poster)
        assertEquals("8.6", series.meta.imdbRating)
        assertEquals(314.1, series.meta.popularity, 0.001)
        val control = ranked.first { it.meta.name == "Mob Land" }
        assertEquals("tt20424130", control.meta.id)
        assertEquals("2023", control.meta.releaseInfo)
    }

    @Test
    fun `anchored same name movie and series both stay`() {
        val movie = cm("addon-a", meta("tt0109830", "Fargo", type = "movie", year = "1996", rating = "8.8"))
        val series = cm("addon-a", meta("tt2802850", "Fargo", type = "series", year = "2014", rating = "8.9"))
        val ranked = SearchSupport.rank(listOf(movie, series), "Fargo")
        assertEquals(2, ranked.size)
    }

    @Test
    fun `yearless namesake carrying a rating does not fold`() {
        val obscureRated = cm(
            "com.linvo.cinemeta",
            meta("tt15379560", "MobLand", type = "movie", rating = "6.1", poster = "ghost-poster")
        )
        val ranked = rankedUnion(
            listOf(mobLandSeriesPrimary()),
            listOf(obscureRated),
            "MobLand"
        )
        // A rating is a real signal of a distinct work: the yearless
        // movie keeps its own card even beside the hit series.
        assertEquals(2, ranked.size)
        assertTrue(ranked.any { it.meta.id == "tt15379560" })
    }

    @Test
    fun `tmdb popularity signals attach by title type and year`() {
        val previews = listOf(
            MetaPreview(id = "tmdb:movie:438631", type = "movie", name = "Dune"),
            MetaPreview(id = "tmdb:movie:697620", type = "movie", name = "Dune", releaseInfo = "2020")
        )
        val hits = listOf(
            TmdbClient.TmdbSearchHit(
                title = "Dune", type = "movie", year = 2021,
                popularity = 48.4, voteAverage = 7.8, voteCount = 100
            ),
            TmdbClient.TmdbSearchHit(
                title = "Dune", type = "movie", year = 2020,
                popularity = 1.9, voteAverage = 7.4, voteCount = 10
            )
        )
        val attached = TmdbClient.attachPopularity(previews, hits)
        // The year-less preview takes the first confident (2021) hit;
        // the 2020 preview keeps its own year's signal.
        assertEquals(48.4, attached[0].popularity, 0.001)
        assertEquals("2021", attached[0].releaseInfo)
        assertEquals(1.9, attached[1].popularity, 0.001)
    }

    // ---- v0.14.28: zero rating, lane independence, Maula Jatt ----

    @Test
    fun `zero rating is no rating`() {
        // TMDB vote_average 0 means zero votes; MDBList likewise
        // reports 0.0 for unrated titles. Neither is a rating.
        assertNull(SearchSupport.ratingOf("0.0"))
        assertNull(SearchSupport.ratingOf("0"))
        assertNull(SearchSupport.ratingOf(null))
        assertNull(SearchSupport.ratingOf(""))
        assertEquals(8.1, SearchSupport.ratingOf("8.1")!!, 0.001)
        assertEquals(9.7, SearchSupport.ratingOf("9.7/10")!!, 0.001)
    }

    @Test
    fun `yearless namesake with a zero rating still folds`() {
        // A "0.0" is not a signal (see ratingOf), so the ghost stays
        // bare and folds exactly like the signal-less original.
        val zeroRatedGhost = cm(
            "com.linvo.cinemeta",
            meta("tt15379560", "MobLand", type = "movie", rating = "0.0", poster = "ghost-poster")
        )
        val ranked = rankedUnion(
            listOf(mobLandSeriesPrimary()),
            listOf(zeroRatedGhost),
            "MobLand"
        )
        assertEquals(1, ranked.size)
        assertEquals(SearchSupport.TMDB_ADDON_ID, ranked.single().addonId)
    }

    @Test
    fun `keyless primary lane is a first party constant independent of any addon`() {
        // Owner's hard requirement (2026-10-31): no TMDB key AND PMeta
        // removed must still search. The lane's URL builder takes ONLY
        // the query — there is no addon-registry input it could be
        // gated on — and the URL is the first-party domain constant,
        // never an installed addon's stored baseUrl.
        assertEquals(
            "https://meta.plavio.site/search.json?q=Maula+Jatt",
            SearchSupport.keylessSearchUrl("Maula Jatt")
        )
        assertTrue(SearchSupport.keylessSearchUrl("MobLand").startsWith("https://meta.plavio.site/"))
        // Both own-machinery lanes share the one display name the user
        // ever sees; the engines behind them are invisible.
        assertEquals("Plavio Search", SearchSupport.PRIMARY_SEARCH_NAME)
    }

    // The owner's "Maula Jatt" screenshot quartet, shaped from the
    // live payloads: TMDB /search/multi (keyed lane) + the PMeta
    // floor row for "Maulavi Master" (tt10644574, 2019, whose TMDB
    // vote_average is 0.0 — the "★ 0.0" card).
    private fun maulaJattPrimary() = cm(
        SearchSupport.TMDB_ADDON_ID,
        meta("tmdb:movie:170078", "Maula Jatt", year = "1979", rating = "9.7", popularity = 1.18, poster = "mj-poster")
    )

    private fun legendPrimary() = cm(
        SearchSupport.TMDB_ADDON_ID,
        meta(
            "tmdb:movie:464293", "The Legend of Maula Jatt", year = "2022",
            rating = "8.1", popularity = 2.55, poster = "legend-poster", background = "legend-bg"
        )
    )

    private fun juanMaulaPrimary() = cm(
        SearchSupport.TMDB_ADDON_ID,
        meta("tmdb:movie:728979", "Juan Maula y el Garrudo", year = "1966", popularity = 0.62)
    )

    private fun maulaviFloor() = cm(
        "com.plavio.catalogs",
        meta("tt10644574", "Maulavi Master", year = "2019", rating = "0.0", poster = "maulavi-poster")
    )

    @Test
    fun `maula jatt settled order keeps the strong contains match above the zero signal near miss`() {
        val ranked = rankedUnion(
            listOf(maulaJattPrimary(), legendPrimary(), juanMaulaPrimary()),
            listOf(maulaviFloor()),
            "Maula Jatt"
        )
        // Settled "Maula Jatt": exact title first, then the contains
        // match (tier 2) — the "maula"-prefix near-miss is tier 3 and
        // CANNOT outrank it in any emission computed for this query,
        // whatever its popularity. (Live payloads add a fifth row,
        // "Jatt in London", tier 3 at pop 1.07, slotting third.)
        assertEquals(
            listOf("Maula Jatt", "The Legend of Maula Jatt", "Juan Maula y el Garrudo", "Maulavi Master"),
            ranked.map { it.meta.name }
        )
    }

    @Test
    fun `maula prefix query reproduces the owner screenshot order exactly`() {
        // The screenshot's order is the SETTLED order for the shorter
        // query "Maula" (the state on screen while "Jatt" was being
        // added): "Maulavi Master" legitimately prefix-matches
        // "maula" (tier 1) there, ahead of the contains-tier Legend.
        val ranked = rankedUnion(
            listOf(maulaJattPrimary(), legendPrimary(), juanMaulaPrimary()),
            listOf(maulaviFloor()),
            "Maula"
        )
        assertEquals(
            listOf("Maula Jatt", "Maulavi Master", "The Legend of Maula Jatt", "Juan Maula y el Garrudo"),
            ranked.map { it.meta.name }
        )
    }
}
