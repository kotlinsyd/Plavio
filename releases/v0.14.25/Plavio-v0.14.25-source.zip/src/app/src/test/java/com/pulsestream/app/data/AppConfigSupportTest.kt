package com.pulsestream.app.data

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * AppConfig (remote control file) — the pure rules: parse, garbage
 * fallback, door host validation, switch defaults, priority order.
 * The prime directive under test: anything absent, unreachable, or
 * malformed resolves to the compiled-in defaults, which reproduce
 * the pre-config behaviour exactly.
 */
class AppConfigSupportTest {

    @After
    fun resetSearchDoor() {
        // The SearchSupport door override is process-global; a test
        // that sets it must never leak it into another test.
        SearchSupport.searchDoorOverride = null
    }

    /** The published contract (PMeta half), verbatim shape. */
    private val contractJson = """
        {
          "version": 1,
          "doors": {
            "pmeta": "https://meta.plavio.site",
            "plaviohd": "https://hd.plavio.site",
            "search": "https://meta.plavio.site/search.json"
          },
          "announcement": null,
          "minVersionCode": 187,
          "switches": { "warmTriggers": true, "searchIndex": true }
        }
    """.trimIndent()

    @Test
    fun `contract fixture parses fully`() {
        val parsed = AppConfigSupport.parse(contractJson)!!
        assertEquals("https://meta.plavio.site", parsed.pmetaDoor)
        assertEquals("https://hd.plavio.site", parsed.plaviohdDoor)
        assertEquals("https://meta.plavio.site/search.json", parsed.searchDoor)
        assertNull(parsed.announcement)
        assertEquals(187, parsed.minVersionCode)
        assertEquals(true, parsed.switches["warmTriggers"])
        assertEquals(true, parsed.switches["searchIndex"])
        // A contract-shaped config changes no effective door: every
        // resolver lands on the compiled default it already names.
        assertEquals(AppConfigSupport.DEFAULT_PMETA_DOOR, AppConfigSupport.pmetaDoor(parsed))
        assertEquals(AppConfigSupport.DEFAULT_SEARCH_DOOR, AppConfigSupport.searchDoor(parsed))
        assertEquals(
            "https://meta.plavio.site/manifest.json",
            AppConfigSupport.pmetaManifestUrl(parsed)
        )
    }

    @Test
    fun `garbage bodies parse to null so last-good survives`() {
        assertNull(AppConfigSupport.parse("not json at all"))
        assertNull(AppConfigSupport.parse(""))
        assertNull(AppConfigSupport.parse("[1,2,3]"))
        assertNull(AppConfigSupport.parse("null"))
        assertNull(AppConfigSupport.parse("{\"doors\":"))
    }

    @Test
    fun `empty object is a valid config that changes nothing`() {
        val parsed = AppConfigSupport.parse("{}")!!
        assertEquals(AppConfigSupport.EMPTY, parsed)
        assertEquals(AppConfigSupport.DEFAULT_PMETA_DOOR, AppConfigSupport.pmetaDoor(parsed))
        assertEquals(AppConfigSupport.DEFAULT_SEARCH_DOOR, AppConfigSupport.searchDoor(parsed))
        assertEquals(0, parsed.minVersionCode)
        assertNull(parsed.announcement)
    }

    @Test
    fun `config door wins over the compiled default`() {
        val parsed = AppConfigSupport.parse(
            """{"doors":{"pmeta":"https://pmeta2.plavio.site","search":"https://pmeta2.plavio.site/search.json"}}"""
        )!!
        assertEquals("https://pmeta2.plavio.site", AppConfigSupport.pmetaDoor(parsed))
        assertEquals("https://pmeta2.plavio.site/search.json", AppConfigSupport.searchDoor(parsed))
        assertEquals(
            "https://pmeta2.plavio.site/manifest.json",
            AppConfigSupport.pmetaManifestUrl(parsed)
        )
        // A door the config never set stays unset (stored tier decides).
        assertNull(parsed.plaviohdDoor)
    }

    @Test
    fun `hostile or broken doors are dropped one by one`() {
        val parsed = AppConfigSupport.parse(
            """
            {"doors":{
              "pmeta":"https://evil.example.com",
              "plaviohd":"http://hd.plavio.site",
              "search":"https://meta.plavio.site.evil.com/search.json"
            }}
            """.trimIndent()
        )!!
        assertNull(parsed.pmetaDoor)
        assertNull(parsed.plaviohdDoor)
        assertNull(parsed.searchDoor)
        // …and each falls back to its compiled default at resolution.
        assertEquals(AppConfigSupport.DEFAULT_PMETA_DOOR, AppConfigSupport.pmetaDoor(parsed))
        assertEquals(AppConfigSupport.DEFAULT_SEARCH_DOOR, AppConfigSupport.searchDoor(parsed))
    }

    @Test
    fun `door validation accepts only first-party https hosts`() {
        assertEquals("https://meta.plavio.site", AppConfigSupport.validDoorOrNull("https://meta.plavio.site"))
        assertEquals("https://eu.plavio.site", AppConfigSupport.validDoorOrNull("https://eu.plavio.site/"))
        assertEquals("https://plavio.site", AppConfigSupport.validDoorOrNull("https://plavio.site"))
        assertEquals(
            "https://plaviometa.vercel.app",
            AppConfigSupport.validDoorOrNull("https://plaviometa.vercel.app")
        )
        // Suffix attack: our domain as a subdomain of a hostile host.
        assertNull(AppConfigSupport.validDoorOrNull("https://meta.plavio.site.evil.com"))
        assertNull(AppConfigSupport.validDoorOrNull("https://notplavio.site"))
        // Scheme, credentials, fragments, blanks, non-URLs.
        assertNull(AppConfigSupport.validDoorOrNull("http://meta.plavio.site"))
        assertNull(AppConfigSupport.validDoorOrNull("https://user:pass@meta.plavio.site"))
        assertNull(AppConfigSupport.validDoorOrNull("https://meta.plavio.site/#x"))
        assertNull(AppConfigSupport.validDoorOrNull(""))
        assertNull(AppConfigSupport.validDoorOrNull("meta.plavio.site"))
        assertNull(AppConfigSupport.validDoorOrNull(null))
    }

    @Test
    fun `announcement needs id title and body`() {
        val withAnnouncement = AppConfigSupport.parse(
            """{"announcement":{"id":"a1","title":"Hello","body":"World"}}"""
        )!!
        assertEquals(
            AppConfigSupport.Announcement("a1", "Hello", "World"),
            withAnnouncement.announcement
        )
        // Missing a field drops ONLY the announcement.
        val missingBody = AppConfigSupport.parse(
            """{"announcement":{"id":"a1","title":"Hello"},"minVersionCode":190}"""
        )!!
        assertNull(missingBody.announcement)
        assertEquals(190, missingBody.minVersionCode)
        // A non-object announcement is ignored the same way.
        assertNull(AppConfigSupport.parse("""{"announcement":"a1"}""")!!.announcement)
    }

    @Test
    fun `minVersionCode accepts only positive whole numbers`() {
        fun floor(json: String) = AppConfigSupport.parse(json)!!.minVersionCode
        assertEquals(200, floor("""{"minVersionCode":200}"""))
        assertEquals(0, floor("""{"minVersionCode":"200"}"""))
        assertEquals(0, floor("""{"minVersionCode":200.5}"""))
        assertEquals(0, floor("""{"minVersionCode":-3}"""))
        assertEquals(0, floor("""{"minVersionCode":0}"""))
        assertEquals(0, floor("""{}"""))
    }

    @Test
    fun `switches keep booleans only and default when absent`() {
        val parsed = AppConfigSupport.parse(
            """{"switches":{"warmTriggers":false,"searchIndex":"yes","futureThing":true}}"""
        )!!
        assertEquals(false, parsed.switches["warmTriggers"])
        assertNull(parsed.switches["searchIndex"])
        assertEquals(true, parsed.switches["futureThing"])
        assertFalse(AppConfigSupport.switchEnabled(parsed, "warmTriggers", default = true))
        assertTrue(AppConfigSupport.switchEnabled(parsed, "searchIndex", default = true))
        assertFalse(AppConfigSupport.switchEnabled(parsed, "neverPublished", default = false))
        // The no-config state defaults everything.
        assertTrue(
            AppConfigSupport.switchEnabled(
                AppConfigSupport.EMPTY, AppConfigSupport.SWITCH_WARM_TRIGGERS, default = true
            )
        )
    }

    @Test
    fun `keyless search url follows the pushed config door`() {
        // Default (no config): byte-identical to the pre-config lane.
        assertEquals(
            "https://meta.plavio.site/search.json?q=Maula+Jatt",
            SearchSupport.keylessSearchUrl("Maula Jatt")
        )
        // A validated door pushed by AppConfig steers the lane.
        SearchSupport.searchDoorOverride = "https://pmeta2.plavio.site/search.json"
        assertEquals(
            "https://pmeta2.plavio.site/search.json?q=Maula+Jatt",
            SearchSupport.keylessSearchUrl("Maula Jatt")
        )
        // An unvalidated value can never steer it (defence at the seam).
        SearchSupport.searchDoorOverride = "https://evil.example.com/search.json"
        assertEquals(
            "https://meta.plavio.site/search.json?q=Maula+Jatt",
            SearchSupport.keylessSearchUrl("Maula Jatt")
        )
        SearchSupport.searchDoorOverride = null
        assertEquals(
            "https://meta.plavio.site/search.json?q=Maula+Jatt",
            SearchSupport.keylessSearchUrl("Maula Jatt")
        )
    }

    @Test
    fun `search url joins an existing query with an ampersand`() {
        assertEquals(
            "https://meta.plavio.site/search.json?src=idx&q=Dune",
            AppConfigSupport.searchUrl("https://meta.plavio.site/search.json?src=idx", "Dune")
        )
    }
}
