package com.pulsestream.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * "More like this" starvation regression (v0.14.25): on the owner's
 * profile (TMDB key saved, slow mobile network) the row never showed
 * because [StreamRepository.getRelated] ran the TMDB stage FIRST and
 * alone with no deadline (3 sequential calls, up to ~75 s), while the
 * fast first-party addon /related answer waited behind it and the UI
 * rendered no placeholder. These tests pin the fix at the
 * [StreamRepository.resolveRelatedConcurrent] seam with scripted
 * fakes under virtual time: TMDB and addon stages race, first
 * non-empty wins, the TMDB stage is budgeted at ~15 s and the whole
 * job at ~20 s.
 */
class RelatedRaceTest {

    private fun sections(id: String, vararg metaIds: String): List<RelatedSection> =
        listOf(
            RelatedSection(
                id = id,
                title = "More like this",
                metas = metaIds.map { MetaPreview(id = it, type = "movie", name = it) }
            )
        )

    /**
     * Fixture shaped like the live PlavioMeta /related answer for
     * tt4425200 (measured 2026-11-13 in the investigation: HTTP 200,
     * ~18 KB, 1 section, 29–30 metas, first meta tt10366206).
     */
    private fun goldenRelatedJson(): String {
        val metas = StringBuilder()
        metas.append("""{"id":"tt10366206","type":"movie","name":"John Wick: Chapter 4","poster":"https://example.test/p1.jpg"}""")
        for (i in 1..28) {
            metas.append(',')
            metas.append("""{"id":"tt%07d","type":"movie","name":"Pick $i","poster":"https://example.test/p$i.jpg"}""".format(1000000 + i))
        }
        return """{"sections":[{"id":"more_like_this","title":"More like this","metas":[$metas]}]}"""
    }

    @Test
    fun goldenPayloadParses() {
        val parsed = StremioParser.parseRelated(goldenRelatedJson(), "movie")
        assertEquals(1, parsed.size)
        assertEquals("More like this", parsed[0].title)
        assertTrue("live payload carries >=29 metas, got ${parsed[0].metas.size}", parsed[0].metas.size >= 29)
        assertEquals("tt10366206", parsed[0].metas.first().id)
    }

    /** THE bug: a 60 s TMDB stall must not starve a 100 ms addon answer. */
    @Test
    fun slowTmdbDoesNotStarveFastAddonRelated() = runTest {
        val pmetaSections = StremioParser.parseRelated(goldenRelatedJson(), "movie")
        var fallbackCalled = false
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = {
                delay(60_000)
                sections("tmdb_more_like_this", "tmdb:movie:1")
            },
            addonStage = {
                delay(100)
                pmetaSections
            },
            fallbackStage = {
                fallbackCalled = true
                sections("fallback_similar", "tt9999999")
            }
        )
        assertEquals(pmetaSections, result)
        assertTrue(
            "addon answer must land in <5s of virtual time, took ${testScheduler.currentTime}ms",
            testScheduler.currentTime < 5_000
        )
        assertTrue("fallback must not run when a fast stage wins", !fallbackCalled)
    }

    /** Deadline: when every stage hangs, the job gives up empty at ~20 s, not ~150 s. */
    @Test
    fun allStagesHangingReturnsEmptyWithinOverallDeadline() = runTest {
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = {
                delay(600_000)
                sections("tmdb_more_like_this", "tmdb:movie:1")
            },
            addonStage = {
                delay(600_000)
                sections("more_like_this", "tt10366206")
            },
            fallbackStage = {
                delay(600_000)
                sections("fallback_similar", "tt9999999")
            }
        )
        assertTrue(result.isEmpty())
        assertTrue(
            "whole job must end by the ~20s deadline, took ${testScheduler.currentTime}ms",
            testScheduler.currentTime <= StreamRepository.RELATED_OVERALL_TIMEOUT_MS
        )
    }

    /** TMDB still wins when it answers first with picks — and the loser is cancelled. */
    @Test
    fun tmdbWinsWhenItAnswersFirstAndLoserIsCancelled() = runTest {
        val tmdbSections = sections("tmdb_more_like_this", "tmdb:movie:42")
        var addonCancelled = false
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = {
                delay(100)
                tmdbSections
            },
            addonStage = {
                try {
                    delay(60_000)
                    sections("more_like_this", "tt10366206")
                } catch (e: CancellationException) {
                    addonCancelled = true
                    throw e
                }
            },
            fallbackStage = { sections("fallback_similar", "tt9999999") }
        )
        assertEquals(tmdbSections, result)
        assertTrue("the losing stage must be cancelled, not left running", addonCancelled)
        assertTrue(testScheduler.currentTime < 5_000)
    }

    /** Both fast stages empty -> the generic fallback is what answers. */
    @Test
    fun bothStagesEmptyFallsBack() = runTest {
        val fallbackSections = sections("fallback_similar", "tt1375666")
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = { emptyList() },
            addonStage = { emptyList() },
            fallbackStage = { fallbackSections }
        )
        assertEquals(fallbackSections, result)
    }

    /** No TMDB key saved: the addon stage alone decides (keyless installs). */
    @Test
    fun noTmdbStageRunsAddonOnly() = runTest {
        val addonSections = sections("more_like_this", "tt10366206")
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = null,
            addonStage = {
                delay(100)
                addonSections
            },
            fallbackStage = { sections("fallback_similar", "tt9999999") }
        )
        assertEquals(addonSections, result)
    }

    /**
     * An EMPTY addon answer is not a win: with TMDB still legitimately
     * working inside its budget, the race waits for TMDB — but no
     * longer than the ~15 s TMDB budget before falling back.
     */
    @Test
    fun emptyAddonAnswerDoesNotCutOffTmdbButBudgetStillApplies() = runTest {
        val fallbackSections = sections("fallback_similar", "tt1375666")
        val result = StreamRepository.resolveRelatedConcurrent(
            tmdbStage = {
                delay(600_000)
                sections("tmdb_more_like_this", "tmdb:movie:1")
            },
            addonStage = {
                delay(100)
                emptyList()
            },
            fallbackStage = { fallbackSections }
        )
        assertEquals(fallbackSections, result)
        assertTrue(
            "fallback should start at the ~15s TMDB budget, took ${testScheduler.currentTime}ms",
            testScheduler.currentTime >= StreamRepository.RELATED_TMDB_TIMEOUT_MS &&
                testScheduler.currentTime <= StreamRepository.RELATED_OVERALL_TIMEOUT_MS
        )
    }
}
