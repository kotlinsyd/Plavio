package com.pulsestream.app.data

import com.pulsestream.app.data.db.InstalledAddon
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.36 (defect 2): addon identity = manifest id + normalised
 * origin. The same addon under any URL spelling (plain, /u/<code>/,
 * /c/<token>/, urlencoded config, trailing slash, http) is ONE
 * addon; a different addon is never merged into it.
 */
class AddonIdentityTest {

    private fun addon(id: String, url: String, sortOrder: Int = 0) = InstalledAddon(
        id = id, name = id, version = "1", description = "", baseUrl = url,
        types = "movie", resources = "stream", sortOrder = sortOrder, addedAt = 1L
    )

    @Test
    fun `origin normalisation folds spelling variants`() {
        val origin = "https://hd.plavio.site"
        assertEquals(origin, AddonIdentity.originOf("https://hd.plavio.site"))
        assertEquals(origin, AddonIdentity.originOf("https://hd.plavio.site/"))
        assertEquals(origin, AddonIdentity.originOf("http://hd.plavio.site"))
        assertEquals(origin, AddonIdentity.originOf("https://HD.PLAVIO.SITE"))
        assertEquals(origin, AddonIdentity.originOf("hd.plavio.site"))
        assertEquals(origin, AddonIdentity.originOf("https://hd.plavio.site:443"))
        assertEquals(origin, AddonIdentity.originOf("http://hd.plavio.site:80"))
        // Path and query are configuration spellings, not origin.
        assertEquals(origin, AddonIdentity.originOf("https://hd.plavio.site/u/--UZCtwgEIMLaAjyz09pFw"))
        assertEquals(origin, AddonIdentity.originOf("https://hd.plavio.site/c/eyJmb28iOiJiYXIifQ"))
        // A non-default port IS part of the origin.
        assertEquals("https://example.test:8443", AddonIdentity.originOf("https://example.test:8443/x"))
        assertNull(AddonIdentity.originOf(""))
        assertNull(AddonIdentity.originOf("not a url"))
    }

    @Test
    fun `same addon under u, c and plain spellings matches`() {
        val installed = listOf(
            addon("community.plaviohd", "https://hd.plavio.site/u/--UZCtwgEIMLaAjyz09pFw", sortOrder = 0)
        )
        // Plain preinstalled spelling.
        assertEquals(
            installed[0],
            AddonIdentity.findMatch(installed, "community.plaviohd", "https://hd.plavio.site")
        )
        // /c/ token spelling.
        assertEquals(
            installed[0],
            AddonIdentity.findMatch(installed, "community.plaviohd", "https://hd.plavio.site/c/eyJmb28iOiJiYXIifQ")
        )
        // http + trailing slash + manifest suffix spelling.
        assertEquals(
            installed[0],
            AddonIdentity.findMatch(installed, "community.plaviohd", "http://hd.plavio.site/manifest.json")
        )
        // Id case wobble still matches the one row.
        assertEquals(
            installed[0],
            AddonIdentity.findMatch(installed, "Community.PlavioHD", "https://hd.plavio.site")
        )
    }

    @Test
    fun `different addon on the same origin does not match`() {
        val installed = listOf(addon("community.plaviohd", "https://hd.plavio.site"))
        assertNull(AddonIdentity.findMatch(installed, "org.other.addon", "https://hd.plavio.site"))
        assertNull(AddonIdentity.findMatch(installed, "", "https://hd.plavio.site"))
    }

    @Test
    fun `same manifest id on another origin still lands on the one row`() {
        // The addons table's primary key is the manifest id, so an
        // install under an existing id can only replace that row —
        // findMatch must report it as a match (an update), never as
        // a fresh install that would silently clobber.
        val installed = listOf(addon("com.example.addon", "https://old.example.test"))
        assertEquals(
            installed[0],
            AddonIdentity.findMatch(installed, "com.example.addon", "https://new.example.test")
        )
    }

    @Test
    fun `dedupe collapses identity duplicates keeping the first`() {
        val first = addon("community.plaviohd", "https://hd.plavio.site", sortOrder = 0)
        val respelled = addon("community.plaviohd", "https://hd.plavio.site/u/--UZCtwgEIMLaAjyz09pFw", sortOrder = 1)
        val other = addon("com.other", "https://other.test", sortOrder = 2)
        val sameHostOtherAddon = addon("com.neighbour", "https://hd.plavio.site", sortOrder = 3)
        val out = AddonIdentity.dedupeInstalled(listOf(first, respelled, other, sameHostOtherAddon))
        assertEquals(listOf(first, other, sameHostOtherAddon), out)
        assertTrue(AddonIdentity.dedupeInstalled(emptyList()).isEmpty())
    }
}
