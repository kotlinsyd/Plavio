package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.32 (item 6): pins the Search "Popular" section's pure
 * rules — the language plan follows the user's own search
 * proportions, and the mix interleaves languages round-robin
 * inside their quotas, deduped, with dry languages' slots
 * flowing to the rest.
 */
class PopularByLanguageTest {

    private fun preview(id: String) = MetaPreview(id = id, type = "movie", name = id)

    // ---- the plan ----

    @Test
    fun `plan follows the search proportions`() {
        val plan = popularLanguagePlan(listOf("hi", "hi", "hi", "en"), 48)
        assertEquals(mapOf("hi" to 36, "en" to 12), plan)
    }

    @Test
    fun `plan leftover goes by largest remainder, ties by recency`() {
        // 1/1/1 of 10: floors are 3 each (9 assigned); the single
        // leftover's remainders tie, so the most recent wins it.
        val plan = popularLanguagePlan(listOf("en", "hi", "ur"), 10)
        assertEquals(listOf("en", "hi", "ur"), plan.keys.toList())
        assertEquals(4, plan["en"])
        assertEquals(3, plan["hi"])
        assertEquals(3, plan["ur"])
    }

    @Test
    fun `every searched language earns a slot when there is room`() {
        // 9 English + 1 Hindi search, only 5 slots: Hindi's floor
        // is 0, but the min-one rule steals one from English.
        val plan = popularLanguagePlan(List(9) { "en" } + listOf("hi"), 5)
        assertEquals(4, plan["en"])
        assertEquals(1, plan["hi"])
    }

    @Test
    fun `plan is empty for no history, blanks, or no room`() {
        assertTrue(popularLanguagePlan(emptyList(), 48).isEmpty())
        assertTrue(popularLanguagePlan(listOf("", "  "), 48).isEmpty())
        assertTrue(popularLanguagePlan(listOf("hi"), 0).isEmpty())
        // Language codes normalise (case/space) before counting.
        assertEquals(mapOf("hi" to 6), popularLanguagePlan(listOf("HI", " hi "), 6))
    }

    // ---- the mix ----

    @Test
    fun `mix interleaves languages inside their quotas`() {
        val perLanguage = mapOf(
            "hi" to listOf(preview("h1"), preview("h2"), preview("h3")),
            "en" to listOf(preview("e1"), preview("e2"))
        )
        val mixed = mixPopularByLanguage(
            perLanguage, mapOf("hi" to 2, "en" to 2), emptySet(), 4
        )
        assertEquals(listOf("h1", "e1", "h2", "e2"), mixed.map { it.id })
    }

    @Test
    fun `mix dedupes across languages and against the grid above`() {
        val perLanguage = mapOf(
            "hi" to listOf(preview("x"), preview("h2")),
            "en" to listOf(preview("x"), preview("e2"))
        )
        val mixed = mixPopularByLanguage(
            perLanguage, mapOf("hi" to 1, "en" to 1), emptySet(), 4
        )
        assertEquals(listOf("x", "e2"), mixed.map { it.id })

        val excluded = mixPopularByLanguage(
            mapOf("hi" to listOf(preview("h1"), preview("h2"))),
            mapOf("hi" to 1), setOf("h1"), 4
        )
        assertEquals(listOf("h2"), excluded.map { it.id })
    }

    @Test
    fun `a dry language's leftover slots flow to the others`() {
        val perLanguage = mapOf(
            "hi" to listOf(preview("h1")),
            "en" to listOf(preview("e1"), preview("e2"), preview("e3"))
        )
        val mixed = mixPopularByLanguage(
            perLanguage, mapOf("hi" to 2, "en" to 1), emptySet(), 3
        )
        assertEquals(listOf("h1", "e1", "e2"), mixed.map { it.id })
    }

    @Test
    fun `mix honours the limit and empty inputs`() {
        val perLanguage = mapOf("hi" to (1..10).map { preview("h$it") })
        assertEquals(3, mixPopularByLanguage(perLanguage, mapOf("hi" to 10), emptySet(), 3).size)
        assertTrue(mixPopularByLanguage(perLanguage, emptyMap(), emptySet(), 5).isEmpty())
        assertTrue(mixPopularByLanguage(perLanguage, mapOf("hi" to 2), emptySet(), 0).isEmpty())
    }
}
