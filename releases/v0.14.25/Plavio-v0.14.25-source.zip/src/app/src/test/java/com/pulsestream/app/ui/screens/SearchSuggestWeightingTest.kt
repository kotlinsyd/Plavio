package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.MetaPreview
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * v0.14.29: "You May Like This" language weighting — a term's picks
 * are sorted same-language-first (the seed's original language)
 * inside a deepened candidate pool, then trimmed to the per-term
 * limit, so Hindi seeds surface their Hindi picks instead of an
 * all-English head.
 */
class SearchSuggestWeightingTest {

    private fun meta(id: String, lang: String?) = MetaPreview(
        id = id, type = "movie", name = id, originalLanguage = lang
    )

    @Test
    fun `same language picks move first, order stable within groups`() {
        val candidates = listOf(
            meta("en1", "en"), meta("hi1", "hi"), meta("en2", "en"),
            meta("hi2", "hi"), meta("fr1", "fr")
        )
        val out = languageWeightedPicks(candidates, "hi", 24)
        assertEquals(listOf("hi1", "hi2", "en1", "en2", "fr1"), out.map { it.id })
    }

    @Test
    fun `weighting happens before the trim`() {
        // 30 candidates: 26 English head, 4 Hindi tail. Without
        // weighting the Hindi picks would fall outside the 24 trim.
        val candidates = (1..26).map { meta("en$it", "en") } +
            (1..4).map { meta("hi$it", "hi") }
        val out = languageWeightedPicks(candidates, "hi", 24)
        assertEquals(24, out.size)
        assertEquals(listOf("hi1", "hi2", "hi3", "hi4"), out.take(4).map { it.id })
    }

    @Test
    fun `seed without language leaves order untouched`() {
        val candidates = listOf(meta("a", "en"), meta("b", "hi"), meta("c", null))
        assertEquals(
            listOf("a", "b", "c"),
            languageWeightedPicks(candidates, null, 24).map { it.id }
        )
        assertEquals(
            listOf("a", "b", "c"),
            languageWeightedPicks(candidates, "", 24).map { it.id }
        )
    }

    @Test
    fun `language codes compare case insensitively and picks without language keep tail order`() {
        val candidates = listOf(
            meta("x", null), meta("y", "HI"), meta("z", "en")
        )
        val out = languageWeightedPicks(candidates, "Hi", 24)
        assertEquals(listOf("y", "x", "z"), out.map { it.id })
    }
}
