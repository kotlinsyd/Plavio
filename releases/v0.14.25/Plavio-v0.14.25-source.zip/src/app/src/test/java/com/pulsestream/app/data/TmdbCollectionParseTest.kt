package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Item 8 (v0.14.38): franchise collection parsing — parts come
 * back in release order (undated last), posters resolved, and a
 * payload without a real collection yields no row at all.
 */
class TmdbCollectionParseTest {

    private val sample = """
        {
          "id": 404609,
          "name": "John Wick Collection",
          "parts": [
            {"id": 603692, "title": "John Wick: Chapter 4", "release_date": "2023-03-22", "poster_path": "/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg"},
            {"id": 245891, "title": "John Wick: Chapter 2", "release_date": "2017-02-08", "poster_path": "/hUuht2uNWNSd7gWwYYhPJKUU6wX.jpg"},
            {"id": 458156, "title": "John Wick: Chapter 3 - Parabellum", "release_date": "2019-05-15", "poster_path": "/ziEuYlhLDfQH5UoHJNTSKqWLq3f.jpg"},
            {"id": 245890, "title": "John Wick", "release_date": "2014-10-22", "poster_path": "/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg"},
            {"id": 999001, "title": "John Wick: Chapter 5", "release_date": "", "poster_path": null}
          ]
        }
    """.trimIndent()

    @Test
    fun partsAreSortedByReleaseDateWithUndatedLast() {
        val collection = TmdbClient.parseCollection(sample)
        requireNotNull(collection)
        assertEquals("John Wick Collection", collection.name)
        assertEquals(
            listOf(
                "John Wick", "John Wick: Chapter 2",
                "John Wick: Chapter 3 - Parabellum", "John Wick: Chapter 4",
                "John Wick: Chapter 5"
            ),
            collection.parts.map { it.title }
        )
        assertEquals("2014", collection.parts.first().year)
        assertNull(collection.parts.last().year)
    }

    @Test
    fun posterUrlsAreResolvedAndMissingPosterStaysNull() {
        val collection = TmdbClient.parseCollection(sample)
        requireNotNull(collection)
        assertEquals(
            "https://image.tmdb.org/t/p/w342/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg",
            collection.parts.first().posterUrl
        )
        assertNull(collection.parts.last().posterUrl)
    }

    @Test
    fun singlePartOrGarbageYieldsNoCollection() {
        assertNull(TmdbClient.parseCollection("""{"id":1,"name":"Solo","parts":[{"id":2,"title":"Only","release_date":"2020-01-01"}]}"""))
        assertNull(TmdbClient.parseCollection("not json"))
        assertNull(TmdbClient.parseCollection("""{"id":1,"parts":[]}"""))
    }
}
