package com.pulsestream.app.ui.components

import com.pulsestream.app.data.StreamItem
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Owner's screenshot (2026-11-05): on The Vampire Diaries S01E01 the
 * first three PlavioHD rows showed the bare file size ("6.06 GB") as
 * the card heading, over the stream name. The payloads below are the
 * live rows exactly as the addon served them.
 */
class StreamCardDisplayNameTest {

    private fun factsFor(name: String, title: String): StreamFacts =
        streamFacts(
            StreamItem(
                url = "https://pixeldrain.dev/api/file/TEST?download",
                name = name,
                title = title,
                sourceName = "PlavioHD"
            ),
            showSize = true
        )

    @Test
    fun `remux row heading is the title, not the size`() {
        val facts = factsFor(
            "The Vampire Diaries 2009 PixalDrain 1080p",
            "The.Vampire.Diaries.S01E01.1080p.DD5.1.VC-1.REMUX-FraMeSToR.mkv\nREMUX · 6.06 GB"
        )
        assertTrue(facts.displayName, facts.displayName.contains("Vampire Diaries"))
        assertFalse(facts.displayName, facts.displayName.contains("GB"))
    }

    @Test
    fun `web-dl row heading is the title, not the size`() {
        val facts = factsFor(
            "The Vampire Diaries 2009 PixalDrain 1080p",
            "The.Vampire.Diaries.S01E01.Pilot.1080p.HMAX.WEB-DL.DD5.1.H.264-playWEB.mkv\nWEB-DL · H.264 · 2.62 GB"
        )
        assertTrue(facts.displayName, facts.displayName.contains("Vampire Diaries"))
        assertFalse(facts.displayName, facts.displayName.contains("GB"))
    }

    @Test
    fun `prose bluray row heading is the clean title`() {
        val facts = factsFor(
            "The Vampire Diaries 2009 PixalDrain 1080p",
            "The Vampire Diaries (2009) S01E01 Pilot (1080p BluRay x265 10-Bit SDR DDP 5.1 English .mkv\nBluRay · x265 · English · DDP · 5.1 · 1.60 GB"
        )
        assertTrue(facts.displayName, facts.displayName.contains("Vampire Diaries"))
        assertFalse(facts.displayName, facts.displayName.contains("GB"))
        assertFalse(facts.displayName, facts.displayName.contains("BluRay"))
        assertFalse(facts.displayName, facts.displayName.contains(".mkv"))
    }
}
