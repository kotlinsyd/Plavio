package com.pulsestream.app.data.debrid

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Offcloud response parsing against fixtures shaped from maintained
 * clients (the vendor's own docs are thin). The /cache answer has
 * been seen in array, URL-keyed and flat shapes — the parser accepts
 * all three, pinned here.
 */
class OffcloudApiTest {

    private val magnet = "magnet:?xt=urn:btih:abcdef"

    @Test
    fun cache_arrayShape() {
        assertTrue(
            OffcloudApi.parseCacheBody(
                """[{"cached":true,"files":[{"folder":["Dir"],"filename":"movie.mkv"}]}]""",
                magnet
            )
        )
        assertFalse(OffcloudApi.parseCacheBody("""[{"cached":false}]""", magnet))
    }

    @Test
    fun cache_keyedAndFlatShapes() {
        assertTrue(
            OffcloudApi.parseCacheBody(
                """{"magnet:?xt=urn:btih:abcdef":{"cached":true}}""",
                magnet
            )
        )
        assertTrue(OffcloudApi.parseCacheBody("""{"cached":true}""", magnet))
    }

    @Test
    fun cache_noAuthThrows() {
        try {
            OffcloudApi.parseCacheBody("""{"error":"NOAUTH"}""", magnet)
            fail("expected OffcloudException")
        } catch (e: OffcloudException) {
            assertTrue(e.isAuthError)
        }
    }

    @Test
    fun cloudRequestIdAndStatus() {
        assertEquals(
            "req-1",
            OffcloudApi.parseCloudRequestId(
                JSONObject("""{"requestId":"req-1","fileName":"movie.mkv","status":"created"}""")
            )
        )
        assertEquals(
            "downloaded",
            OffcloudApi.parseCloudStatus(JSONObject("""{"requestId":"req-1","status":"downloaded"}"""))
        )
        assertEquals(OffcloudApi.STATUS_DOWNLOADED, "downloaded")
    }

    @Test
    fun cloudRequestId_missingThrows() {
        try {
            OffcloudApi.parseCloudRequestId(JSONObject("""{"status":"created"}"""))
            fail("expected OffcloudException")
        } catch (e: OffcloudException) {
            assertFalse(e.isAuthError)
        }
    }

    @Test
    fun exploreFiles_carryLinks() {
        val files = OffcloudApi.parseExploreFiles(
            JSONObject(
                """{"files":[
                    {"id":"1","name":"movie.mkv","size":"2000","path":"movie.mkv","url":"https://dl.example/1"},
                    {"id":"2","name":"subs.srt","size":"10","path":"subs.srt","url":"https://dl.example/2"}
                ]}"""
            )
        )
        assertEquals(2, files.size)
        assertEquals("movie.mkv", files[0].name)
        assertEquals(2000L, files[0].size)
        assertEquals("https://dl.example/1", files[0].url)
        assertEquals(1, files[1].sourceIndex)
    }
}
