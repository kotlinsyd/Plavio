package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WarmSupportTest {

    private fun cm(id: String, type: String = "movie", name: String = id) =
        CachedMeta(
            addonId = "addon-a", addonName = "addon-a", baseUrl = "",
            meta = MetaPreview(id = id, type = type, name = name)
        )

    // ---- URL builder ----

    @Test
    fun `movie warm url has no query`() {
        val target = WarmSupport.target("movie", "tt15398776")!!
        assertEquals(
            "https://hd.plavio.site/warm/movie/tt15398776.json",
            WarmSupport.warmUrl("https://hd.plavio.site", target)
        )
    }

    @Test
    fun `base url trailing slash is trimmed`() {
        val target = WarmSupport.target("movie", "tt15398776")!!
        assertEquals(
            "https://hd.plavio.site/warm/movie/tt15398776.json",
            WarmSupport.warmUrl("https://hd.plavio.site/", target)
        )
    }

    @Test
    fun `series default warm url omits season and episode`() {
        val target = WarmSupport.target("series", "tt0903747")!!
        assertNull(target.season)
        assertNull(target.episode)
        assertEquals(
            "https://hd.plavio.site/warm/series/tt0903747.json",
            WarmSupport.warmUrl("https://hd.plavio.site", target)
        )
    }

    @Test
    fun `series warm url carries an explicit pair`() {
        val target = WarmSupport.target("series", "tt0903747", season = 2, episode = 5)!!
        assertEquals(
            "https://hd.plavio.site/warm/series/tt0903747.json?season=2&episode=5",
            WarmSupport.warmUrl("https://hd.plavio.site", target)
        )
    }

    // ---- Validation ----

    @Test
    fun `tmdb and opaque ids never warm`() {
        assertNull(WarmSupport.target("movie", "tmdb:movie:872585"))
        assertNull(WarmSupport.target("series", "tmdb:tv:1399"))
        assertNull(WarmSupport.target("movie", "cnc:some-opaque-id"))
        assertNull(WarmSupport.target("movie", null))
        assertNull(WarmSupport.target("movie", ""))
        assertNull(WarmSupport.target("movie", "tt")) // no digits
        assertNull(WarmSupport.target("movie", "tt15398776:1:1")) // episode form, not a title id
    }

    @Test
    fun `tt id is normalised and type spellings map to the server types`() {
        assertEquals("tt15398776", WarmSupport.target("movie", " TT15398776 ")!!.imdbId)
        assertEquals("series", WarmSupport.target("tv", "tt0903747")!!.type)
        assertEquals("series", WarmSupport.target("series", "tt0903747")!!.type)
        assertNull(WarmSupport.target("channel", "tt0903747"))
        assertNull(WarmSupport.target(null, "tt0903747"))
    }

    @Test
    fun `half or non-positive episode pairs collapse to the server default`() {
        val half = WarmSupport.target("series", "tt0903747", season = 3, episode = null)!!
        assertNull(half.season)
        assertNull(half.episode)
        val zero = WarmSupport.target("series", "tt0903747", season = 0, episode = 0)!!
        assertNull(zero.season)
        assertNull(zero.episode)
        // Movies never carry a pair, whatever the caller passed.
        val movie = WarmSupport.target("movie", "tt15398776", season = 1, episode = 1)!!
        assertNull(movie.season)
        assertNull(movie.episode)
    }

    // ---- Settled-search selection ----

    @Test
    fun `search selection takes the first five tt rows in ranked order`() {
        val results = listOf(
            cm("tmdb:movie:1", name = "tmdb-only, skipped"),
            cm("tt0000001"),
            cm("tt0000002", type = "series"),
            cm("tt0000003"),
            cm("tt0000004"),
            cm("tt0000005"),
            cm("tt0000006"),
            cm("tt0000007")
        )
        val targets = WarmSupport.selectSearchTargets(results)
        assertEquals(
            listOf("tt0000001", "tt0000002", "tt0000003", "tt0000004", "tt0000005"),
            targets.map { it.imdbId }
        )
        assertEquals("series", targets[1].type)
        // Search rows warm the title (server default episode), never a pair.
        assertTrue(targets.all { it.season == null && it.episode == null })
    }

    @Test
    fun `search selection collapses duplicate tt ids and tolerates empty input`() {
        val results = listOf(cm("tt0000001"), cm("tt0000001"), cm("tt0000002"))
        assertEquals(
            listOf("tt0000001", "tt0000002"),
            WarmSupport.selectSearchTargets(results).map { it.imdbId }
        )
        assertTrue(WarmSupport.selectSearchTargets(emptyList()).isEmpty())
        assertTrue(
            WarmSupport.selectSearchTargets(listOf(cm("tmdb:movie:9"))).isEmpty()
        )
    }

    // ---- Session dedupe ----

    @Test
    fun `each target warms at most once per session`() {
        val ledger = WarmLedger()
        val movie = WarmSupport.target("movie", "tt15398776")!!
        assertTrue(ledger.markIfNew(movie))
        assertFalse(ledger.markIfNew(movie))
        assertTrue(ledger.markIfNew(WarmSupport.target("movie", "tt0816692")!!))
    }

    @Test
    fun `series default and explicit S01E01 are the same target`() {
        val ledger = WarmLedger()
        assertTrue(ledger.markIfNew(WarmSupport.target("series", "tt0903747")!!))
        assertFalse(
            ledger.markIfNew(WarmSupport.target("series", "tt0903747", season = 1, episode = 1)!!)
        )
        // A different episode is a different target.
        assertTrue(
            ledger.markIfNew(WarmSupport.target("series", "tt0903747", season = 1, episode = 2)!!)
        )
    }

    @Test
    fun `ledger is bounded with oldest-first eviction`() {
        val ledger = WarmLedger(maxEntries = 3)
        val a = WarmSupport.target("movie", "tt0000001")!!
        val b = WarmSupport.target("movie", "tt0000002")!!
        val c = WarmSupport.target("movie", "tt0000003")!!
        val d = WarmSupport.target("movie", "tt0000004")!!
        assertTrue(ledger.markIfNew(a))
        assertTrue(ledger.markIfNew(b))
        assertTrue(ledger.markIfNew(c))
        assertTrue(ledger.markIfNew(d)) // evicts a
        assertFalse(ledger.markIfNew(b))
        assertTrue(ledger.markIfNew(a)) // a was evicted, so it may warm again
    }
}
