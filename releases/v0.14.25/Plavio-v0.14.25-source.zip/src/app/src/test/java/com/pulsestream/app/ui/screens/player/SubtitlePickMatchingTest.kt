package com.pulsestream.app.ui.screens.player

import com.pulsestream.app.data.ResolvedSubtitle
import com.pulsestream.app.data.Subtitle
import androidx.media3.common.MimeTypes
import com.pulsestream.app.data.detectSubtitleMimeType
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.30 (owner's note 3): the subtitle panel listed every file,
 * but a tap on a file that was not already downloaded never made
 * subtitles appear, and the match between "the URL the panel
 * listed" and "the URL the resolver published" was a bare `==` —
 * any spelling difference between the two sides (scheme/host
 * casing, default port, percent-encoding, trailing slash) silently
 * broke the pick. These tests pin [subtitleMatchKey] and
 * [findResolvedForPick], the matching the fixed tap → pending →
 * activate chain runs on, plus the resolver's widened SRT sniff
 * ([detectSubtitleMimeType]) that decides whether a downloaded
 * file joins the resolved set at all.
 */
class SubtitlePickMatchingTest {

    private fun resolved(url: String, lang: String = "en") = ResolvedSubtitle(
        sub = Subtitle(url = url, lang = lang),
        file = File("/tmp/$url.hashCode()"),
        mimeType = MimeTypes.APPLICATION_SUBRIP
    )

    @Test
    fun `exact url still matches first (pre-fix behaviour preserved)`() {
        val a = resolved("https://subs.plavio.site/files/abc.srt")
        val b = resolved("https://subs.plavio.site/files/def.srt")
        assertEquals(b, findResolvedForPick(listOf(a, b), b.sub.url))
    }

    @Test
    fun `scheme and host casing differences still match`() {
        val r = resolved("HTTPS://Subs.Plavio.Site/files/abc.srt")
        assertNotNull(
            findResolvedForPick(listOf(r), "https://subs.plavio.site/files/abc.srt")
        )
    }

    @Test
    fun `default port and trailing slash differences still match`() {
        val r = resolved("https://subs.plavio.site:443/files/abc.srt")
        assertNotNull(
            findResolvedForPick(listOf(r), "https://subs.plavio.site/files/abc.srt")
        )
        val r2 = resolved("https://example.com/subs/xyz/")
        assertNotNull(
            findResolvedForPick(listOf(r2), "https://example.com/subs/xyz")
        )
    }

    @Test
    fun `percent-encoded and literal spellings of the same file match`() {
        val r = resolved("https://example.com/subs/my%20movie%20%5BEN%5D.srt")
        assertNotNull(
            findResolvedForPick(listOf(r), "https://example.com/subs/my movie [EN].srt")
        )
    }

    @Test
    fun `different files never match`() {
        val r = resolved("https://subs.plavio.site/files/abc.srt")
        assertNull(findResolvedForPick(listOf(r), "https://subs.plavio.site/files/abd.srt"))
        assertNull(findResolvedForPick(listOf(r), "https://other.example/files/abc.srt"))
        assertNull(findResolvedForPick(emptyList(), "https://subs.plavio.site/files/abc.srt"))
    }

    @Test
    fun `query strings still distinguish files`() {
        val r = resolved("https://example.com/get?id=41")
        assertNotNull(findResolvedForPick(listOf(r), "https://example.com/get?id=41"))
        assertNull(findResolvedForPick(listOf(r), "https://example.com/get?id=42"))
    }

    @Test
    fun `match key is stable and idempotent`() {
        val u = "HTTPS://Example.COM:443/a//b%20c.srt?x=%41"
        assertEquals(subtitleMatchKey(u), subtitleMatchKey(subtitleMatchKey(u)))
        assertEquals("https://example.com/a/b c.srt?x=A", subtitleMatchKey(u))
    }

    @Test
    fun `lenient srt shapes now pass the resolver sniff`() {
        // One-digit hours, 1-digit millis, no numeric cue index —
        // a real SubRip file the strict sniff used to drop whole.
        val lenient = """
            0:04:31,5 --> 0:04:34,25
            Hello there.

            0:04:35,0 --> 0:04:37,5
            General Kenobi.
        """.trimIndent()
        assertEquals(
            MimeTypes.APPLICATION_SUBRIP,
            detectSubtitleMimeType(lenient)
        )
    }

    @Test
    fun `strict srt and vtt still sniff as before`() {
        val srt = "1\n00:00:01,000 --> 00:00:03,000\nHi\n\n2\n00:00:04,000 --> 00:00:06,000\nYo\n"
        assertEquals(MimeTypes.APPLICATION_SUBRIP, detectSubtitleMimeType(srt))
        val vtt = "WEBVTT\n\n00:01.000 --> 00:04.000\nHi\n"
        assertEquals(MimeTypes.TEXT_VTT, detectSubtitleMimeType(vtt))
    }

    @Test
    fun `error bodies still fail the sniff`() {
        assertNull(detectSubtitleMimeType("<html><body>404 Not Found</body></html>"))
        assertNull(detectSubtitleMimeType("{\"error\":\"no subtitles\"}"))
        assertTrue(detectSubtitleMimeType("") == null)
    }
}
