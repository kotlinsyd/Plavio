package com.pulsestream.app.data.download

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Item 6 (v0.14.38): the downloader resume rules. The owner's bug
 * was pause + resume restarting from zero; these pin the fixed
 * rules in DownloadProtocol that DownloadManager now follows.
 */
class DownloadResumeRulesTest {

    // -- segmentStateReusable: totals decide, validators do not ----

    @Test
    fun segmentStateReusableWhenTotalsAndLengthAgree() {
        assertTrue(DownloadProtocol.segmentStateReusable(savedTotal = 1_000L, onDiskBytes = 1_000L, probeTotal = 1_000L))
    }

    @Test
    fun segmentStateRejectedWhenProbeTotalDiffers() {
        // A different total means a different file: never splice.
        assertFalse(DownloadProtocol.segmentStateReusable(savedTotal = 1_000L, onDiskBytes = 1_000L, probeTotal = 2_000L))
    }

    @Test
    fun segmentStateRejectedWhenFileTruncated() {
        assertFalse(DownloadProtocol.segmentStateReusable(savedTotal = 1_000L, onDiskBytes = 400L, probeTotal = 1_000L))
    }

    @Test
    fun segmentStateRejectedForZeroTotal() {
        assertFalse(DownloadProtocol.segmentStateReusable(savedTotal = 0L, onDiskBytes = 0L, probeTotal = 0L))
    }

    // -- rangeTotalMatches: the fresh-URL / resume identity check --

    @Test
    fun rangeTotalMatchesWhenEqual() {
        assertTrue(DownloadProtocol.rangeTotalMatches(rangeTotal = 5_000L, knownTotal = 5_000L))
    }

    @Test
    fun rangeTotalMismatchWhenServerFileDiffers() {
        assertFalse(DownloadProtocol.rangeTotalMatches(rangeTotal = 6_000L, knownTotal = 5_000L))
    }

    @Test
    fun rangeTotalPassesWhenEitherSideUnknown() {
        // Unknown can never disprove identity; If-Range + the strict
        // Content-Range parse remain the guards in that case.
        assertTrue(DownloadProtocol.rangeTotalMatches(rangeTotal = null, knownTotal = 5_000L))
        assertTrue(DownloadProtocol.rangeTotalMatches(rangeTotal = 5_000L, knownTotal = 0L))
        assertTrue(DownloadProtocol.rangeTotalMatches(rangeTotal = 5_000L, knownTotal = -1L))
    }

    // -- canRebindPartial: fresh URL onto a saved partial ----------

    @Test
    fun rebindAllowedForPausedOrFailedWithBytes() {
        assertTrue(DownloadProtocol.canRebindPartial("PAUSED", 123L))
        assertTrue(DownloadProtocol.canRebindPartial("FAILED", 123L))
    }

    @Test
    fun rebindRefusedWithoutBytesOrForLiveRows() {
        assertFalse(DownloadProtocol.canRebindPartial("PAUSED", 0L))
        assertFalse(DownloadProtocol.canRebindPartial("DOWNLOADING", 123L))
        assertFalse(DownloadProtocol.canRebindPartial("QUEUED", 123L))
        assertFalse(DownloadProtocol.canRebindPartial("COMPLETED", 123L))
        assertFalse(DownloadProtocol.canRebindPartial("CANCELLED", 123L))
    }
}
