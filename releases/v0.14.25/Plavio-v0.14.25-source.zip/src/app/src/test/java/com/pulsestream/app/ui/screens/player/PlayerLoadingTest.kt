package com.pulsestream.app.ui.screens.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.33: pins the player loading state's locked spec — the
 * phase → status-word mapping, the honest bar (asymptote at 90%,
 * never a fake 100%), the H1 heartbeat keyframes, and the quiet
 * meta line built only from fields the meta actually carried.
 */
class PlayerLoadingTest {

    @Test
    fun `status words are the samples exact lines`() {
        assertEquals(
            "Finding streams…",
            playerLoadingStatusText(PlayerLoadingPhase.FINDING_STREAMS)
        )
        assertEquals(
            "Picking best quality…",
            playerLoadingStatusText(PlayerLoadingPhase.PICKING_QUALITY)
        )
        assertEquals(
            "Loading…",
            playerLoadingStatusText(PlayerLoadingPhase.LOADING)
        )
    }

    @Test
    fun `a blank-url vod request starts finding, everything else starts loading`() {
        assertEquals(
            PlayerLoadingPhase.FINDING_STREAMS,
            initialLoadingPhase(streamUrlBlank = true, isLive = false, isTrailer = false)
        )
        // Live and trailer requests never take the pending-pick path.
        assertEquals(
            PlayerLoadingPhase.LOADING,
            initialLoadingPhase(streamUrlBlank = true, isLive = true, isTrailer = false)
        )
        assertEquals(
            PlayerLoadingPhase.LOADING,
            initialLoadingPhase(streamUrlBlank = true, isLive = false, isTrailer = true)
        )
        // A URL already in hand: find + pick happened upstream.
        assertEquals(
            PlayerLoadingPhase.LOADING,
            initialLoadingPhase(streamUrlBlank = false, isLive = false, isTrailer = false)
        )
    }

    @Test
    fun `bar eases toward ninety percent and never reaches it`() {
        assertEquals(0f, playerLoadingBarFraction(0.0), 0.0001f)
        // t = 2.4 s: 0.90 * (1 - e^-1) = 0.5689…
        assertEquals(0.5689f, playerLoadingBarFraction(2.4), 0.001f)
        // A long wait still stops short of a fake full bar…
        val late = playerLoadingBarFraction(30.0)
        assertTrue(late < 0.90f)
        assertTrue(late > 0.899f)
        // …and never exceeds the 90% asymptote, however long it runs.
        assertTrue(playerLoadingBarFraction(120.0) <= 0.90f)
        // Negative time clamps to zero.
        assertEquals(0f, playerLoadingBarFraction(-5.0), 0.0001f)
        // Monotonic: the bar never walks backwards.
        var prev = 0f
        for (t in 0..40) {
            val f = playerLoadingBarFraction(t * 0.25)
            assertTrue(f >= prev)
            prev = f
        }
    }

    @Test
    fun `elapsed formats as tenths with no locale separators`() {
        assertEquals("0.0s", formatLoadingElapsed(0L))
        assertEquals("4.2s", formatLoadingElapsed(4_200L))
        assertEquals("4.2s", formatLoadingElapsed(4_299L))
        assertEquals("12.3s", formatLoadingElapsed(12_345L))
    }

    @Test
    fun `buffer visual gate - overlay only for initial load and resume`() {
        // Initial load: this title has never played → overlay.
        assertEquals(
            PlayerBufferVisual.STARTUP_OVERLAY,
            playerBufferVisual(
                isBuffering = true, hasError = false,
                hasStartedOnce = false, resumeBuffering = false
            )
        )
        // Seek buffering and slow-network rebuffer after playback
        // began → the plain spinner, never the overlay (the
        // 0.14.33 device leak: a request copy() used to reset the
        // started latch and re-arm the overlay mid-playback).
        assertEquals(
            PlayerBufferVisual.PLAIN_SPINNER,
            playerBufferVisual(
                isBuffering = true, hasError = false,
                hasStartedOnce = true, resumeBuffering = false
            )
        )
        // Resume: play pressed after a pause, buffering back up →
        // overlay, even though the title has played before.
        assertEquals(
            PlayerBufferVisual.STARTUP_OVERLAY,
            playerBufferVisual(
                isBuffering = true, hasError = false,
                hasStartedOnce = true, resumeBuffering = true
            )
        )
        // Not buffering → neither visual, whatever the flags.
        assertEquals(
            PlayerBufferVisual.NONE,
            playerBufferVisual(
                isBuffering = false, hasError = false,
                hasStartedOnce = false, resumeBuffering = true
            )
        )
        // A fatal error suppresses both (the error overlay rules).
        assertEquals(
            PlayerBufferVisual.NONE,
            playerBufferVisual(
                isBuffering = true, hasError = true,
                hasStartedOnce = false, resumeBuffering = false
            )
        )
    }

    @Test
    fun `status capsule anchors bottom-centre clear of the edge`() {
        // The capsule stands alone at the bottom of the loading
        // screen (PlayerLoadingOverlay aligns it BottomCenter with
        // this lift) — inside the owner's 48–64dp band, never
        // tucked under the title at the edge.
        assertEquals(56, LOADING_CAPSULE_BOTTOM_PADDING_DP)
        assertTrue(LOADING_CAPSULE_BOTTOM_PADDING_DP in 48..64)
    }

    @Test
    fun `cast line rotates one name at a time and wraps`() {
        val cast = listOf("Tom Cruise", "Rebecca Ferguson", "Hayley Atwell")
        assertEquals("Starring Tom Cruise", playerLoadingCastLine(cast, 0L))
        assertEquals("Starring Tom Cruise", playerLoadingCastLine(cast, 2_199L))
        assertEquals("Starring Rebecca Ferguson", playerLoadingCastLine(cast, 2_200L))
        assertEquals("Starring Hayley Atwell", playerLoadingCastLine(cast, 4_400L))
        // After the last name the rotation cycles back to the first.
        assertEquals("Starring Tom Cruise", playerLoadingCastLine(cast, 6_600L))
        // The index pins agree with the line pins.
        assertEquals(0, playerLoadingCastIndex(0L, 3))
        assertEquals(1, playerLoadingCastIndex(2_200L, 3))
        assertEquals(2, playerLoadingCastIndex(4_400L, 3))
        assertEquals(0, playerLoadingCastIndex(6_600L, 3))
        assertEquals(0, playerLoadingCastIndex(1_000L, 0))
    }

    @Test
    fun `cast line is absent without cast and capped at six`() {
        // No cast carried → no line, ever. Nothing is padded.
        assertNull(playerLoadingCastLine(emptyList(), 0L))
        assertNull(playerLoadingCastLine(emptyList(), 60_000L))
        assertNull(playerLoadingCastLine(listOf(" ", ""), 0L))
        // Blanks are dropped and names trimmed before rotating.
        assertEquals(
            listOf("A", "B"),
            playerLoadingCastNames(listOf(" A ", " ", "B"))
        )
        // Top-billed first, rotation capped at the pinned maximum.
        val many = (1..10).map { "Actor $it" }
        assertEquals(LOADING_CAST_MAX, playerLoadingCastNames(many).size)
        assertEquals(6, LOADING_CAST_MAX)
        assertEquals("Actor 1", playerLoadingCastNames(many).first())
        assertEquals("Actor 6", playerLoadingCastNames(many).last())
        assertEquals(2_200L, LOADING_CAST_ROTATE_MS)
    }

    @Test
    fun `info line without cast follows phases then the real pick`() {
        // No cast, no pick yet: the line is the phase word.
        assertEquals(
            "Finding streams…",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.FINDING_STREAMS, 0L, null, null
            )
        )
        assertEquals(
            "Picking best quality…",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.PICKING_QUALITY, 3_000L, null, null
            )
        )
        // Once a pick truly exists, source + quality take over —
        // and stay even as the phase moves on to LOADING.
        assertEquals(
            "HDHub4u · 2160P",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.LOADING, 5_000L, "HDHub4u", "2160P"
            )
        )
        // Whichever part the pick carries renders on its own.
        assertEquals(
            "HDHub4u",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.LOADING, 5_000L, "HDHub4u", null
            )
        )
        assertEquals(
            "1080P",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.LOADING, 5_000L, null, "1080P"
            )
        )
        // Blank strings are not a pick: the phase word stays.
        assertEquals(
            "Loading…",
            playerLoadingInfoLine(
                emptyList(), PlayerLoadingPhase.LOADING, 5_000L, " ", ""
            )
        )
        assertNull(playerLoadingPickedText(null, null))
        assertNull(playerLoadingPickedText(" ", " "))
    }

    @Test
    fun `info line with cast stays on the cast`() {
        // Cast beats both the phase words and a landed pick.
        val cast = listOf("Tom Cruise", "Rebecca Ferguson")
        assertEquals(
            "Starring Tom Cruise",
            playerLoadingInfoLine(
                cast, PlayerLoadingPhase.FINDING_STREAMS, 0L, "HDHub4u", "2160P"
            )
        )
        assertEquals(
            "Starring Rebecca Ferguson",
            playerLoadingInfoLine(
                cast, PlayerLoadingPhase.LOADING, 2_200L, "HDHub4u", "2160P"
            )
        )
    }

    @Test
    fun `heartbeat keyframes are the slowed lub-dub`() {
        // v0.14.34 (owner: "breath is so fast"): the locked
        // sample's 2s shape stretched ×1.6 to a calm 3.2s cycle,
        // dub peak softened 1.045 → 1.040, stillness tail grown.
        assertEquals(3200, HEARTBEAT_CYCLE_MS)
        assertEquals(
            listOf(
                0 to 1.000f, // rest
                224 to 1.028f, // lub
                416 to 1.010f, // dip
                704 to 1.040f, // dub — the peak
                1088 to 1.006f,
                1408 to 1.000f, // settled
                3200 to 1.000f // stillness to the cycle's end
            ),
            HEARTBEAT_KEYFRAMES
        )
        // The dub is the cycle's peak.
        assertEquals(1.040f, HEARTBEAT_KEYFRAMES.maxOf { it.second }, 0.0f)
        // Rises attack, falls ease: segments into lub/dub rise, the rest fall.
        assertTrue(heartbeatSegmentIsRise(0))
        assertTrue(!heartbeatSegmentIsRise(1))
        assertTrue(heartbeatSegmentIsRise(2))
        assertTrue(!heartbeatSegmentIsRise(3))
        assertTrue(!heartbeatSegmentIsRise(5))
        assertTrue(!heartbeatSegmentIsRise(6))
        // The sample's exact easing control points.
        assertEquals(listOf(0.16f, 1f, 0.3f, 1f), HEARTBEAT_RISE_EASING.toList())
        assertEquals(listOf(0.4f, 0f, 0.2f, 1f), HEARTBEAT_FALL_EASING.toList())
    }

    @Test
    fun `backdrop wins over poster, blanks fall through`() {
        assertEquals("bg", playerLoadingArt("bg", "poster"))
        assertEquals("poster", playerLoadingArt(null, "poster"))
        assertEquals("poster", playerLoadingArt("  ", "poster"))
        assertNull(playerLoadingArt(null, null))
        assertNull(playerLoadingArt("", " "))
    }

    @Test
    fun `meta line joins only the fields that exist`() {
        assertEquals(
            "2010 · 2h 28m · Sci-Fi · Thriller · ★ 8.8",
            playerLoadingMetaLine(
                releaseInfo = "2010",
                runtime = "148 min",
                genres = listOf("Sci-Fi", "Thriller", "Action"),
                imdbRating = "8.8"
            )
        )
        // A series range yields its first year.
        assertEquals(
            "2008",
            playerLoadingMetaLine("2008–2013", null, emptyList(), null)
        )
        // Missing fields simply don't render.
        assertEquals(
            "★ 7.5",
            playerLoadingMetaLine(null, null, emptyList(), "7.5")
        )
        assertEquals(
            "45 min · Drama",
            playerLoadingMetaLine(null, "45 min", listOf("Drama"), null)
        )
        // Nothing at all → no line.
        assertNull(playerLoadingMetaLine(null, null, emptyList(), null))
        assertNull(playerLoadingMetaLine(" ", " ", listOf(" "), " "))
    }

    @Test
    fun `runtime formats minutes over an hour as hours`() {
        assertEquals("2h 28m", formatLoadingRuntime("148 min"))
        assertEquals("1h", formatLoadingRuntime("60 min"))
        assertEquals("45 min", formatLoadingRuntime("45 min"))
        assertEquals("2h 28m", formatLoadingRuntime("2h 28m"))
        assertNull(formatLoadingRuntime(null))
        assertNull(formatLoadingRuntime("  "))
    }
}
