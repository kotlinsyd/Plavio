package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.39 (Follow actors): pins the followed-people store — the
 * encode/decode round-trip, the follow-time BASELINE rule (older
 * titles and unreadable years are baselined so day one never
 * floods the Home row), and the new-titles filter the Home row
 * renders.
 */
class FollowActorsSupportTest {

    private val year = 2026

    private fun meta(id: String, releaseInfo: String?, type: String = "movie") =
        MetaPreview(id = id, type = type, name = "Title $id", releaseInfo = releaseInfo)

    private fun person(vararg metas: MetaPreview) = PersonDetail(
        id = 42, name = "Test Actor", photo = "https://img.example/p.jpg",
        movies = metas.filter { it.type == "movie" },
        series = metas.filter { it.type == "series" }
    )

    @Test
    fun `encode decode round-trips actors including escapes`() {
        val actors = listOf(
            FollowedActor(1, "Anne | Hathaway", "https://x/y.jpg", setOf("tt1", "tt2")),
            FollowedActor(2, "Bob", null, emptySet())
        )
        val back = FollowActorsSupport.decode(FollowActorsSupport.encode(actors))
        assertEquals(actors, back)
    }

    @Test
    fun `decode of empty and legacy blank gives no actors`() {
        assertTrue(FollowActorsSupport.decode("").isEmpty())
        assertTrue(FollowActorsSupport.decode("[]").isEmpty())
        assertTrue(FollowActorsSupport.decode(null).isEmpty())
    }

    @Test
    fun `follow baselines everything before last year and unreadable years`() {
        val p = person(
            meta("tt_old", "2010"),
            meta("tt_edge", "2024"),       // currentYear - 2 → baseline
            meta("tt_recent", "2025"),     // currentYear - 1 → NOT baseline
            meta("tt_now", "2026"),
            meta("tt_nodate", null)        // unreadable → baseline
        )
        val followed = FollowActorsSupport.follow(emptyList(), p, year)
        assertEquals(1, followed.size)
        val baseline = followed.single().baselineIds
        assertTrue("tt_old" in baseline)
        assertTrue("tt_edge" in baseline)
        assertTrue("tt_nodate" in baseline)
        assertFalse("tt_recent" in baseline)
        assertFalse("tt_now" in baseline)
    }

    @Test
    fun `new titles are the unbaselined recent releases only`() {
        val p = person(
            meta("tt_old", "2010"),
            meta("tt_recent", "2025"),
            meta("tt_now", "2026"),
            meta("tt_range", "2025–2027", type = "series")
        )
        val actor = FollowActorsSupport.follow(emptyList(), p, year).single()
        val fresh = FollowActorsSupport.newTitles(p, actor, year).map { it.id }
        assertEquals(listOf("tt_recent", "tt_now", "tt_range"), fresh)
    }

    @Test
    fun `a release landing after the follow joins the new titles`() {
        val atFollow = person(meta("tt_old", "2010"), meta("tt_now", "2026"))
        val actor = FollowActorsSupport.follow(emptyList(), atFollow, year).single()
        val later = person(
            meta("tt_old", "2010"), meta("tt_now", "2026"), meta("tt_next", "2027")
        )
        val fresh = FollowActorsSupport.newTitles(later, actor, year).map { it.id }
        assertEquals(listOf("tt_now", "tt_next"), fresh)
    }

    @Test
    fun `double follow is a no-op and unfollow removes`() {
        val p = person(meta("tt_now", "2026"))
        val once = FollowActorsSupport.follow(emptyList(), p, year)
        val twice = FollowActorsSupport.follow(once, p, year)
        assertEquals(once, twice)
        assertTrue(FollowActorsSupport.unfollow(once, 42).isEmpty())
        assertTrue(FollowActorsSupport.isFollowed(once, 42))
        assertFalse(FollowActorsSupport.isFollowed(once, 7))
    }

    @Test
    fun `year of reads the first four digit run`() {
        assertEquals(2023, FollowActorsSupport.yearOf(meta("x", "2023–2025")))
        assertEquals(1999, FollowActorsSupport.yearOf(meta("x", "1999")))
        assertEquals(null, FollowActorsSupport.yearOf(meta("x", "unknown")))
        assertEquals(null, FollowActorsSupport.yearOf(meta("x", null)))
    }
}
