package com.pulsestream.app.data

import com.pulsestream.app.data.db.Profiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

/**
 * Item 5 (v0.14.38): the Search landing grids are persisted per
 * profile. The prefs-file naming is the seam that guarantees one
 * profile's saved "You May Like This" grid can never be read by
 * another profile, while the default profile keeps the historic
 * file name (grids saved before the change stay valid).
 */
class SearchSuggestCacheTest {

    @Test
    fun defaultProfileKeepsHistoricPrefsName() {
        assertEquals("plavio_search_suggest", SearchSuggestCache.prefsNameFor(Profiles.DEFAULT_ID))
    }

    @Test
    fun otherProfilesGetTheirOwnPrefsFile() {
        val a = SearchSuggestCache.prefsNameFor("profile_abc")
        val b = SearchSuggestCache.prefsNameFor("profile_xyz")
        assertEquals("plavio_search_suggest_profile_abc", a)
        assertNotEquals(a, b)
        assertNotEquals(a, SearchSuggestCache.prefsNameFor(Profiles.DEFAULT_ID))
    }

    @Test
    fun unsafeProfileIdCharsAreSanitised() {
        // SharedPreferences file names must stay filesystem-safe.
        assertEquals(
            "plavio_search_suggest_profile_a_b_c",
            SearchSuggestCache.prefsNameFor("profile a/b.c")
        )
    }

    @Test
    fun termsKeyIsOrderSensitiveAndNormalised() {
        assertEquals(
            SearchSuggestCache.termsKey(listOf(" Dune ", "OPPENHEIMER")),
            SearchSuggestCache.termsKey(listOf("dune", "oppenheimer"))
        )
        assertNotEquals(
            SearchSuggestCache.termsKey(listOf("dune", "oppenheimer")),
            SearchSuggestCache.termsKey(listOf("oppenheimer", "dune"))
        )
    }
}
