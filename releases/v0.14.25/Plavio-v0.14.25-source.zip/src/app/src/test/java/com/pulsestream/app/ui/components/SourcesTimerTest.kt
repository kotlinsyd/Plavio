package com.pulsestream.app.ui.components

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * v0.14.32 (item 2): pins the sources timer capsule's locked
 * words — live counting while loading, then time + ONE word:
 * under 10s "🚀 … · Rocket!", 10s and over "😌 … · Steady!".
 * (The owner's mid-build spec change removed the third verdict;
 * the capsule is display-only.)
 */
class SourcesTimerTest {

    @Test
    fun `under ten seconds is rocket, ten and over is steady`() {
        assertEquals(SourcesTimerMood.ROCKET, sourcesTimerMood(0L))
        assertEquals(SourcesTimerMood.ROCKET, sourcesTimerMood(9_999L))
        assertEquals(SourcesTimerMood.STEADY, sourcesTimerMood(10_000L))
        assertEquals(SourcesTimerMood.STEADY, sourcesTimerMood(31_200L))
        assertEquals(SourcesTimerMood.STEADY, sourcesTimerMood(600_000L))
    }

    @Test
    fun `elapsed formats as tenths with no locale separators`() {
        assertEquals("0.0s", formatSourcesElapsed(0L))
        assertEquals("2.3s", formatSourcesElapsed(2_300L))
        assertEquals("2.3s", formatSourcesElapsed(2_399L))
        assertEquals("14.5s", formatSourcesElapsed(14_500L))
        assertEquals("59.9s", formatSourcesElapsed(59_999L))
        assertEquals("61.0s", formatSourcesElapsed(61_000L))
        assertEquals("0.0s", formatSourcesElapsed(-500L))
    }

    @Test
    fun `loading and done lines are the exact locked words`() {
        assertEquals("⏱ Loading… 3.2s", sourcesTimerLoadingText(3_200L))
        assertEquals("🚀 2.3s · Rocket!", sourcesTimerDoneText(2_300L))
        assertEquals("😌 14.5s · Steady!", sourcesTimerDoneText(14_500L))
        assertEquals("😌 10.0s · Steady!", sourcesTimerDoneText(10_000L))
    }
}
