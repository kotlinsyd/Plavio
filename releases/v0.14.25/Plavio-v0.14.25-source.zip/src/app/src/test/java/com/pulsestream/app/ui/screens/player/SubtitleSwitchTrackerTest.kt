package com.pulsestream.app.ui.screens.player

import androidx.media3.common.MimeTypes
import com.pulsestream.app.data.ResolvedSubtitle
import com.pulsestream.app.data.Subtitle
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Subtitle switch fix (2026-11-09, owner's device report on
 * v0.14.31): Arabic picked in a previous session kept rendering
 * after he tapped English. Proven causes in the pre-fix code: the
 * Step-1 language tap applied nothing (navigation only), and a
 * not-yet-downloaded file pick parked in a pending slot with no
 * downloading state, no failure state and no exit when the
 * download/resolve failed ([com.pulsestream.app.data.resolveSubtitleFiles]
 * drops failures silently).
 *
 * These tests pin [SubtitlePickTracker] — the decision core the
 * fixed switch path runs on — plus [subtitleCandidatesForLanguage],
 * the candidate list the language tap picks from:
 *  - A active, pick B → B (and only B) is handed to the renderer;
 *  - pick unresolved → downloading state, auto-apply on publish;
 *  - resolve cycle that tried the pick but didn't publish it →
 *    visible failure, pending retired (no late resurrection);
 *  - a cycle that never attempted the pick changes nothing;
 *  - a persisted/remembered A in the same publish never wins
 *    over a fresh pending tap on B.
 */
class SubtitleSwitchTrackerTest {

    private val arabic = Subtitle(url = "https://subs.example/arabic.srt", lang = "ar")
    private val english = Subtitle(url = "https://subs.example/english.srt", lang = "en")
    private val english2 = Subtitle(url = "https://subs.example/english-sdh.srt", lang = "en")
    private val french = Subtitle(url = "https://subs.example/french.srt", lang = "fr")

    private fun resolved(sub: Subtitle) = ResolvedSubtitle(
        sub = sub,
        file = File("/tmp/${sub.url.hashCode()}"),
        mimeType = MimeTypes.APPLICATION_SUBRIP
    )

    @Test
    fun `active A, pick B - B is the rendered source and A is deactivated`() {
        val tracker = SubtitlePickTracker()
        tracker.markActivated(resolved(arabic))
        assertEquals(subtitleMatchKey(arabic.url), tracker.activeKey)

        tracker.beginPick(english, "English")
        val hit = tracker.activationFor(listOf(resolved(arabic), resolved(english)))
        assertEquals(resolved(english), hit)

        tracker.markActivated(hit!!)
        assertEquals(subtitleMatchKey(english.url), tracker.activeKey)
        assertFalse(tracker.isDownloading)
        assertNull(tracker.pendingKey)
    }

    @Test
    fun `unresolved pick shows downloading and auto-applies when it publishes`() {
        val tracker = SubtitlePickTracker()
        tracker.markActivated(resolved(arabic))
        tracker.beginPick(english, "English")

        assertTrue(tracker.isDownloading)
        assertEquals("English", tracker.pendingLabel)
        // Not published yet: nothing activates, A keeps rendering,
        // the pick stays visibly pending — never a silent switch.
        assertNull(tracker.activationFor(listOf(resolved(arabic))))
        assertTrue(tracker.isDownloading)
        assertEquals(subtitleMatchKey(arabic.url), tracker.activeKey)

        // The publish containing B activates B with no second tap.
        val hit = tracker.activationFor(listOf(resolved(arabic), resolved(english)))
        assertEquals(resolved(english), hit)
        tracker.markActivated(hit!!)
        assertFalse(tracker.isDownloading)
    }

    @Test
    fun `resolve cycle that tried the pick but did not publish it surfaces a failure`() {
        val tracker = SubtitlePickTracker()
        tracker.beginPick(english, "English")

        tracker.resolveCycleFinished(
            cycleInputs = listOf(arabic, english),
            published = listOf(resolved(arabic))
        )

        assertEquals("English", tracker.failedLabel)
        assertFalse(tracker.isDownloading)
        assertNull(tracker.pendingKey)
        // The dead pick can never resurrect over a newer choice:
        // a later publish containing it activates nothing.
        assertNull(tracker.activationFor(listOf(resolved(english))))
    }

    @Test
    fun `resolve cycle that never attempted the pick leaves it downloading`() {
        val tracker = SubtitlePickTracker()
        tracker.beginPick(english, "English")

        // This cycle's input predates the tap (it never tried B).
        tracker.resolveCycleFinished(
            cycleInputs = listOf(arabic),
            published = listOf(resolved(arabic))
        )

        assertNull(tracker.failedLabel)
        assertTrue(tracker.isDownloading)
        assertEquals(subtitleMatchKey(english.url), tracker.pendingKey)
    }

    @Test
    fun `persisted A in the same publish never overrides a fresh tap on B`() {
        val tracker = SubtitlePickTracker()
        // Arabic was the remembered/default choice and renders first.
        tracker.markActivated(resolved(arabic))

        tracker.beginPick(english, "English")
        // The publish carries the remembered A (listed first, as the
        // default would be) AND the tapped B: the pending tap wins.
        val hit = tracker.activationFor(listOf(resolved(arabic), resolved(english)))
        assertEquals(resolved(english), hit)
    }

    @Test
    fun `off cancels a pending pick so a late download cannot switch back on`() {
        val tracker = SubtitlePickTracker()
        tracker.beginPick(english, "English")
        tracker.cancel()

        assertFalse(tracker.isDownloading)
        assertNull(tracker.activationFor(listOf(resolved(english))))
    }

    @Test
    fun `a new pick retires the previous failure state`() {
        val tracker = SubtitlePickTracker()
        tracker.beginPick(english, "English")
        tracker.resolveCycleFinished(
            cycleInputs = listOf(english),
            published = emptyList()
        )
        assertEquals("English", tracker.failedLabel)

        tracker.beginPick(french, "French")
        assertNull(tracker.failedLabel)
        assertTrue(tracker.isDownloading)
        assertEquals(subtitleMatchKey(french.url), tracker.pendingKey)
    }

    @Test
    fun `a spelling-different publish of the pick still activates it`() {
        val tracker = SubtitlePickTracker()
        val listed = Subtitle(url = "https://subs.example.com/files/eng.srt", lang = "en")
        tracker.beginPick(listed, "English")

        val publishedCopy = resolved(
            Subtitle(url = "HTTPS://Subs.Example.com:443/files/eng.srt", lang = "en")
        )
        assertEquals(publishedCopy, tracker.activationFor(listOf(publishedCopy)))
    }

    @Test
    fun `language candidates are exactly that language, in panel order`() {
        val subs = listOf(arabic, english, french, english2)
        assertEquals(
            listOf(english, english2),
            subtitleCandidatesForLanguage(subs, "en")
        )
        assertEquals(listOf(arabic), subtitleCandidatesForLanguage(subs, "ar"))
        // ISO-639-2 tags match their 639-1 code, as everywhere else
        // in the app (subtitleLangMatches).
        val araTagged = Subtitle(url = "https://subs.example/ara.srt", lang = "ara")
        assertEquals(
            listOf(araTagged),
            subtitleCandidatesForLanguage(listOf(araTagged, english), "ar")
        )
        assertTrue(subtitleCandidatesForLanguage(subs, "ko").isEmpty())
    }
}
