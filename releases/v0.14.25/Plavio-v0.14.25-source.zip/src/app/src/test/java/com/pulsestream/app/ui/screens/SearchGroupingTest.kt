package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.CachedMeta
import com.pulsestream.app.data.MetaPreview
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pins for the grouped search results (v0.14.35): the split into
 * Movies / Series shelves must preserve the results' ranking
 * order inside each shelf, drop an empty shelf entirely, and
 * land every item on exactly one shelf.
 */
class SearchGroupingTest {
    private data class Item(val title: String, val type: String?)

    private fun item(title: String, type: String?) = Item(title, type)

    @Test fun splitPreservesRankingOrderWithinEachShelf() {
        val results = listOf(
            item("m1", "movie"),
            item("s1", "series"),
            item("m2", "movie"),
            item("s2", "series"),
            item("m3", "movie")
        )
        val groups = groupSearchResults(results) { it.type }
        assertEquals(
            listOf("m1", "m2", "m3"),
            groups.first { it.first == SearchResultShelf.MOVIES }.second.map { it.title }
        )
        assertEquals(
            listOf("s1", "s2"),
            groups.first { it.first == SearchResultShelf.SERIES }.second.map { it.title }
        )
    }

    @Test fun moviesShelfComesBeforeSeriesShelf() {
        val groups = groupSearchResults(
            listOf(item("s1", "series"), item("m1", "movie"))
        ) { it.type }
        assertEquals(
            listOf(SearchResultShelf.MOVIES, SearchResultShelf.SERIES),
            groups.map { it.first }
        )
    }

    @Test fun shelfTitlesAreMoviesAndSeries() {
        assertEquals("Movies", SearchResultShelf.MOVIES.title)
        assertEquals("Series", SearchResultShelf.SERIES.title)
    }

    @Test fun emptyGroupIsDroppedEntirely() {
        val moviesOnly = groupSearchResults(
            listOf(item("m1", "movie"), item("m2", "movie"))
        ) { it.type }
        assertEquals(1, moviesOnly.size)
        assertEquals(SearchResultShelf.MOVIES, moviesOnly.single().first)

        val seriesOnly = groupSearchResults(
            listOf(item("s1", "series"))
        ) { it.type }
        assertEquals(1, seriesOnly.size)
        assertEquals(SearchResultShelf.SERIES, seriesOnly.single().first)

        assertTrue(groupSearchResults(emptyList<Item>()) { it.type }.isEmpty())
    }

    @Test fun noItemIsDroppedOrDuplicated() {
        val results = listOf(
            item("a", "movie"), item("b", "series"), item("c", "tv"),
            item("d", "anime"), item("e", null), item("f", "movie")
        )
        val groups = groupSearchResults(results) { it.type }
        val flattened = groups.flatMap { it.second }
        assertEquals(results.size, flattened.size)
        assertEquals(results.toSet(), flattened.toSet())
    }

    @Test fun tvTypeIsASeriesShelfType() {
        // Addons publish shows as "tv" as well as "series"; both
        // are the episode-bearing family.
        assertEquals(SearchResultShelf.SERIES, searchResultShelf("tv"))
        assertEquals(SearchResultShelf.SERIES, searchResultShelf("series"))
    }

    @Test fun typeMatchingIgnoresCaseAndWhitespace() {
        assertEquals(SearchResultShelf.SERIES, searchResultShelf(" Series "))
        assertEquals(SearchResultShelf.SERIES, searchResultShelf("TV"))
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf(" Movie "))
    }

    @Test fun unknownAndBlankTypesFoldIntoMovies() {
        // MetaPreview carries no episode list, so an unknown type
        // has no episode-bearing signal: it stays visible on the
        // Movies shelf rather than vanishing or inventing a shelf.
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf("movie"))
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf("anime"))
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf(""))
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf("  "))
        assertEquals(SearchResultShelf.MOVIES, searchResultShelf(null))
    }

    @Test fun groupsRealCachedMetaByMetaType() {
        fun cached(id: String, type: String) = CachedMeta(
            addonId = "addon",
            addonName = "Addon",
            baseUrl = "",
            meta = MetaPreview(id = id, type = type, name = id)
        )
        val results = listOf(
            cached("m1", "movie"),
            cached("s1", "series"),
            cached("s2", "tv"),
            cached("m2", "movie")
        )
        val groups = groupSearchResults(results) { it.meta.type }
        assertEquals(
            listOf("m1", "m2"),
            groups.first { it.first == SearchResultShelf.MOVIES }.second.map { it.meta.id }
        )
        assertEquals(
            listOf("s1", "s2"),
            groups.first { it.first == SearchResultShelf.SERIES }.second.map { it.meta.id }
        )
    }
}
