package com.pulsestream.app.data.debrid

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Debrid-Link response parsing against fixtures shaped from the
 * official v2 API and maintained clients. The /seedbox/cached
 * endpoint is recorded as removed upstream, so its parser is only a
 * fast path when it answers; everything else rides add+poll.
 */
class DebridLinkApiTest {

    private val magnet = "magnet:?xt=urn:btih:ABCDEF0123456789ABCDEF0123456789ABCDEF01"
    private val hash = "abcdef0123456789abcdef0123456789abcdef01"

    @Test
    fun cached_hitByHashKey() {
        assertTrue(
            DebridLinkApi.parseCached(
                JSONObject(
                    """{"success":true,"value":{
                        "abcdef0123456789abcdef0123456789abcdef01":{
                            "name":"Movie","hashString":"abcdef0123456789abcdef0123456789abcdef01",
                            "files":[{"name":"movie.mkv","size":100}]
                        }
                    }}"""
                ),
                magnet,
                hash
            )
        )
    }

    @Test
    fun cached_entryWithoutFilesIsMiss() {
        assertFalse(
            DebridLinkApi.parseCached(
                JSONObject(
                    """{"success":true,"value":{
                        "abcdef0123456789abcdef0123456789abcdef01":{"name":"Movie","files":[]}
                    }}"""
                ),
                magnet,
                hash
            )
        )
    }

    @Test
    fun cached_absentEntryIsProvenMiss() {
        assertFalse(
            DebridLinkApi.parseCached(
                JSONObject("""{"success":true,"value":{}}"""),
                magnet,
                hash
            )
        )
    }

    @Test
    fun cached_authErrorThrows() {
        try {
            DebridLinkApi.parseCached(
                JSONObject("""{"success":false,"error":"badToken","error_description":"bad token"}"""),
                magnet,
                hash
            )
            fail("expected DebridLinkException")
        } catch (e: DebridLinkException) {
            assertTrue(e.isAuthError)
        }
    }

    @Test
    fun torrent_filesCarryDownloadUrls() {
        val torrent = DebridLinkApi.parseTorrent(
            JSONObject(
                """{"id":"t1","name":"Movie","hashString":"abc","downloaded":true,"status":4,
                    "totalSize":300,"downloadPercent":100,"error":0,"errorString":"",
                    "files":[
                        {"id":"f1","name":"movie.mkv","downloadUrl":"https://dl.example/1","downloaded":true,"size":200},
                        {"id":"f2","name":"subs.srt","downloadUrl":"https://dl.example/2","downloaded":true,"size":10}
                    ]}"""
            )
        )
        assertTrue(torrent.downloaded)
        assertEquals(2, torrent.files.size)
        assertEquals("movie.mkv", torrent.files[0].name)
        assertEquals("https://dl.example/1", torrent.files[0].downloadUrl)
        assertEquals(0, torrent.files[0].sourceIndex)
    }

    @Test
    fun torrent_errorFlagSurfaced() {
        val torrent = DebridLinkApi.parseTorrent(
            JSONObject(
                """{"id":"t2","name":"Bad","downloaded":false,"status":0,"error":3,
                    "errorString":"Torrent too big","files":[]}"""
            )
        )
        assertEquals(3, torrent.error)
        assertEquals("Torrent too big", torrent.errorString)
    }

    @Test
    fun addedTorrent_unwrapsValue() {
        val torrent = DebridLinkApi.parseAddedTorrent(
            JSONObject(
                """{"success":true,"value":{"id":"t9","name":"New","downloaded":false,"error":0,"files":[]}}"""
            )
        )
        assertEquals("t9", torrent.id)
    }
}
