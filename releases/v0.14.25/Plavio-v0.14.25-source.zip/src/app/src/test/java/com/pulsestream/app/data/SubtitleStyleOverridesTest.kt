package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.39 (settings audit D1): pins the per-title subtitle style
 * override — encode/decode round-trip, tolerant decode, and the
 * resolve rule (override field wins, else the global default) that
 * makes Settings the only home of the defaults while the in-player
 * rail adjusts one title only.
 */
class SubtitleStyleOverridesTest {

    private val globals = SubtitleStyleValues(
        fontSizeSp = 18,
        textColor = 0xFFFFFFFF.toInt(),
        backgroundColor = 0,
        bold = false,
        edgeType = 1,
        edgeColor = 0xFF000000.toInt(),
        bottomOffset = 20,
        fontFamily = 0
    )

    @Test
    fun `empty override encodes to blank and decodes back to empty`() {
        assertEquals("", SubtitleStyleOverride.EMPTY.encode())
        assertTrue(SubtitleStyleOverride.decode("").isEmpty)
        assertTrue(SubtitleStyleOverride.decode(null).isEmpty)
        assertTrue(SubtitleStyleOverride.decode("[]").isEmpty)
    }

    @Test
    fun `full override round-trips through encode and decode`() {
        val full = SubtitleStyleOverride(
            fontSizeSp = 24, textColor = 0xFFFFD93B.toInt(),
            backgroundColor = 0x99000000.toInt(), bold = true,
            edgeType = 3, edgeColor = 0xFF112233.toInt(),
            bottomOffset = 55, fontFamily = 2
        )
        assertEquals(full, SubtitleStyleOverride.decode(full.encode()))
    }

    @Test
    fun `partial override round-trips with the rest inherited`() {
        val partial = SubtitleStyleOverride(textColor = 0xFF00E5FF.toInt())
        val back = SubtitleStyleOverride.decode(partial.encode())
        assertEquals(partial, back)
        assertFalse(back.isEmpty)
    }

    @Test
    fun `decode skips unknown keys and bad values`() {
        val decoded = SubtitleStyleOverride.decode("zz=5;tc=oops;bd=1;fs=22")
        assertEquals(22, decoded.fontSizeSp)
        assertEquals(true, decoded.bold)
        assertEquals(null, decoded.textColor)
    }

    @Test
    fun `resolve takes the override field where set and the global elsewhere`() {
        val resolved = SubtitleStyleOverride(
            textColor = 0xFF00E5FF.toInt(), bold = true
        ).resolve(globals)
        assertEquals(0xFF00E5FF.toInt(), resolved.textColor)
        assertEquals(true, resolved.bold)
        assertEquals(globals.fontSizeSp, resolved.fontSizeSp)
        assertEquals(globals.backgroundColor, resolved.backgroundColor)
        assertEquals(globals.edgeType, resolved.edgeType)
        assertEquals(globals.edgeColor, resolved.edgeColor)
        assertEquals(globals.bottomOffset, resolved.bottomOffset)
        assertEquals(globals.fontFamily, resolved.fontFamily)
    }

    @Test
    fun `empty override resolves to exactly the globals`() {
        assertEquals(globals, SubtitleStyleOverride.EMPTY.resolve(globals))
    }
}
