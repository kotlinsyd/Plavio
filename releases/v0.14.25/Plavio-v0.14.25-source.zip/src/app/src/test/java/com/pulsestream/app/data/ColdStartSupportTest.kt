package com.pulsestream.app.data

import com.pulsestream.app.data.ColdStartSupport.CachedRowInfo
import com.pulsestream.app.data.ColdStartSupport.FetchEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pins for the v0.14.35 cold-start fix's pure seams:
 *  - the ONE "Home rows servable" definition the splash gate and
 *    Home's cached read now share (step 4),
 *  - the Home refresh fetch plan: non-TV only, provider first
 *    (steps 2+3),
 *  - progress-emission batching (step 2),
 *  - the persisted-manifest codec round-trip (step 5),
 *  - the owner's 5 s skeleton budget (step 8).
 */
class ColdStartSupportTest {

    // ---------- fetch plan (steps 2+3) ----------

    private fun manifest(
        id: String,
        catalogs: List<CatalogRef>,
        resources: List<String> = listOf("catalog", "meta", "stream")
    ) = AddonManifest(
        id = id, name = id, version = "1.0", description = "",
        types = listOf("movie", "series"), catalogs = catalogs,
        resources = resources
    )

    private fun cat(type: String, id: String) = CatalogRef(type = type, id = id, name = id)

    @Test
    fun fetchPlanExcludesTvCatalogs() {
        val plan = ColdStartSupport.homeFetchPlan(
            listOf(
                "live" to manifest(
                    "live",
                    listOf(cat("tv", "live-sports"), cat("movie", "top"))
                ),
                "meta" to manifest("meta", listOf(cat("series", "popular")))
            ),
            providerId = null
        )
        assertEquals(
            listOf(
                FetchEntry("live", "movie", "top"),
                FetchEntry("meta", "series", "popular")
            ),
            plan
        )
        assertTrue(plan.none { it.type == "tv" })
    }

    @Test
    fun fetchPlanPutsProviderCatalogsFirstAndStaysStable() {
        val plan = ColdStartSupport.homeFetchPlan(
            listOf(
                "a" to manifest("a", listOf(cat("movie", "a1"), cat("movie", "a2"))),
                "b" to manifest("b", listOf(cat("movie", "b1"))),
                "c" to manifest("c", listOf(cat("series", "c1"), cat("movie", "c2")))
            ),
            providerId = "c"
        )
        assertEquals(
            listOf(
                FetchEntry("c", "series", "c1"),
                FetchEntry("c", "movie", "c2"),
                FetchEntry("a", "movie", "a1"),
                FetchEntry("a", "movie", "a2"),
                FetchEntry("b", "movie", "b1")
            ),
            plan
        )
    }

    @Test
    fun fetchPlanSkipsManifestsWithoutCatalogResource() {
        val plan = ColdStartSupport.homeFetchPlan(
            listOf(
                "streams-only" to manifest(
                    "streams-only",
                    listOf(cat("movie", "top")),
                    resources = listOf("stream")
                ),
                "meta" to manifest("meta", listOf(cat("movie", "top")))
            ),
            providerId = null
        )
        assertEquals(listOf(FetchEntry("meta", "movie", "top")), plan)
    }

    @Test
    fun fetchPlanEmptyForNoManifests() {
        assertTrue(ColdStartSupport.homeFetchPlan(emptyList(), "x").isEmpty())
    }

    // ---------- provider resolution from cache (step 4) ----------

    private fun row(addonId: String, type: String = "movie", items: Int = 3, catalogId: String = "top") =
        CachedRowInfo(addonId = addonId, type = type, catalogId = catalogId, itemCount = items)

    @Test
    fun cachedProviderStoredPickWins() {
        val provider = ColdStartSupport.resolveCachedProviderId(
            rows = listOf(row("a"), row("b")),
            enabledAddonIds = setOf("a", "b"),
            storedProviderId = "b",
            providerOrder = { listOf("a", "b").indexOf(it) }
        )
        assertEquals("b", provider)
    }

    @Test
    fun cachedProviderFallsBackToBestRankedCandidate() {
        val provider = ColdStartSupport.resolveCachedProviderId(
            rows = listOf(row("a"), row("b")),
            enabledAddonIds = setOf("a", "b"),
            storedProviderId = "gone",
            providerOrder = { listOf("b", "a").indexOf(it) }
        )
        assertEquals("b", provider)
    }

    @Test
    fun cachedProviderNeedsNonTvNonEmptyEnabledRows() {
        // Only Live TV rows in the cache: the old splash gate called
        // this "feed ready"; the unified definition must not.
        assertNull(
            ColdStartSupport.resolveCachedProviderId(
                rows = listOf(row("live", type = "tv", items = 40)),
                enabledAddonIds = setOf("live"),
                storedProviderId = null,
                providerOrder = { 0 }
            )
        )
        // Empty rows don't make a candidate either.
        assertNull(
            ColdStartSupport.resolveCachedProviderId(
                rows = listOf(row("a", items = 0)),
                enabledAddonIds = setOf("a"),
                storedProviderId = null,
                providerOrder = { 0 }
            )
        )
        // Nor do a disabled addon's rows.
        assertNull(
            ColdStartSupport.resolveCachedProviderId(
                rows = listOf(row("a")),
                enabledAddonIds = emptySet(),
                storedProviderId = null,
                providerOrder = { 0 }
            )
        )
    }

    // ---------- servability (step 4) ----------

    private fun servable(
        row: CachedRowInfo,
        enabled: Set<String> = setOf("a", "b"),
        provider: String? = "a",
        visible: Boolean = true
    ) = ColdStartSupport.isHomeServable(row, enabled, provider) { _, _, _ -> visible }

    @Test
    fun servableHappyPath() {
        assertTrue(servable(row("a")))
        // No provider resolved -> the gate is skipped.
        assertTrue(servable(row("b"), provider = null))
    }

    @Test
    fun servableRejectsTvEmptyOtherProviderHiddenAndDisabled() {
        assertFalse(servable(row("a", type = "tv", items = 40)))
        assertFalse(servable(row("a", items = 0)))
        assertFalse(servable(row("b"))) // provider is "a"
        assertFalse(servable(row("a"), visible = false))
        assertFalse(servable(row("a"), enabled = setOf("b")))
    }

    // ---------- progress batching (step 2) ----------

    @Test
    fun progressEmissionDueRules() {
        assertTrue(ColdStartSupport.progressEmissionDue(newProviderRows = 1, rowsSinceEmission = 1))
        assertFalse(ColdStartSupport.progressEmissionDue(newProviderRows = 0, rowsSinceEmission = 3))
        assertTrue(
            ColdStartSupport.progressEmissionDue(
                newProviderRows = 0,
                rowsSinceEmission = ColdStartSupport.PROGRESS_EMIT_BATCH
            )
        )
        assertFalse(ColdStartSupport.progressEmissionDue(newProviderRows = 0, rowsSinceEmission = 0))
    }

    // ---------- skeleton budget (step 8) ----------

    @Test
    fun skeletonBudgetIsOwnersFiveSeconds() {
        assertEquals(5_000L, ColdStartSupport.HOME_SKELETON_FALLBACK_MS)
    }

    // ---------- manifest codec (step 5) ----------

    @Test
    fun manifestCodecRoundTripsFullManifest() {
        val original = AddonManifest(
            id = "community.plaviohd",
            name = "PlavioHD",
            version = "1.9.231",
            description = "House addon",
            types = listOf("movie", "series"),
            catalogs = listOf(
                CatalogRef(
                    type = "movie", id = "top", name = "Top",
                    extra = listOf("search", "genre"),
                    genreOptions = listOf("Action", "Drama")
                ),
                CatalogRef(type = "series", id = "popular", name = "Popular")
            ),
            resources = listOf("catalog", "meta", "stream", "subtitles"),
            configurable = true,
            logo = "https://example.com/logo.svg"
        )
        val decoded = ManifestCodec.decode(ManifestCodec.encode(original))
        assertEquals(original, decoded)
    }

    @Test
    fun manifestCodecRoundTripsMinimalManifest() {
        val original = AddonManifest(
            id = "a.b",
            name = "a.b",
            version = "",
            description = "",
            types = emptyList(),
            catalogs = emptyList(),
            resources = listOf("stream"),
            configurable = false,
            logo = null
        )
        assertEquals(original, ManifestCodec.decode(ManifestCodec.encode(original)))
    }

    @Test
    fun manifestCodecDecodeRejectsGarbage() {
        assertNull(ManifestCodec.decode("not json at all"))
        assertNull(ManifestCodec.decode("{}"))
    }

    @Test
    fun manifestStoreRoundTripsEntriesWithTimestamps() {
        val m = manifest("meta", listOf(cat("movie", "top"), cat("tv", "live")))
        val store = mapOf(
            "https://meta.example" to (123_456L to m),
            "https://other.example" to (999L to manifest("other", emptyList()))
        )
        val decoded = ManifestStoreCodec.decodeStore(ManifestStoreCodec.encodeStore(store))
        assertEquals(store, decoded)
    }

    @Test
    fun manifestStoreDecodesGarbageToEmpty() {
        assertTrue(ManifestStoreCodec.decodeStore(null).isEmpty())
        assertTrue(ManifestStoreCodec.decodeStore("").isEmpty())
        assertTrue(ManifestStoreCodec.decodeStore("{broken").isEmpty())
        assertTrue(ManifestStoreCodec.decodeStore("[1,2]").isEmpty())
    }
}
