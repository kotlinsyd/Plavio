package com.pulsestream.app.ui.components

import com.pulsestream.app.data.StreamItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.28 (owner's Elite-only + formatter-priority rule):
 * Elite is the only built-in badge style and the migration target
 * for every removed style; the Fusion filters[] pack shape parses
 * into canonical keys; addon-formatter-shaped rows are detected so
 * their text governs over app badges.
 */
class BadgeEliteOnlyTest {

    @Test
    fun `elite is the only built in and the fallback for removed styles`() {
        assertEquals(listOf(BadgeStyle.ELITE), BadgeStyle.builtIns)
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("ELITE"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("NARD"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("GROUPED"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("GOLD"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("MINIMALIST"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("ONYX"))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName(null))
        assertEquals(BadgeStyle.ELITE, BadgeStyle.fromName("junk"))
        assertEquals(BadgeStyle.IMPORTED, BadgeStyle.fromName("IMPORTED"))
    }

    @Test
    fun `fusion filter names map to canonical keys`() {
        assertEquals("res-2160p", canonicalBadgeKey("4K"))
        assertEquals("res-1080p", canonicalBadgeKey("1080p"))
        assertEquals("src-bluray", canonicalBadgeKey("BluRay"))
        assertEquals("src-webdl", canonicalBadgeKey("WebDL"))
        assertEquals("remux", canonicalBadgeKey("Remux"))
        assertEquals("hdr-hdr10plus", canonicalBadgeKey("HDR10+"))
        assertEquals("hdr-dv", canonicalBadgeKey("DV"))
        assertEquals("audio-dtshd", canonicalBadgeKey("DTS-HD MA"))
        assertEquals("audio-dtshd", canonicalBadgeKey("DTS-HD"))
        assertEquals("audio-ddp", canonicalBadgeKey("DD+"))
        assertEquals("audio-truehd", canonicalBadgeKey("TrueHD"))
        assertEquals("atmos", canonicalBadgeKey("Atmos"))
        assertEquals("codec-hevc", canonicalBadgeKey("H265 HEVC"))
        assertEquals("codec-avc", canonicalBadgeKey("H264 AVC"))
        assertEquals("ch-71", canonicalBadgeKey("7.1"))
        assertEquals("ch-51", canonicalBadgeKey("5.1"))
        assertEquals("lang-en", canonicalBadgeKey("English"))
        assertEquals("lang-es", canonicalBadgeKey("Spanish"))
        assertEquals("lang-ja", canonicalBadgeKey("Japanese"))
        // Combo / streaming / unkeyed names are skipped, never blank.
        assertNull(canonicalBadgeKey("Atmos+DV"))
        assertNull(canonicalBadgeKey("DTS:X"))
        assertNull(canonicalBadgeKey("NETFLIX"))
        assertNull(canonicalBadgeKey("IMAX"))
        assertNull(canonicalBadgeKey("Multi"))
    }

    // Note: the filters[] extraction itself (collectPackEntries)
    // runs on org.json, which is a stub in plain JVM unit tests —
    // it is exercised on-device through the existing import flow,
    // whose other shapes (direct maps, GitHub listings, HTML) ride
    // the same org.json path. The name→key half is pure and is
    // covered by the test above.

    private fun stream(name: String?, title: String?) = StreamItem(
        url = "https://example.test/x.mkv", name = name, title = title,
        sourceName = "PlavioHD"
    )

    @Test
    fun `default composition is not formatter shaped`() {
        // PlavioHD Default: name "<Provider> <quality>", title =
        // filename line over one details line (2 lines total here
        // because streamDisplayName-style rows carry name+title).
        assertFalse(
            isAddonFormatted(
                stream(
                    "HDHub4u 2160p",
                    "Movie.2026.2160p.WEB-DL.x265.mkv"
                )
            )
        )
        assertFalse(isAddonFormatted(stream("HDHub4u 1080p", "2160p · Hindi · 5.1 · 8.2 GB")))
    }

    @Test
    fun `preset shaped rows are formatter shaped`() {
        // Plavio Modern: emoji name + multi-line emoji description.
        assertTrue(
            isAddonFormatted(
                stream(
                    "🌀 Plavio ❄️ 4K • HDHub4u",
                    "🍿 Movie\n🎞️ 2160p • WEB-DL\n🛰️ Source: PlavioHD • HDHub4u\n💾 8.2 GB"
                )
            )
        )
        // Torrentio Minimalist: separator name + 3 title lines.
        assertTrue(
            isAddonFormatted(
                stream(
                    "1080p • HDHub4u",
                    "Movie Title\n1080p x265 | 2.1 GB | HDHub4u\nAudio: Hindi"
                )
            )
        )
        // Pure Essentials: separator name alone is enough.
        assertTrue(
            isAddonFormatted(stream("Auto • Direct • Vidrock", "Movie Title"))
        )
        // Custom template with an emoji-led line.
        assertTrue(
            isAddonFormatted(stream("Vidrock 2160p", "🧩 Movie | 2160p | WEB-DL"))
        )
        // MediaFusion Pro: pipe-separated spec lines in the title.
        assertTrue(
            isAddonFormatted(
                stream(
                    "HDHub4u 2160p",
                    "Movie Name (2026)\n2160p | BluRay | Hindi | 8.2 GB"
                )
            )
        )
    }

    @Test
    fun `v0_14_29 widened shapes are formatter shaped`() {
        // Torrentio Minimalist WITHOUT emoji or separators: the
        // title's second line is a plain specs line (3 spec-token
        // families, not a dotted filename).
        assertTrue(
            isAddonFormatted(
                stream("2160p KmMovies", "2160p BluRay x265 · 2.1 GB")
            )
        )
        // AIOStreams-style: formatting lives in bracketed tokens on
        // a single name line, description empty.
        assertTrue(
            isAddonFormatted(stream("[HDR] [DV] Movie Name 2160p WEB-DL", null))
        )
        // AIOStreams-style: separators in the TITLE (v0.14.28 only
        // looked at the name).
        assertTrue(
            isAddonFormatted(stream("Torrentio 2160p", "Movie | 2160p | BluRay"))
        )
        // Fusion bracket shape: bracketed tokens trailing the name.
        assertTrue(
            isAddonFormatted(
                stream("Movie Name 2160p [DV] [Atmos] [REMUX]", "2.1 GB")
            )
        )
    }

    @Test
    fun `v0_14_33 preset blind spots are formatter shaped`() {
        // Verbatim live rows the detector missed (owner-reported
        // 2026-11-09): the rows were re-dressed as plain house rows.
        // MinimalisticGDrive: the 🧿 name lead was unrecognised.
        assertTrue(isAddonFormatted(stream("🧿1080p", "1080p")))
        // MinimalisticGDrive: 💿 name lead / 🌎 title lead.
        assertTrue(isAddonFormatted(stream("💿720p", "🌎 Hindi")))
        // GDrive: 🔍 title lead; a 2-line row with no separator.
        assertTrue(isAddonFormatted(stream("Cinezo 1080p", "🔍 Cinezo")))
        // Tamtaro: ✎-led title carrying ⛉ and its " · " separator.
        assertTrue(
            isAddonFormatted(stream("1080P⁽ʷᵉᵇ⁾", "✎ Cinezo ⛉ 1.2 GB · Hindi"))
        )
        // Tamtaro: ⛉-led title line.
        assertTrue(
            isAddonFormatted(stream("1080P⁽ʷᵉᵇ⁾", "⛉ 1.2 GB · Hindi"))
        )
        // Tamtaro: " · " in the title counts with a formatter glyph
        // present in the row even when no line is led by it.
        assertTrue(
            isAddonFormatted(stream("Vidrock 1080p", "Size ⛉ 1.2 GB · Hindi"))
        )
        // " · " as the NAME separator counts on its own.
        assertTrue(isAddonFormatted(stream("1080p · Tamtaro", "Movie Title")))
        // Guard: a bare " · " title with no formatter glyph anywhere
        // is the PlavioHD Default details-line shape and must stay
        // on the house path (also pinned in the Default test above).
        assertFalse(isAddonFormatted(stream("Vidrock 1080p", "1080p · Hindi · 5.1")))
    }

    @Test
    fun `specs pattern in the name only stays on the house path`() {
        // A Default-style name carrying quality + source tokens over
        // a filename title: the specs-pattern rule must not flip it
        // (formatters put their spec lines in the title).
        assertFalse(
            isAddonFormatted(
                stream("TMAddon 1080p BluRay", "Movie.2024.1080p.WEB-DL.x265.mkv")
            )
        )
        // The same name repeated as its own title must not flip
        // itself either.
        assertFalse(isAddonFormatted(stream("TMAddon 1080p BluRay", "TMAddon 1080p BluRay")))
        // But a plain specs line in the TITLE (Torrentio Minimalist
        // without separators) is a formatter row.
        assertTrue(isAddonFormatted(stream("Torrentio", "1080p WEB-DL x265")))
    }

    @Test
    fun `default rows with a bracket tag stay on the house path`() {
        // A Default details/filename line can carry ONE leading
        // bracket tag — that alone must not flip the row to raw.
        assertFalse(
            isAddonFormatted(
                stream(
                    "HDHub4u 2160p",
                    "[FSLv2] Movie.2026.2160p.WEB-DL.x265.mkv"
                )
            )
        )
    }

    @Test
    fun `formatted text renders verbatim`() {
        // Name block then title block, every line exactly as
        // composed, in the addon's own order.
        assertEquals(
            "🌀 Plavio ❄️ 4K • HDHub4u\n🍿 Movie\n🎞️ 2160p • WEB-DL",
            addonFormattedText(
                stream("🌀 Plavio ❄️ 4K • HDHub4u", "🍿 Movie\n🎞️ 2160p • WEB-DL")
            )
        )
        // Lines that overlap each other are NOT deduped away (the
        // v0.14.28 re-compose dropped them).
        assertEquals(
            "Movie 2160p\nMovie 2160p\n2160p WEB-DL",
            addonFormattedText(stream("Movie 2160p", "Movie 2160p\n2160p WEB-DL"))
        )
        // Byte-identical name and title print once.
        assertEquals(
            "Same text",
            addonFormattedText(stream("Same text", "Same text"))
        )
        // Missing title -> the name alone; missing name -> title.
        assertEquals("Only name", addonFormattedText(stream("Only name", null)))
        assertEquals("Only title", addonFormattedText(stream(null, "Only title")))
    }
}
