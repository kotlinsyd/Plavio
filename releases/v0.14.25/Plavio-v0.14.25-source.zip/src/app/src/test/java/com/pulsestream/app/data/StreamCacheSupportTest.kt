package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.36 (defect 1): the session stream cache's seed rules. The
 * cache holds formatter-composed stream text; a 3-hour seed window
 * (v0.14.21) plus zero lifecycle invalidation froze that text after
 * server-side style changes. These pins hold the window at the
 * documented few minutes and guarantee that callers which settle on
 * an emission can suppress the seed entirely.
 */
class StreamCacheSupportTest {

    private val now = 1_700_000_000_000L

    @Test
    fun `seed window is five minutes`() {
        assertEquals(5L * 60L * 1000L, StreamCacheSupport.SEED_TTL_MS)
    }

    @Test
    fun `fresh entry emits as seed when the caller allows it`() {
        assertTrue(StreamCacheSupport.shouldEmitSeed(now - 60_000L, now, seedFromCache = true))
        assertTrue(StreamCacheSupport.shouldEmitSeed(now - 1L, now, seedFromCache = true))
    }

    @Test
    fun `entry at or past the window never emits`() {
        assertFalse(
            StreamCacheSupport.shouldEmitSeed(
                now - StreamCacheSupport.SEED_TTL_MS, now, seedFromCache = true
            )
        )
        assertFalse(StreamCacheSupport.shouldEmitSeed(now - 3L * 3600L * 1000L, now, seedFromCache = true))
        assertFalse(StreamCacheSupport.isSeedFresh(now - StreamCacheSupport.SEED_TTL_MS, now))
    }

    @Test
    fun `seed suppressed callers never emit even for a fresh entry`() {
        assertFalse(StreamCacheSupport.shouldEmitSeed(now - 1_000L, now, seedFromCache = false))
        assertFalse(StreamCacheSupport.shouldEmitSeed(now, now, seedFromCache = false))
    }

    @Test
    fun `missing or uninitialised entries never emit`() {
        assertFalse(StreamCacheSupport.shouldEmitSeed(null, now, seedFromCache = true))
        assertFalse(StreamCacheSupport.shouldEmitSeed(0L, now, seedFromCache = true))
        assertFalse(StreamCacheSupport.isSeedFresh(0L, now))
    }
}
