package com.pulsestream.app.data.debrid

import com.pulsestream.app.data.StreamItem
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Native debrid layer (v0.14.28): provider order, first-success-wins,
 * NotCached fall-through, the playability gate, the AppConfig switch-
 * off path, magnet/hash extraction, pending-row identity, the account
 * state model and the shared file selection. Pure logic only — the
 * per-provider HTTP clients are fixture-tested in their own suites.
 */
class DebridServiceTest {

    private fun provider(tag: String, result: DebridResolveResult) =
        DebridService.Provider(tag = tag, diagnosticsName = tag) { _, _, _ -> result }

    private fun pendingRow(url: String = "infohash:abc123", hash: String? = "abc123") =
        StreamItem(url = url, infoHash = hash)

    @Test
    fun providerOrder_createTagsTorBoxFirst() {
        val service = DebridService.create(
            torboxApiKey = "tb",
            realDebridApiKey = "rd",
            premiumizeApiKey = "pm",
            allDebridApiKey = "ad",
            debridLinkApiKey = "dl",
            offcloudApiKey = "oc",
            enabled = true
        )
        assertTrue(service.isActive)
        assertEquals(
            listOf("⚡ TorBox", "⚡ RD", "⚡ Premiumize", "⚡ AllDebrid", "⚡ Debrid-Link", "⚡ Offcloud"),
            service.providerTags
        )
    }

    @Test
    fun create_withNoKeys_isInactive() {
        val service = DebridService.create(null, null, null, null, null, null, enabled = true)
        assertFalse(service.isActive)
        assertTrue(service.providerTags.isEmpty())
    }

    @Test
    fun switchOff_disablesEverything() = runBlocking {
        val service = DebridService.create(
            torboxApiKey = "tb",
            realDebridApiKey = "rd",
            premiumizeApiKey = "pm",
            allDebridApiKey = "ad",
            debridLinkApiKey = "dl",
            offcloudApiKey = "oc",
            enabled = false
        )
        assertFalse(service.isActive)
        var applied = 0
        service.resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { true },
            applyResolved = { _, _, _, _ -> applied++ }
        )
        assertEquals(0, applied)
        // Also with providers present but the list empty by construction.
        val manual = DebridService(emptyList())
        assertFalse(manual.isActive)
    }

    @Test
    fun firstSuccessWins_laterProvidersNeverCalled() = runBlocking {
        var secondCalled = false
        val first = DebridService.Provider("one", "one") { _, _, _ ->
            DebridResolveResult.Resolved("https://cdn.example/v.mp4")
        }
        val second = DebridService.Provider("two", "two") { _, _, _ ->
            secondCalled = true
            DebridResolveResult.Resolved("https://cdn.example/other.mp4")
        }
        val applied = mutableListOf<String>()
        DebridService(listOf(first, second)).resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { it.startsWith("https://") },
            applyResolved = { _, _, tag, url -> applied += "$tag|$url" }
        )
        assertEquals(listOf("one|https://cdn.example/v.mp4"), applied)
        assertFalse(secondCalled)
    }

    @Test
    fun notCached_fallsThroughToNextProvider() = runBlocking {
        val applied = mutableListOf<String>()
        DebridService(
            listOf(
                provider("one", DebridResolveResult.NotCached),
                provider("two", DebridResolveResult.Resolved("https://cdn.example/v.mkv"))
            )
        ).resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { true },
            applyResolved = { _, _, tag, _ -> applied += tag }
        )
        assertEquals(listOf("two"), applied)
    }

    @Test
    fun error_fallsThroughToo() = runBlocking {
        val applied = mutableListOf<String>()
        DebridService(
            listOf(
                provider("one", DebridResolveResult.Error("boom")),
                provider("two", DebridResolveResult.Resolved("https://cdn.example/v.mkv"))
            )
        ).resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { true },
            applyResolved = { _, _, tag, _ -> applied += tag }
        )
        assertEquals(listOf("two"), applied)
    }

    @Test
    fun unplayableResolvedUrl_doesNotWin() = runBlocking {
        val applied = mutableListOf<String>()
        DebridService(
            listOf(
                provider("one", DebridResolveResult.Resolved("magnet:?xt=urn:btih:abc123")),
                provider("two", DebridResolveResult.Resolved("https://cdn.example/v.mkv"))
            )
        ).resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { it.startsWith("http") },
            applyResolved = { _, _, tag, _ -> applied += tag }
        )
        assertEquals(listOf("two"), applied)
    }

    @Test
    fun allProvidersMiss_nothingApplied() = runBlocking {
        var applied = 0
        DebridService(
            listOf(
                provider("one", DebridResolveResult.NotCached),
                provider("two", DebridResolveResult.NotCached)
            )
        ).resolveAll(
            pending = listOf(pendingRow()),
            isPlayable = { true },
            applyResolved = { _, _, _, _ -> applied++ }
        )
        assertEquals(0, applied)
    }

    @Test
    fun magnetHash_extraction() {
        val hex = "0123456789abcdef0123456789abcdef01234567"
        assertEquals(hex, DebridSupport.magnetHash("magnet:?xt=urn:btih:$hex&dn=Movie"))
        assertEquals(
            hex,
            DebridSupport.magnetHash("magnet:?dn=Movie&xt=urn:btih:${hex.uppercase()}&tr=udp://t")
        )
        // Base32 (32 chars) is a valid btih form.
        assertEquals(
            "abcdefghijklmnopqrstuvwxyz234567",
            DebridSupport.magnetHash("magnet:?xt=urn:btih:ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
        )
        assertNull(DebridSupport.magnetHash("magnet:?dn=NoHash"))
        assertNull(DebridSupport.magnetHash("magnet:?xt=urn:btih:tooshort"))
        assertNull(DebridSupport.magnetHash("https://example.com/file.mkv"))
        assertNull(DebridSupport.magnetHash(""))
    }

    @Test
    fun hashFor_andPendingStreams() {
        val infoRow = StreamItem(url = "infohash:deadbeef", infoHash = "deadbeef")
        val magnetRow = StreamItem(url = "magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567")
        val magnetWithField = StreamItem(
            url = "magnet:?xt=urn:btih:whatever",
            infoHash = "cafebabe"
        )
        val direct = StreamItem(url = "https://cdn.example/v.mp4")
        val bareInfohashUrl = StreamItem(url = "infohash:deadbeef")

        assertEquals("deadbeef", DebridSupport.hashFor(infoRow))
        assertEquals(
            "0123456789abcdef0123456789abcdef01234567",
            DebridSupport.hashFor(magnetRow)
        )
        assertEquals("cafebabe", DebridSupport.hashFor(magnetWithField))
        assertNull(DebridSupport.hashFor(direct))
        // Today's rule preserved: an infohash: URL without the field
        // was never pending and still is not.
        assertNull(DebridSupport.hashFor(bareInfohashUrl))

        assertEquals(
            listOf(infoRow, magnetRow, magnetWithField),
            DebridSupport.pendingStreams(listOf(infoRow, direct, magnetRow, bareInfohashUrl, magnetWithField))
        )
    }

    @Test
    fun samePendingRow_identity() {
        val target = StreamItem(
            url = "infohash:deadbeef", infoHash = "deadbeef", fileIdx = 2, filePath = "E03.mkv"
        )
        assertTrue(
            DebridSupport.isSamePendingRow(
                StreamItem(url = "infohash:deadbeef", infoHash = "deadbeef", fileIdx = 2, filePath = "E03.mkv"),
                target
            )
        )
        assertFalse(
            DebridSupport.isSamePendingRow(
                StreamItem(url = "infohash:deadbeef", infoHash = "deadbeef", fileIdx = 3, filePath = "E03.mkv"),
                target
            )
        )
        assertFalse(
            DebridSupport.isSamePendingRow(
                StreamItem(url = "infohash:other", infoHash = "other", fileIdx = 2, filePath = "E03.mkv"),
                target
            )
        )
        val magnetTarget = StreamItem(url = "magnet:?xt=urn:btih:abc&dn=X")
        assertTrue(
            DebridSupport.isSamePendingRow(StreamItem(url = "magnet:?xt=urn:btih:abc&dn=X"), magnetTarget)
        )
        assertFalse(
            DebridSupport.isSamePendingRow(StreamItem(url = "magnet:?xt=urn:btih:abc&dn=Y"), magnetTarget)
        )
    }

    @Test
    fun accountState_mapping() {
        assertEquals(
            DebridSupport.AccountState.NO_KEY,
            DebridSupport.accountState(keyPresent = false, persistedVerdict = null)
        )
        assertEquals(
            DebridSupport.AccountState.NOT_CHECKED,
            DebridSupport.accountState(keyPresent = true, persistedVerdict = null)
        )
        assertEquals(
            DebridSupport.AccountState.ACTIVE,
            DebridSupport.accountState(keyPresent = true, persistedVerdict = "working")
        )
        assertEquals(
            DebridSupport.AccountState.INVALID,
            DebridSupport.accountState(keyPresent = true, persistedVerdict = "rejected")
        )
        assertEquals(
            DebridSupport.AccountState.UNREACHABLE,
            DebridSupport.accountState(keyPresent = true, persistedVerdict = "unreachable")
        )
        assertEquals(
            DebridSupport.AccountState.CHECKING,
            DebridSupport.accountState(keyPresent = true, persistedVerdict = "working", checkInFlight = true)
        )
        assertEquals("Working", DebridSupport.accountStateText(DebridSupport.AccountState.ACTIVE))
        assertEquals("Not connected", DebridSupport.accountStateText(DebridSupport.AccountState.NO_KEY))
    }

    @Test
    fun fileSelection_mirrorsTorBoxRules() {
        val single = listOf(
            DebridFileSelection.FileEntry("notes.txt", 10, 0),
            DebridFileSelection.FileEntry("movie.mkv", 100, 1)
        )
        assertEquals(1, DebridFileSelection.select(single, null, null)?.sourceIndex)

        val pack = listOf(
            DebridFileSelection.FileEntry("a.mkv", 100, 0),
            DebridFileSelection.FileEntry("b.mkv", 200, 1)
        )
        // No hints + several videos: refuse to guess (never largest).
        assertNull(DebridFileSelection.select(pack, null, null))
        assertEquals(1, DebridFileSelection.select(pack, 1, null)?.sourceIndex)
        assertEquals(0, DebridFileSelection.select(pack, null, "a.mkv")?.sourceIndex)
        assertNull(DebridFileSelection.select(pack, 1, "a.mkv"))
        assertNull(DebridFileSelection.select(pack, 7, null))
    }
}
