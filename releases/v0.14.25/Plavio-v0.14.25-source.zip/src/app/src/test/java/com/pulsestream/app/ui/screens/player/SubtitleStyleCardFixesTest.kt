package com.pulsestream.app.ui.screens.player

import android.app.Application
import android.graphics.Typeface
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * v0.14.31 items 1 + 4 — the subtitle Style card fixes.
 *
 * Item 1: the SIZE row printed the raw Compose state object
 * ("MutableIntState(value=19)@259105137.value sp") because the
 * template interpolated the state instead of its value. The row
 * now renders [subtitleSizeName] / [subtitleSizeText], pure
 * functions of the Int — these tests pin the wording so no
 * state object can ever reach the screen through them again.
 *
 * Item 4: the Bold toggle must change the actual caption
 * weight, not just flip a UI state. The toggle writes
 * SettingsStore.subtitleBold; applySubtitleStyle feeds it to
 * [subtitleTypeface], whose result goes into the renderer's
 * CaptionStyleCompat. These tests pin that seam: bold yields a
 * BOLD-styled typeface for every family, no-bold keeps the
 * family face, and System+no-bold keeps the null (renderer
 * default) exactly as before.
 */
@RunWith(RobolectricTestRunner::class)
@Config(application = Application::class, sdk = [35])
class SubtitleStyleCardFixesTest {

    @Test
    fun `size text is the clean human size for every storable value`() {
        for (sp in 12..40 step 2) {
            val text = subtitleSizeText(sp)
            assertEquals("$sp sp", text)
            assertFalse(text.contains("MutableIntState"))
            assertFalse(text.contains("@"))
            assertFalse(text.contains("value"))
        }
        assertEquals("19 sp", subtitleSizeText(19))
    }

    @Test
    fun `size name bands match the card's long-standing bands`() {
        assertEquals("Small", subtitleSizeName(12))
        assertEquals("Small", subtitleSizeName(16))
        assertEquals("Medium", subtitleSizeName(19))
        assertEquals("Medium", subtitleSizeName(24))
        assertEquals("Large", subtitleSizeName(26))
        assertEquals("Large", subtitleSizeName(32))
        assertEquals("Extra large", subtitleSizeName(34))
        assertEquals("Extra large", subtitleSizeName(40))
    }

    @Test
    fun `bold on produces a bold-styled typeface for every family`() {
        for (family in 0..3) {
            val tf = subtitleTypeface(family, bold = true)
            assertNotNull("family $family bold must yield a typeface", tf)
            // The invariant the renderer relies on: the bold
            // face carries the framework's BOLD style bit. (The
            // convenience isBold getter is NOT used — Robolectric's
            // shadow typeface doesn't back it for create() faces,
            // while the style int is what CaptionStyleCompat
            // itself consumes on device.)
            assertTrue(
                "family $family bold must carry the BOLD style bit",
                tf!!.style and Typeface.BOLD != 0
            )
        }
    }

    @Test
    fun `bold off keeps the family face and the system default`() {
        // System (0) + no bold = null: the renderer default,
        // untouched users see no change (pre-fix behaviour).
        assertNull(subtitleTypeface(0, bold = false))
        // Named families + no bold = the plain family face,
        // never carrying the BOLD style bit.
        for (family in 1..3) {
            val tf = subtitleTypeface(family, bold = false)
            assertNotNull(tf)
            assertTrue(
                "family $family without bold must not carry BOLD",
                tf!!.style and Typeface.BOLD == 0
            )
        }
        assertEquals(Typeface.SANS_SERIF, subtitleTypeface(1, bold = false))
        assertEquals(Typeface.SERIF, subtitleTypeface(2, bold = false))
        assertEquals(Typeface.MONOSPACE, subtitleTypeface(3, bold = false))
    }
}
