package com.pulsestream.app.ui.screens.player

import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.StreamResult
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerStartupTest {
    @Test
    fun playerStartsPreparingBeforeSavedPositionLookupCanSuspend() = runBlocking {
        val events = mutableListOf<String>()
        val savedPosition = CompletableDeferred<Long>()
        val startup = async(start = CoroutineStart.UNDISPATCHED) {
            preparePlayerBeforeSavedPositionLookup(
                preparePlayer = { events += "prepare" },
                loadSavedPosition = {
                    events += "load-position"
                    savedPosition.await()
                }
            )
        }

        assertEquals(listOf("prepare", "load-position"), events)
        assertFalse(startup.isCompleted)
        savedPosition.complete(42_000L)
        assertEquals(42_000L, startup.await())
    }

    @Test
    fun staleResumeUrlDoesNotPreloadWhileFreshSourceResolutionMayBeNeeded() = runBlocking {
        val events = mutableListOf<String>()
        val saved = preparePlayerBeforeSavedPositionLookup(
            preparePlayer = { events += "prepare-old-url" },
            loadSavedPosition = { events += "load-position"; 42_000L },
            prepareEarly = false
        )
        assertEquals(listOf("load-position"), events)
        assertEquals(42_000L, saved)
    }

    @Test
    fun mobileLiveStartupWatchdogOnlyFiresAfterTimeoutWhileWaitingToPlay() {
        assertFalse(shouldFailoverStalledLiveStartup(
            isLive = true, isTv = false, playWhenReady = true, hasEverPlayed = false,
            isBuffering = true, elapsedMs = MOBILE_LIVE_STARTUP_TIMEOUT_MS - 1
        ))
        assertTrue(shouldFailoverStalledLiveStartup(
            isLive = true, isTv = false, playWhenReady = true, hasEverPlayed = false,
            isBuffering = true, elapsedMs = MOBILE_LIVE_STARTUP_TIMEOUT_MS
        ))
    }

    @Test
    fun mobileLiveStartupWatchdogNeverInterruptsVODTVPausedOrPreviouslyHealthyPlayback() {
        val elapsed = MOBILE_LIVE_STARTUP_TIMEOUT_MS * 2
        fun check(
            isLive: Boolean = true,
            isTv: Boolean = false,
            playWhenReady: Boolean = true,
            hasEverPlayed: Boolean = false,
            isBuffering: Boolean = true
        ) = shouldFailoverStalledLiveStartup(
            isLive, isTv, playWhenReady, hasEverPlayed, isBuffering, elapsed
        )

        assertFalse(check(isLive = false))
        assertFalse(check(isTv = true))
        assertFalse(check(playWhenReady = false))
        assertFalse(check(hasEverPlayed = true))
        assertFalse(check(isBuffering = false))
    }

    @Test
    fun mobileLiveRebufferWatchdogRecoversOnlyAfterSustainedBufferingAfterPlayback() {
        assertFalse(shouldFailoverStalledLiveRebuffer(
            isLive = true, isTv = false, playWhenReady = true, hasEverPlayed = true,
            isBuffering = true, elapsedMs = MOBILE_LIVE_REBUFFER_TIMEOUT_MS - 1
        ))
        assertTrue(shouldFailoverStalledLiveRebuffer(
            isLive = true, isTv = false, playWhenReady = true, hasEverPlayed = true,
            isBuffering = true, elapsedMs = MOBILE_LIVE_REBUFFER_TIMEOUT_MS
        ))
    }

    @Test
    fun mobileLiveRebufferWatchdogDoesNotInterruptPausedVodTvOrStartup() {
        val elapsed = MOBILE_LIVE_REBUFFER_TIMEOUT_MS * 2
        fun check(
            isLive: Boolean = true,
            isTv: Boolean = false,
            playWhenReady: Boolean = true,
            hasEverPlayed: Boolean = true,
            isBuffering: Boolean = true
        ) = shouldFailoverStalledLiveRebuffer(
            isLive, isTv, playWhenReady, hasEverPlayed, isBuffering, elapsed
        )
        assertFalse(check(isLive = false))
        assertFalse(check(isTv = true))
        assertFalse(check(playWhenReady = false))
        assertFalse(check(hasEverPlayed = false))
        assertFalse(check(isBuffering = false))
    }

    @Test
    fun mobileLiveUsesDefaultLiveEdgeInsteadOfOldCandidateOffset() {
        val events = mutableListOf<String>()
        seekToPlaybackStart(true, 120_000L,
            seekToPosition = { events += "position:$it" },
            seekToDefaultPosition = { events += "live-edge" })
        assertEquals(listOf("live-edge"), events)
    }

    @Test
    fun nonMobileLivePlaybackPreservesExistingResumeOffset() {
        val events = mutableListOf<String>()
        seekToPlaybackStart(false, 120_000L,
            seekToPosition = { events += "position:$it" },
            seekToDefaultPosition = { events += "live-edge" })
        assertEquals(listOf("position:120000"), events)
    }

    // --- v0.14.26: pending auto-pick wait (Watch Now tap path) ---
    // Scripted replay of the owner's cold-title case: the loader
    // answers provisional empties (PlavioHD's still-filling marker)
    // for a while, then the unmarked set lands with 2 streams. The
    // old player resolver (30 s cap, fallback gated on full flow
    // completion) reported "No stream available" in this shape; the
    // wait must instead ride it out and pick.
    private val twoStreams = listOf(
        StreamItem(url = "https://cdn.example/a.mp4"),
        StreamItem(url = "https://cdn.example/b.mp4")
    )

    @Test
    fun pendingPickWaitsThroughProvisionalEmptiesForLateStreams() = runBlocking {
        var collects = 0
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = {
                collects++
                flow {
                    emit(StreamResult(emptyList(), emptyList(), filling = true))
                    delay(50)
                    emit(StreamResult(emptyList(), emptyList(), filling = true))
                    delay(50)
                    emit(StreamResult(twoStreams, emptyList()))
                }
            },
            pickWinner = { playable -> playable.first() },
            isDisposed = { false },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertEquals("https://cdn.example/a.mp4", pick?.stream?.url)
        assertEquals(2, pick?.streams?.size)
        assertEquals(1, collects)
    }

    @Test
    fun pendingPickOnlyConcludesEmptyAfterConfirmationPass() = runBlocking {
        var collects = 0
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = {
                collects++
                flowOf(StreamResult(emptyList(), emptyList()))
            },
            pickWinner = { null },
            isDisposed = { false },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertNull(pick)
        // Initial collect + exactly ONE confirmation collect — the
        // Detail loader's settle rule. Null before this point would
        // be a provisional verdict presented as final.
        assertEquals(2, collects)
    }

    @Test
    fun pendingPickConfirmationPassFindsLateStreams() = runBlocking {
        var collects = 0
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = {
                collects++
                if (collects == 1) flowOf(StreamResult(emptyList(), emptyList()))
                else flowOf(StreamResult(twoStreams, emptyList()))
            },
            pickWinner = { playable -> playable.first() },
            isDisposed = { false },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertEquals(2, collects)
        assertEquals("https://cdn.example/a.mp4", pick?.stream?.url)
    }

    @Test
    fun pendingPickFallsBackToFirstPlayableWhenNoWinnerAndFlowSettles() = runBlocking {
        // The prober likes nothing (every candidate unproven from
        // this seat) but the loader settled WITH streams: the first
        // playable is the pick, exactly as the Sources sheet plays
        // these rows on tap — never a "no streams" verdict.
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = { flowOf(StreamResult(twoStreams, emptyList())) },
            pickWinner = { null },
            isDisposed = { false },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertEquals("https://cdn.example/a.mp4", pick?.stream?.url)
    }

    @Test
    fun pendingPickStartsWithFirstWinnerWithoutWaitingForFullList() = runBlocking {
        // Owner's start rule: the first stream the pick returns
        // starts playback; the wait does not hold it for the fuller
        // list that is still arriving behind it.
        val first = listOf(StreamItem(url = "https://cdn.example/first.mp4"))
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = {
                flow {
                    emit(StreamResult(first, emptyList()))
                    delay(60_000) // the rest of the list is far behind
                }
            },
            pickWinner = { playable -> playable.first() },
            isDisposed = { false },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertEquals("https://cdn.example/first.mp4", pick?.stream?.url)
    }

    @Test
    fun pendingPickNeverCallsStreamsInHandNoStreams() = runBlocking {
        // A leg hangs past the pass budget (flow never completes)
        // while streams are already in hand and no winner is picked:
        // the set in hand is returned, not a "no streams" verdict,
        // and no confirmation pass is burned.
        var collects = 0
        val pick = awaitPendingAutoPick(
            initialStreams = twoStreams,
            initialSubtitles = emptyList(),
            openCollect = {
                collects++
                flow {
                    emit(StreamResult(twoStreams, emptyList()))
                    delay(60_000)
                }
            },
            pickWinner = { null },
            isDisposed = { false },
            passBudgetMs = 300, pollMs = 10, confirmationDelayMs = 10
        )
        assertEquals("https://cdn.example/a.mp4", pick?.stream?.url)
        assertEquals(1, collects)
    }

    @Test
    fun pendingPickAbortsWhenDisposed() = runBlocking {
        val pick = awaitPendingAutoPick(
            initialStreams = emptyList(),
            initialSubtitles = emptyList(),
            openCollect = {
                flow {
                    emit(StreamResult(emptyList(), emptyList(), filling = true))
                    delay(60_000)
                }
            },
            pickWinner = { null },
            isDisposed = { true },
            passBudgetMs = 5_000, pollMs = 10, confirmationDelayMs = 10
        )
        assertNull(pick)
    }

    @Test
    fun pausingOrBecomingReadyResetsTheActiveStartupWait() {
        assertEquals(1_000L, liveStartupWaitingSince(null, 1_000L, true, true))
        assertEquals(1_000L, liveStartupWaitingSince(1_000L, 2_000L, true, true))
        assertEquals(null, liveStartupWaitingSince(1_000L, 50_000L, false, true))
        assertEquals(51_000L, liveStartupWaitingSince(null, 51_000L, true, true))
        assertEquals(null, liveStartupWaitingSince(51_000L, 52_000L, true, false))
    }
}
