package com.pulsestream.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TmdbClientTest {
    @Test fun `empty cast is not incorrectly considered fully enriched`() {
        assertFalse(TmdbClient.isFullyEnrichedCast(emptyList()))
    }

    @Test fun `cast missing photo or id remains eligible for enrichment`() {
        assertFalse(TmdbClient.isFullyEnrichedCast(listOf(CastMember(id = 1, name = "A", photo = null))))
        assertFalse(TmdbClient.isFullyEnrichedCast(listOf(CastMember(id = 0, name = "A", photo = "photo"))))
        assertTrue(TmdbClient.isFullyEnrichedCast(listOf(CastMember(id = 1, name = "A", photo = "photo"))))
    }

    // ---- v0.14.32: TMDB Discover (Search "Popular" section) ----

    @Test fun `discover url asks the one language direct, popularity first, floored`() {
        val movie = TmdbClient.discoverUrl("movie", "hi", TmdbClient.DISCOVER_MOVIE_VOTE_FLOOR)
        assertTrue(movie.contains("/discover/movie?"))
        assertTrue(movie.contains("with_original_language=hi"))
        assertTrue(movie.contains("sort_by=popularity.desc"))
        assertTrue(movie.contains("vote_count.gte=50"))
        assertTrue(movie.contains("include_adult=false"))
        val tv = TmdbClient.discoverUrl("tv", "hi", TmdbClient.DISCOVER_TV_VOTE_FLOOR)
        assertTrue(tv.contains("/discover/tv?"))
        assertTrue(tv.contains("vote_count.gte=20"))
    }

    @Test fun `discover parse builds trending-shaped previews with popularity`() {
        val root = Json.parseToJsonElement(
            """
            {"results":[
              {"id":238,"title":"Dangal","poster_path":"/p.jpg","backdrop_path":"/b.jpg",
               "release_date":"2016-12-21","original_language":"hi","popularity":42.5},
              {"id":999,"name":"Ignored Fields Show","first_air_date":"2020-05-01",
               "original_language":"hi","popularity":9.0},
              {"title":"No id, skipped","popularity":99.0}
            ]}
            """.trimIndent()
        ).jsonObject
        val parsed = TmdbClient.parseDiscoverResults(root, "movie")
        assertEquals(2, parsed.size)
        val (first, pop) = parsed[0]
        assertEquals("tmdb:movie:238", first.id)
        assertEquals("movie", first.type)
        assertEquals("Dangal", first.name)
        assertEquals("https://image.tmdb.org/t/p/w342/p.jpg", first.poster)
        assertEquals("https://image.tmdb.org/t/p/w780/b.jpg", first.background)
        assertEquals("2016", first.releaseInfo)
        assertEquals("hi", first.originalLanguage)
        assertEquals(42.5, pop, 0.001)
        // A tv payload parsed as tv becomes a series with a tmdb:tv id.
        val tvParsed = TmdbClient.parseDiscoverResults(root, "tv")
        assertEquals("series", tvParsed[1].first.type)
        assertEquals("tmdb:tv:999", tvParsed[1].first.id)
        assertEquals("2020", tvParsed[1].first.releaseInfo)
    }

    @Test fun `discover parse of an empty payload is empty`() {
        val root = Json.parseToJsonElement("""{"page":1}""").jsonObject
        assertTrue(TmdbClient.parseDiscoverResults(root, "movie").isEmpty())
    }
}
