package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.14.39 (What's New): pins the show-once rules — an entry for
 * the running version, only after a real update (a higher stamped
 * code), and never on a fresh install (stamp 0 stays silent).
 */
class WhatsNewTest {

    @Test
    fun `the running test version has an entry with plain lines`() {
        val entry = WhatsNew.entryFor(223)
        assertNotNull(entry)
        assertEquals("0.14.39", entry!!.versionName)
        assertTrue(entry.lines.size in 2..6)
        assertTrue(entry.lines.all { it.isNotBlank() })
    }

    @Test
    fun `shows after an update to a version with an entry`() {
        assertTrue(WhatsNew.shouldShow(lastSeenCode = 222, currentCode = 223))
        assertTrue(WhatsNew.shouldShow(lastSeenCode = 219, currentCode = 223))
    }

    @Test
    fun `never shows on a fresh install`() {
        assertFalse(WhatsNew.shouldShow(lastSeenCode = 0, currentCode = 223))
    }

    @Test
    fun `never shows twice for the same version`() {
        assertFalse(WhatsNew.shouldShow(lastSeenCode = 223, currentCode = 223))
    }

    @Test
    fun `never shows for a version without an entry`() {
        assertFalse(WhatsNew.shouldShow(lastSeenCode = 222, currentCode = 224))
        assertFalse(WhatsNew.shouldShow(lastSeenCode = 100, currentCode = 150))
    }
}
