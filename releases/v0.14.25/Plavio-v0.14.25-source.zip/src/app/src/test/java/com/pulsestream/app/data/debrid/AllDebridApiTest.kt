package com.pulsestream.app.data.debrid

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * AllDebrid response parsing against recorded-shape fixtures from
 * the official API docs (docs.alldebrid.com). No live account — the
 * parsers are pure; the HTTP shell is not exercised here.
 */
class AllDebridApiTest {

    @Test
    fun upload_readyFlagIsTheCacheVerdict() {
        val ready = AllDebridApi.parseUploadEntry(
            JSONObject(
                """{"status":"success","data":{"magnets":[
                    {"magnet":"magnet:?xt=urn:btih:abc","hash":"abc","name":"Movie","size":100,"ready":true,"id":42}
                ]}}"""
            )
        )
        assertEquals(42L, ready.id)
        assertTrue(ready.ready)

        val notReady = AllDebridApi.parseUploadEntry(
            JSONObject(
                """{"status":"success","data":{"magnets":[
                    {"magnet":"magnet:?xt=urn:btih:abc","hash":"abc","name":"Movie","size":100,"ready":false,"id":43}
                ]}}"""
            )
        )
        assertFalse(notReady.ready)
    }

    @Test
    fun upload_entryErrorThrows() {
        try {
            AllDebridApi.parseUploadEntry(
                JSONObject(
                    """{"status":"success","data":{"magnets":[
                        {"error":{"code":"MAGNET_MUST_BE_PREMIUM","message":"You must be premium"}}
                    ]}}"""
                )
            )
            fail("expected AllDebridException")
        } catch (e: AllDebridException) {
            assertFalse(e.isAuthError)
        }
    }

    @Test
    fun authErrorCodesDetected() {
        assertTrue(AllDebridApi.isAuthErrorCode("AUTH_BAD_APIKEY"))
        assertTrue(AllDebridApi.isAuthErrorCode("AUTH_MISSING_APIKEY"))
        assertFalse(AllDebridApi.isAuthErrorCode("MAGNET_INVALID_URI"))

        try {
            AllDebridApi.parseUploadEntry(
                JSONObject("""{"status":"error","error":{"code":"AUTH_BAD_APIKEY","message":"Bad key"}}""")
            )
            fail("expected AllDebridException")
        } catch (e: AllDebridException) {
            assertTrue(e.isAuthError)
        }
    }

    @Test
    fun statusCode_readyIs4() {
        val code = AllDebridApi.parseStatusCode(
            JSONObject(
                """{"status":"success","data":{"magnets":[
                    {"id":42,"filename":"Movie","size":100,"status":"Ready","statusCode":4}
                ]}}"""
            ),
            42L
        )
        assertEquals(4, code)
        assertEquals(AllDebridApi.STATUS_READY, code)
    }

    @Test
    fun filesTree_flattensInOrder() {
        val files = AllDebridApi.parseFiles(
            JSONObject(
                """{"status":"success","data":{"magnets":[{"id":"42","files":[
                    {"n":"Season 1","e":[
                        {"n":"E01.mkv","s":100,"l":"https://dl.example/1"},
                        {"n":"E02.mkv","s":200,"l":"https://dl.example/2"}
                    ]},
                    {"n":"readme.txt","s":5,"l":"https://dl.example/3"}
                ]}]}}"""
            ),
            42L
        )
        assertEquals(3, files.size)
        assertEquals("Season 1/E01.mkv", files[0].name)
        assertEquals(100L, files[0].size)
        assertEquals(0, files[0].sourceIndex)
        assertEquals("https://dl.example/1", files[0].link)
        assertEquals("readme.txt", files[2].name)
        assertEquals(2, files[2].sourceIndex)
    }
}
