# Build and API references

The Gradle 8.10.2 binary distribution checksum was retrieved from the official endpoint, https://services.gradle.org/distributions/gradle-8.10.2-bin.zip.sha256 : `31c55713e40233a8303827ceb42ca48a47267a0ad4bab9177123121e71524c26`. It is pinned in the wrapper properties.

The official Real-Debrid API documentation, https://api.real-debrid.com/ , documents `GET /torrents/info/{id}` file entries with `id`, `path`, `bytes` and `selected` (0 or 1), plus a `links` array. `POST /torrents/selectFiles/{id}` takes selected file IDs from torrent info. The app now preserves selected flags and maps a requested file to the selected-file link position instead of always using the first link. Ambiguous count mappings fail closed; live season-pack testing remains necessary.

Native alignment references, inspected by the native review task, are recorded in `native-build-provenance.md`. Existing binaries were preserved, not falsely relabeled as compatible.
