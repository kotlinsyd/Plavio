# Native FFmpeg JNI inventory and provenance status

**Status: original JNI binaries are preserved; no rebuild or ELF-header modification was performed.** The current artifacts fail the 16 KiB ELF load-segment alignment check. Their source revision, FFmpeg revision, build configuration, NDK, enabled decoder set, and redistribution-license composition cannot be established from this checkout. Do not describe them as 16 KiB compatible or reproducibly built.

## Checked-in artifacts (as inspected 2026-10-19)

| Android ABI | Path | ELF identity | PT_LOAD `p_align` values | SHA-256 | GNU build ID |
|---|---|---|---|---|---|
| `arm64-v8a` | `app/src/main/jniLibs/arm64-v8a/libffmpegJNI.so` | ELF64 / AArch64 | `0x1000`, `0x1000`, `0x1000` (all 4 KiB) | `aaa9d7f1f0f8b74cdf2b98e2bb69c3e6e95bb99758178681ba445907481a1d80` | `4dc30bb7a5823a1206a2e4baf8d0cfc0fdb97a89` |
| `armeabi-v7a` | `app/src/main/jniLibs/armeabi-v7a/libffmpegJNI.so` | ELF32 / ARM | `0x1000`, `0x1000`, `0x1000` (all 4 KiB) | `59ece2012d8617554db003a102d03ef4b9bd3c5ade6d592b41036194eca373c1` | `44d8efa5331a396f6ac52a85f04a97bd6220c829` |

The app pins AndroidX Media3 `1.4.1` in `gradle/libs.versions.toml`, and has matching FFmpeg Java sources under `app/src/main/java/androidx/media3/decoder/ffmpeg/`. That establishes the app-side version, **not** the origin or exact correspondence of either binary.

## Codec-path and static decoder evidence

`PlayerScreen` constructs `PlavioAudioRenderersFactory`, not the older `PlavioRenderersFactory` class. The active factory enables `EXTENSION_RENDERER_MODE_PREFER` and installs `NoHardwareDolbySelector`; for E-AC-3/E-AC-3 JOC, AC-3, DTS, DTS-HD, and TrueHD MIME types that selector returns an empty MediaCodec decoder list. This intentionally excludes MediaCodec for those formats and prefers the Media3 FFmpeg extension; other audio MIME types continue through `MediaCodecSelector.DEFAULT`. The exact Media3 `FfmpegLibrary` Java source loads the native library named `ffmpegJNI`, and maps E-AC-3/JOC to FFmpeg codec name `eac3`, AC-3 to `ac3`, DTS/DTS-HD to `dca`, and TrueHD to `truehd`. Both current ELF files expose the expected JNI method entry points. The inactive older `PlavioRenderersFactory` explicitly prepends a second FFmpeg renderer and should not be used as evidence of the active path. Source configuration expresses a software preference, but does not prove a track actually selected FFmpeg or that a particular device played it.

The current ARM64 and ARMv7 libraries both export FFmpeg decoder registration symbols `ff_ac3_decoder`, `ff_eac3_decoder`, `ff_dca_decoder`, `ff_truehd_decoder`, and `ff_mlp_decoder`. This is positive **static compiled-code evidence** for those decoder implementations in both ELF files and is a reason to preserve these exact artifacts pending a codec-approved replacement. It is not a complete codec inventory and does not demonstrate successful initialization, E-AC-3/JOC stream decoding, multichannel output, PCM quality, or OnePlus 13R behavior. Symbols/strings cannot substitute for known-good media playback tests.

The `FfmpegAudioRenderer` decodes to PCM and delegates output to Media3's audio sink; source contains output-format handling for PCM16/float and input channel-count/sample-rate. This does not establish passthrough/bitstream output, Atmos rendering, or device sink behavior. We found no explicit app audio-channel cap or channel-remapping setting in the active factory path. The selector comments mention OnePlus 13R as motivation, but no playback, listening, or OnePlus 13R test is claimed here.

Run `python3 scripts/native-codec-inventory.py` from the project root for machine-readable hashes, ABI identity, build IDs, `PT_LOAD` alignment/congruence, and exported `ff_*_decoder` symbols. The tool reads the bundled artifacts but does not modify them. Its static symbol evidence must not be interpreted as runtime codec support or provenance.

## Rebuild feasibility and provenance gap

The Android SDK is available at `/home/ubuntu/android-sdk`; no Android NDK/toolchain was installed during this investigation. Host GNU `readelf` is available. Internet access works, but acquiring and setting up a full Android NDK plus reconstructing and validating the native configuration was not feasible within this bounded investigation. More importantly, this project has no recorded FFmpeg source commit, codec configuration, build command, or source-to-binary checksum trail. Replacing the libraries with a guessed decoder set could silently remove existing codec support, so no replacement was made.

The upstream [Media3 1.4.1 FFmpeg decoder README](https://github.com/androidx/media/blob/1.4.1/libraries/decoder_ffmpeg/README.md) says the extension needs separately built FFmpeg binaries, notes testing with NDK r26b (r23c when `ANDROID_ABI` is below 21), recommends FFmpeg 6.0, and describes building configured decoders. It also warns that FFmpeg is separately licensed from the Apache-2.0 Media3 code. These are upstream guidance, **not** evidence of how these existing binaries were produced. A responsible replacement requires the owner to establish the currently supported decoder/codec set and licensing/configuration requirements, then pin exact Media3 and FFmpeg source commits, NDK revision, build flags, enabled decoders, license notices, and output checksums. Build with 16 KiB linker alignment (or a supported NDK default), compare required codec support, run the verifier below, and perform a 16 KiB page-size device/emulator load/playback test before replacing either ABI.

### Rebuild gate and validation plan

Do not start a replacement build until the owner supplies/reviews: (1) the exact Media3 source tag/commit corresponding to the copied Java decoder classes and its native JNI source; (2) the exact FFmpeg release/commit plus every local patch/submodule; (3) the old per-ABI build scripts/configure arguments, enabled/disabled decoder list, external libraries, and license configuration (or an explicit owner-approved replacement support list); (4) NDK revision, CMake/make/tool versions, environment variables, compiler/linker flags, and ABI/API-level settings; (5) original source-to-binary provenance and known-good E-AC-3/Dolby reference streams. Current evidence cannot recover these inputs from the `.so` files. In particular, do not infer FFmpeg version/configure flags from symbol or strings scans.

When those inputs are available, use this controlled sequence: check out the pinned Media3 and FFmpeg revisions and verify their commit hashes; apply only reviewed patches; use the upstream Media3 extension build procedure with the owner-approved decoder list and pinned NDK/toolchain (no hand-guessed configure flags); build both `arm64-v8a` and `armeabi-v7a` with the required 16 KiB linker alignment; record source/config/toolchain hashes and output checksums; compare per-ABI decoder registration symbols against the accepted support baseline; run `scripts/native-codec-inventory.py` and `scripts/check-native-alignment.py`; then validate APK ZIP alignment separately. Do not replace either checked-in `.so` until the build is reproducible, required audio support is retained, license notices are reviewed, and runtime tests pass.

Minimum playback matrix before rollout: (a) the actual target OnePlus 13R and its recorded Android/OxygenOS build, exercising known-good E-AC-3 DD+ 5.1 and 7.1 where available, E-AC-3 JOC/Atmos-labelled input, AC-3, DTS/DTS-HD, and TrueHD files; (b) a 16 KiB page-size ARM64 Android emulator/device to verify loading and playback; and (c) an ARMv7 device only if that ABI remains a product requirement. For each sample record input hash/codec/profile/channels/sample rate, selected renderer/decoder and logs, playback start/continuity, output PCM channel count/rate, audible channel mapping and sync, seek/release behavior, and failure fallback. Compare results against current-library baselines on the same phone and output route. This is a proposed future matrix, not completed testing; JOC/Atmos or TrueHD passthrough must not be claimed based only on decoder availability or PCM output.

Android's [16 KB page-size guidance](https://developer.android.com/guide/practices/page-sizes) requires shared-library `PT_LOAD` segments to have at least `2**14` alignment; NDK r28+ aligns by default, while r27 and older require linker options `-Wl,-z,max-page-size=16384` and `-Wl,-z,common-page-size=16384`. ELF alignment alone is not runtime validation and APK ZIP alignment is a separate packaging check.

## Verification

Run from the project root:

```sh
python3 scripts/check-native-alignment.py
```

It checks the required ARM64 and ARMv7 ABI directories and JNI libraries, ELF machine/class, every discovered shared object's `PT_LOAD` alignment, and segment offset/address congruence. It intentionally fails against the present binaries. It does not check APK ZIP alignment, dependencies outside `jniLibs`, codec functionality, licenses, or runtime behavior. Do not remove an ABI or codec library to make verification pass without an explicit, reviewed support decision.
