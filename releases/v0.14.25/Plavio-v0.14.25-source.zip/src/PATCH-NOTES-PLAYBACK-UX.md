# Plavio playback and UX patch notes

This patch is based on the supplied 0.11.9 source ZIP. It intentionally preserves the existing feature set and does not change the package ID, signing configuration, release manifest, or app version.

## Changes

- Live playback now has a separate bounded recovery watchdog for streams that play successfully and later remain buffering for 20 seconds while playback is requested. It retries at most twice per channel session, then presents a recovery error instead of buffering indefinitely. Pausing, VOD playback, TV playback, and startup handling remain separate.
- Source diagnostics now retain `startup_timeout` and `rebuffer_timeout` as distinct outcomes instead of collapsing them into generic `failed` entries. Diagnostics remain volatile and do not store stream URLs, titles, tokens, or account identifiers.
- Live player controls no longer display a misleading VOD seekbar/time chips or 10-second rewind/forward buttons. The live panel shows channel title, LIVE status, and connecting/buffering/on-air feedback. VOD seek controls remain unchanged.
- Subtitle downloads now use the stream's validated request headers when appropriate, while the existing origin-scoping policy strips non-transport headers on cross-origin requests and redirects. The cache identity includes a digest of the request-header set to avoid reusing a subtitle cached under a different session.
- Subtitle content detection now accepts WebVTT and SRT syntax and rejects arbitrary text, HTML, or JSON error bodies instead of misclassifying them as SubRip. The subtitle cache version was bumped so older unvalidated cache entries are discarded.
- Shared Liquid Glass surfaces now have translucent gradient fills and slightly stronger edge lighting/glow while keeping the implementation gradient-based to avoid a blur pass on every catalog card.
- Added unit tests for subtitle-format detection and the live rebuffer timeout policy.

## Validation status

- Source-level checks were reviewed after the changes.
- `scripts/scan-source-secrets.py` passed.
- `scripts/verify-public-auth-settings.py` failed on the supplied source tree; this was not caused by this patch and needs separate investigation.
- `scripts/check-native-alignment.py` fails because the supplied bundled FFmpeg JNI libraries have 4 KiB PT_LOAD alignment, not the required 16 KiB alignment. This is pre-existing native-binary packaging debt and was not changed here.
- A fresh Gradle test/build could not be run in this environment because the Gradle 8.10.2 distribution was not cached and network access to `services.gradle.org` is unavailable. The supplied ZIP's old build report is not evidence that these new changes compile. Please run the unit tests/build in Android Studio or a connected build environment before release.

## Known limitation

This source patch cannot guarantee a particular live stream will play: provider availability, URL expiry, required stream-specific headers, network access, and device codec support still affect playback. The new recovery behaviour makes failures bounded and more understandable; real-device playback tests remain required.
