# Account login: what is known

## Publishing does not change the installed app

Uploading the project to GitLab or GitHub cannot repair a rejected API configuration in an APK already on a phone. A corrected client configuration needs a new build; a backend configuration problem needs an authorized backend correction. Neither happens merely by publishing source.

## Offline checks

The exact delivered 0.11.5 APK and source have matching cloud endpoint and public client configuration. The endpoint is non-placeholder HTTPS. The embedded public JWT declares the anon role, its project reference matches the configured host, and its declared expiry is not past as of this task. No configuration value is reproduced here.

These checks do not verify the JWT signature, current gateway acceptance, legacy-key enablement, or whether this is the intended project. The APK contains no literal “wrong API” or “Invalid API key” message, but the previous client could display provider error text at runtime.

No live account request or account change was made. The reported symptom is not sufficient to determine which configuration is wrong. If the server explicitly rejects the API key, that is not an account-password failure; the maintainer must verify the intended project's currently accepted public client configuration. This candidate does not change the endpoint or public key and does not claim successful login.

## Changes in 0.11.6

`CloudManager.kt` now checks local configuration before account requests. `CloudAuthErrors.kt` translates explicit API-configuration rejection, missing auth routes, ordinary login failures, email verification, rate limits and temporary server failures into safe messages, without displaying raw provider details. The helper uses the existing platform-independent JSON library so its behavior is locally testable.

`CloudAuthErrorsTest.kt` covers these mappings, malformed/structured errors and safe fallbacks. Final executed test counts are in `docs/validation-summary.txt`; current source and build limits are in `REPAIR-0.11.6.md`.

## Evidence needed if login still fails

The exact on-screen error or a screenshot with email/personal data hidden is sufficient for the next diagnosis. Do not send passwords, API-key values, session tokens or account credentials. The maintainer can verify public client configuration separately through their authorized deployment process.
