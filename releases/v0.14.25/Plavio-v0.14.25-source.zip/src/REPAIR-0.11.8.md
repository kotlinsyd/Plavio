# Plavio 0.11.8: mobile cloud configuration repair

## The API rejection is fixed at the public-settings gate

The exact supplied `Plavio-0.11.7-mobile-source.zip` used a public anon key that did not match the active legacy anon key for its Supabase project. This mobile build replaces only that key literal in `CloudManager.kt`. The endpoint, auth/session code, backend, and access policies are unchanged. The version is now **0.11.8 (89)** so it can update 0.11.7.

The active public legacy anon key was retrieved with the read-only Supabase `get_publishable_keys` tool after checking the target project was healthy. Its role and project claims were checked before insertion. No saved credentials or service-role key were used.

A public `GET /auth/v1/settings` using the corrected configuration returned **HTTP 200** with valid public settings JSON. The verifier disallows redirects and records no keys, response body, account information or request headers. Sanitized evidence is in `docs/public-auth-settings-0.11.8.json`. This proves gateway acceptance of the public client configuration, **not successful account sign-in**. No login or user-data request was attempted.

## Configuration regression protection

`CloudPublicConfigurationTest` checks the compiled app's intended HTTPS endpoint, the exact accepted configuration using a SHA-256 pin, and the legacy key's public `anon` role, project, issuer and validity timestamps. Assertions do not echo key values. Merely matching JWT claims is insufficient to prove gateway acceptance; `scripts/verify-public-auth-settings.py` provides the separate explicit read-only network check.

Run the public check only when desired:

```sh
python3 scripts/verify-public-auth-settings.py --write-evidence
```

It never signs in, queries account data, modifies the backend, or prints the key/body. Rotation requires retrieving the then-active public legacy anon key, verifying HTTP 200, and deliberately updating the regression digest; never substitute a service-role key.

## Willow Live: what “skip” means

All 0.11.7 Live/fallback production code is preserved byte-for-byte. For Live, automatic fallback is driven by supported terminal player errors, not by buffering alone. Eight automatic advances allow a seventh candidate to be reached after six failures; this does not guarantee that any particular production Willow candidate works. Automatic fallback skips already-tried URL-plus-header identities and does not cycle them; manual next-source navigation intentionally wraps. Successful playback resets the consecutive failure counter, not the tried-identity guard. Late alternatives can be awaited for up to 20 seconds.

The broader Live error policy remains excluded from movies/series, whose existing three-advance policy is unchanged. A stream that buffers indefinitely without a qualifying error can still require manual intervention. No arbitrary buffering timer or new playback behavior was added in this repair. Added local regression coverage is summarized in `docs/validation-summary.txt`.

The new focused policy regression verifies that the eight-advance budget is closed at the cap and becomes eligible again when the caller supplies a reset consecutive-failure count. Existing tests retain coverage for reaching source 7, non-cycling, header variants and Live-only policy scope. This does not exercise the player listener's actual reset, buffering-only behavior or manual-next wrapping; those require player/navigation or device testing.

## Preserved behavior and remaining checks

The 0.11.7 cached Live loading, source/header identity, lifecycle recovery guards, MIME fallback, safe probe redirects, download range/storage safeguards, renderer factories and original ARM FFmpeg JNI binaries remain unchanged. No production media stream was played or probed for this repair. Prior repair documents and their 401 observations are historical, superseded by this repair and its public-settings evidence.

The APK is a **debug candidate**, not a production-signed release. Signature comparison with the delivered 0.11.7 APK is in the validation summary. Do not uninstall an important installation merely to bypass a signature conflict. The inherited native-library 16 KiB alignment limitation remains; ordinary APK ZIP alignment is a separate check.

On a phone, install as an update if the signer matches, then test account sign-in yourself and recheck Live/Willow playback. No connected phone or emulator was used here, so real playback, credential acceptance and full device lifecycle behavior are not claimed verified.

## Verification and scope

Executed test counts, lint results, signature, APK metadata, preserved-source checks and build tasks are recorded in `docs/validation-summary.txt`; final JUnit XML reports are under `docs/junit/`. The public request evidence and build log are sanitized and included. The matching source ZIP excludes caches, generated APKs, machine-local SDK paths and private signing material.

No TV build/test, repository push, deployment, backend/RLS change, account login, private-data query or saved credential use occurred.
