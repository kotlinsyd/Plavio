# Plavio 0.11.7: mobile Live and playback checks

This debug candidate comes from the exact supplied 0.11.6 mobile source. It does not change or deploy the addon/backend, build TV, or claim successful cloud login. Detailed executed counts and signer verification are in `docs/validation-summary.txt`.

## What the one-time speed check found

At **19 October 2026, 12:25:52 Pakistan time (07:25:52 UTC)**, the public production endpoint returned:

| Request | HTTP | Complete response time | Result |
|---|---:|---:|---|
| `GET /manifest.json` | 200 | 95 ms | 4 catalogs |
| `GET /stream/tv/plaviohdtv-nuvio_sport_spk_admin-willow-cricket.json` | 200 | 4,287 ms | 16 HTTP(S) candidates; 7 carried header objects |

These were exactly one request each, without retries, configured addon credentials or subsequent media requests. No stream URL/header value was saved. This single sandbox sample shows a fast manifest but a several-second channel resolution; it cannot measure phone-to-provider speed, first video frame, sustained playback, concurrency under load, or prove an outage. Sanitized evidence is in `docs/public-latency-0.11.7.json`.

## Why Live can load slowly

The archived mobile app's cold Live load waits for all requested addon catalogs before returning. Its persisted Room rows were available through `loadTvRowsCached()` but the Live UI did not use them. Catalog requests are deliberately concurrency-limited, and slow requests can hold the final result until their timeout. M3U loading followed addon loading sequentially. `init` and `ON_RESUME` could also start overlapping refresh jobs.

The candidate now shows enabled addons' persisted Live rows while refreshing, coalesces overlapping loads, fetches addon/M3U rows concurrently, and keeps saved rows with a clear warning if refresh throws. A successful empty refresh clears old rows. This improves repeat/cold-cache display, not the production stream resolver's own response time. A first installation with no saved rows must still wait for network data. Catalog results remain batch-based rather than fully incremental.

## Why Willow could need repeated skips

The mobile Live selector accepts a candidate when its URL parses as HTTP(S), not when playback is proven. It chooses the first available emission's first stream. Addons resolve concurrently, so the earliest responder may beat the channel's preferred addon; the player later refills its source list. Initial selection does not use Plavio Pick's probe. The original automatic fallback handled only selected errors and allowed three advances per uninterrupted failure run. A failed MIME recovery stopped instead of continuing to another source. URL-only merging could also discard a same-URL candidate with different required headers.

Those are verified app behaviors, not proof that any specific one of the actual first six Willow entries is broken. We did not play or probe the production candidates and cannot say whether those entries fail because of HTTP status, provider headers, tokens, transport, format, codec or device behavior.

The mobile Live candidate now:

- Preserves URL-plus-header variants and allows switching between them.
- Automatically advances to untried later candidates for more Media3 network/IO errors and the existing parser/decoder failures, including failed MIME recovery.
- Allows **eight automatic advances**, enough to reach a seventh candidate after six failures. This cap applies to a consecutive failure run; successful playback resets the counter, while the tried-candidate set still prevents automatic cycling.
- Waits up to 20 seconds for late alternatives instead of immediately abandoning a failed first source when none are available yet.
- Guards player callbacks and delayed recovery against replacement, manual choice, channel changes and disposal.
- Records only fixed fallback outcome labels with opaque source IDs; no URLs, titles, header values or exception text enter the source diagnostics log.

Automatic candidate selection remains bounded and does not prove a source usable before Media3 attempts it. Manual next-source navigation still wraps intentionally. A stream that buffers indefinitely without emitting a relevant error can still require manual intervention. Background source enumeration can still repeat the original resolution request; this candidate does not introduce a shared persistent stream-response cache.

## Nuvio-derived path and headers

The mobile app uses Media3/ExoPlayer and its Nuvio-derived UA/MIME conventions. The trace confirmed resource type, stream URL, per-candidate headers and MIME hints reach the native player. The 0.11.6 archive already repairs well-formed IPTV `url|Header=value` suffixes, case-insensitive header precedence, encoded playlist extensions and bounded MIME probing when Range is rejected.

A full independent Nuvio client source tree was not available locally. The local adapter reference can spend time checking candidates and retains uncertain results; it is not evidence of a current production defect. No backend code was modified or executed for this audit.

The separate **Plavio Pick** probe had disabled every redirect when sensitive headers were present, whereas the actual player supported safe redirects. Its transport now matches playback: same-origin headers remain, cross-origin sensitive/custom credentials are stripped, HTTPS downgrade redirects remain blocked. This can avoid false negatives in Plavio Pick but does not itself fix initial Live selection, which does not use that probe. No broad header-forwarding exception was introduced.

## Large files: what is and is not established

No arbitrary 2 GB/4 GB playback cap or integer conversion truncating playback length was found in the inspected mobile path. The download range parser uses `Long`, validates range starts/ends/totals, and treats an ignored resume Range/HTTP 200 as restart-from-zero. A separate download storage-reserve addition could overflow for extreme declared lengths; it now uses subtraction-based overflow-safe checks. That is a hardening fix, not a demonstrated explanation for real large-movie playback failure.

Actual failed files' codec/profile, bitrate, range responses, signed-link expiry and device decoder behavior were not supplied or tested. A large file's size alone does not diagnose which of those applies. **Large-file playback is not claimed fixed.** The renderer factories and both FFmpeg JNI libraries are unchanged, preserving the existing audio/decoding path. The inherited 4 KiB/16 KiB native alignment limitation remains.

## Could movies/series skip too quickly?

The owner's suggestion is an unconfirmed hypothesis. The inspected movie/series code does not advance merely because the stream is buffering or because a short UI timer expires. It advances immediately **after Media3 emits a terminal `onPlayerError`** for selected HTTP/file/parser/decoder errors, up to three advances per consecutive failure run. The playback HTTP transport has 15-second connect/read timeouts; those are network operation limits, not a fixed 15-second time-to-first-frame allowance. No custom load-error retry policy was found in this source path; Media3's normal load handling precedes the terminal callback.

It is possible for a recoverable-looking real-world response to reach that terminal path and make the immediate next-source choice feel premature, but no reported error code or timestamp proves that here. A buffering-only, no-error stream should not be auto-skipped by this handler. The candidate deliberately does not add arbitrary delays or broaden movie/series failover without evidence. Its new Live error-policy expansion is explicitly excluded from non-Live requests; the stale-player callback guard also prevents a retired player's error from causing an unrelated new-source switch. To test the hypothesis, note elapsed time before the source changes, whether an error/attempt indicator appears, the error code, and whether manually retrying the same source succeeds.

## Cloud login needs maintainer configuration work

The supplied public auth-settings check returned HTTP 401 with the APK's public key and no account credentials. That confirms app/API configuration rejection before password validation. Local JWT claims match the endpoint and are not expired, but do not verify signature or gateway acceptance. Disabled legacy keys, superseded signing configuration or an invalid embedded signature remain alternatives, not established facts.

Privately verify the intended project's accepted public client configuration in Supabase **Settings > API Keys**, preferably an existing active publishable key; validate only the public auth-settings endpoint, then rebuild. Do not embed a service-role/secret key, relax RLS, reset the password or publish source as a workaround. Endpoint and public key remain unchanged here. See `CLOUD-CONFIGURATION-0.11.7.md` and [Supabase's official key guidance](https://supabase.com/docs/guides/getting-started/api-keys).

## What the owner should test next

1. Install the signed mobile debug APK as an update only if its signer matches the installed app. Final certificate comparison is in the validation summary. Another computer's source rebuild normally has a different debug signer. Do not uninstall an important installation to bypass a conflict; back up first or use a spare device. No production signing key is included.
2. Open Live after process restart and on repeat visits; verify saved channels appear during refresh. With several addons installed, check that a slow one no longer hides saved rows. Check any M3U playlists still load.
3. Open the same Willow Cricket channel. Note the candidate count, automatic attempt indicator, elapsed time until first frame, and the first visible playback **error code** if it stops. Verify source 7 can be reached, same-URL header variants can be selected, and changing channel/back during recovery never starts ghost playback.
4. Recheck one previously failing large file and one known-working smaller file on the same phone. Supply only title/version or a non-secret release label, reported size, resolution/video codec, phone model, Android version, player error code, and whether failure is at start or seek. Do not send signed stream URLs, configured addon URLs, cookies, tokens, passwords or header values. Then a narrowly scoped fixture can target the actual failure class.
5. After the maintainer separately corrects the public cloud configuration and rebuilds, the owner should perform the sign-in test. This candidate is not a cloud-login fix.

## Verification boundaries

Final mobile unit-test, lint, APK signature, ZIP alignment, native/source equality and package results are in `docs/validation-summary.txt` and `docs/verified-build.log`. Local fixtures cover Live policy/source identity, cached loading/coalescing, probe redirect/header behavior, range/storage boundaries and inherited playback handoff. They do not simulate every Compose player lifecycle race or decode a real high-bitrate file. No connected phone/emulator was available. No TV build/test, account/private-data access, saved credential use, load test, media-provider request, repo push, production mutation or deployment occurred.
