# Plavio 0.11.9 — lighter Liquid Glass, TorBox and Live repair

## What changed

- **Liquid Glass is lighter.** The default canvas is now smoky slate (`#202630`) rather than near-black, with softer neutral panels (`#303A47`), lifted glass gradients, brighter muted text and clearer rims. Plavio's cyan/magenta accents are preserved. Primary and secondary text are tested at a minimum 4.5:1 contrast on the base canvas, panels and glass fills. If an existing installation still looks black, turn **Settings → Appearance → AMOLED black** off; that explicit battery-saving option is retained, not silently overwritten.
- **TorBox key entry is enabled.** Open **Settings → Integrations → TorBox**, paste your own key and tap **Save**. The field remains masked by default. Reopen it to edit; clear the field and save to remove the key. Cancel discards edits. “API key saved” means local storage, not successful TorBox authentication. Storage failures leave the dialog open with a safe error instead of exposing an exception or claiming success. Real-Debrid's existing disabled state is unchanged.
- **Playback source requests no longer wait behind background catalog requests.** Source discovery now has its own four-request limit. The selected Live channel's addon gets the first request slot, and each network timeout starts after acquiring a slot. Results still arrive progressively and preserve URL/header variants.
- **A mobile Live source that never starts no longer buffers forever.** After 30 seconds of startup waiting, the player invokes its existing next-untried-source path, with the existing eight-advance limit. This applies only before the first successful playback, not to healthy playback, movies, episodes or intentionally paused playback. It does not make dead candidates work or guarantee that Willow's seventh candidate is available.
- **Live starts and source switches use that stream's default live position.** They no longer seek to zero or reuse a different Live candidate's playback offset. Movies and episode resume behavior are preserved. Mobile Live ignores stored resume positions.
- **The Live channel resolver no longer cancels cached-debrid resolution at 25 seconds.** It has a 65-second overall deadline, allowing more time for addon retrieval and cached-link resolution. Direct playable results still start immediately; this is not a fixed wait. Large queues or unavailable providers can still exhaust the deadline.
- **Provider exception details are hidden from the Live error message.** A signed/configured source URL must not be shown through an exception string.

## What is preserved

The corrected 0.11.8 Supabase public configuration, encrypted settings and portable credential-envelope implementation are unchanged. The TorBox cached-only API/file-selection implementation is unchanged; this repair does not add torrent downloads. Existing TorBox cached-stream and encrypted-sync regression suites are included in the full mobile test run.

Both renderer factories, the FFmpeg Java decoder classes and all packaged native FFmpeg binaries are unchanged. No codecs, audio support, original app features or source files were removed. Existing header sanitization, byte-range handling, cross-origin credential restrictions and bounded playback buffering remain in place.

## Local verification

The package includes current JUnit XML in `docs/junit/`, the mobile build log, Android lint output, and `docs/validation-0.11.9.json` with executed counts and checks. New tests cover TorBox editing/save/cancel/clear/masking/storage failure, encrypted persistence/recreation, foreground discovery under saturated catalog slots, preferred-addon dispatch, Live startup timeout exclusions, default Live position and preserved on-demand resume offsets.

The persistence test uses real AES-GCM and local preferences with a test-only in-memory key-retrieval boundary because Robolectric is not a hardware Android Keystore. It does not certify physical-device Keystore behavior.

The delivered APK is **mobile debug 0.11.9 (90)**. Its signing certificate is checked against the delivered 0.11.8 debug APK, and its source ZIP is checked byte-for-byte against the packaged build tree. This is not a production-signed release. The inherited native-library 16 KiB alignment limitation remains; ordinary APK ZIP alignment is a separate check.

## Still needs a phone or working provider

- Install the APK as an update to the prior debug build. Do not uninstall a valuable installation to bypass a signature mismatch.
- Check the lighter theme on the phone, including Home, Settings, dialogs and the bottom dock. Color/contrast assertions do not replace a physical-screen visual check over all artwork and overlays.
- Enter your own TorBox key inside the app; close/reopen settings and then restart the app to check persistence. Try a legitimately available cached movie and a specific episode. Invalid/uncached responses must remain errors rather than fake playable links.
- Test the reported addon-backed channels, Willow's failing candidates, initial buffering fallback, manual source switching, channel zapping, pause/resume, app background/foreground and recovery after a source ends. The watchdog covers initial startup, not every later rebuffer event. Its helper policy is unit-tested; an actual Media3/network/device lifecycle still needs testing.
- On the OnePlus phone, check EAC3/FFmpeg audio, subtitles and a large high-bitrate file, including seeking and extended playback. No new large-file performance defect was confirmed locally, so buffering/decoder code was not speculatively rewritten. Smoothness and provider throughput cannot be certified by unit tests.
- Check sign-in and encrypted account sync yourself if used. The corrected cloud configuration is preserved; no account was accessed here.

No real TorBox key, account login, provider/media playback request, backend change, TV build/test, repository push, deployment or publication was performed.

## Nuvio comparison

Reference only; no wholesale upstream code, credentials or private assets were imported. The reviewed Mobile revision was [324afcff](https://github.com/NuvioMedia/NuvioMobile/tree/324afcffb962f1f7df45c5fa951131acec5a15a7). Mobile is Kotlin Multiplatform and is not a drop-in replacement for Plavio's Android Live path.

Useful Live-specific references came from the separate TV repository at [c613e931](https://github.com/NuvioMedia/NuvioTV/tree/c613e93111353283b42c12d516788c19df504c3c): [progressive addon stream fan-out](https://github.com/NuvioMedia/NuvioTV/blob/c613e93111353283b42c12d516788c19df504c3c/app/src/main/java/com/nuvio/tv/data/repository/StreamRepositoryImpl.kt#L196-L235), [Live classification](https://github.com/NuvioMedia/NuvioTV/blob/c613e93111353283b42c12d516788c19df504c3c/app/src/main/java/com/nuvio/tv/ui/screens/player/LivePlaybackUiPolicy.kt#L3-L28), [playback headers and range handling](https://github.com/NuvioMedia/NuvioTV/blob/c613e93111353283b42c12d516788c19df504c3c/app/src/main/java/com/nuvio/tv/ui/screens/player/PlayerPlaybackNetworking.kt#L75-L148), [bounded 64 KiB extractor read buffering](https://github.com/NuvioMedia/NuvioTV/blob/c613e93111353283b42c12d516788c19df504c3c/app/src/main/java/com/nuvio/tv/ui/screens/player/BufferedReadDataSource.kt#L10-L17) and [cached-only TorBox resolution](https://github.com/NuvioMedia/NuvioTV/blob/c613e93111353283b42c12d516788c19df504c3c/app/src/main/java/com/nuvio/tv/core/debrid/TorboxDirectDebridResolver.kt#L39-L85). These informed the review, not a TV build. Plavio already blocks addon-supplied Range defaults and has bounded streaming; those existing safeguards were retained.
