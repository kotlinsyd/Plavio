/* No analytics, cookies, remote scripts, or stored identifiers. */
(() => {
  'use strict';
  const status = document.getElementById('copy-status');
  let statusTimeout;
  function notify(message) {
    if (!status) return;
    status.textContent = message;
    status.classList.add('visible');
    clearTimeout(statusTimeout);
    statusTimeout = setTimeout(() => status.classList.remove('visible'), 5500);
  }
  document.querySelectorAll('[data-copy]').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const value = button.dataset.copy;
      const original = button.innerHTML;
      let copied = false;
      try {
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(value);
          copied = true;
        }
      } catch (_) { /* Permission may be denied; try the local selection fallback. */ }
      if (!copied) {
        const field = document.createElement('textarea');
        field.value = value;
        field.setAttribute('readonly', '');
        field.setAttribute('aria-hidden', 'true');
        field.style.position = 'fixed';
        field.style.opacity = '0';
        document.body.appendChild(field);
        field.select();
        try { copied = document.execCommand('copy'); } catch (_) { copied = false; }
        field.remove();
        button.focus({ preventScroll: true });
      }
      if (copied) {
        button.textContent = 'Copied';
        notify('PlavioMeta URL copied. Paste it in Addons → + in Plavio.');
        setTimeout(() => { button.innerHTML = original; }, 2500);
      } else {
        const code = document.getElementById('meta-manifest');
        if (code && window.getSelection) {
          const range = document.createRange();
          range.selectNodeContents(code);
          const selection = window.getSelection();
          selection.removeAllRanges();
          selection.addRange(range);
        }
        notify('Copy was blocked. Press and hold the manifest URL to copy it manually.');
      }
    });
  });
})();

/* Live latest-release updater: keeps the version labels and download links
   current on their own, reading the same stable.json / tv-stable.json feeds
   the in-app updater uses (via the GitLab API, which allows cross-origin
   reads). If a feed can't be reached, the static content in index.html
   stays exactly as written. */
(() => {
  'use strict';
  const FEED_BASE = 'https://gitlab.com/api/v4/projects/87396069/repository/files/';
  const versionPattern = /v\d+\.\d+\.\d+/g;
  const bareVersionPattern = /(?<![\d.])\d+\.\d+\.\d+(?![\d.])/g;

  function swapVersion(element, tag) {
    element.childNodes.forEach(node => {
      if (node.nodeType === Node.TEXT_NODE) {
        node.textContent = node.textContent.replace(versionPattern, tag);
      }
    });
  }

  async function fetchFeed(name) {
    const response = await fetch(FEED_BASE + name + '/raw?ref=main', { headers: { 'Accept': 'application/json' } });
    if (!response.ok) return null;
    const feed = await response.json();
    if (!feed || !/^\d+\.\d+\.\d+$/.test(feed.version || '')) return null;
    if (typeof feed.apkUrl !== 'string' || !feed.apkUrl.startsWith('https://gitlab.com/')) return null;
    return feed;
  }

  async function refreshMobile() {
    const feed = await fetchFeed('stable.json');
    if (!feed) return;
    const tag = 'v' + feed.version;
    document.querySelectorAll('[data-rel="apk-download"], [data-rel="gitlab-mirror"]').forEach(link => {
      link.href = feed.apkUrl;
      swapVersion(link, tag);
    });
    document.querySelectorAll('[data-rel="release-pill"], [data-rel="apk-meta"], [data-rel="release-eyebrow"]').forEach(element => {
      swapVersion(element, tag);
    });
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', metaDesc.getAttribute('content').replace(bareVersionPattern, feed.version));
    const jsonld = document.getElementById('release-jsonld');
    if (jsonld) {
      try {
        const data = JSON.parse(jsonld.textContent);
        data.softwareVersion = feed.version;
        data.downloadUrl = feed.apkUrl;
        jsonld.textContent = JSON.stringify(data);
      } catch (_) { /* Leave the static JSON-LD untouched. */ }
    }
  }

  async function refreshTv() {
    const feed = await fetchFeed('tv-stable.json');
    if (!feed) return;
    const tag = 'v' + feed.version;
    const abis = feed.abis || {};
    document.querySelectorAll('a[href*="/plavio-tv/"]').forEach(link => {
      if (link.hasAttribute('data-site-pin')) return; /* Pinned by the page itself (a build offered for download here before it reaches the in-app updater) — the feed rewrite leaves it alone. */
      if (link.href.includes('-arm64') && abis['arm64-v8a']) link.href = abis['arm64-v8a'];
      else if (link.href.includes('-armv7') && abis['armeabi-v7a']) link.href = abis['armeabi-v7a'];
      else if (!link.href.includes('-arm')) link.href = feed.apkUrl;
      const note = link.getAttribute('data-note');
      if (note) link.setAttribute('data-note', note.replace(bareVersionPattern, feed.version));
      swapVersion(link, tag);
    });
  }

  function refreshRelease() {
    refreshMobile().catch(() => {});
    refreshTv().catch(() => {});
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', refreshRelease);
  } else {
    refreshRelease();
  }
})();
