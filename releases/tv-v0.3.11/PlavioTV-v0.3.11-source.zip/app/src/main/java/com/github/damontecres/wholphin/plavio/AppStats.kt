package com.github.damontecres.wholphin.plavio

import android.content.Context
import com.github.damontecres.wholphin.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * Anonymous install + activity counting on the owner's OWN stats
 * server — the same counting the phone app runs (its AppStats),
 * ported to TV with flavor pinned to "tv" so Stats can split phone
 * vs TV installs and activity. No Google, no Firebase, no
 * third-party analytics.
 *
 * What is sent: a random install UUID (generated on the device; it
 * identifies no person), the app version and the flavor — nothing
 * else. Tiny GETs to /app-ping:
 *   kind=install    — once per install (first launch)
 *   kind=session    — every launch
 *   kind=heartbeat  — every 5 minutes while the app is on screen
 *   kind=session_end — when a foreground session ends, with dur=
 *                      its real length in seconds, so Stats reports
 *                      average session length + total time-in-app.
 *
 * Counting is ON by default and can be turned off in Settings →
 * "Anonymous usage counting". Failures are silent and never block
 * the app; a failed install ping is retried on a later launch.
 */
object AppStats {
    private const val ENDPOINT = "https://plaviohd.edon.workers.dev/app-ping"
    private const val FLAVOR = "tv"
    private const val PREFS = "plavio_stats"
    private const val KEY_UUID = "install_uuid"
    private const val KEY_COUNTED = "install_counted"
    private const val PRIVACY_PREFS = "plavio_privacy"
    private const val KEY_ENABLED = "anonymous_stats"

    fun enabled(context: Context): Boolean =
        context
            .getSharedPreferences(PRIVACY_PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, true)

    fun setEnabled(
        context: Context,
        value: Boolean,
    ) {
        context
            .getSharedPreferences(PRIVACY_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, value)
            .apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun uuid(context: Context): String {
        val p = prefs(context)
        return p.getString(KEY_UUID, null)
            ?: UUID.randomUUID().toString().also {
                p.edit().putString(KEY_UUID, it).apply()
            }
    }

    private fun ping(
        context: Context,
        kind: String,
        extra: String = "",
    ): Boolean {
        return try {
            val query =
                "uuid=${URLEncoder.encode(uuid(context), "UTF-8")}" +
                    "&ver=${URLEncoder.encode(BuildConfig.VERSION_NAME, "UTF-8")}" +
                    "&flavor=${URLEncoder.encode(FLAVOR, "UTF-8")}" +
                    "&kind=$kind" + extra
            val conn = URL("$ENDPOINT?$query").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            // Drain the response so the hit registers server-side.
            conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Launch ping: the one-time install count, plus a session tick. */
    suspend fun trackLaunch(context: Context) =
        withContext(Dispatchers.IO) {
            val appCtx = context.applicationContext
            if (!enabled(appCtx)) return@withContext
            val p = prefs(appCtx)
            if (!p.getBoolean(KEY_COUNTED, false)) {
                if (ping(appCtx, "install")) {
                    p.edit().putBoolean(KEY_COUNTED, true).apply()
                }
            }
            ping(appCtx, "session")
        }

    /** Foreground heartbeat: keeps "online now" honest. */
    suspend fun heartbeat(context: Context) =
        withContext(Dispatchers.IO) {
            val appCtx = context.applicationContext
            if (!enabled(appCtx)) return@withContext
            ping(appCtx, "heartbeat")
        }

    private val sessionScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Wall-clock start of the current foreground session (0 = none). */
    @Volatile
    private var sessionStartMs: Long = 0L

    /** Marks a foreground session start (MainActivity.onStart). */
    fun sessionStarted() {
        if (sessionStartMs == 0L) {
            sessionStartMs = System.currentTimeMillis()
        }
    }

    /**
     * Closes the current foreground session (MainActivity.onStop) and
     * reports its real duration. Sub-5-second blips are dropped
     * instead of pinged, so the server's averages aren't dragged
     * down by noise.
     */
    fun sessionEnded(context: Context) {
        val start = sessionStartMs
        sessionStartMs = 0L
        if (start == 0L) return
        val seconds = (System.currentTimeMillis() - start) / 1000L
        if (seconds < 5) return
        val appCtx = context.applicationContext
        if (!enabled(appCtx)) return
        sessionScope.launch { ping(appCtx, "session_end", "&dur=$seconds") }
    }
}
