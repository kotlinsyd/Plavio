package com.github.damontecres.wholphin.plavio

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioAddonsDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_addons")

/** An addon installed in Plavio TV: its base URL plus the manifest fetched when it was added. */
data class InstalledAddon(
    val baseUrl: String,
    val manifest: AddonManifest,
    val enabled: Boolean = true,
    val preinstalled: Boolean = false,
) {
    val id: String get() = manifest.id
    val name: String get() = manifest.name
}

/** Serializable mirror of [CatalogRef] for persistence. */
@Serializable
private data class StoredCatalog(
    val type: String,
    val id: String,
    val name: String,
    val extra: List<String> = emptyList(),
)

/** Serializable mirror of [InstalledAddon] for persistence. */
@Serializable
private data class StoredAddon(
    val baseUrl: String,
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val logo: String? = null,
    val types: List<String> = emptyList(),
    val resources: List<String> = emptyList(),
    val catalogs: List<StoredCatalog> = emptyList(),
    val configurable: Boolean = false,
    val enabled: Boolean = true,
    val preinstalled: Boolean = false,
) {
    fun toInstalled(): InstalledAddon =
        InstalledAddon(
            baseUrl = baseUrl,
            manifest =
                AddonManifest(
                    id = id,
                    name = name,
                    version = version,
                    description = description,
                    types = types,
                    catalogs =
                        catalogs.map {
                            CatalogRef(type = it.type, id = it.id, name = it.name, extra = it.extra)
                        },
                    resources = resources,
                    configurable = configurable,
                    logo = logo,
                ),
            enabled = enabled,
            preinstalled = preinstalled,
        )

    companion object {
        fun from(addon: InstalledAddon): StoredAddon =
            StoredAddon(
                baseUrl = addon.baseUrl,
                id = addon.manifest.id,
                name = addon.manifest.name,
                version = addon.manifest.version,
                description = addon.manifest.description,
                logo = addon.manifest.logo,
                types = addon.manifest.types,
                resources = addon.manifest.resources,
                catalogs =
                    addon.manifest.catalogs.map {
                        StoredCatalog(type = it.type, id = it.id, name = it.name, extra = it.extra)
                    },
                configurable = addon.manifest.configurable,
                enabled = addon.enabled,
                preinstalled = addon.preinstalled,
            )
    }
}

/**
 * Persists the installed addons (base URLs + manifests) in a Preferences
 * DataStore, following the same storage approach the app already uses for
 * its key/value data.
 *
 * Pre-install behavior mirrors the phone app: the factory set (public
 * PlavioHD + PMeta on, HDHub bundled off — see [ensureHouseAddons]) is
 * installed once per manifest id on first launch; a user who removes one
 * is never force-fed it again, and a failed attempt (e.g. offline first
 * launch) is retried on the next one.
 */
@Singleton
class AddonStore
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioAddonsDataStore
        private val api = StremioApi()
        private val json = Json { ignoreUnknownKeys = true }
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        val addons: StateFlow<List<InstalledAddon>> =
            dataStore.data
                .map { prefs -> decode(prefs[KEY_ADDONS]) }
                .stateIn(scope, SharingStarted.Eagerly, emptyList())

        /** Fetches the manifest for [url] and installs (or refreshes) the addon. */
        suspend fun addAddon(url: String): Result<InstalledAddon> =
            withContext(Dispatchers.IO) {
                runCatching {
                    val baseUrl = StremioApi.normalizeBaseUrl(url)
                    val manifest = api.fetchManifest(baseUrl)
                    val existing = addons.value.firstOrNull { it.id == manifest.id }
                    val addon =
                        InstalledAddon(
                            baseUrl = baseUrl,
                            manifest = manifest,
                            enabled = existing?.enabled ?: true,
                            preinstalled = existing?.preinstalled ?: false,
                        )
                    mutate { list ->
                        list.filterNot { it.id == addon.id } + addon
                    }
                    addon
                }
            }

        suspend fun removeAddon(id: String) {
            mutate { list -> list.filterNot { it.id == id } }
        }

        /**
         * Re-fetches the manifest for an installed addon from its stored
         * base URL and updates the stored record (phone parity: the
         * phone's Addons screen Refresh does exactly this). Enabled and
         * pre-installed are user-owned and survive; on any failure the
         * stored record is left untouched and the error is returned.
         */
        suspend fun refreshAddon(id: String): Result<InstalledAddon> =
            withContext(Dispatchers.IO) {
                runCatching {
                    val current =
                        addons.value.firstOrNull { it.id == id }
                            ?: throw IllegalStateException("Addon not found")
                    val manifest = api.fetchManifest(current.baseUrl)
                    val updated = current.copy(manifest = manifest)
                    mutate { list ->
                        // The refreshed manifest's id can DIFFER from the
                        // stored one (an addon re-published under a new
                        // id at the same URL — PMeta replacing the old
                        // PlavioMeta at plaviometa.vercel.app did exactly
                        // this). Replace this entry with the updated one
                        // and drop any OTHER entry already carrying the
                        // new id, so a refresh can never leave two rows
                        // with the same id (the PLAVIO-9 duplicate-key
                        // crash).
                        list.mapNotNull {
                            when {
                                it.id == id -> updated
                                it.id == updated.id -> null
                                else -> it
                            }
                        }
                    }
                    updated
                }
            }

        /**
         * Replaces the whole addon set from a restored backup (the
         * phone's import does the same). Imported entries carry no
         * catalog list — manifests are re-fetched in the background so
         * home rows and search work again, exactly like the phone
         * re-resolving manifests after a restore.
         */
        suspend fun importAddons(imported: List<InstalledAddon>) {
            // A restored backup can itself carry a duplicated id; the
            // installed set is keyed by id everywhere, so never let a
            // twin in through this door either.
            mutate { imported.distinctBy { it.id } }
            imported.forEach { setPreinstallDone(it.id) }
            scope.launch {
                imported.forEach { addon ->
                    runCatching { api.fetchManifest(addon.baseUrl) }
                        .onSuccess { manifest ->
                            mutate { list ->
                                list.map {
                                    if (it.id == addon.id) it.copy(manifest = manifest) else it
                                }
                            }
                        }
                }
            }
        }

        /**
         * Addons-only sync merge (v0.3.14): unlike [importAddons]
         * (a full restore, which replaces the installed set), this
         * keeps everything already installed, appends only the
         * addons the device doesn't have yet (by id), and syncs the
         * `enabled` flag of the ones it does have — so addons added
         * on the phone appear on the TV without wiping TV-only
         * addons. Returns how many addons were newly added. New
         * entries get the same background manifest re-fetch as a
         * restore, so their home rows/search work.
         */
        suspend fun mergeAddons(imported: List<InstalledAddon>): Int {
            val existingIds = addons.value.map { it.id }.toSet()
            val newOnes = imported.distinctBy { it.id }.filter { it.id !in existingIds }
            mutate { list ->
                val byId = imported.distinctBy { it.id }.associateBy { it.id }
                val updated =
                    list.map { current ->
                        byId[current.id]?.let { current.copy(enabled = it.enabled) } ?: current
                    }
                updated + newOnes
            }
            newOnes.forEach { setPreinstallDone(it.id) }
            if (newOnes.isNotEmpty()) {
                scope.launch {
                    newOnes.forEach { addon ->
                        runCatching { api.fetchManifest(addon.baseUrl) }
                            .onSuccess { manifest ->
                                mutate { list ->
                                    list.map {
                                        if (it.id == addon.id) it.copy(manifest = manifest) else it
                                    }
                                }
                            }
                    }
                }
            }
            return newOnes.size
        }

        suspend fun setEnabled(
            id: String,
            enabled: Boolean,
        ) {
            mutate { list ->
                list.map { if (it.id == id) it.copy(enabled = enabled) else it }
            }
        }

        /**
         * Installs the factory pre-installed addons, plus the bundled
         * OFF-by-default set. Factory set (owner's rule 2026-11-02,
         * amended 19:20 the same day, and again 2026-11-07):
         * pre-installed ON = PlavioHD + PMeta + addon.plavio.site
         * (the public Live TV addon) + HDHub — all four ship ON
         * since v0.3.20; the bundled OFF set is empty. No other
         * extras ship in the set. Seeding is once-per-id, so this
         * governs fresh installs; a user's own installed/synced
         * addons are never touched by it.
         */
        suspend fun ensureHouseAddons() =
            withContext(Dispatchers.IO) {
                // Public PlavioHD: pre-installed and on by default.
                ensurePreinstalled(PLAVIOHD_URL)
                // PMeta is the default metadata addon: on.
                ensurePreinstalled(PMETA_URL)
                // The public Live TV addon: pre-installed and on.
                ensurePreinstalled(LIVETV_URL)
                // HDHub: pre-installed and on (owner rule change
                // 2026-11-07 — it seeded OFF before v0.3.20).
                ensurePreinstalled(HDHUB_URL)
                ensureBundledAddons()
            }

        /**
         * Bundled addons, mirroring the phone app's
         * `ensureBundledAddons`: seeded once per manifest id, all OFF by
         * default, never re-seeded after the user deletes one, and normal
         * addons afterwards (toggle/remove work). The set is empty
         * since v0.3.20 (HDHub moved to the factory ON set).
         */
        suspend fun ensureBundledAddons() =
            withContext(Dispatchers.IO) {
                BUNDLED_ADDON_URLS.forEach { ensurePreinstalled(it, enabled = false) }
            }

        private suspend fun ensurePreinstalled(
            url: String,
            enabled: Boolean = true,
        ) {
            try {
                val baseUrl = StremioApi.normalizeBaseUrl(url)
                val manifest = api.fetchManifest(baseUrl)
                val existing = addons.value.firstOrNull { it.id == manifest.id }
                if (existing != null) {
                    setPreinstallDone(manifest.id)
                    return
                }
                if (isPreinstallDone(manifest.id)) return
                mutate { list ->
                    list.filterNot { it.id == manifest.id } +
                        InstalledAddon(
                            baseUrl = baseUrl,
                            manifest = manifest,
                            enabled = enabled,
                            preinstalled = true,
                        )
                }
                setPreinstallDone(manifest.id)
            } catch (e: Exception) {
                // Offline or dead URL — try again next launch.
                Timber.v(e, "Pre-install of $url failed, will retry next launch")
            }
        }

        private suspend fun isPreinstallDone(manifestId: String): Boolean =
            dataStore.data.first()[booleanPreferencesKey(KEY_PREINSTALL_PREFIX + manifestId)] ?: false

        private suspend fun setPreinstallDone(manifestId: String) {
            dataStore.edit { prefs ->
                prefs[booleanPreferencesKey(KEY_PREINSTALL_PREFIX + manifestId)] = true
            }
        }

        private suspend fun mutate(transform: (List<InstalledAddon>) -> List<InstalledAddon>) {
            dataStore.edit { prefs ->
                val updated = transform(decode(prefs[KEY_ADDONS]))
                prefs[KEY_ADDONS] =
                    json.encodeToString(
                        kotlinx.serialization.builtins.ListSerializer(StoredAddon.serializer()),
                        updated.map { StoredAddon.from(it) },
                    )
            }
        }

        private fun decode(raw: String?): List<InstalledAddon> {
            if (raw.isNullOrBlank()) return emptyList()
            return runCatching {
                val decoded =
                    json
                        .decodeFromString(
                            kotlinx.serialization.builtins.ListSerializer(StoredAddon.serializer()),
                            raw,
                        ).map { it.toInstalled() }
                // Self-heal (PLAVIO-9): a stored list written before the
                // refresh-race fix can hold the same addon id twice,
                // which hard-crashes the keyed Addons list. The set is
                // keyed by id everywhere, so collapse twins here — first
                // occurrence wins. Every read (the addons StateFlow and
                // every mutate) flows through decode, so an owner
                // already carrying the duplicate is healed on the first
                // read of the new build, and the next mutate persists
                // the healed list.
                val deduped = decoded.distinctBy { it.id }
                if (deduped.size != decoded.size) {
                    Timber.w(
                        "Dropped ${decoded.size - deduped.size} duplicate addon row(s) on read",
                    )
                }
                deduped
            }.getOrElse {
                Timber.w(it, "Failed to decode stored addons, starting fresh")
                emptyList()
            }
        }

        companion object {
            /** Public PlavioHD — pre-installed and on by default. */
            const val PLAVIOHD_URL = "https://hd.plavio.site/manifest.json"

            /** PMeta — the default metadata addon (enabled). */
            const val PMETA_URL = "https://meta.plavio.site/manifest.json"

            /** The public Live TV addon — pre-installed and on by default (owner order 2026-11-02 19:20). */
            const val LIVETV_URL = "https://addon.plavio.site/manifest.json"

            /** HDHub (the standalone addon) — pre-installed; seeded ON since v0.3.20 (owner rule change 2026-11-07). */
            const val HDHUB_URL = "https://hdhub.thevolecitor.qzz.io/manifest.json"

            /** The factory pre-installed (ON) set — their Remove stays disabled in the Addons UI. */
            val FACTORY_ADDON_URLS = listOf(PLAVIOHD_URL, PMETA_URL, LIVETV_URL, HDHUB_URL)

            /**
             * Bundled addons seeded OFF by default. EMPTY since
             * v0.3.20: HDHub was the only entry, and the owner's
             * rule change (2026-11-07) moved it into the factory
             * ON set above — all four seeds now ship ON.
             */
            val BUNDLED_ADDON_URLS = emptyList<String>()

            private val KEY_ADDONS = stringPreferencesKey("installed_addons")
            private const val KEY_PREINSTALL_PREFIX = "preinstall_done_"
        }
    }
