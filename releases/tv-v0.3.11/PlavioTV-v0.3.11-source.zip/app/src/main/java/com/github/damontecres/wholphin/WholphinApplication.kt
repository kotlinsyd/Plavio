package com.github.damontecres.wholphin

import android.app.Application
import android.os.Build
import android.os.StrictMode
import android.util.Log
import androidx.compose.runtime.Composer
import androidx.compose.runtime.ExperimentalComposeRuntimeApi
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.github.damontecres.wholphin.plavio.CrashReports
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject
import kotlinx.coroutines.launch

@OptIn(ExperimentalComposeRuntimeApi::class)
@HiltAndroidApp
class WholphinApplication :
    Application(),
    Configuration.Provider {
    init {
        instance = this

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        } else {
            Timber.plant(
                object : Timber.Tree() {
                    override fun isLoggable(
                        tag: String?,
                        priority: Int,
                    ): Boolean = priority >= Log.INFO

                    override fun log(
                        priority: Int,
                        tag: String?,
                        message: String,
                        t: Throwable?,
                    ) {
                        Log.println(priority, tag ?: "Wholphin", message)
                    }
                },
            )
        }

        Composer.setDiagnosticStackTraceEnabled(BuildConfig.DEBUG)
    }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy
                    .Builder()
                    .detectNetwork()
                    .penaltyLog()
                    .penaltyDeathOnNetwork()
                    .build(),
            )
//            StrictMode.setVmPolicy(
//                StrictMode.VmPolicy
//                    .Builder()
//                    .detectAll()
//                    .penaltyLog()
//                    .build(),
//            )
        }
        // Sentry is the single crash path (ACRA's dialog promised a
        // SEND with no destination and was removed in v0.2.1). Manual,
        // guarded init; a no-op when the user opted out or no DSN was
        // injected at build time.
        CrashReports.initIfEnabled(this)
        CrashReports.putCustomData("SDK_INT", Build.VERSION.SDK_INT.toString())
        // v0.2.2 parity batch: reduced-motion preference + the
        // episode alert store load synchronously; the periodic check
        // is (re)scheduled once the saved toggle value lands.
        com.github.damontecres.wholphin.plavio.MotionPreferences.initialize(this)
        com.github.damontecres.wholphin.plavio.EpisodeAlertStore.initialize(this)
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            com.github.damontecres.wholphin.plavio.EpisodeAlerts
                .ensureScheduled(this@WholphinApplication, uiPrefs.episodeAlertsEnabledOnce())
        }
    }

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    @Inject
    lateinit var uiPrefs: com.github.damontecres.wholphin.plavio.PlavioUiPrefs

    override val workManagerConfiguration: Configuration
        get() =
            Configuration
                .Builder()
                .setWorkerFactory(workerFactory)
                .build()

    companion object {
        lateinit var instance: WholphinApplication
            private set
    }
}
