package com.github.damontecres.wholphin.plavio.download

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioDownloadsDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_downloads")

enum class DownloadStatus { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

/** One downloaded (or downloading) title, persisted across launches. */
@Serializable
data class DownloadEntry(
    val id: String,
    val url: String,
    val title: String,
    val poster: String? = null,
    val type: String = "movie",
    val videoId: String = "",
    val metaId: String = "",
    val season: Int = 0,
    val episode: Int = 0,
    val seriesName: String? = null,
    val episodeTitle: String? = null,
    val sourceName: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String? = null,
    val filePath: String = "",
    val isHls: Boolean = false,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val downloadedBytes: Long = 0,
    val totalBytes: Long = -1,
    val error: String? = null,
    val createdAt: Long = 0,
) {
    val progressFraction: Float
        get() =
            when {
                status == DownloadStatus.COMPLETED -> 1f
                totalBytes > 0 -> (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
                else -> 0f
            }
}

/**
 * Plavio TV's download engine — the phone app's download behaviour in
 * TV form (the phone's Room-backed manager doesn't fit this tree, which
 * dropped Room in Stage 5; state lives in a Preferences DataStore like
 * the other Plavio stores):
 *
 * - Progressive files over HTTP with Range resume (If-Range guarded),
 *   pause / resume / cancel.
 * - HLS VOD: best variant of a master playlist, segments fetched
 *   (AES-128 decrypted when keyed), joined and remuxed to one MP4 via
 *   MediaExtractor/MediaMuxer; live playlists are refused, DASH is
 *   refused up front.
 * - Downloads keep running while the app process lives; if the process
 *   dies mid-download the entry comes back as PAUSED and resumes where
 *   it left off.
 */
@Singleton
class PlavioDownloadManager
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioDownloadsDataStore
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val json = Json { ignoreUnknownKeys = true }
        private val client =
            OkHttpClient
                .Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
        private val jobs = mutableMapOf<String, Job>()
        private val etags = mutableMapOf<String, Pair<String?, String?>>()

        val entries: StateFlow<List<DownloadEntry>> =
            dataStore.data
                .map { prefs -> decode(prefs[KEY_ENTRIES]) }
                .stateIn(scope, SharingStarted.Eagerly, emptyList())

        init {
            // Anything left "downloading" by a dead process is resumable.
            scope.launch {
                val stuck = entries.first().filter { it.status == DownloadStatus.DOWNLOADING }
                stuck.forEach { update(it.copy(status = DownloadStatus.PAUSED)) }
            }
        }

        fun downloadsDir(): File =
            File(context.getExternalFilesDir(null), "downloads").apply { mkdirs() }

        fun isHlsUrl(url: String): Boolean = url.lowercase().contains(".m3u8")

        fun isDashUrl(url: String): Boolean = url.lowercase().contains(".mpd")

        /** Starts (or restarts) a download for [entry]-shaped input. Returns the entry id. */
        fun enqueue(
            url: String,
            title: String,
            poster: String?,
            type: String,
            videoId: String,
            metaId: String,
            season: Int,
            episode: Int,
            seriesName: String?,
            episodeTitle: String?,
            sourceName: String?,
            headers: Map<String, String>,
            mimeType: String?,
        ): String {
            val id =
                MessageDigest
                    .getInstance("SHA-256")
                    .digest(url.toByteArray(Charsets.UTF_8))
                    .take(10)
                    .joinToString("") { "%02x".format(it.toInt() and 0xff) }
            scope.launch {
                val existing = entries.value.firstOrNull { it.id == id }
                if (existing != null && existing.status == DownloadStatus.COMPLETED) return@launch
                val hls = isHlsUrl(url)
                val fileName = sanitizeFileName(title) + if (hls) ".mp4" else guessExtension(url)
                val entry =
                    (existing ?: DownloadEntry(
                        id = id,
                        url = url,
                        title = title,
                        poster = poster,
                        type = type,
                        videoId = videoId,
                        metaId = metaId,
                        season = season,
                        episode = episode,
                        seriesName = seriesName,
                        episodeTitle = episodeTitle,
                        sourceName = sourceName,
                        headers = headers,
                        mimeType = mimeType,
                        createdAt = System.currentTimeMillis(),
                    )).copy(
                        filePath = File(downloadsDir(), "$id-$fileName").absolutePath,
                        isHls = hls,
                        status = DownloadStatus.QUEUED,
                        error = null,
                    )
                upsert(entry)
                start(entry)
            }
            return id
        }

        fun pause(id: String) {
            jobs.remove(id)?.cancel()
            scope.launch {
                entries.value.firstOrNull { it.id == id }?.let {
                    if (it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED) {
                        update(it.copy(status = DownloadStatus.PAUSED))
                    }
                }
            }
        }

        fun resume(id: String) {
            scope.launch {
                entries.value.firstOrNull { it.id == id }?.let { entry ->
                    if (entry.status == DownloadStatus.PAUSED || entry.status == DownloadStatus.FAILED) {
                        start(entry.copy(status = DownloadStatus.QUEUED, error = null))
                    }
                }
            }
        }

        /** Cancel = stop and throw the partial data away entirely. */
        fun cancel(id: String) {
            jobs.remove(id)?.cancel()
            scope.launch {
                entries.value.firstOrNull { it.id == id }?.let { entry ->
                    deleteFiles(entry)
                    mutate { list -> list.filterNot { it.id == id } }
                }
            }
        }

        /** Delete a finished download (file + entry). */
        fun delete(id: String) = cancel(id)

        private fun start(entry: DownloadEntry) {
            jobs[entry.id]?.cancel()
            jobs[entry.id] =
                scope.launch {
                    update(entry.copy(status = DownloadStatus.DOWNLOADING, error = null))
                    try {
                        if (entry.isHls) {
                            downloadHls(entry)
                        } else {
                            downloadProgressive(entry)
                        }
                        entries.value.firstOrNull { it.id == entry.id }?.let { done ->
                            update(
                                done.copy(
                                    status = DownloadStatus.COMPLETED,
                                    downloadedBytes = File(done.filePath).length(),
                                    totalBytes = File(done.filePath).length(),
                                    error = null,
                                ),
                            )
                        }
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Timber.w(e, "Download %s failed", entry.id)
                        entries.value.firstOrNull { it.id == entry.id }?.let { failed ->
                            if (failed.status == DownloadStatus.DOWNLOADING) {
                                update(
                                    failed.copy(
                                        status = DownloadStatus.FAILED,
                                        error = e.message ?: "Download failed",
                                    ),
                                )
                            }
                        }
                    } finally {
                        jobs.remove(entry.id)
                    }
                }
        }

        // --------------------------------------------------------------
        // Progressive download with Range resume
        // --------------------------------------------------------------

        private suspend fun downloadProgressive(entry: DownloadEntry) =
            withContext(Dispatchers.IO) {
                val target = File(entry.filePath)
                var existing = if (target.exists()) target.length() else 0L
                var total = entry.totalBytes
                var attempts = 0
                while (true) {
                    attempts++
                    if (attempts > 4) throw IOException("Download kept restarting")
                    val builder = Request.Builder().url(entry.url)
                    entry.headers.forEach { (k, v) -> builder.header(k, v) }
                    if (existing > 0) {
                        builder.header("Range", "bytes=$existing-")
                        etags[entry.id]?.let { (etag, lastModified) ->
                            (etag?.takeUnless { it.startsWith("W/") } ?: lastModified)
                                ?.let { builder.header("If-Range", it) }
                        }
                    }
                    val restart =
                        client.newCall(builder.build()).execute().use { resp ->
                            when {
                                resp.code == 206 -> {
                                    val rangeTotal =
                                        Regex("""bytes \d+-\d+/(\d+)""")
                                            .find(resp.header("Content-Range") ?: "")
                                            ?.groupValues
                                            ?.get(1)
                                            ?.toLongOrNull()
                                    if (rangeTotal != null) total = rangeTotal
                                    etags[entry.id] =
                                        resp.header("ETag") to resp.header("Last-Modified")
                                    appendBody(entry, resp, existing, total)
                                    false
                                }
                                resp.code == 200 -> {
                                    // Server ignored Range (or first request): write fresh.
                                    val len = resp.body?.contentLength() ?: -1
                                    if (len > 0) total = len
                                    val head = resp.peekBody(64).bytes()
                                    if (isUnsupportedPayload(head)) {
                                        throw IOException(
                                            "This link serves an adaptive manifest, not a complete file — it can't be downloaded.",
                                        )
                                    }
                                    existing = 0
                                    appendBody(entry, resp, 0, total)
                                    false
                                }
                                resp.code == 416 && total > 0 && existing >= total -> false
                                !resp.isSuccessful -> throw IOException("HTTP ${resp.code}")
                                else -> false
                            }
                        }
                    if (!restart) break
                    existing = 0
                    target.delete()
                }
                if (target.length() <= 0L) throw IOException("Download produced an empty file")
            }

        /** Streams the response body onto [target] starting at [offset]; returns nothing. */
        private fun appendBody(
            entry: DownloadEntry,
            resp: okhttp3.Response,
            offset: Long,
            total: Long,
        ) {
            val body = resp.body ?: throw IOException("Empty response")
            val target = File(entry.filePath)
            RandomAccessFile(target, "rw").use { raf ->
                raf.seek(offset)
                body.byteStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    var written = offset
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                        written += n
                        if (written - lastReport > 512 * 1024) {
                            lastReport = written
                            val snapshot = written
                            scope.launch {
                                entries.value.firstOrNull { it.id == entry.id }?.let {
                                    update(it.copy(downloadedBytes = snapshot, totalBytes = total))
                                }
                            }
                        }
                    }
                }
            }
        }

        private fun isUnsupportedPayload(prefix: ByteArray): Boolean {
            val text =
                prefix
                    .toString(Charsets.UTF_8)
                    .trimStart('\uFEFF', ' ', '\t', '\r', '\n')
                    .lowercase()
            return text.startsWith("#extm3u") || text.startsWith("<mpd") ||
                (text.startsWith("<?xml") && "<mpd" in text) ||
                text.startsWith("<!doctype html") || text.startsWith("<html")
        }

        // --------------------------------------------------------------
        // HLS download (ported from the phone app's approach)
        // --------------------------------------------------------------

        private data class HlsMedia(
            val segmentUrls: List<String>,
            val initUrl: String?,
            val keyUrl: String?,
            val keyIv: ByteArray?,
            val mediaSequence: Long,
            val sampleAes: Boolean,
        )

        private fun resolveHttpUrl(
            base: String,
            ref: String,
        ): String =
            runCatching {
                base.toHttpUrl().resolve(ref)?.toString()
            }.getOrNull() ?: ref

        private fun parseMasterPlaylist(
            text: String,
            base: String,
        ): String? {
            var bestBandwidth = -1L
            var best: String? = null
            var pendingBandwidth: Long? = null
            for (raw in text.lines()) {
                val line = raw.trim()
                when {
                    line.startsWith("#EXT-X-STREAM-INF") ->
                        pendingBandwidth =
                            Regex("""BANDWIDTH=(\d+)""").find(line)?.groupValues?.get(1)?.toLongOrNull()
                    line.isNotEmpty() && !line.startsWith("#") -> {
                        val bw = pendingBandwidth ?: 0L
                        if (bw > bestBandwidth) {
                            bestBandwidth = bw
                            best = resolveHttpUrl(base, line)
                        }
                        pendingBandwidth = null
                    }
                }
            }
            return best
        }

        private fun parseMediaPlaylist(
            text: String,
            base: String,
        ): HlsMedia {
            var keyUrl: String? = null
            var keyIv: ByteArray? = null
            var sampleAes = false
            var mediaSequence = 0L
            var initUrl: String? = null
            val segs = mutableListOf<String>()
            for (raw in text.lines()) {
                val line = raw.trim()
                when {
                    line.startsWith("#EXT-X-MEDIA-SEQUENCE:") ->
                        mediaSequence = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                    line.startsWith("#EXT-X-KEY:") -> {
                        when (Regex("""METHOD=([A-Z0-9-]+)""").find(line)?.groupValues?.get(1)) {
                            "SAMPLE-AES" -> sampleAes = true
                            "AES-128" -> {
                                Regex("""URI="([^"]+)"""").find(line)?.groupValues?.get(1)
                                    ?.let { keyUrl = resolveHttpUrl(base, it) }
                                Regex("""IV=0x([0-9A-Fa-f]+)""").find(line)?.groupValues?.get(1)?.let { hex ->
                                    keyIv =
                                        hex.padStart(32, '0').takeLast(32).chunked(2)
                                            .map { it.toInt(16).toByte() }.toByteArray()
                                }
                            }
                        }
                    }
                    line.startsWith("#EXT-X-MAP:") ->
                        Regex("""URI="([^"]+)"""").find(line)?.groupValues?.get(1)
                            ?.let { initUrl = resolveHttpUrl(base, it) }
                    line.isNotEmpty() && !line.startsWith("#") -> segs.add(resolveHttpUrl(base, line))
                }
            }
            return HlsMedia(segs, initUrl, keyUrl, keyIv, mediaSequence, sampleAes)
        }

        private fun fetchBytes(
            url: String,
            headers: Map<String, String>,
        ): ByteArray? {
            val request =
                Request
                    .Builder()
                    .url(url)
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .build()
            return runCatching {
                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) null else resp.body?.bytes()
                }
            }.getOrNull()
        }

        private suspend fun downloadHls(entry: DownloadEntry) {
            val target = File(entry.filePath)
            val workDir = File(entry.filePath + ".hls").apply { mkdirs() }
            var playlistUrl = entry.url
            var text =
                fetchBytes(playlistUrl, entry.headers)?.toString(Charsets.UTF_8)
                    ?: throw IOException("Could not fetch the HLS playlist")
            if (text.contains("#EXT-X-STREAM-INF")) {
                playlistUrl =
                    parseMasterPlaylist(text, playlistUrl)
                        ?: throw IOException("No playable variant in the HLS playlist")
                text =
                    fetchBytes(playlistUrl, entry.headers)?.toString(Charsets.UTF_8)
                        ?: throw IOException("Could not fetch the HLS variant playlist")
            }
            if (!text.contains("#EXT-X-ENDLIST")) {
                throw IOException("Live streams can't be saved offline — only finished streams can.")
            }
            val media = parseMediaPlaylist(text, playlistUrl)
            if (media.segmentUrls.isEmpty()) throw IOException("The HLS playlist has no segments")
            if (media.sampleAes) {
                throw IOException("This stream uses SAMPLE-AES encryption, which can't be downloaded yet.")
            }
            val keyBytes =
                media.keyUrl?.let {
                    fetchBytes(it, entry.headers) ?: throw IOException("Could not fetch the HLS encryption key")
                }

            fun segmentFile(index: Int) = File(workDir, "seg-%05d".format(index))
            val semaphore = Semaphore(3)
            coroutineScope {
                val jobs =
                    media.segmentUrls.mapIndexed { index, segUrl ->
                        async(Dispatchers.IO) {
                            val out = segmentFile(index)
                            if (out.exists() && out.length() > 0) return@async
                            semaphore.withPermit {
                                val raw =
                                    fetchBytes(segUrl, entry.headers)
                                        ?: throw IOException("Segment ${index + 1} of ${media.segmentUrls.size} failed")
                                val plain =
                                    if (keyBytes != null) {
                                        decryptAes128(
                                            raw,
                                            keyBytes,
                                            media.keyIv ?: sequenceIv(media.mediaSequence + index),
                                        )
                                    } else {
                                        raw
                                    }
                                out.writeBytes(plain)
                                val done = media.segmentUrls.indices.count {
                                    segmentFile(it).exists()
                                }
                                scope.launch {
                                    entries.value.firstOrNull { it.id == entry.id }?.let {
                                        update(
                                            it.copy(
                                                downloadedBytes = done.toLong(),
                                                totalBytes = media.segmentUrls.size.toLong(),
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    }
                jobs.awaitAll()
            }

            val joined = File(entry.filePath + ".joined")
            withContext(Dispatchers.IO) {
                FileOutputStream(joined).use { out ->
                    if (media.initUrl != null) {
                        val initFile = File(workDir, "seg-init")
                        if (!initFile.exists()) {
                            val bytes =
                                fetchBytes(media.initUrl, entry.headers)
                                    ?: throw IOException("Could not fetch the HLS init segment")
                            initFile.writeBytes(bytes)
                        }
                        initFile.inputStream().use { it.copyTo(out) }
                    }
                    media.segmentUrls.indices.forEach { i ->
                        segmentFile(i).inputStream().use { it.copyTo(out) }
                    }
                }
            }
            val remuxed = runCatching { remuxToMp4(joined, target) }.getOrDefault(false)
            if (!remuxed) {
                withContext(Dispatchers.IO) { joined.copyTo(target, overwrite = true) }
            }
            joined.delete()
            workDir.deleteRecursively()
            if (target.length() <= 0L) throw IOException("The HLS download produced an empty file")
        }

        private fun decryptAes128(
            data: ByteArray,
            key: ByteArray,
            iv: ByteArray,
        ): ByteArray {
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
            return cipher.doFinal(data)
        }

        private fun sequenceIv(sequence: Long): ByteArray {
            val iv = ByteArray(16)
            var v = sequence
            for (i in 15 downTo 8) {
                iv[i] = (v and 0xFF).toByte()
                v = v shr 8
            }
            return iv
        }

        /** Stream-copy remux (no re-encode). False when the container/codecs refuse. */
        private fun remuxToMp4(
            source: File,
            target: File,
        ): Boolean {
            val extractor = MediaExtractor()
            var muxer: MediaMuxer? = null
            return try {
                extractor.setDataSource(source.absolutePath)
                if (extractor.trackCount == 0) return false
                val mx = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                muxer = mx
                val trackMap = mutableMapOf<Int, Int>()
                for (i in 0 until extractor.trackCount) {
                    val format: MediaFormat = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        trackMap[i] = mx.addTrack(format)
                        extractor.selectTrack(i)
                    }
                }
                if (trackMap.isEmpty()) return false
                mx.start()
                val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
                val info = android.media.MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    val track = trackMap[extractor.sampleTrackIndex] ?: run {
                        extractor.advance()
                        continue
                    }
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = extractor.sampleFlags
                    mx.writeSampleData(track, buffer, info)
                    extractor.advance()
                }
                true
            } catch (e: Exception) {
                Timber.v(e, "HLS remux failed, keeping joined stream")
                false
            } finally {
                runCatching { muxer?.stop() }
                runCatching { muxer?.release() }
                runCatching { extractor.release() }
                if (target.exists() && target.length() == 0L) target.delete()
            }
        }

        // --------------------------------------------------------------
        // Persistence
        // --------------------------------------------------------------

        private fun deleteFiles(entry: DownloadEntry) {
            runCatching { File(entry.filePath).delete() }
            runCatching { File(entry.filePath + ".hls").deleteRecursively() }
            runCatching { File(entry.filePath + ".joined").delete() }
        }

        private suspend fun upsert(entry: DownloadEntry) {
            mutate { list -> list.filterNot { it.id == entry.id } + entry }
        }

        private suspend fun update(entry: DownloadEntry) {
            mutate { list -> list.map { if (it.id == entry.id) entry else it } }
        }

        private suspend fun mutate(transform: (List<DownloadEntry>) -> List<DownloadEntry>) {
            dataStore.edit { prefs ->
                val updated = transform(decode(prefs[KEY_ENTRIES]))
                prefs[KEY_ENTRIES] =
                    json.encodeToString(
                        kotlinx.serialization.builtins.ListSerializer(DownloadEntry.serializer()),
                        updated.sortedByDescending { it.createdAt },
                    )
            }
        }

        private fun decode(raw: String?): List<DownloadEntry> {
            if (raw.isNullOrBlank()) return emptyList()
            return runCatching {
                json.decodeFromString(
                    kotlinx.serialization.builtins.ListSerializer(DownloadEntry.serializer()),
                    raw,
                )
            }.getOrElse {
                Timber.w(it, "Failed to decode downloads, starting fresh")
                emptyList()
            }
        }

        private companion object {
            val KEY_ENTRIES = stringPreferencesKey("entries")

            fun sanitizeFileName(title: String): String {
                val clean =
                    title
                        .replace(Regex("""[\\/:*?"<>|]"""), " ")
                        .replace(Regex("""\s+"""), " ")
                        .trim()
                        .take(60)
                return clean.ifBlank { "download" }
            }

            fun guessExtension(url: String): String {
                val path = url.substringBefore('?').lowercase()
                return when {
                    path.endsWith(".mkv") -> ".mkv"
                    path.endsWith(".webm") -> ".webm"
                    path.endsWith(".avi") -> ".avi"
                    path.endsWith(".mov") -> ".mov"
                    else -> ".mp4"
                }
            }
        }
    }
