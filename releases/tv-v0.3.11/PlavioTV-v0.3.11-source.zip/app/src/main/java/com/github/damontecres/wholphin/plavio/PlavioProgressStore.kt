package com.github.damontecres.wholphin.plavio

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioProgressDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_progress")

/**
 * One in-progress title in the Plavio flow: everything needed to resume
 * playback (the chosen stream, its headers and subtitles) plus where the
 * user left off. Deliberately independent of the Jellyfin-shaped
 * ItemPlayback tables — this is local-only state for addon items.
 */
data class ContinueWatchingEntry(
    val type: String,
    val videoId: String,
    val metaId: String,
    val title: String,
    val poster: String?,
    val season: Int = 0,
    val episode: Int = 0,
    val episodeTitle: String? = null,
    val seriesName: String? = null,
    val streamUrl: String,
    val streamLabel: String? = null,
    val sourceName: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String? = null,
    val subtitles: List<Subtitle> = emptyList(),
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
) {
    /** One entry per playable item (an episode's video id is unique). */
    val key: String get() = "$type|$videoId"

    val progressFraction: Float
        get() =
            if (durationMs > 0) {
                (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }

    /** Rebuilds the request the player needs to resume this entry. */
    fun toPlaybackRequest(): PlaybackRequest =
        PlaybackRequest(
            streamUrl = streamUrl,
            title = title,
            poster = poster,
            videoId = videoId,
            subtitles = subtitles,
            season = season,
            episode = episode,
            isMovie = type == "movie",
            type = type,
            streamLabel = streamLabel,
            sourceName = sourceName,
            metaId = metaId,
            seriesName = seriesName,
            episodeTitle = episodeTitle,
            headers = headers,
            mimeType = mimeType,
        )
}

/** Serializable mirror of [Subtitle] for persistence. */
@Serializable
private data class StoredSubtitle(
    val url: String,
    val lang: String,
)

/** Serializable mirror of [ContinueWatchingEntry] for persistence. */
@Serializable
private data class StoredEntry(
    val type: String,
    val videoId: String,
    val metaId: String,
    val title: String,
    val poster: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    val episodeTitle: String? = null,
    val seriesName: String? = null,
    val streamUrl: String,
    val streamLabel: String? = null,
    val sourceName: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val mimeType: String? = null,
    val subtitles: List<StoredSubtitle> = emptyList(),
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
) {
    fun toEntry(): ContinueWatchingEntry =
        ContinueWatchingEntry(
            type = type,
            videoId = videoId,
            metaId = metaId,
            title = title,
            poster = poster,
            season = season,
            episode = episode,
            episodeTitle = episodeTitle,
            seriesName = seriesName,
            streamUrl = streamUrl,
            streamLabel = streamLabel,
            sourceName = sourceName,
            headers = headers,
            mimeType = mimeType,
            subtitles = subtitles.map { Subtitle(url = it.url, lang = it.lang) },
            positionMs = positionMs,
            durationMs = durationMs,
            updatedAt = updatedAt,
        )

    companion object {
        fun from(entry: ContinueWatchingEntry): StoredEntry =
            StoredEntry(
                type = entry.type,
                videoId = entry.videoId,
                metaId = entry.metaId,
                title = entry.title,
                poster = entry.poster,
                season = entry.season,
                episode = entry.episode,
                episodeTitle = entry.episodeTitle,
                seriesName = entry.seriesName,
                streamUrl = entry.streamUrl,
                streamLabel = entry.streamLabel,
                sourceName = entry.sourceName,
                headers = entry.headers,
                mimeType = entry.mimeType,
                subtitles = entry.subtitles.map { StoredSubtitle(url = it.url, lang = it.lang) },
                positionMs = entry.positionMs,
                durationMs = entry.durationMs,
                updatedAt = entry.updatedAt,
            )
    }
}

/**
 * Local continue-watching store for the Plavio flow, persisted as JSON in
 * a Preferences DataStore (the same storage style as [AddonStore]).
 *
 * The save rules mirror the phone app's `savePlayback`: a position under
 * 10 seconds is not worth listing, and when less than 30 seconds remain
 * the title counts as finished and its entry is dropped.
 */
@Singleton
class PlavioProgressStore
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioProgressDataStore
        private val json = Json { ignoreUnknownKeys = true }
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        /** In-progress titles, most recently watched first. */
        val entries: StateFlow<List<ContinueWatchingEntry>> =
            dataStore.data
                .map { prefs -> decode(prefs[KEY_ENTRIES]) }
                .stateIn(scope, SharingStarted.Eagerly, emptyList())

        /**
         * Records playback progress for [request]. Applies the phone's
         * rules: ignores barely-started playback, and a title with less
         * than [FINISH_REMAINING_MS] left is finished — its entry (if
         * any) is removed instead of updated.
         */
        suspend fun record(
            request: PlaybackRequest,
            positionMs: Long,
            durationMs: Long,
        ) {
            // Trailers and live TV never get a resume entry (same as the phone).
            if (request.isTrailer || request.isLive) return
            val key = "${request.type}|${request.videoId}"
            if (durationMs > 0 && durationMs - positionMs < FINISH_REMAINING_MS) {
                removeByKey(key)
                return
            }
            if (positionMs < MIN_POSITION_MS) return
            val entry =
                ContinueWatchingEntry(
                    type = request.type,
                    videoId = request.videoId,
                    metaId = request.metaId,
                    title = request.title,
                    poster = request.poster,
                    season = request.season,
                    episode = request.episode,
                    episodeTitle = request.episodeTitle,
                    seriesName = request.seriesName,
                    streamUrl = request.streamUrl,
                    streamLabel = request.streamLabel,
                    sourceName = request.sourceName,
                    headers = request.headers,
                    mimeType = request.mimeType,
                    subtitles = request.subtitles,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    updatedAt = System.currentTimeMillis(),
                )
            mutate { list ->
                (list.filterNot { it.key == key } + entry)
                    .sortedByDescending { it.updatedAt }
                    .take(MAX_ENTRIES)
            }
        }

        suspend fun remove(
            type: String,
            videoId: String,
        ) {
            removeByKey("$type|$videoId")
        }

        /** Replaces all entries from a restored backup (the phone's import does the same). */
        suspend fun replaceAll(entries: List<ContinueWatchingEntry>) {
            val capped =
                entries
                    .sortedByDescending { it.updatedAt }
                    .distinctBy { it.key }
                    .take(MAX_ENTRIES)
            dataStore.edit { prefs ->
                prefs[KEY_ENTRIES] =
                    json.encodeToString(
                        kotlinx.serialization.builtins.ListSerializer(StoredEntry.serializer()),
                        capped.map { StoredEntry.from(it) },
                    )
            }
        }

        private suspend fun removeByKey(key: String) {
            mutate { list -> list.filterNot { it.key == key } }
        }

        private suspend fun mutate(transform: (List<ContinueWatchingEntry>) -> List<ContinueWatchingEntry>) {
            dataStore.edit { prefs ->
                val updated = transform(decode(prefs[KEY_ENTRIES]))
                prefs[KEY_ENTRIES] =
                    json.encodeToString(
                        kotlinx.serialization.builtins.ListSerializer(StoredEntry.serializer()),
                        updated.map { StoredEntry.from(it) },
                    )
            }
        }

        private fun decode(raw: String?): List<ContinueWatchingEntry> {
            if (raw.isNullOrBlank()) return emptyList()
            return runCatching {
                json
                    .decodeFromString(
                        kotlinx.serialization.builtins.ListSerializer(StoredEntry.serializer()),
                        raw,
                    ).map { it.toEntry() }
                    // The Home row keys by entry.key (type|videoId): a
                    // persisted list (or an old backup) holding the same
                    // title twice is a duplicate-key crash — keep the
                    // most recent copy of each.
                    .distinctBy { it.key }
                    .sortedByDescending { it.updatedAt }
            }.getOrElse {
                Timber.w(it, "Failed to decode continue watching entries, starting fresh")
                emptyList()
            }
        }

        companion object {
            /** Positions below this are not worth a resume entry. */
            const val MIN_POSITION_MS = 10_000L

            /** Less than this remaining counts as finished. */
            const val FINISH_REMAINING_MS = 30_000L

            const val MAX_ENTRIES = 20

            private val KEY_ENTRIES = stringPreferencesKey("continue_watching")
        }
    }
