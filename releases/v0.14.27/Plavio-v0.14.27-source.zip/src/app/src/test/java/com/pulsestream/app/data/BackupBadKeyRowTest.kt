package com.pulsestream.app.data

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.pulsestream.app.data.db.AppDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * v0.14.49 restore fix: a backup row whose identity `key` is
 * unusable (missing, blank, wrong-typed, over-long) is SKIPPED —
 * it must not abort the whole restore (the owner's cloud backup
 * died exactly this way, 2026-11-15: one bad row, "Invalid 'key'.",
 * nothing imported). Every other field keeps the strict
 * validation: a bad non-key field still fails the import.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class BackupBadKeyRowTest {
    private fun fixture(test: suspend (AppDatabase, StreamRepository) -> Unit) = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries().build()
        val repo = StreamRepository(db, StremioApi(), SettingsStore(context))
        try { test(db, repo) } finally { db.close() }
    }

    private val badKeyBackup: String by lazy {
        val longKey = "k".repeat(1025)
        """
        {"format":"plavio-backup","version":2,"settings":{},
         "watchlist":[
           {"key":"good-watch","addonId":"addon","type":"movie","metaId":"tt1","name":"Good"},
           {"key":"","addonId":"addon","type":"movie","metaId":"tt2","name":"Blank key"},
           {"key":42,"addonId":"addon","type":"movie","metaId":"tt3","name":"Numeric key"}
         ],
         "favorites":[
           {"key":"good-fav","addonId":"addon","type":"movie","metaId":"tt1","name":"Fav"},
           {"addonId":"addon","type":"movie","metaId":"tt4","name":"Missing key"}
         ],
         "plavioStatuses":[
           {"key":"good-status","status":"watching","addonId":"addon","type":"movie","metaId":"tt1","name":"S"},
           {"key":"$longKey","status":"watching","addonId":"addon","type":"movie","metaId":"tt5","name":"Too long"}
         ],
         "playback":[
           {"key":"good-play","title":"P","videoId":"tt1","streamUrl":"https://example.com/v.mp4","positionMs":5000,"durationMs":9000},
           {"key":"  ","title":"Blank","videoId":"tt6","streamUrl":"https://example.com/x.mp4"}
         ],
         "customLists":[],"customListItems":[]}
        """.trimIndent()
    }

    @Test
    fun `rows with an invalid key are skipped and the good rows import`() = fixture { db, repo ->
        val result = repo.importBackupJson(badKeyBackup)
        assertTrue("import must succeed despite bad-key rows: $result", result.isSuccess)
        assertEquals(listOf("good-watch"), db.watchlistDao().getAll().map { it.key })
        assertEquals(listOf("good-fav"), db.favoriteDao().getAll().map { it.key })
        assertEquals(listOf("good-status"), db.titleStatusDao().getAll().map { it.key })
        assertEquals(listOf("good-play"), db.playbackDao().getAll().map { it.key })
    }

    @Test
    fun `preview counts only the surviving rows`() = fixture { _, repo ->
        val preview = repo.previewBackupJson(badKeyBackup).getOrThrow()
        assertEquals(1, preview.watchlistCount)
        assertEquals(1, preview.playbackCount)
    }

    @Test
    fun `a bad non-key field still fails the whole import`() = fixture { _, repo ->
        val json = """
            {"format":"plavio-backup","version":2,"settings":{},
             "watchlist":[{"key":"fine","poster":"not-a-url"}],
             "customLists":[],"customListItems":[]}
        """.trimIndent()
        assertTrue(repo.importBackupJson(json).isFailure)
    }
}
