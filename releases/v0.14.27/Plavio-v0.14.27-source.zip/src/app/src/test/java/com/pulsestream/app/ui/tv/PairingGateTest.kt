package com.pulsestream.app.ui.tv

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * S-M11 (v0.14.48): the TV pairing gate — correct code passes,
 * wrong codes consume attempts, the session locks after the
 * attempt budget, and the code expires.
 */
class PairingGateTest {

    @Test
    fun correctCodePassesAndWrongCodeIsRefused() {
        val gate = PairingGate()
        assertNull(gate.check("123456", "123456"))
        assertEquals("Wrong pairing code.", gate.check("000000", "123456"))
        // A wrong attempt does not burn the session for the right code.
        assertNull(gate.check("123456", "123456"))
    }

    @Test
    fun sessionLocksAfterTheAttemptBudget() {
        val gate = PairingGate(maxFailures = 3)
        repeat(3) { gate.check("000000", "123456") }
        val refusal = gate.check("123456", "123456")
        assertTrue(refusal?.contains("locked") == true)
    }

    @Test
    fun codeExpiresAfterItsTtl() {
        var now = 1_000_000L
        val gate = PairingGate(ttlMs = 60_000L, nowMs = { now })
        assertNull(gate.check("123456", "123456"))
        now += 61_000L
        val refusal = gate.check("123456", "123456")
        assertTrue(refusal?.contains("expired") == true)
    }
}
