package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.CatalogRow
import org.junit.Assert.assertSame
import org.junit.Test

/**
 * v0.14.27 (owner's refresh-flash report): the Home hero may only
 * re-pick when a SETTLED row-set lands. A catalog refresh emits
 * progressive waves (refreshing = true); the hero must keep its
 * current set through every wave and swap exactly once at the
 * settle. A wholesale replacement (no shared catalog identity —
 * e.g. a meta-provider switch) is not a wave and is taken at once.
 */
class HeroSourceRowsTest {

    private fun row(addonId: String, catalogId: String, type: String = "movie") =
        CatalogRow(
            addonId = addonId,
            addonName = addonId,
            baseUrl = "https://example.invalid",
            catalogName = catalogId,
            type = type,
            catalogId = catalogId,
            items = emptyList()
        )

    private val settled = listOf(row("meta", "trending"), row("meta", "popular"))
    private val wave = listOf(row("meta", "trending"), row("other", "fresh"))
    private val settledNext = listOf(row("meta", "trending"), row("meta", "new"))
    private val replacement = listOf(row("othermeta", "top"), row("othermeta", "hot"))

    @Test
    fun `first set is taken even while refreshing`() {
        assertSame(wave, heroSourceRows(null, wave, refreshing = true))
    }

    @Test
    fun `intermediate waves never move the hero`() {
        assertSame(settled, heroSourceRows(settled, wave, refreshing = true))
    }

    @Test
    fun `the settled set is taken exactly once`() {
        assertSame(settledNext, heroSourceRows(settled, settledNext, refreshing = false))
    }

    @Test
    fun `a wholesale replacement is taken even mid-refresh`() {
        assertSame(replacement, heroSourceRows(settled, replacement, refreshing = true))
    }

    @Test
    fun `a settled first set is taken`() {
        assertSame(settled, heroSourceRows(null, settled, refreshing = false))
    }
}
