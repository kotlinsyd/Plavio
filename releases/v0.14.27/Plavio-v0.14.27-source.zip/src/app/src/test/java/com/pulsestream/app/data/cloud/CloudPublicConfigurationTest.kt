package com.pulsestream.app.data.cloud

import com.pulsestream.app.BuildConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest
import java.util.Base64

/**
 * Pins the app's public Supabase configuration (S-M3 replacement,
 * v0.14.48). The original test pointed at a CloudManager class
 * that no longer exists and silently stopped running; this one
 * pins the values the app actually ships — [BuildConfig] fields
 * fed by the build-time properties — so a swapped endpoint or a
 * privileged/wrong-project key fails the suite loudly.
 *
 * The key itself is never asserted literally: its JWT claims
 * (role + project ref) and a SHA-256 fingerprint pin its identity
 * without embedding the credential in the test.
 */
class CloudPublicConfigurationTest {

    @Test
    fun endpointIsTheIntendedHttpsProjectWithoutCredentialsOrQuery() {
        val url = BuildConfig.PLAVIO_SUPABASE_URL
        assertEquals("https://vpngqutsjxrdgaihogor.supabase.co", url)
        assertFalse("endpoint must not embed credentials", url.contains("@"))
        assertFalse("endpoint must not carry a query", url.contains("?"))
    }

    @Test
    fun embeddedKeyIsAnonForThisProject() {
        val parts = BuildConfig.PLAVIO_SUPABASE_ANON_KEY.split(".")
        assertEquals("anon key must be a JWT", 3, parts.size)
        val segment = parts[1]
        val padded = segment + "=".repeat((4 - segment.length % 4) % 4)
        val payload = String(Base64.getUrlDecoder().decode(padded), Charsets.UTF_8)
        assertTrue("key role must be anon", payload.contains("\"role\":\"anon\""))
        assertTrue(
            "key must belong to the intended project",
            payload.contains("\"ref\":\"vpngqutsjxrdgaihogor\"")
        )
    }

    @Test
    fun embeddedKeyMatchesThePinnedVerifiedFingerprint() {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(BuildConfig.PLAVIO_SUPABASE_ANON_KEY.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        assertEquals(EXPECTED_KEY_SHA256, hex)
    }

    private companion object {
        /** SHA-256 of the read-only verified legacy anon key. */
        const val EXPECTED_KEY_SHA256 =
            "47b16100ee01249d12a06c3b10794991a3797171a9c2a99b2b7f979ab1038491"
    }
}
