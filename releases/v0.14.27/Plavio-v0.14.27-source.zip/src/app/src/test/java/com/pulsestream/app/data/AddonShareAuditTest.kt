package com.pulsestream.app.data

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * S-M10 (v0.14.48): the share audit must catch credential tokens
 * riding in the URL PATH — above all the house permanent-link
 * shape /u/<code>/… — without flagging ordinary addon URLs.
 */
class AddonShareAuditTest {

    private fun reasonsFor(url: String): List<String> =
        AddonShare.audit(listOf(SharedAddon("Test", url))).risks
            .flatMap { it.reasons }

    @Test
    fun housePermanentLinkShapeIsFlagged() {
        val url = "https://hd.plavio.site/u/Ab3dEf6hJk9mN2pQ4rStUv/manifest.json"
        assertTrue(reasonsFor(url).contains("personal link code in URL path"))
    }

    @Test
    fun ordinaryAddonUrlsStaySafe() {
        assertTrue(reasonsFor("https://example.com/addon/manifest.json").isEmpty())
        assertTrue(reasonsFor("https://torrentio.strem.fun/manifest.json").isEmpty())
        // A short /u/ segment is a path name, not a code.
        assertTrue(reasonsFor("https://example.com/u/abc/manifest.json").isEmpty())
        // A "u" segment NOT followed by a long token is fine.
        assertTrue(reasonsFor("https://example.com/u/manifest.json").isEmpty())
    }

    @Test
    fun queryAndUserInfoChecksStillFire() {
        assertTrue(reasonsFor("https://example.com/manifest.json?apiKey=secretvalue").isNotEmpty())
        assertTrue(reasonsFor("https://user:pass@example.com/manifest.json").isNotEmpty())
        assertTrue(
            AddonShare.audit(
                listOf(SharedAddon("Ok", "https://example.com/manifest.json"))
            ).isSafe
        )
    }
}
