package com.pulsestream.app.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * v0.14.49 (audit M9): the Subtitles → Font pick reaches the MPV
 * engine as a `sub-font` name. "System" (0) and unknown indices
 * leave libmpv's default untouched — the same rule the Exo path
 * applies with its null typeface.
 */
class MpvSubFontNameTest {
    @Test
    fun `system and unknown indices leave the default`() {
        assertNull(mpvSubFontName(0))
        assertNull(mpvSubFontName(99))
        assertNull(mpvSubFontName(-1))
    }

    @Test
    fun `named families map to the fontconfig generics`() {
        assertEquals("sans-serif", mpvSubFontName(1))
        assertEquals("serif", mpvSubFontName(2))
        assertEquals("monospace", mpvSubFontName(3))
    }
}
