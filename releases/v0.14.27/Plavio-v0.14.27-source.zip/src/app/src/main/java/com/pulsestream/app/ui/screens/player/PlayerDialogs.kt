package com.pulsestream.app.ui.screens.player

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/** Resume-from-saved-position prompt. Callbacks cover dismiss/confirm/start-over. */
@Composable
internal fun ResumePromptDialog(
    savedMs: Long,
    title: String,
    onResume: () -> Unit,
    onStartOver: () -> Unit
) {
    AlertDialog(
        onDismissRequest = {
            // Tapping outside keeps their place and resumes.
            onResume()
        },
        containerColor = Color(0xFF14141F),
        title = {
            Text(
                "Resume playback",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                "Resume \"${title}\" from ${formatMs(savedMs)}?",
                color = TextSecondary
            )
        },
        confirmButton = {
            TextButton(onClick = onResume) {
                Text("Resume", color = LocalPalette.current.accent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onStartOver) {
                Text("Start over", color = TextSecondary)
            }
        }
    )
}

/** Speed pill + dropdown menu for the bottom toolbar. */
@Composable
internal fun SpeedMenuButton(
    speed: Float,
    menuOpen: Boolean,
    onOpenMenu: () -> Unit,
    onDismissMenu: () -> Unit,
    onSpeedSelected: (Float) -> Unit
) {
    Box {
        PillBarButton(
            icon = Icons.Filled.Speed,
            label = speedLabel(speed),
            onClick = onOpenMenu
        )
        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = onDismissMenu,
            // Dock pure frost (v0.14.42): the capsule's popup menus
            // wear the same tint + dim silver outline as the capsule
            // itself (see PlayerComponents.dockFrostTint). v0.14.45:
            // the radius joins the ONE shared popup theme (22dp,
            // PlayerComponents.PlayerPopupShape); the menu already
            // opens straight above this button, as the owner's
            // placement rules require. v0.14.46: the container wore
            // the thick popup frost (playerPopupFrostTint) like every
            // player popup. v0.14.47: that token is now SOLID —
            // fully opaque, no glass — per the owner's order.
            shape = PlayerPopupShape,
            containerColor = playerPopupFrostTint(),
            border = BorderStroke(1.dp, DockFrostOutline)
        ) {
            SPEEDS.forEach { s ->
                DropdownMenuItem(
                    text = { Text(speedLabel(s)) },
                    onClick = { onSpeedSelected(s) }
                )
            }
        }
    }
}

/**
 * Sleep timer pill + menu for the bottom toolbar (v0.14.13,
 * item 9): Off / 15 / 30 / 45 / 60 minutes / End of episode. The
 * pill label shows the remaining time while a timed sleep runs.
 */
@Composable
internal fun SleepTimerButton(
    label: String,
    active: Boolean,
    menuOpen: Boolean,
    onOpenMenu: () -> Unit,
    onDismissMenu: () -> Unit,
    onSelectMinutes: (Int) -> Unit,
    onSelectEndOfEpisode: () -> Unit,
    onOff: () -> Unit
) {
    Box {
        PillBarButton(
            icon = Icons.Filled.Bedtime,
            label = label,
            onClick = onOpenMenu
        )
        DropdownMenu(
            expanded = menuOpen,
            onDismissRequest = onDismissMenu,
            // Dock pure frost (v0.14.42): same tint + outline as the
            // capsule and the speed menu above. v0.14.45: radius on
            // the shared popup theme (22dp, PlayerPopupShape).
            // v0.14.46: thick popup frost, same as the speed menu.
            // v0.14.47: the shared token is SOLID (fully opaque).
            shape = PlayerPopupShape,
            containerColor = playerPopupFrostTint(),
            border = BorderStroke(1.dp, DockFrostOutline)
        ) {
            DropdownMenuItem(
                text = { Text("Off") },
                onClick = onOff
            )
            listOf(15, 30, 45, 60).forEach { minutes ->
                DropdownMenuItem(
                    text = { Text("$minutes minutes") },
                    onClick = { onSelectMinutes(minutes) }
                )
            }
            DropdownMenuItem(
                text = { Text("End of episode") },
                onClick = onSelectEndOfEpisode
            )
            if (active) {
                DropdownMenuItem(
                    text = { Text("Cancel timer", color = TextSecondary) },
                    onClick = onOff
                )
            }
        }
    }
}
