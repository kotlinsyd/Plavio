package com.pulsestream.app.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Resilient hand-written parser for the Stremio addon protocol.
 * Addons in the wild vary (resources as strings or objects, missing fields),
 * so we parse JsonElement defensively with defaults instead of @Serializable.
 */
object StremioParser {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // Safe string read: a field that arrives as an object/array (addons in
    // the wild do this) defaults to null instead of jsonPrimitive throwing
    // IllegalArgumentException and aborting the entire parse.
    private fun JsonObject.str(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }

    private fun JsonObject.strList(key: String): List<String> =
        (this[key] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull } ?: emptyList()

    /**
     * Reads behaviorHints.proxyHeaders.request — extra HTTP headers an addon
     * requires on the stream URL (used by some debrid-backed addons).
     * Returns an empty map when absent.
    */
    private fun parseProxyHeaders(s: JsonObject, embeddedHeaders: Map<String, String>): Map<String, String> {
        val hints = s["behaviorHints"] as? JsonObject
        val req = (hints?.get("proxyHeaders") as? JsonObject)?.get("request") as? JsonObject
        val proxyHeaders = parseHeaderObject(req)
        // Explicit Stremio header objects retain their existing precedence over
        // proxy headers; both override URL-embedded IPTV headers.
        val merged = linkedMapOf<String, Pair<String, String>>()
        listOf(embeddedHeaders, proxyHeaders, parseHeaderObject(s["headers"] as? JsonObject)).forEach { source ->
            source.forEach { (name, value) -> merged[name.lowercase()] = name to value }
        }
        return merged.values.associate { it }
    }

    /**
     * IPTV playlists/addons often encode request headers as
     * `https://host/live.m3u8|User-Agent=...&Referer=...`. Treat the suffix as
     * headers only when every pair is well-formed; otherwise preserve the URL
     * unchanged rather than guessing at an arbitrary pipe in a URL.
     */
    private fun splitEmbeddedHeaders(rawUrl: String?): Pair<String?, Map<String, String>> {
        if (rawUrl == null) return null to emptyMap()
        val separator = rawUrl.lastIndexOf('|')
        if (separator < 0 || separator == rawUrl.lastIndex) return rawUrl to emptyMap()
        val pairs = rawUrl.substring(separator + 1).split('&')
        val headers = linkedMapOf<String, String>()
        for (pair in pairs) {
            val equals = pair.indexOf('=')
            if (equals <= 0) return rawUrl to emptyMap()
            val name = decodeHeaderComponent(pair.substring(0, equals)) ?: return rawUrl to emptyMap()
            val value = decodeHeaderComponent(pair.substring(equals + 1)) ?: return rawUrl to emptyMap()
            if (!name.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+")) ||
                value.isBlank() || value.any { it == '\r' || it == '\n' || it == '\u0000' }) {
                return rawUrl to emptyMap()
            }
            headers[name] = value
        }
        return rawUrl.substring(0, separator) to headers
    }

    private fun decodeHeaderComponent(value: String): String? =
        runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrNull()

    private fun parseHeaderObject(obj: JsonObject?): Map<String, String> =
        obj?.entries?.mapNotNull { (k, v) ->
            val value = (v as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
            if (value != null) k to value else null
        }?.toMap() ?: emptyMap()

    private fun resourceNames(el: JsonElement): List<String> = when (el) {
        is JsonPrimitive -> listOfNotNull(el.contentOrNull)
        is JsonObject -> listOfNotNull(el.str("name"))
        else -> emptyList()
    }

    fun parseManifest(text: String): AddonManifest {
        val obj = json.parseToJsonElement(text).jsonObject
        val id = obj.str("id") ?: throw IllegalArgumentException("Manifest is missing 'id'")
        val name = obj.str("name") ?: id
        val resources = (obj["resources"] as? JsonArray)
            ?.flatMap { resourceNames(it) } ?: emptyList()
        val catalogs = (obj["catalogs"] as? JsonArray)?.mapNotNull { el ->
            val c = el as? JsonObject ?: return@mapNotNull null
            val type = c.str("type") ?: return@mapNotNull null
            val cid = c.str("id") ?: return@mapNotNull null
            // "extra" declares supported query extras. Stremio shapes vary:
            // strings ("search"), {name:"search"} objects, or {name, options}.
            val extra = (c["extra"] as? JsonArray)?.mapNotNull { x ->
                when (x) {
                    is JsonPrimitive -> x.contentOrNull
                    is JsonObject -> x.str("name")
                    else -> null
                }
            } ?: emptyList()
            // Genre options ride on the genre extra object when the
            // manifest declares them ({name:"genre", options:[...]}).
            val genreOptions = (c["extra"] as? JsonArray)?.firstNotNullOfOrNull { x ->
                val o = x as? JsonObject ?: return@firstNotNullOfOrNull null
                if (o.str("name")?.equals("genre", ignoreCase = true) != true) {
                    return@firstNotNullOfOrNull null
                }
                (o["options"] as? JsonArray)?.mapNotNull { opt ->
                    (opt as? JsonPrimitive)?.contentOrNull
                }
            } ?: emptyList()
            CatalogRef(
                type = type, id = cid, name = c.str("name") ?: cid,
                extra = extra, genreOptions = genreOptions
            )
        } ?: emptyList()
        return AddonManifest(
            id = id,
            name = name,
            version = obj.str("version") ?: "",
            description = obj.str("description") ?: "",
            logo = obj.str("logo"),
            types = obj.strList("types"),
            catalogs = catalogs,
            resources = resources,
            configurable = ((obj["behaviorHints"] as? JsonObject)
                ?.get("configurable") as? JsonPrimitive)?.booleanOrNull ?: false
        )
    }

    private fun parseMetaPreview(obj: JsonObject, fallbackType: String): MetaPreview? {
        val id = obj.str("id") ?: return null
        return MetaPreview(
            id = id,
            type = obj.str("type") ?: fallbackType,
            name = obj.str("name") ?: id,
            poster = obj.str("poster"),
            background = obj.str("background"),
            logo = obj.str("logo"),
            description = obj.str("description"),
            releaseInfo = obj.str("releaseInfo"),
            imdbRating = obj.str("imdbRating"),
            genres = obj.strList("genres"),
            popularity = (obj["popularity"] as? JsonPrimitive)?.contentOrNull
                ?.toDoubleOrNull() ?: 0.0,
            originalLanguage = obj.str("originalLanguage") ?: obj.str("original_language")
        )
    }

    fun parseCatalog(text: String, fallbackType: String): List<MetaPreview> {
        val obj = json.parseToJsonElement(text).jsonObject
        return (obj["metas"] as? JsonArray)?.mapNotNull { el ->
            (el as? JsonObject)?.let { parseMetaPreview(it, fallbackType) }
        } ?: emptyList()
    }

    fun parseMeta(text: String, fallbackType: String): MetaDetail? {
        val obj = json.parseToJsonElement(text).jsonObject
        val meta = obj["meta"] as? JsonObject ?: return null
        val preview = parseMetaPreview(meta, fallbackType) ?: return null
        val videos = (meta["videos"] as? JsonArray)?.mapNotNull { el ->
            val v = el as? JsonObject ?: return@mapNotNull null
            val vid = v.str("id") ?: return@mapNotNull null
            Video(
                id = vid,
                title = v.str("title") ?: v.str("name") ?: vid,
                season = (v["season"] as? JsonPrimitive)?.intOrNull ?: 0,
                episode = (v["episode"] as? JsonPrimitive)?.intOrNull ?: 0,
                overview = v.str("overview") ?: v.str("description"),
                thumbnail = v.str("thumbnail"),
                released = v.str("released")
            )
        } ?: emptyList()
        // Standard `app_extras` block (v0.14.45): the spec-shaped side
        // block rich meta addons carry beside the plain top-level
        // fields — PlavioMeta serves it since its standard-shape flip,
        // Nuvio's catalog addon always did. Parsed once here; cast,
        // certification, TMDB rating and season posters below all
        // fall back to it only when the classic fields are absent, so
        // every other addon's answers parse exactly as before.
        val appExtras = meta["app_extras"] as? JsonObject
        return MetaDetail(
            id = preview.id, type = preview.type, name = preview.name,
            poster = preview.poster, background = preview.background, logo = preview.logo,
            description = preview.description, releaseInfo = preview.releaseInfo,
            imdbRating = preview.imdbRating, genres = preview.genres, videos = videos,
            trailerStreams = parseTrailers(meta), cast = parseCast(meta),
            runtime = meta.str("runtime"),
            imdbId = meta.str("imdb_id") ?: meta.str("imdbId")
                ?: preview.id.takeIf { it.startsWith("tt") },
            defaultVideoId = (meta["behaviorHints"] as? JsonObject)?.str("defaultVideoId"),
            status = meta.str("status"),
            certification = meta.str("certification") ?: meta.str("contentRating")
                ?: meta.str("mpaaRating") ?: appExtras?.str("certification")
                ?: appExtras?.str("certificationLocal"),
            tmdbRating = parseAppExtrasTmdbRating(appExtras),
            seasonPosters = parseAppExtrasSeasonPosters(appExtras),
            country = meta.str("country") ?: meta.str("originCountry"),
            network = meta.str("network") ?: meta.strList("networks").firstOrNull(),
            director = meta.str("director"),
            writer = meta.str("writer"),
            mdblistRating = meta.str("mdblistRating"),
            traktRating = (meta["mdblistRatings"] as? JsonObject)?.str("trakt"),
            rtRating = (meta["mdblistRatings"] as? JsonObject)?.str("tomatoes"),
            rtAudienceRating = (meta["mdblistRatings"] as? JsonObject)?.str("tomatoesaudience"),
            metacriticRating = (meta["mdblistRatings"] as? JsonObject)?.str("metacritic"),
            letterboxdRating = (meta["mdblistRatings"] as? JsonObject)?.str("letterboxd"),
            collection = parseMetaCollection(meta)
        )
    }

    /**
     * Franchise collection embedded in the meta (PlavioMeta v2.4.9,
     * v0.14.40 item 9): `{id, name, parts: [{id, imdb_id, title,
     * release_date, poster_path}]}` with parts already in release
     * order. Defensive throughout — a malformed field yields null
     * (no row), never a broken meta; fewer than two usable parts
     * also yields null, matching the server's own rule. A part's
     * imdb_id / poster_path may legitimately be null.
     */
    private fun parseMetaCollection(meta: JsonObject): MetaCollection? {
        val col = meta["collection"] as? JsonObject ?: return null
        val id = (col["id"] as? JsonPrimitive)?.intOrNull ?: return null
        val name = col.str("name")?.takeIf { it.isNotBlank() } ?: return null
        val parts = (col["parts"] as? JsonArray)?.mapNotNull { el ->
            val p = el as? JsonObject ?: return@mapNotNull null
            val tmdbId = (p["id"] as? JsonPrimitive)?.intOrNull ?: return@mapNotNull null
            val title = p.str("title")?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            MetaCollectionPart(
                tmdbId = tmdbId,
                imdbId = p.str("imdb_id")?.takeIf { it.isNotBlank() },
                title = title,
                releaseDate = p.str("release_date")?.takeIf { it.isNotBlank() },
                posterPath = p.str("poster_path")?.takeIf { it.isNotBlank() }
            )
        } ?: return null
        if (parts.size < 2) return null
        return MetaCollection(id, name, parts)
    }

    /**
     * Ratings from the universal /ratings endpoint (v0.14.20): the
     * same MDBList data PMeta embeds in its own metas, served for
     * titles whose metadata came from any other addon. All values are
     * display-ready text — IMDb on its native scale, the rest 0–100.
     */
    data class EndpointRatings(
        val imdbRating: String?,
        val mdblistRating: String?,
        val traktRating: String?,
        val rtRating: String?,
        val rtAudienceRating: String?,
        val metacriticRating: String?,
        val letterboxdRating: String?
    )

    /**
     * Parses the /ratings endpoint body ({imdbRating: number,
     * mdblistRating: string, mdblistRatings: {source: number}}) with
     * the same field helpers [parseMeta] uses for the in-meta fields,
     * so both paths land in identical MetaDetail rating fields.
     * Null when the body carries no usable rating at all.
     */
    fun parseRatingsEndpoint(text: String): EndpointRatings? {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return null
        val per = obj["mdblistRatings"] as? JsonObject
        val imdb = (obj["imdbRating"] as? JsonPrimitive)?.contentOrNull
            ?.toDoubleOrNull()?.takeIf { it > 0 }?.let { "%.1f".format(it) }
        val out = EndpointRatings(
            imdbRating = imdb,
            mdblistRating = obj.str("mdblistRating"),
            traktRating = per?.str("trakt"),
            rtRating = per?.str("tomatoes"),
            rtAudienceRating = per?.str("tomatoesaudience"),
            metacriticRating = per?.str("metacritic"),
            letterboxdRating = per?.str("letterboxd")
        )
        val any = listOf(
            out.imdbRating, out.mdblistRating, out.traktRating, out.rtRating,
            out.rtAudienceRating, out.metacriticRating, out.letterboxdRating
        ).any { !it.isNullOrBlank() }
        return out.takeIf { any }
    }

    /**
     * Cast list. Three serving shapes are accepted, richest first
     * (v0.14.45):
     *  1. The standard `app_extras.cast` block — objects
     *     [{name, character, photo}] with NO person id (PlavioMeta's
     *     standard shape since its flip; Nuvio's catalog addon).
     *  2. Legacy top-level objects [{id,name,photo,character?}]
     *     (PlavioMeta before the flip).
     *  3. Top-level plain name strings (keyless/Cinemeta mode).
     * The list WITH photos wins when only one shape carries them, so
     * no addon loses cast photos to the preference order; otherwise
     * app_extras wins ties as the standard source. A "character"
     * field is read whenever an addon sends one — never required.
     *
     * Person ids: app_extras entries carry none, so an id-less entry
     * is matched by name against the meta's own actor `links`
     * (PlavioMeta serves {category:"actor", personId} links for the
     * same cast) and inherits that TMDB person id — actor pages keep
     * opening the rich filmography exactly as with the legacy
     * object cast. Entries that stay id=0 use the existing
     * name-search fallback page, like every names-only cast.
     */
    private fun parseCast(meta: JsonObject): List<CastMember> {
        val personIds = parseActorLinkIds(meta)
        val fromExtras = parseCastEntries(meta["app_extras"] as? JsonObject, personIds)
        val fromTopLevel = parseCastEntries(meta, personIds)
        return when {
            fromExtras.any { !it.photo.isNullOrBlank() } -> fromExtras
            fromTopLevel.any { !it.photo.isNullOrBlank() } -> fromTopLevel
            fromExtras.isNotEmpty() -> fromExtras
            else -> fromTopLevel
        }
    }

    /** One `cast` array (of [holder]) in either entry shape; see [parseCast]. */
    private fun parseCastEntries(
        holder: JsonObject?,
        personIds: Map<String, Int>
    ): List<CastMember> {
        val arr = holder?.get("cast") as? JsonArray ?: return emptyList()
        return arr.mapNotNull { el ->
            when (el) {
                is JsonObject -> {
                    val name = el.str("name") ?: return@mapNotNull null
                    val rawId = (el["id"] as? JsonPrimitive)?.intOrNull ?: 0
                    CastMember(
                        id = if (rawId > 0) rawId
                            else personIds[name.trim().lowercase()] ?: 0,
                        name = name,
                        photo = el.str("photo"),
                        character = el.str("character")
                    )
                }
                is JsonPrimitive -> el.contentOrNull?.takeIf { it.isNotBlank() }?.let {
                    CastMember(
                        id = personIds[it.trim().lowercase()] ?: 0,
                        name = it
                    )
                }
                else -> null
            }
        }.take(12)
    }

    /**
     * TMDB person ids from the meta's actor `links`
     * ([{name, category:"actor", personId, url}]), keyed by lowercase
     * name; the /person/<id> in the link URL is the fallback when no
     * explicit personId rides along. Addons that serve no actor
     * links (most) simply yield an empty map and nothing changes.
     */
    private fun parseActorLinkIds(meta: JsonObject): Map<String, Int> {
        val arr = meta["links"] as? JsonArray ?: return emptyMap()
        val out = LinkedHashMap<String, Int>()
        for (el in arr) {
            val o = el as? JsonObject ?: continue
            if (o.str("category")?.equals("actor", ignoreCase = true) != true) continue
            val name = o.str("name")?.trim()?.lowercase()
                ?.takeIf { it.isNotEmpty() } ?: continue
            val pid = (o["personId"] as? JsonPrimitive)?.intOrNull
                ?: o.str("url")?.let { url ->
                    Regex("""/person/(\d+)""").find(url)
                        ?.groupValues?.get(1)?.toIntOrNull()
                }
                ?: continue
            if (pid > 0) out.putIfAbsent(name, pid)
        }
        return out
    }

    /**
     * TMDB score out of `app_extras.ratings`
     * ({tmdb:{rating, votes}, imdb:{...}}), display text as served.
     * Only the TMDB value is read — the IMDb value already arrives
     * via the standard top-level `imdbRating`.
     */
    private fun parseAppExtrasTmdbRating(appExtras: JsonObject?): String? {
        val ratings = appExtras?.get("ratings") as? JsonObject ?: return null
        return (ratings["tmdb"] as? JsonObject)?.str("rating")
    }

    /**
     * Season posters out of `app_extras.seasonPosters`: served as an
     * array in season order ([s1, s2, …], Nuvio shape) or an object
     * keyed by season number ({"1": url}); both land in the model's
     * season-number map. Blank entries are skipped, never mapped.
     */
    private fun parseAppExtrasSeasonPosters(appExtras: JsonObject?): Map<Int, String> {
        val el = appExtras?.get("seasonPosters") ?: return emptyMap()
        val out = LinkedHashMap<Int, String>()
        when (el) {
            is JsonArray -> el.forEachIndexed { index, item ->
                (item as? JsonPrimitive)?.contentOrNull
                    ?.takeIf { it.isNotBlank() }?.let { out[index + 1] = it }
            }
            is JsonObject -> for ((key, value) in el) {
                val season = key.toIntOrNull() ?: continue
                (value as? JsonPrimitive)?.contentOrNull
                    ?.takeIf { it.isNotBlank() }?.let { out[season] = it }
            }
            else -> Unit
        }
        return out
    }

    /**
     * YouTube trailer references. PlavioMeta serves `trailerStreams`:
     * [{title, ytId}] in the standard shape (v0.14.45), and before
     * the flip [{source, type}] with the YouTube id in `source` —
     * both are accepted here, the legacy one under the same 11-char
     * YouTube-id check the `trailers` array below uses. The
     * Stremio-standard `trailers` array also carries the id in
     * `source` ([{source, type}]).
     */
    private fun parseTrailers(meta: JsonObject): List<TrailerStream> {
        val out = linkedMapOf<String, TrailerStream>()
        (meta["trailerStreams"] as? JsonArray)?.forEach { el ->
            val o = el as? JsonObject ?: return@forEach
            val ytId = o.str("ytId")?.trim()?.takeIf { it.isNotEmpty() }
                ?: o.str("source")?.trim()
                    ?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
                ?: return@forEach
            out.putIfAbsent(ytId, TrailerStream(o.str("title") ?: "", ytId))
        }
        (meta["trailers"] as? JsonArray)?.forEach { el ->
            val o = el as? JsonObject ?: return@forEach
            val ytId = o.str("source")?.trim()?.takeIf { it.isNotEmpty() } ?: return@forEach
            // Skip non-YouTube sources (ids are 11-char YouTube video ids).
            if (!ytId.matches(Regex("[A-Za-z0-9_-]{11}"))) return@forEach
            out.putIfAbsent(ytId, TrailerStream(o.str("title") ?: "", ytId))
        }
        return out.values.toList()
    }

    fun parseStreams(text: String): StreamResult {
        val obj = json.parseToJsonElement(text).jsonObject
        val streams = (obj["streams"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val (url, embeddedHeaders) = splitEmbeddedHeaders(s.str("url"))
            val magnetHash = torrentHashFromMagnet(url)
            val infoHash = s.str("infoHash") ?: magnetHash
            val behaviorHints = s["behaviorHints"] as? JsonObject
            // Keep entries that have either a direct URL or an infoHash
            // (infoHash-only entries can be resolved via TorBox debrid).
            if (url == null && infoHash == null) return@mapNotNull null
            StreamItem(
                // Placeholder URL for infoHash-only entries so dedup still
                // works; StreamRepository replaces it with the real HTTP
                // link once TorBox resolves it.
                url = if (magnetHash != null) "infohash:$infoHash" else url ?: "infohash:$infoHash",
                name = s.str("name"),
                title = s.str("title") ?: s.str("description"),
                headers = parseProxyHeaders(s, embeddedHeaders),
                infoHash = infoHash,
                fileIdx = (s["fileIdx"] as? JsonPrimitive)?.intOrNull
                    ?: ((s["behaviorHints"] as? JsonObject)?.get("fileIdx") as? JsonPrimitive)?.intOrNull,
                filePath = s.str("filePath") ?: s.str("file") ?: s.str("path")
                    ?: s.str("filename") ?: behaviorHints?.str("filePath"),
                mimeType = s.str("mimeType") ?: behaviorHints?.str("mimeType"),
                videoSize = ((s["videoSize"] ?: behaviorHints?.get("videoSize")) as? JsonPrimitive)
                    ?.contentOrNull?.toLongOrNull(),
                filename = s.str("filename") ?: behaviorHints?.str("filename"),
                // P6: per-file audio language, when the payload carries
                // it in any of the shapes addons use.
                audioLanguage = s.str("audioLanguage") ?: s.str("language")
                    ?: behaviorHints?.str("audioLanguage") ?: behaviorHints?.str("language")
                    ?: ((s["audioLanguages"] as? JsonArray)?.firstOrNull() as? JsonPrimitive)?.contentOrNull,
                // Smart Picks: PlavioHD's serve-time pick flag
                // (behaviorHints.plavioPick, addon v1.9.135).
                plavioPick = (behaviorHints?.get("plavioPick") as? JsonPrimitive)?.booleanOrNull ?: false
            )
        } ?: emptyList()
        val subtitles = (obj["subtitles"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val url = s.str("url") ?: return@mapNotNull null
            Subtitle(url = url, lang = s.str("lang") ?: "und")
        } ?: emptyList()
        // v0.14.25: PlavioHD's still-filling marker (additive top-level
        // field beside "streams"; absent on every final answer and on
        // every other addon's payload).
        val filling = (obj["filling"] as? JsonPrimitive)?.booleanOrNull ?: false
        return StreamResult(streams, subtitles, filling)
    }

    /** Parses a dedicated /subtitles/{type}/{id}.json response. */
    fun parseSubtitles(text: String): List<Subtitle> {
        val obj = json.parseToJsonElement(text).jsonObject
        return (obj["subtitles"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val url = s.str("url") ?: return@mapNotNull null
            Subtitle(url = url, lang = s.str("lang") ?: "und")
        } ?: emptyList()
    }

    /** Parses PlavioMeta /related/{type}/{id}.json: { sections: [{id,title,metas}] }. */
    fun parseRelated(text: String, fallbackType: String): List<RelatedSection> {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return emptyList()
        return ((obj["sections"] as? JsonArray) ?: return emptyList()).mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val title = s.str("title") ?: return@mapNotNull null
            val metas = ((s["metas"] as? JsonArray) ?: JsonArray(emptyList())).mapNotNull { m ->
                (m as? JsonObject)?.let { parseMetaPreview(it, fallbackType) }
            }
            if (metas.isEmpty()) return@mapNotNull null
            RelatedSection(
                id = s.str("id") ?: title,
                title = title,
                metas = metas
            )
        }
    }

    /** Parses PlavioMeta /person/{id}.json: { person, movies, series }. */
    fun parsePerson(text: String): PersonDetail? {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return null
        val p = obj["person"] as? JsonObject ?: return null
        val name = p.str("name") ?: return null
        fun metas(key: String, type: String): List<MetaPreview> =
            ((obj[key] as? JsonArray) ?: JsonArray(emptyList())).mapNotNull { m ->
                (m as? JsonObject)?.let { parseMetaPreview(it, type) }
            }
        return PersonDetail(
            id = (p["id"] as? JsonPrimitive)?.intOrNull ?: 0,
            name = name,
            photo = p.str("photo"),
            movies = metas("movies", "movie"),
            series = metas("series", "series"),
            // Actor details (v0.14.40, item 14): picked up when the
            // serving addon carries them; absent keys stay null and
            // the page simply skips those lines.
            birthday = p.str("birthday")?.takeIf { it.isNotBlank() },
            deathday = p.str("deathday")?.takeIf { it.isNotBlank() },
            placeOfBirth = (p.str("placeOfBirth") ?: p.str("place_of_birth"))
                ?.takeIf { it.isNotBlank() },
            biography = (p.str("biography") ?: p.str("bio"))?.takeIf { it.isNotBlank() },
            knownFor = p.str("knownFor")
                ?.split("·")?.map { it.trim() }?.filter { it.isNotBlank() }
                ?: emptyList()
        )
    }

    /**
     * Parses the /person-search/{query}.json extension:
     * { "people": [ { "id": 42802, "name": "...", "photo": "...", "knownFor": "..." } ] }.
     * Returns null when the payload carries no people array at all —
     * the addon doesn't serve the route (an error page or another JSON
     * shape), so the caller tries the next addon. A present-but-empty
     * array is a real answer and returns an empty list.
     */
    fun parsePersonSearch(text: String): List<CastMember>? {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return null
        val arr = obj["people"] as? JsonArray ?: return null
        return arr.mapNotNull { el ->
            val p = el as? JsonObject ?: return@mapNotNull null
            val name = p.str("name") ?: return@mapNotNull null
            CastMember(
                id = (p["id"] as? JsonPrimitive)?.intOrNull ?: 0,
                name = name,
                photo = p.str("photo"),
                knownFor = p.str("knownFor")
            )
        }
    }
}
