package com.pulsestream.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.res.painterResource
import com.pulsestream.app.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Card
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.pulsestream.app.data.MdbListApi
import com.pulsestream.app.ui.components.OrbitDots
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pulsestream.app.ui.components.AddToListSheet
import com.pulsestream.app.ui.components.PlayButton
import com.pulsestream.app.ui.components.WatchedPill
import com.pulsestream.app.ui.components.SafePosterImage
import com.pulsestream.app.data.CastMember
import com.pulsestream.app.data.MetaDetail
import com.pulsestream.app.data.MetaPreview
import com.pulsestream.app.data.notifications.EpisodeNotifyStore
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.data.BrowsingPrivacy
import com.pulsestream.app.data.TrailerResolver
import com.pulsestream.app.data.TmdbClient
import com.pulsestream.app.data.RelatedSection
import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.StreamProber
import com.pulsestream.app.data.CustomListsRepository
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.Subtitle
import com.pulsestream.app.data.Video
import com.pulsestream.app.data.streamQualityLabel
import com.pulsestream.app.data.SUBTITLE_LANGUAGE_OPTIONS
import com.pulsestream.app.ui.components.parseStreamInfo
import com.pulsestream.app.ui.components.ErrorState
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.liquidGlass
import androidx.compose.ui.draw.alpha
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.LoadingState
import com.pulsestream.app.ui.components.AddonTabs
import com.pulsestream.app.ui.components.pickAutoplayStream
import com.pulsestream.app.ui.components.rememberStreamBrowserState
import com.pulsestream.app.ui.components.StreamCard
import com.pulsestream.app.ui.components.StreamList
import com.pulsestream.app.ui.components.streamCapsuleConfig
import com.pulsestream.app.ui.components.streamListItems
import com.pulsestream.app.ui.components.DownloadConfirmDialog
import com.pulsestream.app.ui.components.StreamTab
import com.pulsestream.app.ui.components.addonKey
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import androidx.compose.ui.focus.focusProperties
import com.pulsestream.app.ui.tv.rememberIsTv
import com.pulsestream.app.ui.tv.tvFocusRing
import com.pulsestream.app.ui.tv.tvSheetFocus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

sealed interface MetaUiState {
    data object Loading : MetaUiState
    data class Content(val meta: MetaDetail) : MetaUiState
    data class Error(val message: String) : MetaUiState
}

sealed interface StreamsUiState {
    data object Idle : StreamsUiState
    data object Loading : StreamsUiState
    data class Content(val streams: List<StreamItem>, val subtitles: List<Subtitle>, val loadingMore: Boolean = false) : StreamsUiState
    data class Error(val message: String) : StreamsUiState
}

/** Fired when the user pressed Play: play this stream immediately. */
data class AutoPlay(val stream: StreamItem, val subtitles: List<Subtitle>)

/** State of the "Plavio Pick" background stream check. */
sealed interface PickState {
    data object Idle : PickState
    data object Probing : PickState
    data class Found(val stream: StreamItem) : PickState
    data object None : PickState
}

/** Probe-restart debounce for the Detail prefetch (v0.14.17 lag fix). */
private const val PROBE_DEBOUNCE_MS = 600L

class DetailViewModel(private val repo: StreamRepository) : ViewModel() {
    /** Set from the composable; used for TV-aware probing headers. */
    var isTv: Boolean = false
    var metaState by mutableStateOf<MetaUiState>(MetaUiState.Loading)
        private set
    var streamsState by mutableStateOf<StreamsUiState>(StreamsUiState.Idle)
        private set
    var selectedSeason by mutableStateOf<Int?>(null)
        private set
    var selectedVideo by mutableStateOf<Video?>(null)
        private set
    /** Shuffle episodes (v0.9.0+): random pick instead of sequential. Backed by SettingsStore. */
    var shuffleEpisodes by mutableStateOf(repo.settings.shuffleEpisodes)
        private set
    var autoPlayEvent by mutableStateOf<AutoPlay?>(null)
        private set
    /** "Plavio Pick": best verified stream, probed in the background. */
    var pickState by mutableStateOf<PickState>(PickState.Idle)
        private set
    /** "More like this" + "More from <actor>" rows from PlavioMeta. */
    var relatedState by mutableStateOf<List<RelatedSection>>(emptyList())
        private set

    /** Set when the user pressed Play while streams were still loading. */
    private var pendingAutoPlay = false
    /**
     * Watch Now rework (owner's order 2026-10-28): incremented when a
     * Watch Now tap must go STRAIGHT to the player in pending auto-pick
     * mode — streams still arriving, or no pick winner yet. The player
     * continues the same shared fetch and finishes the pick itself;
     * the detail page never makes the user wait.
     */
    var pendingPlayTick by mutableStateOf(0)
        private set
    /** Incremented when a Watch Now tap lands on a settled zero-stream result. */
    var noStreamTick by mutableStateOf(0)
        private set

    internal fun requestPendingPlay() { pendingPlayTick++ }
    internal fun requestNoStreamMessage() { noStreamTick++ }

    /**
     * Live channel opened from a catalog row (v0.14.26, batch
     * item 4): the channel entry the row itself carried — set by
     * [loadChannel] BEFORE any meta lookup, so the composable can
     * render the minimal channel page (name/poster from the row +
     * Play) while — and even if — the serving addon never answers
     * a meta request. Null for normal movie/series loads.
     */
    var channelHint by mutableStateOf<MetaPreview?>(null)
        private set

    /** Base URL of the addon that SERVED the channel's catalog. */
    private var channelBaseUrl: String? = null
    /** In-flight stream collection — cancelled when a new one starts. */
    private var streamsJob: Job? = null
    /**
     * Load generation (v0.14.21): bumped at the top of every loadStreams
     * call. Only the job carrying the current generation may write
     * streamsState — a cancelled attempt unwinding late can no longer
     * stamp its error over the load that replaced it.
     */
    private var streamsGeneration = 0
    /** In-flight Plavio Pick probe — cancelled when streams reload. */
    private var probeJob: Job? = null
    /** Debounce timer for probe restarts (v0.14.17 lag fix). */
    private var probeRestartJob: Job? = null
    /** Latest merged list awaiting the debounced probe. */
    private var latestProbeStreams: List<StreamItem> = emptyList()
    /** Current stream-fetch target — lets an interrupted prefetch resume. */
    private var currentStreamType: String? = null
    private var currentStreamVideoId: String? = null
    /** True when the prefetch was cancelled because the player took over. */
    private var prefetchInterrupted = false
    /**
     * Related rows (P1, v0.14.22): OWNED, not hosted. load() starts the
     * related load as its own supervised job the moment the meta lands —
     * the streams flow may hasten nothing and gate nothing any more.
     * [relatedLoaded] latches on COMPLETION (in the job's finally), so a
     * failed/cancelled attempt never reads as "done", and a streams
     * failure can no longer strand the section or its spinner.
     */
    private var relatedJob: Job? = null
    private var ratingsJob: Job? = null
    private var relatedLoaded = false
    /** Base URL of the addon the title was opened from — tried first for metadata. */
    private var hintBaseUrl: String? = null
    /**
     * v0.14.19 (tmdb-id streams fix): the IMDb tt id stream addons can
     * resolve, when this page was opened with a TMDB-native id
     * (tmdb:movie:… / tmdb:tv:… — minted by More Like This and actor
     * filmographies). Stream addons were handed the tmdb id verbatim
     * and returned nothing. Null for every other id shape — those
     * keep the exact pre-fix behaviour (opaque ids like cnc: too).
     */
    private var resolvedStreamSeriesId: String? = null

    /**
     * Resolves the stream-target id for a TMDB-native meta, in order:
     * the meta's own imdbId, its behaviorHints.defaultVideoId, then a
     * bare "tmdb:<numeric>" re-fetch (PlavioMeta rewrites the id to
     * the tt id for that shape). Null when nothing tt-shaped is found
     * — the caller then falls back to today's behaviour.
     */
    private suspend fun resolveTmdbStreamId(meta: MetaDetail): String? {
        val reference = parseTmdbReference(meta.id, meta.type) ?: return null
        meta.imdbId?.takeIf { it.startsWith("tt") }?.let { return it }
        meta.defaultVideoId?.takeIf { it.startsWith("tt") }?.let { return it }
        val refetched = runCatching {
            repo.getMetaFromAny(hintBaseUrl, meta.type, "tmdb:${reference.tmdbId}")
        }.getOrNull() ?: return null
        return refetched.id.takeIf { it.startsWith("tt") }
            ?: refetched.imdbId?.takeIf { it.startsWith("tt") }
            ?: refetched.defaultVideoId?.takeIf { it.startsWith("tt") }
    }

    /**
     * v0.14.20 display-name repair. An addon can answer a TMDB-native
     * id with a stub that carries the id but no title — the parser
     * then falls back to name = id, and that raw id became the title
     * on the detail page, the source sheet and the player (owner's
     * screenshots: sheet header "tmdb:movie:814889"). The Search path
     * never hits this: tt-keyed metas arrive fully named. When the
     * loaded meta has no real name, borrow ONLY the display fields
     * from a better-named copy of the same title — the bare
     * "tmdb:<n>" re-fetch (the same channel [resolveTmdbStreamId]
     * uses; PlavioMeta serves the full named meta for that shape) or
     * the resolved tt id. Id, type and videos are never touched, so
     * stream targeting stays exactly the v0.14.19 logic.
     */
    private suspend fun repairDisplayName(meta: MetaDetail, resolvedTtId: String?): MetaDetail {
        if (meta.name.isNotBlank() && meta.name != meta.id) return meta
        val candidates = ArrayList<String>()
        parseTmdbReference(meta.id, meta.type)?.let { candidates += "tmdb:${it.tmdbId}" }
        resolvedTtId?.let { candidates += it }
        for (candidateId in candidates) {
            if (candidateId == meta.id) continue
            val named = runCatching {
                repo.getMetaFromAny(hintBaseUrl, meta.type, candidateId)
            }.getOrNull() ?: continue
            if (named.name.isBlank() || named.name == named.id || named.name == meta.id) continue
            return meta.copy(
                name = named.name,
                releaseInfo = meta.releaseInfo?.takeIf { it.isNotBlank() } ?: named.releaseInfo
            )
        }
        return meta
    }

    /**
     * Universal ratings fill-in (v0.14.20). Skipped when the meta
     * already carries MDBList data (the in-meta path — PMeta serves
     * the fields itself). Otherwise asks the /ratings endpoint once
     * for the title's tt id and merges the answer into the displayed
     * meta: MDBList's true IMDb value replaces whatever the serving
     * addon (or the TMDB gap-fill) claimed, and the per-source scores
     * fill their empty slots. A late answer for a page the user has
     * already left is dropped (id check before applying).
     */
    private fun maybeLoadEndpointRatings(meta: MetaDetail) {
        val hasMdbData = !meta.mdblistRating.isNullOrBlank() ||
            !meta.traktRating.isNullOrBlank() || !meta.rtRating.isNullOrBlank() ||
            !meta.rtAudienceRating.isNullOrBlank() ||
            !meta.metacriticRating.isNullOrBlank() ||
            !meta.letterboxdRating.isNullOrBlank()
        if (hasMdbData) return
        val ttId = resolvedStreamSeriesId?.takeIf { it.startsWith("tt") }
            ?: meta.imdbId?.takeIf { it.startsWith("tt") }
            ?: meta.defaultVideoId?.takeIf { it.startsWith("tt") }
            ?: meta.id.takeIf { it.startsWith("tt") }
            ?: return
        ratingsJob = viewModelScope.launch {
            val ratings = runCatching { repo.endpointRatings(ttId) }.getOrNull()
                ?: return@launch
            val current = (metaState as? MetaUiState.Content)?.meta ?: return@launch
            if (current.id != meta.id) return@launch
            metaState = MetaUiState.Content(
                current.copy(
                    imdbRating = ratings.imdbRating ?: current.imdbRating,
                    mdblistRating = current.mdblistRating ?: ratings.mdblistRating,
                    traktRating = current.traktRating ?: ratings.traktRating,
                    rtRating = current.rtRating ?: ratings.rtRating,
                    rtAudienceRating = current.rtAudienceRating ?: ratings.rtAudienceRating,
                    metacriticRating = current.metacriticRating ?: ratings.metacriticRating,
                    letterboxdRating = current.letterboxdRating ?: ratings.letterboxdRating
                )
            )
        }
    }

    /** The stream id for one episode of the current meta. */
    private fun streamIdForEpisode(meta: MetaDetail, video: Video): String {
        if (video.id.startsWith("tt")) return video.id
        val resolved = resolvedStreamSeriesId ?: return video.id
        return "$resolved:${video.season}:${video.episode}"
    }

    /** Retries the current stream target (keeps the tmdb resolution). */
    fun retryStreams() {
        val meta = (metaState as? MetaUiState.Content)?.meta ?: return
        val video = selectedVideo
        val id = if (meta.type == "series" && video != null) streamIdForEpisode(meta, video)
            else resolvedStreamSeriesId ?: meta.id
        loadStreams(meta.type, id)
    }

    /**
     * Live channel load (v0.14.26, batch item 4): a `tv` row goes
     * toward the SERVING addon and toward PLAY — never through
     * the movie/series meta gate that produced "Couldn't find
     * details for this title in any installed addon." for every
     * channel. The page is built from the catalog row already in
     * hand; streams come straight from the serving addon; a real
     * meta answer from that same addon may still enrich the page,
     * but its absence can no longer dead-end the channel.
     */
    fun loadChannel(hintBaseUrl: String?, type: String, id: String, hint: MetaPreview?) {
        channelHint = hint
        channelBaseUrl = hintBaseUrl
        load(hintBaseUrl, type, id)
    }

    fun load(hintBaseUrl: String?, type: String, id: String) {
        this.hintBaseUrl = hintBaseUrl
        resolvedStreamSeriesId = null
        ratingsJob?.cancel()
        // Drop stale related rows immediately — the new fetch is async and the
        // old title's rows would flash until it returns.
        relatedState = emptyList()
        viewModelScope.launch {
            metaState = MetaUiState.Loading
            try {
                // Live channels (v0.14.26, item 4): ask the SERVING
                // addon first and alone, on its own short budget —
                // the full meta walk is slow for channel ids and its
                // failure used to dead-end the channel entirely.
                val servingMeta = if (type == "tv" && hintBaseUrl != null) {
                    withTimeoutOrNull(6_000L) {
                        runCatching { repo.getStreamsMeta(hintBaseUrl, type, id) }.getOrNull()
                    }
                } else null
                // Metadata may live in a different addon than the catalog:
                // try every meta-capable addon until one succeeds.
                val meta = servingMeta ?: repo.getMetaFromAny(hintBaseUrl, type, id)
                if (meta == null && type == "tv") {
                    // No addon answered meta for this channel: build
                    // the page from the catalog row and go toward
                    // play anyway — the tap must never dead-end.
                    val hint = channelHint
                    val built = MetaDetail(
                        id = id,
                        type = type,
                        name = hint?.name?.takeIf { it.isNotBlank() } ?: "Live channel",
                        poster = hint?.poster,
                        background = hint?.background,
                        description = hint?.description
                    )
                    metaState = MetaUiState.Content(built)
                    loadStreams(type, id)
                } else if (meta == null) {
                    metaState = MetaUiState.Error("Couldn't find details for this title in any installed addon.")
                } else {
                    // TMDB-native ids: resolve the tt stream target
                    // BEFORE any stream fetch (no-op for other ids).
                    resolvedStreamSeriesId = resolveTmdbStreamId(meta)
                    // v0.14.20: a stub meta (id echoed, no title) gets
                    // its display name repaired BEFORE anything renders
                    // it — the raw id otherwise becomes the title on
                    // this page, the source sheet and the player.
                    val displayMeta = repairDisplayName(meta, resolvedStreamSeriesId)
                    metaState = MetaUiState.Content(displayMeta)
                    // Universal ratings (v0.14.20): when the serving
                    // meta carried no MDBList fields, fetch them from
                    // the /ratings endpoint as a background job — the
                    // page is already on screen and the ratings row
                    // fills in when the answer lands.
                    maybeLoadEndpointRatings(displayMeta)
                    // P1/P3 (v0.14.22): related starts NOW as its own
                    // supervised job, keyed to the canonical tt id when
                    // this page was opened with a TMDB-shaped id (the
                    // stub id must never key the lookup).
                    startRelatedJob(
                        displayMeta.type,
                        resolvedStreamSeriesId ?: displayMeta.id
                    )
                    // Warm trigger (v0.14.28, owner's order): opening
                    // a title starts PlavioHD caching it right away,
                    // so the streams are ready when the user presses
                    // play. Fire-and-forget — the repository call only
                    // validates the id and launches in the background.
                    // Series warm here without an episode (the server
                    // default, S01E01); the episode this page actually
                    // presents warms from selectEpisode below, in the
                    // same open sequence, and session dedupe folds the
                    // two when they name the same episode.
                    repo.warmDetailTitle(
                        displayMeta.type,
                        resolvedStreamSeriesId ?: displayMeta.imdbId
                            ?: displayMeta.defaultVideoId ?: displayMeta.id
                    )
                    if (displayMeta.type == "series" && displayMeta.videos.isNotEmpty()) {
                        val seasons = displayMeta.videos.map { it.season }.distinct().sorted()
                        selectSeason(seasons.first(), displayMeta)
                    } else {
                        loadStreams(displayMeta.type, resolvedStreamSeriesId ?: displayMeta.id)
                    }
                }
            } catch (e: CancellationException) {
                // v0.14.21: a superseded load is not an error — never
                // let its cancellation message reach the screen.
                throw e
            } catch (e: Exception) {
                metaState = MetaUiState.Error(e.message ?: "Couldn't load details")
            }
        }
    }

    fun selectSeason(season: Int, meta: MetaDetail) {
        selectedSeason = season
        val episodes = meta.videos.filter { it.season == season }
            .sortedWith(compareBy({ it.episode }, { it.title }))
        val pick = if (shuffleEpisodes) episodes.randomOrNull() else episodes.firstOrNull()
        if (pick != null) selectEpisode(pick)
    }

    /** Toggle shuffle mode; enabling it immediately jumps to a random episode. */
    fun updateShuffle(enabled: Boolean) {
        shuffleEpisodes = enabled
        repo.settings.shuffleEpisodes = enabled
        if (enabled) selectRandomEpisode()
    }

    /** Picks a random episode from the current season and selects it. */
    fun selectRandomEpisode() {
        val meta = (metaState as? MetaUiState.Content)?.meta ?: return
        val episodes = meta.videos.filter { it.season == selectedSeason }
        val pick = episodes.randomOrNull() ?: return
        selectEpisode(pick)
    }

    /**
     * Episode tap = play (v0.14.14, item 1): tapping an episode card
     * starts playback immediately — no intermediate sources step.
     * Tapping the already-selected episode reuses the Watch Now
     * decision tree ([onPlayPressed]: settled pick plays at once,
     * still-loading goes pending, settled-empty shows the message).
     * Tapping a DIFFERENT episode selects it and hands the player
     * over in pending auto-pick mode at once — the player continues
     * the new episode's fetch and auto-picks there. streamsState is
     * reset to Loading SYNCHRONOUSLY on a switch so the pending
     * handoff can never carry the previous episode's stream list
     * (the old load job is generation-guarded from writing, too).
     */
    fun playEpisodeDirect(video: Video) {
        if (selectedVideo?.id == video.id) {
            onPlayPressed()
            return
        }
        selectEpisode(video)
        streamsState = StreamsUiState.Loading
        requestPendingPlay()
    }

    fun selectEpisode(video: Video) {
        selectedVideo = video
        val meta = (metaState as? MetaUiState.Content)?.meta ?: return
        // Warm trigger (v0.14.28): the episode this page presents
        // warms with its season/episode, once per session per episode
        // (session dedupe) — selecting another episode warms that one
        // too, so a tap on any episode starts its caching.
        repo.warmDetailTitle(
            meta.type,
            resolvedStreamSeriesId ?: meta.imdbId ?: meta.defaultVideoId ?: meta.id,
            season = video.season,
            episode = video.episode
        )
        loadStreams(meta.type, streamIdForEpisode(meta, video))
    }

    fun retryLoad(repo: StreamRepository, addonId: String, type: String, metaId: String) {
        viewModelScope.launch {
            val baseUrl = repo.getAddonBaseUrl(addonId)
            load(baseUrl, type, metaId)
        }
    }

    /**
     * Streams may live in different addons than catalogs/metadata.
     * Collects the progressive merged flow: sources appear (and autoplay
     * fires) as soon as the first addon answers instead of waiting for
     * every addon — the fix for slow stream loading.
     */
    fun loadStreams(type: String, videoId: String) {
        // Live channels (v0.14.26, item 4): a channel's streams come
        // from its SERVING addon toward play — the same direct path
        // the Live tab plays through (liveStreamResultsFlow) — never
        // through the PrePlay gate below: a channel must load its
        // streams on open regardless of the PrePlay switch.
        if (type == "tv") {
            loadChannelStreams(videoId)
            return
        }
        // PrePlay (item 13, v0.14.24): this on-page load ALWAYS runs
        // — it is the load the Sources sheet, the autoplay picks and
        // the probe all read, and it is what stable v0.14.22 did on
        // every Details open. v0.14.27 FIX (batch N7): the v0.14.24
        // gate that returned early here whenever the PrePlay switch
        // was off silently disabled ALL of that — with the switch at
        // its default OFF, no request was ever dispatched and the
        // sheet settled instantly on "0 streams" for every addon.
        // The switch keeps its real surface elsewhere: with it on,
        // this load doubles as the pocket fill (streamResultsFlow
        // writes the merged result into the repository's session
        // stream cache, so the play press starts from that cached
        // emission instantly), and the player's next-episode
        // prefetch stays gated on the switch in PlayerScreen
        // (repository.prePlayPrefetch is only called from there).
        // v0.14.21: a refresh/retry tap for the target already loading is a
        // no-op — cancelling a healthy in-flight load only restarted the
        // whole fan-out from zero (and the dead attempt's cancellation
        // error then landed on the fresh one). A different target still
        // takes over, and from a settled/error state a load always starts.
        if (streamsJob?.isActive == true &&
            type == currentStreamType && videoId == currentStreamVideoId
        ) return
        val gen = ++streamsGeneration
        streamsJob?.cancel()
        probeJob?.cancel()
        probeRestartJob?.cancel()
        pickState = PickState.Idle
        currentStreamType = type
        currentStreamVideoId = videoId
        prefetchInterrupted = false
        streamsJob = viewModelScope.launch {
            if (gen == streamsGeneration) streamsState = StreamsUiState.Loading
            var gotAny = false
            try {
                repo.streamResultsFlow(type, videoId).collect { result ->
                    if (result.streams.isNotEmpty()) {
                        gotAny = true
                        if (gen == streamsGeneration) {
                            streamsState = StreamsUiState.Content(result.streams, result.subtitles, loadingMore = true)
                        }
                        maybeProbePick(result.streams)
                        if (pendingAutoPlay) {
                            pendingAutoPlay = false
                            playBestOrFirst()
                        }
                    }
                    // Empty intermediate emissions: stay on Loading, don't flash an error.
                }
                // v0.8.29 fix: transient failures (cold-start timeouts, dispatcher
                // contention) could empty the first pass while a manual retry
                // succeeded. v0.14.21: at most ONE confirmation pass — three
                // full re-collects multiplied one bad pass into ~a minute
                // before the sheet would settle.
                var attempt = 0
                while (!gotAny && attempt < 1) {
                    attempt++
                    kotlinx.coroutines.delay(1500L * attempt)
                    repo.streamResultsFlow(type, videoId).collect { result ->
                        if (result.streams.isNotEmpty()) {
                            gotAny = true
                            if (gen == streamsGeneration) {
                                streamsState = StreamsUiState.Content(result.streams, result.subtitles, loadingMore = true)
                            }
                            maybeProbePick(result.streams)
                                if (pendingAutoPlay) {
                                pendingAutoPlay = false
                                playBestOrFirst()
                            }
                        }
                    }
                }
                // P1: related is its own job now — no settle call here.
                if (gotAny && gen == streamsGeneration) {
                    // Collection is over: the Watch Now side-spinner stops,
                    // whatever is on screen is the final list.
                    val settled = streamsState as? StreamsUiState.Content
                    if (settled != null && settled.loadingMore) {
                        streamsState = settled.copy(loadingMore = false)
                    }
                }
                if (!gotAny && gen == streamsGeneration) {
                    // Settled zero (owner's Watch Now rework,
                    // 2026-10-28): the Sources sheet and the Watch
                    // Now tap both surface this exact wording.
                    streamsState = StreamsUiState.Error("No stream available")
                }
            } catch (e: CancellationException) {
                // v0.14.21: cancellation is not an error — rethrow so its
                // message ("…Coroutine was cancelled") can never again be
                // rendered as the stream error.
                throw e
            } catch (e: Exception) {
                if (!gotAny && gen == streamsGeneration) {
                    streamsState = StreamsUiState.Error(e.message ?: "Couldn't load sources")
                } else if (gotAny && gen == streamsGeneration) {
                    // P1: a flow that throws AFTER partial success must
                    // still settle — never strand loadingMore forever.
                    val settled = streamsState as? StreamsUiState.Content
                    if (settled != null && settled.loadingMore) {
                        streamsState = settled.copy(loadingMore = false)
                    }
                }
            }
        }
    }

    /**
     * Channel stream load (v0.14.26, item 4): collects the serving
     * addon's streams via the repository's live flow (serving addon
     * first, others as failover partners — the Live tab's exact
     * behaviour), keeps only playable live URLs, and settles into
     * the same [StreamsUiState] the Play path already understands.
     * Bounded: the collect runs under the same 20 s window the
     * Live tab uses, so a slow addon can't strand the page.
     */
    private fun loadChannelStreams(videoId: String) {
        if (streamsJob?.isActive == true &&
            currentStreamType == "tv" && videoId == currentStreamVideoId
        ) return
        val gen = ++streamsGeneration
        streamsJob?.cancel()
        probeJob?.cancel()
        probeRestartJob?.cancel()
        pickState = PickState.Idle
        currentStreamType = "tv"
        currentStreamVideoId = videoId
        prefetchInterrupted = false
        streamsJob = viewModelScope.launch {
            if (gen == streamsGeneration) streamsState = StreamsUiState.Loading
            var gotAny = false
            try {
                val ref = com.pulsestream.app.data.TvChannelRef(
                    addonId = repo.addonIdForBaseUrl(channelBaseUrl) ?: "",
                    metaId = videoId,
                    name = channelHint?.name ?: "",
                    poster = channelHint?.poster,
                    type = "tv"
                )
                withTimeoutOrNull(20_000L) {
                    repo.liveStreamResultsFlow(ref).collect { result ->
                        val playable = result.streams.filter {
                            com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                        }
                        if (playable.isNotEmpty()) {
                            gotAny = true
                            if (gen == streamsGeneration) {
                                streamsState = StreamsUiState.Content(
                                    playable, result.subtitles, loadingMore = true
                                )
                            }
                            maybeProbePick(playable)
                            if (pendingAutoPlay) {
                                pendingAutoPlay = false
                                playBestOrFirst()
                            }
                        }
                    }
                }
                if (gen != streamsGeneration) return@launch
                if (gotAny) {
                    val settled = streamsState as? StreamsUiState.Content
                    if (settled != null && settled.loadingMore) {
                        streamsState = settled.copy(loadingMore = false)
                    }
                } else {
                    streamsState = StreamsUiState.Error("No stream available")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!gotAny && gen == streamsGeneration) {
                    streamsState = StreamsUiState.Error(e.message ?: "Couldn't load sources")
                }
            }
        }
    }

    /**
     * Starts (or restarts, for a new title) the related-rows job. The job
     * is supervised by viewModelScope alone: it does not ride the streams
     * flow, is not cancelled by onScreenCovered's prefetch stop, and its
     * latch is written in finally — completion, not attempt.
     */
    private fun startRelatedJob(type: String, metaId: String) {
        relatedJob?.cancel()
        relatedLoaded = false
        relatedJob = viewModelScope.launch {
            try {
                relatedState = repo.getRelated(type, metaId, hintBaseUrl)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Related is best-effort: an empty section, never an error.
            } finally {
                relatedLoaded = true
            }
        }
    }

    /**
     * The player (or anything else) covered this screen (v0.14.17 lag
     * fix, audit cause 1d): the background prefetch + probe stop so
     * playback never competes with them for bandwidth/CPU. Whatever
     * was found so far stays in state; an interrupted fetch resumes
     * when the user comes back (see [onScreenResumed]).
     */
    fun onScreenCovered() {
        probeRestartJob?.cancel()
        probeJob?.cancel()
        if (streamsJob?.isActive == true) {
            streamsJob?.cancel()
            prefetchInterrupted = true
        }
    }

    /** The screen is on top again: resume a prefetch the player interrupted. */
    fun onScreenResumed() {
        if (!prefetchInterrupted) return
        prefetchInterrupted = false
        val type = currentStreamType ?: return
        val videoId = currentStreamVideoId ?: return
        loadStreams(type, videoId)
    }

    /**
     * Starts (or restarts, when the merged list grew) the background Plavio Pick
     * probe. Keeps an already-found winner — no churn while sources stream in.
     */
    private fun maybeProbePick(streams: List<StreamItem>) {
        // No quality cap on the probe pick (owner's 2 autoplay rules,
        // 2026-11-02, v0.14.39): the adaptive device/network cap used
        // to apply whenever quality sat on "Auto", which broke both
        // rules — a set quality order was overridden, and with no
        // rule set the pick could never reach the highest quality.
        // The probe now honours only the user's own rules: the size
        // limit and the explicit quality bucket (both passed below).
        val found = pickState as? PickState.Found
        if (found != null) {
            // Keep the winner while it is still in the merged list; a
            // winner that vanished is dropped and re-probed (v0.14.17).
            // (The old cap-violation re-probe went with the cap in
            // v0.14.39 — there is no cap to violate any more.)
            val winnerGone = streams.none { it.url == found.stream.url }
            if (!winnerGone) return
        }
        // v0.14.17 lag fix (audit cause 1b): DEBOUNCE the restart.
        // The merged flow emits once per addon (and once per resolved
        // debrid stream), and the old code cancelled + restarted a
        // full probe wave on every single emission. Now the running
        // probe is cancelled, and a fresh one only starts once the
        // list has been stable for ~600 ms, against the latest list;
        // StreamProber's verdict reuse means that one run only pays
        // for genuinely new URLs.
        latestProbeStreams = streams
        probeJob?.cancel()
        probeRestartJob?.cancel()
        probeRestartJob = viewModelScope.launch {
            kotlinx.coroutines.delay(PROBE_DEBOUNCE_MS)
            val latest = latestProbeStreams
            // Same no-cap rule as above (v0.14.39): only the user's
            // size limit + explicit quality steer the probe pick.
            val capNow: String? = null
            probeJob = viewModelScope.launch {
                pickState = PickState.Probing
                val best = StreamProber.findBest(
                    latest.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) },
                    isTv, capNow,
                    maxSizeGb = repo.settings.autoplayMaxSizeGb,
                    explicitQuality = repo.settings.autoplayQuality.takeIf { it != "Auto" },
                    preferredLanguage = repo.settings.preferredAudioLanguage
                )
                pickState = if (best != null) PickState.Found(best) else PickState.None
                // Warm the winner's connection so Play starts without the
                // DNS + TLS cost (shared pool — see PlaybackHttp).
                if (best != null) com.pulsestream.app.data.PlaybackHttp.warmUp(best.url)
            }
        }
    }

    /**
     * Play button (Watch Now rework, owner's order 2026-10-28): NO
     * waiting on this page — the streams prefetch has been running in
     * the background since the page opened. A tap either plays a pick
     * that is already final (the saved resume stream, the settings
     * rule, or a finished Plavio Pick probe) or goes straight to the
     * player in pending auto-pick mode, where the SAME shared fetch
     * continues and the player finishes the pick and auto-plays the
     * best stream — no further tap anywhere. A settled zero-stream
     * result surfaces "No stream available" instead of opening an
     * empty player.
     */
    fun onPlayPressed() {
        when (val s = streamsState) {
            is StreamsUiState.Error -> requestNoStreamMessage()
            is StreamsUiState.Content -> {
                val playable = s.streams.filter {
                    com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                }
                if (playable.isEmpty()) {
                    // Still arriving (debrid placeholders resolve
                    // late) → the player continues the fetch; truly
                    // settled with nothing → the message.
                    if (s.loadingMore) requestPendingPlay() else requestNoStreamMessage()
                    return
                }
                viewModelScope.launch {
                    val resume = resumeStreamFor(playable)
                    if (resume != null) {
                        val cur = streamsState as? StreamsUiState.Content ?: return@launch
                        autoPlayEvent = AutoPlay(resume, cur.subtitles)
                        return@launch
                    }
                    val cur = streamsState as? StreamsUiState.Content ?: return@launch
                    // Debrid lane still resolving (owner's order
                    // 2026-10-31): don't rule a pick from a snapshot
                    // the TorBox rows haven't reached — hand over to
                    // the player, which continues the same fetch and
                    // picks there, cached streams first.
                    if (com.pulsestream.app.data.debrid.DebridSupport.isActive(repo.settings) &&
                        com.pulsestream.app.data.debrid.DebridSupport.hasPending(cur.streams)
                    ) {
                        requestPendingPlay()
                        return@launch
                    }
                    if (repo.settings.streamAutoplay) {
                        val ruled = pickAutoplayStream(playable, repo.settings)
                        if (ruled != null) {
                            autoPlayEvent = AutoPlay(ruled, cur.subtitles)
                        } else {
                            // Only placeholders the rule can't use
                            // yet — the player finishes the pick.
                            requestPendingPlay()
                        }
                        return@launch
                    }
                    val pick = pickState as? PickState.Found
                    if (pick != null && !pick.stream.url.startsWith("infohash:")) {
                        autoPlayEvent = AutoPlay(pick.stream, cur.subtitles)
                    } else {
                        // The probe has no winner yet — never wait
                        // for it here; the player takes over the
                        // same fetch and picks there.
                        requestPendingPlay()
                    }
                }
            }
            else -> {
                // Idle/Loading: the prefetch from page-open is in
                // flight — go straight to the player with it.
                val meta = (metaState as? MetaUiState.Content)?.meta
                if (meta != null && s is StreamsUiState.Idle) {
                    val videoId = if (meta.type == "series") {
                        selectedVideo?.let { streamIdForEpisode(meta, it) }
                            ?: resolvedStreamSeriesId ?: meta.id
                    } else resolvedStreamSeriesId ?: meta.id
                    loadStreams(meta.type, videoId)
                }
                requestPendingPlay()
            }
        }
    }

    private fun playBestOrFirst() {
        val s = streamsState as? StreamsUiState.Content ?: return
        // Only consider playable streams - skip unresolved infohash: placeholders.
        // Debrid resolution replaces these with real HTTP links asynchronously.
        val playableStreams = s.streams.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
        if (playableStreams.isEmpty()) { pendingAutoPlay = true; return }
        // Resume preference (DB v15): if this title/episode has an
        // in-progress saved row, Play resumes the stream the user
        // was watching — the same mechanism as the Continue
        // Watching resume — ahead of every pick below.
        viewModelScope.launch {
            val resume = resumeStreamFor(playableStreams)
            if (resume != null) {
                val cur = streamsState as? StreamsUiState.Content ?: return@launch
                autoPlayEvent = AutoPlay(resume, cur.subtitles)
            } else {
                playBestOrFirstPicked()
            }
        }
    }

    /**
     * The saved-stream match for the currently selected video, or
     * null when there is no real in-progress row for it (position
     * under 10 s doesn't count as a resume).
     */
    private suspend fun resumeStreamFor(playable: List<StreamItem>): StreamItem? {
        val meta = (metaState as? MetaUiState.Content)?.meta ?: return null
        // Probe with the SAME id builders the play path saved under
        // (CW resume stickiness fix, 2026-11-02): the old probe passed
        // meta.id as the IMDb id — null for TMDB/PMeta-keyed metas —
        // while the save carried resolvePlaybackIds' real tt id, so
        // the probe's identity ("id|<episode video id>") never equalled
        // the saved row's ("ep|tt|S|E") and Detail Play silently fell
        // through to the auto-pick for every non-tt-keyed series. The
        // video id likewise mirrors the stream fetch id, so the
        // non-tt fallback identity lines up too.
        val ids = resolvePlaybackIds(meta, selectedVideo)
        val row = repo.playbackRowFor(
            ids.imdbId,
            ids.season,
            ids.episode,
            selectedVideo?.let { streamIdForEpisode(meta, it) }
                ?: resolvedStreamSeriesId ?: meta.id
        ) ?: return null
        if (row.positionMs < 10_000) return null
        return repo.matchResumeStream(row, playable)
    }

    private fun playBestOrFirstPicked() {
        val s = streamsState as? StreamsUiState.Content ?: return
        // Only consider playable streams - skip unresolved infohash: placeholders.
        // Debrid resolution replaces these with real HTTP links asynchronously.
        val playableStreams = s.streams.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
        if (playableStreams.isEmpty()) { pendingAutoPlay = true; return }
        // Settings > Streams autoplay: pick by the user's quality/size rule
        // instead of the probed fastest stream.
        if (repo.settings.streamAutoplay) {
            val ruled = pickAutoplayStream(playableStreams, repo.settings)
            if (ruled != null) {
                autoPlayEvent = AutoPlay(ruled, s.subtitles)
                return
            }
            // No playable streams yet - wait for debrid resolution instead of
            // playing an unresolvable placeholder.
            return
        }
        val pick = pickState as? PickState.Found
        if (pick != null && !pick.stream.url.startsWith("infohash:")) {
            autoPlayEvent = AutoPlay(pick.stream, s.subtitles)
            return
        }
        if (pickState is PickState.Probing) {
            viewModelScope.launch {
                withTimeoutOrNull(2500) { probeJob?.join() }
                val best = pickState as? PickState.Found
                val cur = streamsState as? StreamsUiState.Content ?: return@launch
                val curPlayable = cur.streams.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
                if (best != null && !best.stream.url.startsWith("infohash:")) autoPlayEvent = AutoPlay(best.stream, cur.subtitles)
                else if (curPlayable.isNotEmpty()) autoPlayEvent = AutoPlay(curPlayable.first(), cur.subtitles)
            }
            return
        }
        if (playableStreams.isNotEmpty()) autoPlayEvent = AutoPlay(playableStreams.first(), s.subtitles)
    }

    fun consumeAutoPlay(): AutoPlay? {
        val e = autoPlayEvent
        autoPlayEvent = null
        return e
    }

    /**
     * "More like this" + "More from <actor>" rows. PlavioMeta's
     * /related needs an IMDb tt id; other providers are covered by the
     * repository's TMDB stage (key linked) and the generic
     * genre/cast fallback. Quietly empty when no source has data.
     */
    fun loadRelated(type: String, metaId: String) {
        // P1: delegates to the owned related job (see startRelatedJob).
        startRelatedJob(type, metaId)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    repository: StreamRepository,
    listsRepository: CustomListsRepository,
    addonId: String,
    type: String,
    metaId: String,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPlayTrailer: (PlaybackRequest) -> Unit = {},
    onOpenActor: (Int, String) -> Unit = { _, _ -> },
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit = { _, _, _ -> }
) {
    val vm: DetailViewModel = viewModel(factory = vmFactory { DetailViewModel(repository) })
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    // TV-aware probing: the prober must send the same UA the player will.
    vm.isTv = rememberIsTv()

    // v0.14.17 lag fix (audit cause 1d): when this screen stops being
    // the top destination (the player opened over it, or the app was
    // backgrounded), the background stream prefetch + probe are
    // cancelled so they never compete with playback; an interrupted
    // prefetch resumes when the user returns to this page.
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> vm.onScreenCovered()
                Lifecycle.Event.ON_RESUME -> vm.onScreenResumed()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) vm.onScreenResumed()
        onDispose { lifecycle.removeObserver(observer) }
    }

    // Resolve the addon base URL (from search cache or the database) as a hint,
    // then load. Metadata/streams may come from *other* installed addons.
    // Live channels (v0.14.26, item 4) load through loadChannel: the
    // row entry stashed by the opener becomes the page's floor, so a
    // channel can never dead-end on the meta gate again.
    LaunchedEffect(addonId, type, metaId) {
        val baseUrl = repository.getAddonBaseUrl(addonId)
        if (type == "tv") {
            val hint = repository.pendingChannelHint?.takeIf { it.id == metaId }
            repository.pendingChannelHint = null
            vm.loadChannel(baseUrl, type, metaId, hint)
        } else {
            vm.load(baseUrl, type, metaId)
        }
    }

    // Play button: autoplay the first available stream as soon as it's ready.
    LaunchedEffect(vm.autoPlayEvent) {
        vm.consumeAutoPlay()?.let { autoplay ->
            // #12: streams may finish loading after the user already backed
            // out — never navigate to the player from a dead screen.
            if (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return@LaunchedEffect
            val allStreams = (vm.streamsState as? StreamsUiState.Content)?.streams ?: emptyList()
            startPlayback(vm, repository, autoplay.stream, autoplay.subtitles, allStreams, onPlay)
        }
    }

    // Watch Now rework (2026-10-28): a tap with no final pick yet goes
    // STRAIGHT to the player in pending auto-pick mode — the player
    // continues the same background fetch (the repository session
    // cache replays everything found so far) and auto-plays the best
    // stream by the existing rules. No waiting happens on this page.
    LaunchedEffect(vm.pendingPlayTick) {
        if (vm.pendingPlayTick == 0) return@LaunchedEffect
        if (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) return@LaunchedEffect
        startPendingPlayback(vm, repository, onPlay)
    }

    // Settled zero-stream tap: surface the message, open nothing.
    val toastContext = LocalContext.current
    LaunchedEffect(vm.noStreamTick) {
        if (vm.noStreamTick == 0) return@LaunchedEffect
        Toast.makeText(toastContext, "No stream available", Toast.LENGTH_SHORT).show()
    }

    fun retry() {
        vm.retryLoad(repository, addonId, type, metaId)
    }

    GlowBackground {
        when (val state = vm.metaState) {
            is MetaUiState.Loading -> {
                BackBar(onBack)
                LoadingState("Loading details…")
            }
            is MetaUiState.Error -> {
                BackBar(onBack)
                ErrorState(state.message) { retry() }
            }
            is MetaUiState.Content -> DetailContent(
                vm = vm,
                meta = state.meta,
                addonId = addonId,
                repository = repository,
                listsRepository = listsRepository,
                onBack = onBack,
                onPlay = onPlay,
                onPlayTrailer = onPlayTrailer,
                onOpenActor = onOpenActor,
                onOpenDetail = onOpenDetail
            )
        }
    }
}

/**
 * Builds a [PlaybackRequest] for a stream and hands it to the player.
 * Shared by autoplay, the Play button and tapping a stream card.
 */
private fun startPlayback(
    vm: DetailViewModel,
    repository: StreamRepository,
    stream: StreamItem,
    subtitles: List<Subtitle>,
    allStreams: List<StreamItem>,
    onPlay: () -> Unit
) {
    if (stream.url.startsWith("infohash:", true) || stream.url.startsWith("magnet:", true)) return
    val meta = (vm.metaState as? MetaUiState.Content)?.meta ?: return
    val isSeries = meta.type == "series" && vm.selectedVideo != null
    val title = if (isSeries) {
        val v = vm.selectedVideo!!
        "${meta.name} S${v.season}E${v.episode}"
    } else meta.name
    val ids = resolvePlaybackIds(meta, vm.selectedVideo)
    repository.pendingPlayback = PlaybackRequest(
        streamUrl = stream.url,
        headers = stream.headers,
        mimeType = stream.mimeType,
        title = title,
        poster = vm.selectedVideo?.thumbnail ?: meta.poster,
        videoId = vm.selectedVideo?.id ?: meta.id,
        subtitles = subtitles,
        imdbId = ids.imdbId,
        season = ids.season,
        episode = ids.episode,
        isMovie = ids.isMovie,
        type = meta.type,
        streamLabel = streamQualityLabel(stream),
        sourceName = stream.sourceName,
        // DB v15 stream identity + title logo: saves persist these
        // so a Continue Watching resume re-selects THIS stream.
        sourceId = stream.sourceId,
        streamTitle = stream.title ?: stream.name,
        logo = meta.logo,
        streams = allStreams,
        episodes = meta.videos,
        metaId = meta.id,
        seriesName = meta.name.takeIf { !ids.isMovie },
        episodeTitle = vm.selectedVideo?.title
    )
    onPlay()
}

/**
 * Watch Now rework (owner's order 2026-10-28): hands the player a
 * PENDING request — no stream chosen yet (blank streamUrl is the
 * marker) — carrying everything the prefetch has found so far. The
 * player continues the same shared stream fetch and auto-plays the
 * best stream by the existing pick rules (resume match → Settings >
 * Streams rule → Plavio Pick probe → first playable). Nothing waits
 * on the detail page and no second fetch is started from zero: the
 * repository's session result cache replays the prefetch's results
 * into the player's collection instantly.
 */
private fun startPendingPlayback(
    vm: DetailViewModel,
    repository: StreamRepository,
    onPlay: () -> Unit
) {
    val meta = (vm.metaState as? MetaUiState.Content)?.meta ?: return
    val content = vm.streamsState as? StreamsUiState.Content
    val isSeries = meta.type == "series" && vm.selectedVideo != null
    val title = if (isSeries) {
        val v = vm.selectedVideo!!
        "${meta.name} S${v.season}E${v.episode}"
    } else meta.name
    val ids = resolvePlaybackIds(meta, vm.selectedVideo)
    repository.pendingPlayback = PlaybackRequest(
        streamUrl = "",
        title = title,
        poster = vm.selectedVideo?.thumbnail ?: meta.poster,
        videoId = vm.selectedVideo?.id ?: meta.id,
        subtitles = content?.subtitles ?: emptyList(),
        imdbId = ids.imdbId,
        season = ids.season,
        episode = ids.episode,
        isMovie = ids.isMovie,
        type = meta.type,
        logo = meta.logo,
        streams = content?.streams ?: emptyList(),
        episodes = meta.videos,
        metaId = meta.id,
        seriesName = meta.name.takeIf { !ids.isMovie },
        episodeTitle = vm.selectedVideo?.title
    )
    onPlay()
}

@Composable
private fun BackBar(onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun DetailContent(
    vm: DetailViewModel,
    meta: MetaDetail,
    addonId: String,
    repository: StreamRepository,
    listsRepository: CustomListsRepository,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPlayTrailer: (PlaybackRequest) -> Unit = {},
    onOpenActor: (Int, String) -> Unit = { _, _ -> },
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit
) {
    val isSeries = meta.type == "series" && meta.videos.isNotEmpty()
    val seasons = rememberSeasonList(meta)
    // Hoisted out of the LazyColumn DSL: the filter+sort used to re-run
    // on every recomposition of the (stream-driven) content lambda.
    val episodes = remember(meta.videos, vm.selectedSeason) {
        meta.videos.filter { it.season == vm.selectedSeason }
            .sortedWith(compareBy({ it.episode }, { it.title }))
    }
    // Shared scope for the play section
    val scope = rememberCoroutineScope()
    // Unified sheet state: the ⋮ button opens it for THIS title;
    // press & hold on a related poster opens it for that card
    // (owner's fix #6 — one hold behaviour app-wide).
    var showAddToList by remember { mutableStateOf(false) }
    var relatedSheetTarget by remember { mutableStateOf<com.pulsestream.app.data.MetaPreview?>(null) }
    // Shared stream-browser state: addon tabs + filtered list stay in sync as
    // sources stream in progressively.
    val allStreams = (vm.streamsState as? StreamsUiState.Content)?.streams ?: emptyList()
    val browserState = rememberStreamBrowserState(allStreams, repository.settings)
    // Sources dressing (Sample 1): addon name → manifest logo for the
    // source pickers' tabs.
    var addonLogos by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    LaunchedEffect(Unit) { addonLogos = repository.addonLogosByName() }
    // Mini floating source-picker card (the button next to Play opens this
    // instead of scrolling to the sources section).
    var sourcePickerOpen by remember { mutableStateOf(false) }
    // Full-page sources (long-press Play): title header + addon tabs + stream list.
    var fullPageSourceOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    // Zero-edge top (owner's order 2026-10-25): the detail poster runs
    // to the physical top of the display, under the status bar - the
    // time/battery icons sit ON the poster. Same trick Home uses: the
    // column is measured one status-bar taller and placed shifted up
    // by the same amount. The D-A layout itself is unchanged; the
    // hero's top action row gets the inset back as padding so the
    // buttons stay exactly where they were, below the status icons.
    val detailDensity = LocalDensity.current
    val detailStatusDp = with(detailDensity) { WindowInsets.statusBars.getTop(detailDensity).toDp() }
    val detailStatusPx = with(detailDensity) { detailStatusDp.roundToPx() }
    // On TV, land D-pad focus on the Play button when the detail screen opens.
    val isTvDetail = rememberIsTv()
    val playButtonFocus = remember { FocusRequester() }
    var playFocusLanded by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val browsingPrivacy = remember(context) { BrowsingPrivacy(context) }
    var hideEpisodeDetails by remember { mutableStateOf(browsingPrivacy.hideUnrevealedEpisodes()) }
    val episodeShowKey = "$addonId|${meta.type}|${meta.id}"
    var revealedEpisodeIds by remember(episodeShowKey) {
        mutableStateOf(browsingPrivacy.revealedEpisodes(episodeShowKey))
    }
    LaunchedEffect(isTvDetail, playFocusLanded) {
        if (isTvDetail && !playFocusLanded) {
            playFocusLanded = true
            delay(400)
            runCatching { playButtonFocus.requestFocus() }
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .layout { measurable, constraints ->
                val placeable = measurable.measure(
                    constraints.copy(
                        minHeight = constraints.maxHeight + detailStatusPx,
                        maxHeight = constraints.maxHeight + detailStatusPx
                    )
                )
                layout(placeable.width, placeable.height) {
                    placeable.place(0, -detailStatusPx)
                }
            },
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            // Hero (v0.14.18, owner's approved detail sample): the
            // BACKDROP runs full-bleed and fades into the page
            // background; the title's LOGO artwork sits centred over
            // the lower hero with the genres line under it — a large
            // styled title text stands in when the meta carries no
            // logo. The glass back button floats top-left. No poster
            // card and no facts column any more: facts, ratings and
            // the action row live in their own rows below the hero.
            val heroHeight = (LocalConfiguration.current.screenHeightDp * 0.56f).dp
            val heroArt = meta.background?.takeIf { it.isNotBlank() } ?: meta.poster
            val heroPalette = LocalPalette.current
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(heroHeight)
            ) {
                if (heroArt != null) {
                    SafePosterImage(
                        model = heroArt,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                // The fade: clear until ~45%, then into the page
                // background, so the hero melts into the page.
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            0.45f to Color.Transparent,
                            1.0f to heroPalette.background
                        )
                    )
                )
                // A soft top shade so the back button and the status
                // icons stay readable over bright artwork.
                Box(
                    Modifier.fillMaxWidth().height(110.dp).background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.38f), Color.Transparent)
                        )
                    )
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp + detailStatusDp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                    ) {
                        Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                    // Top-right stays empty: lists & tracking live on
                    // the ••• button beside Watch Now (v0.14.7 rule).
                }
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 24.dp, bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val heroLogo = meta.logo?.takeIf { it.isNotBlank() }
                    if (heroLogo != null) {
                        SafePosterImage(
                            model = heroLogo,
                            contentDescription = meta.name,
                            modifier = Modifier
                                .height(84.dp)
                                .widthIn(max = 300.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text(
                            meta.name,
                            style = MaterialTheme.typography.headlineLarge.copy(
                                shadow = Shadow(
                                    color = Color.Black.copy(alpha = 0.65f),
                                    offset = Offset(0f, 4f),
                                    blurRadius = 18f
                                )
                            ),
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (meta.genres.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            meta.genres.take(3).joinToString(" • "),
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD8D8E4),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
        item {
          Column {
            // Action row (v0.14.18, owner's approved detail sample):
            // one big WHITE pill — "Watch Now", no play icon — wired
            // to the same play behaviour as always: the button
            // carries NO loading state and is never disabled, taps
            // during the background prefetch go straight to the
            // player, and a settled zero-stream result surfaces "No
            // stream available" (see onPlayPressed). Long-press opens
            // the full source list. With progress on the title the
            // label becomes "Continue Watching" and the pill carries
            // the resume bar, as before. The round ••• button at the
            // right opens the unified lists/tracking sheet for this
            // title; on series pages the episode bell (v0.14.13)
            // keeps its place in this row.
            val continueWatching by repository.continueWatching.collectAsState(initial = emptyList())
            val resumeState = continueWatching.find { it.videoId == meta.id || it.key.contains(meta.id) }
            val hasResume = resumeState != null && resumeState.positionMs > 0 && resumeState.durationMs > 0
            val resumeProgress = if (hasResume) resumeState!!.positionMs.toFloat() / resumeState!!.durationMs else 0f
            val playText = if (hasResume) "Continue Watching" else "Watch Now"
            val notifyStore = remember { EpisodeNotifyStore(context) }
            var bellExplicit by remember(meta.id) {
                mutableStateOf(notifyStore.explicitChoice(meta.id))
            }
            var bellFollowed by remember(meta.id) { mutableStateOf(false) }
            LaunchedEffect(meta.id) {
                if (meta.type == "series") {
                    bellFollowed = runCatching {
                        repository.followedSeries().any { it.metaId == meta.id }
                    }.getOrDefault(false)
                }
            }
            val bellOn = bellExplicit ?: bellFollowed
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                WatchNowButton(
                    onClick = { vm.onPlayPressed() },
                    onLongClick = { fullPageSourceOpen = true },
                    text = playText,
                    resumeProgress = if (hasResume) resumeProgress else null,
                    modifier = Modifier.weight(1f).focusRequester(playButtonFocus)
                )
                if (meta.type == "series") {
                    Spacer(Modifier.width(10.dp))
                    IconButton(
                        onClick = {
                            val target = !bellOn
                            notifyStore.setChoice(meta.id, target, meta.name)
                            bellExplicit = target
                            // Tap feedback (owner's order 2026-10-29):
                            // say plainly what the bell now means.
                            Toast.makeText(
                                context,
                                if (target) {
                                    "New episode notifications on"
                                } else {
                                    "New episode notifications off"
                                },
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50))
                    ) {
                        Icon(
                            if (bellOn) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                            contentDescription = if (bellOn) {
                                "Episode notifications on"
                            } else {
                                "Episode notifications off"
                            },
                            tint = if (bellOn) LocalPalette.current.accent else TextSecondary
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                IconButton(
                    onClick = { showAddToList = true },
                    modifier = Modifier
                        .background(Color(0xFF15151F), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.10f), CircleShape)
                ) {
                    Icon(
                        Icons.Filled.MoreHoriz,
                        contentDescription = "Lists & tracking",
                        tint = Color.White
                    )
                }
            }
          }
        }
        // Meta row (v0.14.18 sample): year · runtime · certification
        // badge — each part shown only when the meta carries it.
        val metaYear = meta.releaseInfo?.takeIf { it.isNotBlank() }
        val metaRuntime = meta.runtime?.takeIf { it.isNotBlank() }
        val metaCert = meta.certification?.takeIf { it.isNotBlank() }
        if (metaYear != null || metaRuntime != null || metaCert != null) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    metaYear?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    metaRuntime?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    metaCert?.let {
                        Text(
                            it,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary,
                            modifier = Modifier
                                .border(1.5.dp, Color(0xFF8A8A9C), RoundedCornerShape(6.dp))
                                .padding(horizontal = 9.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
        // Ratings row (v0.14.18 sample; v0.14.20): IMDb from the
        // meta, TMDB when enrichment supplied a vote, plus the
        // MDBList-sourced scores PMeta serves. No row at all when
        // the title has none of them.
        if (!meta.imdbRating.isNullOrBlank() || !meta.tmdbRating.isNullOrBlank() ||
            !meta.traktRating.isNullOrBlank() || !meta.rtRating.isNullOrBlank() ||
            !meta.rtAudienceRating.isNullOrBlank() || !meta.metacriticRating.isNullOrBlank() ||
            !meta.letterboxdRating.isNullOrBlank() || !meta.mdblistRating.isNullOrBlank()
        ) {
            item {
                DetailRatingsRow(meta)
            }
        }
        // Crew lines (v0.14.18 sample): Director / Writer from the
        // meta's credits, when present.
        if (!meta.director.isNullOrBlank() || !meta.writer.isNullOrBlank()) {
            item {
                Column(Modifier.padding(horizontal = 16.dp).padding(top = 16.dp)) {
                    meta.director?.takeIf { it.isNotBlank() }?.let { director ->
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(color = TextSecondary)) { append("Director:  ") }
                                append(director)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                    meta.writer?.takeIf { it.isNotBlank() }?.let { writer ->
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(color = TextSecondary)) { append("Writer:  ") }
                                append(writer)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
        // Synopsis (v0.14.18 sample): the overview under the crew
        // lines, folded to four lines with a plain "Show More ▾"
        // under it ("Show Less ▴" folds it back). No block at all
        // when the meta carries no description.
        if (!meta.description.isNullOrBlank()) {
            item {
                var synopsisExpanded by remember(meta.id) { mutableStateOf(false) }
                var synopsisOverflows by remember(meta.id) { mutableStateOf(false) }
                Column(Modifier.padding(horizontal = 16.dp).padding(top = 14.dp)) {
                    Text(
                        meta.description!!.trim(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        maxLines = if (synopsisExpanded) Int.MAX_VALUE else 4,
                        overflow = TextOverflow.Ellipsis,
                        onTextLayout = { layout ->
                            if (!synopsisExpanded) {
                                synopsisOverflows = layout.hasVisualOverflow
                            }
                        }
                    )
                    if (synopsisOverflows) {
                        Text(
                            if (synopsisExpanded) "Show Less ▴" else "Show More ▾",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier
                                .padding(top = 5.dp)
                                .clickable { synopsisExpanded = !synopsisExpanded }
                        )
                    }
                }
            }
        }
        // No tracking sections on the detail page (owner's fix,
        // v0.14.7): Simkl/Trakt/MDBList live only in the press-and-hold
        // sheet on poster cards; the detail page stays clean.
        // Cast row: directly under the new top blocks. Uses the
        // serving meta's standard cast, never one provider's:
        // photo + character when the meta carries them, initial-
        // letter circles for names-only cast, and no row at all when
        // the meta has no cast.
        if (meta.cast.isNotEmpty()) {
            item(key = "cast") {
                Text(
                    "Cast",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                )
                // One chip per person (PLAVIO-D): the serving meta can
                // list the same actor twice — two roles, or a repeated
                // name in a keyless list where every id is 0. The raw
                // list crashed this row with a duplicate lazy key
                // ("Key 0_<name> was already used").
                val castRowMembers = remember(meta.cast) { dedupeCastMembers(meta.cast) }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(
                        castRowMembers,
                        key = { index, actor ->
                            if (actor.id > 0) "person_${actor.id}"
                            else "person_${actor.name}_${actor.character ?: ""}_$index"
                        }
                    ) { _, actor ->
                        // Actors with a TMDB person id open the rich
                        // /person page; names-only actors (keyless meta
                        // addons) open the name-search fallback page —
                        // actor pages must work with ANY meta addon
                        // (owner's order 2026-10-26), not only titles
                        // served by PlavioMeta.
                        val clickable = actor.name.isNotBlank()
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(72.dp)
                                .then(
                                    if (clickable) {
                                        Modifier.clickable {
                                            onOpenActor(actor.id, actor.name)
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                        ) {
                            if (!actor.photo.isNullOrBlank()) {
                                SafePosterImage(
                                    model = actor.photo,
                                    contentDescription = actor.name,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .liquidGlass(CircleShape)
                                )
                            } else {
                                // Names-only cast: an initial-letter
                                // circle instead of a face photo.
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .liquidGlass(CircleShape)
                                ) {
                                    Text(
                                        text = actorInitials(actor.name),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                actor.name,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                            if (!actor.character.isNullOrBlank()) {
                                Text(
                                    actor.character!!,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        // Genre chips: the synopsis that used to share this item
        // moved above Watch Now (item 34); the chips keep their
        // own quiet row under the cast row.
        if (meta.genres.isNotEmpty()) {
            item {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    meta.genres.take(4).forEach { genre ->
                        Text(
                            genre,
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimary,
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(50))
                                .padding(horizontal = 11.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
        // Trailers section: horizontal cards like "You May Like"
        if (meta.trailerStreams.isNotEmpty()) {
            item(key = "trailers") {
                Text(
                    "Trailers",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // v0.14.19 sweep: index-suffixed — an addon
                    // listing the same trailer ytId twice would
                    // otherwise duplicate the lazy key (PLAVIO-H
                    // class). Same treatment the episode list uses.
                    itemsIndexed(meta.trailerStreams, key = { index, t -> "${t.ytId}_$index" }) { _, trailer ->
                        var resolving by remember { mutableStateOf(false) }
                        var trailerUnavailable by remember { mutableStateOf(false) }
                        Card(
                            modifier = Modifier
                                .width(160.dp)
                                .clickable(enabled = !resolving) {
                                    if (resolving) return@clickable
                                    resolving = true
                                    trailerUnavailable = false
                                    scope.launch {
                                        try {
                                            val playback = withTimeoutOrNull(30_000) {
                                                TrailerResolver.resolvePlayback(trailer.ytId)
                                            }
                                            if (playback != null) {
                                                onPlayTrailer(
                                                    PlaybackRequest(
                                                        streamUrl = playback.videoUrl,
                                                        title = "${meta.name} — Trailer",
                                                        poster = meta.background ?: meta.poster,
                                                        videoId = "trailer_${trailer.ytId}",
                                                        isMovie = meta.type == "movie",
                                                        type = meta.type,
                                                        streamLabel = "TRAILER",
                                                        metaId = meta.id,
                                                        isTrailer = true,
                                                        mergeAudioUrl = playback.audioUrl
                                                    )
                                                )
                                            } else {
                                                trailerUnavailable = true
                                            }
                                        } finally {
                                            resolving = false
                                        }
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A24))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // YouTube thumbnail as poster
                                SafePosterImage(
                                    model = "https://i.ytimg.com/vi/${trailer.ytId}/hqdefault.jpg",
                                    contentDescription = trailer.title,
                                    modifier = Modifier.fillMaxSize()
                                )
                                // Dark overlay for play button visibility
                                Box(
                                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                if (resolving) {
                                    OrbitDots(modifier = Modifier.size(26.dp))
                                } else {
                                    Icon(
                                        Icons.Filled.PlayArrow,
                                        contentDescription = "Play trailer",
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                                }
                            }
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = trailer.title,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                if (trailerUnavailable) {
                                    Text(
                                        "Trailer stream unavailable",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        // ("You May Like" rail removed, owner's pick 2026-10-24:
        // PlavioMeta's "More like this" rows below replace it —
        // they work for every user, not only TMDB-key holders.)
        // (Available Streams button removed — long-press Play opens the source picker.)
        item {
            if (vm.streamsState is StreamsUiState.Error) {
                Text(
                    (vm.streamsState as StreamsUiState.Error).message,
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
        if (isSeries) {
            item(key = "seasons") {
                // Seasons (v0.14.18, owner's approved series sample):
                // poster cards in a row — the season's own poster
                // when season data carries one, else the series
                // poster; the picked season is outlined in white and
                // its name sits under the card.
                Column {
                    Text(
                        "Seasons",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(seasons, key = { it }) { season ->
                            val isSel = vm.selectedSeason == season
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(112.dp).clickable { vm.selectSeason(season, meta) }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(112f / 158f)
                                        .then(
                                            if (isSel) Modifier.border(
                                                2.5.dp, Color.White, RoundedCornerShape(12.dp)
                                            ) else Modifier.border(
                                                1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(12.dp)
                                            )
                                        )
                                        .clip(RoundedCornerShape(12.dp))
                                ) {
                                    SafePosterImage(
                                        model = meta.seasonPosters[season] ?: meta.poster ?: meta.background,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    if (season == 0) "Specials" else "Season $season",
                                    color = if (isSel) TextPrimary else TextSecondary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
            item(key = "episodes_header") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Text(
                        "Episodes",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.updateShuffle(!vm.shuffleEpisodes) }) {
                        Icon(
                            Icons.Filled.Shuffle,
                            contentDescription = if (vm.shuffleEpisodes) "Shuffle on" else "Shuffle off",
                            tint = if (vm.shuffleEpisodes) LocalPalette.current.accent else TextSecondary
                        )
                    }
                    if (!isTvDetail) {
                        FilterChip(
                            selected = hideEpisodeDetails,
                            onClick = {
                                val enabled = !hideEpisodeDetails
                                hideEpisodeDetails = enabled
                                browsingPrivacy.setHideUnrevealedEpisodes(enabled)
                            },
                            label = { Text("Hide spoilers") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
                                selectedLabelColor = TextPrimary,
                                containerColor = Color.White.copy(alpha = 0.06f),
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }
            itemsIndexed(episodes, key = { index, video -> "ep_${video.id}_$index" }) { _, video ->
                val watchedKeys by com.pulsestream.app.data.WatchedMarks.keys.collectAsState()
                val selected = vm.selectedVideo?.id == video.id
                val episodeRevealed = video.id in revealedEpisodeIds
                val hideDetails = BrowsingPrivacy.shouldHideEpisodeDetails(hideEpisodeDetails, episodeRevealed)
                EpisodeCardRow(
                    video = video,
                    selected = selected,
                    hideDetails = hideDetails,
                    isWatched = com.pulsestream.app.data.WatchedMarks.episodeKey(meta.id, video.season, video.episode) in watchedKeys,
                    spoilerMode = hideEpisodeDetails,
                    isTv = isTvDetail,
                    // Episode tap plays direct (v0.14.14, item 1):
                    // no select-then-sources step.
                    onClick = { vm.playEpisodeDirect(video) },
                    onReveal = { revealedEpisodeIds = browsingPrivacy.setEpisodeRevealed(episodeShowKey, video.id, true) },
                    onHide = { revealedEpisodeIds = browsingPrivacy.setEpisodeRevealed(episodeShowKey, video.id, false) }
                )
            }
            item(key = "episodes_spacer") {
                Spacer(Modifier.height(8.dp))
            }
        }
        // Show Details — glass fact tiles (owner's Sample A pick, 2026-10-24).
        // Only facts the meta actually carries are shown.
        val detailTiles = buildDetailTiles(meta)
        if (detailTiles.size >= 2) {
            item(key = "show_details") {
                Column {
                    Text(
                        "Show Details",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    Column(
                        Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        detailTiles.chunked(3).forEach { rowTiles ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                rowTiles.forEach { (label, value) ->
                                    Column(
                                        modifier = Modifier.weight(1f)
                                            .liquidGlass(RoundedCornerShape(14.dp))
                                            .padding(horizontal = 11.dp, vertical = 10.dp)
                                    ) {
                                        Text(
                                            label.uppercase(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.2.sp,
                                            maxLines = 1
                                        )
                                        Spacer(Modifier.height(3.dp))
                                        Text(
                                            value,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                repeat(3 - rowTiles.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        // "More like this" + "More from <actor>" rows from PlavioMeta.
        // Quietly absent when the endpoint has nothing (e.g. keyless mode).
        vm.relatedState.forEach { section ->
            item(key = "related_${section.id}") {
                com.pulsestream.app.ui.components.SectionTitle(section.title)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(section.metas.distinctBy { it.id }, key = { it.id }) { related ->
                        com.pulsestream.app.ui.components.PosterCard(
                            meta = related,
                            // launchSingleTop-style: tapping the title that's already
                            // open is a no-op, so the backstack never stacks the
                            // same detail destination twice.
                            onClick = {
                                if (related.id != meta.id || related.type != meta.type) {
                                    onOpenDetail(addonId, related.type, related.id)
                                }
                            },
                            onLongClick = { relatedSheetTarget = related }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    // Mini floating source-picker card: same-size button next to Play opens
    // this with a springy pop instead of scrolling to the sources section.
    // The popup gets the full stream list and runs its own per-addon tabs
    // (the inline section below keeps the shared "All" browser state).
    val streamsContent = vm.streamsState as? StreamsUiState.Content
    // Download confirmation dialog state
    var downloadStream by remember { mutableStateOf<StreamItem?>(null) }
    SourcePickerPopup(
        visible = sourcePickerOpen,
        streams = allStreams,
        loading = vm.streamsState is StreamsUiState.Loading,
        loadingMore = streamsContent?.loadingMore == true,
        errorMessage = (vm.streamsState as? StreamsUiState.Error)?.message,
        onDismiss = { sourcePickerOpen = false },
        onRetry = { vm.retryStreams() },
        onPick = { stream ->
            sourcePickerOpen = false
            if (streamsContent != null) {
                startPlayback(vm, repository, stream, streamsContent.subtitles, streamsContent.streams, onPlay)
            }
        },
        onDownload = { stream -> downloadStream = stream },
        settings = repository.settings,
        addonLogos = addonLogos
    )

    // Source picker (long-press Play): Bottom Sheet (Sample M;
    // owner's pick v0.12.14) — slides over the detail page, which
    // stays dimmed behind it. Same picker body, sheet mode.
    if (fullPageSourceOpen) {
      ModalBottomSheet(
        onDismissRequest = { fullPageSourceOpen = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = LocalPalette.current.background,
        dragHandle = { BottomSheetDefaults.DragHandle() }
      ) {
        FullPageSourcePicker(
            inSheet = true,
            meta = meta,
            streams = allStreams,
            loading = vm.streamsState is StreamsUiState.Loading,
            loadingMore = streamsContent?.loadingMore == true,
            errorMessage = (vm.streamsState as? StreamsUiState.Error)?.message,
            onBack = { fullPageSourceOpen = false },
            onRetry = { vm.retryStreams() },
            onPick = { stream ->
                fullPageSourceOpen = false
                if (streamsContent != null) {
                    startPlayback(vm, repository, stream, streamsContent.subtitles, streamsContent.streams, onPlay)
                }
            },
            onDownload = { stream -> downloadStream = stream },
            settings = repository.settings,
            addonLogos = addonLogos
        )
      }
    }

    // Download confirmation dialog
    downloadStream?.let { stream ->
        DownloadConfirmDialog(
            stream = stream,
            title = meta.name ?: "Video",
            posterUrl = meta.poster,
            onDismiss = { downloadStream = null },
            type = meta.type,
            imdbId = resolvePlaybackIds(meta, vm.selectedVideo).imdbId,
            bundledSubtitles = streamsContent?.subtitles ?: emptyList(),
            repository = repository
        )
    }

    // "Add to list" bottom sheet
    if (showAddToList) {
        AddToListSheet(
            listsRepository = listsRepository,
            addonId = addonId,
            type = meta.type,
            metaId = meta.id,
            name = meta.name ?: "Video",
            poster = meta.poster,
            onDismiss = { showAddToList = false },
            repository = repository,
            year = meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
            rating = meta.imdbRating?.takeIf { it.isNotBlank() }
        )
    }
    // Same sheet for a press-and-held related poster (fix #6).
    relatedSheetTarget?.let { related ->
        AddToListSheet(
            listsRepository = listsRepository,
            addonId = addonId,
            type = related.type,
            metaId = related.id,
            name = related.name,
            poster = related.poster,
            onDismiss = { relatedSheetTarget = null },
            repository = repository,
            year = related.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
            rating = related.imdbRating?.takeIf { it.isNotBlank() }
        )
    }
}

@Composable
private fun rememberSeasonList(meta: MetaDetail): List<Int> {
    return meta.videos.map { it.season }.distinct().sorted()
}

// ---------------------------------------------------------------------------
// Detail helpers
// ---------------------------------------------------------------------------

/**
 * One entry per person for the cast row (PLAVIO-D). Identity is the
 * TMDB person id when the meta carries one, otherwise the name —
 * keyless cast lists give every member id 0, so the name is the only
 * identity there. First billing wins; a later duplicate only fills
 * in a photo/character the kept entry lacks.
 */
private fun dedupeCastMembers(cast: List<CastMember>): List<CastMember> {
    val byIdentity = LinkedHashMap<String, CastMember>()
    for (member in cast) {
        val identity = if (member.id > 0) {
            "id:${member.id}"
        } else {
            "name:${member.name.trim().lowercase()}"
        }
        val existing = byIdentity[identity]
        if (existing == null) {
            byIdentity[identity] = member
        } else {
            byIdentity[identity] = existing.copy(
                photo = existing.photo ?: member.photo,
                character = existing.character ?: member.character
            )
        }
    }
    return byIdentity.values.toList()
}

/** "Tom Hanks" -> "TH" — the mark on a names-only cast circle. */
private fun actorInitials(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    if (parts.isEmpty()) return "?"
    val first = parts.first().first().uppercaseChar()
    return if (parts.size > 1) {
        "$first${parts.last().first().uppercaseChar()}"
    } else {
        "$first"
    }
}

private data class PlaybackIds(
    val imdbId: String,
    val season: Int,
    val episode: Int,
    val isMovie: Boolean
)

/**
 * Cinemeta ids are IMDb ids ("tt1234567"); series episode ids look like
 * "tt1234567:1:2". Everything downstream (IntroDB, subtitle search) wants
 * the bare IMDb id plus season/episode.
 */
private fun resolvePlaybackIds(meta: MetaDetail, video: Video?): PlaybackIds {
    val vid = video?.id ?: meta.id
    // v0.14.19: for TMDB-native metas the raw split yields the garbage
    // id "tmdb" — prefer the meta's real tt id when it carries one.
    val imdbId = vid.substringBefore(":").takeIf { it.startsWith("tt") }
        ?: meta.imdbId?.takeIf { it.startsWith("tt") }
        ?: meta.defaultVideoId?.takeIf { it.startsWith("tt") }
        ?: vid.substringBefore(":")
    return PlaybackIds(
        imdbId = imdbId,
        season = video?.season ?: 0,
        episode = video?.episode ?: 0,
        isMovie = meta.type == "movie"
    )
}


/** Rounded-rectangle shape for the picker card — follows the app theme. */
private val PickerShape = RoundedCornerShape(20.dp)

/**
 * Per-addon tab state for the source picker. Unlike the shared inline
 * [com.pulsestream.app.ui.components.StreamBrowserState] (which has an "All"
 * tab), the picker shows one tab per addon and selects the first addon by
 * default.
 */
@Stable
private class PickerTabState(
    val tabs: List<StreamTab>,
    val selectedKey: String?,
    val filtered: List<StreamItem>,
    val onSelect: (String) -> Unit
)

@Composable
private fun rememberPickerTabState(
    streams: List<StreamItem>,
    addonLogos: Map<String, String> = emptyMap()
): PickerTabState {
    var selectedKey by remember { mutableStateOf<String?>(null) }
    // groupBy preserves first-encounter order; the stream list arrives
    // prioritized (starred addons first), so the first tab is the top addon.
    val tabs = remember(streams, addonLogos) {
        streams.groupBy { it.addonKey() }
            .map { (key, list) -> StreamTab(key, key, list.size, logo = addonLogos[key]) }
    }
    val safeKey = if (tabs.any { it.key == selectedKey }) selectedKey else tabs.firstOrNull()?.key
    val filtered = remember(streams, safeKey) {
        if (safeKey == null) emptyList() else streams.filter { it.addonKey() == safeKey }
    }
    return remember(tabs, safeKey, filtered) {
        PickerTabState(tabs, safeKey, filtered) { selectedKey = it }
    }
}

/**
 * Mini floating source-picker card. The same-size button next to Play pops
 * this open with a springy scale+fade+rise animation; tapping the dimmed
 * scrim or the close button dismisses it the same way in reverse.
 *
 * The card is a plain rounded rectangle in the app theme's panel color.
 * A tab row lists one tab per addon ("Name · count"); tapping a tab filters
 * the list to that addon's streams. On stream failure the REAL error is shown
 * with a working Retry instead of the generic "no sources" line.
 */
@Composable
private fun SourcePickerPopup(
    visible: Boolean,
    streams: List<StreamItem>,
    loading: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    onPick: (StreamItem) -> Unit,
    onDownload: ((StreamItem) -> Unit)? = null,
    settings: com.pulsestream.app.data.SettingsStore? = null,
    addonLogos: Map<String, String> = emptyMap(),
    loadingMore: Boolean = false
) {
    if (rememberIsTv()) {
        // TV: show the picker in its OWN window (a Compose Dialog), exactly like
        // Nuvio TV does. A same-window overlay leaves D-pad focus on the screen
        // underneath; a dialog window keeps every key press inside the popup,
        // Back dismisses it, and focus returns to the Source button afterwards.
        if (visible) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = onDismiss,
                properties = androidx.compose.ui.window.DialogProperties(
                    usePlatformDefaultWidth = false
                )
            ) {
                SourcePickerOverlay(true, streams, loading, errorMessage, onDismiss, onRetry, onPick, onDownload, settings, addonLogos, loadingMore)
            }
        }
    } else {
        SourcePickerOverlay(visible, streams, loading, errorMessage, onDismiss, onRetry, onPick, onDownload, settings, addonLogos, loadingMore)
    }
}

@Composable
private fun SourcePickerOverlay(
    visible: Boolean,
    streams: List<StreamItem>,
    loading: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    onPick: (StreamItem) -> Unit,
    onDownload: ((StreamItem) -> Unit)? = null,
    settings: com.pulsestream.app.data.SettingsStore? = null,
    addonLogos: Map<String, String> = emptyMap(),
    loadingMore: Boolean = false
) {
    val springy = androidx.compose.animation.core.spring<Float>(
        dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
        stiffness = androidx.compose.animation.core.Spring.StiffnessMedium
    )
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.fadeIn(
            animationSpec = androidx.compose.animation.core.tween(180)
        ),
        exit = androidx.compose.animation.fadeOut(
            animationSpec = androidx.compose.animation.core.tween(150)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .focusProperties { canFocus = false } // scrim must never take D-pad focus
                .clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.animation.AnimatedVisibility(
                visible = visible,
                enter = androidx.compose.animation.scaleIn(
                    initialScale = 0.82f, animationSpec = springy
                ) + androidx.compose.animation.fadeIn(
                    animationSpec = androidx.compose.animation.core.tween(160)
                ) + androidx.compose.animation.slideInVertically(
                    initialOffsetY = { it / 6 },
                    animationSpec = androidx.compose.animation.core.tween(220)
                ),
                exit = androidx.compose.animation.scaleOut(
                    targetScale = 0.9f,
                    animationSpec = androidx.compose.animation.core.tween(140)
                ) + androidx.compose.animation.fadeOut(
                    animationSpec = androidx.compose.animation.core.tween(140)
                )
            ) {
                // Stop scrim clicks from falling through the card.
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .heightIn(max = 520.dp)
                        .clip(PickerShape)
                        .background(LocalPalette.current.panel)
                        .border(1.dp, GlassBorder, PickerShape)
                        .focusProperties { canFocus = false } // only the rows inside are focus stops
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                ) {
                    PickerCardBody(
                        streams = streams,
                        loading = loading,
                        errorMessage = errorMessage,
                        onDismiss = onDismiss,
                        onRetry = onRetry,
                        onPick = onPick,
                        onDownload = onDownload,
                        settings = settings,
                        addonLogos = addonLogos,
                        loadingMore = loadingMore
                    )
                }
            }
        }
    }
}

/**
 * Picker card content: header, per-addon tab row, then the filtered stream
 * list (or the loading / real-error / empty states).
 */
@Composable
private fun PickerCardBody(
    streams: List<StreamItem>,
    loading: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    onPick: (StreamItem) -> Unit,
    onDownload: ((StreamItem) -> Unit)? = null,
    settings: com.pulsestream.app.data.SettingsStore? = null,
    addonLogos: Map<String, String> = emptyMap(),
    loadingMore: Boolean = false
) {
    val palette = LocalPalette.current
    val tabState = rememberPickerTabState(streams, addonLogos)
    val isTv = rememberIsTv()
    val firstTabFocus = remember { FocusRequester() }
    // On TV, land D-pad focus on the first addon tab once tabs exist.
    var tvFocusLanded by remember { mutableStateOf(false) }
    LaunchedEffect(isTv, tabState.tabs.isNotEmpty(), tvFocusLanded) {
        if (isTv && tabState.tabs.isNotEmpty() && !tvFocusLanded) {
            tvFocusLanded = true
            delay(300)
            runCatching { firstTabFocus.requestFocus() }
        }
    }

    Column(Modifier.fillMaxWidth().tvSheetFocus()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Choose source",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.weight(1f))
            // Same count/load capsule as the two main Sources
            // surfaces (owner's order 2026-10-27).
            com.pulsestream.app.ui.components.StreamCountCapsule(
                total = streams.size,
                loading = loading || loadingMore,
                onRefresh = onRetry
            )
            IconButton(onClick = onDismiss) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close",
                    tint = TextSecondary
                )
            }
        }
        if (tabState.tabs.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(tabState.tabs, key = { _, tab -> tab.key }) { index, tab ->
                    val selected = tab.key == tabState.selectedKey
                    Box(
                        modifier = Modifier
                            .then(if (index == 0) Modifier.focusRequester(firstTabFocus) else Modifier)
                            .tvFocusRing(RoundedCornerShape(50))
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (selected) palette.accent.copy(alpha = 0.22f)
                                else Color.White.copy(alpha = 0.06f)
                            )
                            .border(
                                1.dp,
                                if (selected) palette.accent else GlassBorder,
                                RoundedCornerShape(50)
                            )
                            .clickable { tabState.onSelect(tab.key) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Sample 1 dressing: addon logo on the tab
                            // (letter tile fallback), toggleable in
                            // Settings → Streams.
                            if (settings?.streamAddonLogos != false) {
                                com.pulsestream.app.ui.components.TabLogoOrLetter(
                                    name = tab.label, logo = tab.logo
                                )
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                text = "${tab.label} · ${tab.count}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) TextPrimary else TextSecondary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        when {
            loading && streams.isEmpty() -> {
                Box(
                    Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    OrbitDots(modifier = Modifier.size(34.dp))
                }
            }
            errorMessage != null && streams.isEmpty() -> {
                // Audit #24: show the REAL stream error (not "no sources yet"),
                // with a Retry that re-queries every addon.
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
                    Text(
                        errorMessage,
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) {
                        Text("Retry", color = Color(0xFF0A0A12), fontWeight = FontWeight.Bold)
                    }
                }
            }
            streams.isEmpty() -> {
                Text(
                    "No sources found yet — they appear here as each addon answers.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
                )
            }
            else -> {
                StreamList(
                    streams = tabState.filtered,
                    onPick = onPick,
                    modifier = Modifier.heightIn(max = 400.dp),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    onDownload = onDownload,
                    showSizeBadge = settings?.streamSizeBadges ?: true,
                    sizeBadgeTop = settings?.streamBadgeTop ?: false,
                    capsuleConfig = settings?.streamCapsuleConfig()
                        ?: com.pulsestream.app.ui.components.StreamCapsuleConfig()
                )
            }
        }
    }
}


/** Full-screen picker opened by long-pressing Play. All content scrolls on small screens. */
@Composable
internal fun FullPageSourcePicker(
    meta: MetaDetail,
    streams: List<StreamItem>,
    loading: Boolean,
    errorMessage: String?,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onPick: (StreamItem) -> Unit,
    onDownload: ((StreamItem) -> Unit)? = null,
    inSheet: Boolean = false,
    settings: com.pulsestream.app.data.SettingsStore? = null,
    addonLogos: Map<String, String> = emptyMap(),
    /** True while addons are still answering after the first results. */
    loadingMore: Boolean = false
) {
    val palette = LocalPalette.current
    val browserState = rememberStreamBrowserState(streams, settings, addonLogos = addonLogos)
    androidx.activity.compose.BackHandler(onBack = onBack)
    val pickerBody: @Composable () -> Unit = {
        Column(
            (if (inSheet) Modifier.fillMaxWidth().fillMaxHeight(0.85f)
             else Modifier.fillMaxSize()).tvSheetFocus()
        ) {
            if (inSheet) {
                // Sheet header: the title (owner's order 2026-10-25:
                // the "choose a source" suffix removed) + the stream
                // count capsule (owner's order 2026-10-27: total
                // loaded at the top, orbit loader while addons are
                // still answering, tap = force refresh). The sheet's
                // drag handle sits above this; no back / close row
                // and no banner inside the sheet.
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        meta.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    com.pulsestream.app.ui.components.StreamCountCapsule(
                        total = streams.size,
                        loading = loading || loadingMore,
                        onRefresh = onRetry
                    )
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Text(
                        "Choose stream",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    com.pulsestream.app.ui.components.StreamCountCapsule(
                        total = streams.size,
                        loading = loading || loadingMore,
                        onRefresh = onRetry
                    )
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.Close, contentDescription = "Close stream picker", tint = TextSecondary)
                    }
                }
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize().testTag("stream-picker-list"),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                if (!inSheet) {
                item(key = "poster") {
                    // Design I banner (user's approved design): full-width backdrop
                    // with gradient into the page background, title + count below.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    ) {
                        SafePosterImage(
                            model = meta.background ?: meta.poster,
                            contentDescription = "${meta.name} banner",
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            palette.background.copy(alpha = 0.7f),
                                            palette.background
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Text(
                                meta.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 2
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = com.pulsestream.app.ui.components.accentStarText(
                                    listOfNotNull(
                                        "${streams.size} sources available",
                                        meta.releaseInfo?.takeIf { it.isNotBlank() },
                                        meta.imdbRating?.takeIf { it.isNotBlank() }?.let { "★ $it" }
                                ).joinToString(" · "),
                                LocalPalette.current.accent
                            ),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
                }
                item(key = "filters") {
                    Text(
                        "Add-ons",
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    AddonTabs(browserState, compact = true)
                    com.pulsestream.app.ui.components.QualityPills(
                        browserState,
                        compact = true,
                        modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            // (v0.14.14, item 5: the "Recommended
                            // streams" heading went with the removed
                            // filter chip — Recommended is a row tag.)
                            browserState.selectedQuality?.let { "$it streams" } ?: "Available streams",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "${browserState.filtered.size} results",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                    if ((loading || loadingMore) && streams.isNotEmpty()) {
                        androidx.compose.material3.LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            color = palette.accent
                        )
                    }
                }
                when {
                    loading && streams.isEmpty() -> item(key = "loading") {
                        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            OrbitDots(modifier = Modifier.size(34.dp))
                        }
                    }
                    errorMessage != null && streams.isEmpty() -> item(key = "error") {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp)) {
                            Text(errorMessage, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                                Text("Retry", color = Color(0xFF0A0A12), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    streams.isEmpty() -> item(key = "empty") {
                        Text(
                            "No sources found yet — they appear here as each addon answers.",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    browserState.filtered.isEmpty() -> item(key = "no-matches") {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text(
                                "No streams match this add-on and quality. Choose Any or another add-on.",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            androidx.compose.material3.TextButton(onClick = {
                                browserState.onSelectTab(com.pulsestream.app.ui.components.STREAM_TAB_ALL)
                                browserState.onSelectQuality(null)
                            }) { Text("Clear filters", color = palette.accent) }
                        }
                    }
                    else -> streamListItems(
                        streams = browserState.filtered,
                        onPick = onPick,
                        onDownload = onDownload,
                        compact = true,
                        showSizeBadge = browserState.showSizeBadges,
                        sizeBadgeTop = browserState.sizeBadgeTop,
                        capsuleConfig = browserState.capsuleConfig
                    )
                }
            }
        }
    }
    if (inSheet) pickerBody() else GlowBackground { pickerBody() }
}

/** TMDB recommendation item. */
/** Facts for the Show Details tiles — only what the meta actually carries. */
private fun buildDetailTiles(meta: MetaDetail): List<Pair<String, String>> {
    val tiles = mutableListOf<Pair<String, String>>()
    meta.status?.takeIf { it.isNotBlank() }?.let { tiles += "Status" to it }
    // Series: a year range from episode air dates says more than the bare year.
    val release = if (meta.type == "series" && meta.videos.isNotEmpty()) {
        val years = meta.videos.mapNotNull { it.released?.take(4)?.toIntOrNull() }
        if (years.isNotEmpty()) {
            val lo = years.min()
            val hi = years.max()
            if (lo != hi) "$lo\u2013$hi" else meta.releaseInfo ?: lo.toString()
        } else meta.releaseInfo
    } else meta.releaseInfo
    release?.takeIf { it.isNotBlank() }?.let { tiles += "Release" to it }
    meta.certification?.takeIf { it.isNotBlank() }?.let { tiles += "Certification" to it }
    meta.country?.takeIf { it.isNotBlank() }?.let { tiles += "Origin" to it }
    meta.runtime?.takeIf { it.isNotBlank() }?.let { tiles += "Runtime" to it }
    meta.network?.takeIf { it.isNotBlank() }?.let { tiles += "Network" to it }
    meta.production?.takeIf { it.isNotBlank() }?.let { tiles += "Production" to it }
    meta.imdbRating?.takeIf { it.isNotBlank() }?.let { tiles += "IMDb" to it }
    if (meta.genres.isNotEmpty()) tiles += "Genres" to meta.genres.take(2).joinToString(", ")
    return tiles.take(6)
}

/** "2011-09-22T00:00:00.000Z" -> "Sep 22, 2011"; anything odd passes through short. */
private fun formatEpisodeDate(released: String?): String {
    if (released.isNullOrBlank()) return ""
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val parts = released.take(10).split("-")
    if (parts.size == 3) {
        val year = parts[0]
        val month = parts[1].toIntOrNull()
        val day = parts[2].toIntOrNull()
        if (month != null && month in 1..12 && day != null) {
            return "${months[month - 1]} $day, $year"
        }
    }
    return released.take(10)
}

/**
 * Watch Now pill (v0.14.18, owner's approved detail sample): one big
 * WHITE pill, bold dark label, NO play icon. Tap plays, long-press
 * opens the full source list — the same gestures the old glass
 * PlayButton carried. With resume progress the label reads "Continue
 * Watching" and a slim progress bar rides the pill's bottom edge.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WatchNowButton(
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    text: String,
    resumeProgress: Float?,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    Box(
        modifier = modifier
            .height(56.dp)
            .tvFocusRing(RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.Black,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
        if (resumeProgress != null && resumeProgress > 0f) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Black.copy(alpha = 0.15f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(resumeProgress.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(LocalPalette.current.accent)
                )
            }
        }
    }
}

/**
 * Ratings row (v0.14.18, owner's approved detail sample): value over
 * a small uppercase label, hairlines above and below. IMDb comes from
 * the meta itself; TMDB shows when TMDB enrichment supplied a vote
 * (rendered on the 0–100 scale, as in the sample). Since v0.14.20 the
 * row also carries the MDBList per-source scores PMeta serves (Trakt,
 * RT, RT Audience, Metacritic, Letterboxd) and the MDBList aggregate —
 * the owner wants at least five ratings where data exists. A rating
 * the title doesn't have simply has no slot — no placeholders.
 */
@Composable
private fun DetailRatingsRow(meta: MetaDetail) {
    val slots = buildList {
        meta.imdbRating?.takeIf { it.isNotBlank() }?.let { add(it to "IMDb") }
        meta.tmdbRating?.takeIf { it.isNotBlank() }?.let { raw ->
            val scaled = raw.toDoubleOrNull()?.let { Math.round(it * 10).toString() } ?: raw
            add(scaled to "TMDB")
        }
        // MDBList per-source scores (v0.14.20): already on the
        // 0–100 scale, shown as served. Missing source, no slot.
        meta.traktRating?.takeIf { it.isNotBlank() }?.let { add(it to "Trakt") }
        meta.rtRating?.takeIf { it.isNotBlank() }?.let { add(it to "RT") }
        meta.metacriticRating?.takeIf { it.isNotBlank() }?.let { add(it to "Metacritic") }
        meta.rtAudienceRating?.takeIf { it.isNotBlank() }?.let { add(it to "RT Audience") }
        meta.letterboxdRating?.takeIf { it.isNotBlank() }?.let { add(it to "Letterboxd") }
        meta.mdblistRating?.takeIf { it.isNotBlank() }?.let { add(it to "MDBList") }
    }.take(5) // v0.14.22 (owner): five ratings max — the locked five
    // lead (IMDb, TMDB, Trakt, RT, Metacritic); a missing one lets
    // the next source slide in so the row still fills to five.
    if (slots.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 18.dp)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.07f)))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 13.dp)) {
            slots.forEach { (value, label) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    OneLineFitText(
                        value,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    OneLineFitText(
                        label.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        letterSpacing = 0.6.sp
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.07f)))
    }
}

/**
 * One line, always (v0.14.21): the text never wraps — when it would
 * overflow its slot it shrinks its font until it fits. The ratings
 * row leans on this at the full eight slots, where "RT Audience"
 * and "Letterboxd" used to spill onto a second line.
 */
@Composable
private fun OneLineFitText(
    text: String,
    style: androidx.compose.ui.text.TextStyle,
    color: Color,
    fontWeight: FontWeight? = null,
    letterSpacing: androidx.compose.ui.unit.TextUnit =
        androidx.compose.ui.unit.TextUnit.Unspecified
) {
    var fontSize by remember(text, style) { mutableStateOf(style.fontSize) }
    Text(
        text,
        style = style.copy(fontSize = fontSize),
        color = color,
        fontWeight = fontWeight,
        letterSpacing = letterSpacing,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { result ->
            if (result.hasVisualOverflow && fontSize > 6.sp) {
                fontSize = (fontSize.value * 0.88f).sp
            }
        }
    )
}

/**
 * Episode card (v0.14.18, owner's approved series sample): a wide row
 * card — still on the left with the "S3 E1" badge and the WATCHED
 * pill, title / date / two-line overview on the right. Tap plays the
 * episode directly (v0.14.14 behaviour); spoiler mode keeps the same
 * hide/reveal contract the old rail cards had.
 */
@Composable
private fun EpisodeCardRow(
    video: Video,
    selected: Boolean,
    hideDetails: Boolean,
    isWatched: Boolean,
    spoilerMode: Boolean,
    isTv: Boolean,
    onClick: () -> Unit,
    onReveal: () -> Unit,
    onHide: () -> Unit
) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 7.dp)
            .background(Color.White.copy(alpha = 0.045f), RoundedCornerShape(18.dp))
            .border(
                if (selected) 1.5.dp else 1.dp,
                if (selected) palette.accent else Color.White.copy(alpha = 0.06f),
                RoundedCornerShape(18.dp)
            )
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(112.dp)
                .clip(RoundedCornerShape(12.dp))
        ) {
            if (!hideDetails && video.thumbnail != null) {
                SafePosterImage(
                    video.thumbnail, null, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.linearGradient(listOf(Color(0xFF2A3448), Color(0xFF121826)))
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "S${video.season} E${video.episode}",
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Box(
                Modifier.padding(7.dp)
                    .background(Color.Black.copy(alpha = 0.78f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 7.dp, vertical = 3.dp)
            ) {
                Text(
                    "S${video.season} E${video.episode}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            if (isWatched && !hideDetails) {
                WatchedPill(Modifier.align(Alignment.BottomStart).padding(7.dp))
            }
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            if (hideDetails) {
                Text(
                    "Episode details hidden",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                if (!isTv) {
                    TextButton(onClick = onReveal) { Text("Reveal") }
                }
            } else {
                Text(
                    video.title,
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val dateText = formatEpisodeDate(video.released)
                if (dateText.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        dateText,
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (!video.overview.isNullOrBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(
                        video.overview!!,
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (spoilerMode && !isTv) {
                    Text(
                        "Hide details",
                        color = palette.accent,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 6.dp).clickable(onClick = onHide)
                    )
                }
            }
        }
    }
}
