package com.pulsestream.app

import android.app.PictureInPictureParams
import android.app.PendingIntent
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.lerp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.withContext
import com.pulsestream.app.data.AppConfig
import com.pulsestream.app.data.update.UpdateChecker
import com.pulsestream.app.data.AddonShare
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.data.PlayerChoice
import com.pulsestream.app.data.CustomListsRepository
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.notifications.EpisodeNotifications
import com.pulsestream.app.data.notifications.NotificationNav
import com.pulsestream.app.util.ExternalPlayer
import com.pulsestream.app.data.update.UpdateInfo
import com.pulsestream.app.ui.components.CrashReportDialog
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.components.AnnouncementPrompt
import com.pulsestream.app.ui.components.UpdatePrompt
import com.pulsestream.app.ui.nav.Routes
import com.pulsestream.app.ui.screens.LiveScreen
import com.pulsestream.app.ui.screens.OnboardingScreen
import com.pulsestream.app.ui.screens.ProfilesScreen
import com.pulsestream.app.ui.screens.SplashScreen
import com.pulsestream.app.ui.screens.SettingsScreen
import com.pulsestream.app.ui.screens.AccountScreen
import com.pulsestream.app.ui.screens.AddonsScreen
import com.pulsestream.app.ui.screens.CatalogScreen
import com.pulsestream.app.ui.screens.DetailScreen
import com.pulsestream.app.ui.screens.FeedbackScreen
import com.pulsestream.app.ui.screens.DownloadsScreen
import com.pulsestream.app.ui.screens.LibraryScreen
import com.pulsestream.app.ui.screens.PlaybackSettingsScreen
import com.pulsestream.app.ui.screens.ActorScreen
import com.pulsestream.app.ui.screens.StreamsSettingsScreen
import com.pulsestream.app.ui.screens.SubtitleSettingsScreen
import com.pulsestream.app.ui.screens.AppearanceSettingsScreen
import com.pulsestream.app.ui.screens.AboutScreen
import com.pulsestream.app.ui.screens.LicensesScreen
import com.pulsestream.app.ui.screens.HomeScreen
import com.pulsestream.app.ui.screens.PlayerScreen
import com.pulsestream.app.ui.screens.SearchScreen
import com.pulsestream.app.ui.components.MiniTrailerOverlay
import com.pulsestream.app.ui.components.TrailerMiniController
import com.pulsestream.app.ui.components.TrailerPlayerState
import com.pulsestream.app.ui.screens.TrailerPlayerScreen
import com.pulsestream.app.ui.screens.WatchlistScreen
import com.pulsestream.app.ui.screens.ListsScreen
import com.pulsestream.app.ui.screens.ListDetailScreen
import com.pulsestream.app.ui.screens.BackupScreen
import com.pulsestream.app.ui.screens.IntegrationsScreen
import com.pulsestream.app.ui.theme.AccentTheme
import com.pulsestream.app.ui.theme.AppTheme
import com.pulsestream.app.ui.theme.LocalCardCorner
import com.pulsestream.app.ui.theme.LocalPosterCorner
import com.pulsestream.app.ui.theme.LocalPosterScale
import com.pulsestream.app.ui.theme.LocalReduceMotion
import com.pulsestream.app.ui.theme.LocalSpacingScale
import com.pulsestream.app.ui.theme.cardCornersFor
import com.pulsestream.app.ui.theme.paletteForTheme
import com.pulsestream.app.ui.theme.asDark
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.PulseStreamTheme
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.theme.paletteFor
import com.pulsestream.app.ui.tv.TvAddonSetupScreen
import com.pulsestream.app.ui.tv.TvBottomBar
import com.pulsestream.app.ui.tv.rememberIsTv
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import com.pulsestream.app.ui.tv.tvFocusRing

class MainActivity : ComponentActivity() {

    companion object {
        /**
         * True while the player screen is in the composition (set by
         * PlayerScreen's DisposableEffect). Used by onUserLeaveHint to
         * auto-enter PiP only when video is actually playing.
         */
        @Volatile
        var isPlayerActive: Boolean = false

        /**
         * TV remote: Left/Right while the player is open. Value = seek delta
         * in ms (negative = back). PlayerScreen should collect this and call
         * player.seekTo(). (Play/pause reuses [pipToggleRequest].)
         */
        val playerSeekRequest = MutableSharedFlow<Long>(extraBufferCapacity = 4)

        /**
         * Current PiP mode, updated in onPictureInPictureModeChanged.
         * PlayerScreen collects this to hide its overlay UI while floating.
         */
        val pipMode = MutableStateFlow(false)

        /**
         * Incremented when the user dismisses the PiP window with its X:
         * the activity then stops without being destroyed, so nothing else
         * releases playback. PlayerScreen compares against the value it saw
         * at composition and exits (running its dispose teardown) on a bump.
         */
        val pipDismissedCount = MutableStateFlow(0L)

        /** Broadcast action for the PiP window's play/pause RemoteAction. */
        const val ACTION_PIP_TOGGLE = "com.pulsestream.app.ACTION_PIP_TOGGLE"

        /**
         * Intent extra carrying a nav route (e.g. a detail page) requested
         * by a notification tap. MainActivity stashes it on
         * [com.pulsestream.app.data.notifications.NotificationNav]; PulseNav
         * navigates there once past splash/onboarding.
         */
        const val EXTRA_OPEN_ROUTE = "com.pulsestream.app.OPEN_ROUTE"

        /**
         * Last known video dimensions, kept current by PlayerScreen's
         * player listener. Used for the PiP aspect ratio when the user
         * presses Home (onUserLeaveHint has no player access).
         */
        @Volatile
        var pipVideoW: Int = 16

        @Volatile
        var pipVideoH: Int = 9

        /**
         * Last known playing state, kept current by PlayerScreen's player
         * listener so the PiP RemoteAction shows the right icon.
         */
        @Volatile
        var pipIsPlaying: Boolean = true

        /**
         * True from PiP entry until the activity next resumes in
         * fullscreen; lets onStop tell a PiP dismissal (X) apart from a
         * normal backgrounding.
         */
        var wasInPip: Boolean = false

        /**
         * Direct stop hook registered by PlayerScreen while it lives:
         * stops + releases its ExoPlayer immediately. The PiP-dismissal
         * rework (v0.14.4) calls this from the activity, because on the
         * owner's Samsung an X-closed PiP stops the activity without
         * the player screen ever collecting the dismissal counter —
         * its audio then played on until the app was killed.
         */
        @Volatile
        var pipEmergencyStop: (() -> Unit)? = null

        /**
         * Fired by the PiP play/pause RemoteAction's broadcast receiver.
         * PlayerScreen collects this and toggles the ExoPlayer.
         */
        val pipToggleRequest = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

        /**
         * PiP windows only support aspect ratios roughly between 1:2.39 and
         * 2.39:1 — clamp anything wider/taller (e.g. a 9:16 portrait video
         * stays portrait, an extreme pano gets clamped, never crashes).
         */
        fun clampPipRatio(w: Int, h: Int): Rational {
            if (w <= 0 || h <= 0) return Rational(16, 9)
            val r = w.toFloat() / h.toFloat()
            return when {
                r > 2.39f -> Rational(239, 100)
                r < 1f / 2.39f -> Rational(100, 239)
                else -> Rational(w, h)
            }
        }

        /**
         * Builds PiP params with the video's (clamped) aspect ratio and a
         * play/pause RemoteAction so the floating window has transport
         * controls like YouTube's PiP.
         */
        fun buildPipParams(context: Context, playing: Boolean): PictureInPictureParams {
            val toggleIntent = PendingIntent.getBroadcast(
                context,
                0,
                Intent(ACTION_PIP_TOGGLE).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val action = if (playing) {
                RemoteAction(
                    Icon.createWithResource(context, android.R.drawable.ic_media_pause),
                    "Pause",
                    "Pause video",
                    toggleIntent
                )
            } else {
                RemoteAction(
                    Icon.createWithResource(context, android.R.drawable.ic_media_play),
                    "Play",
                    "Play video",
                    toggleIntent
                )
            }
            return PictureInPictureParams.Builder()
                .setAspectRatio(clampPipRatio(pipVideoW, pipVideoH))
                .setActions(listOf(action))
                .build()
        }
    }

    /**
     * Receives the PiP window's play/pause RemoteAction taps and forwards
     * them to PlayerScreen via [pipToggleRequest].
     */
    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_PIP_TOGGLE) {
                pipToggleRequest.tryEmit(Unit)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // No dark scrim behind the gesture bar (owner's order
        // 2026-10-22): Android's navigation-bar contrast enforcement
        // paints a black layer behind the system navigation area, so
        // the app background never reached the physical bottom edge
        // around the floating dock. Off — the app's own background
        // now runs edge to edge, around and below the capsule.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        handleAddonDeepLink(intent)
        handleNotificationRoute(intent)
        handleTitleLink(intent)
        // Safety net: (re)schedule the episode check on cold start.
        // Idempotent (KEEP) and a no-op when alerts are disabled.
        EpisodeNotifications.ensureScheduled(this)
        com.pulsestream.app.data.notifications.MovieNotifications.ensureScheduled(this)
        // Anonymous-stats heartbeat (the owner's own open-source
        // counting, 2026-10-22): while the app is on screen, one tiny
        // ping every 5 minutes — this is what makes "online now" on
        // his stats server true. RESUMED only, so time in the
        // background never counts as online.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (true) {
                    delay(5 * 60 * 1000L)
                    com.pulsestream.app.data.AppStats.heartbeat(this@MainActivity)
                }
            }
        }
        // PiP play/pause RemoteAction receiver (explicit intent, not exported).
        val pipFilter = IntentFilter(ACTION_PIP_TOGGLE)
        ContextCompat.registerReceiver(this, pipReceiver, pipFilter, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            val app = applicationContext as PulseApp
            // If the last run crashed, show the log with a Copy button.
            var crashReport by remember { mutableStateOf<String?>(null) }
            LaunchedEffect(Unit) {
                crashReport = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    app.readCrashReport()
                }
            }
            if (crashReport != null) {
                CrashReportDialog(
                    report = crashReport!!,
                    onDismiss = {
                        app.clearCrashReport()
                        crashReport = null
                    }
                )
            }
            // Theme state: bumped whenever Settings changes accent/AMOLED so the
            // whole app re-skins without restarting the activity.
            var themeTick by remember { mutableIntStateOf(0) }
            val palette = remember(themeTick) {
                // Six frosted themes (2026-10-25); weak devices get the
                // solid version of the chosen theme automatically.
                val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val lowEnd = am.isLowRamDevice || am.memoryClass <= 64
                paletteForTheme(
                    AppTheme.byName(app.settings.appTheme),
                    AccentTheme.byName(app.settings.accentName),
                    frosted = !lowEnd
                )
            }
            val isLight = palette.light
            PulseStreamTheme(palette = palette, isLight = isLight) {
                // Appearance extras (v0.14.39, owner's A–H list):
                // text size rides the density fontScale so every sp
                // scales; poster size / card corners / spacing /
                // reduced-motion ride their own locals into the
                // shared components. All re-read on themeTick, so a
                // change in Settings → Appearance applies live via
                // the same onThemeChanged bump the accent uses.
                // Defaults reproduce the pre-.39 look exactly.
                val appearanceSettings = app.settings
                val (cardCorner, posterCorner) = cardCornersFor(appearanceSettings.cardCorners)
                val baseDensity = LocalDensity.current
                androidx.compose.runtime.CompositionLocalProvider(
                    LocalDensity provides androidx.compose.ui.unit.Density(
                        baseDensity.density,
                        baseDensity.fontScale * appearanceSettings.textScaleFactor()
                    ),
                    LocalPosterScale provides appearanceSettings.posterScale(),
                    LocalCardCorner provides cardCorner,
                    LocalPosterCorner provides posterCorner,
                    LocalSpacingScale provides appearanceSettings.spacingScale(),
                    LocalReduceMotion provides appearanceSettings.reduceAnimations
                ) {
                    PulseNav(onThemeChanged = { themeTick++ })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAddonDeepLink(intent)
        handleNotificationRoute(intent)
        handleTitleLink(intent)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        // Auto-backup to Plavio Cloud when app goes to background (if logged in)
        // Note: CloudManager needs settings/repository; auto-backup is handled
        // via the AccountScreen's lifecycle instead to avoid circular dependencies.
    }

    /**
     * Refreshes the PiP window's play/pause RemoteAction icon. Called by
     * PlayerScreen's player listener on every play-state change; the params
     * only take effect while the video is actually floating.
     */
    fun updatePipActions(playing: Boolean) {
        pipIsPlaying = playing
        if (isInPictureInPictureMode) {
            setPictureInPictureParams(buildPipParams(this, playing))
        }
    }

    /**
     * Auto-enter Picture-in-Picture when the user presses Home/recents while
     * a video is playing (v0.9.0+). Only fires for explicit user leave, not
     * for in-app navigation, and honors the pipEnabled setting.
     */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!isPlayerActive) return
        // D-c: never float a player that is only loading or paused —
        // pipIsPlaying is kept current by the player listener and reset
        // to false when a player screen composes, so true here means
        // playback was actually confirmed.
        if (!pipIsPlaying) return
        val app = applicationContext as PulseApp
        if (!app.settings.pipEnabled) return
        enterPictureInPictureMode(buildPipParams(this, pipIsPlaying))
    }

    /**
     * Tracks PiP state so PlayerScreen can hide its overlay UI while the
     * video floats (the system draws its own PiP controls instead).
     * On entering PiP, (re)applies params so the play/pause RemoteAction
     * is present with the correct icon from the first frame.
     */
    private val pipHandler = Handler(Looper.getMainLooper())

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipMode.value = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            wasInPip = true
            setPictureInPictureParams(buildPipParams(this, pipIsPlaying))
        } else if (wasInPip) {
            // PiP exit has two shapes: expand back to fullscreen (the
            // activity returns to RESUMED and onResume clears wasInPip)
            // or the X close (the activity heads for stopped, and on
            // some devices — the owner's Samsung — nothing in the
            // player screen runs again). Re-check shortly: still not
            // resumed means dismissed, so stop playback from here.
            pipHandler.postDelayed({
                if (wasInPip && !isInPictureInPictureMode &&
                    !lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
                ) {
                    handlePipDismissal()
                }
            }, 600L)
        }
    }

    /**
     * Runs once per PiP dismissal: signals the player screen (counter)
     * AND stops playback directly through its registered hook, so the
     * audio dies even when the stopped activity never recomposes.
     */
    private fun handlePipDismissal() {
        if (!wasInPip) return
        wasInPip = false
        pipDismissedCount.value += 1
        runCatching { pipEmergencyStop?.invoke() }
    }

    override fun onStart() {
        super.onStart()
        // Time-in-app (owner's order 2026-10-25): arm the session clock;
        // onStop reports the real foreground duration to Stats.
        com.pulsestream.app.data.AppStats.sessionStarted()
        // Continue Watching widget (v0.14.13, item 10): re-read the
        // rows whenever the app comes to the foreground.
        com.pulsestream.app.ui.widget.CwWidgetUpdater.refresh(this)
    }

    override fun onResume() {
        super.onResume()
        // Back in fullscreen (e.g. PiP expanded): the next onStop is a
        // normal backgrounding, not a PiP dismissal.
        if (!isInPictureInPictureMode) wasInPip = false
    }

    override fun onStop() {
        super.onStop()
        com.pulsestream.app.data.AppStats.sessionEnded(this)
        // PiP dismissed with X: activity stops but is NOT destroyed and
        // the player screen never leaves composition — the dismissal
        // handler stops playback directly instead of relying on the
        // screen hearing about it (owner's device reports 2026-10-25
        // and 2026-10-26 — the counter-only path did not fire on his
        // Samsung, audio played until the app was killed).
        if (wasInPip && !isInPictureInPictureMode) {
            handlePipDismissal()
        }
    }

    /**
     * plavio-addons:// deep link (manifest VIEW intent-filter): stash the
     * bundle link on the repository. PulseNav navigates to the Addons tab and
     * AddonsScreen opens its import dialog pre-filled — both cold start and
     * while the app is already running funnel through here.
     */
    private fun handleAddonDeepLink(intent: Intent?) {
        if (intent == null) return
        val dataString = intent.dataString ?: return
        // stremio:// links (e.g. from "Install" buttons on addon pages):
        // convert to https:// manifest URL and add directly.
        if (dataString.startsWith("stremio://", ignoreCase = true)) {
            val manifestUrl = "https://" + dataString.removePrefix("stremio://").removePrefix("stremio://")
            // Handle encoded URLs: stremio://addon/<encoded-url>
            val cleanUrl = if (manifestUrl.contains("/addon/")) {
                try {
                    java.net.URLDecoder.decode(manifestUrl.substringAfter("/addon/"), "UTF-8")
                } catch (_: Exception) {
                    manifestUrl.substringAfter("/addon/")
                }
            } else {
                manifestUrl
            }
            if (cleanUrl.startsWith("https://")) {
                val app = applicationContext as PulseApp
                // Store as pending manifest URL for AddonsScreen to pick up
                app.repository.setPendingManifestUrl(cleanUrl)
                return
            }
        }
        // Validates the link actually carries a decodable bundle.
        if (AddonShare.bundleFromIntent(intent).isNullOrEmpty()) return
        val link = intent.dataString ?: return
        val app = applicationContext as PulseApp
        app.repository.setPendingAddonBundle(link)
    }

    /** Last title link consumed, so a redelivered intent can't re-route. */
    private var lastTitleLink: String? = null

    /**
     * Title deep links (v0.14.13, item 7):
     *   plavio://title/<type>/<id>
     *   https://plavio.site/t/<type>/<id>
     * Both open the title's detail page through the same
     * NotificationNav stash the episode notifications use; the
     * detail resolves with addonId "" (the any-addon meta walk),
     * exactly like a Library Upcoming tap. <id> is the title's meta
     * id (an IMDb tt id wherever the title has one).
     */
    private fun handleTitleLink(intent: Intent?) {
        val data = intent?.data ?: return
        val link = data.toString()
        if (link == lastTitleLink) return
        val segments = data.pathSegments
        val type: String?
        val id: String?
        when {
            data.scheme == "plavio" && data.host == "title" -> {
                type = segments.getOrNull(0)
                id = segments.getOrNull(1)
            }
            data.scheme == "https" && data.host == "plavio.site" &&
                segments.firstOrNull() == "t" -> {
                type = segments.getOrNull(1)
                id = segments.getOrNull(2)
            }
            else -> return
        }
        if ((type != "movie" && type != "series") || id.isNullOrBlank()) return
        lastTitleLink = link
        NotificationNav.pendingRoute.value =
            com.pulsestream.app.ui.nav.Routes.detail("", type, id)
    }

    /**
     * Notification tap (episode alert): the PendingIntent carries
     * [EXTRA_OPEN_ROUTE] with a detail-page route. Stash it on
     * NotificationNav; PulseNav navigates there once past
     * splash/onboarding — same pattern as the addon deep link above.
     * The extra is consumed (removed) so a later onNewIntent without a
     * route doesn't re-trigger the navigation.
     */
    private fun handleNotificationRoute(intent: Intent?) {
        val route = intent?.getStringExtra(EXTRA_OPEN_ROUTE)?.takeIf { it.isNotBlank() }
            ?: return
        intent.removeExtra(EXTRA_OPEN_ROUTE)
        NotificationNav.pendingRoute.value = route
    }
}

private data class Tab(
    val route: String,
    val label: String,
    val icon: ImageVector,
)
/**
 * One item in the floating dock (v0.12.7, owner's pick — sample A
 * "Glass Shrink"): the icon WITH its name under it, proper size and
 * even gaps. [labelFraction] is the tray's open amount (1 = open,
 * 0 = shrunk): as the tray shrinks on scroll-down the name is eaten —
 * its slot collapses and it fades and crops away — until only the
 * icon remains; scrolling up grows it back. The accent pill sits
 * behind the whole segment when selected.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun DockItem(
    tab: Tab,
    selected: Boolean,
    labelFraction: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    labelSizeDp: Float = 10f,
    // Press-and-hold (Home tab only, v0.14.14: opens the Home
    // catalogs picker). Null = plain tap-only item, as before.
    onLongClick: (() -> Unit)? = null
) {
    val palette = LocalPalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp)
            .clip(RoundedCornerShape(50))
            .then(
                if (selected) {
                    if (palette.light) {
                        // Sample C (owner's pick 2026-10-26): the settled
                        // pill, steady from the first touch — the accent
                        // tint pre-blended over the capsule's own backing
                        // into opaque stops.
                        val pillBase = Color(0xFFF7F3EC)
                        Modifier.background(
                            Brush.verticalGradient(
                                listOf(
                                    lerp(pillBase, palette.accent, 0.32f),
                                    lerp(pillBase, palette.accent, 0.12f)
                                )
                            ),
                            RoundedCornerShape(50)
                        )
                    } else {
                        // Dark glass pill (owner's correction 2026-10-31,
                        // Nuvio reference): a soft charcoal glass oval —
                        // a light wash over the dark capsule, subtle rim —
                        // with pure-white icon + label (see below). The
                        // white frosted pill (Sample B) was rejected on
                        // device the same evening: too white, washed out.
                        // The readability half of Sample B stays: content
                        // is pure white, never the old near-black
                        // accentText that made the selected tab unreadable.
                        Modifier
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.White.copy(alpha = 0.22f),
                                        Color.White.copy(alpha = 0.13f)
                                    )
                                ),
                                RoundedCornerShape(50)
                            )
                            .border(
                                1.dp,
                                Color.White.copy(alpha = 0.16f),
                                RoundedCornerShape(50)
                            )
                    }
                } else {
                    Modifier
                }
            )
            // No ripple: the capsule highlight on the selected tab is the
            // feedback; a square ripple clashes with the pill shape.
            .then(
                if (onLongClick != null) {
                    Modifier.combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClick,
                        onLongClick = onLongClick
                    )
                } else {
                    Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClick
                    )
                }
            )
            .padding(horizontal = 3.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            tab.icon,
            contentDescription = tab.label,
            tint = when {
                // Pure white on the dark glass pill (readability fix).
                selected && !palette.light -> Color.White
                selected -> palette.accentText
                palette.light -> palette.textPrimary.copy(alpha = 0.72f)
                else -> Color.White.copy(alpha = 0.82f)
            },
            modifier = Modifier.size(22.dp)
        )
        // The name slot: eaten as the tray shrinks — height collapses
        // (driven by the same spring value as the capsule's own size),
        // the text fades and is cropped by the closing slot.
        Box(
            modifier = Modifier
                .height((15 * labelFraction).dp)
                .clipToBounds()
                .graphicsLayer { alpha = labelFraction },
            contentAlignment = Alignment.Center
        ) {
            Text(
                tab.label,
                // Label size (v0.12.16, owner's order): computed by
                // the dock from the tray's real width and passed in
                // as DP, then converted back to SP through the
                // density — so the drawn size is the same on every
                // device and ignores the system font-size setting.
                // That setting is what still clipped "Downloads" to
                // "Downlo…" on another phone at a fixed 10sp. The
                // full word now always fits, on every screen.
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = with(LocalDensity.current) { labelSizeDp.dp.toSp() }
                ),
                color = when {
                    // Pure white on the dark glass pill (readability fix).
                    selected && !palette.light -> Color.White
                    selected -> palette.accentText
                    palette.light -> palette.textPrimary.copy(alpha = 0.72f)
                    else -> Color.White.copy(alpha = 0.82f)
                },
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Video surfaces (player, trailer players) stay on the dark cinematic palette in both theme modes. */
@Composable
private fun DarkVideoSurface(content: @Composable () -> Unit) {
    PulseStreamTheme(palette = LocalPalette.current.asDark(), isLight = false, content = content)
}

/** Bottom-dock tabs; labels come from string resources so they follow the app language. */
@Composable
private fun appTabs() = listOf(
    Tab(Routes.HOME, stringResource(R.string.nav_home), Icons.Filled.Home),
    Tab(Routes.SEARCH, stringResource(R.string.nav_search), Icons.Filled.Search),
    Tab(Routes.LIBRARY, stringResource(R.string.nav_library), Icons.Filled.MenuBook),
    // v0.14.25 (items 5 + 6): seat order is Home / Search / Library /
    // Profile, and the Profile seat opens the full Settings root —
    // every settings category as visible rows, with the account card
    // at the top opening Account & Sync. In v0.14.24 this seat opened
    // the Account screen directly, so from Profile the owner could
    // reach ONLY Account & Sync and no settings at all (his verdict:
    // "There is no settings at all, only account and black shell").
    Tab(Routes.SETTINGS, stringResource(R.string.nav_profile), Icons.Filled.Person)
)

@Composable
private fun PulseNav(onThemeChanged: () -> Unit) {
    val systemMotionEnabled = remember { com.pulsestream.app.ui.screens.systemAnimationsEnabled() }
    val navController = rememberNavController()
    val appContext = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val app = appContext as PulseApp
    val repository = remember { app.repository }
    val listsRepository = remember { CustomListsRepository(app.database) }
    // Activity context for the "Ask every time" player chooser dialog.
    val activity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity

    // In-app update check (GitLab releases) on every launch; silent when nothing new.
    var updateInfo by remember { mutableStateOf<UpdateInfo?>(null) }
    LaunchedEffect(Unit) {
        // Only a found update is assigned: the min-version route
        // below may land its prompt first, and a null here must not
        // wipe it. (When nothing else sets it, null-over-null is the
        // same state as before.)
        UpdateChecker.check(appContext)?.let { updateInfo = it }
    }

    // Remote app config (AppConfig): the announcement and the
    // minimum-version floor ride the StateFlow its background reader
    // maintains. Both stay silent when the config is absent or
    // unreachable — the compiled-in defaults reproduce the pre-config
    // behaviour exactly.
    val appConfig by AppConfig.state.collectAsState()
    // Minimum-version floor: the running build is older than the
    // oldest supported versionCode, so route into the EXISTING
    // updater prompt (UpdatePrompt below) via a forced check that
    // skips the daily throttle / major-only filter but keeps the
    // updater's cadence (auto-check toggle, "Later" skip). Runs once
    // per composition, and again if a later config raises the floor.
    var minVersionPromptDone by remember { mutableStateOf(false) }
    LaunchedEffect(appConfig.minVersionCode) {
        if (!minVersionPromptDone && appConfig.minVersionCode > BuildConfig.VERSION_CODE) {
            minVersionPromptDone = true
            if (updateInfo == null) {
                updateInfo = UpdateChecker.checkMinVersion(appContext)
            }
        }
    }
    // Announcement: shown once per id (the seen-id persists in
    // AppConfig's prefs); a local dismissal state makes the dialog
    // close instantly, before the prefs write is observed.
    var dismissedAnnouncementId by remember { mutableStateOf<String?>(null) }
    val visibleAnnouncement = appConfig.announcement?.takeIf {
        updateInfo == null && it.id != dismissedAnnouncementId &&
            it.id != AppConfig.seenAnnouncementId(appContext)
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val isTv = rememberIsTv()

    // Mini floating trailer player (YouTube-style): one trailer at a time,
    // floats above all tabs. Mobile only — TV keeps the full player.
    val trailerMini = remember { TrailerMiniController() }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
                trailerMini.pauseForBackground()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Deep link: a plavio-addons:// link opened the app (cold start or while
    // running — MainActivity stashed it via handleAddonDeepLink). Jump to the
    // Addons tab; AddonsScreen picks up the pending bundle and opens its
    // import dialog pre-filled. Skipped on splash/onboarding so the startup
    // flow isn't hijacked — the effect refires once the real destination
    // lands. Same nav options as the dock (single top, state kept).
    val pendingBundle by repository.pendingAddonBundle.collectAsState()
    val pendingManifestUrl by repository.pendingManifestUrl.collectAsState()
    LaunchedEffect(pendingBundle, pendingManifestUrl, currentDestination) {
        val route = currentDestination?.route
        if ((pendingBundle != null || pendingManifestUrl != null) && route != null &&
            route != Routes.SPLASH && route != Routes.ONBOARDING
        ) {
            navController.navigate(Routes.ADDONS) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    // Notification tap (episode alert): MainActivity stashed a detail route
    // via handleNotificationRoute. Navigate once past splash/onboarding,
    // then clear so it fires exactly once.
    val pendingRoute by NotificationNav.pendingRoute.collectAsState()
    LaunchedEffect(pendingRoute, currentDestination) {
        val route = pendingRoute
        val dest = currentDestination?.route
        if (route != null && dest != null &&
            dest != Routes.SPLASH && dest != Routes.ONBOARDING
        ) {
            NotificationNav.pendingRoute.value = null
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    if (isTv) {
        // TV: bottom-center nav bar (replaced the old left rail). The bar is
        // hidden on splash/onboarding/player, same as the rail was. Content
        // gets bottom padding so the bar never covers anything; the bar is
        // drawn below the content in a Column, not overlaid.
        val barHiddenRoutes = setOf(Routes.SPLASH, Routes.ONBOARDING, Routes.PLAYER)
        val destRoutes = currentDestination?.hierarchy?.mapNotNull { it.route }.orEmpty()
        val showBar = destRoutes.none { it in barHiddenRoutes }
        val barFocus = remember { FocusRequester() }
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(LocalPalette.current.background)
        ) {
            // Left-side Home button, vertically centered: jumps home and
            // parks focus on the bar.
            if (showBar) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(start = 12.dp, end = 8.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    IconButton(
                        onClick = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                            runCatching { barFocus.requestFocus() }
                        },
                        modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                    ) {
                        Icon(
                            Icons.Filled.Home,
                            contentDescription = "Home",
                            tint = TextSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    PulseNavGraph(navController, repository, listsRepository, onThemeChanged)
                }
                if (showBar) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        TvBottomBar(
                            currentDestination = currentDestination,
                            barFocus = barFocus,
                            onNavigate = { route ->
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    } else {
        val tabs = appTabs()
        // Press-and-hold Home → Home catalogs picker (v0.14.14).
        var showHomeCatalogPicker by remember { mutableStateOf(false) }
        val showBottomBar = tabs.any { it.route == currentDestination?.route }
        // Scroll-aware nav: compact (icons only) when scrolling down, like Nuvio.
        var compactNav by remember { mutableStateOf(false) }
        // Real frosted-glass backdrop (v0.12.20): the page content is
        // recorded once into a graphics layer, then a second layer
        // replays it with a RenderEffect blur; the dock draws that
        // blurred copy behind itself (clipped to the capsule, aligned
        // by root positions). Needs Android 12+ (RenderEffect); older
        // phones keep the darker solid tint instead.
        val deviceBlurSupported = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
        // Dock glass blur toggle (v0.14.39, appearance item H): OFF
        // stops the backdrop blur entirely and the dock falls back to
        // a solid dark capsule (heavier tint branch below).
        val dockBlurEnabled = repository.settings.dockGlassBlur
        val blurSupported = deviceBlurSupported && dockBlurEnabled
        val contentLayer = androidx.compose.ui.graphics.rememberGraphicsLayer()
        val blurLayer = androidx.compose.ui.graphics.rememberGraphicsLayer()
        var contentOriginPx by remember { mutableStateOf(Offset.Zero) }
        var dockOriginPx by remember { mutableStateOf(Offset.Zero) }
        val nestedScrollConnection = remember {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    // available.y < 0 means scrolling down (content moving up).
                    // Hysteresis: only collapse on a clear downward scroll,
                    // only expand on a clear upward scroll — the nav stays
                    // minimized until the user scrolls up (no dancing).
                    if (available.y < -10) compactNav = true
                    else if (available.y > 10) compactNav = false
                    return Offset.Zero
                }
            }
        }
        Box(Modifier.fillMaxSize().nestedScroll(nestedScrollConnection)) {
            // Full-height content (v0.12.2; Scaffold removed v0.12.11):
            // even with no bottomBar, the Scaffold kept reserving the
            // bottom system inset for its content area — a solid strip
            // under the floating dock (owner's on-device note). A plain
            // Box now hosts the content: only the status-bar top inset
            // is applied (screens already expect exactly that — Home
            // shifts its list up by the same amount for the immersive
            // hero), and the content owns every remaining pixel down
            // to the physical bottom edge, scrolling under the dock.
            // Tab screens carry their own extra bottom list padding so
            // the last row can scroll clear of the capsule.
            val shellDensity = LocalDensity.current
            val shellStatusTop = with(shellDensity) {
                WindowInsets.statusBars.getTop(shellDensity).toDp()
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(LocalPalette.current.background)
                    .padding(top = shellStatusTop)
                    .onGloballyPositioned { contentOriginPx = it.positionInRoot() }
                    .drawWithContent {
                        if (!blurSupported || !showBottomBar) {
                            drawContent()
                        } else {
                            contentLayer.record { this@drawWithContent.drawContent() }
                            drawLayer(contentLayer)
                            val r = 22.dp.toPx()
                            blurLayer.renderEffect = androidx.compose.ui.graphics.BlurEffect(
                                r, r, androidx.compose.ui.graphics.TileMode.Clamp
                            )
                            blurLayer.record { drawLayer(contentLayer) }
                        }
                    }
            ) {
                PulseNavGraph(navController, repository, listsRepository, onThemeChanged, trailerMini)
            }
        // Floating dock (v0.12.10, owner's order): no longer a
        // Scaffold bottomBar — the reserved solid strip at the
        // bottom is GONE. The screen's usable area runs the full
        // height and cards scroll underneath the capsule, which
        // floats over the content as an overlay. Tab screens
        // already carry ~104dp bottom list padding, so the last
        // row can still scroll clear of the capsule.
            if (showBottomBar) {
                // One spring drives the whole shrink (v0.12.7, owner's
                // pick: sample A "Glass Shrink"). A single Animatable
                // morphs the capsule's width + height a little — the
                // tray NEVER folds into a Home pill: scrolling down
                // shrinks it slightly from both sides and from
                // top/bottom and eats the tab names (icons stay);
                // scrolling up grows it back with the names. Softly
                // damped spring: gentle settle, no bounce jitter. The
                // hysteresis latch above (compactNav) owns the trigger.
                val foldAnim = remember { Animatable(0f) }
                // Reduced animations (v0.14.39, appearance item G):
                // the shrink snaps instead of springing.
                val reduceMotion = LocalReduceMotion.current
                LaunchedEffect(compactNav, reduceMotion) {
                    val target = if (compactNav) 1f else 0f
                    if (reduceMotion) {
                        foldAnim.snapTo(target)
                    } else {
                        foldAnim.animateTo(
                            targetValue = target,
                            animationSpec = spring(dampingRatio = 0.92f, stiffness = 205f)
                        )
                    }
                }
                val fold = foldAnim.value
                // Seated at the bottom edge (v0.12.15) and lifted a
                // little in v0.12.16 (owner's order 2026-10-22): the
                // capsule floated 6dp off the physical bottom — a
                // stretch for one-hand thumbs. It now floats 16dp
                // up. The content still owns every pixel to the
                // physical edge and scrolls underneath it; only the
                // capsule's seat moved.
                BoxWithConstraints(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        // v0.12.18: lifted above the system gesture pill /
                        // 3-button bar (navigationBarsPadding) plus a 10dp
                        // float, so the capsule never collides with system
                        // buttons — while the CONTENT still runs to the
                        // physical edge behind it (clear bottom, like Nuvio).
                        .navigationBarsPadding()
                        .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // End states (v0.12.7): open = nearly the FULL
                    // width (only the 16dp side gaps), 62dp tall, five
                    // tabs with icon + name spread evenly; shrunk = 85%
                    // of that width, 47dp tall, names eaten, icons only.
                    // v0.14.25 (item 5): the shrink no longer applies —
                    // the owner's pill standard is icon + text label on
                    // every seat at all times, and the 47dp shrunk
                    // height cannot hold a label, so the capsule keeps
                    // its open size and the labels stay (labelFraction
                    // is pinned to 1f at the DockItem call below). The
                    // fold spring above is left running but unread.
                    val capsuleWidth = maxWidth
                    val capsuleHeight = 62.dp
                    // Per-tab width in the OPEN tray drives the label
                    // size (v0.12.16): narrower tray → slightly smaller
                    // labels, so all five full words always fit.
                    val perTabDp = (maxWidth / 4).value
                    val labelSizeDp = when {
                        perTabDp >= 76f -> 10.5f
                        perTabDp >= 70f -> 10f
                        perTabDp >= 64f -> 9.5f
                        perTabDp >= 58f -> 9f
                        else -> 8.5f
                    }
                    // Capsule-fitted black backing (v0.12.9; RESTORED
                    // v0.12.15 on the owner's correction): a black pill
                    // EXACTLY the capsule's size and shape sits directly
                    // behind it — same animated width/height, so it
                    // shrinks and grows in lockstep and never shows
                    // outside the capsule at all. The v0.12.13 removal
                    // was a misread: the owner's "solid black" was
                    // never this pill — it is the dead screen space
                    // BELOW the capsule, fixed in v0.12.15 by seating
                    // the dock at the very bottom edge.
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .width(capsuleWidth)
                            .height(capsuleHeight)
                            .clip(RoundedCornerShape(50))
                            .onGloballyPositioned { dockOriginPx = it.positionInRoot() }
                            .drawBehind {
                                if (blurSupported) {
                                    val d = dockOriginPx - contentOriginPx
                                    translate(-d.x, -d.y) {
                                        drawLayer(blurLayer)
                                    }
                                }
                            }
                            // Dark tint over the blur keeps white icons/labels
                            // readable on bright posters; heavier when no blur.
                            .background(
                                // Normal mode (Sample A): the backing flips
                                // to white glass and the dock icons go dark.
                                if (LocalPalette.current.light) Color.White.copy(alpha = 0.82f)
                                // Dark frosted glass (owner's correction
                                // 2026-10-31, his Nuvio screenshot): the white
                                // frost wash (Sample B) read washed-out on
                                // device — "Glass is white which looks bad".
                                // The capsule glass is DARK: a deep black
                                // tint over the real blur, Nuvio-style.
                                else if (blurSupported) Color.Black.copy(alpha = 0.38f)
                                // Blur switched OFF in Appearance
                                // (v0.14.39 item H): solid dark dock.
                                else if (!dockBlurEnabled) Color.Black.copy(alpha = 0.92f)
                                else Color.Black.copy(alpha = 0.48f),
                                RoundedCornerShape(50)
                            )
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Transparent,
                        shadowElevation = 0.dp,
                        modifier = Modifier
                            .width(capsuleWidth)
                            .height(capsuleHeight)
                    ) {
                        Row(
                            // Liquid-glass dock: sheen + accent glow + specular rim.
                            // v0.12.7 (owner's order): LIGHT tinted glass
                            // with blur — darken nearly gone (0.03), frost
                            // up (0.12) — over the fitted black backing,
                            // so the buttons show properly. Other glass untouched.
                            modifier = Modifier
                                .liquidGlass(RoundedCornerShape(50), frost = 0.12f, darken = 0.03f)
                                .fillMaxSize()
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            tabs.forEach { tab ->
                                val selected =
                                    currentDestination?.hierarchy?.any { it.route == tab.route } == true
                                val isHome = tab.route == Routes.HOME
                                // All four tabs stay, always (v0.12.7;
                                // dock cut to four in v0.12.28 — Live moved
                                // to a Home top-right pill and Downloads
                                // into Settings, owner's orders 2026-10-24):
                                // the shrink only eats the names — no tab
                                // ever melts away or folds into a pill.
                                DockItem(
                                    tab = tab,
                                    selected = selected,
                                    // v0.14.25 (item 5): labels always
                                    // shown — never eaten by the shrink.
                                    labelFraction = 1f,
                                    labelSizeDp = labelSizeDp,
                                    modifier = Modifier.weight(1f),
                                    onLongClick = if (isHome) {
                                        { showHomeCatalogPicker = true }
                                    } else null,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                        // Home (v0.12.4): tapping Home
                                        // lands on Home scrolled to the
                                        // very top — from any other tab,
                                        // and when already on Home.
                                        if (isHome) {
                                            com.pulsestream.app.ui.screens.HomeScrollSignal
                                                .requestScrollToTop()
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        // Press-and-hold Home catalogs picker sheet (v0.14.14).
        if (showHomeCatalogPicker) {
            com.pulsestream.app.ui.screens.HomeCatalogPickerSheet(
                repository = repository,
                onDismiss = { showHomeCatalogPicker = false }
            )
        }
        // Full portrait trailer layer — floats above the current tab (which
        // stays mounted behind it). Slides/fades up on open, collapses down
        // into the mini player on swipe-down/back.
        AnimatedVisibility(
            visible = trailerMini.playerState == TrailerPlayerState.Full,
            enter = if (systemMotionEnabled) slideInVertically(
                initialOffsetY = { it }, animationSpec = spring(dampingRatio = 0.88f, stiffness = 450f)
            ) + fadeIn(tween(280)) else androidx.compose.animation.EnterTransition.None,
            exit = if (systemMotionEnabled) slideOutVertically(
                targetOffsetY = { it }, animationSpec = tween(380, easing = FastOutSlowInEasing)
            ) + fadeOut(tween(300)) else androidx.compose.animation.ExitTransition.None
        ) {
            val req = trailerMini.request
            val player = trailerMini.player
            if (req != null && player != null) {
                DarkVideoSurface {
                    TrailerPlayerScreen(
                        repository = repository,
                        request = req,
                        externalPlayer = player,
                        onBack = { trailerMini.minimize() },
                        onSwipeDown = { trailerMini.minimize() }
                    )
                }
            }
        }
        // Mini floating trailer player, above content and dock.
        AnimatedVisibility(
            visible = trailerMini.playerState == TrailerPlayerState.Mini,
            enter = if (systemMotionEnabled) fadeIn(tween(220, delayMillis = 120)) + scaleIn(
                initialScale = 0.6f, transformOrigin = TransformOrigin(1f, 1f),
                animationSpec = tween(300, delayMillis = 120, easing = FastOutSlowInEasing)
            ) else androidx.compose.animation.EnterTransition.None,
            exit = if (systemMotionEnabled) fadeOut(tween(200)) + scaleOut(
                targetScale = 0.6f, transformOrigin = TransformOrigin(1f, 1f),
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) else androidx.compose.animation.ExitTransition.None
        ) {
            DarkVideoSurface {
                MiniTrailerOverlay(
                    controller = trailerMini,
                    onExpand = { trailerMini.expand() }
                )
            }
        }
        } // end Box wrapping mobile Scaffold
    } // end else (mobile bottom dock)

    // Update popup, shown over whatever screen is visible (both form factors).
    UpdatePrompt(
        info = updateInfo,
        onDismiss = { updateInfo = null }
    )

    // Owner announcement (AppConfig), shown once per id and only when
    // no update prompt is up — the two never stack.
    AnnouncementPrompt(
        announcement = visibleAnnouncement,
        onDismiss = {
            visibleAnnouncement?.let { AppConfig.markAnnouncementSeen(appContext, it.id) }
            dismissedAnnouncementId = visibleAnnouncement?.id
        }
    )
}

@Composable
private fun PulseNavGraph(
    navController: NavHostController,
    repository: StreamRepository,
    listsRepository: CustomListsRepository,
    onThemeChanged: () -> Unit,
    trailerMini: TrailerMiniController? = null
) {
    val appContext = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val activity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity

    val navScope = rememberCoroutineScope()
    fun openResolvedDetail(addonId: String, type: String, metaId: String) {
        navScope.launch {
            val target = com.pulsestream.app.ui.screens.resolveDetailTarget(repository, addonId, type, metaId)
            navController.navigate(Routes.detail(target.addonId, target.type, target.metaId))
        }
    }

    // External-player protected-link warning (owner's order 2026-10-26):
    // non-null while the warning popup is up for that request.
    var externalWarnReq by remember { mutableStateOf<PlaybackRequest?>(null) }
    var externalWarnHide by remember { mutableStateOf(false) }

    /**
     * External handoff with the warning gate: protected links show the
     * one-time warning popup first (rendered below the NavHost); a
     * failed launch falls back to the built-in player.
     */
    fun playExternal(req: PlaybackRequest) {
        val ctx = activity ?: appContext
        if (ExternalPlayer.needsWarning(ctx, req)) {
            externalWarnHide = false
            externalWarnReq = req
        } else if (!ExternalPlayer.play(ctx, req)) {
            repository.pendingPlayback = req
            navController.navigate(Routes.PLAYER)
        }
    }

    /**
     * Single choke point for all playback. Honors Settings > Playback >
     * "Preferred player". Built-in behavior is unchanged; external/ask modes
     * only divert when the user chose them.
     */
    fun playRequest(req: PlaybackRequest) {
        when (PlayerChoice.fromName(repository.settings.preferredPlayer)) {
            PlayerChoice.BUILT_IN -> {
                repository.pendingPlayback = req
                navController.navigate(Routes.PLAYER)
            }
            PlayerChoice.EXTERNAL -> playExternal(req)
            PlayerChoice.ASK -> {
                val act = activity
                if (act == null || act.isFinishing) {
                    repository.pendingPlayback = req
                    navController.navigate(Routes.PLAYER)
                } else {
                    android.app.AlertDialog.Builder(act)
                        .setTitle("Play with")
                        .setItems(arrayOf("Built-in player", "External player")) { _, which ->
                            if (which == 1) {
                                playExternal(req)
                            } else {
                                repository.pendingPlayback = req
                                navController.navigate(Routes.PLAYER)
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }

    // Shared downloaded-file playback (Downloads screen + Library
    // Downloads section): same file check, same local player route.
    val playDownloadedFile: (String, String) -> Unit = { filePath, title ->
        val file = java.io.File(filePath)
        if (!file.exists() || !file.canRead()) {
            android.widget.Toast.makeText(
                appContext,
                "Downloaded file not found \u2014 it may have been deleted.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        } else {
            playRequest(
                PlaybackRequest(
                    streamUrl = "file://$filePath",
                    title = title,
                    poster = null,
                    videoId = "download_${filePath.hashCode()}",
                    isMovie = true
                )
            )
        }
    }
    // Shared-art poster→detail flight REMOVED (v0.14.16,
    // PLAVIO-12 / PLAVIO-13): the graph used to live inside one
    // SharedTransitionLayout with per-destination visibility
    // scopes; the flight's lookahead machinery kept crashing
    // ("Placement happened before lookahead") even after the
    // v0.14.14 arbiter hardening, so the wrapper is gone — posters
    // simply appear in place and destinations keep their ordinary
    // fade / hard-cut transitions below.
    // Reduced animations (v0.14.39, appearance item G): destination
    // changes become hard cuts instead of the default crossfades.
    val reduceMotionNav = LocalReduceMotion.current
    NavHost(
        navController = navController, startDestination = Routes.SPLASH,
        enterTransition = {
            if (reduceMotionNav) androidx.compose.animation.EnterTransition.None
            else androidx.compose.animation.fadeIn()
        },
        exitTransition = {
            if (reduceMotionNav) androidx.compose.animation.ExitTransition.None
            else androidx.compose.animation.fadeOut()
        },
        popEnterTransition = {
            if (reduceMotionNav) androidx.compose.animation.EnterTransition.None
            else androidx.compose.animation.fadeIn()
        },
        popExitTransition = {
            if (reduceMotionNav) androidx.compose.animation.ExitTransition.None
            else androidx.compose.animation.fadeOut()
        }
    ) {
        composable(Routes.SPLASH) {
            // Warm the home catalog cache while the splash animation
            // plays. The splash leaves once the animation is done AND
            // the feed is ready — but a cached feed counts as ready
            // (owner's fix 2026-10-24): Home renders cached rows
            // instantly and refreshes in the background, so a warm
            // start never waits on the network. Only a truly empty
            // cache waits for the refresh; 8s cap so a dead network
            // can never trap the user on the splash.
            var feedReady by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                launch {
                    if (runCatching { repository.hasCachedHomeRows() }
                            .getOrDefault(false)
                    ) {
                        feedReady = true
                    }
                    runCatching { repository.refreshCatalogRows() }
                    feedReady = true
                }
                launch { runCatching { repository.pruneOversizedCache() } }
                launch { delay(8000); feedReady = true }
            }
            // Welcome/onboarding guide REMOVED (owner's order
            // 2026-10-22): a fresh install goes straight to
            // Home — no popup guide. The flag is settled so
            // nothing can route into the retired flow again.
            val splashDone: () -> Unit = {
                if (!repository.settings.onboardingDone) {
                    repository.settings.onboardingDone = true
                }
                val next = Routes.HOME
                navController.navigate(next) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }
            if (repository.settings.startupAnimation) {
                SplashScreen(
                    feedReady = feedReady,
                    onDone = splashDone
                )
            } else {
                // Startup animation OFF (v0.14.39, appearance item
                // F): the locked clip is never played — a plain
                // backdrop while the feed warms, then straight Home
                // the moment it is ready (the 8s safety cap in the
                // warm-up above still applies). The clip asset and
                // SplashScreen itself are untouched.
                LaunchedEffect(feedReady) {
                    if (feedReady) splashDone()
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(LocalPalette.current.background)
                )
            }
        }
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                repository = repository,
                onDone = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                repository = repository,
                listsRepository = listsRepository,
                onOpenDetail = { addonId, type, metaId ->
                    openResolvedDetail(addonId, type, metaId)
                },
                onResumePlayback = {
                    repository.pendingPlayback?.let { playRequest(it) }
                },
                onGoToAddons = { navController.navigate(Routes.ADDONS) },
                onGoToWatchlist = { navController.navigate(Routes.WATCHLIST) },
                onGoToLists = { navController.navigate(Routes.LISTS) },
                onOpenCatalog = { row ->
                    repository.pendingCatalog = row
                    navController.navigate(
                        Routes.catalog(row.addonId, row.type, row.catalogId)
                    )
                },
                onGoToLive = { navController.navigate(Routes.LIVE) },
            )
        }
        composable(Routes.LIVE) {
            LiveScreen(
                repository = repository,
                onPlay = { req ->
                    // #3: the Live tab builds the PlaybackRequest — it must be
                    // handed to the player, not dropped.
                    playRequest(req)
                },
                onGoToAddons = { navController.navigate(Routes.ADDONS) }
            )
        }
        composable(Routes.TRAILER_PLAYER) {
            DarkVideoSurface {
                TrailerPlayerScreen(
                    repository = repository,
                    externalPlayer = trailerMini?.player,
                    onBack = {
                        // YouTube behavior: back minimizes to the floating player.
                        trailerMini?.minimize()
                        navController.popBackStack()
                    }
                )
            }
        }
        composable(Routes.SEARCH) {
        SearchScreen(
            repository = repository,
            listsRepository = listsRepository,
            onOpenDetail = { addonId, type, metaId ->
                openResolvedDetail(addonId, type, metaId)
            },
            onOpenActor = { personId, personName ->
                navController.navigate(Routes.actor(personId, personName))
            },
            // v0.14.26 (item 10): the Search page's Live icon opens
            // the stable Live section (internals untouched).
            onGoToLive = { navController.navigate(Routes.LIVE) }
        )
        }
        composable(Routes.WATCHLIST) {
            WatchlistScreen(
                repository = repository,
                onOpenDetail = { addonId, type, metaId ->
                    openResolvedDetail(addonId, type, metaId)
                }
            )
        }
        composable(Routes.LIBRARY) {
            LibraryScreen(
                repository = repository,
                listsRepository = listsRepository,
                onOpenDetail = { addonId, type, metaId ->
                    openResolvedDetail(addonId, type, metaId)
                },
                onOpenList = { listId ->
                    navController.navigate(Routes.listDetail(listId))
                },
                onGoToWatchlist = { navController.navigate(Routes.WATCHLIST) },
                onGoToLists = { navController.navigate(Routes.LISTS) },
                onGoToDownloads = { navController.navigate(Routes.DOWNLOADS) },
                onPlayDownload = playDownloadedFile,
                onConnect = { navController.navigate(Routes.INTEGRATIONS) }
            )
        }
        composable(Routes.LISTS) {
            ListsScreen(
                listsRepository = listsRepository,
                onOpenList = { listId ->
                    navController.navigate(Routes.listDetail(listId))
                }
            )
        }
        composable(
            Routes.LIST_DETAIL,
            arguments = listOf(
                navArgument("listId") { type = NavType.StringType }
            )
        ) { entry ->
            ListDetailScreen(
                listsRepository = listsRepository,
                listId = entry.arguments!!.getString("listId")!!,
                onBack = { navController.popBackStack() },
                onOpenDetail = { addonId, type, metaId ->
                    openResolvedDetail(addonId, type, metaId)
                }
            )
        }
        composable(Routes.ADDONS) {
            AddonsScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onGoToTvSetup = { navController.navigate(Routes.TV_ADDON_SETUP) }
            )
        }
        // v0.14.27 (batch N4): the Addons & Integrations hub PAGE
        // is gone — Settings opens the bottom popup card instead
        // (AddonsHubSheet inside SettingsScreen). Manage addons and
        // Integrations keep their own destinations below/above.
        composable(Routes.TV_ADDON_SETUP) {
            TvAddonSetupScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                repository = repository,
                onThemeChanged = onThemeChanged,
                onGoToAddons = { navController.navigate(Routes.ADDONS) },
                onGoToPlayback = { navController.navigate(Routes.PLAYBACK_SETTINGS) },
                onGoToSubtitles = { navController.navigate(Routes.SUBTITLE_SETTINGS) },
                onGoToAppearance = { navController.navigate(Routes.APPEARANCE_SETTINGS) },
                onGoToStreams = { navController.navigate(Routes.STREAMS_SETTINGS) },
                onGoToAbout = { navController.navigate(Routes.ABOUT) },
                onGoToFeedback = { navController.navigate(Routes.FEEDBACK) },
                onGoToAccount = { navController.navigate(Routes.ACCOUNT) },
                onGoToIntegrations = { navController.navigate(Routes.INTEGRATIONS) },
                onGoToDownloads = { navController.navigate(Routes.DOWNLOADS) },
                onGoToNotifications = { navController.navigate(Routes.NOTIFICATIONS_SETTINGS) }
            )
        }
        composable(Routes.NOTIFICATIONS_SETTINGS) {
            com.pulsestream.app.ui.screens.NotificationsScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.PROFILES) {
            ProfilesScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.INTEGRATIONS) {
            IntegrationsScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.ACCOUNT) {
            AccountScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onGoToProfiles = { navController.navigate(Routes.PROFILES) },
                onGoToBackup = { navController.navigate(Routes.BACKUP) }
            )
        }
        // v0.14.25 (item 6): the file backup/restore screen finally
        // gets its destination — it was fully implemented but
        // unreachable (no destination, dead import). Account & Sync
        // links here.
        composable(Routes.BACKUP) {
            BackupScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.PLAYBACK_SETTINGS) {
            PlaybackSettingsScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SUBTITLE_SETTINGS) {
            SubtitleSettingsScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onGoToIntegrations = { navController.navigate(Routes.INTEGRATIONS) }
            )
        }
        composable(Routes.APPEARANCE_SETTINGS) {
            AppearanceSettingsScreen(
                repository = repository,
                onThemeChanged = onThemeChanged,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.STREAMS_SETTINGS) {
            StreamsSettingsScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.ABOUT) {
            AboutScreen(
                onBack = { navController.popBackStack() },
                onGoToLicenses = { navController.navigate(Routes.LICENSES) }
            )
        }
        composable(Routes.FEEDBACK) {
            FeedbackScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.DOWNLOADS) {
            DownloadsScreen(
                onBack = { navController.popBackStack() },
                onPlayFile = playDownloadedFile
            )
        }
        composable(Routes.LICENSES) {
            LicensesScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            Routes.DETAIL,
            arguments = listOf(
                navArgument("addonId") { type = NavType.StringType },
                navArgument("type") { type = NavType.StringType },
                navArgument("metaId") { type = NavType.StringType }
            )
        ) { entry ->
            val trailerCtx = androidx.compose.ui.platform.LocalContext.current.applicationContext
            DetailScreen(
                repository = repository,
                listsRepository = listsRepository,
                addonId = Routes.dec(entry.arguments!!.getString("addonId")!!),
                type = Routes.dec(entry.arguments!!.getString("type")!!),
                metaId = Routes.dec(entry.arguments!!.getString("metaId")!!),
                onBack = { navController.popBackStack() },
                onPlay = {
                    // startPlayback() stashed the request; honor the
                    // preferred-player setting instead of always navigating.
                    val req = repository.pendingPlayback
                    if (req != null) playRequest(req)
                    else navController.navigate(Routes.PLAYER)
                },
                onPlayTrailer = { req ->
                    repository.pendingPlayback = req
                    // Mini floating player (mobile); TV falls back to the full player.
                    val mini = trailerMini
                    if (mini != null) {
                        mini.play(trailerCtx, req)
                    } else {
                        navController.navigate(Routes.TRAILER_PLAYER)
                    }
                },
                onOpenDetail = { relatedAddonId, relatedType, relatedMetaId ->
                    openResolvedDetail(relatedAddonId, relatedType, relatedMetaId)
                },
                onOpenActor = { personId, personName ->
                    navController.navigate(Routes.actor(personId, personName))
                }
            )
        }
        composable(
            Routes.ACTOR,
            arguments = listOf(
                androidx.navigation.navArgument("personId") {
                    type = androidx.navigation.NavType.IntType
                },
                androidx.navigation.navArgument("name") {
                    type = androidx.navigation.NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { entry ->
            ActorScreen(
                repository = repository,
                listsRepository = listsRepository,
                personId = entry.arguments!!.getInt("personId"),
                personName = entry.arguments!!.getString("name")
                    ?.let { runCatching { Routes.dec(it) }.getOrNull() },
                onBack = { navController.popBackStack() },
                onOpenDetail = { type, metaId ->
                    // PlavioMeta addon id — detail resolves meta/streams from
                    // any capable addon via the base-URL hint chain.
                    openResolvedDetail("community.plaviometa", type, metaId)
                }
            )
        }
        composable(Routes.PLAYER) {
            DarkVideoSurface {
                PlayerScreen(
                    repository = repository,
                    onBack = { navController.popBackStack() }
                )
            }
        }
        composable(
            Routes.CATALOG,
            arguments = listOf(
                navArgument("addonId") { type = NavType.StringType },
                navArgument("type") { type = NavType.StringType },
                navArgument("catalogId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            CatalogScreen(
                repository = repository,
                listsRepository = listsRepository,
                onBack = { navController.popBackStack() },
                onOpenDetail = { addonId, type, metaId ->
                    openResolvedDetail(addonId, type, metaId)
                },
                catalogAddonId = backStackEntry.arguments?.getString("addonId"),
                catalogType = backStackEntry.arguments?.getString("type"),
                catalogCatalogId = backStackEntry.arguments?.getString("catalogId")
            )
        }
    }

    // Protected-link warning for the preferred-player flow (owner's
    // order 2026-10-26 — same popup as the player's External button).
    externalWarnReq?.let { warnReq ->
        val warnCtx = activity ?: appContext
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { externalWarnReq = null },
            title = { androidx.compose.material3.Text("Protected link") },
            text = {
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.Text(
                        "This source uses protected headers, which stay in Plavio — " +
                            "the other app may not be able to play this link."
                    )
                    androidx.compose.foundation.layout.Spacer(
                        androidx.compose.ui.Modifier.height(8.dp)
                    )
                    androidx.compose.foundation.layout.Row(
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.Checkbox(
                            checked = externalWarnHide,
                            onCheckedChange = { externalWarnHide = it }
                        )
                        androidx.compose.material3.Text("Don't show again")
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    if (externalWarnHide) {
                        ExternalPlayer.setWarningSuppressed(warnCtx, true)
                    }
                    externalWarnReq = null
                    if (!ExternalPlayer.play(warnCtx, warnReq)) {
                        repository.pendingPlayback = warnReq
                        navController.navigate(Routes.PLAYER)
                    }
                }) {
                    androidx.compose.material3.Text("Open anyway")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { externalWarnReq = null }) {
                    androidx.compose.material3.Text("Cancel")
                }
            }
        )
    }

    // One-time Google-removal migration prompt (v0.14.6): installs that
    // were signed in with Google are invited to create a Plavio account
    // so sync keeps working. Local data is untouched either way; a new
    // account backs the current data up immediately on creation.
    var showGoogleMigration by remember {
        mutableStateOf(
            repository.settings.legacyGoogleAccountName() != null &&
                !repository.settings.googleMigrationPromptShown &&
                !com.pulsestream.app.data.cloud.PlavioAccountManager(appContext, repository).isSignedIn()
        )
    }
    if (showGoogleMigration) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                repository.settings.googleMigrationPromptShown = true
                showGoogleMigration = false
            },
            title = { androidx.compose.material3.Text("Google sign-in has been removed") },
            text = {
                androidx.compose.material3.Text(
                    "Plavio now syncs with a free Plavio account instead of Google. " +
                        "Create one and your current watchlist, history, addons and " +
                        "settings back up to it right away. Nothing on this device changes."
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    repository.settings.googleMigrationPromptShown = true
                    showGoogleMigration = false
                    navController.navigate(Routes.ACCOUNT)
                }) {
                    androidx.compose.material3.Text("Create Plavio account")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = {
                    repository.settings.googleMigrationPromptShown = true
                    showGoogleMigration = false
                }) {
                    androidx.compose.material3.Text("Later")
                }
            }
        )
    }
}
