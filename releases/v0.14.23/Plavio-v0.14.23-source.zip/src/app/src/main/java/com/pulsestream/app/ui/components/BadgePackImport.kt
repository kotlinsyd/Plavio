package com.pulsestream.app.ui.components

import android.content.Context
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * User-imported badge packs (v0.14.21, Settings → Streams → Badge
 * style → Import pack). The user pastes a Fusion-style pack link:
 * a JSON manifest whose entries map badge names to image URLs (the
 * shape the community pack registries publish), a GitHub-contents
 * style listing, or a page whose image links are the badges. Badges
 * land in internal storage under canonical key names
 * (`res-2160p.png`, `lang-te.png`, …); rendering reads them through
 * the IMPORTED style, and any key the pack doesn't carry falls back
 * to the built-in house chip, so an imported pack can dress a stream
 * but can never hide one of its facts.
 */

fun badgeImportedDir(context: Context): File = File(context.filesDir, "badges/imported")

private val importHttp: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
}

/** Result of one import attempt: how many badges landed, and the pack's name when it declared one. */
data class BadgePackImportResult(val count: Int, val packName: String?)

private val IMAGE_EXT_RE = Regex("""\.(png|webp|jpg|jpeg)$""", RegexOption.IGNORE_CASE)
private val HREF_RE = Regex("""(?:href|src)\s*=\s*"([^"]+)"""", RegexOption.IGNORE_CASE)

/** Bare/alternate badge names → the canonical keys streamBadgeKeys emits. */
private val BADGE_KEY_ALIASES: Map<String, String> = buildMap {
    put("2160p", "res-2160p"); put("4k", "res-2160p"); put("uhd", "res-2160p")
    put("1440p", "res-1440p"); put("1080p", "res-1080p"); put("720p", "res-720p")
    put("480p", "res-480p"); put("360p", "res-360p")
    put("bluray", "src-bluray"); put("blu-ray", "src-bluray"); put("bdrip", "src-bluray")
    put("webdl", "src-webdl"); put("web-dl", "src-webdl")
    put("webrip", "src-webrip"); put("web-rip", "src-webrip")
    put("hdrip", "src-hdrip"); put("dvdrip", "src-dvdrip"); put("hdtv", "src-hdtv")
    put("cam", "src-cam"); put("hdcam", "src-cam"); put("hdts", "src-cam")
    put("hevc", "codec-hevc"); put("x265", "codec-hevc"); put("h265", "codec-hevc")
    put("avc", "codec-avc"); put("x264", "codec-avc"); put("h264", "codec-avc")
    put("av1", "codec-av1"); put("10bit", "bit-10"); put("10-bit", "bit-10")
    put("dv", "hdr-dv"); put("dolbyvision", "hdr-dv"); put("dolby-vision", "hdr-dv")
    put("hdr10plus", "hdr-hdr10plus"); put("hdr10+", "hdr-hdr10plus")
    put("hdr10", "hdr-hdr10"); put("hdr", "hdr-hdr")
    put("truehd", "audio-truehd"); put("dtshd", "audio-dtshd"); put("dts-hd", "audio-dtshd")
    put("dts", "audio-dts"); put("ddp", "audio-ddp"); put("dd+", "audio-ddp")
    put("dd", "audio-dd"); put("ac3", "audio-dd"); put("aac", "audio-aac")
    put("flac", "audio-flac"); put("opus", "audio-opus")
    put("51", "ch-51"); put("5.1", "ch-51"); put("71", "ch-71"); put("7.1", "ch-71")
    put("61", "ch-61"); put("6.1", "ch-61"); put("20", "ch-20"); put("2.0", "ch-20")
}

/** A canonical key carries one of the known group prefixes (or is atmos/remux). */
private val CANONICAL_KEY_RE = Regex("""^(res|src|codec|hdr|audio|ch|lang|tag)-[a-z0-9+]+$""")

/**
 * Normalizes a pack entry name (a JSON key or a file name) to a
 * canonical badge key, or null when the name names nothing we render.
 */
private fun canonicalBadgeKey(rawName: String): String? {
    var name = rawName.trim().substringAfterLast('/').lowercase()
    name = name.replace(IMAGE_EXT_RE, "")
    if (name.isBlank()) return null
    if (CANONICAL_KEY_RE.matches(name) || name == "atmos" || name == "remux") return name
    BADGE_KEY_ALIASES[name]?.let { return it }
    // Bare two-letter language codes ride as lang-<code>.
    if (name.length == 2 && name.all { it.isLetter() }) return "lang-$name"
    return null
}

private fun httpGetBytes(url: String): ByteArray? {
    val request = Request.Builder()
        .url(url)
        .header("User-Agent", "Plavio")
        .build()
    return runCatching {
        importHttp.newCall(request).execute().use { response ->
            if (!response.isSuccessful) null else response.body?.bytes()
        }
    }.getOrNull()
}

/** Collects (rawName → imageUrl) pairs from a JSON object, one level into badge sub-objects. */
private fun collectFromJsonObject(obj: JSONObject, into: MutableMap<String, String>) {
    val keys = obj.keys()
    while (keys.hasNext()) {
        val key = keys.next()
        when (val value = obj.opt(key)) {
            is String -> if (value.startsWith("http")) into[key] = value
            is JSONObject -> collectFromJsonObject(value, into)
        }
    }
}

private fun collectPackEntries(body: String, baseUrl: String): Map<String, String> {
    val out = LinkedHashMap<String, String>()
    val trimmed = body.trim()
    if (trimmed.startsWith("{")) {
        runCatching {
            val obj = JSONObject(trimmed)
            // A single direct image link as the whole manifest.
            collectFromJsonObject(obj, out)
        }
    } else if (trimmed.startsWith("[")) {
        // GitHub-contents style listing: [{name, download_url}, …].
        runCatching {
            val arr = JSONArray(trimmed)
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name")
                val url = item.optString("download_url")
                    .ifBlank { item.optString("url") }
                if (name.isNotBlank() && url.startsWith("http")) out[name] = url
            }
        }
    }
    if (out.isEmpty()) {
        // HTML page (or a JSON shape we didn't match): the image
        // links on it are the pack.
        for (match in HREF_RE.findAll(body)) {
            val href = match.groupValues[1]
            if (!IMAGE_EXT_RE.containsMatchIn(href)) continue
            val absolute = runCatching {
                java.net.URL(java.net.URL(baseUrl), href).toString()
            }.getOrNull() ?: continue
            out[href.substringAfterLast('/')] = absolute
        }
    }
    return out
}

/**
 * Downloads the pack at [link] into the imported-pack directory.
 * Replaces any previously imported pack. Returns the number of
 * usable badges and the pack's declared name (the JSON's top-level
 * "name", when present). Throws with a user-readable message when
 * the link yields nothing usable.
 */
suspend fun importBadgePack(context: Context, link: String): BadgePackImportResult =
    withContext(Dispatchers.IO) {
        val url = link.trim()
        require(url.startsWith("https://") || url.startsWith("http://")) {
            "That link doesn't look right"
        }
        val bodyBytes = httpGetBytes(url) ?: throw IllegalStateException("Couldn't open that link")
        val body = bodyBytes.toString(Charsets.UTF_8)
        val packName = runCatching {
            JSONObject(body.trim()).optString("name").ifBlank { null }
        }.getOrNull()
        val entries = collectPackEntries(body, url)
        val dir = badgeImportedDir(context)
        val staging = File(dir.parentFile, "imported-staging")
        staging.deleteRecursively()
        staging.mkdirs()
        var count = 0
        for ((rawName, imageUrl) in entries) {
            if (count >= 96) break
            val key = canonicalBadgeKey(rawName) ?: continue
            val bytes = httpGetBytes(imageUrl) ?: continue
            if (bytes.isEmpty() || bytes.size > 2_000_000) continue
            // Only real, decodable images land — a broken "badge"
            // must not shadow the house fallback.
            if (BitmapFactory.decodeByteArray(bytes, 0, bytes.size) == null) continue
            File(staging, "$key.png").writeBytes(bytes)
            count++
        }
        if (count == 0) {
            staging.deleteRecursively()
            throw IllegalStateException("No usable badges found at that link")
        }
        dir.deleteRecursively()
        staging.renameTo(dir)
        BadgePackImportResult(count, packName)
    }
