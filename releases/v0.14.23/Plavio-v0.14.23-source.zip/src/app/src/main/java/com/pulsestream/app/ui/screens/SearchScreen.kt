package com.pulsestream.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.FilterChip
import com.pulsestream.app.ui.components.OrbitDots
import com.pulsestream.app.ui.components.VoiceSearchButton
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.pulsestream.app.ui.components.SafePosterImage
import com.pulsestream.app.ui.components.ShimmerPoster
import com.pulsestream.app.ui.components.tmdbSizedImage
import com.pulsestream.app.ui.theme.LocalPosterCorner
import com.pulsestream.app.ui.tv.tvFocusRing
import com.pulsestream.app.data.CachedMeta
import com.pulsestream.app.data.CastMember
import com.pulsestream.app.data.SearchHistory
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The Live entry icon (v0.14.26, item 10 — owner's locked style,
 * 2026-11-07): a white TV outline with a play triangle inside and
 * a small red dot at the bottom-right corner of the outline.
 * Drawn, not an asset, so it stays crisp at any density.
 */
@Composable
private fun LiveEntryIcon() {
    androidx.compose.foundation.Canvas(Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        val stroke = 2.2.dp.toPx()
        val inset = stroke / 2f + 1.dp.toPx()
        val body = androidx.compose.ui.geometry.Rect(
            inset, h * 0.16f, w - inset - 3.dp.toPx(), h * 0.86f
        )
        // Antenna: two short strokes from the top edge.
        val cx = (body.left + body.right) / 2f
        drawLine(
            color = Color.White,
            start = androidx.compose.ui.geometry.Offset(cx, body.top),
            end = androidx.compose.ui.geometry.Offset(cx - w * 0.16f, h * 0.02f),
            strokeWidth = stroke
        )
        drawLine(
            color = Color.White,
            start = androidx.compose.ui.geometry.Offset(cx, body.top),
            end = androidx.compose.ui.geometry.Offset(cx + w * 0.16f, h * 0.02f),
            strokeWidth = stroke
        )
        // TV outline.
        drawRoundRect(
            color = Color.White,
            topLeft = body.topLeft,
            size = body.size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
        )
        // Play triangle, centred in the body.
        val tcx = (body.left + body.right) / 2f
        val tcy = (body.top + body.bottom) / 2f
        val tw = w * 0.20f
        val th = h * 0.24f
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(tcx - tw * 0.42f, tcy - th / 2f)
            lineTo(tcx - tw * 0.42f, tcy + th / 2f)
            lineTo(tcx + tw * 0.58f, tcy)
            close()
        }
        drawPath(path, color = Color.White)
        // The red dot at the outline's bottom-right corner.
        drawCircle(
            color = Color(0xFFE53935),
            radius = 3.4.dp.toPx(),
            center = androidx.compose.ui.geometry.Offset(body.right, body.bottom)
        )
    }
}

@Composable
fun SearchScreen(
    repository: StreamRepository,
    listsRepository: com.pulsestream.app.data.CustomListsRepository,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    onOpenActor: (Int, String) -> Unit = { _, _ -> },
    // v0.14.26 (batch item 10 + the Live entry settlement): the ONE
    // change to the settled Search page — the Live icon at the
    // top-right opens the stable Live section. Default no-op keeps
    // every other caller byte-identical.
    onGoToLive: () -> Unit = {}
) {
    // Press-and-hold sheet target (v0.14.7, owner's fix #3): the
    // Trakt/Simkl/MDBList sheet must open from search results too.
    var sheetTarget by remember { mutableStateOf<CachedMeta?>(null) }
    // Survive rotation: query/type/genre are saveable, and the debounced
    // search effect below re-runs on restore (results aren't parcelable,
    // so they re-fetch instead of being saved).
    var query by rememberSaveable { mutableStateOf("") }
    var selectedGenre by rememberSaveable { mutableStateOf<String?>(null) }
    // The query+type combo the saved genre belongs to — resets the genre
    // when the search moves on (replaces the old remember(query) reset).
    var genreOwner by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<CachedMeta>>(emptyList()) }
    // Actors matching the query (owner's order 2026-10-26 — search by
    // actor): name + photo, tap opens the actor page.
    var people by remember { mutableStateOf<List<CastMember>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var resultOwner by remember { mutableStateOf("") }
    // R5(ii) (v0.14.23): actors get the same ownership guard titles
    // already had — without it, the previous query's actors stayed
    // rendered (and tappable) while a new query debounced/searched.
    var peopleOwner by remember { mutableStateOf("") }
    val queryOwner = query.trim()
    val queryResults = if (queryOwner == resultOwner) results else emptyList()
    val visiblePeople = if (queryOwner == peopleOwner) people else emptyList()
    val genres = remember(queryResults) {
        queryResults.flatMap { it.meta.genres }.distinct().sorted().take(14)
    }
    // "Refine" (year / IMDb-rating filters) removed in v0.12.0 — user's
    // call: useless. Only the genre chips below still filter the results.
    val visibleResults = remember(queryResults, selectedGenre) {
        if (selectedGenre == null) queryResults
        else queryResults.filter { selectedGenre in it.meta.genres }
    }
    val clearRefinements = {
        selectedGenre = null
    }
    val appContext = LocalContext.current.applicationContext
    var history by remember { mutableStateOf(SearchHistory.get(appContext)) }

    // ---- "You May Like This" suggestions grid (v0.14.23 stable —
    // owner's final shape, 2026-11-07, replacing the v0.14.27
    // per-term shelves) ----
    // ONE grid on the landing, built from the last 5 history terms
    // COMBINED. The history lives only on this device
    // (SearchHistory is SharedPreferences). Each term is resolved
    // to its single top title through the same progressive union
    // the search field uses; that title's similar titles come from
    // the repository's getRelated — the exact More Like This path
    // the Details page renders (TMDB when the user has a key, the
    // meta addons' /related, then the genre fallback), so the
    // picks work with any metadata addon, never one hardwired
    // source. Per-term picks are interleaved into the one grid —
    // mixed languages in the searches, mixed picks out, never
    // grouped by term. A term that resolves to no single title (a
    // phrase like "Hindi movies") contributes nothing, and a slow
    // or failed term never blocks the grid. When the merged grid
    // ends up empty — or there is no history at all — the same
    // space shows "Popular now" instead.
    val suggestTerms = history.take(5)
    val suggestByTerm = remember {
        androidx.compose.runtime.mutableStateMapOf<String, List<CachedMeta>>()
    }
    var suggestSettled by remember { mutableStateOf(false) }
    var suggestResolvedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var popularItems by remember { mutableStateOf<List<CachedMeta>>(emptyList()) }
    LaunchedEffect(suggestTerms) {
        suggestByTerm.clear()
        suggestResolvedIds = emptySet()
        suggestSettled = suggestTerms.isEmpty()
        val jobs = suggestTerms.map { term ->
            launch {
                try {
                    var settled: List<CachedMeta> = emptyList()
                    repository.searchProgressiveUnion(term, null).collect { snapshot ->
                        if (snapshot.isNotEmpty()) settled = snapshot
                    }
                    val resolved = resolveSearchedTitle(term, settled)
                        ?: return@launch
                    suggestResolvedIds = suggestResolvedIds + resolved.meta.id
                    val sections = runCatching {
                        repository.getRelated(
                            resolved.meta.type, resolved.meta.id, resolved.baseUrl
                        )
                    }.getOrDefault(emptyList())
                    val picks = sections.flatMap { it.metas }
                        .filter { it.id != resolved.meta.id }
                        .distinctBy { it.id }
                        .take(SUGGEST_PER_TERM_PICKS)
                        .map { meta ->
                            CachedMeta(
                                addonId = resolved.addonId,
                                addonName = resolved.addonName,
                                baseUrl = resolved.baseUrl,
                                meta = meta
                            )
                        }
                    if (picks.isNotEmpty()) suggestByTerm[term] = picks
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // This term contributes nothing; the grid stands.
                }
            }
        }
        jobs.forEach { it.join() }
        suggestSettled = true
    }
    // The merged grid, recomputed as each term's picks land:
    // round-robin across terms (most recent search first) so the
    // mix shows from the very first cards; every resolved title is
    // excluded from the suggestions and the merged set is deduped.
    val likeItems: List<CachedMeta> = run {
        val perTerm = suggestTerms.mapNotNull { suggestByTerm[it] }
        val seen = HashSet<String>()
        val merged = ArrayList<CachedMeta>()
        var index = 0
        while (true) {
            var anyAtIndex = false
            for (list in perTerm) {
                val item = list.getOrNull(index) ?: continue
                anyAtIndex = true
                if (item.meta.id in suggestResolvedIds) continue
                if (seen.add(item.meta.id)) merged.add(item)
            }
            if (!anyAtIndex) break
            index++
        }
        merged
    }
    // "Popular now" fills the same space when there is no history,
    // or when the suggestions grid settled empty.
    val showPopular = history.isEmpty() || (suggestSettled && likeItems.isEmpty())
    LaunchedEffect(showPopular) {
        if (showPopular && popularItems.isEmpty()) {
            popularItems = runCatching { repository.loadPopularTitles(60) }
                .getOrDefault(emptyList())
        }
    }

    // Discover REMOVED (v0.14.27, batch N1 — owner's order
    // 2026-11-07): the Search landing is the search field plus
    // recent searches only; the Live icon stays at the top-right.
    // Nothing of the Discover state, pickers or grid remains.

    // Opening a result (title or actor) is what earns a history entry
    // (owner's spec 2026-10-26): with first-letter searching, recording
    // per keystroke would fill recents with fragments ("a", "av", "ava").
    fun recordSettledSearch() {
        val q = query.trim()
        if (q.isNotEmpty()) {
            SearchHistory.add(appContext, q)
            history = SearchHistory.get(appContext)
        }
    }

    // Debounced live search: starts on the FIRST letter (owner's order
    // 2026-10-26) — instant local-cache hits, then addon results.
    LaunchedEffect(query) {
        val q = query.trim()
        if (q.isEmpty()) {
            results = emptyList()
            people = emptyList()
            peopleOwner = ""
            resultOwner = ""
            searching = false
            return@LaunchedEffect
        }
        // R5(ii): a new query starts with no actors — the previous
        // query's strip must not linger through this query's debounce.
        people = emptyList()
        peopleOwner = ""
        // Genre filter resets with each new query (and stays put on
        // rotation, where owner still matches).
        val owner = q
        if (owner != genreOwner) {
            selectedGenre = null
            genreOwner = owner
        }
        searching = true
        // v0.14.27 (render-gate fix): ownership is claimed BEFORE the
        // debounce and stale rows are cleared, so the union collector
        // below can apply snapshots for this query from the very first
        // lane. Previously resultOwner was only set when local hits
        // existed, which silently discarded every progressive snapshot
        // for cold queries — exactly the searches that need them.
        resultOwner = owner
        results = emptyList()
        delay(300)
        // App-owned progressive union (v0.14.27): query-cache seed +
        // local hits first, then the primary stage (TMDB direct with
        // a saved key; PMeta /search.json when keyless) and the addon
        // floor as they land. Every emission is the ranked union so
        // far — lanes only add rows, and the settled answer can no
        // longer overwrite progressive results away.
        try {
            repository.searchProgressiveUnion(q, null).collect { snapshot ->
                results = snapshot
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            // Lanes fail soft inside the repository; whatever landed stands.
        }
        searching = false
        // People ride the same settled query; skipped for 1-letter
        // queries (too noisy) but never chip-gated any more.
        people = if (q.length >= 2) {
            runCatching { repository.searchPeople(q) }.getOrDefault(emptyList())
        } else {
            emptyList()
        }
        peopleOwner = owner
    }

    // ---- Scroll-overlap (owner's approved sample 2026-10-26) ----
    // The header (title, bar, chips, genres) and the Actors strip stay
    // put; the "Movies & Series" layer starts below them and, as the
    // grid scrolls, slides up OVER everything — actors, genres, chips,
    // even the search bar — until the posters own the full screen.
    // Scrolling back to the grid's top lowers it again.
    val headerHeightState = remember { mutableIntStateOf(0) }
    val actorsHeightState = remember { mutableIntStateOf(0) }
    val rootHeightState = remember { mutableIntStateOf(0) }
    var layerLiftPx by remember(resultOwner) {
        mutableFloatStateOf(0f)
    }
    val resultsGridState = remember(resultOwner) {
        LazyGridState()
    }
    val overlapConnection = remember(resultsGridState) {
        object : NestedScrollConnection {
            override fun onPreScroll(
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                val dy = available.y
                val maxLift =
                    (headerHeightState.intValue + actorsHeightState.intValue).toFloat()
                return when {
                    // Scrolling down: lift the layer over the header
                    // first; the grid itself starts moving once the
                    // layer is docked at the top.
                    dy < 0f && layerLiftPx < maxLift -> {
                        val consume = min(-dy, maxLift - layerLiftPx)
                        layerLiftPx += consume
                        Offset(0f, -consume)
                    }
                    // Scrolling back: the grid returns to its top
                    // first, then the layer lowers, restoring the
                    // header underneath.
                    dy > 0f && layerLiftPx > 0f &&
                        resultsGridState.firstVisibleItemIndex == 0 &&
                        resultsGridState.firstVisibleItemScrollOffset == 0 -> {
                        val consume = min(dy, layerLiftPx)
                        layerLiftPx -= consume
                        Offset(0f, consume)
                    }
                    else -> Offset.Zero
                }
            }
        }
    }
    val density = LocalDensity.current
    val headerDp = with(density) { headerHeightState.intValue.toDp() }

    // Results-state shape: the titles layer exists when there are
    // titles (or a genre verdict to show); the Actors strip alone
    // (All mode, actors but no titles) is also a results state.
    val hasTitlesLayer = visibleResults.isNotEmpty() || selectedGenre != null
    val hasActorsStrip = visiblePeople.isNotEmpty()
    val hasResultsState = hasTitlesLayer || hasActorsStrip

    GlowBackground {
        Box(
            Modifier
                .fillMaxSize()
                .onSizeChanged { rootHeightState.intValue = it.height }
        ) {
            // Header zone: stays put and gets COVERED by the sliding
            // titles layer (never scrolls itself).
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { headerHeightState.intValue = it.height }
            ) {
                // Title row: "Search" + the Live entry icon at the
                // TOP-RIGHT (v0.14.26, item 10 — owner's locked
                // style: white TV outline, play triangle inside,
                // small red dot at the bottom-right of the outline).
                // This icon is the ONLY change to the settled page.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Search",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.padding(16.dp).weight(1f)
                    )
                    IconButton(
                        onClick = onGoToLive,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        LiveEntryIcon()
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .liquidGlass(RoundedCornerShape(50))
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Movies, shows…", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Filled.Search, null, tint = TextSecondary) },
                        // Voice search (owner 2026-10-31): renders ONLY
                        // when a recognition service resolves and the
                        // mic permission isn't denied — otherwise this
                        // slot is empty and the bar is unchanged. A
                        // result writes the SAME query state typed text
                        // uses, so everything downstream is identical.
                        trailingIcon = {
                            VoiceSearchButton(onResult = { query = it })
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(50),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = LocalPalette.current.accent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(8.dp))
                // Results genre chips: derived from the results, filtering locally.
                if (genres.isNotEmpty() && query.trim().length >= 1) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item(key = "genre_all") {
                            FilterChip(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)),
                                selected = selectedGenre == null,
                                onClick = { selectedGenre = null },
                                label = { Text("All genres") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
                                    selectedLabelColor = TextPrimary,
                                    containerColor = Color.White.copy(alpha = 0.06f),
                                    labelColor = TextSecondary
                                )
                            )
                        }
                        items(genres, key = { "genre_$it" }) { genre ->
                            FilterChip(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)),
                                selected = selectedGenre == genre,
                                onClick = { selectedGenre = if (selectedGenre == genre) null else genre },
                                label = { Text(genre) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
                                    selectedLabelColor = TextPrimary,
                                    containerColor = Color.White.copy(alpha = 0.06f),
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            when {
                query.trim().isEmpty() -> {
                    // Landing (v0.12.4 Sample B; Discover removed
                    // v0.14.27 batch N1; suggestions grid v0.14.23):
                    // capsule bar (above) → ONE headline over a
                    // single downward poster grid — the "You May
                    // Like This" picks merged from the last 5
                    // searches, or "Popular now" when there is
                    // nothing to suggest. Bottom padding keeps the
                    // last row clear of the floating dock.
                    val landingItems =
                        if (likeItems.isNotEmpty()) likeItems else popularItems
                    val landingTitle =
                        if (likeItems.isNotEmpty()) "You May Like This" else "Popular now"
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        contentPadding = PaddingValues(
                            start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = headerDp)
                    ) {
                        if (landingItems.isNotEmpty()) {
                            item(
                                key = "suggest_headline",
                                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }
                            ) {
                                Text(
                                    landingTitle,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(bottom = 2.dp)
                                )
                            }
                            itemsIndexed(
                                landingItems,
                                key = { index, item -> "${item.addonId}_${item.meta.id}_$index" }
                            ) { _, item ->
                                GridPoster(
                                    item,
                                    onClick = {
                                        onOpenDetail(
                                            item.addonId,
                                            item.meta.type,
                                            item.meta.id
                                        )
                                    },
                                    onLongClick = { sheetTarget = item }
                                )
                            }
                        }
                        // The quiet clear control under the content:
                        // wipes the on-device history; the
                        // suggestions go with it and Popular takes
                        // their place.
                        if (history.isNotEmpty()) {
                            item(
                                key = "clear_history",
                                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            SearchHistory.clear(appContext)
                                            history = emptyList()
                                        }
                                        .padding(start = 16.dp, end = 16.dp, top = 14.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "Clear search history",
                                        color = TextSecondary,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
                searching && !hasResultsState -> {
                    // Shimmer skeleton grid while results land (owner's
                    // order 2026-10-26) — no orbit screen, no blank wait.
                    // v0.14.27: only when there is NOTHING to show yet —
                    // once any lane has landed, the results branch below
                    // wins even while the search is still running.
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        contentPadding = PaddingValues(
                            start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = headerDp),
                        userScrollEnabled = false
                    ) {
                        items(12) {
                            Column {
                                ShimmerPoster(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(2f / 3f)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    " ",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                !hasResultsState -> Box(
                    Modifier
                        .fillMaxSize()
                        .padding(top = headerDp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No results for \"$query\"",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                else -> {
                    // Covered zone: the Actors strip (All mode) — it
                    // stays put and the titles layer slides over it.
                    if (hasActorsStrip) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(top = headerDp)
                                .onSizeChanged { actorsHeightState.intValue = it.height }
                        ) {
                            Text(
                                "Actors",
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp)
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // Same duplicate-key guard as the detail
                                // cast row (PLAVIO-D): /person-search
                                // results are not deduped upstream and
                                // keyless entries all share id 0, so one
                                // entry per person and an index-backed
                                // key for the id-less ones.
                                itemsIndexed(
                                    visiblePeople.distinctBy {
                                        if (it.id > 0) "id:${it.id}"
                                        else "name:${it.name.trim().lowercase()}"
                                    },
                                    key = { index, person ->
                                        if (person.id > 0) "person_${person.id}"
                                        else "person_${person.name}_$index"
                                    }
                                ) { _, person ->
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .width(72.dp)
                                            .tvFocusRing(RoundedCornerShape(12.dp))
                                            .clickable {
                                                recordSettledSearch()
                                                onOpenActor(person.id, person.name)
                                            }
                                    ) {
                                        SafePosterImage(
                                            model = person.photo,
                                            contentDescription = person.name,
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .liquidGlass(CircleShape)
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = person.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextPrimary,
                                            maxLines = 2,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    } else {
                        // No strip in this filter: the layer's travel
                        // is just the header's height.
                        LaunchedEffect(Unit) { actorsHeightState.intValue = 0 }
                    }
                    // The sliding titles layer: opaque, starts under
                    // the strip and rises over the whole header as
                    // the grid scrolls (see overlapConnection).
                    if (hasTitlesLayer) {
                        val layerTopPx = (
                            headerHeightState.intValue +
                                actorsHeightState.intValue -
                                layerLiftPx.roundToInt()
                            ).coerceAtLeast(0)
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .height(with(density) { rootHeightState.intValue.toDp() })
                                .offset { IntOffset(0, layerTopPx) }
                                .background(LocalPalette.current.background)
                                .zIndex(1f)
                        ) {
                            Text(
                                "Movies & Series",
                                color = TextPrimary,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                            )
                            LazyVerticalGrid(
                                state = resultsGridState,
                                columns = GridCells.Adaptive(110.dp),
                                // Bottom 104dp: last row scrolls clear of the floating dock.
                                contentPadding = PaddingValues(
                                    start = 16.dp, end = 16.dp, top = 8.dp, bottom = 104.dp
                                ),
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .nestedScroll(overlapConnection)
                            ) {
                                if (visibleResults.isEmpty()) {
                                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                        Column(
                                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                "No $selectedGenre titles in these results.",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodyMedium,
                                                textAlign = TextAlign.Center
                                            )
                                            TextButton(onClick = clearRefinements) {
                                                Text("Show all genres", color = LocalPalette.current.accent)
                                            }
                                        }
                                    }
                                }
                                itemsIndexed(
                                    visibleResults,
                                    key = { index, item -> "${item.addonId}_${item.meta.id}_$index" }
                                ) { _, item ->
                                    GridPoster(
                                        item,
                                        onClick = {
                                            recordSettledSearch()
                                            onOpenDetail(item.addonId, item.meta.type, item.meta.id)
                                        },
                                        onLongClick = { sheetTarget = item }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Hold sheet (v0.14.7, owner's fix #3): press & hold any
            // result poster opens the same Trakt/Simkl/MDBList sheet
            // as Home and Library.
            sheetTarget?.let { item ->
                com.pulsestream.app.ui.components.AddToListSheet(
                    listsRepository = listsRepository,
                    addonId = item.addonId,
                    type = item.meta.type,
                    metaId = item.meta.id,
                    name = item.meta.name,
                    poster = item.meta.poster,
                    onDismiss = { sheetTarget = null },
                    repository = repository,
                    year = item.meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
                    rating = item.meta.imdbRating
                )
            }
        }
    }
}

/** Search category chips. Types come from addon data ("movie", "series", "tv"). */


/**
 * The only source caption Search ever shows (owner's final label
 * spec v3, 2026-10-31): "We'll show Plavio Search only in our app,
 * even if at backend Cinemeta is giving results." Every result card
 * carries this constant, whichever lane or addon produced the row.
 * The rows themselves keep their true addonId/addonName provenance —
 * Detail opening and stream routing use it — only this visible
 * caption is constant. No other screen's labels change.
 */
private const val SEARCH_SOURCE_CAPTION = "Plavio Search"

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun GridPoster(item: CachedMeta, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    // Shared-art poster→detail flight REMOVED (v0.14.16,
    // PLAVIO-12/13): same removal as PosterCard — a tap is just a
    // tap now, no arming, no shared element.
    Column(
        Modifier
            .tvFocusRing(RoundedCornerShape(12.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
        ) {
            SafePosterImage(
                // Poster missing → fall back to the backdrop before
                // the empty placeholder (v0.14.28): TMDB rows carry a
                // background even for titles with no poster art.
                model = item.meta.poster ?: item.meta.background,
                contentDescription = item.meta.name,
                modifier = Modifier.fillMaxSize()
            )
            // No studio logo on portrait grid posters (owner
            // decision, item 19): the poster art already carries
            // the title; logos live on heroes + CW cards only.
            // Same glass ★ chip as every other poster card
            // (owner's #5, v0.14.8); only when a REAL rating exists —
            // a "0.0" is no rating (zero votes) and never renders
            // (v0.14.28, owner's Maula Jatt screenshot).
            item.meta.imdbRating?.takeIf {
                (it.substringBefore('/').trim().toDoubleOrNull() ?: 0.0) > 0.0
            }?.let { rating ->
                com.pulsestream.app.ui.components.PosterRatingChip(
                    rating,
                    Modifier.align(Alignment.TopStart).padding(6.dp)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = item.meta.name,
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            // Constant caption, not item.addonName (see
            // SEARCH_SOURCE_CAPTION): the true source stays on the
            // row for routing; the user only ever sees Plavio Search.
            text = SEARCH_SOURCE_CAPTION,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Max similar picks taken per history term into the merged grid. */
private const val SUGGEST_PER_TERM_PICKS = 24

/** Lowercase, punctuation-stripped form for title/term matching. */
private fun normalizeForMatch(raw: String): String =
    raw.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim().replace(Regex("\\s+"), " ")

/**
 * Resolves one history term to the single title it points at, from
 * the settled union-search results for that term: the best-ranked
 * movie/series whose title actually matches the term (normalised
 * containment, either way). A phrase search ("Hindi movies")
 * matches no single title and resolves to null — under the owner's
 * shape it contributes nothing to the suggestions grid.
 */
private fun resolveSearchedTitle(term: String, settled: List<CachedMeta>): CachedMeta? {
    val t = normalizeForMatch(term)
    if (t.isEmpty()) return null
    return settled.firstOrNull { item ->
        if (item.meta.type != "movie" && item.meta.type != "series") {
            false
        } else {
            val n = normalizeForMatch(item.meta.name)
            n.isNotEmpty() && (n == t || n.contains(t) || t.contains(n))
        }
    }
}
