package com.pulsestream.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.Job
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import com.pulsestream.app.ui.tv.rememberIsTv
import com.pulsestream.app.ui.tv.tvFocusRing
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pulsestream.app.data.CatalogRow
import com.pulsestream.app.data.MetaPreview
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.data.AppConfig
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.db.PlaybackState
import com.pulsestream.app.ui.components.ErrorState
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.OrbitDots
import com.pulsestream.app.data.CustomListsRepository
import com.pulsestream.app.ui.components.AddToListSheet
import com.pulsestream.app.ui.components.LoadingState
import com.pulsestream.app.ui.components.PosterCard
import com.pulsestream.app.ui.components.SafePosterImage
import com.pulsestream.app.ui.components.SectionTitle
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.GlassWhite
import com.pulsestream.app.ui.components.tmdbSizedImage
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Dock → Home scroll-to-top signal (v0.12.4): the bottom dock's Home tab
 * bumps [requests] whenever it's tapped while unfolded; HomeScreen
 * collects it and smooth-scrolls its list to the very top. A plain
 * counter (not an event bus) so a tap that lands while Home is being
 * restored from the back stack still takes effect on arrival.
 */
object HomeScrollSignal {
    val requests = MutableStateFlow(0)
    fun requestScrollToTop() {
        requests.value += 1
    }
}

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data object Empty : HomeUiState
    data class Content(val rows: List<CatalogRow>, val refreshing: Boolean = false) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class HomeViewModel(private val repo: StreamRepository) : ViewModel() {
    var uiState by mutableStateOf<HomeUiState>(HomeUiState.Loading)
        private set

    // P2 (v0.14.22): load generation guard — overlapping load() calls
    // (picker signal, provider change, splash) must not let a slower
    // stale refresh land over a fresher one. Every uiState write below
    // is gated on the generation that started the load.
    private var loadGeneration = 0

    /**
     * Cache-first loading: show cached catalogs instantly, then quietly
     * refresh in the background — but only when the cache is stale (the
     * splash warm-up may have just refreshed it). [forceRefresh] skips
     * the cache entirely.
     */
    fun load(forceRefresh: Boolean = false) {
        val gen = ++loadGeneration
        viewModelScope.launch {
            if (!forceRefresh) {
                // v0.14.19 (PLAVIO-H family): the row set handed to
                // the LazyColumn is deduped by row identity at this
                // boundary too — the repo paths already distinctBy,
                // this makes "no two rows share a key" hold by
                // construction whatever path delivered the rows
                // (a provider switch replaces the set atomically
                // via the uiState assignments below, never merges).
                val cached = repo.loadCatalogRowsCached().filter { it.type != "tv" }
                    .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
                if (cached.isNotEmpty()) {
                    // Timed auto-refresh (owner, item 22): there is
                    // no manual refresh on Home anymore — the feed
                    // refreshes ITSELF once the cache is older than
                    // ~3 h, in the background, rows staying on screen.
                    val stale = !repo.isCatalogCacheFresh(HOME_FEED_REFRESH_MS)
                    if (gen == loadGeneration) {
                        uiState = HomeUiState.Content(cached, refreshing = stale)
                    }
                    if (stale) {
                        // Progressive refresh (mobile overhaul): each
                        // addon's rows replace their cached rows as
                        // they land; the screen never waits for the
                        // slowest addon. The final emission is the
                        // authoritative list.
                        var latestRows = cached
                        val completed = runCatching {
                            repo.refreshCatalogRowsProgressive().collect { fresh ->
                                val rows = fresh.filter { it.type != "tv" }
                                    .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
                                if (rows.isNotEmpty()) {
                                    latestRows = rows
                                    if (gen == loadGeneration) {
                                        uiState = HomeUiState.Content(rows, refreshing = true)
                                    }
                                }
                            }
                        }.isSuccess
                        if (gen == loadGeneration) {
                            uiState = HomeUiState.Content(
                                if (completed) latestRows else cached
                            )
                        }
                    }
                    return@launch
                }
            }
            if (gen == loadGeneration) uiState = HomeUiState.Loading
            try {
                // Live TV has its own tab — never show tv-type rows on Home
                // (hero or cards). First paint comes from the first
                // progressive batch, not the completed refresh.
                var sawRows = false
                var finalRows: List<CatalogRow> = emptyList()
                repo.refreshCatalogRowsProgressive().collect { fresh ->
                    val rows = fresh.filter { it.type != "tv" }
                        .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
                    finalRows = rows
                    if (rows.isNotEmpty()) {
                        sawRows = true
                        if (gen == loadGeneration) {
                            uiState = HomeUiState.Content(rows, refreshing = true)
                        }
                    }
                }
                if (gen == loadGeneration) {
                    uiState = if (!sawRows || finalRows.isEmpty()) {
                        HomeUiState.Empty
                    } else {
                        HomeUiState.Content(finalRows)
                    }
                }
            } catch (e: Exception) {
                if (gen == loadGeneration) {
                    uiState = HomeUiState.Error(e.message ?: "Couldn't load catalogs")
                }
            }
        }
    }

    companion object {
        /** Home feed auto-refresh window (item 22): ~3 hours. */
        const val HOME_FEED_REFRESH_MS: Long = 3 * 60 * 60 * 1000L
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: StreamRepository,
    listsRepository: CustomListsRepository,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    onResumePlayback: () -> Unit,
    onGoToAddons: () -> Unit,
    onGoToWatchlist: () -> Unit,
    onGoToLists: () -> Unit,
    onOpenCatalog: (row: CatalogRow) -> Unit,
    onGoToLive: () -> Unit = {},
) {
    val vm: HomeViewModel = viewModel(factory = vmFactory { HomeViewModel(repository) })
    // Hold-Home catalog picker → reload rows when its choices change
    // (v0.14.14). Saveable handled-counter, same pattern as the
    // scroll-to-top signal: a change fired while Home sat in the back
    // stack is honoured once, on return.
    val catalogRequests by HomeCatalogSignal.requests.collectAsState()
    var handledCatalogRequest by rememberSaveable {
        mutableStateOf(HomeCatalogSignal.requests.value)
    }
    LaunchedEffect(catalogRequests) {
        if (catalogRequests != handledCatalogRequest) {
            handledCatalogRequest = catalogRequests
            vm.load()
        }
    }
    val watching by repository.continueWatching.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val heroContext = androidx.compose.ui.platform.LocalContext.current

    // Hero Watch Now (CENTER 1): play immediately — resolve the title's
    // meta, take its streams, pick per the autoplay rules, play. When
    // nothing playable turns up, say so and open the detail page.
    fun playFeatured(item: FeaturedTitle) {
        scope.launch {
            val full = runCatching {
                repository.getMetaFromAny(item.addonId, item.meta.type, item.meta.id)
            }.getOrNull()
            val video = if (item.meta.type == "series") full?.videos?.firstOrNull() else null
            val videoId = when {
                item.meta.type == "series" -> video?.id
                else -> full?.id ?: item.meta.id
            }
            if (videoId == null) {
                android.widget.Toast.makeText(
                    heroContext, "No episodes found for this title yet.",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                return@launch
            }
            val result = kotlinx.coroutines.withTimeoutOrNull(20_000) {
                repository.streamResultsFlow(item.meta.type, videoId, item.addonId)
                    .let { flow ->
                        var lastResult: com.pulsestream.app.data.StreamResult? = null
                        flow.collect { lastResult = it }
                        lastResult
                    }
            }
            val streams = result?.streams.orEmpty()
            val pick = com.pulsestream.app.ui.components.pickAutoplayStream(streams, repository.settings)
            if (pick == null) {
                android.widget.Toast.makeText(
                    heroContext, "No playable source found — opening details.",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                onOpenDetail(item.addonId, item.meta.type, item.meta.id)
                return@launch
            }
            repository.pendingPlayback = PlaybackRequest(
                streamUrl = pick.url,
                headers = pick.headers,
                mimeType = pick.mimeType,
                title = if (video != null) {
                    "${item.meta.name} S${video.season}E${video.episode}"
                } else item.meta.name,
                poster = video?.thumbnail ?: full?.poster ?: item.meta.poster,
                videoId = videoId,
                subtitles = result?.subtitles.orEmpty(),
                imdbId = item.meta.id.takeIf { it.startsWith("tt") },
                season = video?.season ?: 0,
                episode = video?.episode ?: 0,
                isMovie = item.meta.type == "movie",
                type = item.meta.type,
                streamLabel = com.pulsestream.app.data.streamQualityLabel(pick),
                sourceName = pick.sourceName,
                sourceId = pick.sourceId,
                streamTitle = pick.title ?: pick.name,
                logo = full?.logo ?: item.meta.logo,
                streams = streams,
                episodes = full?.videos.orEmpty(),
                metaId = full?.id ?: item.meta.id,
                seriesName = item.meta.name.takeIf { item.meta.type == "series" },
                episodeTitle = video?.title
            )
            onResumePlayback()
        }
    }

    // Continue Watching resume (DB v15, owner's v0.14.7-test report):
    // the tap used to hand the player a bare request and the resume
    // landed on the FIRST stream even though he had been watching a
    // later one he picked in Sources. Resolve the title's streams
    // briefly, prefer the saved stream (exact URL → same addon +
    // title fingerprint, see StreamRepository.matchResumeStream),
    // and fall back cleanly when it is genuinely gone: nothing
    // resolved → the saved URL as before; resolved but no match →
    // the normal auto-pick.
    //
    // Instant hand-off (v0.14.14, item 3): an entry WITH a saved
    // stream no longer waits for that resolution on this page — the
    // player opens INSTANTLY and the same re-resolution runs inside
    // it (the player's #15 fresh-URL pass keys on exactly this
    // request shape: saved URL + empty stream list + a saved
    // position; 6 s cap, saved-stream identity preferred, the
    // two-tier autoplay rule as fallback — item 6 — and the stored
    // URL plays when nothing fresh answers). Only imported entries
    // (Trakt/Simkl, item 13 — no saved stream at all) keep the
    // resolve-first path below.
    fun resumeContinueWatching(item: PlaybackState) {
        val isMovieItem = item.season == 0 && item.episode == 0
        val type = if (isMovieItem) "movie" else "series"
        // Episode-title fallback (owner, 2026-10-28): decode the
        // saved episode list first so a row with no episodeTitle
        // can still surface the current episode's title in the
        // player header instead of "S1E1" alone.
        val decodedEpisodes = com.pulsestream.app.data.decodeEpisodeIds(item.episodeIdsJson)
        if (item.importSource == null && item.streamUrl.isNotBlank()) {
            repository.pendingPlayback = PlaybackRequest(
                streamUrl = item.streamUrl,
                headers = emptyMap(),
                mimeType = null,
                title = item.title,
                poster = item.poster,
                videoId = item.videoId,
                subtitles = emptyList(),
                imdbId = item.imdbId,
                season = item.season,
                episode = item.episode,
                isMovie = isMovieItem,
                type = type,
                streamLabel = item.streamQuality,
                sourceName = item.streamName,
                sourceId = item.streamAddonId,
                streamTitle = item.streamTitle,
                logo = item.logo,
                // Empty on purpose: the marker the player's #15
                // re-resolution keys on (see the note above).
                streams = emptyList(),
                episodes = decodedEpisodes,
                startAtProgressPct = item.remoteProgressPct
                    ?.takeIf { item.durationMs <= 0 }
                    ?.let { it / 100f },
                seriesName = item.seriesName,
                episodeTitle = item.episodeTitle ?: decodedEpisodes.firstOrNull {
                    it.season == item.season && it.episode == item.episode
                }?.title?.takeIf { it.isNotBlank() },
                metaId = item.metaId ?: ""
            )
            onResumePlayback()
            return
        }
        scope.launch {
            var resolved: com.pulsestream.app.data.StreamResult? = null
            kotlinx.coroutines.withTimeoutOrNull(6_000) {
                repository.streamResultsFlow(type, item.videoId).collect { res ->
                    if (res.streams.any {
                            com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                        }
                    ) {
                        resolved = res
                    }
                }
            }
            val candidates = resolved?.streams.orEmpty().filter {
                com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
            }
            val matched = repository.matchResumeStream(item, candidates)
            val chosen = matched ?: if (candidates.isNotEmpty()) {
                com.pulsestream.app.ui.components.pickAutoplayStream(
                    candidates, repository.settings
                )
            } else null
            // Imported entries (Trakt/Simkl, item 13) carry no
            // saved stream: when nothing resolves for one, opening
            // the title's page beats handing the player a dead URL.
            if (chosen == null && item.importSource != null) {
                onOpenDetail("", type, item.metaId ?: item.imdbId ?: item.videoId)
                return@launch
            }
            repository.pendingPlayback = PlaybackRequest(
                streamUrl = chosen?.url ?: item.streamUrl,
                headers = chosen?.headers ?: emptyMap(),
                mimeType = chosen?.mimeType,
                title = item.title,
                poster = item.poster,
                videoId = item.videoId,
                subtitles = resolved?.subtitles.orEmpty(),
                imdbId = item.imdbId,
                season = item.season,
                episode = item.episode,
                isMovie = isMovieItem,
                type = type,
                streamLabel = chosen?.let {
                    com.pulsestream.app.data.streamQualityLabel(it)
                } ?: item.streamQuality,
                sourceName = chosen?.sourceName ?: item.streamName,
                sourceId = chosen?.sourceId ?: item.streamAddonId,
                streamTitle = chosen?.let { it.title ?: it.name } ?: item.streamTitle,
                logo = item.logo,
                streams = resolved?.streams.orEmpty(),
                // Series context saved with the row (DB v14) + the
                // episode list itself (DB v16, item 16): a resumed
                // session starts WITH its episodes, so the Episodes
                // button and autoplay-next work without any fetch.
                episodes = decodedEpisodes,
                // Percent-only imported progress (item 13): the
                // player seeks to this fraction once it knows the
                // real duration.
                startAtProgressPct = item.remoteProgressPct
                    ?.takeIf { item.durationMs <= 0 }
                    ?.let { it / 100f },
                seriesName = item.seriesName,
                episodeTitle = item.episodeTitle ?: decodedEpisodes.firstOrNull {
                    it.season == item.season && it.episode == item.episode
                }?.title?.takeIf { it.isNotBlank() },
                metaId = item.metaId ?: ""
            )
            onResumePlayback()
        }
    }
    // Long-press context menu target: (addonId, meta) for the pressed poster.
    // (contextMenuTarget removed in v0.14.7, fix #6: hold opens the
    // unified sheet directly via addToListTarget.)
    // Add-to-list sheet target: (addonId, meta).
    var addToListTarget by remember { mutableStateOf<Pair<String, MetaPreview>?>(null) }
    // Continue Watching hold-to-remove target (v0.14.7, owner's fix #5:
    // no more x button on the cards — press & hold opens this menu).
    var cwRemoveTarget by remember { mutableStateOf<PlaybackState?>(null) }
    // Watchlist lives ONLY in the Watchlist tab (top-right bookmark) — it is
    // deliberately not shown on Home (v0.8.21 behavior fix).
    // Reload when Home catalog visibility changes in Settings.
    val catalogVersion by repository.catalogVisibility.collectAsState(initial = 0)

    LaunchedEffect(catalogVersion) { vm.load() }

    // The status-bar inset the Scaffold already padded away above this
    // screen: the Content list shifts up by exactly this amount so the
    // immersive hero reaches the very top of the screen, under the
    // status bar (v0.12.4, Sample C).
    val density = LocalDensity.current
    val statusBarDp = with(density) { WindowInsets.statusBars.getTop(density).toDp() }
    val statusBarPx = with(density) { statusBarDp.roundToPx() }

    // Android TV: initial D-pad focus target (the hero card).
    val isTv = rememberIsTv()
    val heroFocus = remember { FocusRequester() }
    // Land focus on the hero ONCE per Home visit — never yank it back on
    // every catalog refresh while the user is browsing the rows.
    var heroFocusDone by remember { mutableStateOf(false) }

    GlowBackground {
        // No header (v0.12.3, owner's order): the "Plavio" wordmark +
        // tagline row is gone, so the screen starts clear and the hero
        // poster owns the full top of the screen. The one functional
        // control the header held — the Saved (Watchlist / My Lists)
        // button — floats overlaid at the top end (below, after the
        // content states).
        Box(Modifier.fillMaxSize()) {
            when (val state = vm.uiState) {
                is HomeUiState.Loading -> HomeLoadingSkeleton()
                is HomeUiState.Error -> ErrorState(state.message, onRetry = { vm.load() })
                is HomeUiState.Empty -> NoAddonsEmptyState(
                    repository = repository,
                    onGoToAddons = onGoToAddons,
                    onReload = { vm.load() }
                )
                is HomeUiState.Content -> {
                    // Hero carousel data: computed once per row-set, outside the
                    // LazyColumn DSL (remember can't run inside the list scope).
                    val featured = remember(state.rows) { featuredTitles(state.rows) }
                    // Dock Home-tap → scroll to the very top (v0.12.4).
                    // handledScrollRequest is saveable so a request fired
                    // while Home sat in the back stack is honoured once,
                    // on return, and never replayed on later visits.
                    val homeListState = rememberLazyListState()
                    var handledScrollRequest by rememberSaveable {
                        mutableStateOf(HomeScrollSignal.requests.value)
                    }
                    val scrollRequests by HomeScrollSignal.requests.collectAsState()
                    LaunchedEffect(scrollRequests) {
                        if (scrollRequests != handledScrollRequest) {
                            handledScrollRequest = scrollRequests
                            runCatching { homeListState.animateScrollToItem(0) }
                        }
                    }
                    // TV: land D-pad focus on the hero once content is in.
                    LaunchedEffect(isTv, featured.size) {
                        if (isTv && featured.isNotEmpty() && !heroFocusDone) {
                            heroFocusDone = true
                            delay(600)
                            runCatching { heroFocus.requestFocus() }
                        }
                    }
                    // Flexible hero (owner, item 21) + no manual
                    // refresh (item 22): pull-to-refresh is GONE — the
                    // feed auto-refreshes on the ViewModel's staleness
                    // window. The pull-down gesture at the very top
                    // now STRETCHES the hero instead (Nuvio feel): the
                    // drag feeds a pixel stretch (with resistance),
                    // the hero item scales it in its graphicsLayer —
                    // transform only, never layout — and a spring
                    // snaps it back on release.
                    var heroStretchPx by remember { mutableFloatStateOf(0f) }
                    val stretchScope = rememberCoroutineScope()
                    var stretchSpringJob by remember { mutableStateOf<Job?>(null) }
                    val stretchDensity = LocalDensity.current
                    val screenHeightDpF = LocalConfiguration.current.screenHeightDp
                    val maxHeroStretchPx = remember(stretchDensity, screenHeightDpF) {
                        with(stretchDensity) {
                            ((screenHeightDpF * 0.55f).dp + 40.dp).toPx() * 0.22f
                        }
                    }
                    val heroStretchConnection = remember {
                        object : NestedScrollConnection {
                            // Spring-back helper (owner, 2026-10-28):
                            // shared by onPreFling/onPostFling — spring
                            // whenever a stretch remains and no spring
                            // is already running.
                            private fun springBackIfNeeded() {
                                if (heroStretchPx > 0f &&
                                    stretchSpringJob?.isActive != true
                                ) {
                                    val start = heroStretchPx
                                    stretchSpringJob = stretchScope.launch {
                                        Animatable(start).animateTo(
                                            0f,
                                            spring(
                                                dampingRatio = 0.55f,
                                                stiffness = 190f
                                            )
                                        ) { heroStretchPx = value }
                                    }
                                }
                            }

                            override fun onPreScroll(
                                available: Offset,
                                source: NestedScrollSource
                            ): Offset {
                                if (isTv || source != NestedScrollSource.Drag) {
                                    return Offset.Zero
                                }
                                // Stretch direction fix (owner device
                                // report, 2026-10-28): onPreScroll must
                                // NEVER feed the stretch — feeding here
                                // on available.y < 0 misfired on a
                                // scroll-down gesture (finger swiping
                                // up through the feed, e.g. starting
                                // on Continue Watching). Its only job
                                // is to unwind: if a stretch is applied
                                // and the delta is in the scroll-down
                                // direction (available.y < 0, the same
                                // sign the old code wrongly fed on),
                                // drain the stretch first (0.5
                                // resistance) and consume only the
                                // drained amount, so reversing the
                                // gesture shrinks the hero back before
                                // the list scrolls.
                                return when {
                                    available.y < 0f && heroStretchPx > 0f -> {
                                        val drain = minOf(
                                            heroStretchPx / 0.5f, -available.y
                                        )
                                        heroStretchPx -= drain * 0.5f
                                        Offset(0f, -drain)
                                    }
                                    else -> Offset.Zero
                                }
                            }

                            override fun onPostScroll(
                                consumed: Offset,
                                available: Offset,
                                source: NestedScrollSource
                            ): Offset {
                                if (isTv || source != NestedScrollSource.Drag) {
                                    return Offset.Zero
                                }
                                // Only pull-down overscroll may feed
                                // the stretch (owner, 2026-10-28): the
                                // leftover the list could not consume,
                                // available.y > 0 (opposite sign to
                                // the misfire), unconsumed on Y, and
                                // the list at its very top.
                                val atTop = homeListState.firstVisibleItemIndex == 0 &&
                                    homeListState.firstVisibleItemScrollOffset == 0
                                if (!atTop || consumed.y != 0f || available.y <= 0f) {
                                    return Offset.Zero
                                }
                                stretchSpringJob?.cancel()
                                stretchSpringJob = null
                                val room = maxHeroStretchPx - heroStretchPx
                                if (room <= 0f) return Offset.Zero
                                val added = (available.y * 0.5f).coerceAtMost(room)
                                if (added <= 0f) return Offset.Zero
                                heroStretchPx += added
                                // Consume what was used: the input
                                // delta behind the applied stretch.
                                return Offset(0f, added / 0.5f)
                            }

                            override suspend fun onPreFling(available: Velocity): Velocity {
                                // Finger released: spring the hero
                                // back to rest (slightly bouncy).
                                springBackIfNeeded()
                                return Velocity.Zero
                            }

                            override suspend fun onPostFling(
                                consumed: Velocity,
                                available: Velocity
                            ): Velocity {
                                // Feeding now happens in onPostScroll,
                                // so the release spring must also be
                                // triggered from onPostFling
                                // (owner, 2026-10-28).
                                springBackIfNeeded()
                                return Velocity.Zero
                            }
                        }
                    }
                    LazyColumn(
                        state = homeListState,
                        modifier = Modifier
                            .fillMaxSize()
                            .nestedScroll(heroStretchConnection)
                            // Full-bleed BOTH ends (v0.12.12): the column
                            // is measured statusBarPx TALLER than its
                            // parent and placed shifted up by the same
                            // amount, so the hero reaches the screen's
                            // top edge AND the viewport reaches the
                            // physical bottom edge — cards scroll under
                            // and below the floating dock to the very
                            // edge. The old plain .offset() shifted the
                            // column up WITHOUT the extra height, ending
                            // the viewport short of the bottom and
                            // leaving a solid strip under the dock.
                            .layout { measurable, constraints ->
                                val placeable = measurable.measure(
                                    constraints.copy(
                                        minHeight = constraints.maxHeight + statusBarPx,
                                        maxHeight = constraints.maxHeight + statusBarPx
                                    )
                                )
                                layout(placeable.width, placeable.height) {
                                    placeable.place(0, -statusBarPx)
                                }
                            },
                        // Extra bottom room so the last row scrolls clear
                        // of the floating dock (content now runs under it).
                        contentPadding = PaddingValues(bottom = 104.dp)
                    ) {
                        // Hero carousel: featured titles with backdrop art, first item
                        // so it's the first thing on screen. Explicit key keeps it
                        // stable while rows refresh underneath.
                        if (featured.isNotEmpty()) {
                            item(key = "hero_carousel") {
                                // Pinned hero (v0.12.5, owner's order): the
                                // hero stays at the top while the catalog
                                // sheet scrolls UP AND OVER it. The hero is
                                // still a normal list item (pager swipe,
                                // tap and TV focus untouched), but its draw
                                // position is counter-translated by exactly
                                // its scrolled-off amount, so it visually
                                // never leaves the top; the sections below
                                // are drawn after it, hence over it. At rest
                                // the translation is 0 and the first section
                                // starts exactly at the hero's bottom
                                // border — the round-5 -22dp static overlap
                                // (which also left a 22dp dead band in the
                                // layout under the first row) is gone.
                                Box(
                                    Modifier.graphicsLayer {
                                        val heroInfo = homeListState.layoutInfo
                                            .visibleItemsInfo
                                            .firstOrNull { it.key == "hero_carousel" }
                                        translationY = if (heroInfo != null && heroInfo.offset < 0)
                                            -heroInfo.offset.toFloat() else 0f
                                        // Flexible hero (item 21): the
                                        // pull-down stretch, drawn as a
                                        // gentle zoom from the top edge —
                                        // graphicsLayer only, so the
                                        // gesture stays 1:1 with zero
                                        // layout work per frame (the TV
                                        // hero-jank lesson).
                                        if (heroStretchPx > 0f) {
                                            val frac = (heroStretchPx / maxHeroStretchPx)
                                                .coerceIn(0f, 1f)
                                            scaleX = 1f + 0.08f * frac
                                            scaleY = 1f + 0.10f * frac
                                            transformOrigin = TransformOrigin(0.5f, 0f)
                                        }
                                    }
                                ) {
                                    HeroCarousel(
                                        featured = featured,
                                        onOpenDetail = onOpenDetail,
                                        heroFocus = heroFocus,
                                        onWatchNow = { playFeatured(it) },
                                        onGoToLive = onGoToLive
                                    )
                                }
                            }
                        }
                        if (watching.isNotEmpty()) {
                            // Explicit key: this section appears/disappears as the
                            // Flow emits, so an index-based default key would
                            // reshuffle every row below it on each emission.
                            item(key = "continue_watching") {
                              Column(
                                // Scroll-over sheet (v0.12.5): sections
                                // carry the solid app background so the
                                // sheet reads cleanly (headers stay
                                // legible) while it slides over the
                                // pinned hero.
                                Modifier.background(LocalPalette.current.background)
                              ) {
                                SectionTitle("Continue Watching")
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    itemsIndexed(
                                        watching,
                                        key = { index, item -> "${item.key}_$index" }
                                    ) { _, item ->
                                        ContinueWatchingCard(
                                            item,
                                            posterArtwork = repository.settings.cwArtworkPoster,
                                            onLongPress = { cwRemoveTarget = item }
                                        ) {
                                            resumeContinueWatching(item)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                              }
                            }
                        }
                        // Watchlist intentionally NOT shown here (v0.8.21):
                        // bookmarked titles live only in the Watchlist tab.
                        state.rows.forEachIndexed { rowIndex, row ->
                            // THE v0.3.0 scroll-crash fix: the key MUST include the
                            // catalog TYPE. Cinemeta declares the same catalog ids
                            // ("top", "year", "imdbRating") for both movie and
                            // series — without the type, two rows shared one key
                            // and LazyColumn threw, closing the app on scroll.
                            item(key = "${row.addonId}|${row.type}|${row.catalogId}") {
                              Column(
                                // Scroll-over sheet (v0.12.5): same solid
                                // background as Continue Watching — the
                                // whole sheet slides over the pinned hero
                                // as one readable surface.
                                Modifier.background(LocalPalette.current.background)
                              ) {
                                // Plain row names (owner, 2026-11-04):
                                // addons bake a brand prefix into their
                                // catalog names ("PMeta: Trending Movies").
                                // Display-time only: strip a short leading
                                // "X: " segment; the addon name rides as
                                // the subtitle ONLY when another addon's
                                // row lands on the same plain name.
                                val stripPrefix: (String) -> String = { s ->
                                    val c = s.indexOf(':')
                                    if (c in 1..24 && s.getOrNull(c + 1) == ' ') {
                                        s.substring(c + 2)
                                    } else s
                                }
                                val displayName = stripPrefix(row.catalogName)
                                val nameClash = state.rows.any { other ->
                                    other.addonId != row.addonId && other.type == row.type &&
                                        stripPrefix(other.catalogName) == displayName
                                }
                                SectionTitle(
                                    displayName,
                                    if (nameClash) row.addonName else null,
                                    onMoreClick = { onOpenCatalog(row) }
                                )
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    itemsIndexed(
                                        row.items,
                                        key = { index, meta -> "${row.addonId}_${meta.id}_$index" }
                                    ) { index, meta ->
                                        PosterCard(
                                            meta = meta,
                                            showRatingChip = true,
                                            // MDBList strip: OFF on Home
                                            // (owner, 2026-11-04) — posters
                                            // stay clean. PosterCard's strip
                                            // machinery stays dormant.
                                            onClick = { onOpenDetail(row.addonId, meta.type, meta.id) },
                                            onLongClick = { addToListTarget = row.addonId to meta }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                              }
                            }
                        }
                    }
                }
            }

        }
    }

    // No legacy long-press popup anymore (owner's fix #6, v0.14.7):
    // press & hold on any poster opens the unified AddToListSheet
    // DIRECTLY (see addToListTarget below) — one hold behaviour
    // app-wide, no intermediate dialog.

    // Continue Watching hold menu (v0.14.7, owner's fix #5): the only
    // way to clear an entry now.
    cwRemoveTarget?.let { item ->
        Dialog(onDismissRequest = { cwRemoveTarget = null }) {
            Column(
                modifier = Modifier
                    .liquidGlass(RoundedCornerShape(20.dp))
                    .padding(vertical = 8.dp),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                TextButton(
                    onClick = {
                        scope.launch {
                            // Deletes every row for this entry and
                            // remembers the removal, so the
                            // Trakt/Simkl import (item 13) doesn't
                            // resurrect it with older progress.
                            repository.removeContinueWatchingItem(item)
                        }
                        cwRemoveTarget = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Remove from Continue Watching", color = Color(0xFFF87171))
                }
                TextButton(
                    onClick = { cwRemoveTarget = null },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cancel", color = TextPrimary)
                }
            }
        }
    }

    // Add-to-list bottom sheet.
    addToListTarget?.let { (addonId, meta) ->
        AddToListSheet(
            listsRepository = listsRepository,
            addonId = addonId,
            type = meta.type,
            metaId = meta.id,
            name = meta.name,
            poster = meta.poster,
            onDismiss = { addToListTarget = null },
            repository = repository,
            year = meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
            rating = meta.imdbRating
        )
    }
}

/** One featured title for the hero carousel: its source addon plus metadata. */
private data class FeaturedTitle(val addonId: String, val meta: MetaPreview)

/**
 * Picks up to 6 featured titles for the hero carousel: titles with real
 * backdrop art first (falling back to poster-only titles so the carousel
 * never comes up empty when data is thin).
 */
private fun featuredTitles(rows: List<CatalogRow>, max: Int = 6): List<FeaturedTitle> {
    val all = rows.flatMap { row -> row.items.map { FeaturedTitle(row.addonId, it) } }
        .distinctBy { it.meta.id }
    if (all.isEmpty()) return emptyList()
    val withBackdrop = all.filter { !it.meta.background.isNullOrBlank() }
    return (withBackdrop + all).distinctBy { it.meta.id }.take(max)
}

/**
 * Netflix-style hero carousel: full-bleed backdrop pager at the top of
 * Home. Auto-advances every 5s on mobile (pausing while the user is touching
 * it); never auto-advances on TV to avoid stealing frames from D-pad input.
 * Tap opens the title's detail screen.
 *
 * v0.12.4 (owner's Sample C — "immersive"): the pager is now truly
 * full-bleed — edge-to-edge with no side padding, no rounded frame —
 * the list itself is shifted up under the status bar so the art owns
 * the screen's top edge; the swipe dots moved INSIDE the poster
 * (animated, active = elongated mint pill).
 *
 * v0.12.5 (owner's order): ~20% taller again — 380dp (was 316dp) — and
 * the hero is PINNED: it stays at the top while the catalog sheet
 * scrolls up and over it (the pin lives on the hero's list item in
 * [HomeScreen]; the pager itself is unchanged).
 */
@Composable
private fun HeroCarousel(
    featured: List<FeaturedTitle>,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    heroFocus: FocusRequester? = null,
    onWatchNow: (FeaturedTitle) -> Unit = {},
    onGoToLive: () -> Unit = {}
) {
    val palette = LocalPalette.current
    val pagerState = rememberPagerState(pageCount = { featured.size })
    val isTv = rememberIsTv()
    // Hero height: TV keeps the 380.dp backdrop hero. On mobile the hero
    // takes ~55% of the screen height with the poster filling it
    // edge-to-edge (owner approved 2026-10-27, item 23 — the 45% size
    // read small next to Nuvio's taller hero; the earlier 60% version
    // was full-poster Fit with blurred side bars, rejected on sight —
    // this stays full-bleed Crop, just taller).
    val heroHeight = if (isTv) 380.dp
        else (LocalConfiguration.current.screenHeightDp * 0.55f).dp + 40.dp

    val reducedMotion = com.pulsestream.app.data.rememberReducedMotion()
    LaunchedEffect(pagerState, featured.size, reducedMotion) {
        // No auto-advance on TV: the 5s full-bleed pager animation steals
        // frames from D-pad browsing on weak TV GPUs/CPUs and its backdrop
        // re-decodes cause jank spikes that coincide with user input.
        if (isTv || reducedMotion) return@LaunchedEffect
        while (featured.size > 1) {
            delay(5000)
            if (!pagerState.isScrollInProgress) {
                val next = (pagerState.currentPage + 1) % featured.size
                runCatching { pagerState.animateScrollToPage(next) }
            }
        }
    }

    Box {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(heroHeight),
            key = { index -> "hero_${featured[index].meta.id}_$index" }
        ) { index ->
            val item = featured[index]
            val meta = item.meta
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .tvFocusRing(RoundedCornerShape(0.dp))
                    .clickable { onOpenDetail(item.addonId, meta.type, meta.id) }
                    .then(if (heroFocus != null && index == 0) Modifier.focusRequester(heroFocus) else Modifier)
                    .focusable()
            ) {
                // Background-first on BOTH branches (owner, 2026-10-28):
                // portrait posters carry the title lettering baked in,
                // so drawing the poster on mobile doubled the title
                // once the resolved logo was overlaid on top. When a
                // backdrop exists, draw it full-bleed Crop; the poster
                // is used ONLY when there is no background. TV already
                // followed this rule — now mobile shares it.
                val heroBackground = meta.background?.takeIf { it.isNotBlank() }
                if (heroBackground != null) {
                    SafePosterImage(
                        model = tmdbSizedImage(heroBackground, "w1280"),
                        contentDescription = meta.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    SafePosterImage(
                        model = meta.poster,
                        contentDescription = meta.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.35f),
                                Color.Black.copy(alpha = 0.88f)
                            )
                        )
                    )
                )
                if (isTv) {
                    Column(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = meta.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val info = listOfNotNull(
                            meta.releaseInfo?.take(4),
                            meta.imdbRating?.let { "★ $it" },
                            meta.genres.firstOrNull()
                        ).joinToString("  •  ")
                        if (info.isNotBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = com.pulsestream.app.ui.components.accentStarText(info, LocalPalette.current.accent),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                } else {
                    // CENTER 1 (owner's lock 2026-10-26): centered block —
                    // title logo artwork when the meta carries one, else
                    // the title; facts line; Details (ghost) + Watch Now
                    // (accent) side by side; dots centered below.
                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, bottom = 42.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Studio logo as the hero title (items
                        // 14/15): catalog metas carry no logo, so
                        // resolve it in the background from the
                        // serving addon's meta; big + centred, the
                        // plain title only until/unless one lands.
                        val logo = com.pulsestream.app.ui.components.rememberResolvedLogo(
                            item.addonId, meta.type, meta.id, meta.logo
                        )
                        if (logo != null) {
                            SafePosterImage(
                                model = tmdbSizedImage(logo, "w500"),
                                contentDescription = meta.name,
                                modifier = Modifier
                                    .height(76.dp)
                                    .widthIn(max = 300.dp),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Text(
                                text = meta.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                        val facts = listOfNotNull(
                            if (meta.type == "series") "Series" else "Movie",
                            meta.genres.firstOrNull(),
                            meta.releaseInfo?.take(4)
                        ).joinToString("  •  ")
                        if (facts.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = facts,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Hero buttons a little smaller (owner,
                            // item 20): slimmer padding + labelMedium,
                            // same capsule style and positions.
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .border(
                                        1.dp, Color.White.copy(alpha = 0.45f),
                                        RoundedCornerShape(50)
                                    )
                                    .clickable { onOpenDetail(item.addonId, meta.type, meta.id) }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    "Details",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(palette.accent)
                                    .clickable { onWatchNow(item) }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = palette.accentText,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    "Watch Now",
                                    color = palette.accentText,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
        // Swipe dots INSIDE the poster's lower edge (v0.12.4): the active
        // dot stretches into an elongated pill, animated. CENTER 1
        // (v0.14.6): on phone the dots sit centered under the hero
        // buttons; TV keeps them bottom-end.
        if (featured.size > 1) {
            Row(
                Modifier
                    .align(if (isTv) Alignment.BottomEnd else Alignment.BottomCenter)
                    .padding(
                        end = if (isTv) 16.dp else 0.dp,
                        bottom = if (isTv) 18.dp else 14.dp
                    ),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(featured.size) { i ->
                    val active = i == pagerState.currentPage
                    val dotWidth by animateDpAsState(
                        targetValue = if (active) 18.dp else 6.dp,
                        animationSpec = tween(320),
                        label = "heroDot$i"
                    )
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .width(dotWidth)
                            .height(6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (active) LocalPalette.current.accent
                                else Color.White.copy(alpha = 0.35f)
                            )
                    )
                }
            }
        }
        // Item 15 (v0.14.24, owner's amendment 22:35 PKT): the hero
        // LIVE corner is REMOVED from Home — Live lives in the Search
        // tab's Discover → TV type now. The Live screen itself stays
        // reachable from elsewhere; only this Home corner is gone.
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ContinueWatchingCard(
    item: PlaybackState,
    posterArtwork: Boolean = false,
    onLongPress: () -> Unit,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(200.dp)
            .tvFocusRing(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongPress)
            .focusable()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
                .liquidGlass(RoundedCornerShape(14.dp))
        ) {
            // Artwork (item 35): Scene mode (default) shows the
            // saved still, exactly as before. Poster mode shows the
            // title's poster in the same tile: movie rows already
            // save the poster itself; episode rows save a scene, so
            // their poster resolves from the series meta in the
            // background. No poster anywhere = the scene art stays.
            val isEpisodeRow = item.season > 0 || item.episode > 0
            val resolvedCwPoster =
                com.pulsestream.app.ui.components.rememberResolvedCwPoster(
                    type = "series",
                    metaId = item.metaId?.takeIf { it.isNotBlank() }
                        ?: item.imdbId?.takeIf { it.isNotBlank() } ?: item.videoId,
                    enabled = posterArtwork && isEpisodeRow
                )
            val cardArt = if (posterArtwork) {
                resolvedCwPoster ?: item.poster
            } else {
                item.poster
            }
            SafePosterImage(
                model = tmdbSizedImage(cardArt, "w780"),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize()
            )
            // Studio logo artwork centred on the tile (item 11);
            // the logo is saved with the playback row (DB v15).
            // Rows without one (older saves, imports whose meta had
            // none) resolve it in the background like every other
            // tile (items 14/15).
            val cwLogo = com.pulsestream.app.ui.components.rememberResolvedLogo(
                addonId = null,
                type = if (item.season > 0 || item.episode > 0) "series" else "movie",
                metaId = item.metaId?.takeIf { it.isNotBlank() }
                    ?: item.imdbId?.takeIf { it.isNotBlank() } ?: item.videoId,
                known = item.logo
            )
            com.pulsestream.app.ui.components.PosterLogoOverlay(
                cwLogo, widthFraction = 0.6f, heightFraction = 0.52f
            )
            // No x button (owner's fix #5, v0.14.7): removal is
            // press & hold the card -> Remove (live channels can leak
            // into Continue Watching with no expiry, so the hold menu
            // keeps a manual clear for any entry).
            // Progress fraction: from the saved position normally;
            // imported Trakt rows whose runtime was unknown carry
            // only a percent (item 13) — the bar and % chip use it
            // so the card still reads as in-progress.
            val progressFraction = when {
                item.durationMs > 0 -> {
                    (item.positionMs.toFloat() / item.durationMs).coerceIn(0f, 1f)
                }
                item.remoteProgressPct != null -> {
                    (item.remoteProgressPct / 100f).coerceIn(0f, 1f)
                }
                else -> null
            }
            if (progressFraction != null) {
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp),
                    color = LocalPalette.current.accent,
                    trackColor = Color.Black.copy(alpha = 0.5f)
                )
            }
            // T1 chips (v0.14.6): frosted glass, theme glass only (no
            // accent tint) — remaining percent top-right (the exact
            // corner again in v0.14.7, now that the x button is gone),
            // time remaining bottom-right above the progress line.
            if (progressFraction != null && progressFraction > 0f && progressFraction < 1f) {
                val percentLeft = ((1f - progressFraction) * 100).toInt()
                CwGlassChip(
                    text = "$percentLeft% left",
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 6.dp, end = 6.dp)
                )
                if (item.durationMs > 0) {
                    val remainingMsChip = item.durationMs - item.positionMs
                    if (remainingMsChip > 60_000) {
                        CwGlassChip(
                            text = "${formatRemaining(remainingMsChip)} left",
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 6.dp, bottom = 8.dp)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = item.title,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        val remainingMs = item.durationMs - item.positionMs
        // H-A (owner's pick 2026-10-24): the slot under a Continue
        // Watching title carries the time left as a quiet micro label —
        // the same slot catalog cards use for the popularity meter, and
        // no meter here. (PlaybackState has no rating, so no rating
        // chip on these cards.)
        val slotStyle = MaterialTheme.typography.labelSmall.copy(
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
        if (remainingMs > 60_000) {
            Text(
                text = "${formatRemaining(remainingMs)} LEFT".uppercase(),
                style = slotStyle,
                color = TextSecondary,
                maxLines = 1
            )
        } else {
            Text(
                text = "RESUME",
                style = slotStyle,
                color = TextSecondary,
                maxLines = 1
            )
        }
    }
}

/**
 * Frosted glass capsule for the Continue Watching T1 chips: fitted
 * backing + liquid glass, theme glass only — never accent-tinted.
 */
@Composable
private fun CwGlassChip(text: String, modifier: Modifier = Modifier) {
    Box(modifier) {
        Box(
            Modifier
                .matchParentSize()
                .clip(RoundedCornerShape(50))
                .background(
                    if (LocalPalette.current.light) {
                        Color.White.copy(alpha = 0.82f)
                    } else {
                        Color.Black.copy(alpha = 0.48f)
                    },
                    RoundedCornerShape(50)
                )
        )
        Box(
            Modifier
                .liquidGlass(RoundedCornerShape(50), frost = 0.12f, darken = 0.03f)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text,
                color = TextPrimary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/** "50m left" / "1h 20m left" for Continue Watching cards. */
private fun formatRemaining(ms: Long): String {
    val totalMin = (ms / 60_000).toInt().coerceAtLeast(1)
    val h = totalMin / 60
    val m = totalMin % 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}

/** Starter addons for the guided empty-state steps (Sample C).
 *  PMeta's URL follows the effective PMeta door (AppConfig: remote
 *  config → compiled default meta.plavio.site), read at click time. */
private val META_ADDON_URL: String get() = AppConfig.pmetaManifestUrl()
private const val STREAMS_ADDON_URL = "https://hd.plavio.site/manifest.json"

private enum class SetupStepState { Idle, Adding, Added, Failed }

/**
 * "No addons yet" — Sample C (owner's pick 2026-10-24), completed in
 * v0.14.10 (item 36): two guided steps instead of one vague button.
 * Metadata first, streams second, each with its own one-tap Add (the
 * same install path as onboarding). Step states reflect REALITY: an
 * addon already on the device (PlavioHD is pre-installed) shows
 * "✓ Added" without any tap. The ghost button below opens the full
 * Addons screen for any URL. Only reachable when Home has no usable
 * catalogs, so configured users never see it.
 */
@Composable
private fun NoAddonsEmptyState(
    repository: StreamRepository,
    onGoToAddons: () -> Unit,
    onReload: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var metaStep by remember { mutableStateOf(SetupStepState.Idle) }
    var streamsStep by remember { mutableStateOf(SetupStepState.Idle) }
    val installed by repository.addons.collectAsState(initial = emptyList())
    val metaInstalled = installed.any {
        it.id.contains("plaviometa", true) || it.baseUrl.contains("plaviometa", true)
    }
    val streamsInstalled = installed.any {
        it.baseUrl.contains("hd.plavio.site") ||
            it.baseUrl.contains("addon.plavio.site") ||
            it.id.contains("plaviohd", true)
    }

    fun add(url: String, set: (SetupStepState) -> Unit) {
        set(SetupStepState.Adding)
        scope.launch {
            val result = repository.addAddonFromUrl(url)
            if (result.isSuccess) {
                set(SetupStepState.Added)
                onReload()
            } else {
                set(SetupStepState.Failed)
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 58.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.foundation.Image(
                painter = painterResource(com.pulsestream.app.R.drawable.weave_mark),
                contentDescription = null,
                modifier = Modifier.size(76.dp)
            )
            Spacer(Modifier.height(14.dp))
            Text(
                "Welcome to Plavio",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Your home is empty for now \u2014 two quick steps and it fills up.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(2.dp))
        SetupStepRow(
            number = 1,
            title = "Add a metadata addon",
            subtitle = "Posters, ratings, cast and story info for every movie and show.",
            state = if (metaInstalled) SetupStepState.Added else metaStep,
            onAdd = { add(META_ADDON_URL) { metaStep = it } }
        )
        SetupStepRow(
            number = 2,
            title = "Add a streams addon",
            subtitle = "The play buttons \u2014 movies, series and live TV in HD and 4K.",
            state = if (streamsInstalled) SetupStepState.Added else streamsStep,
            onAdd = { add(STREAMS_ADDON_URL) { streamsStep = it } }
        )
        if (streamsInstalled && !metaInstalled) {
            Text(
                "PlavioHD is already added for streams \u2014 and PMeta takes just one tap for metadata.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Text(
            "Or tap \u201CAdd an addon\u201D below to paste any addon URL.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Box(
            Modifier
                .fillMaxWidth()
                .background(GlassWhite, RoundedCornerShape(50))
                .border(1.dp, GlassBorder, RoundedCornerShape(50))
                .clickable { onGoToAddons() }
                .padding(vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Add an addon",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun SetupStepRow(
    number: Int,
    title: String,
    subtitle: String,
    state: SetupStepState,
    onAdd: () -> Unit
) {
    val palette = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .liquidGlass(RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier
                .size(26.dp)
                .background(palette.accent.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "$number",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = palette.accentText
            )
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            if (state == SetupStepState.Failed) {
                Text(
                    "Couldn't add it \u2014 check your connection and try again.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        when (state) {
            SetupStepState.Adding -> OrbitDots(modifier = Modifier.size(22.dp))
            SetupStepState.Added -> Box(
                Modifier
                    .background(Color(0xFF22C55E).copy(alpha = 0.14f), RoundedCornerShape(50))
                    .border(1.dp, Color(0xFF22C55E).copy(alpha = 0.45f), RoundedCornerShape(50))
                    .padding(horizontal = 11.dp, vertical = 6.dp)
            ) {
                Text(
                    "\u2713 Added",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4ADE80)
                )
            }
            else -> Box(
                Modifier
                    .background(palette.accent, RoundedCornerShape(50))
                    .clickable { onAdd() }
                    .padding(horizontal = 13.dp, vertical = 7.dp)
            ) {
                Text(
                    if (state == SetupStepState.Failed) "Retry" else "+ Add",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF04120B)
                )
            }
        }
    }
}

/**
 * Home loading skeleton (item 36, owner's UX pass 2026-10-28): while
 * catalogs load, the hero block and two rails show poster-shaped
 * shimmer placeholders in the real layout instead of blank space.
 * The orbit stays the loader for the player and Live, where it
 * already lives — this is layout-shaped waiting, not a spinner.
 */
@Composable
private fun HomeLoadingSkeleton() {
    val screenH = LocalConfiguration.current.screenHeightDp
    Column(Modifier.fillMaxSize()) {
        com.pulsestream.app.ui.components.ShimmerPoster(
            Modifier
                .fillMaxWidth()
                .height((screenH * 0.55f).dp + 40.dp)
        )
        Spacer(Modifier.height(20.dp))
        repeat(2) {
            Box(
                Modifier
                    .padding(start = 16.dp)
                    .width(150.dp)
                    .height(16.dp)
                    .background(Color.White.copy(alpha = 0.10f), RoundedCornerShape(50))
            )
            Spacer(Modifier.height(12.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(4) {
                    com.pulsestream.app.ui.components.ShimmerPoster(
                        Modifier.width(128.dp).height(180.dp)
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
