package com.pulsestream.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Home Switch (v0.14.26, batch item 1 + owner's fold clarification
 * 2026-11-07 ~15:25 PKT): the control sits inside Addons &
 * Integrations, between Manage addons and Integrations, as ONE
 * row — and its options are FOLDED INSIDE that row: collapsed it
 * shows only the row itself (icon, "Home Switch", the current
 * pick, chevron); tapping expands the addon switches in place,
 * inside this control. The options never render as separate rows
 * outside it and never open another page.
 *
 * Each option is a catalog addon with an on/off switch. Turning
 * one ON makes it the home catalog provider (the same stored pick
 * the hold-Home picker writes); turning the active one OFF clears
 * the pick, so Home falls back to the default provider instead of
 * an empty screen. One setting, one home.
 */
@Composable
fun HomeSwitchSection(repository: StreamRepository) {
    var expanded by remember { mutableStateOf(false) }
    var homeChoices by remember {
        mutableStateOf<List<StreamRepository.HomeCatalogChoice>>(emptyList())
    }
    var homeProviderId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        homeChoices = runCatching { repository.homeCatalogChoices() }
            .getOrDefault(emptyList())
        homeProviderId = runCatching { repository.homeMetaProviderId() }
            .getOrNull()
    }
    val currentName = homeChoices.firstOrNull { it.addonId == homeProviderId }?.addonName
    Column {
        // The folded control itself: a standard grouped Settings
        // row (icon tile + bold name + one-line current pick +
        // expand chevron), exactly the hub's other rows' shape.
        SettingsGroup(
            {
                SettingsStaticRow(
                    icon = Icons.Filled.Home,
                    title = "Home Switch",
                    subtitle = currentName?.let { "Home provider: $it" }
                        ?: "Choose which addon fills Home",
                    trailing = {
                        Icon(
                            if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = if (expanded) "Collapse Home Switch" else "Expand Home Switch",
                            tint = TextSecondary
                        )
                    },
                    onClick = { expanded = !expanded }
                )
            }
        )
        // The options, folded INSIDE the control: rendered only
        // while expanded, within this composable's own column.
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(
                    "The addon switched on here fills your Home screen.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
                if (homeChoices.isEmpty()) {
                    Text(
                        "No catalog addons yet — install one from Manage addons and it will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    homeChoices.forEach { choice ->
                        val isOn = choice.addonId == homeProviderId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isOn) {
                                        repository.settings.homeMetaProviderAddonId = null
                                        homeProviderId = homeChoices
                                            .firstOrNull { it.addonId != choice.addonId }
                                            ?.addonId
                                    } else {
                                        repository.settings.homeMetaProviderAddonId =
                                            choice.addonId
                                        homeProviderId = choice.addonId
                                    }
                                    HomeCatalogSignal.requestReload()
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    choice.addonName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isOn) TextPrimary else TextSecondary
                                )
                                Text(
                                    "${choice.catalogs.size} catalogs" +
                                        if (isOn) " · Home provider" else "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Switch(
                                checked = isOn,
                                onCheckedChange = { wantOn ->
                                    repository.settings.homeMetaProviderAddonId =
                                        if (wantOn) choice.addonId else null
                                    homeProviderId = if (wantOn) {
                                        choice.addonId
                                    } else {
                                        homeChoices.firstOrNull { it.addonId != choice.addonId }
                                            ?.addonId
                                    }
                                    HomeCatalogSignal.requestReload()
                                },
                                colors = settingsSwitchColors()
                            )
                        }
                    }
                }
            }
        }
    }
}
