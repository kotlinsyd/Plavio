package com.pulsestream.app

import android.app.Application
import android.util.Log
import androidx.room.Room
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StremioApi
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.MIGRATION_1_2
import com.pulsestream.app.data.db.MIGRATION_2_3
import com.pulsestream.app.data.db.MIGRATION_3_4
import com.pulsestream.app.data.db.MIGRATION_4_5
import com.pulsestream.app.data.db.MIGRATION_11_12
import com.pulsestream.app.data.db.MIGRATION_12_13
import com.pulsestream.app.data.db.MIGRATION_13_14
import com.pulsestream.app.data.db.MIGRATION_14_15
import com.pulsestream.app.data.db.MIGRATION_15_16
import com.pulsestream.app.data.db.MIGRATION_16_17
import com.pulsestream.app.data.db.MIGRATION_17_18
import com.pulsestream.app.data.db.MIGRATION_18_19
import com.pulsestream.app.data.db.MIGRATION_5_6
import com.pulsestream.app.data.db.MIGRATION_6_7
import com.pulsestream.app.data.db.MIGRATION_7_8
import com.pulsestream.app.data.db.MIGRATION_8_9
import com.pulsestream.app.data.db.MIGRATION_9_10
import com.pulsestream.app.data.db.MIGRATION_10_11
import com.pulsestream.app.ui.tv.isTelevision
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PulseApp : Application(), ImageLoaderFactory {

    /**
     * TV-tuned image pipeline: on memory-constrained TVs (48MB heap class
     * seen in the field) Coil's default ~25% memory cache plus hundreds of
     * posters causes lag and OOMs. Cap it to 8% on TV; phones keep default.
     */
    override fun newImageLoader(): ImageLoader {
        val lowMem = isTelevision()
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(if (lowMem) 0.08 else 0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            // Downscale posters on TV: cards are ~128dp wide, no need for full-res.
            .respectCacheHeaders(false)
            // SVG decoding (v0.14.26, item 13): stock Coil cannot
            // render SVG at all — addon logos declared as .svg
            // (PlavioHD's logo.svg) failed silently and the addons
            // list showed only the initial tile. Registering the
            // coil-svg decoder fixes every SVG image app-wide.
            .components {
                add(coil.decode.SvgDecoder.Factory())
            }
            .build()
    }

    lateinit var repository: StreamRepository
        private set

    lateinit var settings: SettingsStore
        private set

    lateinit var database: AppDatabase
        private set

    /**
     * A crashing background task must never kill the app (previously an
     * uncaught exception here meant an instant force-close loop that also
     * bricked the in-app updater). Failures are logged instead.
     */
    private val appScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, e ->
            Log.e("PulseApp", "Background startup task failed", e)
        }
    )

    override fun onCreate() {
        installCrashCatcher()
        super.onCreate()
        com.pulsestream.app.data.MotionPreferences.initialize(this)
        val db = openDatabase()
        database = db
        settings = SettingsStore(this)
        // Local profiles (v0.14.13, item 8): resolve the active
        // profile BEFORE the repository exists — every partitioned
        // DAO read defaults to CurrentProfile. A cold start opens
        // into the default profile (a pending manual switch is the
        // one-shot exception); seeding/repair runs async below.
        val profilesManager = com.pulsestream.app.data.ProfilesManager(db, settings)
        profilesManager.applyColdStartProfile()
        repository = StreamRepository(db, StremioApi(), settings)
        // Remote app config (owner's order 2026-10-31: little
        // server-driven updates without an APK): doors, announcement,
        // minimum-version floor and feature switches published at
        // meta.plavio.site/app-config.json. Loads the last-good copy
        // synchronously from prefs, then refreshes in the background
        // on its own dispatcher — startup never waits on it, and any
        // failure leaves the compiled-in defaults, which reproduce
        // the pre-config behaviour exactly.
        com.pulsestream.app.data.AppConfig.start(this)
        // v0.14.17 lag fix (audit cause 4): the one-shot startup
        // jobs below used to fire as ~8 concurrent appScope launches
        // competing for the IO pool and the SQLite file during the
        // first seconds of browsing. They now run as ONE sequential
        // chain, cheap checks first, each step failure-isolated so
        // one bad step never starves the rest.
        appScope.launch {
            // P2 (v0.14.22): interrupted-download recovery starts from
            // the APPLICATION, not from opening the Downloads screen —
            // after a process death the rows resume on their own.
            runCatching {
                com.pulsestream.app.data.download.DownloadManager.get(this@PulseApp)
                    .recoverInterruptedDownloads()
            }
            runCatching { profilesManager.ensureSeeded() }
            // Quietly install the pre-installed addons (PlavioHD + PlavioMeta) on first launch.
            runCatching { repository.ensurePreinstalledAddons() }
            // v0.14.34 (owner's order 2026-11-01): the LOCKED PlavioHD
            // (addon.plavio.site) is retired — no longer installed. This
            // cleanup deletes its shipped row along with the other
            // retired pre-installed addons (OpenSubtitles v3, SubSense,
            // Cinemeta since v0.14.35, and untouched CNCVerse/Pengu/Pipe
            // bundle rows).
            // Then the beginner bundle (all OFF by default).
            runCatching { repository.removeRetiredPreinstalledAddons() }
            runCatching { repository.removePreinstalledPublicHd() }
            runCatching { repository.ensureBundledAddons() }
            // Fill in addon logos for installs from before logos were stored.
            runCatching { repository.backfillAddonLogos() }
            // Give pre-ordering addons distinct positions so rearrange works.
            runCatching { repository.normalizeAddonSortOrder() }
            // Drop catalog rows too big for SQLite's CursorWindow (reading one
            // would crash Home with SQLiteBlobTooBigException). Surgical — the
            // watchlist, addons and settings survive.
            runCatching { repository.pruneOversizedCache() }
            // Trakt/Simkl library sync on launch, at most every 6 hours, only
            // when an account is linked (issue #3). Last in the chain: it is
            // the network-heavy step and nothing else waits on it.
            runCatching {
                val sync = com.pulsestream.app.data.LibrarySyncManager(db, settings)
                if (sync.isLinked() &&
                    System.currentTimeMillis() - settings.librarySyncLastAt > 6 * 3600_000L
                ) {
                    sync.sync()
                }
            }
        }
        // Studio-logo resolution for poster tiles/heroes (items
        // 14/15): catalog items carry no logo, so tiles resolve it
        // in the background through the repository's meta walk.
        com.pulsestream.app.data.LogoResolver.fetcher = { addonId, type, metaId ->
            repository.resolveLogoUrl(addonId, type, metaId)
        }
        // Title posters for Continue Watching tiles in Poster
        // artwork mode (item 35): same background-resolution wiring.
        com.pulsestream.app.data.CwPosterResolver.fetcher = { addonId, type, metaId ->
            repository.resolvePosterUrl(addonId, type, metaId)
        }
        // MDBList ratings for Home poster cards (item 29, owner's
        // order 2026-10-28): cards resolve ratings in the background
        // through the repository, cached on disk by the resolver.
        com.pulsestream.app.data.MdbRatingsResolver.fetcher = { imdbId ->
            repository.mdbRatings(imdbId)
        }
        com.pulsestream.app.data.MdbRatingsResolver.settings = settings
        // Anonymous install/session counting on the owner's own
        // stats server (open-source backend, no Google — his order
        // 2026-10-22). Fire-and-forget; never blocks startup.
        appScope.launch { com.pulsestream.app.data.AppStats.trackLaunch(this@PulseApp) }
        // Sentry crash reports (his order 2026-10-23): ON by default with a
        // Settings opt-out. Initialized on a background thread, off the
        // launch path, and fully guarded — a Sentry failure can never stop
        // the app from opening (v0.12.23 lesson: the build where Sentry
        // first went live crashed on open before it could report anything).
        appScope.launch { com.pulsestream.app.data.CrashReports.initIfEnabled(this@PulseApp, settings) }
        // (The pre-installed-addon installs, addon housekeeping and the
        // launch library-sync check run in the serialised one-shot chain
        // above — v0.14.17 lag fix.)
        // Silent Plavio-account auto-backup (owner's order 2026-10-29):
        // once per cold start (Application.onCreate), only when signed
        // in and the Auto backup toggle (Account & Sync) is on.
        // Fire-and-forget — failures are swallowed inside autoBackup()
        // and retried on the next open.
        // v0.14.17 lag fix (audit cause 4): the backup used to land at
        // +20 s — in the middle of the user's first browsing — and
        // serialised the whole library (disk + CPU + upload) on a
        // low-end phone. It now waits +90 s and NEVER runs while the
        // player is open: it waits, bounded, for playback to end, and
        // if the player stays open it skips this cold start entirely
        // (the next open retries, as before).
        appScope.launch {
            val accountManager =
                com.pulsestream.app.data.cloud.PlavioAccountManager(this@PulseApp, repository)
            // P2: a due backup is marked PENDING (persisted) up front, so
            // a process death before the timer can't silently drop it —
            // the flag + last-state stay visible until an upload lands.
            if (runCatching { accountManager.autoBackupDue() }.getOrDefault(false)) {
                settings.autoBackupPending = true
            }
            kotlinx.coroutines.delay(90_000)
            var waits = 0
            while (MainActivity.isPlayerActive && waits < 10) {
                kotlinx.coroutines.delay(30_000)
                waits++
            }
            if (!MainActivity.isPlayerActive) {
                runCatching { accountManager.autoBackup() }
            } else if (settings.autoBackupPending) {
                settings.autoBackupLastState =
                    "held: player stayed open — will retry next launch"
            }
        }
        // Keep the library in sync shortly after the user adds/removes a
        // title (debounced inside the repository hook by the sync's own
        // throttle: the manager no-ops when a sync ran in the last minute).
        repository.onWatchlistChanged = {
            appScope.launch {
                val sync = com.pulsestream.app.data.LibrarySyncManager(db, settings)
                if (sync.isLinked() &&
                    System.currentTimeMillis() - settings.librarySyncLastAt > 60_000L
                ) {
                    runCatching { sync.sync() }
                }
            }
        }
    }

    /**
     * Opens the database, self-healing ONLY from genuine file corruption.
     *
     * A corrupt database file is renamed to a .corrupt.bak backup (never
     * silently deleted) before recreating empty, so user data can still be
     * recovered. Any other failure — failed migration, transient I/O error,
     * programming bug — is rethrown to crash loudly (and show up in the
     * local crash dialog) instead of silently wiping the user's add-ons, watchlist and history.
     * The in-app updater keeps working, so a fix can always reach the phone.
     */
    private fun openDatabase(): AppDatabase {
        return try {
            buildDatabase().also {
                // Force the open now — throws here if the file is corrupt.
                it.openHelper.writableDatabase
            }
        } catch (e: Exception) {
            if (!isCorruption(e)) {
                // Not corruption — do NOT delete user data. Crash loudly so
                // the real bug is visible in the crash dialog instead of
                // masking it as an empty database.
                throw e
            }
            Log.e("PulseApp", "Database file corrupt, backing up and recreating", e)
            // Rename the corrupt file as a backup instead of deleting it.
            runCatching {
                val dbFile = getDatabasePath(DB_NAME)
                if (dbFile.exists()) {
                    val bak = java.io.File(dbFile.parent, "$DB_NAME.corrupt.bak")
                    runCatching { bak.delete() }
                    dbFile.renameTo(bak)
                    // Also move the -wal / -shm sidecars so they don't confuse reopen.
                    for (suffix in listOf("-wal", "-shm")) {
                        runCatching {
                            java.io.File(dbFile.parent, "$DB_NAME$suffix").renameTo(
                                java.io.File(dbFile.parent, "$DB_NAME$suffix.corrupt.bak")
                            )
                        }
                    }
                } else {
                    deleteDatabase(DB_NAME)
                }
            }
            // The fresh DB is empty but the preinstall_done_* flags survived
            // in SharedPreferences — without clearing them the bundled
            // addons (PlavioMeta/Cinemeta/…) would never be reinstalled and
            // the app would look broken with no explanation.
            runCatching { SettingsStore(this).clearPreinstallFlags() }
            buildDatabase()
        }
    }

    /** True only for genuine SQLite file-corruption failures. */
    private fun isCorruption(e: Throwable): Boolean {
        var t: Throwable? = e
        while (t != null) {
            if (t is android.database.sqlite.SQLiteDatabaseCorruptException) return true
            val msg = (t.message ?: "").lowercase()
            // SQLite corruption signatures — deliberately narrow so a failed
            // migration or I/O error never counts as "corrupt".
            if ("database disk image is malformed" in msg ||
                "file is not a database" in msg ||
                "database is corrupt" in msg ||
                "notadb" in msg
            ) return true
            t = t.cause
        }
        return false
    }

    private fun buildDatabase(): AppDatabase =
        Room.databaseBuilder(this, AppDatabase::class.java, DB_NAME)
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19)
            .build()

    /**
     * Saves any uncaught crash to internal storage. On the next launch
     * MainActivity shows it with a Copy button, so the user can send it
     * for diagnosis.
     */
    private fun installCrashCatcher() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                openFileOutput("last_crash.txt", MODE_PRIVATE).bufferedWriter().use { out ->
                    out.write(Log.getStackTraceString(throwable))
                }
            } catch (_: Exception) {
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    /** Crash log from the previous run, if the app died with an exception. */
    fun readCrashReport(): String? {
        val f = java.io.File(filesDir, "last_crash.txt")
        return if (f.exists()) f.readText().take(6000) else null
    }

    fun clearCrashReport() {
        try {
            java.io.File(filesDir, "last_crash.txt").delete()
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val DB_NAME = "pulse-stream.db"
    }
}
