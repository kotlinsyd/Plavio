package com.pulsestream.app.data.notifications

import android.content.Context
import androidx.room.Room
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.StremioApi
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.MIGRATION_1_2
import com.pulsestream.app.data.db.MIGRATION_2_3
import com.pulsestream.app.data.db.MIGRATION_3_4
import com.pulsestream.app.data.db.MIGRATION_4_5
import com.pulsestream.app.data.db.MIGRATION_5_6
import com.pulsestream.app.data.db.MIGRATION_6_7
import com.pulsestream.app.data.db.MIGRATION_7_8
import com.pulsestream.app.data.db.MIGRATION_12_13
import com.pulsestream.app.data.db.MIGRATION_13_14
import com.pulsestream.app.data.db.MIGRATION_14_15
import com.pulsestream.app.data.db.MIGRATION_15_16
import com.pulsestream.app.data.db.MIGRATION_16_17
import com.pulsestream.app.data.db.MIGRATION_17_18
import com.pulsestream.app.data.db.MIGRATION_18_19
import java.time.LocalDate

/**
 * Periodic background check for new episodes of followed series.
 *
 * Runs every [EpisodeNotifications.CHECK_INTERVAL_HOURS] hours when the
 * network is connected and the battery isn't low. For each followed show it
 * resolves the series meta through the repository's cache funnel, finds
 * the newest released episode, and notifies when it's newer than the last
 * seen one.
 *
 * v0.14.13 (audit §3.1 fix): the scan set is the UNION of everything
 * the user follows — the on-device watchlist, the Trakt watchlist
 * and watching/progress, the Simkl plan/watching/by-status/custom
 * lists (StreamRepository.followedSeries, the same union the
 * Library's Upcoming scan reads) — plus series the user subscribed
 * with the detail page's bell, minus bell-muted series
 * ([EpisodeNotifyStore]). The pre-fix worker read ONLY the local
 * watchlist through its own per-addon walk, so notifications could
 * never fire for Trakt/Simkl follows and never touched the disk
 * meta cache. Meta reads now go through
 * [StreamRepository.getMetaFromAny] (cache-first).
 *
 * The first check for a show only records a baseline — no notification —
 * so installing the feature (or re-adding a show) never spams.
 *
 * All failures are contained per show and never crash the worker: an
 * unreachable addon simply means "try again next cycle".
 */
class EpisodeCheckWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val settings = SettingsStore(ctx)
        if (!settings.episodeNotifications) {
            EpisodeNotifications.cancel(ctx)
            return Result.success()
        }

        // Don't resurrect an empty database if the app's own open failed.
        val dbFile = ctx.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) return Result.success()

        val db = runCatching {
            Room.databaseBuilder(ctx, AppDatabase::class.java, DB_NAME)
                .addMigrations(
                    MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5,
                    MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_12_13,
                    MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17,
                    MIGRATION_17_18, MIGRATION_18_19
                )
                .build()
        }.getOrNull() ?: return Result.success()

        // Hoisted so the finally can stop the repository's
        // collectors before db.close() (Kotlin: try-block
        // declarations are not visible in finally).
        var repoRef: StreamRepository? = null
        try {
            val tracker = EpisodeTracker(ctx)
            val notifyStore = EpisodeNotifyStore(ctx)
            val repository = StreamRepository(db, StremioApi(), settings)
            repoRef = repository

            val addons = runCatching { db.addonDao().getAll() }.getOrNull().orEmpty()
            val metaAddons = addons
                .filter { it.enabled && "meta" in it.resourceSet }
                .associateBy { it.id }

            // Scan set (v0.14.13): followed union ∪ bell-subscribed,
            // minus bell-muted. Local entries keep their serving
            // addon (and their existing tracker baselines); service
            // and bell entries carry addonId "".
            val byId = LinkedHashMap<String, StreamRepository.FollowedSeries>()
            runCatching { repository.followedSeries() }.getOrDefault(emptyList())
                .forEach { byId[it.metaId] = it }
            notifyStore.subscribed().forEach { (metaId, name) ->
                if (metaId !in byId) {
                    byId[metaId] = StreamRepository.FollowedSeries(metaId, "", name ?: "")
                }
            }
            val series = byId.values.filter { notifyStore.explicitChoice(it.metaId) != false }
            if (series.isEmpty()) {
                tracker.prune(emptySet())
                return Result.success()
            }

            val keepKeys = mutableSetOf<String>()
            for (item in series) {
                val key = EpisodeTracker.key(item.addonId, item.metaId)
                keepKeys.add(key)
                runCatching {
                    // Cache funnel (v0.14.13): disk meta cache first,
                    // the serving addon hinted for local entries.
                    val hint = item.addonId.takeIf { it.isNotBlank() }
                        ?.let { metaAddons[it]?.baseUrl }
                    val meta = repository.getMetaFromAny(
                        hint, "series", item.metaId, requireVideos = true
                    ) ?: return@runCatching
                    val newest = newestReleased(meta.videos)
                        ?: return@runCatching

                    val last = tracker.lastKnown(item.addonId, item.metaId)
                    if (last == null) {
                        // Baseline: record without notifying.
                        tracker.update(item.addonId, item.metaId, newest.first, newest.second)
                    } else if (isNewer(newest.first, newest.second, last.first, last.second)) {
                        val epTitle = meta.videos
                            .firstOrNull { it.season == newest.first && it.episode == newest.second }
                            ?.title?.takeIf { it.isNotBlank() }
                        EpisodeNotifications.postNewEpisode(
                            ctx, item.addonId, item.metaId,
                            item.name.ifBlank { meta.name },
                            newest.first, newest.second, epTitle
                        )
                        tracker.update(item.addonId, item.metaId, newest.first, newest.second)
                    }
                }
            }
            tracker.prune(keepKeys)
        } finally {
            // v0.14.19 (PLAVIO-K): stop the repository's collectors
            // before closing the DB they query.
            runCatching { repoRef?.shutdown() }
            runCatching { db.close() }
        }
        return Result.success()
    }

    private fun isNewer(s: Int, e: Int, lastS: Int, lastE: Int): Boolean =
        s > lastS || (s == lastS && e > lastE)

    /**
     * Newest episode that has actually aired.
     *
     * Date verdicts (v0.14.15, closing the audit's open finding):
     * - no date at all (null/blank): treated as released — metadata
     *   sources usually omit the date rather than lie about it;
     * - a parseable date: released iff it is not in the future;
     * - a NON-blank date that cannot be parsed: UNKNOWN — the episode
     *   is excluded from candidacy, because an unparseable date must
     *   never cause a notification for an unaired episode (the old
     *   code treated garbage like "2027-13-45" or "TBA" as released).
     *   A leading year still decides when it can: a future year is
     *   FUTURE, a past year is RELEASED. UNKNOWN is per-episode —
     *   the rest of the series keeps alerting normally, and once the
     *   addon fixes the date the episode notifies on a later cycle.
     */
    private fun newestReleased(
        videos: List<com.pulsestream.app.data.Video>
    ): Pair<Int, Int>? {
        val today = runCatching { LocalDate.now() }.getOrNull() ?: return videos
            .maxWithOrNull(compareBy({ it.season }, { it.episode }))
            ?.let { it.season to it.episode }
        return videos
            .filter { v -> dateVerdict(v.released, today) == DateVerdict.RELEASED }
            .maxWithOrNull(compareBy({ it.season }, { it.episode }))
            ?.let { it.season to it.episode }
    }

    private enum class DateVerdict { RELEASED, FUTURE, UNKNOWN }

    private fun dateVerdict(raw: String?, today: LocalDate): DateVerdict {
        if (raw.isNullOrBlank()) return DateVerdict.RELEASED
        parseDatePrefix(raw)?.let { date ->
            return if (date.isAfter(today)) DateVerdict.FUTURE else DateVerdict.RELEASED
        }
        // Unparseable but non-blank: a 4-digit year anywhere in the
        // string still proves the episode's era.
        val year = Regex("(?:19|20)\\d{2}").find(raw)?.value?.toIntOrNull()
            ?: return DateVerdict.UNKNOWN
        return when {
            year > today.year -> DateVerdict.FUTURE
            year < today.year -> DateVerdict.RELEASED
            else -> DateVerdict.UNKNOWN
        }
    }

    /** Parses a leading "yyyy-MM-dd" (ISO datetime prefixes included). */
    private fun parseDatePrefix(raw: String): LocalDate? {
        val parts = raw.take(10).split("-")
        if (parts.size != 3) return null
        val y = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val d = parts[2].toIntOrNull() ?: return null
        return runCatching { LocalDate.of(y, m, d) }.getOrNull()
    }

    companion object {
        private const val DB_NAME = "pulse-stream.db"
    }
}
