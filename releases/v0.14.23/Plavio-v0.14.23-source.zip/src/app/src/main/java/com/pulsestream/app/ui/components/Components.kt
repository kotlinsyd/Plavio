package com.pulsestream.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.imageLoader
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import com.pulsestream.app.data.MetaPreview
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.pulsestream.app.ui.tv.tvFocusRing
import com.pulsestream.app.ui.tv.rememberIsTv
import com.pulsestream.app.ui.theme.AppTheme
import com.pulsestream.app.ui.theme.LocalCardCorner
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.LocalPosterCorner
import com.pulsestream.app.ui.theme.LocalPosterScale
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.GlassWhite
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/** Full-screen deep background with soft accent radial glows.
 * On TV the 3 fullscreen radial gradients are skipped (flat background):
 * re-executing 3 fullscreen gradient shaders on every animation frame is
 * fill-rate-bound on weak TV GPUs and turned small focus animations into
 * jank. Mobile keeps the glows. */
@Composable
fun GlowBackground(content: @Composable BoxScope.() -> Unit) {
    val palette = LocalPalette.current
    val isTv = rememberIsTv()
    Box(modifier = Modifier.fillMaxSize().background(palette.background)) {
        if (!isTv && palette.glowAlpha > 0f) {
            Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val glow1 = palette.accent
            val glow2 = palette.accent2
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glow1.copy(alpha = 0.16f * palette.glowAlpha), Color.Transparent),
                    center = Offset(w * 0.12f, h * 0.06f),
                    radius = w * 0.75f
                ),
                radius = w * 0.75f,
                center = Offset(w * 0.12f, h * 0.06f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glow2.copy(alpha = 0.13f * palette.glowAlpha), Color.Transparent),
                    center = Offset(w * 0.92f, h * 0.55f),
                    radius = w * 0.8f
                ),
                radius = w * 0.8f,
                center = Offset(w * 0.92f, h * 0.55f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glow1.copy(alpha = 0.07f * palette.glowAlpha), Color.Transparent),
                    center = Offset(w * 0.4f, h * 1.02f),
                    radius = w * 0.9f
                ),
                radius = w * 0.9f,
                center = Offset(w * 0.4f, h * 1.02f)
            )
            }
        }
        content()
    }
}

/** Liquid-glass card: gradient fill, top sheen, accent glow and a specular rim (see [liquidGlass]). */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    // Pill-leaning radius (user's order 2026-10-20): big soft corners.
    // v0.14.39 (appearance item E): the radius rides LocalCardCorner —
    // 28.dp Rounded (the shipped look) or 8.dp Sharp.
    val shape = RoundedCornerShape(LocalCardCorner.current)
    val clickableMod = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .then(clickableMod)
            .tvFocusRing(shape)
            .liquidGlass(shape),
        content = content
    )
}

/** A compact glass control with a reliable 48dp minimum touch target. */
@Composable
fun GlassIconButton(
    image: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = TextPrimary
) {
    // Full pill for small glass controls (user's order 2026-10-20).
    val shape = RoundedCornerShape(50)
    IconButton(
        onClick = onClick,
        modifier = modifier
            .sizeIn(minWidth = 48.dp, minHeight = 48.dp)
            .liquidGlass(shape)
    ) {
        Icon(image, contentDescription = contentDescription, tint = tint)
    }
}

/**
 * Poster card with glow shadow for catalog rows / grids.
 *
 * When [onLongClick] is provided, the card itself handles the combined
 * tap/long-press gesture: a plain inner `clickable` would consume the press
 * and a parent's long-press handler would never fire (this is what made
 * "long-press to pin" unreachable on the Live tab).
 */
/**
 * The glass ★ rating pill (H-A style): accent star + the title's
 * rating value on a dark glass capsule. Shared by [PosterCard] and
 * the Search grid's custom poster card so every poster surface
 * carries the identical chip (owner's #5, v0.14.8). Callers render
 * it only for a non-blank rating and position it top-left.
 */
@Composable
fun PosterRatingChip(rating: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .background(Color(0xFF040A12).copy(alpha = 0.72f), RoundedCornerShape(50))
            .padding(horizontal = 7.dp, vertical = 2.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "★",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.5.sp, fontWeight = FontWeight.Bold
            ),
            color = LocalPalette.current.accent
        )
        Spacer(Modifier.width(3.dp))
        Text(
            rating,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.5.sp, fontWeight = FontWeight.Bold
            ),
            color = Color.White
        )
    }
}

/**
 * Notes item 11 (owner-approved, v0.14.8-test): the title's official
 * studio logo artwork, centred on the poster tile — the artwork the
 * serving metadata addon provides in the meta `logo` field (any
 * addon, per the any-metadata-addon principle; PlavioMeta serves it
 * too). When no logo exists the tile stays a plain poster — never
 * fake text in a mismatched font. Loaded through the same Coil
 * cache as the poster itself, so it adds no blocking work; a failed
 * logo simply doesn't draw. Sized to stay clear of the ★ chip
 * (top-left), the WATCHED pill (bottom-left) and corner chips.
 */
@Composable
fun PosterLogoOverlay(
    logo: String?,
    modifier: Modifier = Modifier,
    widthFraction: Float = 0.76f,
    heightFraction: Float = 0.36f
) {
    val url = logo?.takeIf { it.isNotBlank() } ?: return
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxWidth(widthFraction)
                .fillMaxHeight(heightFraction),
            contentAlignment = Alignment.Center
        ) {
            // Soft dark bloom behind the artwork so light logos
            // stay legible on bright posters.
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.32f),
                                Color.Transparent
                            )
                        )
                    )
            )
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(4.dp)
            )
        }
    }
}

/**
 * The studio logo to draw for a tile (notes items 14/15): the
 * artwork the caller already has ([known], e.g. from a full meta
 * or a DB row) wins; otherwise the process-wide LogoResolver
 * cache — filled in the BACKGROUND from the serving addon's meta
 * endpoint, because catalog items carry no logo at all. Asking
 * for a logo never blocks composition; the tile repaints when
 * the artwork lands, and a title with no logo anywhere just
 * keeps its plain poster.
 */
@Composable
fun rememberResolvedLogo(
    addonId: String?,
    type: String,
    metaId: String,
    known: String?
): String? {
    // v0.14.17 lag fix (audit cause 3): observe ONLY this card's key.
    // The whole-map collectAsState used to recompose every visible
    // card on every single logo landing anywhere in the rail.
    val logoKey = "$type|$metaId"
    val resolvedLogo by remember(logoKey) {
        com.pulsestream.app.data.LogoResolver.logos
            .map { it[logoKey] }
            .distinctUntilChanged()
    }.collectAsState(initial = com.pulsestream.app.data.LogoResolver.cached(type, metaId))
    LaunchedEffect(type, metaId, known) {
        if (!known.isNullOrBlank()) {
            com.pulsestream.app.data.LogoResolver.prime(type, metaId, known)
        } else {
            com.pulsestream.app.data.LogoResolver.request(addonId, type, metaId)
        }
    }
    return known?.takeIf { it.isNotBlank() } ?: resolvedLogo
}

/**
 * The title's poster for a Continue Watching tile in Poster artwork
 * mode (item 35): episode rows save a scene still as their art, so
 * the poster comes from the serving meta via [CwPosterResolver],
 * resolved in the background exactly like logos. Null until (and
 * unless) a poster lands — callers fall back to the saved art.
 */
@Composable
fun rememberResolvedCwPoster(
    type: String,
    metaId: String,
    enabled: Boolean = true
): String? {
    // Per-key observation only (v0.14.17 lag fix, audit cause 3) —
    // see rememberResolvedLogo.
    val posterKey = "$type|$metaId"
    val resolvedPoster by remember(posterKey) {
        com.pulsestream.app.data.CwPosterResolver.posters
            .map { it[posterKey] }
            .distinctUntilChanged()
    }.collectAsState(initial = com.pulsestream.app.data.CwPosterResolver.cached(type, metaId))
    LaunchedEffect(type, metaId, enabled) {
        if (enabled) {
            com.pulsestream.app.data.CwPosterResolver.request(null, type, metaId)
        }
    }
    return resolvedPoster
}

/**
 * Sample C "bare glyphs" (item 31, owner's pick 2026-10-28): the
 * little coloured mark each MDBList source is drawn with on Home
 * cards — a brand-coloured glyph, never the source's name in text.
 * Unknown keys fall back to the first letter of their label in
 * neutral grey, so a source MDBList adds later still renders.
 */
private fun mdbGlyphFor(
    source: com.pulsestream.app.data.MdbListApi.SourceRating
): Pair<String, Color> = when (source.key) {
    "imdb" -> "★" to Color(0xFFF5C518)
    "rt_critics" -> "🍅" to Color.White
    "rt_audience" -> "🍿" to Color.White
    "metacritic" -> "M" to Color(0xFF66CC33)
    "tmdb" -> "T" to Color(0xFF01B4E4)
    "trakt" -> "✔" to Color(0xFFED1C24)
    "letterboxd" -> "L" to Color(0xFF00E054)
    "myanimelist" -> "A" to Color(0xFF7C9BE0)
    else -> (source.label.firstOrNull()?.uppercase() ?: "•") to Color(0xFFB8B8B8)
}

/**
 * Pre-blurred poster bitmaps for the MDBList strip backing
 * (v0.14.17 lag fix, audit cause 3).
 *
 * The strip's backing used to be a second copy of the poster drawn
 * through a live BlurEffect RenderEffect inside an offscreen
 * compositing layer — a GPU blur pass per card, re-executed on
 * every recomposition (and PosterCards recomposed constantly: see
 * the per-key flow fixes). Now the blur is computed ONCE per
 * poster — a tiny decode, downscaled hard (the downscale itself is
 * most of the blur) with one filtered upscale — and cached
 * process-wide; the strip draws the cached bitmap under the same
 * wash + fade mask, so the owner's "Fade edge" look is unchanged.
 */
private object PreBlurredPosters {
    private val cache = android.util.LruCache<String, android.graphics.Bitmap>(24)
    private val inFlight =
        java.util.concurrent.ConcurrentHashMap<String, Deferred<android.graphics.Bitmap?>>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun cached(url: String?): android.graphics.Bitmap? =
        url?.takeIf { it.isNotBlank() }?.let { cache.get(it) }

    suspend fun load(
        context: android.content.Context,
        url: String
    ): android.graphics.Bitmap? {
        cache.get(url)?.let { return it }
        val deferred = inFlight.computeIfAbsent(url) {
            scope.async {
                try {
                    val bmp = runCatching { fetchAndBlur(context, url) }.getOrNull()
                    if (bmp != null) cache.put(url, bmp)
                    bmp
                } finally {
                    inFlight.remove(url)
                }
            }
        }
        return deferred.await()
    }

    private suspend fun fetchAndBlur(
        context: android.content.Context,
        url: String
    ): android.graphics.Bitmap? {
        val request = coil.request.ImageRequest.Builder(context)
            .data(url)
            .size(72, 108)
            .allowHardware(false)
            .build()
        val result = context.imageLoader.execute(request)
        val drawable = (result as? coil.request.SuccessResult)?.drawable ?: return null
        val src = drawable.toBitmap(72, 108)
        // Tent blur: crush to a handful of pixels and scale back up
        // with filtering — at strip size, under a 70% wash, this is
        // indistinguishable from a gaussian pass.
        val tiny = android.graphics.Bitmap.createScaledBitmap(src, 12, 18, true)
        val blurred = android.graphics.Bitmap.createScaledBitmap(tiny, 72, 108, true)
        if (tiny !== src) tiny.recycle()
        return blurred
    }
}

/** The pre-blurred copy of [url]'s poster, or null until it lands. */
@Composable
private fun rememberPreBlurredPoster(url: String?): android.graphics.Bitmap? {
    val context = LocalContext.current
    var bitmap by remember(url) { mutableStateOf(PreBlurredPosters.cached(url)) }
    LaunchedEffect(url) {
        val u = url?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        if (bitmap == null) bitmap = PreBlurredPosters.load(context, u)
    }
    return bitmap
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PosterCard(
    meta: MetaPreview,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    showRatingChip: Boolean = true,
    showMdbRatings: Boolean = false,
    modifier: Modifier = Modifier
) {
    // Shared-art poster→detail flight REMOVED (v0.14.16,
    // PLAVIO-12/13): a tap used to arm this card instance for a
    // shared-element flight into the detail hero; the flight's
    // lookahead machinery kept crashing, so a tap is just a tap
    // now and the poster simply appears in place on Detail.
    val gestureModifier = if (onLongClick != null) {
        Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
    } else {
        Modifier.clickable(onClick = onClick)
    }
    // MDBList strip (item 29, owner's order 2026-10-28): Home rails
    // opt in via [showMdbRatings]. Asking never blocks paint — the
    // resolver fetches in the background (and no-ops without a key),
    // and the strip below simply appears when ratings land.
    LaunchedEffect(showMdbRatings, meta.id) {
        if (showMdbRatings && meta.id.startsWith("tt")) {
            com.pulsestream.app.data.MdbRatingsResolver.request(meta.id)
        }
    }
    // Poster size (v0.14.39, appearance item B): the card's fixed
    // 128x180 frame scales by LocalPosterScale (0.85 / 1 / 1.18);
    // corner radius rides LocalPosterCorner (item E).
    val posterScale = LocalPosterScale.current
    val posterCorner = LocalPosterCorner.current
    Column(
        modifier = modifier
            .width(128.dp * posterScale)
            .then(gestureModifier)
            .focusable()
            .tvFocusRing(RoundedCornerShape(posterCorner))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp * posterScale)
                .liquidGlass(RoundedCornerShape(posterCorner))
        ) {
            SafePosterImage(
                model = tmdbSizedImage(meta.poster, "w342"),
                contentDescription = meta.name,
                modifier = Modifier.fillMaxSize()
            )
            // NO studio logo on portrait posters (owner decision,
            // item 19): official poster art already carries the title
            // treatment baked in, so an overlay printed the name
            // twice. Logos live ONLY on the Home/Detail heroes and
            // Continue Watching cards (landscape art, no baked title).
            // MDBList strip sources (item 29): the enabled sources
            // in API order, capped at 4 so the row fits a 128dp
            // card. Empty = draw nothing — no key, no ratings yet,
            // or every source switched off leaves the card exactly
            // as it was.
            // v0.14.17 lag fix (audit cause 3): observe only THIS
            // card's ratings entry (the whole-map collect recomposed
            // every card on every landing), and read the disabled
            // sources ONCE from the app's shared SettingsStore — the
            // card used to construct its own SettingsStore and
            // re-read preferences on every recomposition.
            val mdbRatingsForMeta by remember(meta.id) {
                com.pulsestream.app.data.MdbRatingsResolver.ratings
                    .map { it[meta.id] }
                    .distinctUntilChanged()
            }.collectAsState(
                initial = com.pulsestream.app.data.MdbRatingsResolver.cached(meta.id)
            )
            val mdbDisabledSources = remember(showMdbRatings) {
                if (showMdbRatings) {
                    com.pulsestream.app.data.MdbRatingsResolver.settings
                        ?.mdblistDisabledSources ?: emptySet()
                } else emptySet()
            }
            val mdbStripSources = if (showMdbRatings && meta.id.startsWith("tt")) {
                mdbRatingsForMeta?.sources
                    ?.filter { it.key !in mdbDisabledSources }
                    ?.take(4)
                    .orEmpty()
            } else emptyList()
            // Pre-blurred backing for the strip below (v0.14.17):
            // resolved once per poster, process-wide cache.
            val mdbBlurredPoster = rememberPreBlurredPoster(
                if (mdbStripSources.isNotEmpty()) tmdbSizedImage(meta.poster, "w342") else null
            )
            // WATCHED pill for watched movies (owner's Sample B pick,
            // 2026-10-24). Series posters stay clean \u2014 episodes carry
            // their own pills on the detail page. When the MDBList
            // strip is drawn, the pill rises above it (item 29).
            // Per-key observation only (v0.14.17 lag fix, audit
            // cause 3): the whole-set collect recomposed every card
            // whenever any title's watched mark changed.
            val watchedMovieKey = com.pulsestream.app.data.WatchedMarks.movieKey(meta.id)
            val isWatchedMovie by remember(watchedMovieKey) {
                com.pulsestream.app.data.WatchedMarks.keys
                    .map { watchedMovieKey in it }
                    .distinctUntilChanged()
            }.collectAsState(
                initial = watchedMovieKey in com.pulsestream.app.data.WatchedMarks.keys.value
            )
            if (meta.type == "movie" && isWatchedMovie) {
                WatchedPill(
                    Modifier.align(Alignment.BottomStart).padding(
                        start = 6.dp, top = 6.dp, end = 6.dp,
                        bottom = if (mdbStripSources.isNotEmpty()) 26.dp else 6.dp
                    )
                )
            }
            // H-A rating chip (owner's pick 2026-10-24; extended to
            // EVERY poster surface v0.14.8, owner's #5): a small glass
            // pill on the poster's top-left — accent star, white
            // value. On by default via [showRatingChip]; shown only
            // when the title carries a rating (never a fake 0.0).
            if (showRatingChip) {
                meta.imdbRating?.takeIf { it.isNotBlank() }?.let { rating ->
                    PosterRatingChip(
                        rating,
                        Modifier.align(Alignment.TopStart).padding(6.dp)
                    )
                }
            }
            // MDBList ratings row (item 29; glyphs = the owner's
            // Sample C pick, item 31; backing v1 = his Sample D
            // frost pick, item 33; backing v2 = his Sample D
            // "Fade edge" pick from the thin set, v0.14.11): the
            // BARE coloured glyph + white number row sits in a
            // SOLID frosted band ≈10% of the poster height (18 dp
            // of 180 dp) at the very bottom edge — a blurred copy
            // of the poster art under a ~70% black wash — and above
            // the band the whole frosted backing FADES OUT upward
            // (a DstIn gradient over blur + wash, 30 dp ramp), so
            // the strip melts into the art instead of ending in a
            // hard line; the v1 top hairline is gone. The blur is
            // a copy of the same poster, laid out at the poster
            // box's own size and bottom-anchored inside the strip,
            // so it registers with the art it covers — since
            // v0.14.17 it is a bitmap pre-blurred once per poster
            // and cached (PreBlurredPosters), not a live
            // RenderEffect pass; until it lands, the plain dark
            // wash alone is the backing, under the same fade mask.
            // Drawn only when ratings have actually
            // landed — no ratings, no strip.
            if (mdbStripSources.isNotEmpty()) {
                val mdbShadow = Shadow(
                    Color.Black.copy(alpha = 0.9f), Offset(0f, 1f), 3f
                )
                val mdbValueStyle = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    shadow = mdbShadow
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart = 0.dp, topEnd = 0.dp,
                                bottomStart = 16.dp, bottomEnd = 16.dp
                            )
                        )
                ) {
                    // Backing composite (blurred art + wash) under a
                    // DstIn gradient mask: alpha 0 at the top of the
                    // 48 dp strip zone, full by the top of the solid
                    // 18 dp band (fraction 30/48), full to the bottom
                    // edge. Offscreen compositing keeps the mask
                    // scoped to this backing alone; the glyph row is
                    // a sibling and stays unmasked.
                    Box(
                        Modifier
                            .matchParentSize()
                            .graphicsLayer {
                                compositingStrategy = CompositingStrategy.Offscreen
                            }
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        colorStops = arrayOf(
                                            0f to Color.Transparent,
                                            0.625f to Color.Black,
                                            1f to Color.Black
                                        )
                                    ),
                                    blendMode = BlendMode.DstIn
                                )
                            }
                    ) {
                        // Blurred poster copy — v0.14.17: a bitmap
                        // blurred ONCE per poster and cached
                        // process-wide (PreBlurredPosters), drawn
                        // with the same layout the old live
                        // BlurEffect copy used: matchParentSize
                        // keeps it out of the strip's height,
                        // requiredHeight gives it the poster box's
                        // full 180 dp so its crop matches the poster
                        // image underneath exactly, and the strip's
                        // clip cuts everything above the strip. On
                        // the first frames (bitmap not yet blurred)
                        // the wash below alone is the backing.
                        if (mdbBlurredPoster != null) {
                            Box(Modifier.matchParentSize()) {
                                androidx.compose.foundation.Image(
                                    bitmap = mdbBlurredPoster.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .fillMaxWidth()
                                        .requiredHeight(180.dp)
                                )
                            }
                        }
                        // The ~70% black wash.
                        Box(
                            Modifier
                                .matchParentSize()
                                .background(Color.Black.copy(alpha = 0.70f))
                        )
                    }
                    // The glyph row lives in the solid band: the
                    // bottom 18 dp (≈10% of the 180 dp poster).
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .height(18.dp)
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {

                        mdbStripSources.forEachIndexed { index, source ->
                            if (index > 0) {
                                Text(
                                    text = "·",
                                    style = mdbValueStyle,
                                    color = Color.White.copy(alpha = 0.45f)
                                )
                            }
                            val (glyph, glyphColor) = mdbGlyphFor(source)
                            Text(
                                text = glyph,
                                style = mdbValueStyle.copy(fontWeight = FontWeight.Bold),
                                color = glyphColor
                            )
                            Text(
                                text = source.text,
                                style = mdbValueStyle,
                                color = Color.White
                            )
                        }
                    }
                }
            }
            // Poster only — no corner tag on channel cards.
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = meta.name,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = MaterialTheme.typography.bodySmall.lineHeight
        )
        // Title only under posters (owner, 2026-11-04): the year
        // sub-line is gone on every PosterCard surface — the year
        // still lives on the detail page.
    }
}

@Composable
fun SectionTitle(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    onMoreClick: (() -> Unit)? = null
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
        }
        if (onMoreClick != null) {
            IconButton(onClick = onMoreClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = "View all $title",
                    tint = TextSecondary
                )
            }
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    // Button standard (v0.14.24, item 3): one clean solid pill —
    // the Weave gradient, flat (no gloss sheen, no rim light),
    // a full 52 dp touch height, dimmed when disabled. The same
    // shape language as every other button in the app.
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.sizeIn(minHeight = 52.dp),
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = androidx.compose.foundation.layout.PaddingValues()
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(LocalPalette.current.gradient, RoundedCornerShape(50))
                .padding(horizontal = 28.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0A0A12)
            )
        }
    }
}

@Composable
fun LoadingState(message: String = "Loading…") {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        DotsLoadingIndicator(message)
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                "Something went wrong",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            GradientButton("Retry", onRetry)
        }
    }
}

@Composable
fun EmptyState(title: String, message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(LocalPalette.current.gradient),
                contentAlignment = Alignment.Center
            ) {
                Text("▶", color = Color(0xFF0A0A12), style = MaterialTheme.typography.headlineMedium)
            }
            Spacer(Modifier.height(20.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center)
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(20.dp))
                GradientButton(actionLabel, onAction)
            }
        }
    }
}

/**
 * TMDB serves the same artwork at fixed widths — rails ask for the width
 * they actually draw instead of decoding a w780/original upload into a
 * 128dp card. Non-TMDB URLs (and malformed ones) pass through untouched.
 */
internal fun tmdbSizedImage(url: String?, segment: String): String? {
    if (url == null) return null
    val marker = "image.tmdb.org/t/p/"
    val start = url.indexOf(marker)
    if (start < 0) return url
    val rest = url.substring(start + marker.length)
    val slash = rest.indexOf('/')
    if (slash < 0) return url
    return url.substring(0, start + marker.length) + segment + rest.substring(slash)
}

/**
 * Crash-safe image: guards null/blank URLs (Coil would attempt-and-fail on
 * blank strings from sloppy addon data) and swaps in a glyph placeholder on
 * load error instead of leaving a broken frame.
 */
@Composable
fun SafePosterImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val url = (model as? String)?.takeIf { it.isNotBlank() }
    var loadFailed by remember(model) { mutableStateOf(false) }
    Box(
        modifier = modifier.background(Color.White.copy(alpha = 0.05f)),
        contentAlignment = Alignment.Center
    ) {
        if (!loadFailed && url != null) {
            AsyncImage(
                model = url,
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale,
                onError = { loadFailed = true }
            )
        } else {
            Text(
                "▶",
                color = TextSecondary.copy(alpha = 0.45f),
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}


/**
 * Sample C (owner's pick 2026-10-24): the You May Like loading tile — a
 * soft light sweep over a dark tile with two faint title bars, no
 * spinner. Shown while TMDB recommendations load.
 */
@Composable
fun ShimmerPoster(modifier: Modifier = Modifier) {
    var widthPx by remember { mutableStateOf(0f) }
    val transition = rememberInfiniteTransition(label = "shimmer")
    val sweep by transition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerSweep"
    )
    Box(
        modifier = modifier
            .onSizeChanged { widthPx = it.width.toFloat() }
            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .offset { IntOffset((sweep * widthPx).roundToInt(), 0) }
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.10f),
                            Color.Transparent
                        )
                    )
                )
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                Modifier
                    .width(52.dp)
                    .height(9.dp)
                    .background(Color.White.copy(alpha = 0.13f), RoundedCornerShape(99.dp))
            )
            Box(
                Modifier
                    .width(36.dp)
                    .height(9.dp)
                    .background(Color.White.copy(alpha = 0.13f), RoundedCornerShape(99.dp))
            )
        }
    }
}

/**
 * Connecting-dots loading animation in the app's accent gradient: a wave of
 * light travels through dots linked by glowing segments. Used everywhere
 * loading happens: app launch, pull-to-refresh, search, and the player.
 */
@Composable
fun DotsLoader(
    modifier: Modifier = Modifier,
    dotCount: Int = 7
) {
    val palette = LocalPalette.current
    val reduced = com.pulsestream.app.data.rememberReducedMotion()
    val wave = if (reduced) 0.25f else {
        val transition = rememberInfiniteTransition(label = "dots")
        val animated by transition.animateFloat(initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(animation = tween(1500, easing = LinearEasing), repeatMode = RepeatMode.Restart),
            label = "dotsWave")
        animated
    }
    Canvas(
        modifier
            .width((dotCount * 20).dp)
            .height(26.dp)
    ) {
        // Wave (owner's pick 2026-10-25, Sample B): a pulse of light starts
        // at the CENTER dot and travels out to both edges and back. The old
        // left-to-right wave read as a tight blob — and the Home call site
        // squashed this 5-dot canvas into a 34.dp box, packing the dots.
        // Dots are now spaced across the full canvas width and sized from
        // the spacing, so they can never crowd each other.
        val n = dotCount.coerceAtLeast(1)
        val center = (n - 1) / 2f
        val maxD = center.coerceAtLeast(0.5f)
        val tri = if (wave < 0.5f) wave * 2f else 2f - wave * 2f
        val r = tri * (maxD + 0.6f)
        val spacing = size.width / n
        val cy = size.height / 2f
        val baseR = minOf(spacing * 0.30f, size.height * 0.30f)
        for (i in 0 until n) {
            val d = kotlin.math.abs(i - center)
            val g0 = (1f - kotlin.math.abs(r - d) / 1.1f).coerceIn(0f, 1f)
            val g = g0 * g0
            drawCircle(
                color = (if (palette.appTheme == AppTheme.ONYX) palette.accent
                    else lerp(palette.accent, palette.accent2, d / maxD))
                    .copy(alpha = 0.30f + 0.70f * g),
                radius = baseR * (0.55f + 0.75f * g),
                center = Offset(spacing * (i + 0.5f), cy)
            )
        }
    }
}

@Composable
fun DotsLoadingIndicator(message: String = "Loading…") {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        OrbitDots(modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(14.dp))
        Text(
            message,
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

/** A rating line whose \u2605 wears [starColor] \u2014 the accent colour
 *  drives the small things everywhere (owner's order 2026-10-25). */
fun accentStarText(text: String, starColor: Color): AnnotatedString = buildAnnotatedString {
    text.split("\u2605").forEachIndexed { index, part ->
        if (index > 0) {
            withStyle(SpanStyle(color = starColor, fontWeight = FontWeight.Bold)) { append("\u2605") }
        }
        append(part)
    }
}

/** Small glass "\u2713 WATCHED" pill (owner's Sample B pick, 2026-10-24). */
@Composable
fun WatchedPill(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Color(0xC7050A12), RoundedCornerShape(50))
            .border(1.dp, Color(0xFF3DDC97).copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Check,
            contentDescription = null,
            tint = Color(0xFF3DDC97),
            modifier = Modifier.size(10.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            "WATCHED",
            color = Color(0xFF3DDC97),
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.8.sp
        )
    }
}

/**
 * The signature dots, circling (owner's B1 Orbit pick, 2026-10-24): a
 * glowing head dot orbits an exact ring with four fading tail dots
 * behind it, over a faint dotted ring \u2014 the refresh DotsLoader's
 * family, in circle form. Geometry is computed on one true circle
 * (design space 40 units, ring radius 13.5) so nothing wobbles.
 */
@Composable
fun OrbitDots(modifier: Modifier = Modifier) {
    val palette = LocalPalette.current
    val reduced = com.pulsestream.app.data.rememberReducedMotion()
    val rotation = if (reduced) 0f else {
        val transition = rememberInfiniteTransition(label = "orbit")
        val animated by transition.animateFloat(
            initialValue = 0f, targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(1350, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "orbitRotation"
        )
        animated
    }
    Canvas(modifier) {
        val unit = size.minDimension / 40f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val ringR = 13.5f * unit
        fun pos(angleDeg: Float): Offset {
            val rad = Math.toRadians(angleDeg.toDouble())
            return Offset(
                cx + ringR * Math.cos(rad).toFloat(),
                cy + ringR * Math.sin(rad).toFloat()
            )
        }
        // Faint dotted ring underneath (12 dots, every 30 degrees).
        for (i in 0 until 12) {
            drawCircle(
                color = (if (palette.appTheme == AppTheme.ONYX) palette.accent
                    else lerp(palette.accent, palette.accent2, i / 11f)).copy(alpha = 0.22f),
                radius = 1.4f * unit,
                center = pos(i * 30f)
            )
        }
        // Tail behind the head: evenly spaced on the same circle,
        // shrinking and fading (B1's exact sample values).
        val tailR = listOf(2.5f, 2.05f, 1.65f, 1.3f)
        val tailA = listOf(0.75f, 0.55f, 0.38f, 0.24f)
        for (i in 4 downTo 1) {
            drawCircle(
                color = (if (palette.appTheme == AppTheme.ONYX) palette.accent
                    else lerp(palette.accent, palette.accent2, i / 4f)).copy(alpha = tailA[i - 1]),
                radius = tailR[i - 1] * unit,
                center = pos(rotation - 35f * i)
            )
        }
        // Head with its soft glow.
        val head = pos(rotation)
        drawCircle(color = palette.accent.copy(alpha = 0.28f), radius = 6f * unit, center = head)
        drawCircle(color = palette.accent, radius = 3.1f * unit, center = head)
    }
}

/** Big gradient Play button with an icon, used on the detail screen. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlayButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    text: String = "Play",
    isLoading: Boolean = false,
    loadingMore: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    resumeProgress: Float? = null
) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    Box(
        modifier = modifier
            .height(52.dp)
            .tvFocusRing(RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .then(
                if (enabled && !isLoading) {
                    Modifier.combinedClickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick,
                        onLongClick = onLongClick
                    )
                } else Modifier
            )
            .alpha(if (enabled) 1f else 0.5f),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                // Button standard (v0.14.24, item 3): the hero Play
                // wears the flat Weave gradient like every primary
                // button — no glass, no gloss — with dark ink on top.
                .background(LocalPalette.current.gradient, RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                OrbitDots(modifier = Modifier.size(28.dp))
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    androidx.compose.foundation.layout.Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = Color(0xFF0A0A12),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = text,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF0A0A12)
                        )
                    }
                    // Resume progress bar (dark ink on the gradient)
                    if (resumeProgress != null && resumeProgress > 0) {
                        Spacer(Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .background(
                                    Color(0xFF0A0A12).copy(alpha = 0.25f),
                                    RoundedCornerShape(2.dp)
                                )
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(resumeProgress.coerceIn(0f, 1f))
                                    .background(Color(0xFF0A0A12), RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }
            }
        }
        if (loadingMore && !isLoading) {
            // Streams are still arriving: the button is already playable,
            // and our signature dots circle at its side while more come
            // (owner's B1 Orbit pick, 2026-10-24 \u2014 replaces the plain
            // little circle, same place at the button's right side).
            OrbitDots(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
                    .size(26.dp)
            )
        }
    }
}

/**
 * Secondary button. For primary actions use [PlayButton].
 * Button standard (v0.14.24, item 3): a flat solid pill — the
 * panel colour with a hairline border, 52 dp touch height, no
 * glass gloss — so secondary actions read as one family with
 * the gradient primaries.
 */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = modifier
            .sizeIn(minHeight = 52.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .tvFocusRing(shape)
            .clip(shape)
            .background(LocalPalette.current.panel, shape)
            .border(1.dp, LocalPalette.current.glassBorder, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}
