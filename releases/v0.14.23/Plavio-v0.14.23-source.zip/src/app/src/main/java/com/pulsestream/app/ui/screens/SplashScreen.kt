package com.pulsestream.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.pulsestream.app.R
import com.pulsestream.app.ui.components.OrbitDots
import kotlinx.coroutines.delay

/**
 * Launch splash — the owner's locked HUG startup (settled 2026-10-29).
 *
 * The splash PLAYS THE LOCKED HUG CLIP, bundled at
 * res/raw/splash_g_orbit_build.mp4. The legacy filename is kept; the
 * CONTENT is the HUG master: md5 1338ae0acb84dbf24681c78aa4eb3389,
 * byte-identical to the locked master file
 * (your_files/startup-from-scratch/plavio-startup-hug-120.mp4),
 * re-verified for v0.14.22. In the clip the whole Weave mark stays
 * connected in every frame and settles at 120x120, the signature
 * wordmark + "Your streaming universe" follow, on a flat (3,3,3)
 * background. The wait-state poster
 * (res/drawable-nodpi/splash_g_last_frame.png) is that clip's own
 * settled frame. The loader under the tagline is the app's own
 * [OrbitDots] composable, shown for the whole splash.
 *
 * Earlier revisions of this header narrated superseded samples
 * (Sample G "Orbit Build", Sample A "Rise") — those are NOT what
 * ships. This header was corrected in v0.14.22 (audit items P18/D1)
 * to match the shipped binary.
 *
 * Exit rule: the splash leaves only when ALL THREE hold — the clip
 * has ENDED, 3 seconds have elapsed since splash start, and the
 * home feed is ready; the caller keeps an 8s safety cap so a dead
 * network can't trap the splash. If video playback fails on a
 * device, the clip's last frame
 * (res/drawable-nodpi/splash_g_last_frame.png) is shown for the
 * remaining wait. A local 4.5s cap flips clipDone even if the
 * player wedges without ending or erroring.
 */
@Composable
fun SplashScreen(feedReady: Boolean, onDone: () -> Unit) {
    val context = LocalContext.current
    var clipDone by remember { mutableStateOf(false) }
    var videoFailed by remember { mutableStateOf(false) }

    val player = remember {
        ExoPlayer.Builder(context.applicationContext).build().apply {
            setMediaItem(
                MediaItem.fromUri(
                    RawResourceDataSource.buildRawResourceUri(R.raw.splash_g_orbit_build)
                )
            )
            volume = 0f
            repeatMode = Player.REPEAT_MODE_OFF
            playWhenReady = true
            prepare()
        }
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) clipDone = true
            }

            override fun onPlayerError(error: PlaybackException) {
                videoFailed = true
                clipDone = true
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    // Local safety net: the clip is 2.33s — if the player neither ends
    // nor errors (wedged codec), don't let the splash hang past this.
    LaunchedEffect(Unit) {
        delay(4500)
        clipDone = true
    }
    // The 3-second minimum: the owner's "3 sec circle before reaching
    // home" — the splash never leaves before 3s from its start, even
    // when clip and feed are both ready sooner.
    var minTimeDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(3000)
        minTimeDone = true
    }
    LaunchedEffect(clipDone, minTimeDone, feedReady) {
        if (clipDone && minTimeDone && feedReady) onDone()
    }

    val showPoster = videoFailed || (clipDone && !feedReady)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF04060C))
    ) {
        if (showPoster) {
            Image(
                painter = painterResource(R.drawable.splash_g_last_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        setShutterBackgroundColor(0xFF04060C.toInt())
                        this.player = player
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        // The app's own orbit loader (owner's pick — the same circle
        // used for refresh and loading everywhere in the app), seated
        // under the tagline where the v0.14.9 ring sat. Visible for
        // the whole splash — while the clip plays and while the
        // poster holds waiting for the feed.
        OrbitDots(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp)
                .size(40.dp)
        )
    }
}
