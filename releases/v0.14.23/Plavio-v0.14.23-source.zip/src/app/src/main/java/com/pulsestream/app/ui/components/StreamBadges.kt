package com.pulsestream.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import com.pulsestream.app.ui.theme.TextPrimary

/**
 * The stream-card badge styles (v0.14.21, owner's final lineup of
 * six): GROUPED is Plavio's own tinted-glass capsules; ELITE, NARD,
 * GOLD and MINIMALIST render the genuine artwork of the community
 * badge packs the owner picked from the Badger registry, bundled
 * under `assets/badges/<pack>/` (see each pack's credits.json there);
 * ONYX is the house style — drawn in-app in the Onyx look, with a
 * chip for every canonical key. NARD is the default. A fact a pack
 * has no artwork for doesn't render in that style — the authentic
 * pack behaviour — EXCEPT the house-fill keys no pack carries (the
 * Indian languages, 1440p, the 4K UHD tag): those always render as
 * house chips so the fact is never lost. The size shows once as a
 * text chip dressed to match the style. IMPORTED is a user-imported
 * pack (Settings → Streams → Import pack): its artwork comes from
 * internal storage, and any key it lacks falls back to the house
 * chip. It is not one of the six picker staples — it only appears
 * once a pack has actually been imported.
 */
enum class BadgeStyle(val displayName: String, val assetDir: String?) {
    GROUPED("Grouped", null),
    ELITE("Elite", "elite"),
    GOLD("Gold", "gold"),
    MINIMALIST("Minimalist", "minimalist"),
    NARD("Nard", "nard"),
    ONYX("Onyx", null),
    IMPORTED("Imported pack", null);

    companion object {
        fun fromName(name: String?): BadgeStyle =
            entries.firstOrNull { it.name == name } ?: NARD

        /** The six built-in styles, in picker order. */
        val builtIns: List<BadgeStyle> =
            listOf(GROUPED, ELITE, GOLD, MINIMALIST, NARD, ONYX)
    }
}

/**
 * Canonical badge keys for [facts], in card order (resolution, source,
 * codec, HDR, audio, languages), honouring the per-group toggles. The
 * asset prep decides per pack which keys actually have a file; a missing
 * file renders nothing.
 */
fun streamBadgeKeys(facts: StreamFacts, config: StreamCapsuleConfig): List<String> =
    buildList {
        if (config.shows(StreamFactGroup.RESOLUTION)) {
            when (facts.quality) {
                "2160p" -> add("res-2160p")
                "1440p" -> add("res-1440p")
                "1080p" -> add("res-1080p")
                "720p" -> add("res-720p")
                "480p" -> add("res-480p")
                "360p" -> add("res-360p")
            }
            // The "4K UHD" tag (v0.14.21): no bundled pack carries
            // artwork for it, so it rides as a house chip everywhere.
            if (facts.qualityTag != null) add("tag-4kuhd")
        }
        if (config.shows(StreamFactGroup.SOURCE_CODEC)) {
            when (facts.sourceType) {
                "BluRay", "BDRip", "BRRip" -> add("src-bluray")
                "WEB-DL" -> add("src-webdl")
                "WEBRip" -> add("src-webrip")
                "HDRip" -> add("src-hdrip")
                "DVDRip" -> add("src-dvdrip")
                "HDTV" -> add("src-hdtv")
                "CAM", "HDCAM", "HDTC", "HDTS", "TS" -> add("src-cam")
            }
            if (facts.remux) add("remux")
            when (facts.codec?.uppercase()) {
                "HEVC", "X265" -> add("codec-hevc")
                "AVC", "X264" -> add("codec-avc")
                "AV1" -> add("codec-av1")
            }
            if (facts.bitDepth != null) add("bit-10")
        }
        if (config.shows(StreamFactGroup.HDR)) {
            facts.hdrFormats.forEach { format ->
                when (format) {
                    "DV" -> add("hdr-dv")
                    "HDR10+" -> add("hdr-hdr10plus")
                    "HDR10" -> add("hdr-hdr10")
                    "HDR" -> add("hdr-hdr")
                }
            }
        }
        if (config.shows(StreamFactGroup.AUDIO)) {
            when (facts.audioCodec) {
                "TrueHD" -> add("audio-truehd")
                "DTS-HD" -> add("audio-dtshd")
                "DTS" -> add("audio-dts")
                "DDP" -> add("audio-ddp")
                "AC3", "DD" -> add("audio-dd")
                "AAC" -> add("audio-aac")
                "FLAC" -> add("audio-flac")
                "Opus" -> add("audio-opus")
            }
            if (facts.atmos) add("atmos")
            when (facts.channels) {
                "2.0" -> add("ch-20")
                "5.1" -> add("ch-51")
                "6.1" -> add("ch-61")
                "7.1" -> add("ch-71")
            }
        }
        if (config.shows(StreamFactGroup.LANGUAGES)) {
            facts.languageCodes.forEach { code -> add("lang-" + code.lowercase()) }
        }
    }

/**
 * Keys no bundled pack carries artwork for (v0.14.21): the Indian
 * languages, 1440p and the 4K UHD tag. In every pack style these
 * render as house chips instead of vanishing, so the fact survives
 * the dressing. (Tamil above all — no pack ships it at all.)
 */
val HOUSE_FILL_KEYS: Set<String> = setOf(
    "lang-te", "lang-ta", "lang-ml", "lang-kn",
    "lang-bn", "lang-pa", "lang-mr", "lang-ur",
    "res-1440p", "tag-4kuhd"
)

/** Short printed label for a canonical badge key — the Onyx chips' text. */
fun badgeKeyLabel(key: String): String = when (key) {
    "res-2160p" -> "2160p"
    "res-1440p" -> "1440p"
    "res-1080p" -> "1080p"
    "res-720p" -> "720p"
    "res-480p" -> "480p"
    "res-360p" -> "360p"
    "tag-4kuhd" -> "4K UHD"
    "src-bluray" -> "BluRay"
    "src-webdl" -> "WEB-DL"
    "src-webrip" -> "WEBRip"
    "src-hdrip" -> "HDRip"
    "src-dvdrip" -> "DVDRip"
    "src-hdtv" -> "HDTV"
    "src-cam" -> "CAM"
    "remux" -> "REMUX"
    "codec-hevc" -> "HEVC"
    "codec-avc" -> "AVC"
    "codec-av1" -> "AV1"
    "bit-10" -> "10bit"
    "hdr-dv" -> "DV"
    "hdr-hdr10plus" -> "HDR10+"
    "hdr-hdr10" -> "HDR10"
    "hdr-hdr" -> "HDR"
    "audio-truehd" -> "TrueHD"
    "audio-dtshd" -> "DTS-HD"
    "audio-dts" -> "DTS"
    "audio-ddp" -> "DDP"
    "audio-dd" -> "DD"
    "audio-aac" -> "AAC"
    "audio-flac" -> "FLAC"
    "audio-opus" -> "Opus"
    "atmos" -> "Atmos"
    "ch-20" -> "2.0"
    "ch-51" -> "5.1"
    "ch-61" -> "6.1"
    "ch-71" -> "7.1"
    else -> if (key.startsWith("lang-")) key.removePrefix("lang-").uppercase()
    else key.uppercase()
}

/**
 * The house badge (v0.14.21): a small dark-glass Onyx chip carrying
 * the key's label as text. It IS the Onyx style's rendering, and it
 * fills the gaps of the pack styles (house-fill keys) and of an
 * imported pack (any key the pack lacks). Text is sized so the
 * chip's height stays at the stream-text height (~16dp), never
 * bigger — the same ceiling the pack artwork renders at.
 */
@Composable
fun HouseBadgeChip(key: String) {
    OnyxTextChip(badgeKeyLabel(key))
}

@Composable
private fun OnyxTextChip(text: String) {
    Box(
        Modifier
            .background(Color(0xFF0D0D16).copy(alpha = 0.85f), RoundedCornerShape(6.dp))
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text,
            fontSize = 10.sp,
            lineHeight = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1
        )
    }
}

/** NardBadges group colours (from the pack's own group definitions). */
private fun nardChipColor(key: String): Color = when {
    key.startsWith("res-") || key.startsWith("ch-") -> Color(0xFF858283)
    key.startsWith("src-") || key == "remux" -> Color(0xFF1976D2)
    key.startsWith("hdr-") -> Color(0xFFFF9800)
    key.startsWith("codec-") || key == "bit-10" -> Color(0xFF4CAF50)
    key.startsWith("audio-") || key == "atmos" -> Color(0xFF00BCD4)
    key.startsWith("lang-") -> Color(0xFF4ECDC4)
    else -> Color(0xFF858283)
}

@Composable
private fun rememberBadgeBitmap(path: String): ImageBitmap? {
    val context = LocalContext.current
    return remember(path) {
        runCatching {
            context.assets.open(path).use { BitmapFactory.decodeStream(it) }
                ?.asImageBitmap()
        }.getOrNull()
    }
}

/**
 * One pack badge with the house fill (v0.14.21): the pack's own
 * artwork when the pack carries the key; for a house-fill key the
 * pack lacks, the house chip renders instead of nothing.
 */
@Composable
private fun PackBadge(style: BadgeStyle, dir: String, key: String) {
    val bitmap = rememberBadgeBitmap("badges/$dir/$key.png")
    if (bitmap != null) {
        if (style == BadgeStyle.NARD) {
            Box(
                Modifier
                    .background(nardChipColor(key), RoundedCornerShape(6.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Image(bitmap, contentDescription = null, modifier = Modifier.height(14.dp))
            }
        } else {
            Image(bitmap, contentDescription = null, modifier = Modifier.height(16.dp))
        }
    } else if (key in HOUSE_FILL_KEYS) {
        HouseBadgeChip(key)
    }
}

@Composable
private fun rememberFileBadgeBitmap(file: File): ImageBitmap? =
    remember(file.absolutePath, file.lastModified()) {
        runCatching {
            if (file.isFile) BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
            else null
        }.getOrNull()
    }

/**
 * One badge of the user-imported pack (v0.14.21): the imported
 * artwork when the pack carries the key, the built-in house chip
 * when it doesn't — an imported pack never loses a fact.
 */
@Composable
private fun ImportedBadge(key: String) {
    val context = LocalContext.current
    val file = remember(key) { File(badgeImportedDir(context), "$key.png") }
    val bitmap = rememberFileBadgeBitmap(file)
    if (bitmap != null) {
        Image(bitmap, contentDescription = null, modifier = Modifier.height(16.dp))
    } else {
        HouseBadgeChip(key)
    }
}

/** The size, as a text chip dressed to match the chosen pack. */
@Composable
private fun BadgeSizeChip(style: BadgeStyle, text: String) {
    // The house styles dress the size as a house chip too.
    if (style == BadgeStyle.ONYX || style == BadgeStyle.IMPORTED) {
        OnyxTextChip(text)
        return
    }
    when (style) {
        BadgeStyle.GOLD -> Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFFBE01),
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 3.dp)
        )
        BadgeStyle.MINIMALIST -> Box(
            Modifier
                .border(1.dp, Color.White.copy(alpha = 0.75f), RoundedCornerShape(10.dp))
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) {
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )
        }
        BadgeStyle.NARD -> Box(
            Modifier
                .background(Color(0xFF858283), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )
        }
        else -> Box(
            Modifier
                .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )
        }
    }
}

/**
 * The wrapping badge row under a cleaned stream filename, in the user's
 * chosen style (Settings → Streams → Badge style). GROUPED renders the
 * glass capsules; the pack styles render the packs' bundled artwork.
 * All styles read the same parsed facts and obey the same group toggles
 * (Settings → Streams → Badge details). [extra] renders right after
 * the fact items (the Smart Pick RECOMMENDED chip rides there —
 * v0.14.38); [trailing] renders LAST in the row (the download capsule
 * rides there — v0.14.14); with no facts and no extra content the row
 * doesn't render at all.
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun BadgeStrip(
    facts: StreamFacts,
    config: StreamCapsuleConfig = StreamCapsuleConfig(),
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    extra: (@Composable () -> Unit)? = null
) {
    if (!facts.hasFacts && trailing == null && extra == null) return
    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        if (config.style == BadgeStyle.GROUPED) {
            facts.groupedCapsules(config).forEach { (group, text) ->
                StreamFactCapsule(text, tint = group.capsuleTint())
            }
            extra?.invoke()
            trailing?.invoke()
            return@FlowRow
        }
        val keys = streamBadgeKeys(facts, config)
        val dir = config.style.assetDir
        when {
            config.style == BadgeStyle.ONYX -> {
                // The house style: every key renders, full coverage.
                keys.forEach { key -> HouseBadgeChip(key) }
            }
            config.style == BadgeStyle.IMPORTED -> {
                keys.forEach { key -> ImportedBadge(key) }
            }
            dir != null -> {
                keys.forEach { key -> PackBadge(config.style, dir, key) }
            }
        }
        if (config.style != BadgeStyle.GROUPED && config.shows(StreamFactGroup.SIZE)) {
            facts.size?.let { BadgeSizeChip(config.style, it) }
        }
        extra?.invoke()
        trailing?.invoke()
    }
}

/**
 * The stream card's download action (v0.14.14, owner's restyle): no
 * separate button column — a capsule that rides LAST in the badge row,
 * dressed by the SAME style as the facts beside it. One implementation,
 * parameterised by [style]: Grouped = the liquid-glass capsule; Elite =
 * a self-contained dark chip; Nard = a filled chip in the pack's blue;
 * Gold = bare gold wordmark style; Minimalist = white outline chip.
 */
@Composable
fun StreamDownloadCapsule(
    style: BadgeStyle,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    @Composable
    fun Content(tint: Color) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                Icons.Filled.Download,
                contentDescription = "Download",
                tint = tint,
                modifier = Modifier.size(12.dp)
            )
            Text(
                "Download",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = tint,
                maxLines = 1
            )
        }
    }
    val dim = if (enabled) 1f else 0.4f
    when (style) {
        BadgeStyle.GROUPED -> Box(
            Modifier
                .alpha(dim)
                .liquidGlass(RoundedCornerShape(50), frost = 0.12f)
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) { Content(TextPrimary) }
        BadgeStyle.ELITE -> Box(
            Modifier
                .alpha(dim)
                .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) { Content(Color.White) }
        BadgeStyle.NARD -> Box(
            Modifier
                .alpha(dim)
                .background(Color(0xFF1976D2), RoundedCornerShape(8.dp))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) { Content(Color.White) }
        BadgeStyle.GOLD -> Box(
            Modifier
                .alpha(dim)
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 2.dp, vertical = 3.dp)
        ) { Content(Color(0xFFFFBE01)) }
        BadgeStyle.MINIMALIST -> Box(
            Modifier
                .alpha(dim)
                .border(1.dp, Color.White.copy(alpha = 0.75f), RoundedCornerShape(10.dp))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) { Content(Color.White) }
        BadgeStyle.ONYX, BadgeStyle.IMPORTED -> Box(
            Modifier
                .alpha(dim)
                .background(Color(0xFF0D0D16).copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(8.dp))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) { Content(Color.White) }
    }
}
