package com.pulsestream.app.ui.screens

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * v0.14.47 (item 1): the season flow's "downloads started"
 * confirmation wording — it fires only once the queue has
 * actually been handed to the download engine, and a partial
 * season (some episodes had no downloadable stream) must say
 * so honestly instead of claiming the whole season.
 */
class SeasonDownloadMessageTest {

    @Test
    fun fullSeasonReadsAsStartedWithCount() {
        assertEquals(
            "Downloads started — 8 episodes",
            seasonDownloadsStartedMessage(queued = 8, total = 8)
        )
    }

    @Test
    fun singleEpisodeSeason() {
        assertEquals(
            "Downloads started — 1 episode",
            seasonDownloadsStartedMessage(queued = 1, total = 1)
        )
    }

    @Test
    fun partialSeasonNamesBothNumbers() {
        assertEquals(
            "Downloads started — 5 of 9 episodes",
            seasonDownloadsStartedMessage(queued = 5, total = 9)
        )
    }
}
