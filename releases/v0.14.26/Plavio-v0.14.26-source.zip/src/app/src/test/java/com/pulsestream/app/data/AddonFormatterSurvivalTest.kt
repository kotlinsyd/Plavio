package com.pulsestream.app.data

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.InstalledAddon
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * v0.14.46 — the formatter-loss fix at the repository level
 * (trace: addon-formatter-update-loss-trace-2026-11-14).
 *
 * The user's configured PlavioHD install (their /u/<code>/ link —
 * the formatter and source picks live inside it) is ONE Room row
 * with the factory seed's manifest id. Three behaviours pin the
 * loss shut:
 *  1. the cold-start seed never installs over an existing row,
 *  2. a bare-origin (re)install keeps the row's configured URL
 *     (AddonIdentity.preservedBaseUrl, unit-pinned in
 *     AddonIdentityTest; here end-to-end through addAddonFromUrl),
 *  3. the seed still installs normally when nothing is installed.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class AddonFormatterSurvivalTest {

    private fun manifest(id: String, name: String) = AddonManifest(
        id = id,
        name = name,
        version = "9.9.9",
        description = "",
        types = listOf("movie", "series"),
        catalogs = emptyList(),
        resources = listOf("catalog", "meta", "stream")
    )

    private fun api(): StremioApi {
        val api = mockk<StremioApi>()
        coEvery { api.fetchManifest(any()) } answers {
            if (firstArg<String>().contains("hd.plavio.site")) {
                manifest("community.plaviohd", "PlavioHD (manifest)")
            } else {
                manifest("community.plaviometa", "PlavioMeta (manifest)")
            }
        }
        return api
    }

    private fun addon(id: String, baseUrl: String, name: String = "PlavioHD") = InstalledAddon(
        id = id,
        name = name,
        version = "1.0",
        description = "",
        baseUrl = baseUrl,
        types = "movie,series",
        resources = "catalog,meta,stream",
        enabled = true,
        addedAt = 1L
    )

    private fun withRepository(
        block: suspend (AppDatabase, StreamRepository, SettingsStore) -> Unit
    ) = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("pulse_settings", Context.MODE_PRIVATE)
            .edit().clear().commit()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val settings = SettingsStore(context)
        val repository = StreamRepository(db, api(), settings)
        try {
            block(db, repository, settings)
        } finally {
            db.close()
        }
    }

    @Test
    fun `seed never installs over an existing configured row`() = withRepository { db, repo, settings ->
        // The user's hand-installed configured link, renamed by them.
        db.addonDao().upsert(
            addon(
                "community.plaviohd",
                "https://hd.plavio.site/u/USERCODE",
                name = "My PlavioHD"
            )
        )
        repo.ensurePreinstalledAddons()
        val row = db.addonDao().getAll().single { it.id == "community.plaviohd" }
        // Untouched: not the factory URL, not the manifest's name or
        // version — the seed did not run an install over this row.
        assertEquals("https://hd.plavio.site/u/USERCODE", row.baseUrl)
        assertEquals("My PlavioHD", row.name)
        assertEquals("1.0", row.version)
        // And the seed now considers this id done.
        assertTrue(settings.isPreinstallDone("community.plaviohd"))
    }

    @Test
    fun `seed still installs when nothing is installed`() = withRepository { db, repo, settings ->
        repo.ensurePreinstalledAddons()
        val row = db.addonDao().getAll().single { it.id == "community.plaviohd" }
        assertEquals("https://hd.plavio.site", row.baseUrl)
        assertTrue(row.preinstalled)
        assertTrue(settings.isPreinstallDone("community.plaviohd"))
    }

    @Test
    fun `bare reinstall keeps the configured url end to end`() = withRepository { db, repo, _ ->
        db.addonDao().upsert(addon("community.plaviohd", "https://hd.plavio.site/u/USERCODE"))
        repo.addAddonFromUrl("https://hd.plavio.site").getOrThrow()
        val row = db.addonDao().getAll().single { it.id == "community.plaviohd" }
        assertEquals("https://hd.plavio.site/u/USERCODE", row.baseUrl)
    }

    @Test
    fun `configured reinstall replaces a bare url end to end`() = withRepository { db, repo, _ ->
        db.addonDao().upsert(addon("community.plaviohd", "https://hd.plavio.site"))
        repo.addAddonFromUrl("https://hd.plavio.site/u/NEWCODE").getOrThrow()
        val row = db.addonDao().getAll().single { it.id == "community.plaviohd" }
        assertEquals("https://hd.plavio.site/u/NEWCODE", row.baseUrl)
    }

    @Test
    fun `configured reinstall replaces a configured url end to end`() = withRepository { db, repo, _ ->
        db.addonDao().upsert(addon("community.plaviohd", "https://hd.plavio.site/u/OLDCODE"))
        repo.addAddonFromUrl("https://hd.plavio.site/c/NEWTOKEN").getOrThrow()
        val row = db.addonDao().getAll().single { it.id == "community.plaviohd" }
        assertEquals("https://hd.plavio.site/c/NEWTOKEN", row.baseUrl)
    }
}
