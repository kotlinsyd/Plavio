package com.pulsestream.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The standard `app_extras` meta block (v0.14.45): rich meta addons
 * serve plain name strings in top-level `cast` and the rich cast
 * (photos, characters — no person ids) in `app_extras.cast`
 * (PlavioMeta's standard shape after its flip; Nuvio's catalog
 * addon). The parser must surface those photos in MetaDetail.cast,
 * keep the legacy object cast and names-only cast working, recover
 * person ids from the meta's actor links, and accept both
 * trailerStreams shapes. Fixtures mirror the live answers of both
 * addons (Oppenheimer / MobLand, Nov 2026).
 */
class StremioParserAppExtrasTest {

    @Test
    fun `string cast plus app_extras cast yields cast with photos and characters`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "cast":["Cillian Murphy","Emily Blunt"],
              "app_extras":{
                "cast":[
                  {"name":"Cillian Murphy","character":"J. Robert Oppenheimer","photo":"https://image.tmdb.org/t/p/w500/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg"},
                  {"name":"Emily Blunt","character":"Kitty Oppenheimer","photo":"https://image.tmdb.org/t/p/w500/5nCSG5TL1bP1geD8aaBfaLnLLCD.jpg"}
                ]
              }
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(2, meta!!.cast.size)
        assertEquals("Cillian Murphy", meta.cast[0].name)
        assertEquals("J. Robert Oppenheimer", meta.cast[0].character)
        assertEquals(
            "https://image.tmdb.org/t/p/w500/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg",
            meta.cast[0].photo
        )
        assertEquals("Emily Blunt", meta.cast[1].name)
        assertTrue(meta.cast.all { !it.photo.isNullOrBlank() })
    }

    @Test
    fun `app_extras cast inherits person ids from the meta actor links`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "cast":["Cillian Murphy","Emily Blunt"],
              "links":[
                {"name":"Drama","category":"genre","url":"stremio:///discover/movie?genre=Drama"},
                {"name":"Cillian Murphy","category":"actor","url":"https://www.themoviedb.org/person/2037","personId":2037},
                {"name":"Emily Blunt","category":"actor","url":"https://www.themoviedb.org/person/5081"}
              ],
              "app_extras":{
                "cast":[
                  {"name":"Cillian Murphy","character":"J. Robert Oppenheimer","photo":"https://image.tmdb.org/t/p/w500/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg"},
                  {"name":"Emily Blunt","character":"Kitty Oppenheimer","photo":"https://image.tmdb.org/t/p/w500/5nCSG5TL1bP1geD8aaBfaLnLLCD.jpg"}
                ]
              }
            }}""",
            "movie"
        )
        assertNotNull(meta)
        // Explicit personId wins; the /person/<id> URL form also resolves.
        assertEquals(2037, meta!!.cast[0].id)
        assertEquals(5081, meta.cast[1].id)
    }

    @Test
    fun `app_extras fills certification tmdb rating and season posters`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt31510819","type":"series","name":"MobLand",
              "cast":["Tom Hardy"],
              "app_extras":{
                "cast":[{"name":"Tom Hardy","character":"Harry Da Souza","photo":"https://image.tmdb.org/t/p/w500/d81K0RH8UX7tZj49tZaQhZ9ewH.jpg"}],
                "certification":"TV-MA",
                "ratings":{"tmdb":{"rating":"8.6","votes":1220},"imdb":{"rating":"8.3","votes":141852}},
                "seasonPosters":["https://image.tmdb.org/t/p/w500/abeH7n5pcuQcwYcTxG6DTZvXLP1.jpg","https://image.tmdb.org/t/p/w500/fTlH5NNTXOP96mElp0DaIStRVvK.jpg"]
              }
            }}""",
            "series"
        )
        assertNotNull(meta)
        assertEquals("TV-MA", meta!!.certification)
        assertEquals("8.6", meta.tmdbRating)
        assertEquals(
            mapOf(
                1 to "https://image.tmdb.org/t/p/w500/abeH7n5pcuQcwYcTxG6DTZvXLP1.jpg",
                2 to "https://image.tmdb.org/t/p/w500/fTlH5NNTXOP96mElp0DaIStRVvK.jpg"
            ),
            meta.seasonPosters
        )
    }

    @Test
    fun `top level certification beats app_extras certification`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "certification":"R",
              "app_extras":{"certification":"18"}
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals("R", meta!!.certification)
    }

    @Test
    fun `legacy object cast still parses with ids photos and characters`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "cast":[
                {"id":2037,"name":"Cillian Murphy","photo":"https://image.tmdb.org/t/p/w185/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg","character":"J. Robert Oppenheimer"},
                {"id":5081,"name":"Emily Blunt","photo":"https://image.tmdb.org/t/p/w185/5nCSG5TL1bP1geD8aaBfaLnLLCD.jpg","character":"Kitty Oppenheimer"}
              ]
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(2, meta!!.cast.size)
        assertEquals(2037, meta.cast[0].id)
        assertEquals("Cillian Murphy", meta.cast[0].name)
        assertEquals(
            "https://image.tmdb.org/t/p/w185/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg",
            meta.cast[0].photo
        )
        assertEquals("J. Robert Oppenheimer", meta.cast[0].character)
    }

    @Test
    fun `string only cast still parses to names without photos`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "cast":["Cillian Murphy","Emily Blunt"]
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(listOf("Cillian Murphy", "Emily Blunt"), meta!!.cast.map { it.name })
        assertTrue(meta.cast.all { it.id == 0 && it.photo == null })
    }

    @Test
    fun `photoless app_extras cast does not shadow a photo carrying top level cast`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "cast":[
                {"id":2037,"name":"Cillian Murphy","photo":"https://image.tmdb.org/t/p/w185/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg","character":"J. Robert Oppenheimer"}
              ],
              "app_extras":{"cast":[{"name":"Cillian Murphy","character":"J. Robert Oppenheimer"}]}
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(
            "https://image.tmdb.org/t/p/w185/2lKs67r7FI4bPu0AXxMUJZxmUXn.jpg",
            meta!!.cast[0].photo
        )
        assertEquals(2037, meta.cast[0].id)
    }

    @Test
    fun `trailerStreams ytId entries parse`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "trailerStreams":[{"title":"Official Trailer","ytId":"uYPbbksJxIg"}]
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(1, meta!!.trailerStreams.size)
        assertEquals("uYPbbksJxIg", meta.trailerStreams[0].ytId)
        assertEquals("Official Trailer", meta.trailerStreams[0].title)
    }

    @Test
    fun `trailerStreams legacy source entries still parse`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "trailerStreams":[{"source":"qiuSBWVdgLI","type":"Trailer"}]
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(listOf("qiuSBWVdgLI"), meta!!.trailerStreams.map { it.ytId })
    }

    @Test
    fun `standard trailers source entries still parse and dedupe with trailerStreams`() {
        val meta = StremioParser.parseMeta(
            """{"meta":{
              "id":"tt15398776","type":"movie","name":"Oppenheimer",
              "trailerStreams":[{"title":"Official Trailer","ytId":"uYPbbksJxIg"}],
              "trailers":[{"source":"uYPbbksJxIg","type":"Trailer"},{"source":"qiuSBWVdgLI","type":"Teaser"}]
            }}""",
            "movie"
        )
        assertNotNull(meta)
        assertEquals(listOf("uYPbbksJxIg", "qiuSBWVdgLI"), meta!!.trailerStreams.map { it.ytId })
        assertNull(meta.cast.firstOrNull())
    }
}
