package com.pulsestream.app.data

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.pulsestream.app.data.db.AppDatabase
import io.mockk.coEvery
import io.mockk.mockkObject
import io.mockk.unmockkObject
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

/**
 * v0.14.46 — the first-search-zero fix (plavio-mobile-notes,
 * 2026-11-14 08:21): the primary lane gets ONE automatic retry when
 * an attempt fails or times out. A timeout and a failure funnel
 * through the same null result in searchPrimaryAttempt, so the
 * failure path pinned here is the retry loop itself; a COMPLETED
 * answer — even an empty one — must never be retried.
 *
 * The keyless lane's transport (BoundedHttp) is stubbed at the
 * object seam; no TMDB key is set, so searchPrimary takes the
 * keyless path exactly as the owner's phone did.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class PrimarySearchRetryTest {

    private fun withRepository(block: suspend (StreamRepository) -> Unit) = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("pulse_settings", Context.MODE_PRIVATE)
            .edit().clear().commit()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repository = StreamRepository(db, StremioApi(), SettingsStore(context))
        try {
            block(repository)
        } finally {
            db.close()
        }
    }

    @Test
    fun `failed first attempt is retried and the retry answer wins`() = withRepository { repo ->
        mockkObject(BoundedHttp)
        try {
            var calls = 0
            coEvery { BoundedHttp.get(any(), any(), any(), any()) } answers {
                calls++
                if (calls == 1) throw IOException("cold lookup chain")
                """{"results":[{"id":"tt32324552","type":"movie","name":"Ranabaali"}]}"""
            }
            val results = repo.searchPrimary("ranabaali")
            assertEquals(1, results.size)
            assertEquals("tt32324552", results[0].meta.id)
            assertEquals(2, calls)
        } finally {
            unmockkObject(BoundedHttp)
        }
    }

    @Test
    fun `completed empty answer is not retried`() = withRepository { repo ->
        mockkObject(BoundedHttp)
        try {
            var calls = 0
            coEvery { BoundedHttp.get(any(), any(), any(), any()) } answers {
                calls++
                """{"results":[]}"""
            }
            val results = repo.searchPrimary("nothing matches this")
            assertTrue(results.isEmpty())
            assertEquals(1, calls)
        } finally {
            unmockkObject(BoundedHttp)
        }
    }

    @Test
    fun `two failures return empty after exactly one retry`() = withRepository { repo ->
        mockkObject(BoundedHttp)
        try {
            var calls = 0
            coEvery { BoundedHttp.get(any(), any(), any(), any()) } answers {
                calls++
                throw IOException("still down")
            }
            val results = repo.searchPrimary("ranabaali")
            assertTrue(results.isEmpty())
            assertEquals(2, calls)
        } finally {
            unmockkObject(BoundedHttp)
        }
    }
}
