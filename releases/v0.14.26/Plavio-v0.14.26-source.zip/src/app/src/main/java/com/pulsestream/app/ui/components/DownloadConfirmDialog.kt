package com.pulsestream.app.ui.components

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.Subtitle
import com.pulsestream.app.data.download.DownloadManager
import com.pulsestream.app.data.download.DownloadService
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Confirmation dialog shown before starting a download.
 * Probes the file size via HEAD request and warns if it's large (>500MB).
 *
 * Poster plumbing (2026-10-28): [StreamItem] carries NO poster, so
 * this dialog has none in scope of its own — a caller that knows the
 * title's poster passes it via [posterUrl] (DetailScreen has
 * meta.poster; PlayerScreen has currentRequest.poster) and it is
 * forwarded to [DownloadManager.startDownload], which saves the
 * image locally for the Downloads/Library tiles. Callers that pass
 * nothing keep working unchanged; their downloads get no poster.
 */
@Composable
fun DownloadConfirmDialog(
    stream: StreamItem,
    title: String,
    posterUrl: String? = null,
    onDismiss: () -> Unit,
    onStarted: () -> Unit = {},
    // Subtitle-save plumbing (v0.14.14): when the user enabled "Save
    // subtitles with downloads", the manager fetches the best subtitles
    // for this title — the stream's bundled ones plus, when a
    // repository is provided, the online subtitle addons' results for
    // (type, imdbId) — and stores them beside the media. All optional;
    // callers that pass nothing keep the old behaviour.
    type: String? = null,
    imdbId: String? = null,
    bundledSubtitles: List<Subtitle> = emptyList(),
    repository: StreamRepository? = null
) {
    val context = LocalContext.current
    val manager = remember { DownloadManager.get(context) }
    val scope = rememberCoroutineScope()

    var sizeBytes by remember { mutableStateOf<Long?>(null) }
    var probing by remember { mutableStateOf(true) }
    // v0.14.47 (item 1): the start itself is a visible state, not a
    // silent gap — while startDownload enqueues (it can probe and
    // resolve first), the dialog shows "Starting download…" and
    // the button locks; only when the download is truly enqueued
    // does the "Download started" confirmation fire.
    var starting by remember { mutableStateOf(false) }
    var alreadyDownloaded by remember { mutableStateOf(false) }
    var requestError by remember { mutableStateOf<String?>(null) }
    // v0.14.13 (item 5): DASH joins HLS as a downloadable adaptive
    // format (segment engine + MP4 remux). Live manifests and
    // DRM-protected DASH can't be known from the URL — the engine
    // refuses those with the reason on the download row itself.
    val isDash = manager.isDashDownloadUrl(stream.url)
    val isHls = manager.isHlsDownloadUrl(stream.url)

    LaunchedEffect(stream.url) {
        alreadyDownloaded = manager.getByUrl(stream.url)?.status == "COMPLETED"
        if (!isDash && !isHls) sizeBytes = manager.probeSize(stream.url, stream.headers)
        probing = false
    }

    val enoughStorage = manager.storagePreflight(sizeBytes)
    val isLarge = (sizeBytes ?: -1L) > DownloadManager.LARGE_FILE_WARNING_BYTES
    val displayTitle = stream.title?.takeIf { it.isNotBlank() }
        ?: stream.name?.takeIf { it.isNotBlank() }
        ?: title

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Download", fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        text = {
            Column {
                Text(
                    displayTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
                Spacer(Modifier.height(8.dp))
                when {
                    probing -> {
                        Row {
                            OrbitDots(modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Checking file size…",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    isDash -> {
                        Text(
                            "This is a DASH stream. It will be downloaded in segments and saved as a single MP4 file, so the size can't be checked beforehand. Live or DRM-protected DASH can't be saved — the download will say so if this is one.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    isHls -> {
                        Text(
                            "This is an HLS stream. It will be downloaded in segments and saved as a single MP4 file, so the size can't be checked beforehand.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    alreadyDownloaded -> {
                        Text(
                            "This file is already downloaded.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    else -> {
                        val sizeText = sizeBytes?.let {
                            if (it > 0) manager.formatBytes(it) else "Unknown size"
                        } ?: "Unknown size"
                        Text(
                            "Size: $sizeText",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        if (sizeBytes != null && sizeBytes!! > 0 && !enoughStorage) {
                            Spacer(Modifier.height(8.dp))
                            Text("Not enough free storage for this file plus a safety reserve.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        if (isLarge) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "⚠️ This file is large (${manager.formatBytes(sizeBytes!!)}). " +
                                    "Make sure you have enough storage and a stable connection.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
                if (starting) {
                    Spacer(Modifier.height(8.dp))
                    Row {
                        OrbitDots(modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Starting download…",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
                if ((isHls || isDash) && !manager.hasStorageReserve()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Not enough free storage — downloads keep a safety reserve free. Free up space and try again.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                requestError?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (!alreadyDownloaded) {
                        starting = true
                        scope.launch(kotlinx.coroutines.NonCancellable) {
                            try {
                                val repo = repository
                                val subtitleSearch:
                                    (suspend (String, String) -> List<Subtitle>)? =
                                    if (repo != null) {
                                        { t: String, i: String ->
                                            repo.searchSubtitles(t, i)
                                        }
                                    } else {
                                        null
                                    }
                                manager.startDownload(
                                    url = stream.url,
                                    title = displayTitle,
                                    headers = stream.headers,
                                    posterUrl = posterUrl,
                                    type = type,
                                    imdbId = imdbId,
                                    bundledSubtitles = bundledSubtitles,
                                    subtitleSearch = subtitleSearch
                                )
                                DownloadService.start(context)
                                // v0.14.47: the confirmation fires
                                // HERE — the moment the download is
                                // truly enqueued — not at tap time.
                                Toast.makeText(
                                    context, "Download started", Toast.LENGTH_SHORT
                                ).show()
                                onStarted()
                                onDismiss()
                            } catch (e: Exception) {
                                starting = false
                                requestError = e.message ?: "Could not start this download."
                            }
                        }
                    } else onDismiss()
                },
                // P14 (v0.14.22): adaptive downloads run a storage
                // preflight too — the free-space reserve must hold
                // before starting, same as for progressive files
                // (whose exact size is checked against it above).
                // v0.14.47: locked while a start is in flight.
                enabled = !probing && !starting && !alreadyDownloaded &&
                    (if (isHls || isDash) manager.hasStorageReserve() else enoughStorage)
            ) {
                Text("Download", color = MaterialTheme.colorScheme.primary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
