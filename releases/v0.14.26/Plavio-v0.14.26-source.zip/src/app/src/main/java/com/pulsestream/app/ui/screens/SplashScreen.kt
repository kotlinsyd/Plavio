package com.pulsestream.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsestream.app.R
import kotlinx.coroutines.delay

/**
 * Launch splash — the big-brand way (v0.14.40, item 12; owner's
 * order 2026-11-13, corrected the same morning after he watched
 * the preview: "No icon, only plavio wordings with Play button in
 * O. And your streaming universe.").
 *
 * The composition is SETTLED from the very first frame — no video,
 * no poster, no black or half-built frames: the PLAVIO signature
 * wordmark WITH the play triangle in the O (the Plavio Web
 * derivative, `plavio_web_logo`) centred on the flat (3,3,3)
 * background, the tagline "Your streaming universe" fading in
 * beneath it, and a loader under the tagline for the whole
 * splash. There is NO Weave mark anywhere in the splash — the
 * owner's correction removed it from both this drawn splash and
 * the system splash (Theme.PulseStream.Splash: the flat
 * background with NO icon since v0.14.41).
 *
 * v0.14.41 (owner's amendment, 2026-11-13): the loader became
 * CONNECTING DOTS under the tagline. v0.14.47 (owner's order
 * 2026-11-14): the dots are GONE — he didn't like them. The
 * loader is now the approved travelling-pulse sample (round-2
 * D2): a faint resting line in the same seat, with one soft
 * pulse of light travelling along it, looping seamlessly until
 * the splash ends at Home. HARD RULE from the same order: the
 * wordmark and the tagline arrive ONCE (the shipped timing
 * above) and then HOLD — they never fade out or re-appear; only
 * the pulse loops. Everything else is exactly the .40 splash.
 *
 * The old ExoPlayer HUG clip is retired from the mobile launch:
 * its asset (res/raw/splash_g_orbit_build.mp4) stays in the tree
 * untouched for any other use, and the wait-state poster no
 * longer exists in this flow at all.
 *
 * Exit rule (unchanged from the clip era): the splash leaves
 * only when BOTH hold — 3 seconds have elapsed since splash
 * start and the home feed is ready; the caller keeps the 8s
 * safety cap so a dead network can't trap the splash.
 */
@Composable
fun SplashScreen(feedReady: Boolean, onDone: () -> Unit) {
    var minTimeDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(3000)
        minTimeDone = true
    }
    LaunchedEffect(minTimeDone, feedReady) {
        if (minTimeDone && feedReady) onDone()
    }

    // Tagline fade: starts invisible, fades in over ~0.8s once
    // the wordmark has had its beat (~0.5s in).
    val taglineAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(500)
        taglineAlpha.animateTo(1f, animationSpec = tween(durationMillis = 800))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF030303))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-24).dp)
                .fillMaxWidth()
        ) {
            // The wordmark alone, settled from frame one: 65% of
            // the screen width, centred at the seat the settled
            // clip frame used (the column's slight upward offset
            // keeps the whole stack optically centred).
            Image(
                painter = painterResource(R.drawable.plavio_web_logo),
                contentDescription = "PLAVIO",
                modifier = Modifier.fillMaxWidth(0.65f)
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = "Your streaming universe",
                style = MaterialTheme.typography.bodyLarge,
                fontSize = 16.sp,
                letterSpacing = 1.5.sp,
                color = Color(0xFFC9C9D4),
                modifier = Modifier.alpha(taglineAlpha.value)
            )
            Spacer(Modifier.height(26.dp))
            TravellingPulse(modifier = Modifier.width(96.dp).height(16.dp))
        }
    }
}

/**
 * Travelling pulse (v0.14.47 — owner's pick, replacing the
 * connecting dots he rejected): the approved round-2 D2 sample,
 * rebuilt in Compose with the sample's own motion numbers
 * (build_startup_d2.py). A faint resting line spans the same
 * 96dp seat the dots used; one soft pulse of light travels along
 * it left→right and dissolves, rests a calm beat, and travels
 * again — period 1.5s (travel 40/45 of the period ≈ 1.333s,
 * rest 5/45 ≈ 0.167s), looping seamlessly until the splash ends
 * at Home. The pulse's brightness envelope is sin(π·p) — zero at
 * both travel ends — so the loop point is invisible. Colours are
 * the sample's: pale lavender-white line (216,208,245) and pulse
 * (222,214,252), peak alpha 150/255. The wordmark and tagline
 * are NOT part of this animation — they arrive once and hold
 * (owner's hard rule); only the pulse loops. Reduced motion
 * shows the resting line alone, static.
 */
@Composable
private fun TravellingPulse(modifier: Modifier = Modifier) {
    val reduced = com.pulsestream.app.data.rememberReducedMotion()
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(reduced) {
        if (reduced) {
            phase = 0f
            return@LaunchedEffect
        }
        val anim = Animatable(0f)
        while (true) {
            anim.snapTo(0f)
            anim.animateTo(
                1f,
                animationSpec = tween(durationMillis = 1500, easing = LinearEasing)
            ) { phase = value }
        }
    }
    Canvas(modifier) {
        val cy = size.height / 2f
        val lineColor = Color(0xFFD8D0F5)
        // The faint resting line, in the sample's two layers: a
        // wide, very faint glow pass under a thin core pass (the
        // sample's soft_line: glow alpha 22/255, core alpha 52/255).
        drawLine(
            lineColor.copy(alpha = 22f / 255f),
            Offset(0f, cy),
            Offset(size.width, cy),
            strokeWidth = 3.5.dp.toPx(),
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
        drawLine(
            lineColor.copy(alpha = 52f / 255f),
            Offset(0f, cy),
            Offset(size.width, cy),
            strokeWidth = 1.dp.toPx(),
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
        if (reduced) return@Canvas
        // Travel occupies the first 40/45 of the period; the rest
        // is the calm beat with the envelope at zero.
        val travelFraction = 40f / 45f
        if (phase >= travelFraction) return@Canvas
        val p = phase / travelFraction
        val env = kotlin.math.sin(kotlin.math.PI * p).toFloat()
        if (env <= 0.02f) return@Canvas
        // The sample's pulse: an elliptical radial sprite, 60×22dp
        // in this seat, travelling between 6dp margins with the
        // round-2 ease (EaseInOutCubic) on its position.
        val margin = 6.dp.toPx()
        val x = margin + (size.width - 2 * margin) * EaseInOutCubic.transform(p)
        val blobW = 60.dp.toPx()
        val blobH = 22.dp.toPx()
        val peak = (150f / 255f) * env
        val blobColor = Color(0xFFDED6FC)
        // Radial falloff matching the sample's (1-r²)^1.8 curve,
        // squashed vertically into the ellipse by the transform.
        withTransform({
            translate(x, cy)
            scale(1f, blobH / blobW, Offset.Zero)
        }) {
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to blobColor.copy(alpha = peak),
                        0.5f to blobColor.copy(alpha = peak * 0.60f),
                        0.75f to blobColor.copy(alpha = peak * 0.22f),
                        1f to Color.Transparent
                    ),
                    center = Offset.Zero,
                    radius = blobW / 2f
                ),
                radius = blobW / 2f,
                center = Offset.Zero
            )
        }
    }
}
