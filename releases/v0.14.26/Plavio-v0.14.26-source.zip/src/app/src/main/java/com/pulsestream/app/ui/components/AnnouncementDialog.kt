package com.pulsestream.app.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.AppConfigSupport
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * The owner's one-shot announcement from the remote app config
 * (AppConfig), shown once per announcement id — the seen-id lives in
 * AppConfig's prefs, so dismissing here is permanent for that id and
 * a later launch never re-shows it. Rendered in the UpdateDialog
 * pattern (same AlertDialog shape, palette and container colour —
 * the locked Onyx theme is untouched); a null announcement (the
 * standing state) renders nothing at all.
 */
@Composable
fun AnnouncementPrompt(
    announcement: AppConfigSupport.Announcement?,
    onDismiss: () -> Unit
) {
    if (announcement != null) {
        AnnouncementDialog(announcement = announcement, onDismiss = onDismiss)
    }
}

/** Dismissible announcement popup; every dismissal path is the same
 *  "seen it" — there is nothing to confirm or install. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AnnouncementDialog(
    announcement: AppConfigSupport.Announcement,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                announcement.title,
                color = TextPrimary,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    announcement.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                        .verticalScroll(rememberScrollState())
                )
                // Optional action buttons (v0.14.45): a centred row
                // of small frost capsules under the text, one per
                // config button; a tap opens its URL externally and
                // dismisses (the card counts as seen either way, so
                // the show-once-per-id rule is untouched). No buttons
                // in the payload = the card renders exactly as before.
                if (announcement.buttons.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement
                            .spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement
                            .spacedBy(8.dp)
                    ) {
                        announcement.buttons.forEach { button ->
                            Text(
                                text = button.label,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.08f))
                                    .border(
                                        1.dp,
                                        Color.White.copy(alpha = 0.22f),
                                        RoundedCornerShape(50)
                                    )
                                    .clickable {
                                        runCatching {
                                            context.startActivity(
                                                Intent(
                                                    Intent.ACTION_VIEW,
                                                    Uri.parse(button.url)
                                                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            )
                                        }
                                        onDismiss()
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Got it", color = LocalPalette.current.accent)
            }
        },
        containerColor = Color(0xFF14141F)
    )
}
