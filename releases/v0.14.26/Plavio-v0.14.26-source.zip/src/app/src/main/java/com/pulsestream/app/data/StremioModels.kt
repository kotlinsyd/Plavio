package com.pulsestream.app.data

/** Stremio addon protocol data models (https://github.com/Stremio/stremio-addon-sdk). */

data class CatalogRef(
    val type: String,
    val id: String,
    val name: String,
    /**
     * Catalog "extra" keys the addon declares (e.g. "search", "genre").
     * A catalog supports the Stremio search extra only when "search" is here —
     * addons without it answer 404 to search= queries.
     */
    val extra: List<String> = emptyList(),
    /** Options declared for the `genre` extra ({name:"genre", options:[...]}), when present. */
    val genreOptions: List<String> = emptyList()
) {
    val supportsSearch: Boolean get() = "search" in extra.map { it.lowercase() }
}

data class AddonManifest(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val types: List<String>,
    val catalogs: List<CatalogRef>,
    val resources: List<String>,
    /** True when the manifest's behaviorHints mark it as configurable (has a /configure page). */
    val configurable: Boolean = false,
    /** Manifest logo URL — shown as the addon icon in the Addons tab. */
    val logo: String? = null
) {
    val hasCatalog: Boolean get() = resources.contains("catalog")
    val hasMeta: Boolean get() = resources.contains("meta")
    val hasStream: Boolean get() = resources.contains("stream")
    val hasSubtitles: Boolean get() = resources.contains("subtitles")
    val isFullAddon: Boolean get() = hasCatalog && hasMeta && hasStream
}

data class MetaPreview(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val logo: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val imdbRating: String? = null,
    val genres: List<String> = emptyList(),
    /**
     * TMDB popularity when a search/catalogue lane supplies it
     * (v0.14.27). Search ranking uses it only inside a title-match
     * tier; rows from lanes that publish no signal keep the default
     * zero and fall through to rating/year ordering.
     */
    val popularity: Double = 0.0,
    /**
     * Original language (ISO 639-1, e.g. "hi"/"en") when the serving
     * lane publishes it (v0.14.29): PMeta /related passes TMDB's
     * original_language through as `originalLanguage`, and the TMDB
     * stage fills it directly. Null when the lane carries no signal —
     * the Search suggestions mix weights picks by this field and
     * treats null as language-unknown, never as English.
     */
    val originalLanguage: String? = null
)

data class Video(
    val id: String,
    val title: String,
    val season: Int = 0,
    val episode: Int = 0,
    val overview: String? = null,
    val thumbnail: String? = null,
    val released: String? = null
)

/** A cast member: TMDB person id (0 when unknown, e.g. keyless Cinemeta), name and photo. */
data class CastMember(
    val id: Int = 0,
    val name: String,
    val photo: String? = null,
    /** Best-known titles from the addon's /person-search (search rows
     * only; cast lists leave it null). */
    val knownFor: String? = null,
    /** The character played, when the serving meta carries it
     * (TMDB credits and any addon that sends a "character" field);
     * null for names-only cast. Shown under the actor's name on the
     * detail page's cast row (item 34). */
    val character: String? = null
)

/** Actor filmography from PlavioMeta /person. */
data class PersonDetail(
    val id: Int,
    val name: String,
    val photo: String?,
    val movies: List<MetaPreview>,
    val series: List<MetaPreview>,
    /** TMDB birthday "YYYY-MM-DD" (v0.14.40, item 14); null when unknown. */
    val birthday: String? = null,
    /** TMDB deathday "YYYY-MM-DD" when the person has died. */
    val deathday: String? = null,
    /** Birthplace text as served ("Beirut, Lebanon"). */
    val placeOfBirth: String? = null,
    /** Biography text; null/blank when the source carries none. */
    val biography: String? = null,
    /** The person's best-known titles (popularity order) for the "Known for" line. */
    val knownFor: List<String> = emptyList()
)

/** A YouTube trailer reference from an addon's meta (PlavioMeta `trailerStreams`). */
data class TrailerStream(
    val title: String,
    val ytId: String
)

/**
 * One part of a franchise collection as served INSIDE a movie meta
 * (PlavioMeta v2.4.9 `collection` field, v0.14.40 item 9): TMDB ids,
 * the part's IMDb id when TMDB maps one (null for the rare unmapped
 * part), release date text ("YYYY-MM-DD", "" when undated) and the
 * RAW TMDB poster path (prefix with the image CDN when rendering).
 */
data class MetaCollectionPart(
    val tmdbId: Int,
    val imdbId: String? = null,
    val title: String,
    val releaseDate: String? = null,
    val posterPath: String? = null
)

/**
 * Franchise collection carried by a movie meta itself (PlavioMeta
 * v2.4.9): parts in release order, undated last. Present only when
 * the franchise exists with at least two parts.
 */
data class MetaCollection(
    val id: Int,
    val name: String,
    val parts: List<MetaCollectionPart> = emptyList()
)

data class MetaDetail(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val logo: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val imdbRating: String? = null,
    val genres: List<String> = emptyList(),
    val videos: List<Video> = emptyList(),
    /** YouTube trailers (PlavioMeta `trailerStreams`); empty when the addon provides none. */
    val trailerStreams: List<TrailerStream> = emptyList(),
    /** Top-billed cast (PlavioMeta; names only in keyless/Cinemeta mode). */
    val cast: List<CastMember> = emptyList(),
    /** Extra facts for the Show Details tiles — present only when the meta addon provides them. */
    val runtime: String? = null,
    val status: String? = null,
    val certification: String? = null,
    val country: String? = null,
    val network: String? = null,
    /** Production companies (TMDB Enrichment fills this; addons don't send it). */
    val production: String? = null,
    /**
     * IMDb tt id when the serving meta carries one separately from its
     * own id (an `imdb_id` field, or the id itself when it is a tt id).
     * Opaque addon ids (e.g. CNCVerse `cnc:` payloads) leave this null —
     * TMDB enrichment then resolves by title + year instead.
     */
    val imdbId: String? = null,
    /**
     * behaviorHints.defaultVideoId when the serving meta provides one
     * (v0.14.19): PlavioMeta sends the title's IMDb tt id here for
     * TMDB-native metas — the id stream addons can actually resolve.
     * Used by DetailScreen's tmdb-id stream-target resolution.
     */
    val defaultVideoId: String? = null,
    /** Director name(s) when the serving meta or TMDB enrichment provides them (v0.14.18 detail page). */
    val director: String? = null,
    /** Writer name(s), same provenance as [director]. */
    val writer: String? = null,
    /**
     * TMDB vote (0–10, one decimal as text) when TMDB enrichment
     * supplied one (v0.14.18). Kept separate from [imdbRating]: the
     * detail page's ratings row shows each under its own label and
     * hides whichever is missing.
     */
    val tmdbRating: String? = null,
    /** MDBList aggregate score (0–100 as text) from PMeta's MDBList enrichment (v0.14.20). */
    val mdblistRating: String? = null,
    /** MDBList per-source Trakt score (0–100 as text), when the title has one (v0.14.20). */
    val traktRating: String? = null,
    /** MDBList per-source Rotten Tomatoes critics score (0–100 as text), when present (v0.14.20). */
    val rtRating: String? = null,
    /** MDBList per-source Rotten Tomatoes audience score (0–100 as text), when present (v0.14.20). */
    val rtAudienceRating: String? = null,
    /** MDBList per-source Metacritic score (0–100 as text), when present (v0.14.20). */
    val metacriticRating: String? = null,
    /** MDBList per-source Letterboxd score (0–100 as text), when present (v0.14.20). */
    val letterboxdRating: String? = null,
    /** Per-season poster URLs from TMDB season data (v0.14.18); empty when no season art is known. */
    val seasonPosters: Map<Int, String> = emptyMap(),
    /**
     * Franchise collection served inside the meta (PlavioMeta
     * v2.4.9, v0.14.40 item 9). When present, the Details page
     * renders the collection row from THIS — no extra TMDB chain;
     * the user's own TMDB-key chain stays as the fallback for
     * metas that don't carry it.
     */
    val collection: MetaCollection? = null
)

data class StreamItem(
    val url: String,
    val name: String? = null,
    val title: String? = null,
    /** Name of the addon this stream came from (set when merging multi-addon results). */
    val sourceName: String? = null,
    /** Id of the addon this stream came from — used for star priority. */
    val sourceId: String? = null,
    /**
     * Extra HTTP request headers the stream URL needs (parsed from the
     * addon's behaviorHints.proxyHeaders.request). Sent by the player and
     * the stream prober. Empty for normal direct links.
     */
    val headers: Map<String, String> = emptyMap(),
    /**
     * Torrent info hash for P2P/debrid streams (parsed from the addon's
     * "infoHash" field). Null for direct HTTP streams. When set and the
     * stream has no usable URL, TorBox debrid can resolve it to a direct
     * HTTP link (only when a TorBox API key is configured).
     */
    val infoHash: String? = null,
    /** Index of the requested file within a torrent/file pack, when supplied by the addon. */
    val fileIdx: Int? = null,
    /** Exact torrent-relative file path, when supplied by the addon. */
    val filePath: String? = null,
    /** Optional stream MIME hint, from the stream or its behaviorHints. */
    val mimeType: String? = null,
    /** Optional Stremio video metadata retained for downstream playback decisions. */
    val videoSize: Long? = null,
    val filename: String? = null,
    /** Identity only: lets a cached HTTP link replace its pending row across progressive updates. */
    val resolvedInfoHash: String? = null,
    /**
     * Audio language of this file when the addon payload carries one
     * (P6, v0.14.22): an explicit `audioLanguage`/`language` field on
     * the stream or its behaviorHints, or the first entry of an
     * `audioLanguages` list. Null when the payload says nothing — the
     * autoplay picker then simply has no language signal for the row.
     */
    val audioLanguage: String? = null,
    /**
     * Smart Picks flag (PlavioHD's `behaviorHints.plavioPick`, addon
     * v1.9.135): the serving addon has itself playback-verified this
     * link — demux + decode + seek, verdict fresh — and its source
     * is outside the bottom health tier. Drives the Smart Picks box
     * on the streams surfaces and, when no debrid is attached, the
     * Smart Picks tier of the autoplay ordering. Absent (false) on
     * every other addon and on unverdicted rows.
     */
    val plavioPick: Boolean = false
)

data class Subtitle(
    val url: String,
    val lang: String
)

data class StreamResult(
    val streams: List<StreamItem>,
    val subtitles: List<Subtitle>,
    /**
     * v0.14.25: PlavioHD's still-filling marker — a short-hold answer
     * served while the server-side fill for this title is still
     * running. Such an answer is PROVISIONAL ("not yet"), never a
     * final "no streams exist": [StreamRepository] displays its
     * streams like any progressive emission but keeps the leg open
     * and re-asks inside the first-party budget until an unmarked
     * answer arrives. Absent/false for every other addon and for
     * final PlavioHD answers.
     */
    val filling: Boolean = false,
    /**
     * v0.14.43: TRUE once every leg of the fan-out has produced its
     * first answer (final OR provisional) or finished — the point
     * where a consumer may end its loading state and fire its
     * autoplay decision on what is displayed. A still-filling leg
     * keeps topping the list up behind this flag (its budget is a
     * TOP-UP budget, not a settle budget); late rows keep arriving
     * as further emissions, and the flow's final emission always
     * carries settled = true. Before v0.14.43 the only settle
     * signal was flow completion, so a marked leg held the Details
     * sources section open for up to the 45 s first-party budget.
     */
    val settled: Boolean = false
)

/** A catalog row shown on Home: one catalog of one addon with its items. */
data class CatalogRow(
    val addonId: String,
    val addonName: String,
    val baseUrl: String,
    val catalogName: String,
    val type: String,
    val catalogId: String,
    val items: List<MetaPreview>
)

/** Cached meta used for search, tagged with its source addon. */
data class CachedMeta(
    val addonId: String,
    val addonName: String,
    val baseUrl: String,
    val meta: MetaPreview
)

/** Everything the player needs, passed in-memory via the repository. */
data class PlaybackRequest(
    val streamUrl: String,
    val title: String,
    val poster: String?,
    val videoId: String,
    val subtitles: List<Subtitle> = emptyList(),
    /** IMDb id of the title (from Cinemeta metadata) — powers skip-segments + subtitle search. */
    val imdbId: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    val isMovie: Boolean = false,
    /** Content type for stream re-resolution ("movie"/"series"/"tv"). */
    val type: String = if (isMovie) "movie" else "series",
    /** Display label for the chosen stream, e.g. "1080p". */
    val streamLabel: String? = null,
    /** Addon the chosen stream came from. */
    val sourceName: String? = null,
    /** Id of the addon the chosen stream came from (DB v15 stream identity). */
    val sourceId: String? = null,
    /** The chosen stream's own display title — the resume fingerprint (DB v15). */
    val streamTitle: String? = null,
    /** Official studio logo artwork for the title (notes item 11); saved with playback state. */
    val logo: String? = null,
    /**
     * Wide art for the player's fullscreen loading state (v0.14.33):
     * the title's backdrop, or the episode's own still for series —
     * [poster] stays the fallback when this is null.
     */
    val background: String? = null,
    /**
     * Meta facts for the loading state's quiet line (v0.14.33) —
     * only what the serving meta actually carried; absent fields
     * simply don't render. Never synthesised.
     */
    val releaseInfo: String? = null,
    val runtime: String? = null,
    val genres: List<String> = emptyList(),
    val imdbRating: String? = null,
    /**
     * Top-billed cast NAMES for the loading state's one-by-one
     * "Starring …" line (v0.14.34) — only what the serving meta
     * actually carried; empty (the default everywhere else) means
     * the line never appears. Never synthesised.
     */
    val cast: List<String> = emptyList(),
    /** All fetched streams (in-player Sources switcher); may be empty for resumed items. */
    val streams: List<StreamItem> = emptyList(),
    /**
     * PrePlay carry (v0.14.40, item 13): the stream the Details
     * page's background probe had ALREADY settled on when the user
     * pressed Watch Now into pending mode. The player's pending
     * auto-pick tries this stream before running its own probe from
     * zero — a long Details dwell no longer throws the finished
     * pick away. Null for every other request kind.
     */
    val carriedPick: StreamItem? = null,
    /** Full episode list for series (in-player Episodes picker). */
    val episodes: List<Video> = emptyList(),
    /** Show/movie id (episode-switching context). */
    val metaId: String = "",
    /** Series name for the player header (null for movies). */
    val seriesName: String? = null,
    /** Episode title for the player header (series only). */
    val episodeTitle: String? = null,
    /** Extra HTTP request headers the stream URL needs (from the addon's proxyHeaders). */
    val headers: Map<String, String> = emptyMap(),
    /**
     * Trailer playback (Trailers tab): skips auto-play-next-episode, resume
     * position saving, and Trakt/Simkl scrobbling.
     */
    val isTrailer: Boolean = false,
    /**
     * Resume at this fraction (0f-1f) of the real duration once it
     * is known (notes item 13): set for Continue Watching entries
     * imported from Trakt/Simkl progress when no absolute position
     * could be computed at import time. Null for normal plays.
     */
    val startAtProgressPct: Float? = null,
    /** Optional separate audio track for video-only sources; normal playback is unchanged. */
    val mergeAudioUrl: String? = null,
    /** Optional addon-provided MIME hint; playback may still probe/self-heal it. */
    val mimeType: String? = null,
    /** Originating Live channel, retained for player zap/source re-resolution. */
    val liveChannel: TvChannelRef? = null
) {
    /** M3U uses type=tv; addon Live requests may use a custom resource type. */
    val isLive: Boolean get() = type == "tv" || liveChannel != null
}

/** One entry on the Trailers tab: catalog item + where to fetch its meta/trailers. */
data class TrailerItem(
    val addonId: String,
    val baseUrl: String,
    val type: String,
    val meta: MetaPreview
)

/** A Live TV channel reference for the player's channel-zap handoff. */
data class TvChannelRef(
    val addonId: String,
    val metaId: String,
    val name: String,
    val poster: String?,
    /** Resource type used by the channel meta and /stream request. */
    val type: String = "tv",
    /** Origin catalog identity; addonId above identifies its owning addon. */
    val catalogId: String? = null
)

/** Pulls a quality tag like "1080p"/"4K" out of a stream's name/title, if present. */
fun streamQualityLabel(stream: StreamItem): String? {
    val text = listOfNotNull(stream.name, stream.title).joinToString(" ")
    return Regex("""\b(2160p|1440p|1080p|720p|480p|360p|4K)\b""", RegexOption.IGNORE_CASE)
        .find(text)?.value?.uppercase()
}
