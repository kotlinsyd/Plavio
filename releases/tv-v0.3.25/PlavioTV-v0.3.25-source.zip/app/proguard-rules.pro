-keepattributes SourceFile,LineNumberTable

-keep class com.github.damontecres.wholphin.mpv.MPVLib { *; }

-keep class * extends com.google.protobuf.GeneratedMessageLite { *; }
-keepclassmembers class * extends com.google.protobuf.GeneratedMessageLite {
  <fields>;
  <methods>;
}
-dontwarn com.google.protobuf.**

# TODO investigate using smaller scope
-keep class com.google.common.cache.** { *; }

# Media3SubtitleOverride uses reflection to access/modify these fields
# Bundled FFmpeg audio extension: JNI binds by class/method name and the
# native side calls back into the decoder, so keep the whole package.
-keep class androidx.media3.decoder.ffmpeg.** { *; }

-keep class androidx.media3.ui.SubtitleView {
  private androidx.media3.ui.SubtitleView$Output output;
}
-keep class androidx.media3.ui.CanvasSubtitleOutput {
  private final java.util.List painters;
}
-keep class androidx.media3.ui.SubtitlePainter {
  private final float outlineWidth;
}

# Rhino (NewPipe extractor dep, v0.3.26): its bean-introspection path
# references java.beans, which does not exist on Android and is never
# used at runtime — silence R8's missing-class errors for it.
-dontwarn java.beans.BeanDescriptor
-dontwarn java.beans.BeanInfo
-dontwarn java.beans.IntrospectionException
-dontwarn java.beans.Introspector
-dontwarn java.beans.PropertyDescriptor
