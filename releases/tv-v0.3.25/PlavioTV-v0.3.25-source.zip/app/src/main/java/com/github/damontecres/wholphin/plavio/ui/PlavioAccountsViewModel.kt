package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.cloud.PlavioAccountManager
import com.github.damontecres.wholphin.plavio.cloud.PlavioAutoBackup
import com.github.damontecres.wholphin.plavio.cloud.PlavioBackup
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Everything the Settings → Account section renders. */
data class PlavioAccountUiState(
    val plavioConfigured: Boolean = false,
    val plavioEmail: String? = null,
    val plavioLastSync: String? = null,
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    /** Set after "Forgot password" succeeded: the reset-code form shows. */
    val resetRequestedFor: String? = null,
)

/**
 * Settings → Account: the Plavio account is the one and only sync
 * door on TV (Supabase Auth, no email verification), carrying the
 * full backup payload via [PlavioBackup]. (The Google Drive door
 * was removed in v0.3.26 on the owner's order — it was never used.)
 */
@HiltViewModel
class PlavioAccountsViewModel
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        backup: PlavioBackup,
        private val uiPrefs: PlavioUiPrefs,
    ) : ViewModel() {
        private val accountManager = PlavioAccountManager(context, backup)

        private val _state = MutableStateFlow(PlavioAccountUiState())
        val state: StateFlow<PlavioAccountUiState> = _state

        /** Auto backup on app open (Sync panel switch; phone parity, default on). */
        val autoBackup: StateFlow<Boolean> = uiPrefs.autoBackup

        init {
            refresh()
        }

        fun refresh() {
            _state.value =
                _state.value.copy(
                    plavioConfigured = PlavioAccountManager.isConfigured(),
                    plavioEmail = accountManager.accountEmail(),
                    plavioLastSync = accountManager.lastSyncTime(),
                )
        }

        private fun run(
            onDone: (String) -> Unit,
            block: suspend () -> Unit,
        ) {
            if (_state.value.busy) return
            _state.value = _state.value.copy(busy = true, message = null, error = null)
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching { block() }
                    .onSuccess { onDone("Done") }
                    .onFailure { e ->
                        _state.value =
                            _state.value.copy(
                                busy = false,
                                error = e.message ?: "Something went wrong.",
                            )
                        refresh()
                    }
            }
        }

        private fun finish(message: String) {
            _state.value = _state.value.copy(busy = false, message = message, error = null)
            refresh()
        }

        // --------------------------------------------------------------
        // Plavio account
        // --------------------------------------------------------------

        fun plavioSignIn(
            email: String,
            password: String,
        ) {
            run(onDone = { }) {
                accountManager.signIn(email.trim(), password).getOrThrow()
                val restored = accountManager.syncAfterSignIn().getOrDefault(false)
                finish(
                    if (restored) {
                        "Signed in — your backup was restored."
                    } else {
                        "Signed in — backup saved."
                    },
                )
            }
        }

        fun plavioSignUp(
            email: String,
            password: String,
        ) {
            run(onDone = { }) {
                val sessionNow = accountManager.signUp(email.trim(), password).getOrThrow()
                if (sessionNow) {
                    val restored = accountManager.syncAfterSignIn().getOrDefault(false)
                    finish(
                        if (restored) {
                            "Account created — your backup was restored."
                        } else {
                            "Account created — backup saved."
                        },
                    )
                } else {
                    finish("Account created — sign in to continue.")
                }
            }
        }

        /** Changes the signed-in account's password (Account page, v0.3.21). */
        fun plavioChangePassword(newPassword: String) {
            run(onDone = { }) {
                accountManager.changePassword(newPassword).getOrThrow()
                finish("Password changed.")
            }
        }

        fun plavioSignOut() {
            run(onDone = { }) {
                accountManager.signOut()
                finish("Signed out.")
            }
        }

        fun plavioForgot(email: String) {
            run(onDone = { }) {
                accountManager.requestPasswordReset(email.trim()).getOrThrow()
                _state.value = _state.value.copy(resetRequestedFor = email.trim())
                finish("Reset code sent — check your email.")
            }
        }

        fun plavioResetPassword(
            email: String,
            code: String,
            newPassword: String,
        ) {
            run(onDone = { }) {
                accountManager
                    .verifyResetAndSetPassword(email.trim(), code.trim(), newPassword)
                    .getOrThrow()
                _state.value = _state.value.copy(resetRequestedFor = null)
                finish("Password updated — sign in with the new password.")
            }
        }

        fun plavioSync() {
            run(onDone = { }) {
                accountManager.syncNow().getOrThrow()
                finish("Backup saved to your Plavio account.")
            }
        }

        fun plavioRestore() {
            run(onDone = { }) {
                val found = accountManager.restoreFromAccount().getOrThrow()
                finish(
                    if (found) {
                        "Backup restored."
                    } else {
                        "No backup found on this account yet."
                    },
                )
            }
        }

        /**
         * Flips the app-open auto-backup switch (Sync panel): saves
         * the pref and re-arms (or cancels) the scheduled pass, so
         * the change takes effect without waiting for a restart.
         */
        fun setAutoBackup(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setAutoBackup(enabled)
                PlavioAutoBackup.ensureScheduled(context, enabled)
            }
        }
    }
