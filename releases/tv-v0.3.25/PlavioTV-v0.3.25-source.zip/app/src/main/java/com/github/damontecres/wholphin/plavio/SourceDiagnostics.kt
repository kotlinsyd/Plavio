package com.github.damontecres.wholphin.plavio

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import timber.log.Timber

/** Health of one addon host, derived from its latest settled request. */
enum class SourceHealth {
    /** Never asked (or only ever still loading). */
    UNKNOWN,

    /** Last settled request answered. */
    OK,

    /** Last settled request answered but carried nothing (streams). */
    NO_RESULTS,

    /** Last settled request failed / timed out / needs auth. */
    FAILED,
}

/**
 * Per-source request diagnostics, signature-compatible with the phone
 * app's version so the addon API layer records outcomes the same way.
 * v0.3.26: the records are now KEPT (a bounded in-memory ring) and
 * readable — the Addons screen shows each addon's health from them,
 * and an empty streams screen names which addons failed vs which
 * simply had nothing. Still process-lifetime only, like the phone's.
 */
object SourceDiagnostics {
    data class Entry(
        val provider: String,
        val outcome: String,
        val durationMs: Long,
        val atMs: Long,
    )

    private const val MAX_ENTRIES = 120

    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries

    fun record(
        provider: String,
        outcome: String,
        durationMs: Long,
    ) {
        Timber.v("Addon source $provider: $outcome in $durationMs ms")
        val entry =
            Entry(
                provider = provider,
                outcome = outcome,
                durationMs = durationMs,
                atMs = System.currentTimeMillis(),
            )
        _entries.value = (_entries.value + entry).takeLast(MAX_ENTRIES)
    }

    /** The newest entry per provider, "loading" records included. */
    fun latestByProvider(): Map<String, Entry> =
        _entries.value
            .groupBy { it.provider }
            .mapValues { (_, list) -> list.last() }

    /**
     * The newest SETTLED (non-"loading") entry per provider — a host
     * whose last word is "loading" has a request in flight, which
     * says nothing about its health yet.
     */
    fun latestSettledByProvider(): Map<String, Entry> =
        _entries.value
            .filter { it.outcome != "loading" }
            .groupBy { it.provider }
            .mapValues { (_, list) -> list.last() }

    /** Health for one provider key (a host), from its latest settled record. */
    fun healthFor(provider: String): SourceHealth =
        healthOf(latestSettledByProvider()[provider]?.outcome)

    /** Same, over a caller-held snapshot (Compose state reads). */
    fun healthFor(
        provider: String?,
        snapshot: List<Entry>,
    ): SourceHealth {
        if (provider == null) return SourceHealth.UNKNOWN
        val latest =
            snapshot.lastOrNull { it.provider == provider && it.outcome != "loading" }
        return healthOf(latest?.outcome)
    }

    /** Pure outcome → health mapping (unit-tested). */
    fun healthOf(outcome: String?): SourceHealth =
        when (outcome) {
            "succeeded" -> SourceHealth.OK
            "no_results" -> SourceHealth.NO_RESULTS
            "failed", "timed_out", "authentication_needed" -> SourceHealth.FAILED
            else -> SourceHealth.UNKNOWN
        }

    fun clear() {
        _entries.value = emptyList()
    }
}
