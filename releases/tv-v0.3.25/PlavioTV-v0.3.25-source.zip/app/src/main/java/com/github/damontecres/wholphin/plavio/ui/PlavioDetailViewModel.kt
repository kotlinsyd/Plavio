package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.MetaDetail
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.RelatedSection
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import com.github.damontecres.wholphin.plavio.pickBestStream
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioDetailUiState {
    data object Loading : PlavioDetailUiState

    data class Loaded(
        val meta: MetaDetail,
        val related: List<RelatedSection> = emptyList(),
    ) : PlavioDetailUiState

    data object Unavailable : PlavioDetailUiState
}

/**
 * Watch Now outcome (v0.3.16, note 9 — Instant Play): a press is
 * Ready IMMEDIATELY with an unresolved request; the player finds the
 * streams inside itself and falls back to the sources picker when
 * nothing playable answers. The old Resolving ("Finding…" button)
 * and NoStreams states are gone — the press never waits here.
 */
sealed interface WatchNowState {
    data object Idle : WatchNowState

    data class Ready(
        val request: PlaybackRequest,
    ) : WatchNowState
}

/**
 * The Detail page's in-place Sources popup (v0.3.22): closed, or
 * open over the page with the target's streams filling in
 * progressively (the same bundle the Streams screen would show).
 */
sealed interface DetailSourcesState {
    data object Closed : DetailSourcesState

    data class Open(
        val ref: StreamsRef,
        val streams: List<com.github.damontecres.wholphin.plavio.StreamItem>,
        /** True while more addons are still answering. */
        val loading: Boolean,
    ) : DetailSourcesState
}

/**
 * Franchise/collection split (v0.3.26 batch 5): a related section IS
 * a collection section when the serving addon says so in its id
 * ("collection…", "franchise…") — PlavioMeta's /related serves only
 * "similar" and "cast-*" sections today, so with the current server
 * data this finds nothing and the page renders exactly as before;
 * any addon that serves a collection section gets its row promoted
 * to the front of the related block, in the order the meta served,
 * with the open title itself removed. Nothing is ever derived from
 * title matching — no data, no row.
 */
fun splitFranchiseSections(
    related: List<RelatedSection>,
    selfId: String,
): List<RelatedSection> {
    fun RelatedSection.isCollection(): Boolean {
        val id = this.id.lowercase()
        return id.startsWith("collection") || id.startsWith("franchise")
    }
    val (collections, rest) = related.partition { it.isCollection() }
    if (collections.isEmpty()) return related
    val promoted =
        collections.map { section ->
            section.copy(metas = section.metas.filter { it.id != selfId })
        }.filter { it.metas.isNotEmpty() }
    return promoted + rest
}

@HiltViewModel
class PlavioDetailViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val uiPrefs: PlavioUiPrefs,
        private val watchlistStore: com.github.damontecres.wholphin.plavio.PlavioWatchlistStore,
        private val progressStore: com.github.damontecres.wholphin.plavio.PlavioProgressStore,
        private val watchedStore: com.github.damontecres.wholphin.plavio.PlavioWatchedStore,
        private val downloadManager: com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager,
        private val customListsStore: com.github.damontecres.wholphin.plavio.PlavioCustomListsStore,
        private val addonStore: com.github.damontecres.wholphin.plavio.AddonStore,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioDetailUiState>(PlavioDetailUiState.Loading)
        val state: StateFlow<PlavioDetailUiState> = _state

        /** + My List membership keys (the store's own flow). */
        val myListKeys: StateFlow<Set<String>> = watchlistStore.keys

        /** Episode watch progress for the open title: videoId → fraction (v0.3.21). */
        private val _episodeProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
        val episodeProgress: StateFlow<Map<String, Float>> = _episodeProgress

        /** Watched keys ("type|videoId") from the watched store (v0.3.26). */
        val watchedKeys: StateFlow<Set<String>> = watchedStore.keys

        /** The raw Continue Watching entries — the page filters by meta id. */
        val progressEntries: StateFlow<List<com.github.damontecres.wholphin.plavio.ContinueWatchingEntry>> =
            progressStore.entries

        @Volatile
        private var loadedMetaId: String? = null

        /** The addon base URL this page was opened from (custom-list item keys). */
        @Volatile
        private var loadedBaseUrl: String = ""

        // ---- v0.3.26 batch 5: download season + custom lists ----

        /** Transient feedback line for the Download season button. */
        private val _seasonNotice = MutableStateFlow<String?>(null)
        val seasonNotice: StateFlow<String?> = _seasonNotice

        fun consumeSeasonNotice() {
            _seasonNotice.value = null
        }

        /** Custom lists + their items (the synced store — see PlavioCustomListsStore). */
        val customLists: StateFlow<List<com.github.damontecres.wholphin.plavio.PlavioCustomList>> =
            customListsStore.lists
        val customListItems: StateFlow<List<com.github.damontecres.wholphin.plavio.PlavioCustomListItem>> =
            customListsStore.items

        /**
         * Download season (v0.3.26 batch 5): every episode of
         * [season] queues through the one download engine, resolved
         * exactly the way a single-episode download is — the
         * autoplay pick (the user's quality rules) over the
         * episode's own streams, DASH refused, an episode that
         * already has a download entry in any state skipped. The
         * manager's Wi-Fi-only gate applies inside enqueue/start,
         * so off Wi-Fi the season simply waits in the queue.
         * Episodes resolve one at a time — a season is a background
         * courtesy, not a burst.
         */
        fun downloadSeason(
            meta: MetaDetail,
            season: Int,
        ) {
            val episodes =
                meta.videos
                    .filter { it.season == season }
                    .sortedBy { it.episode }
            if (episodes.isEmpty()) return
            _seasonNotice.value = "Finding streams for season $season…"
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                var queued = 0
                for (episode in episodes) {
                    if (downloadManager.entries.value.any { it.videoId == episode.id }) {
                        continue
                    }
                    val bundle =
                        runCatching {
                            repository.loadStreams("series", episode.id, meta.id)
                        }.getOrNull() ?: continue
                    // Batch 6: a season download starts without an
                    // explicit pick, so the Downloads screen's
                    // default-quality preference steers it.
                    val pick =
                        runCatching { repository.pickForDownload(bundle.streams) }
                            .getOrNull() ?: continue
                    if (downloadManager.isDashUrl(pick.url)) continue
                    downloadManager.enqueue(
                        url = pick.url,
                        title = "${meta.name} — ${episode.title}",
                        poster = episode.thumbnail ?: meta.poster,
                        type = "series",
                        videoId = episode.id,
                        metaId = meta.id,
                        season = episode.season,
                        episode = episode.episode,
                        seriesName = meta.name,
                        episodeTitle = episode.title,
                        sourceName = pick.sourceName,
                        headers = pick.headers,
                        mimeType = pick.mimeType,
                    )
                    queued++
                }
                _seasonNotice.value =
                    when {
                        queued > 0 ->
                            "Queued $queued episode${if (queued == 1) "" else "s"} — find them in Downloads."
                        else ->
                            "Nothing new to queue — this season is already in Downloads."
                    }
            }
        }

        /** Add/remove this title to/from a custom list (membership by title, the phone's rule). */
        fun toggleCustomListMembership(
            meta: MetaDetail,
            listId: String,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val member =
                    listId in
                        com.github.damontecres.wholphin.plavio.PlavioCustomLists.listsContaining(
                            customListsStore.items.value,
                            meta.type,
                            meta.id,
                        )
                if (member) {
                    customListsStore.removeItemByMeta(listId, meta.type, meta.id)
                } else {
                    val addonId =
                        addonStore.addons.value
                            .firstOrNull { it.baseUrl == loadedBaseUrl }
                            ?.id ?: ""
                    customListsStore.addItem(
                        listId = listId,
                        addonId = addonId,
                        type = meta.type,
                        metaId = meta.id,
                        name = meta.name,
                        poster = meta.poster,
                    )
                }
            }
        }

        fun createCustomList(name: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching { customListsStore.createList(name) }
            }
        }

        fun renameCustomList(
            id: String,
            name: String,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching { customListsStore.renameList(id, name) }
            }
        }

        fun deleteCustomList(id: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching { customListsStore.deleteList(id) }
            }
        }

        init {
            // Live progress: the page re-renders its episode lines
            // and action row as progress changes under it (a mark,
            // a removal, a finished episode) instead of holding the
            // snapshot taken at load (v0.3.26).
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                progressStore.entries.collect { entries ->
                    val metaId = loadedMetaId ?: return@collect
                    _episodeProgress.value =
                        entries
                            .filter { it.metaId == metaId }
                            .associate { it.videoId to it.progressFraction }
                }
            }
        }

        fun toggleMyList(meta: MetaDetail) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                watchlistStore.toggle(
                    com.github.damontecres.wholphin.plavio.WatchlistEntry(
                        type = meta.type,
                        metaId = meta.id,
                        name = meta.name,
                        poster = meta.poster,
                    ),
                )
            }
        }

        private val _watchNow = MutableStateFlow<WatchNowState>(WatchNowState.Idle)
        val watchNow: StateFlow<WatchNowState> = _watchNow

        private val _sources = MutableStateFlow<DetailSourcesState>(DetailSourcesState.Closed)
        val sources: StateFlow<DetailSourcesState> = _sources

        /** The full bundle behind the open Sources popup (a pick
         * builds its PlaybackRequest from it, like Watch Now does). */
        private var sourcesBundle: com.github.damontecres.wholphin.plavio.StreamBundle? = null
        private var sourcesJob: kotlinx.coroutines.Job? = null

        /** True when Watch Now should auto-play the best stream (phone parity setting). */
        val autoplayBestStream: StateFlow<Boolean> = uiPrefs.autoplayBestStream

        /** Spoiler blur for unwatched episode pictures (Playback setting; batch 6). */
        val blurUnwatchedEpisodes: StateFlow<Boolean> = uiPrefs.blurUnwatchedEpisodes

        private var loadedKey: String? = null

        fun load(
            baseUrl: String,
            type: String,
            id: String,
        ) {
            val key = "$baseUrl|$type|$id"
            if (key == loadedKey) return
            loadedKey = key
            loadedBaseUrl = baseUrl
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                _state.value = PlavioDetailUiState.Loading
                val meta = repository.loadMeta(baseUrl, type, id)
                if (meta == null) {
                    _state.value = PlavioDetailUiState.Unavailable
                    return@launch
                }
                // v0.3.16 (note 8, owner's explicit order): the page
                // reveals WHOLE. Related rows are fetched BEFORE the
                // first Loaded emission, so the skeleton layer stays
                // up until the page is complete and the finished page
                // appears at once — the targeted waiver of progressive
                // loading for this surface. (Cast photos still enrich
                // in place afterwards: they are images inside cards
                // that already stand, not page structure.)
                val related =
                    runCatching { repository.getRelated(meta.type, meta.id, baseUrl) }
                        .getOrDefault(emptyList())
                _state.value = PlavioDetailUiState.Loaded(meta, related)
                loadedMetaId = meta.id
                // PrePlay (batch 6): warm the stream pocket for
                // the title Watch Now will most likely play, so
                // the press starts instantly. Fire-and-forget —
                // the repository no-ops when the switch is off.
                maybePreResolve(meta)
                _episodeProgress.value =
                    progressStore.entries.value
                        .filter { it.metaId == meta.id }
                        .associate { it.videoId to it.progressFraction }
                enrichCastPhotos(meta)
            }
        }

        /**
         * PrePlay trigger (batch 6): a movie pre-resolves itself; a
         * series pre-resolves the episode Watch Now would target —
         * the most recently touched in-progress episode when one
         * exists, else the first episode in season order.
         */
        private fun maybePreResolve(meta: MetaDetail) {
            if (!uiPrefs.prePlayEnabled.value) return
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching {
                    when (meta.type) {
                        "movie" -> repository.preResolve(meta.type, meta.id, meta.id)
                        "series" -> {
                            val continuing =
                                progressStore.entries.value
                                    .filter { it.metaId == meta.id }
                                    .maxByOrNull { it.updatedAt }
                            val targetId =
                                continuing?.videoId
                                    ?: meta.videos
                                        .filter { it.season >= 0 }
                                        .minWithOrNull(
                                            compareBy({ it.season }, { it.episode }),
                                        )?.id
                            if (targetId != null) {
                                repository.preResolve(meta.type, targetId, meta.id)
                            }
                        }
                    }
                }
            }
        }

        /** The streams reference for a title (series target = the given episode). */
        private fun streamsRefFor(
            meta: MetaDetail,
            target: Video?,
        ): StreamsRef =
            if (meta.type == "series" && target != null) {
                StreamsRef(
                    type = meta.type,
                    videoId = target.id,
                    metaId = meta.id,
                    title = meta.name,
                    poster = target.thumbnail ?: meta.poster,
                    backdrop = meta.background,
                    season = target.season,
                    episode = target.episode,
                    episodeTitle = target.title,
                    seriesName = meta.name,
                    logo = meta.logo,
                    releaseInfo = meta.releaseInfo,
                    runtime = meta.runtime,
                    genres = meta.genres,
                    imdbRating = meta.imdbRating,
                    castNames = meta.cast.map { it.name },
                )
            } else {
                StreamsRef(
                    type = meta.type,
                    videoId = meta.id,
                    metaId = meta.id,
                    title = meta.name,
                    poster = meta.poster,
                    backdrop = meta.background,
                    logo = meta.logo,
                    releaseInfo = meta.releaseInfo,
                    runtime = meta.runtime,
                    genres = meta.genres,
                    imdbRating = meta.imdbRating,
                    castNames = meta.cast.map { it.name },
                )
            }

        /**
         * Watch Now (v0.3.16, note 9 — Instant Play): NO resolution
         * here. The press builds the unresolved request from the
         * already-loaded meta and is Ready on the same frame, so the
         * player opens at once and finds the streams inside itself
         * (the behaviour the owner asked back: "keep loading there
         * as you before doing"). For a series the target is the
         * episode asked for. When the player finds nothing playable
         * it swaps itself for the sources picker — the old NoStreams
         * fallback, one room over.
         */
        fun watchNow(
            meta: MetaDetail,
            target: Video?,
        ) {
            val ref = streamsRefFor(meta, target)
            _watchNow.value =
                WatchNowState.Ready(
                    com.github.damontecres.wholphin.plavio.buildPendingPlaybackRequest(
                        ref,
                        meta.videos,
                    ),
                )
        }

        fun consumeWatchNow() {
            _watchNow.value = WatchNowState.Idle
        }

        // ---- v0.3.26: watching management ----

        /**
         * Play from beginning: the title's saved progress goes first
         * (so nothing downstream can resurrect a resume point), then
         * the same fresh request Watch Now builds — the destination
         * carries resume 0, so no resume prompt appears.
         */
        fun playFromBeginning(
            meta: MetaDetail,
            target: Video?,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                removeTitleProgress(meta)
            }
            watchNow(meta, target)
        }

        /** Remove from Continue Watching: every entry of this title goes. */
        fun removeFromContinueWatching(meta: MetaDetail) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                removeTitleProgress(meta)
            }
        }

        private suspend fun removeTitleProgress(meta: MetaDetail) {
            progressStore.entries.value
                .filter { it.metaId == meta.id }
                .forEach { runCatching { progressStore.remove(it.type, it.videoId) } }
        }

        /** Mark/unmark a movie watched; marking also clears its CW entry. */
        fun setMovieWatched(
            meta: MetaDetail,
            watched: Boolean,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                watchedStore.setWatched(meta.type, meta.id, watched)
                if (watched) {
                    runCatching { progressStore.remove(meta.type, meta.id) }
                }
            }
        }

        /** Mark/unmark one episode watched; marking clears its progress too. */
        fun setEpisodeWatched(
            meta: MetaDetail,
            video: Video,
            watched: Boolean,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                watchedStore.setWatched(meta.type, video.id, watched)
                if (watched) {
                    runCatching { progressStore.remove(meta.type, video.id) }
                }
            }
        }

        /**
         * Mark/unmark a RANGE of episodes (v0.3.33, the episode
         * watched menu's "up to here" / "whole season" rows): the
         * same write as [setEpisodeWatched], once per episode —
         * marking clears each episode's saved progress too, so a
         * bulk mark empties those episodes out of Continue
         * Watching exactly like the single mark did. The caller
         * passes the exact set EpisodeWatchedMenu computed (aired
         * only), which is also the set the menu's label counted.
         */
        fun setEpisodesWatched(
            meta: MetaDetail,
            videos: List<Video>,
            watched: Boolean,
        ) {
            if (videos.isEmpty()) return
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                videos.forEach { video ->
                    watchedStore.setWatched(meta.type, video.id, watched)
                    if (watched) {
                        runCatching { progressStore.remove(meta.type, video.id) }
                    }
                }
            }
        }

        /**
         * Sources popup (v0.3.22): opens over the Detail page with
         * the same target Watch Now uses (the movie itself, or the
         * first episode for a series). Streams fill progressively —
         * each addon's answer renders as it lands.
         */
        fun openSources(
            meta: MetaDetail,
            target: Video?,
        ) {
            val ref = streamsRefFor(meta, target)
            sourcesJob?.cancel()
            sourcesBundle = null
            _sources.value = DetailSourcesState.Open(ref, emptyList(), loading = true)
            sourcesJob =
                viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                    val bundle =
                        runCatching {
                            repository.loadStreamsProgressive(ref.type, ref.videoId, ref.metaId) { partial ->
                                val open = _sources.value
                                if (open is DetailSourcesState.Open && open.ref == ref) {
                                    _sources.value =
                                        open.copy(streams = partial.streams, loading = true)
                                }
                            }
                        }.getOrNull()
                    val open = _sources.value
                    if (open is DetailSourcesState.Open && open.ref == ref) {
                        sourcesBundle = bundle
                        _sources.value =
                            open.copy(streams = bundle?.streams ?: open.streams, loading = false)
                    }
                }
        }

        /** Reload behind the popup's empty state: same target, fresh answers. */
        fun reloadSources(
            meta: MetaDetail,
            target: Video?,
        ) = openSources(meta, target)

        fun closeSources() {
            sourcesJob?.cancel()
            sourcesJob = null
            _sources.value = DetailSourcesState.Closed
        }

        /** A popup pick: build the PlaybackRequest exactly like a
         * Streams-screen pick (full bundle rides along for failover). */
        fun pickSource(
            meta: MetaDetail,
            stream: com.github.damontecres.wholphin.plavio.StreamItem,
        ): PlaybackRequest? {
            val open = _sources.value as? DetailSourcesState.Open ?: return null
            val bundle = sourcesBundle ?: return null
            return buildPlaybackRequest(open.ref, bundle, stream, meta.videos)
        }

        /**
         * Cast photos (v0.3.13): the meta's cast arrives as names +
         * TMDB ids with no photos (PMeta serves them that way — the
         * photo lives on the addon's /person/<id> route). Resolve them
         * in parallel AFTER the page is up and swap them into the cast
         * row as they land; a member whose photo never resolves keeps
         * the initial-letter chip.
         */
        private fun enrichCastPhotos(meta: MetaDetail) {
            val missing = meta.cast.filter { it.photo.isNullOrBlank() && it.id > 0 }
            if (missing.isEmpty()) return
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val photos = mutableMapOf<Int, String>()
                coroutineScope {
                    val deferreds =
                        ArrayList<Deferred<Pair<Int, String?>>>(missing.size)
                    for (member in missing) {
                        deferreds +=
                            async {
                                member.id to
                                    runCatching { repository.fetchPersonPhoto(member.id) }.getOrNull()
                            }
                    }
                    for (deferred in deferreds) {
                        val (id, photo) = deferred.await()
                        if (photo != null) photos[id] = photo
                    }
                }
                if (photos.isEmpty()) return@launch
                val current = _state.value
                if (current is PlavioDetailUiState.Loaded && current.meta.id == meta.id) {
                    _state.value =
                        current.copy(
                            meta =
                                current.meta.copy(
                                    cast =
                                        current.meta.cast.map { member ->
                                            photos[member.id]?.let { member.copy(photo = it) }
                                                ?: member
                                        },
                                ),
                        )
                }
            }
        }
    }
