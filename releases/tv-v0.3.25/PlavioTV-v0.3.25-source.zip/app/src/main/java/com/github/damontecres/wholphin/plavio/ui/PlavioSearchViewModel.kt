package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.CachedMeta
import com.github.damontecres.wholphin.plavio.CastMember
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioSearchUiState {
    /** Nothing searched yet. */
    data object Idle : PlavioSearchUiState

    data object Searching : PlavioSearchUiState

    data class Results(
        val items: List<CachedMeta>,
        /** People matching the query (search by actor) — empty when none matched. */
        val people: List<CastMember> = emptyList(),
    ) : PlavioSearchUiState

    data class NoResults(
        val query: String,
    ) : PlavioSearchUiState

    /** No enabled addon's catalog supports the search extra. */
    data object NoSearchAddons : PlavioSearchUiState
}

@HiltViewModel
class PlavioSearchViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val uiPrefs: com.github.damontecres.wholphin.plavio.PlavioUiPrefs,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioSearchUiState>(PlavioSearchUiState.Idle)
        val state: StateFlow<PlavioSearchUiState> = _state

        /** Recent searches (v0.3.26): newest first, capped at 10. */
        val recentSearches: StateFlow<List<String>> = uiPrefs.recentSearches

        fun clearRecentSearches() {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setRecentSearches(emptyList())
            }
        }

        /** Remembers a settled search (v0.3.26). */
        private suspend fun recordSearch(trimmed: String) {
            runCatching {
                uiPrefs.setRecentSearches(
                    com.github.damontecres.wholphin.plavio.PlavioRecentSearches.add(
                        uiPrefs.recentSearches.value,
                        trimmed,
                    ),
                )
            }
        }

        private var searchJob: Job? = null

        // ── Discover (batch 6): rows for the empty-query state ─────
        private val _discoverRows =
            MutableStateFlow<List<com.github.damontecres.wholphin.plavio.CatalogRow>>(emptyList())
        val discoverRows: StateFlow<List<com.github.damontecres.wholphin.plavio.CatalogRow>> =
            _discoverRows
        private var discoverKicked = false

        /** Loads Discover once per screen instance; rows publish as they settle. */
        fun loadDiscover() {
            if (discoverKicked) return
            discoverKicked = true
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching {
                    repository.loadDiscoverRows { rows -> _discoverRows.value = rows }
                }
            }
        }

        // ── Suggestions (v0.3.26): recents + catalog title matches ────────
        private val _suggestions = MutableStateFlow<List<String>>(emptyList())
        val suggestions: StateFlow<List<String>> = _suggestions

        private var suggestJob: Job? = null

        fun suggest(rawQuery: String) {
            val query = rawQuery.trim()
            suggestJob?.cancel()
            if (query.length < 2) {
                _suggestions.value =
                    com.github.damontecres.wholphin.plavio.SearchSuggestions.build(
                        query,
                        uiPrefs.recentSearches.value,
                        emptyList(),
                    )
                return
            }
            suggestJob =
                viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                    kotlinx.coroutines.delay(120)
                    val titles =
                        if (repository.hasSearchCatalogs()) {
                            runCatching { repository.searchCatalogs(query) }
                                .getOrDefault(emptyList())
                                .map { it.meta.name }
                        } else {
                            emptyList()
                        }
                    _suggestions.value =
                        com.github.damontecres.wholphin.plavio.SearchSuggestions.build(
                            query,
                            uiPrefs.recentSearches.value,
                            titles,
                        )
                }
        }

        fun clearSuggestions() {
            suggestJob?.cancel()
            _suggestions.value = emptyList()
        }

        fun search(query: String) {
            val trimmed = query.trim()
            searchJob?.cancel()
            if (trimmed.isEmpty()) {
                _state.value = PlavioSearchUiState.Idle
                return
            }
            searchJob =
                viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                    _state.value = PlavioSearchUiState.Searching
                    // People run alongside titles: the /person-search
                    // route on the meta addons (cast-scan fallback behind
                    // it) — a name can find the actor even when no title
                    // matches.
                    val people =
                        runCatching { repository.searchPeople(trimmed) }
                            .getOrDefault(emptyList())
                    if (!repository.hasSearchCatalogs()) {
                        _state.value =
                            if (people.isEmpty()) {
                                PlavioSearchUiState.NoSearchAddons
                            } else {
                                PlavioSearchUiState.Results(emptyList(), people)
                            }
                        recordSearch(trimmed)
                        return@launch
                    }
                    val results = repository.searchCatalogs(trimmed)
                    _state.value =
                        if (results.isEmpty() && people.isEmpty()) {
                            PlavioSearchUiState.NoResults(trimmed)
                        } else {
                            PlavioSearchUiState.Results(results, people)
                        }
                    // The search settled — remember it (v0.3.26).
                    // Recorded on settle only, so half-typed
                    // queries never land in the list.
                    recordSearch(trimmed)
                }
        }
    }
