package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.PersonDetail
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioActorUiState {
    data object Loading : PlavioActorUiState

    data class Loaded(
        val person: PersonDetail,
    ) : PlavioActorUiState

    data object Unavailable : PlavioActorUiState
}

@HiltViewModel
class PlavioActorViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val followedActorsStore: com.github.damontecres.wholphin.plavio.PlavioFollowedActorsStore,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioActorUiState>(PlavioActorUiState.Loading)
        val state: StateFlow<PlavioActorUiState> = _state

        /** Followed actors (batch 5, mobile parity) — the toggle reads this. */
        val followedActors: StateFlow<List<com.github.damontecres.wholphin.plavio.FollowedActor>> =
            followedActorsStore.actors

        /**
         * Follow/unfollow this person (batch 5): following captures
         * the filmography baseline from the page's own loaded
         * person, exactly like the phone — Home's "New from your
         * people" row then only surfaces titles newer than it.
         */
        fun toggleFollow(person: PersonDetail) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val current = followedActorsStore.actors.value
                val next =
                    if (com.github.damontecres.wholphin.plavio.FollowActorsSupport
                            .isFollowed(current, person.id)
                    ) {
                        com.github.damontecres.wholphin.plavio.FollowActorsSupport
                            .unfollow(current, person.id)
                    } else {
                        com.github.damontecres.wholphin.plavio.FollowActorsSupport
                            .follow(current, person, java.time.Year.now().value)
                    }
                followedActorsStore.setActors(next)
            }
        }

        private var loadedKey: String? = null

        fun load(
            personId: Int,
            name: String,
        ) {
            val key = "$personId|$name"
            if (key == loadedKey) return
            loadedKey = key
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                _state.value = PlavioActorUiState.Loading
                val person =
                    runCatching { repository.getPerson(personId, name) }.getOrNull()
                _state.value =
                    if (person != null) {
                        PlavioActorUiState.Loaded(person)
                    } else {
                        PlavioActorUiState.Unavailable
                    }
            }
        }
    }
