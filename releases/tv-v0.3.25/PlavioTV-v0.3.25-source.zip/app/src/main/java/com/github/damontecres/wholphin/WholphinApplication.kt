package com.github.damontecres.wholphin

import android.app.Application
import android.os.Build
import android.os.StrictMode
import android.util.Log
import androidx.compose.runtime.Composer
import androidx.compose.runtime.ExperimentalComposeRuntimeApi
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.github.damontecres.wholphin.plavio.CrashReports
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject
import kotlinx.coroutines.launch

@OptIn(ExperimentalComposeRuntimeApi::class)
@HiltAndroidApp
class WholphinApplication :
    Application(),
    Configuration.Provider {
    init {
        instance = this

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        } else {
            Timber.plant(
                object : Timber.Tree() {
                    override fun isLoggable(
                        tag: String?,
                        priority: Int,
                    ): Boolean = priority >= Log.INFO

                    override fun log(
                        priority: Int,
                        tag: String?,
                        message: String,
                        t: Throwable?,
                    ) {
                        Log.println(priority, tag ?: "Wholphin", message)
                    }
                },
            )
        }

        Composer.setDiagnosticStackTraceEnabled(BuildConfig.DEBUG)
    }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy
                    .Builder()
                    .detectNetwork()
                    .penaltyLog()
                    .penaltyDeathOnNetwork()
                    .build(),
            )
//            StrictMode.setVmPolicy(
//                StrictMode.VmPolicy
//                    .Builder()
//                    .detectAll()
//                    .penaltyLog()
//                    .build(),
//            )
        }
        // Sentry is the single crash path (ACRA's dialog promised a
        // SEND with no destination and was removed in v0.2.1). Manual,
        // guarded init; a no-op when the user opted out or no DSN was
        // injected at build time.
        CrashReports.initIfEnabled(this)
        CrashReports.putCustomData("SDK_INT", Build.VERSION.SDK_INT.toString())
        // v0.3.25 (PLAVIO-1X/1Z/1R): WorkManager keeps its state in a
        // SQLite database that it opens lazily, inside its own
        // framework entry points, where an open failure escapes as a
        // fatal IllegalStateException with no app frame able to
        // catch it (1Z: SQLITE_CANTOPEN, Android 9; 1X: SQLITE_FULL
        // on a full disk, BRAVIA; 1R: a SQLite transaction failure
        // surfacing in MainActivity — this app ships no other SQLite
        // database). Probe the file HERE, before anything in this
        // process can touch WorkManager: a database that cannot be
        // opened is deleted (with its journals) so WorkManager
        // recreates a clean one on first use — the only state lost
        // is pending episode-check scheduling, which the launch
        // below re-arms. A full disk is NOT repaired this way (the
        // probe leaves the file alone on SQLiteFullException); the
        // graceful half of that case lives in the stores' guarded
        // writes (PlavioProgressStore / PlavioDownloads).
        repairWorkManagerDatabaseIfDamaged()
        // v0.2.2 parity batch: reduced-motion preference + the
        // episode alert store load synchronously; the periodic check
        // is (re)scheduled once the saved toggle value lands.
        com.github.damontecres.wholphin.plavio.MotionPreferences.initialize(this)
        com.github.damontecres.wholphin.plavio.EpisodeAlertStore.initialize(this)
        // v0.3.23 (PLAVIO-1A/1B): this startup read used to run in a
        // bare scope — a plain Job, no supervisor, no exception
        // handler — so ANY exception escaping it (a DataStore read
        // failure, or a cancellation thrown across the read) reached
        // the thread's uncaught handler as a fatal crash. It now
        // runs under the shared background-scope policy: supervisor
        // + CrashReports.backgroundScopeHandler.
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() +
                kotlinx.coroutines.Dispatchers.IO +
                com.github.damontecres.wholphin.plavio.CrashReports.backgroundScopeHandler,
        ).launch {
            com.github.damontecres.wholphin.plavio.EpisodeAlerts
                .ensureScheduled(this@WholphinApplication, uiPrefs.episodeAlertsEnabledOnce())
            // v0.3.26: arm the app-open auto-backup pass (phone
            // parity) with the saved toggle value; the worker
            // re-checks the toggle and the sign-in before uploading.
            com.github.damontecres.wholphin.plavio.cloud.PlavioAutoBackup
                .ensureScheduled(this@WholphinApplication, uiPrefs.autoBackupEnabledOnce())
        }
        // v0.3.26: the shared remote app config (announcements) —
        // loads the last-good copy, then refreshes in the
        // background. Silent when there is nothing to show.
        com.github.damontecres.wholphin.plavio.PlavioAppConfig.start(this)
    }

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    @Inject
    lateinit var uiPrefs: com.github.damontecres.wholphin.plavio.PlavioUiPrefs

    override val workManagerConfiguration: Configuration
        get() =
            Configuration
                .Builder()
                .setWorkerFactory(workerFactory)
                .build()

    /**
     * v0.3.25: see the call site in [onCreate]. Opens the WorkManager
     * database read-write (so WAL recovery runs exactly as it would
     * for WorkManager itself) and runs the integrity check. Only an
     * open/integrity failure deletes the file — a full-disk failure
     * ([android.database.sqlite.SQLiteFullException]) leaves it in
     * place, because deleting cannot make room and the recreated
     * database would fail the same way.
     */
    private fun repairWorkManagerDatabaseIfDamaged() {
        runCatching {
            val dbFile = getDatabasePath(WORK_DATABASE_NAME)
            if (!dbFile.exists()) return
            val failure =
                runCatching {
                    android.database.sqlite.SQLiteDatabase
                        .openDatabase(
                            dbFile.path,
                            null,
                            android.database.sqlite.SQLiteDatabase.OPEN_READWRITE,
                        ).use { db ->
                            check(db.isDatabaseIntegrityOk) { "integrity check failed" }
                        }
                    null
                }.exceptionOrNull()
            when {
                failure == null -> Unit
                failure is android.database.sqlite.SQLiteFullException ->
                    Timber.w(failure, "WorkManager database cannot write (disk full); leaving it in place")
                else -> {
                    Timber.w(failure, "WorkManager database failed its health probe; resetting it")
                    listOf("", "-wal", "-shm", "-journal").forEach { suffix ->
                        runCatching { java.io.File(dbFile.path + suffix).delete() }
                    }
                }
            }
        }
    }

    companion object {
        /** WorkManager's own database file name (androidx.work). */
        private const val WORK_DATABASE_NAME = "androidx.work.workdb"

        lateinit var instance: WholphinApplication
            private set
    }
}
