package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.MetaPreview
import androidx.compose.runtime.setValue

/**
 * Actor page: photo + name, then the filmography rows (Movies /
 * Series) from whichever meta addon serves /person — with the generic
 * search-based fallback behind it, exactly like the phone.
 */
@Composable
fun PlavioActorScreen(
    destination: PlavioDestination.Actor,
    onItemClick: (MetaPreview) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioActorViewModel =
        hiltViewModel(key = "actor|${destination.personId}|${destination.name}"),
) {
    LaunchedEffect(destination) {
        viewModel.load(destination.personId, destination.name)
    }
    val state by viewModel.state.collectAsState()
    val followedActors by viewModel.followedActors.collectAsState()

    // Entry focus (v0.3.11): this screen owned no requester — it
    // opened with nothing focused. The first card of the first
    // filmography row is home, requested once the page has loaded.
    val entryFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var actorClaimed by remember { mutableStateOf(false) }
    val loaded = state as? PlavioActorUiState.Loaded
    LaunchedEffect(loaded?.person?.id) {
        if (loaded != null) {
            // v0.3.14: shared primitive + screen claim (was a blind burst).
            landFocus(entryFocus, isClaimed = { actorClaimed }, attempts = 8, delayMs = 150)
        }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) actorClaimed = true },
    ) {
        when (val st = state) {
            PlavioActorUiState.Loading -> {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    OrbitLoader(modifier = Modifier.size(64.dp))
                    Text(
                        text = stringResource(R.string.plavio_detail_loading),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            PlavioActorUiState.Unavailable -> {
                Text(
                    text = stringResource(R.string.plavio_actor_unavailable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            is PlavioActorUiState.Loaded -> {
                val person = st.person
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                ) {
                    item {
                        Row(
                            modifier = Modifier.padding(end = 48.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(24.dp),
                        ) {
                            Box(
                                modifier =
                                    Modifier
                                        .size(120.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (person.photo != null) {
                                    AsyncImage(
                                        model =
                                            ImageRequest
                                                .Builder(LocalContext.current)
                                                .data(person.photo)
                                                .size(240, 240)
                                                .crossfade(false)
                                                .build(),
                                        contentDescription = person.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize(),
                                    )
                                } else {
                                    Text(
                                        text = person.name.take(1),
                                        style = MaterialTheme.typography.displayMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(
                                    text = person.name,
                                    style = MaterialTheme.typography.displaySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                )
                                // Follow (batch 5, mobile parity):
                                // following captures the baseline
                                // from this filmography; Home's "New
                                // from your people" row surfaces what
                                // arrives after it. Only for real
                                // person ids — the search-fallback
                                // person (id 0) has no stable identity
                                // to follow.
                                if (person.id > 0) {
                                    val following =
                                        com.github.damontecres.wholphin.plavio
                                            .FollowActorsSupport
                                            .isFollowed(followedActors, person.id)
                                    PlavioFixedButton(
                                        text =
                                            stringResource(
                                                if (following) {
                                                    R.string.plavio_actor_following
                                                } else {
                                                    R.string.plavio_actor_follow
                                                },
                                            ),
                                        onClick = { viewModel.toggleFollow(person) },
                                        whiteFocus = true,
                                        kind =
                                            if (following) {
                                                PlavioButtonKind.Outline
                                            } else {
                                                PlavioButtonKind.Primary
                                            },
                                        modifier = Modifier.width(190.dp),
                                    )
                                }
                            }
                        }
                    }
                    if (person.movies.isNotEmpty()) {
                        item {
                            FilmographyRow(
                                title = stringResource(R.string.plavio_actor_movies),
                                items = person.movies,
                                onItemClick = onItemClick,
                                firstItemFocus = entryFocus,
                            )
                        }
                    }
                    if (person.series.isNotEmpty()) {
                        item {
                            FilmographyRow(
                                title = stringResource(R.string.plavio_actor_series),
                                items = person.series,
                                onItemClick = onItemClick,
                                firstItemFocus =
                                    if (person.movies.isEmpty()) entryFocus else null,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilmographyRow(
    title: String,
    items: List<MetaPreview>,
    onItemClick: (MetaPreview) -> Unit,
    firstItemFocus: androidx.compose.ui.focus.FocusRequester? = null,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(end = 48.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(end = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            itemsIndexed(items, key = { index, item -> "${item.type}|${item.id}|$index" }) { index, item ->
                SharedPosterCard(
                    item = item,
                    onClick = { onItemClick(item) },
                    modifier =
                        if (index == 0 && firstItemFocus != null) {
                            Modifier.focusRequester(firstItemFocus)
                        } else {
                            Modifier
                        },
                )
            }
        }
    }
}
