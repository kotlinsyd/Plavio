package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.CrashReports
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.download.DownloadEntry
import com.github.damontecres.wholphin.plavio.download.DownloadStatus
import com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class PlavioDownloadsViewModel
    @Inject
    constructor(
        private val downloadManager: PlavioDownloadManager,
        private val uiPrefs: PlavioUiPrefs,
    ) : ViewModel() {
        val entries: StateFlow<List<DownloadEntry>> = downloadManager.entries

        /** Auto-download next episode switch (this screen is its only home; phone parity). */
        val autoDownloadNextEpisode: StateFlow<Boolean> = uiPrefs.autoDownloadNextEpisode

        fun setAutoDownloadNextEpisode(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setAutoDownloadNextEpisode(enabled)
            }
        }

        // ---- Wi-Fi-only downloads (v0.3.26) ----
        // The switch lives here (this screen is its home); the
        // gate itself is wired app-wide by the root view model,
        // because downloads enqueue from the player and streams
        // screens too, where this VM does not exist.

        val wifiOnlyDownloads: StateFlow<Boolean> = uiPrefs.wifiOnlyDownloads

        fun setWifiOnlyDownloads(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setWifiOnlyDownloads(enabled)
                // Turning it off opens the gate: queued entries go.
                if (!enabled) downloadManager.recheckQueued()
            }
        }

        // ---- Download defaults (batch 6) ----
        // Both rows live on the Downloads screen beside the other
        // download switches. The quality steers only downloads that
        // start without an explicit pick (season / next episode);
        // the storage choice steers where NEW downloads land.

        val downloadQuality: StateFlow<String> = uiPrefs.downloadQuality

        /** The quality cycle: "Auto" first, then the canonical buckets. */
        val downloadQualityOptions: List<String> =
            listOf("Auto") + com.github.damontecres.wholphin.plavio.QUALITY_ORDER_OPTIONS

        fun cycleDownloadQuality() {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val options = downloadQualityOptions
                val next =
                    options[(options.indexOf(uiPrefs.downloadQuality.value) + 1) % options.size]
                uiPrefs.setDownloadQuality(next)
            }
        }

        val downloadStorageIndex: StateFlow<Int> = uiPrefs.downloadStorageIndex

        /** Labels for the storage roots, in root order; empty/single = the row hides. */
        val storageRootLabels: List<String> =
            downloadManager.storageRoots().map { downloadManager.storageRootLabel(it) }

        fun cycleDownloadStorage() {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val count = downloadManager.storageRoots().size
                if (count > 1) {
                    uiPrefs.setDownloadStorageIndex(
                        (uiPrefs.downloadStorageIndex.value + 1) % count,
                    )
                }
            }
        }

        /** The directory new downloads land in (the summary's free-space probe). */
        fun downloadsDir(): File = downloadManager.downloadsDir()

        fun pause(id: String) = downloadManager.pause(id)

        fun resume(id: String) = downloadManager.resume(id)

        fun delete(id: String) = downloadManager.delete(id)

        /** The offline playback request for a finished download, or null if the file is gone. */
        fun playRequest(entry: DownloadEntry): PlaybackRequest? {
            if (entry.status != DownloadStatus.COMPLETED) return null
            val file = File(entry.filePath)
            if (!file.exists() || file.length() == 0L) return null
            return PlaybackRequest(
                streamUrl = "file://${entry.filePath}",
                title = entry.title,
                poster = entry.poster,
                videoId = entry.videoId,
                season = entry.season,
                episode = entry.episode,
                isMovie = entry.type == "movie",
                type = entry.type,
                streamLabel = "Download",
                sourceName = entry.sourceName,
                metaId = entry.metaId,
                seriesName = entry.seriesName,
                episodeTitle = entry.episodeTitle,
            )
        }
    }
