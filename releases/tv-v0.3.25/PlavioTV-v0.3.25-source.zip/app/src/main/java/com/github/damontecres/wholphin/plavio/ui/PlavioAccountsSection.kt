package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.ui.components.Button

/** The account panels' shared status lines: result message, error, busy. */
@Composable
private fun AccountStatusLines(
    state: PlavioAccountUiState,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        state.message?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = LocalPlavioAccent.current.primary,
            )
        }
        state.error?.let { error ->
            Text(
                text = error,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.error,
            )
        }
        if (state.busy) {
            Text(
                text = stringResource(R.string.plavio_account_working),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * The Email panel's content (v0.3.26 split): ONLY the Plavio account
 * form — sign in / create account / forgot password / reset code —
 * plus the signed-in header. Sync actions live in the Sync panel
 * ([PlavioSyncBlock]) and the change-password form in the Password
 * panel; before the split all three panels rendered this one shared
 * block, so every door opened the same full control set. The Plavio
 * account is the only door (the Google Drive door was removed in
 * v0.3.26 on the owner's order — never used). Text is entered with
 * the TV keyboard through [PlavioClickToEditField] — the keyboard
 * opens only on an explicit OK press (v0.3.16).
 */
@Composable
fun PlavioAccountFormBlock(
    modifier: Modifier = Modifier,
    viewModel: PlavioAccountsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    val emailState = rememberTextFieldState()
    val passwordState = rememberTextFieldState()
    val codeState = rememberTextFieldState()
    val newPasswordState = rememberTextFieldState()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ---- Plavio account ----
        Text(
            text = stringResource(R.string.plavio_account_plavio_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (!state.plavioConfigured) {
            Text(
                text = stringResource(R.string.plavio_account_not_configured),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else if (state.plavioEmail == null) {
            Text(
                text = stringResource(R.string.plavio_account_email_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PlavioClickToEditField(
                state = emailState,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next,
                    ),
                emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
            )
            Text(
                text = stringResource(R.string.plavio_account_password_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PlavioClickToEditField(
                state = passwordState,
                modifier = Modifier.fillMaxWidth(),
                isPassword = true,
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_account_sign_in),
                    onClick = {
                        viewModel.plavioSignIn(
                            emailState.text.toString(),
                            passwordState.text.toString(),
                        )
                    },
                    kind = PlavioButtonKind.Primary,
                    enabled = !state.busy,
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_account_create),
                    onClick = {
                        viewModel.plavioSignUp(
                            emailState.text.toString(),
                            passwordState.text.toString(),
                        )
                    },
                    enabled = !state.busy,
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_account_forgot),
                    onClick = { viewModel.plavioForgot(emailState.text.toString()) },
                    enabled = !state.busy,
                )
            }
            if (state.resetRequestedFor != null) {
                Text(
                    text = stringResource(R.string.plavio_account_code_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                PlavioClickToEditField(
                    state = codeState,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions =
                        KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next,
                        ),
                    emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                )
                Text(
                    text = stringResource(R.string.plavio_account_new_password_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                PlavioClickToEditField(
                    state = newPasswordState,
                    modifier = Modifier.fillMaxWidth(),
                    isPassword = true,
                    keyboardOptions =
                        KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done,
                        ),
                    emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_account_set_password),
                    onClick = {
                        viewModel.plavioResetPassword(
                            state.resetRequestedFor ?: emailState.text.toString(),
                            codeState.text.toString(),
                            newPasswordState.text.toString(),
                        )
                    },
                    kind = PlavioButtonKind.Primary,
                    enabled = !state.busy,
                )
            }
        } else {
            Text(
                text =
                    stringResource(R.string.plavio_account_signed_in_as, state.plavioEmail ?: ""),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.plavioLastSync?.let { last ->
                Text(
                    text = stringResource(R.string.plavio_account_last_sync, last),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                text = stringResource(R.string.plavio_account_sync_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        AccountStatusLines(state)
    }
}

/**
 * The Sync & backup panel's content (v0.3.26 split): ONLY the sync
 * actions — Sync now / Restore / Sign out. "Sync addons" is NOT
 * here: it has exactly one home, the Addons screen's own button
 * (v0.3.26 audit fix — it used to live in both).
 *
 * v0.3.34: the Auto backup switch moved OUT of this panel onto
 * the Account page's SYNC section (the approved sample shows it
 * as a page row) — one home only, per the no-doubles rule. The
 * switch binds the same PlavioAccountsViewModel.autoBackup flow.
 */
@Composable
fun PlavioSyncBlock(
    modifier: Modifier = Modifier,
    viewModel: PlavioAccountsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_account_sync_row),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (state.plavioEmail == null) {
            Text(
                text = stringResource(R.string.plavio_account_sync_needs_signin),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            Text(
                text =
                    stringResource(R.string.plavio_account_signed_in_as, state.plavioEmail ?: ""),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.plavioLastSync?.let { last ->
                Text(
                    text = stringResource(R.string.plavio_account_last_sync, last),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_sync_now),
                    onClick = { viewModel.plavioSync() },
                    kind = PlavioButtonKind.Primary,
                    enabled = !state.busy,
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_restore),
                    onClick = { viewModel.plavioRestore() },
                    enabled = !state.busy,
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_account_sign_out),
                    onClick = { viewModel.plavioSignOut() },
                    kind = PlavioButtonKind.Danger,
                    enabled = !state.busy,
                )
            }
        }

        AccountStatusLines(state)
    }
}

/**
 * The Account screen (v0.3.21 redesign, the owner's approved
 * sample): a photo card on the left (photo, name, @username, the
 * green Synced pill, Change photo) and the account rows on the
 * right — Username / Email / Password / Sync & backup / Connected
 * services, each carrying "»" into its panel, and Sign out in red
 * with no mark. Each panel carries ONLY its own controls (v0.3.26
 * split): Email = [PlavioAccountFormBlock], Sync & backup =
 * [PlavioSyncBlock], Password = the change-password form alone,
 * plus small dedicated forms (username, photo picker) — every
 * control wired, focus landing on each panel's first control and
 * returning to the row on Back.
 *
 * Signed OUT (owner's fix 2026-11-04): the rows are only Sign in /
 * Create account, both opening the shared form — the detail rows
 * and Sign out exist only once a door is signed in, same as the
 * phone app. A guest page must never show account details, a
 * password row, or a Sign out row. (v0.3.27 adds ONE exception:
 * the Connected services row shows for guests too — debrid /
 * Trakt / Simkl are separate services, not the Plavio account,
 * and they lived in Settings before the move; gating them behind
 * Plavio sign-in would strand every signed-out debrid user.)
 *
 * v0.3.27: the Connected services row opens an in-Account page
 * rendering [PlavioIntegrationsScreen] — the debrid keys and
 * Trakt/Simkl linking moved here from Settings → Streams →
 * Integrations, so every login lives in exactly one place (the
 * owner's no-duplicates rule).
 *
 * v0.3.34 (owner's account reorganization, approved sample): this
 * page is now the ONE home for everything account-shaped. The
 * identity card's column gains a PROFILES section directly under
 * the card — one row per profile (the active one carries the
 * green Active pill), "+ Add profile", and the explainer line;
 * every profile row opens the existing [PlavioProfilesScreen] as
 * an in-Account page, so switch / rename / remove keep their
 * panels and the Settings root's standalone Profiles row is gone.
 * The right column is grouped under ACCOUNT / SYNC / CONNECTED
 * SERVICES headings: SYNC carries Sync & backup, the Auto backup
 * switch (lifted out of the Sync panel onto the page), and Trakt
 * / Simkl as VISIBLE rows with their connection state — each
 * opening its own [AccountLinkBlock] panel, pulled up out of the
 * Connected services page, which keeps the debrid keys only.
 * Same ViewModels, same prefs keys, same sign-ins — surfaces
 * re-homed, data untouched. Guests keep Sign in / Create account,
 * the Profiles section, the Trakt / Simkl rows and Connected
 * services (those services are not the Plavio account).
 */
@Composable
fun PlavioAccountScreen(
    modifier: Modifier = Modifier,
    viewModel: PlavioAccountsViewModel = hiltViewModel(),
    profileViewModel: PlavioProfileViewModel = hiltViewModel(),
    profilesViewModel: PlavioProfilesViewModel = hiltViewModel(),
    integrationsViewModel: PlavioIntegrationsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val profileName by profileViewModel.profileName.collectAsState()
    val profileUsername by profileViewModel.profileUsername.collectAsState()
    val photoBase64 by profileViewModel.profilePhotoBase64.collectAsState()
    val profiles by profilesViewModel.profiles.collectAsState()
    val activeProfileId by profilesViewModel.activeId.collectAsState()
    val autoBackup by viewModel.autoBackup.collectAsState()
    val traktToken by integrationsViewModel.traktToken.collectAsState()
    val simklToken by integrationsViewModel.simklToken.collectAsState()
    val traktLink by integrationsViewModel.traktLink.collectAsState()
    val simklLink by integrationsViewModel.simklLink.collectAsState()
    val context = LocalContext.current

    var page by remember { mutableStateOf("main") }
    androidx.activity.compose.BackHandler(enabled = page != "main") { page = "main" }

    val email = state.plavioEmail
    val displayName =
        profileName ?: email?.substringBefore("@")?.replaceFirstChar { it.uppercase() }
            ?: stringResource(R.string.plavio_account_guest)
    val username = profileUsername ?: email?.substringBefore("@") ?: ""
    val photoBitmap =
        remember(photoBase64) {
            photoBase64?.let { encoded ->
                runCatching {
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }.getOrNull()
            }
        }
    var photoNote by remember { mutableStateOf<String?>(null) }
    val photoPicker =
        androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        ) { uri ->
            if (uri != null) {
                runCatching {
                    val bytes = context.contentResolver.openInputStream(uri)?.readBytes()
                        ?: error("empty")
                    val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: error("not an image")
                    val scaled =
                        android.graphics.Bitmap.createScaledBitmap(bitmap, 256, 256, true)
                    val out = java.io.ByteArrayOutputStream()
                    scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                    profileViewModel.setProfilePhotoBase64(
                        android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP),
                    )
                    photoNote = null
                }.onFailure {
                    photoNote = context.getString(R.string.plavio_account_photo_failed)
                }
            }
        }

    // Focus: the first row on entry; panels take their first control.
    val usernameRowFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    val panelFirstFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(page) {
        // v0.3.15: the v0.3.11 bounded-retry loop is replaced by the
        // shared additive landing (one shot + one next-frame
        // confirmation) — see PlavioFocus.landFocus for why the
        // retry windows are banned.
        // The Connected services page owns its own entry landing
        // (its first field), exactly as it did inside Settings —
        // this landing stands down for it. The Profiles page
        // (v0.3.34) owns its landing the same way (its first Use
        // button / Add field), so the landing stands down for it
        // too.
        if (page != "connected" && page != "profiles") {
            landFocus(if (page == "main") usernameRowFocus else panelFirstFocus)
        }
    }

    var confirmSignOut by remember { mutableStateOf(false) }
    val signOutFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    if (confirmSignOut) {
        PlavioConfirmDialog(
            title = stringResource(R.string.plavio_account_sign_out_title),
            message = stringResource(R.string.plavio_account_sign_out_text),
            confirmText = stringResource(R.string.plavio_account_sign_out),
            dismissText = stringResource(R.string.plavio_cancel),
            danger = true,
            openerFocus = signOutFocus,
            onConfirm = {
                confirmSignOut = false
                viewModel.plavioSignOut()
            },
            onDismiss = { confirmSignOut = false },
        )
    }

    if (page == "connected") {
        // Connected services (v0.3.27): the debrid keys and the
        // Trakt/Simkl linking that used to live under Settings →
        // Streams → Integrations live HERE now — the Account section
        // is the one home for every login (owner's order). The page
        // is the same composable with the same
        // PlavioIntegrationsViewModel and the same PlavioUiPrefs
        // keys, so every existing sign-in carries over untouched.
        // Back (the handler above) returns to the account rows, and
        // the page keeps its own entry focus landing (its first
        // field), exactly as it behaved inside Settings.
        PlavioIntegrationsScreen(modifier = Modifier.fillMaxSize())
        return
    }

    if (page == "profiles") {
        // Profiles (v0.3.34): the switcher that used to hang off
        // the Settings root renders here as an in-Account page —
        // the same composable, the same PlavioProfilesViewModel,
        // the same panels (Use / Rename / Remove / Add), so every
        // profile carries over untouched. Back (the handler above)
        // returns to the account rows, and the page keeps its own
        // entry focus landing, exactly as it behaved in Settings.
        PlavioProfilesScreen(modifier = Modifier.fillMaxSize())
        return
    }

    // v0.3.11: a scrolling column, not a LazyColumn — the email
    // panel's shared account block is far taller than the viewport,
    // and as ONE lazy item its lower controls sat in the same
    // unreachable-below-the-fold trap as the Settings panels. Every
    // control is a direct scroll child now; the layout (paddings,
    // spacing, header) is unchanged.
    val accountScrollState = androidx.compose.foundation.rememberScrollState()
    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(end = 40.dp, top = 72.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_tray_account),
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Column(
            modifier = Modifier.weight(1f).verticalScroll(accountScrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
        when (page) {
            "main" -> {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        // Left column (v0.3.34): the identity card,
                        // with the PROFILES section directly under
                        // it — profile management's only home.
                        Column(
                            modifier = Modifier.width(300.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                        // Photo card.
                        PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Box(
                                    modifier =
                                        Modifier
                                            .size(120.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(
                                                if (photoBitmap == null) {
                                                    LocalPlavioAccent.current.primary
                                                } else {
                                                    MaterialTheme.colorScheme.surfaceVariant
                                                },
                                            ),
                                    contentAlignment = androidx.compose.ui.Alignment.Center,
                                ) {
                                    if (photoBitmap != null) {
                                        androidx.compose.foundation.Image(
                                            bitmap = photoBitmap.asImageBitmap(),
                                            contentDescription = null,
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize(),
                                        )
                                    } else {
                                        Text(
                                            text = displayName.take(1).uppercase(),
                                            style = MaterialTheme.typography.displayMedium,
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                            color = LocalPlavioAccent.current.onAccent(),
                                        )
                                    }
                                }
                                Text(
                                    text = displayName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                )
                                if (username.isNotBlank()) {
                                    Text(
                                        text = "@$username",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                PlavioStatusChip(
                                    text =
                                        stringResource(
                                            if (state.plavioEmail != null) {
                                                R.string.plavio_account_synced
                                            } else {
                                                R.string.plavio_tray_not_signed_in
                                            },
                                        ),
                                    positive = state.plavioEmail != null,
                                )
                                PlavioFixedButton(
                                    text = stringResource(R.string.plavio_account_change_photo),
                                    onClick = {
                                        runCatching { photoPicker.launch("image/*") }
                                            .onFailure {
                                                photoNote =
                                                    context.getString(R.string.plavio_account_photo_failed)
                                            }
                                    },
                                )
                                if (photoNote != null) {
                                    Text(
                                        text = photoNote!!,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                        }
                        // PROFILES (v0.3.34): one row per profile
                        // under the identity card — the active one
                        // carries the Active pill, the rest carry
                        // "»"; every row opens the Profiles page,
                        // where switch / rename / remove / add live
                        // in their existing panels.
                        AccountSectionHeader(
                            text = stringResource(R.string.plavio_settings_profiles),
                        )
                        profiles.forEach { profile ->
                            val isActive = profile.id == activeProfileId
                            AccountRow(
                                title = profile.name,
                                value = null,
                                activePill = isActive,
                                showMark = !isActive,
                                onClick = { page = "profiles" },
                            )
                        }
                        if (profiles.size <
                            com.github.damontecres.wholphin.plavio.PlavioProfileState.MAX_PROFILES
                        ) {
                            AccountRow(
                                title = "+ " + stringResource(R.string.plavio_profiles_add),
                                value = null,
                                onClick = { page = "profiles" },
                            )
                        }
                        Text(
                            text = stringResource(R.string.plavio_account_profiles_explainer),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        }
                        // Rows.
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            if (state.plavioEmail == null) {
                                // Signed out: only the doors in. Both
                                // rows open the account form (the
                                // "email" panel), which carries the
                                // email/password form — the Plavio
                                // account is the only door.
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_settings_account),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sign_in),
                                    value = null,
                                    onClick = { page = "email" },
                                    modifier = Modifier.focusRequester(usernameRowFocus),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_create),
                                    value = null,
                                    onClick = { page = "email" },
                                )
                                // Trakt / Simkl and Connected
                                // services show for a guest too:
                                // they are separate services, not
                                // the Plavio account, and they lived
                                // in Settings before the v0.3.27 move
                                // — gating them behind Plavio sign-in
                                // would strand every signed-out
                                // debrid user.
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_account_section_sync),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_integrations_trakt),
                                    value =
                                        stringResource(
                                            if (traktToken != null) {
                                                R.string.plavio_account_status_connected
                                            } else {
                                                R.string.plavio_account_status_not_connected
                                            },
                                        ),
                                    statusPositive = traktToken != null,
                                    onClick = { page = "trakt" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_integrations_simkl),
                                    value =
                                        stringResource(
                                            if (simklToken != null) {
                                                R.string.plavio_account_status_connected
                                            } else {
                                                R.string.plavio_account_status_not_connected
                                            },
                                        ),
                                    statusPositive = simklToken != null,
                                    onClick = { page = "simkl" },
                                )
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_account_connected_row),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_connected_row),
                                    value = null,
                                    onClick = { page = "connected" },
                                )
                            } else {
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_settings_account),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_username),
                                    value = if (username.isNotBlank()) "@$username" else null,
                                    onClick = { page = "username" },
                                    modifier = Modifier.focusRequester(usernameRowFocus),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_email_hint),
                                    value = email,
                                    onClick = { page = "email" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_password_row),
                                    value = "••••••••",
                                    onClick = { page = "password" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sign_out),
                                    value = null,
                                    danger = true,
                                    showMark = false,
                                    onClick = { confirmSignOut = true },
                                    modifier = Modifier.focusRequester(signOutFocus),
                                )
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_account_section_sync),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sync_row),
                                    value = state.plavioLastSync,
                                    onClick = { page = "sync" },
                                )
                                // Auto backup (v0.3.34): the switch
                                // sits on the page now, in the SYNC
                                // section — its ONLY home; the copy
                                // inside the Sync panel was removed
                                // in the same pass (the owner's
                                // no-doubles rule). Same flow, same
                                // store: PlavioAccountsViewModel.
                                PlavioSwitchRow(
                                    label = stringResource(R.string.plavio_account_auto_backup),
                                    checked = autoBackup,
                                    onStateChange = { viewModel.setAutoBackup(it) },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_integrations_trakt),
                                    value =
                                        stringResource(
                                            if (traktToken != null) {
                                                R.string.plavio_account_status_connected
                                            } else {
                                                R.string.plavio_account_status_not_connected
                                            },
                                        ),
                                    statusPositive = traktToken != null,
                                    onClick = { page = "trakt" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_integrations_simkl),
                                    value =
                                        stringResource(
                                            if (simklToken != null) {
                                                R.string.plavio_account_status_connected
                                            } else {
                                                R.string.plavio_account_status_not_connected
                                            },
                                        ),
                                    statusPositive = simklToken != null,
                                    onClick = { page = "simkl" },
                                )
                                AccountSectionHeader(
                                    text = stringResource(R.string.plavio_account_connected_row),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_connected_row),
                                    value = null,
                                    onClick = { page = "connected" },
                                )
                            }
                        }
                    }
            }

            "username" -> {
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        val nameState = rememberTextFieldState(profileName ?: "")
                        val usernameState = rememberTextFieldState(profileUsername ?: "")
                        Text(
                            text = stringResource(R.string.plavio_account_username),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text = stringResource(R.string.plavio_account_display_name),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioClickToEditField(
                            state = nameState,
                            modifier =
                                Modifier.fillMaxWidth().focusRequester(panelFirstFocus),
                            keyboardOptions =
                                KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Next,
                                ),
                            emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                        )
                        Text(
                            text = stringResource(R.string.plavio_account_username),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioClickToEditField(
                            state = usernameState,
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions =
                                KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done,
                                ),
                            emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                        )
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_integrations_save),
                            onClick = {
                                profileViewModel.setProfileName(nameState.text.toString())
                                profileViewModel.setProfileUsername(usernameState.text.toString())
                                page = "main"
                            },
                            kind = PlavioButtonKind.Primary,
                        )
                    }
            }

            "password" -> {
                    // v0.3.26 split: ONLY the change-password form
                    // lives here (plus the status lines, so the
                    // change's result is readable where it was made).
                    // The reset path lives in the Email panel's form.
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (state.plavioEmail != null) {
                                val newPasswordState = rememberTextFieldState()
                                Text(
                                    text = stringResource(R.string.plavio_account_password_row),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground,
                                )
                                PlavioClickToEditField(
                                    state = newPasswordState,
                                    modifier =
                                        Modifier.fillMaxWidth().focusRequester(panelFirstFocus),
                                    isPassword = true,
                                    keyboardOptions =
                                        KeyboardOptions(
                                            keyboardType = KeyboardType.Password,
                                            imeAction = ImeAction.Done,
                                        ),
                                    emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                                )
                                PlavioFixedButton(
                                    text = stringResource(R.string.plavio_account_change_password),
                                    onClick = {
                                        viewModel.plavioChangePassword(newPasswordState.text.toString())
                                    },
                                    kind = PlavioButtonKind.Primary,
                                    enabled = !state.busy,
                                )
                            }
                            AccountStatusLines(state)
                        }
                    }
            }

            "sync" -> {
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        PlavioSyncBlock()
                    }
            }

            "trakt" -> {
                    // Trakt linking (v0.3.34): the same
                    // AccountLinkBlock that lived on the Connected
                    // services page, now behind the Account page's
                    // own Trakt row — one home for the linking UI.
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        AccountLinkBlock(
                            title = stringResource(R.string.plavio_integrations_trakt),
                            linked = traktToken != null,
                            linkState = traktLink,
                            onStart = { integrationsViewModel.startTraktLink() },
                            onSubmit = { integrationsViewModel.submitTraktCode(it) },
                            onCancel = { integrationsViewModel.cancelTraktLink() },
                            onUnlink = { integrationsViewModel.unlinkTrakt() },
                        )
                    }
            }

            "simkl" -> {
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        AccountLinkBlock(
                            title = stringResource(R.string.plavio_integrations_simkl),
                            linked = simklToken != null,
                            linkState = simklLink,
                            onStart = { integrationsViewModel.startSimklLink() },
                            onSubmit = { integrationsViewModel.submitSimklCode(it) },
                            onCancel = { integrationsViewModel.cancelSimklLink() },
                            onUnlink = { integrationsViewModel.unlinkSimkl() },
                        )
                    }
            }

            else -> {
                // "email": the account form alone (sign-in / create
                // / reset) — the Sync panel carries the sync actions.
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        PlavioAccountFormBlock()
                    }
            }
        }
        }
    }
}

/** A small caps section heading on the Account page (v0.3.34 grouping). */
@Composable
private fun AccountSectionHeader(
    text: String,
    modifier: Modifier = Modifier,
) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        letterSpacing = 2.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.padding(start = 4.dp, top = 8.dp),
    )
}

/**
 * One Account row: title + current value + "»" (the Settings row
 * language). v0.3.34 additions: [activePill] renders the green
 * Active pill instead of a value/mark (the current profile's row),
 * and [statusPositive] draws a small state dot before the value
 * (the Trakt / Simkl rows: green = connected, muted = not).
 */
@Composable
private fun AccountRow(
    title: String,
    value: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    showMark: Boolean = true,
    activePill: Boolean = false,
    statusPositive: Boolean? = null,
) {
    androidx.tv.material3.Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape =
            androidx.tv.material3.ClickableSurfaceDefaults.shape(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            ),
        scale =
            androidx.tv.material3.ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            androidx.tv.material3.ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelFramed,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = PlavioOnyx.PanelFramed,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = PlavioOnyx.PanelFramed,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(androidx.compose.foundation.shape.RoundedCornerShape(14.dp)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                color =
                    if (danger) {
                        androidx.compose.ui.graphics.Color(0xFFF87171)
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                modifier = Modifier.weight(1f),
            )
            if (activePill) {
                PlavioStatusChip(
                    text = stringResource(R.string.plavio_profiles_active),
                    positive = true,
                )
            } else {
                if (value != null) {
                    if (statusPositive != null) {
                        Box(
                            modifier =
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (statusPositive) {
                                            PlavioOnyx.CachedGreen
                                        } else {
                                            androidx.compose.ui.graphics.Color.White
                                                .copy(alpha = 0.35f)
                                        },
                                    ),
                        )
                    }
                    Text(
                        text = value,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                }
                if (showMark) {
                    Text(
                        text = "»",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
