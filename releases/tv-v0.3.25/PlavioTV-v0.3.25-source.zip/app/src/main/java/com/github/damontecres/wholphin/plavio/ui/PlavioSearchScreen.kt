package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed as lazyRowItemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CachedMeta
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.SearchFilters
import com.github.damontecres.wholphin.ui.components.Button
import com.github.damontecres.wholphin.ui.components.EditTextBox
import kotlinx.coroutines.launch

/**
 * Search: the field capsule at the top-left + the results poster
 * grid on the right, updating AS YOU TYPE (debounced — every key
 * re-searches). Picking a result opens the same detail page the
 * home rows lead to.
 *
 * v0.3.16 (note 10, owner's order): the custom in-app keyboard is
 * REMOVED — Search uses the TV's default system keyboard, as
 * usual. Entering the screen lands focus on the field and raises
 * the system IME; the IME's Search action runs the search and the
 * focus then moves to the first result (the pending-move machine
 * below). This supersedes the v0.3.10 "never pop the IME"
 * discipline and the v0.3.11 bottom-anchored custom grid.
 */
@Composable
fun PlavioSearchScreen(
    onItemClick: (CachedMeta) -> Unit,
    onPersonClick: (com.github.damontecres.wholphin.plavio.CastMember) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioSearchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val discoverRows by viewModel.discoverRows.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    // v0.3.16 (note 10): the field IS the entry point — focus lands
    // on it and the system keyboard rises, the usual TV behaviour.
    val fieldFocusRequester = remember { FocusRequester() }
    val entryKeyboardController = LocalSoftwareKeyboardController.current
    // Entry landing (v0.3.14): the shared primitive with a claim fed
    // by the screen root's focus state. Bounded, confirmed,
    // cancellable.
    var searchClaimed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        landFocus(
            requester = fieldFocusRequester,
            isClaimed = { searchClaimed },
            attempts = 8,
            delayMs = 140,
        )
        entryKeyboardController?.show()
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    val entryScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            entryScope.launch(CrashReports.backgroundScopeHandler) {
                searchClaimed = false
                landFocus(fieldFocusRequester, isClaimed = { searchClaimed }, attempts = 6, delayMs = 130)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    // Done → results is a state machine, not a hope (v0.3.14, the
    // reference behaviour): pressing Done records a PENDING move.
    // The move fires only once the search for it has been seen
    // running (Searching) and has finished into Results — if results
    // were already on screen, focus does NOT jump into the stale
    // grid; it waits for the new ones. Any focus the user takes in
    // the results grid himself cancels the pending move.
    var pendingResultsMove by remember { mutableStateOf(false) }
    var moveSawSearching by remember { mutableStateOf(false) }
    var resultsClaimed by remember { mutableStateOf(false) }
    val firstResultFocus = remember { FocusRequester() }
    LaunchedEffect(state, pendingResultsMove) {
        if (!pendingResultsMove) return@LaunchedEffect
        when (state) {
            PlavioSearchUiState.Searching -> moveSawSearching = true
            is PlavioSearchUiState.Results -> {
                if (moveSawSearching) {
                    kotlinx.coroutines.delay(90)
                    landFocus(
                        requester = firstResultFocus,
                        isClaimed = { resultsClaimed || !pendingResultsMove },
                        attempts = 8,
                        delayMs = 120,
                    )
                    pendingResultsMove = false
                    moveSawSearching = false
                }
            }
            is PlavioSearchUiState.NoResults -> {
                pendingResultsMove = false
                moveSawSearching = false
            }
            else -> {}
        }
    }
    // Live search: any query change re-searches after a short settle.
    LaunchedEffect(query) {
        if (query.isBlank()) return@LaunchedEffect
        kotlinx.coroutines.delay(350)
        viewModel.search(query)
    }
    // Discover (batch 6): rows for the empty state load once, in
    // the background — the page never waits on them.
    LaunchedEffect(Unit) {
        viewModel.loadDiscover()
    }
    // Suggestions (v0.3.26): debounced alongside the live search —
    // recents + catalog title matches for what's being typed.
    LaunchedEffect(query) {
        if (query.isBlank()) {
            viewModel.clearSuggestions()
            return@LaunchedEffect
        }
        kotlinx.coroutines.delay(250)
        viewModel.suggest(query)
    }
    // Result filters (v0.3.26): client-side over the loaded results;
    // a new query starts unfiltered again.
    var typeFilter by remember { mutableStateOf<String?>(null) }
    var genreFilter by remember { mutableStateOf<String?>(null) }
    var yearFilter by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(query) {
        typeFilter = null
        genreFilter = null
        yearFilter = null
    }

    // Voice search: shown only when a speech recognizer is installed
    // on the TV. The system recognizer owns the mic permission and
    // the listening UI; the recognized text lands in the query.
    val context = LocalContext.current
    val voiceAvailable =
        remember {
            context.packageManager
                .queryIntentActivities(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH),
                    0,
                ).isNotEmpty()
        }
    val voicePrompt = stringResource(R.string.plavio_search_voice_prompt)
    val voiceLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val spoken =
                    result.data
                        ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                        ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    query = spoken
                }
            }
        }

    // Layout: the field column on the left, the RESULTS taking
    // whatever height is left (the lazy grid absorbs any height
    // shortage). On short screens the heading line steps aside.
    // (v0.3.16, note 10: the custom keyboard that used to anchor
    // the bottom-left is gone — the system IME overlays instead,
    // as on any other TV app.)
    BoxWithConstraints(
        modifier =
            modifier
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) searchClaimed = true }
                .padding(end = PlavioChrome.endPad(), top = 72.dp, bottom = 24.dp),
    ) {
        val compactHeight = maxHeight < 430.dp
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            // Left: the field capsule column.
            Column(
                modifier = Modifier.width(468.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (!compactHeight) {
                    Text(
                        text = stringResource(R.string.plavio_search_heading),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    EditTextBox(
                        value = query,
                        onValueChange = { query = it },
                        modifier =
                            Modifier
                                .weight(1f)
                                .focusRequester(fieldFocusRequester),
                        keyboardOptions =
                            KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Search,
                            ),
                        keyboardActions =
                            KeyboardActions(
                                onSearch = {
                                    // The system keyboard's Search
                                    // action takes over the old
                                    // custom keyboard's Done job: arm
                                    // the pending results move, then
                                    // search — focus lands on the
                                    // first result when THIS search
                                    // lands (the machine above).
                                    resultsClaimed = false
                                    moveSawSearching = false
                                    pendingResultsMove = true
                                    viewModel.search(query)
                                },
                            ),
                        placeholder = {
                            androidx.compose.material3.Text(
                                text = stringResource(R.string.plavio_search_hint),
                            )
                        },
                    )
                    if (voiceAvailable) {
                        PlavioFixedButton(
                            text = "",
                            onClick = {
                                voiceLauncher.launch(
                                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(
                                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                                        )
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, voicePrompt)
                                    },
                                )
                            },
                            leadingIcon = PlavioIcons.Mic,
                            modifier = Modifier.width(56.dp),
                        )
                    }
                }
            }
            // Recent searches (v0.3.26): shown while the field is
            // empty — tap one to run it again; Clear all wipes the
            // list. Picking one sets the query, which fires the
            // debounced live search like typing it would.
            val recents by viewModel.recentSearches.collectAsState()
            if (query.isBlank() && recents.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_search_recent),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    recents.forEach { recent ->
                        PlavioFilterCapsule(
                            text = recent,
                            selected = false,
                            onClick = { query = recent },
                        )
                    }
                    PlavioFilterCapsule(
                        text = stringResource(R.string.plavio_search_clear_all),
                        selected = false,
                        onClick = { viewModel.clearRecentSearches() },
                    )
                }
            }
            // Suggestions (v0.3.26): while typing, matching recents
            // and catalog titles — picking one runs that search and
            // arms the same pending move the IME Search action uses.
            val suggestions by viewModel.suggestions.collectAsState()
            if (query.isNotBlank() && suggestions.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_search_suggestions),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    suggestions.forEach { suggestion ->
                        PlavioFilterCapsule(
                            text = suggestion,
                            selected = false,
                            onClick = {
                                query = suggestion
                                resultsClaimed = false
                                moveSawSearching = false
                                pendingResultsMove = true
                                viewModel.search(suggestion)
                            },
                        )
                    }
                }
            }
        }

        // Right: results.
        Box(modifier = Modifier.weight(1f)) {
            when (val st = state) {
                PlavioSearchUiState.Idle -> {
                    // Discover (batch 6): with nothing typed, the
                    // right pane browses the discover addon's
                    // trending/popular catalogs; until they land
                    // (or when there are none) the idle line shows.
                    if (discoverRows.isNotEmpty()) {
                        DiscoverRows(rows = discoverRows, onItemClick = onItemClick)
                    } else {
                        SearchMessage(text = stringResource(R.string.plavio_search_idle))
                    }
                }

                PlavioSearchUiState.Searching -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            OrbitLoader(modifier = Modifier.size(56.dp))
                            Text(
                                text = stringResource(R.string.plavio_search_searching),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                is PlavioSearchUiState.Results -> {
                    // Filters (v0.3.26): capsule rows over the loaded
                    // results — type always; genre and year join when
                    // the result set actually carries them. Filtering
                    // is client-side over what already loaded.
                    val allMetas = st.items.map { it.meta }
                    val genres = remember(st.items) { SearchFilters.availableGenres(allMetas) }
                    val years = remember(st.items) { SearchFilters.availableYears(allMetas) }
                    val filteredMetas =
                        SearchFilters.filter(allMetas, typeFilter, genreFilter, yearFilter)
                    val filteredItems = st.items.filter { it.meta in filteredMetas }
                    val filtersActive =
                        typeFilter != null || genreFilter != null || yearFilter != null
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            item {
                                PlavioFilterCapsule(
                                    text = stringResource(R.string.plavio_filter_any),
                                    selected = typeFilter == null,
                                    onClick = { typeFilter = null },
                                )
                            }
                            item {
                                PlavioFilterCapsule(
                                    text = stringResource(R.string.plavio_actor_movies),
                                    selected = typeFilter == "movie",
                                    onClick = { typeFilter = "movie" },
                                )
                            }
                            item {
                                PlavioFilterCapsule(
                                    text = stringResource(R.string.plavio_actor_series),
                                    selected = typeFilter == "series",
                                    onClick = { typeFilter = "series" },
                                )
                            }
                        }
                        if (genres.size > 1) {
                            androidx.compose.foundation.lazy.LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                item {
                                    PlavioFilterCapsule(
                                        text = stringResource(R.string.plavio_filter_any),
                                        selected = genreFilter == null,
                                        onClick = { genreFilter = null },
                                    )
                                }
                                genres.forEach { genre ->
                                    item {
                                        PlavioFilterCapsule(
                                            text = genre,
                                            selected = genreFilter == genre,
                                            onClick = { genreFilter = genre },
                                        )
                                    }
                                }
                            }
                        }
                        if (years.size > 1) {
                            androidx.compose.foundation.lazy.LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                item {
                                    PlavioFilterCapsule(
                                        text = stringResource(R.string.plavio_filter_any),
                                        selected = yearFilter == null,
                                        onClick = { yearFilter = null },
                                    )
                                }
                                years.forEach { year ->
                                    item {
                                        PlavioFilterCapsule(
                                            text = year,
                                            selected = yearFilter == year,
                                            onClick = { yearFilter = year },
                                        )
                                    }
                                }
                            }
                        }
                        if (filteredItems.isEmpty()) {
                            SearchMessage(
                                text = stringResource(R.string.plavio_search_no_filter_matches),
                            )
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 124.dp),
                                modifier =
                                    Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .onFocusChanged { if (it.hasFocus) resultsClaimed = true },
                        contentPadding = PaddingValues(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        if (st.people.isNotEmpty() && !filtersActive) {
                            item(
                                key = "people",
                                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) },
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = stringResource(R.string.plavio_search_people),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground,
                                    )
                                    androidx.compose.foundation.lazy.LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        lazyRowItemsIndexed(
                                            st.people,
                                            key = { index, member -> "${member.id}|${member.name}|$index" },
                                        ) { personIndex, member ->
                                            PersonCard(
                                                member = member,
                                                onClick = { onPersonClick(member) },
                                                focusRequester =
                                                    if (personIndex == 0) {
                                                        firstResultFocus
                                                    } else {
                                                        null
                                                    },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        items(filteredItems, key = { "${it.addonId}|${it.meta.type}|${it.meta.id}" }) { item ->
                            SharedPosterCard(
                                item = item.meta,
                                onClick = { onItemClick(item) },
                                modifier = Modifier.fillMaxWidth(),
                                // The pending Done-move lands on the
                                // first poster — unless a people row
                                // sits above it and owns the landing.
                                focusRequester =
                                    if ((st.people.isEmpty() || filtersActive) &&
                                        item == filteredItems.firstOrNull()
                                    ) {
                                        firstResultFocus
                                    } else {
                                        null
                                    },
                            )
                        }
                            }
                        }
                    }
                }

                is PlavioSearchUiState.NoResults -> {
                    SearchMessage(text = stringResource(R.string.plavio_search_no_results, st.query))
                }

                PlavioSearchUiState.NoSearchAddons -> {
                    SearchMessage(text = stringResource(R.string.plavio_search_no_addons))
                }
            }
        }
        }
    }
}

/**
 * Discover rows (batch 6): the picked catalogs of the discover
 * addon as poster rows in the results pane — the same cards the
 * rest of the app uses; a tap opens the title exactly like a
 * search result (the CachedMeta carries the row's addon).
 */
@Composable
private fun DiscoverRows(
    rows: List<com.github.damontecres.wholphin.plavio.CatalogRow>,
    onItemClick: (CachedMeta) -> Unit,
) {
    androidx.compose.foundation.lazy.LazyColumn(
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 8.dp),
    ) {
        item(key = "discover-heading") {
            Text(
                text = stringResource(R.string.plavio_search_discover),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
        }
        lazyRowItemsIndexed(
            rows,
            key = { _, row -> "discover|${row.addonId}|${row.type}|${row.catalogId}" },
        ) { _, row ->
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = row.catalogName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(end = 8.dp),
                ) {
                    lazyRowItemsIndexed(
                        row.items,
                        key = { index, item -> "${item.type}|${item.id}|$index" },
                    ) { _, item ->
                        SharedPosterCard(
                            item = item,
                            onClick = {
                                onItemClick(
                                    CachedMeta(
                                        addonId = row.addonId,
                                        addonName = row.addonName,
                                        baseUrl = row.baseUrl,
                                        meta = item,
                                    ),
                                )
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchMessage(text: String) {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SearchPosterCard(
    item: MetaPreview,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    androidx.tv.material3.Card(
        onClick = onClick,
        modifier = modifier.width(124.dp),
        colors =
            androidx.tv.material3.CardDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
            ),
        scale = plavioCardScale(),
    ) {
        Column {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (item.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(item.poster)
                                .size(248, 372)
                                .crossfade(false)
                                .build(),
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = item.name.take(1),
                        style = MaterialTheme.typography.displaySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}
