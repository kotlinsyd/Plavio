package com.github.damontecres.wholphin.plavio

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/** Streams + subtitles gathered for one playable item, merged across addons. */
data class StreamBundle(
    val streams: List<StreamItem>,
    val subtitles: List<Subtitle>,
)

/**
 * Fans addon-protocol requests out over the installed addons: catalogs for
 * the home rows, meta for the detail page and streams for playback. Every
 * per-addon call is isolated — one dead or slow addon never blanks the
 * whole result.
 */
@Singleton
class AddonCatalogRepository
    @Inject
    constructor(
        private val addonStore: AddonStore,
        private val uiPrefs: PlavioUiPrefs,
        // Batch 6: Hilt always supplies the real probe in the app;
        // the default only serves manual constructions (unit
        // tests), where an unknown chain must not second-guess
        // picks — [applyHdrFallback] treats null as DV-capable.
        private val hdrSupport: DeviceHdrSupport? = null,
    ) {
        private val api = StremioApi()

        private val enabledAddons: List<InstalledAddon>
            get() = addonStore.addons.value.filter { it.enabled }

        /** Addons that can serve home rows right now. */
        fun catalogAddons(): List<InstalledAddon> = enabledAddons.filter { it.manifest.hasCatalog }

        /** Enabled addons that serve streams — the set an empty streams screen reports health for. */
        fun streamAddons(): List<InstalledAddon> = enabledAddons.filter { it.manifest.hasStream }

        /** [loadHomeRowsProgressive] without the incremental callback. */
        suspend fun loadHomeRows(): List<CatalogRow> = loadHomeRowsProgressive { }

        /**
         * One row per movie/series catalog of every enabled addon, in addon
         * then manifest order. Catalogs that fail or come back empty are
         * dropped so the home only shows rows with something in them.
         *
         * Progressive (owner's principle, v0.3.10): [onRows] fires as each
         * catalog settles, with the rows ready so far — already hidden-
         * filtered and order-sorted exactly like the final list — so Home
         * renders its first row as soon as the fastest catalog answers
         * instead of waiting for the slowest one. The returned list is
         * the same final list the old await-all version produced.
         */
        suspend fun loadHomeRowsProgressive(onRows: (List<CatalogRow>) -> Unit): List<CatalogRow> =
            coroutineScope {
                val targets =
                    catalogAddons().flatMap { addon ->
                        addon.manifest.catalogs
                            .filter { it.type == "movie" || it.type == "series" }
                            .map { catalog -> addon to catalog }
                    }
                // Snapshot helper: completed rows in fan-out order,
                // hidden-filtered and order-sorted like the final list.
                // Batch B: the filter + sort runs on
                // Dispatchers.Default — it re-runs on every settled
                // catalog while the caller sits on Main. Both call
                // sites pass a fresh filterNotNull() copy and the two
                // prefs are StateFlow reads, so the computation works
                // on a consistent snapshot; results are delivered on
                // the original context in the same order as before.
                suspend fun arrange(rows: List<CatalogRow>): List<CatalogRow> =
                    withContext(Dispatchers.Default) {
                        val hidden = uiPrefs.homeHiddenAddons.value
                        val order = uiPrefs.homeAddonOrder.value
                        rows
                            .filter { it.addonId !in hidden }
                            .withIndex()
                            .sortedWith(
                                compareBy<IndexedValue<CatalogRow>> { indexed ->
                                    val pos = order.indexOf(indexed.value.addonId)
                                    if (pos >= 0) pos else Int.MAX_VALUE
                                }.thenBy { it.index },
                            ).map { it.value }
                    }
                val completed = arrayOfNulls<CatalogRow>(targets.size)
                val gate = Mutex()
                val jobs =
                    targets.mapIndexed { index, (addon, catalog) ->
                        launch {
                            val items =
                                runCatching {
                                    api.fetchCatalog(addon.baseUrl, catalog.type, catalog.id)
                                }.onFailure {
                                    Timber.v(it, "Catalog %s/%s from %s failed", catalog.type, catalog.id, addon.name)
                                }.getOrNull()
                            val row =
                                if (items.isNullOrEmpty()) {
                                    null
                                } else {
                                    CatalogRow(
                                        addonId = addon.id,
                                        addonName = addon.name,
                                        baseUrl = addon.baseUrl,
                                        catalogName = catalog.name,
                                        type = catalog.type,
                                        catalogId = catalog.id,
                                        items = items,
                                    )
                                }
                            gate.withLock {
                                completed[index] = row
                                val snapshot = arrange(completed.filterNotNull())
                                if (snapshot.isNotEmpty()) onRows(snapshot)
                            }
                        }
                    }
                jobs.joinAll()
                arrange(completed.filterNotNull())
            }

        /**
         * Discover rows for the Search screen's empty state (batch
         * 6): the picked catalogs of ONE addon (see
         * [DiscoverCatalogs]), fetched in parallel; [onRows] fires
         * as each catalog settles with the rows ready so far, in
         * pick order — the section joins when it lands and never
         * blocks the page. Empty when no catalog addon exists or
         * every picked catalog comes back empty.
         */
        suspend fun loadDiscoverRows(onRows: (List<CatalogRow>) -> Unit): List<CatalogRow> =
            coroutineScope {
                val addon =
                    DiscoverCatalogs.sourceAddon(
                        catalogAddons(),
                        uiPrefs.defaultCatalogAddonId.value,
                    ) ?: return@coroutineScope emptyList()
                val targets = DiscoverCatalogs.pick(addon.manifest.catalogs)
                if (targets.isEmpty()) return@coroutineScope emptyList()
                val completed = arrayOfNulls<CatalogRow>(targets.size)
                val gate = Mutex()
                val jobs =
                    targets.mapIndexed { index, catalog ->
                        launch {
                            val items =
                                runCatching {
                                    api.fetchCatalog(addon.baseUrl, catalog.type, catalog.id)
                                }.onFailure {
                                    Timber.v(it, "Discover catalog %s/%s from %s failed", catalog.type, catalog.id, addon.name)
                                }.getOrNull()
                            if (!items.isNullOrEmpty()) {
                                gate.withLock {
                                    completed[index] =
                                        CatalogRow(
                                            addonId = addon.id,
                                            addonName = addon.name,
                                            baseUrl = addon.baseUrl,
                                            catalogName = catalog.name,
                                            type = catalog.type,
                                            catalogId = catalog.id,
                                            items = items,
                                        )
                                    onRows(completed.filterNotNull())
                                }
                            }
                        }
                    }
                jobs.joinAll()
                completed.filterNotNull()
            }

        /** True when at least one enabled addon's catalog declares the "search" extra. */
        fun hasSearchCatalogs(): Boolean =
            catalogAddons().any { addon ->
                addon.manifest.catalogs.any { catalog ->
                    (catalog.type == "movie" || catalog.type == "series") && catalog.supportsSearch
                }
            }

        /**
         * Live search across every enabled catalog addon: each movie/series
         * catalog that declares the "search" extra is queried via
         * [StremioApi.searchCatalog] (addons without it answer 404 to
         * search= queries, so they are never asked). Results merge in
         * addon order and dedupe by (type, id), keeping the first addon's
         * copy. Per-addon failures are isolated, like the catalog fan-out.
         */
        suspend fun searchCatalogs(query: String): List<CachedMeta> =
            coroutineScope {
                val jobs =
                    catalogAddons().flatMap { addon ->
                        addon.manifest.catalogs
                            .filter { catalog ->
                                (catalog.type == "movie" || catalog.type == "series") && catalog.supportsSearch
                            }.map { catalog ->
                                async {
                                    runCatching {
                                        api.searchCatalog(addon.baseUrl, catalog.type, catalog.id, query)
                                    }.onFailure {
                                        Timber.v(it, "Search %s/%s from %s failed", catalog.type, catalog.id, addon.name)
                                    }.getOrDefault(emptyList())
                                        .map { meta ->
                                            CachedMeta(
                                                addonId = addon.id,
                                                addonName = addon.name,
                                                baseUrl = addon.baseUrl,
                                                meta = meta,
                                            )
                                        }
                                }
                            }
                    }
                val seen = HashSet<String>()
                jobs.awaitAll().flatten().filter { cached ->
                    seen.add("${cached.meta.type}|${cached.meta.id}")
                }
            }

        /**
         * Meta for [id], preferring the addon the item came from (its ids are
         * authoritative there) and falling back to the other enabled meta
         * addons — ids are usually portable (e.g. IMDb ids) across addons.
         */
        /**
         * Base URL of the default meta addon (episode checks + alert
         * deep links). v0.3.16 (note 6): the user's chosen default
         * catalog addon wins when it is set, enabled and can serve
         * meta; otherwise the historic pick — the first enabled meta
         * addon — stands.
         */
        fun primaryMetaBaseUrl(): String? {
            val chosen = uiPrefs.defaultCatalogAddonId.value
            if (chosen != null) {
                enabledAddons
                    .firstOrNull { it.id == chosen && it.manifest.hasMeta }
                    ?.let { return it.baseUrl }
            }
            return enabledAddons.firstOrNull { it.manifest.hasMeta }?.baseUrl
        }

        suspend fun loadMeta(
            sourceBaseUrl: String,
            type: String,
            id: String,
        ): MetaDetail? {
            // Candidate order: the addon the item came from first
            // (its ids are authoritative), then the user's chosen
            // default catalog addon (v0.3.16, note 6), then the rest
            // in addon order.
            val chosenId = uiPrefs.defaultCatalogAddonId.value
            val candidates =
                enabledAddons
                    .filter { it.manifest.hasMeta }
                    .sortedByDescending { addon ->
                        when {
                            addon.baseUrl == sourceBaseUrl -> 2
                            addon.id == chosenId -> 1
                            else -> 0
                        }
                    }
            for (addon in candidates) {
                val meta =
                    runCatching { api.fetchMeta(addon.baseUrl, type, id) }
                        .onFailure { Timber.v(it, "Meta %s/%s from %s failed", type, id, addon.name) }
                        .getOrNull()
                if (meta != null) return meta
            }
            return null
        }

        /**
         * Streams for [videoId] from every enabled stream addon, plus
         * subtitles: the ones embedded in stream responses and, when the
         * title has an IMDb id, the dedicated subtitles endpoint of every
         * enabled subtitles addon. Torrent-only entries (no direct HTTP
         * URL) are excluded — Plavio TV plays direct streams only.
         */
        /** [loadStreamsProgressive] without the incremental callback. */
        suspend fun loadStreams(
            type: String,
            videoId: String,
            metaId: String,
        ): StreamBundle = loadStreamsProgressive(type, videoId, metaId) { }

        /**
         * Progressive form of [loadStreams] (owner's principle, v0.3.10):
         * [onBundle] fires as each stream addon (and each dedicated
         * subtitles endpoint) settles, carrying the playable streams
         * gathered so far — rules-sorted, in addon order. Snapshots only
         * ever contain direct http(s) streams; infoHash placeholders
         * join in the final bundle once the debrid pass has resolved
         * them. The returned bundle is built exactly like the old
         * await-all version built it (same merge, same debrid pass,
         * same rules), so callers that ignore [onBundle] see no change.
         */
        suspend fun loadStreamsProgressive(
            type: String,
            videoId: String,
            metaId: String,
            onBundle: (StreamBundle) -> Unit,
        ): StreamBundle =
            coroutineScope {
                // Debrid (phone parity): with a TorBox / Real-Debrid key
                // configured, infoHash-only entries are kept and resolved
                // to direct links in the final bundle; without a key they
                // stay excluded.
                val torboxKey = uiPrefs.torboxApiKey.value
                val realDebridKey = uiPrefs.realDebridApiKey.value
                val debridConfigured =
                    torboxKey != null || realDebridKey != null ||
                        uiPrefs.premiumizeApiKey.value != null ||
                        uiPrefs.allDebridApiKey.value != null ||
                        uiPrefs.debridLinkApiKey.value != null ||
                        uiPrefs.offcloudApiKey.value != null

                val streamAddons = enabledAddons.filter { it.manifest.hasStream }
                val results = arrayOfNulls<Pair<InstalledAddon, StreamResult>>(streamAddons.size)
                val subtitleAddons = enabledAddons.filter { it.manifest.hasSubtitles }
                val dedicatedSubs = arrayOfNulls<List<Subtitle>>(subtitleAddons.size)

                fun directFrom(completed: List<Pair<InstalledAddon, StreamResult>>): List<StreamItem> =
                    completed.flatMap { (addon, result) ->
                        result.streams
                            .filter {
                                it.url.startsWith("http://") || it.url.startsWith("https://") ||
                                    (debridConfigured && it.infoHash != null)
                            }.map { it.copy(sourceName = addon.name, sourceId = addon.id) }
                    }

                fun subtitlesFrom(
                    completed: List<Pair<InstalledAddon, StreamResult>>,
                    dedicated: List<List<Subtitle>>,
                ): List<Subtitle> {
                    val merged = LinkedHashMap<String, Subtitle>()
                    completed.forEach { (_, result) ->
                        result.subtitles.forEach { merged.putIfAbsent(it.url, it) }
                    }
                    dedicated.flatten().forEach { merged.putIfAbsent(it.url, it) }
                    return merged.values.toList()
                }

                // Batch B (main-thread relief): the merge + rules
                // sort below used to run on the caller's dispatcher
                // (Main) once per settled addon. The settled inputs
                // are captured FIRST — filterNotNull() copies the
                // arrays into fresh lists of immutable results, and
                // both call sites already hold [gate], so the capture
                // sees a consistent state — then the computation runs
                // on Dispatchers.Default over that immutable capture.
                // onBundle still fires on the original context, in
                // the same order, with the same bundle contents.
                suspend fun snapshot(): StreamBundle {
                    val completed = results.filterNotNull()
                    val dedicated = dedicatedSubs.filterNotNull()
                    return withContext(Dispatchers.Default) {
                        val playable =
                            directFrom(completed).filter {
                                it.url.startsWith("http://") || it.url.startsWith("https://")
                            }
                        val streams =
                            if (type == "tv") playable else applyStreamRules(playable)
                        StreamBundle(
                            streams = streams,
                            subtitles = subtitlesFrom(completed, dedicated),
                        )
                    }
                }

                val gate = Mutex()
                val streamJobs =
                    streamAddons.mapIndexed { index, addon ->
                        launch {
                            val result =
                                runCatching { api.fetchStreams(addon.baseUrl, type, videoId) }
                                    .onFailure {
                                        Timber.v(it, "Streams %s/%s from %s failed", type, videoId, addon.name)
                                    }.getOrNull()
                            if (result != null) {
                                gate.withLock {
                                    results[index] = addon to result
                                    onBundle(snapshot())
                                }
                            }
                        }
                    }
                val imdbId = IMDB_ID_REGEX.find(metaId)?.value ?: IMDB_ID_REGEX.find(videoId)?.value
                val subtitleJobs =
                    if (imdbId == null) {
                        emptyList()
                    } else {
                        subtitleAddons.mapIndexed { index, addon ->
                            launch {
                                val subs =
                                    runCatching { api.fetchSubtitles(addon.baseUrl, type, imdbId) }
                                        .onFailure {
                                            Timber.v(it, "Subtitles %s from %s failed", imdbId, addon.name)
                                        }.getOrNull()
                                if (subs != null) {
                                    gate.withLock {
                                        dedicatedSubs[index] = subs
                                        onBundle(snapshot())
                                    }
                                }
                            }
                        }
                    }
                // Stream-wait budget (v0.3.26, Settings → Streams):
                // the user's picked cap on how long this fan-out may
                // run before the app shows what it has. 0 = Default —
                // no overall cap, today's behaviour (each addon keeps
                // its own HTTP timeout). When the cap fires, the jobs
                // are cancelled and the bundle is built from whatever
                // settled in time — the progressive snapshots the UI
                // already showed stay valid.
                val waitBudgetMs =
                    uiPrefs.streamWaitSeconds.value
                        .takeIf { it > 0 }
                        ?.let { it * 1_000L }
                if (waitBudgetMs != null) {
                    val settled =
                        kotlinx.coroutines.withTimeoutOrNull(waitBudgetMs) {
                            (streamJobs + subtitleJobs).joinAll()
                            true
                        }
                    if (settled == null) {
                        (streamJobs + subtitleJobs).forEach { it.cancel() }
                    }
                } else {
                    (streamJobs + subtitleJobs).joinAll()
                }

                val finalResults = results.filterNotNull()
                val directStreams = directFrom(finalResults)
                val streams =
                    if (type == "tv") {
                        directStreams
                    } else {
                        // Batch B: the debrid pass stays on this
                        // context (it suspends on network calls); only
                        // the pure rules sort of its result moves to
                        // Dispatchers.Default, like the snapshots above.
                        val resolved = resolveDebridStreams(directStreams)
                        withContext(Dispatchers.Default) { applyStreamRules(resolved) }
                    }
                val bundle =
                    StreamBundle(
                        streams = streams,
                        subtitles = subtitlesFrom(finalResults, dedicatedSubs.filterNotNull()),
                    )
                onBundle(bundle)
                bundle
            }

        // ---- PrePlay pocket (v0.3.26 batch 6) ----
        //
        // The pocket: stream bundles resolved BEFORE the Play press
        // (details page open; next episode while one plays), held in
        // memory only. At the press, [loadStreamsForPlay] serves the
        // pocket as-is while it is fresh ([PrePlayLogic.FRESH_MS])
        // and re-fetches ONLY the addons whose data went stale —
        // the spec's "refresh only stale addons at press".
        //
        // Debrid preparation rides the same pass honestly: in this
        // tree the debrid pass is part of loadStreams itself, so a
        // pocketed bundle's infoHash rows already carry their
        // resolved direct links where the provider answered from
        // cache — there is no separate unrestrict step to pre-run.
        // The freshness window is the prepared link's validity
        // gate: past it, the press re-runs the full pass for the
        // stale addons instead of trusting an old link.

        /** One pocketed bundle + when each addon inside it settled. */
        private class PocketEntry(
            val bundle: StreamBundle,
            val settledAtMs: Map<String, Long>,
            val fetchedAtMs: Long,
        )

        private val pocket = ConcurrentHashMap<String, PocketEntry>()
        private val pocketInFlight = ConcurrentHashMap.newKeySet<String>()
        private val pocketScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        private fun pocketKey(
            type: String,
            videoId: String,
        ): String = "$type|$videoId"

        /**
         * Warm the pocket for one title (fire-and-forget; failures
         * are silent by spec). No-ops when PrePlay is off, for Live
         * TV, while a fresh entry already exists, or while the same
         * title is already being resolved.
         */
        fun preResolve(
            type: String,
            videoId: String,
            metaId: String,
        ) {
            if (!uiPrefs.prePlayEnabled.value) return
            if (type == "tv") return
            val key = pocketKey(type, videoId)
            val existing = pocket[key]
            if (existing != null &&
                PrePlayLogic.isFresh(existing.fetchedAtMs, System.currentTimeMillis())
            ) {
                return
            }
            if (!pocketInFlight.add(key)) return
            pocketScope.launch(CrashReports.backgroundScopeHandler) {
                try {
                    // Per-addon settle times: the first snapshot a
                    // stream's source appears in is (to the moment
                    // the snapshot fired) when its addon answered.
                    val settled = ConcurrentHashMap<String, Long>()
                    val bundle =
                        loadStreamsProgressive(type, videoId, metaId) { snapshot ->
                            val now = System.currentTimeMillis()
                            snapshot.streams
                                .mapNotNull { it.sourceId }
                                .distinct()
                                .forEach { id -> settled.putIfAbsent(id, now) }
                        }
                    if (bundle.streams.isNotEmpty()) {
                        pocket[key] =
                            PocketEntry(bundle, settled.toMap(), System.currentTimeMillis())
                        trimPocket()
                    }
                } catch (e: Exception) {
                    Timber.v(e, "PrePlay pre-resolve failed for %s", key)
                } finally {
                    pocketInFlight.remove(key)
                }
            }
        }

        private fun trimPocket() {
            while (pocket.size > POCKET_MAX_ENTRIES) {
                val oldest =
                    pocket.entries.minByOrNull { it.value.fetchedAtMs }?.key ?: break
                pocket.remove(oldest)
            }
        }

        /**
         * The Play-press load: the pocket when PrePlay is on and an
         * entry exists — fresh entries as-is; stale ones refreshed
         * per-addon (kept streams + fresh fetches for the stale
         * addons only, then the same debrid pass + rules the full
         * load applies). Streams from addons no longer enabled are
         * dropped; an entry emptied that way falls back to the full
         * load. Anything else is exactly [loadStreams].
         */
        suspend fun loadStreamsForPlay(
            type: String,
            videoId: String,
            metaId: String,
        ): StreamBundle {
            val key = pocketKey(type, videoId)
            val entry = pocket[key]
            if (!uiPrefs.prePlayEnabled.value || entry == null) {
                return loadStreams(type, videoId, metaId)
            }
            val now = System.currentTimeMillis()
            val enabledIds =
                addonStore.addons.value.filter { it.enabled }.map { it.id }.toSet()
            val keptStreams = entry.bundle.streams.filter { it.sourceId in enabledIds }
            if (keptStreams.isEmpty()) {
                return loadStreams(type, videoId, metaId)
            }
            val stale = PrePlayLogic.staleAddons(enabledIds, entry.settledAtMs, now)
            if (stale.isEmpty()) {
                return StreamBundle(keptStreams, entry.bundle.subtitles)
            }
            val staleAddons =
                addonStore.addons.value.filter { it.enabled && it.id in stale }
            val torboxKey = uiPrefs.torboxApiKey.value
            val realDebridKey = uiPrefs.realDebridApiKey.value
            val debridConfigured =
                torboxKey != null || realDebridKey != null ||
                    uiPrefs.premiumizeApiKey.value != null ||
                    uiPrefs.allDebridApiKey.value != null ||
                    uiPrefs.debridLinkApiKey.value != null ||
                    uiPrefs.offcloudApiKey.value != null
            val freshByAddon =
                supervisorScope {
                    staleAddons
                        .map { addon ->
                            async {
                                // Same per-addon shape the full load
                                // uses: fetch by base URL, keep direct
                                // links (+ infoHash rows when a debrid
                                // key exists), stamp the source.
                                val result =
                                    runCatching {
                                        api.fetchStreams(addon.baseUrl, type, videoId)
                                    }.getOrNull()
                                val part =
                                    result
                                        ?.streams
                                        ?.filter {
                                            it.url.startsWith("http://") ||
                                                it.url.startsWith("https://") ||
                                                (debridConfigured && it.infoHash != null)
                                        }?.map {
                                            it.copy(sourceName = addon.name, sourceId = addon.id)
                                        }
                                        ?: emptyList()
                                addon.id to part
                            }
                        }.awaitAll()
                }
            val merged = keptStreams + freshByAddon.flatMap { it.second }
            val resolved =
                if (type == "tv") {
                    merged
                } else {
                    applyStreamRules(
                        resolveDebridStreams(merged),
                    )
                }
            val refreshedAt = System.currentTimeMillis()
            val newSettled = entry.settledAtMs.toMutableMap()
            freshByAddon.forEach { (id, _) -> newSettled[id] = refreshedAt }
            pocket[key] =
                PocketEntry(
                    StreamBundle(resolved, entry.bundle.subtitles),
                    newSettled.filterKeys { it in enabledIds },
                    refreshedAt,
                )
            return StreamBundle(resolved, entry.bundle.subtitles)
        }

        /**
         * Debrid pass (phone parity): resolve infoHash-only streams
         * through the configured providers in the phone's order —
         * TorBox → Real-Debrid → Premiumize → AllDebrid →
         * Debrid-Link → Offcloud — in parallel (max 3 at a time,
         * the stream-wait budget or 45 s each). Cache-first always:
         * a provider is only asked about torrents it has cached.
         * Resolved entries replace their placeholders in place and
         * carry the provider tag in their source name. Unresolved
         * placeholders are dropped — the TV player needs direct
         * links.
         */
        private suspend fun resolveDebridStreams(streams: List<StreamItem>): List<StreamItem> {
            val torboxKey = uiPrefs.torboxApiKey.value
            val realDebridKey = uiPrefs.realDebridApiKey.value
            val premiumizeKey = uiPrefs.premiumizeApiKey.value
            val allDebridKey = uiPrefs.allDebridApiKey.value
            val debridLinkKey = uiPrefs.debridLinkApiKey.value
            val offcloudKey = uiPrefs.offcloudApiKey.value
            if (torboxKey == null && realDebridKey == null && premiumizeKey == null &&
                allDebridKey == null && debridLinkKey == null && offcloudKey == null
            ) {
                return streams
            }
            val pending = streams.filter { it.infoHash != null && it.url.startsWith("infohash:") }
            if (pending.isEmpty()) return streams
            val torbox = torboxKey?.let { com.github.damontecres.wholphin.plavio.debrid.TorBoxApi(it) }
            val realDebrid =
                realDebridKey?.let { com.github.damontecres.wholphin.plavio.debrid.RealDebridApi(it) }
            val premiumize =
                premiumizeKey?.let { com.github.damontecres.wholphin.plavio.debrid.PremiumizeApi(it) }
            val allDebrid =
                allDebridKey?.let { com.github.damontecres.wholphin.plavio.debrid.AllDebridApi(it) }
            val debridLink =
                debridLinkKey?.let { com.github.damontecres.wholphin.plavio.debrid.DebridLinkApi(it) }
            val offcloud =
                offcloudKey?.let { com.github.damontecres.wholphin.plavio.debrid.OffcloudApi(it) }
            val resolved = kotlinx.coroutines.sync.Mutex()
            val byIdentity = HashMap<String, StreamItem>()
            // The stream-wait budget names this pass too (v0.3.26):
            // a picked cap replaces the historic 45 s per-item budget.
            val debridBudgetMs =
                uiPrefs.streamWaitSeconds.value
                    .takeIf { it > 0 }
                    ?.let { it * 1_000L }
                    ?: 45_000L
            kotlinx.coroutines.coroutineScope {
                val gate = kotlinx.coroutines.sync.Semaphore(3)
                pending.forEach { stream ->
                    launch {
                        gate.acquire()
                        try {
                            val url =
                                kotlinx.coroutines.withTimeoutOrNull(debridBudgetMs) {
                                    // One provider attempt: on a
                                    // resolved link, record the
                                    // replacement (provider tag in
                                    // the source name) and hand the
                                    // URL back; anything else falls
                                    // through to the next provider.
                                    suspend fun attempt(
                                        tag: String,
                                        resolve: suspend () -> String?,
                                    ): String? {
                                        val link = runCatching { resolve() }.getOrNull() ?: return null
                                        resolved.withLock {
                                            byIdentity[streamIdentity(stream)] =
                                                stream.copy(
                                                    url = link,
                                                    infoHash = null,
                                                    sourceName = tag + (stream.sourceName ?: ""),
                                                )
                                        }
                                        return link
                                    }
                                    var found: String? = null
                                    if (torbox != null && found == null) {
                                        found =
                                            attempt("⚡ TorBox · ") {
                                                val result =
                                                    torbox.resolveCachedDetailed(
                                                        stream.infoHash!!,
                                                        stream.fileIdx,
                                                        stream.filePath,
                                                    )
                                                (result as? com.github.damontecres.wholphin.plavio.debrid.DebridResolveResult.Resolved)?.url
                                            }
                                    }
                                    if (realDebrid != null && found == null) {
                                        found =
                                            attempt("⚡ RD · ") {
                                                realDebrid.resolveCachedToHttp(
                                                    stream.infoHash!!,
                                                    stream.fileIdx,
                                                    stream.filePath,
                                                )
                                            }
                                    }
                                    if (premiumize != null && found == null) {
                                        found =
                                            attempt("⚡ Premiumize · ") {
                                                val result =
                                                    premiumize.resolveCachedDetailed(
                                                        stream.infoHash!!,
                                                        stream.fileIdx,
                                                        stream.filePath,
                                                    )
                                                (result as? com.github.damontecres.wholphin.plavio.debrid.DebridResolveResult.Resolved)?.url
                                            }
                                    }
                                    if (allDebrid != null && found == null) {
                                        found =
                                            attempt("⚡ AllDebrid · ") {
                                                val result =
                                                    allDebrid.resolveCachedDetailed(
                                                        stream.infoHash!!,
                                                        stream.fileIdx,
                                                        stream.filePath,
                                                    )
                                                (result as? com.github.damontecres.wholphin.plavio.debrid.DebridResolveResult.Resolved)?.url
                                            }
                                    }
                                    if (debridLink != null && found == null) {
                                        found =
                                            attempt("⚡ Debrid-Link · ") {
                                                val result =
                                                    debridLink.resolveCachedDetailed(
                                                        stream.infoHash!!,
                                                        stream.fileIdx,
                                                        stream.filePath,
                                                    )
                                                (result as? com.github.damontecres.wholphin.plavio.debrid.DebridResolveResult.Resolved)?.url
                                            }
                                    }
                                    if (offcloud != null && found == null) {
                                        found =
                                            attempt("⚡ Offcloud · ") {
                                                val result =
                                                    offcloud.resolveCachedDetailed(
                                                        stream.infoHash!!,
                                                        stream.fileIdx,
                                                        stream.filePath,
                                                    )
                                                (result as? com.github.damontecres.wholphin.plavio.debrid.DebridResolveResult.Resolved)?.url
                                            }
                                    }
                                    found
                                }
                            if (url == null) {
                                resolved.withLock {
                                    byIdentity[streamIdentity(stream)] = stream.copy(url = "")
                                }
                            }
                        } finally {
                            gate.release()
                        }
                    }
                }
            }
            return streams.mapNotNull { stream ->
                if (stream.infoHash != null && stream.url.startsWith("infohash:")) {
                    val replacement = byIdentity[streamIdentity(stream)]
                    when {
                        replacement == null -> stream
                        replacement.url.isEmpty() -> null
                        else -> replacement
                    }
                } else {
                    stream
                }
            }
        }

        private fun streamIdentity(stream: StreamItem): String =
            listOf(
                stream.infoHash.orEmpty(),
                stream.fileIdx?.toString().orEmpty(),
                stream.filePath.orEmpty(),
                stream.sourceId.orEmpty(),
            ).joinToString("|")

        /**
         * Streams rules (phone parity): TorBox ⚡ streams first when
         * TorBox is linked, then the user's quality order (unknown
         * quality last, stable). No per-source cap (removed v0.3.9,
         * owner order): every stream an addon returns stays eligible.
         */
        private fun applyStreamRules(streams: List<StreamItem>): List<StreamItem> {
            val order = uiPrefs.qualityOrder.value
            val torboxLinked = uiPrefs.torboxApiKey.value != null
            // Batch B (perf refactor, output unchanged):
            // canonicalStreamQuality() runs a regex over a stream's
            // name/title, and the comparator below used to re-run it
            // on every comparison (O(n log n) times). Precompute each
            // stream's rank ONCE here instead. The map is keyed by
            // instance identity, so duplicate-but-equal rows each
            // keep their own entry; canonicalStreamQuality is pure,
            // so every precomputed rank equals the value the
            // comparator used to compute, and the stable sort yields
            // exactly the same order as before.
            val qualityRank = java.util.IdentityHashMap<StreamItem, Int>(streams.size)
            for (stream in streams) {
                val idx = order.indexOf(canonicalStreamQuality(stream))
                qualityRank[stream] = if (idx >= 0) idx else Int.MAX_VALUE
            }
            return streams.sortedWith(
                compareByDescending<StreamItem> { stream ->
                    if (torboxLinked &&
                        (stream.sourceName?.contains("TorBox") == true ||
                            stream.title?.contains("⚡") == true ||
                            stream.name?.contains("⚡") == true)
                    ) {
                        1
                    } else {
                        0
                    }
                }.thenBy { stream ->
                    qualityRank.getValue(stream)
                },
            )
        }

        /**
         * Autoplay pick: quality only (v0.3.9, owner order). With the
         * Streams rule on, the pick honours the rule instead of
         * leaking around it.
         *
         * Quality walk: the quality the user selected in Settings
         * first; if none exists, step DOWN the ladder (e.g. 720p ->
         * 480p) before ever stepping UP to a heavier stream. Unknown
         * quality sorts last.
         *
         * File size plays no part in the WALK itself: no cap, no
         * filtering, and streams with an unknown size are full
         * candidates (the v0.3.7 size rule was removed — the quality
         * the user picked is the walk's criterion). The pick is the
         * first stream in quality-walk order, so it can never
         * dead-end. (v0.3.32: for play picks the weak-device guard
         * breaks ties WITHIN a walk step — see
         * [pickBestStreamWeakGuarded]; the walk order itself is
         * never overridden.)
         * Rule off: play picks take the weak-device guard pick
         * (v0.3.32); the plain best-stream pick stands unchanged
         * for downloads (weakDeviceGuard = false).
         *
         * Binge anchoring (v0.3.26): when the caller passes the
         * previous episode's pick as the anchor (its addon identity
         * and canonical quality), a stream from the SAME addon in the
         * SAME quality family wins — picked by this same logic
         * restricted to the anchored pool. It is a preference only,
         * never a filter: an anchor that yields no candidate (addon
         * absent, or that addon has no stream in the anchor's quality
         * family) falls through to the plain pick below, unchanged.
         * Callers that pass no anchor (manual picks, failover) get
         * exactly the pre-anchor behaviour.
         */
        fun pickForAutoplay(
            streams: List<StreamItem>,
            anchorSourceId: String? = null,
            anchorSourceName: String? = null,
            anchorQuality: String? = null,
            /**
             * Weak-device guard (v0.3.32): play picks pass true
             * (the default) — see [pickBestStreamWeakGuarded]. The
             * download pick passes false: a download is not started
             * by the player, so its semantics stay exactly the
             * pre-guard ones.
             */
            weakDeviceGuard: Boolean = true,
        ): StreamItem? {
            val playable = streams.filter { !it.url.startsWith("infohash:") && it.url.isNotBlank() }
            if (playable.isEmpty()) return null
            if (anchorQuality != null && (anchorSourceId != null || anchorSourceName != null)) {
                val anchored =
                    playable.filter { stream ->
                        canonicalStreamQuality(stream) == anchorQuality &&
                            (
                                (anchorSourceId != null && stream.sourceId == anchorSourceId) ||
                                    (anchorSourceName != null && stream.sourceName == anchorSourceName)
                                )
                    }
                if (anchored.isNotEmpty()) {
                    pickFromPlayable(anchored, weakDeviceGuard)?.let {
                        return applyHdrFallback(playable, it)
                    }
                }
            }
            return pickFromPlayable(playable, weakDeviceGuard)?.let {
                applyHdrFallback(playable, it)
            }
        }

        /**
         * Dolby Vision fallback (batch 6): every automatic pick
         * funnels through here — a DV pick on a chain without DV
         * support steps down to the title's best HDR10, then SDR
         * copy (see [HdrFallback]); on a DV-capable chain, and for
         * non-DV picks, the pick stands untouched.
         */
        private fun applyHdrFallback(
            playable: List<StreamItem>,
            chosen: StreamItem,
        ): StreamItem =
            HdrFallback.pickWithFallback(
                playable,
                chosen,
                hdrSupport?.dolbyVisionSupported ?: true,
            )

        /**
         * Download pick (v0.3.26 batch 6): the autoplay pick over
         * the pool the Downloads screen's default-quality preference
         * selects (see [downloadPool] — a specific quality restricts
         * the pool to that quality, with the full list as the
         * never-dead-end fallback; "Auto" is the plain autoplay
         * pick). Used ONLY where a download starts without an
         * explicit pick (season download, auto-downloaded next
         * episode); a stream the user tapped Download on is never
         * re-picked.
         */
        fun pickForDownload(streams: List<StreamItem>): StreamItem? =
            pickForAutoplay(
                downloadPool(streams, uiPrefs.downloadQuality.value),
                weakDeviceGuard = false,
            )

        /** The pick itself, over an already-filtered playable pool. */
        private fun pickFromPlayable(
            playable: List<StreamItem>,
            weakDeviceGuard: Boolean,
        ): StreamItem? {
            if (!uiPrefs.streamAutoplay.value) {
                // Default path (no Streams rule): the plain pick
                // took the heaviest row in the list — since the
                // 2026-11-16 hub-2160p server fix that is routinely
                // a 40+ GB DV REMUX a small TV cannot even start
                // (the owner's Moana report, v0.3.31). Play picks
                // take the weak-device guard instead; it is a
                // ranking, never a filter, so it cannot dead-end.
                return if (weakDeviceGuard) {
                    pickBestStreamWeakGuarded(playable)
                } else {
                    pickBestStream(playable)
                }
            }
            val order = uiPrefs.qualityOrder.value
            val prefQ = uiPrefs.autoplayQuality.value
            // Quality-walk order: preferred first, then lighter, then
            // heavier, then unknown. With "Auto" the user's own quality
            // order is the walk.
            val walk: List<String?> =
                if (prefQ != "Auto") {
                    val ladder = QUALITY_ORDER_OPTIONS
                    val prefIdx = ladder.indexOf(prefQ)
                    val lighter =
                        if (prefIdx >= 0) ladder.subList(prefIdx + 1, ladder.size) else emptyList()
                    val heavier =
                        if (prefIdx >= 0) ladder.subList(0, prefIdx) else ladder
                    listOf(prefQ) + lighter + heavier + listOf(null)
                } else {
                    order + listOf(null)
                }
            val qualityRank: (StreamItem) -> Int = { stream ->
                val q = canonicalStreamQuality(stream)
                walk.indexOf(q).takeIf { it >= 0 } ?: Int.MAX_VALUE
            }
            // Stable sort by quality walk only (addon order breaks ties).
            // Weak-device guard (v0.3.32): the user's own quality
            // walk stays the PRIMARY key — an explicit Settings
            // quality rule is never overridden — but within one
            // walk step the guard breaks ties toward the copy a
            // small TV starts most easily (SDR before HDR/DV,
            // MP4/HLS before MKV, smaller file before bigger).
            return if (weakDeviceGuard) {
                playable
                    .sortedWith(
                        compareBy<StreamItem>(qualityRank)
                            .thenBy { streamHdrClass(it) }
                            .thenBy { streamContainerClass(it) }
                            .thenBy { it.videoSize ?: Long.MAX_VALUE },
                    )
                    .firstOrNull()
            } else {
                playable.sortedWith(compareBy(qualityRank)).firstOrNull()
            }
        }

        /**
         * In-player "Fetch subtitles online": query every enabled
         * subtitles addon's dedicated endpoint for this title (the same
         * source [loadStreams] merges at resolve time). Deduped by URL;
         * the caller filters out subtitles the request already has.
         */
        suspend fun fetchOnlineSubtitles(
            type: String,
            videoId: String,
            metaId: String,
        ): List<Subtitle> =
            coroutineScope {
                val imdbId =
                    IMDB_ID_REGEX.find(metaId)?.value ?: IMDB_ID_REGEX.find(videoId)?.value
                        ?: return@coroutineScope emptyList()
                val jobs =
                    enabledAddons
                        .filter { it.manifest.hasSubtitles }
                        .map { addon ->
                            async {
                                runCatching { api.fetchSubtitles(addon.baseUrl, type, imdbId) }
                                    .onFailure {
                                        Timber.v(it, "Online subtitles %s from %s failed", imdbId, addon.name)
                                    }.getOrNull()
                            }
                        }
                val byUrl = LinkedHashMap<String, Subtitle>()
                jobs.awaitAll().filterNotNull().flatten().forEach { byUrl.putIfAbsent(it.url, it) }
                byUrl.values.toList()
            }

        /**
         * Resolves a Live channel into a playable request (best stream),
         * carrying the sibling channel list for in-player zapping. Used
         * by the Live tab's tap-to-play and by the player's zap buttons.
         */
        suspend fun loadChannelRequest(
            channel: TvChannelRef,
            siblings: List<TvChannelRef>,
        ): PlaybackRequest? {
            val bundle =
                runCatching { loadStreams(channel.type, channel.metaId, channel.metaId) }
                    .getOrNull() ?: return null
            val best = pickBestStream(bundle.streams) ?: return null
            val ref =
                com.github.damontecres.wholphin.plavio.ui
                    .StreamsRef(
                        type = channel.type,
                        videoId = channel.metaId,
                        metaId = channel.metaId,
                        title = channel.name,
                        poster = channel.poster,
                    )
            return buildPlaybackRequest(ref, bundle, best).copy(
                liveChannel = channel,
                liveChannels = siblings,
            )
        }

        // --------------------------------------------------------------
        // Metadata flexibility (owner's order, same rules as the phone):
        // related rows and actor pages follow whichever addon serves the
        // title — /related + /person on the meta addons in preference
        // order first (PlavioMeta is simply the richest), then generic
        // fallbacks built from standard catalog/search data. No feature
        // is hardwired to one addon, and no TMDB key is involved.
        // --------------------------------------------------------------

        private fun isPlavioMeta(addon: InstalledAddon): Boolean =
            addon.id.contains("plaviometa", ignoreCase = true) ||
                addon.baseUrl.contains("plaviometa", ignoreCase = true)

        private fun isCinemeta(addon: InstalledAddon): Boolean =
            addon.id.contains("cinemeta", ignoreCase = true) ||
                addon.baseUrl.contains("cinemeta", ignoreCase = true)

        private fun metaRank(addon: InstalledAddon): Int =
            when {
                isPlavioMeta(addon) -> 0
                isCinemeta(addon) -> 1
                else -> 2
            }

        /** Meta addons for [type], the hinted (serving) addon first, then by rank. */
        fun metaAddonsFor(
            type: String,
            hintBaseUrl: String? = null,
        ): List<InstalledAddon> =
            enabledAddons
                .filter { addon ->
                    addon.manifest.hasMeta &&
                        (addon.manifest.types.isEmpty() || type in addon.manifest.types)
                }.sortedWith(
                    compareByDescending<InstalledAddon> { it.baseUrl == hintBaseUrl }
                        .thenBy { metaRank(it) },
                )

        private fun metaAddonsByRank(): List<InstalledAddon> =
            enabledAddons
                .filter { it.manifest.hasMeta }
                .sortedWith(compareBy<InstalledAddon> { metaRank(it) })

        /**
         * "More like this" + "More from <actor>" sections for a title.
         * /related is tried on every meta addon in preference order;
         * when no addon serves it, the rows are built app-side from
         * standard protocol data (genre catalogs + search).
         */
        suspend fun getRelated(
            type: String,
            id: String,
            hintBaseUrl: String? = null,
        ): List<RelatedSection> {
            val addons = metaAddonsFor(type, hintBaseUrl)
            for (addon in addons) {
                val sections =
                    withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                        runCatching { api.fetchRelated(addon.baseUrl, type, id) }.getOrNull()
                    }
                if (!sections.isNullOrEmpty()) return sections
            }
            return buildRelatedFallback(type, id, hintBaseUrl, addons)
        }

        private suspend fun buildRelatedFallback(
            type: String,
            id: String,
            hintBaseUrl: String?,
            metaAddons: List<InstalledAddon>,
        ): List<RelatedSection> {
            val meta = loadMeta(hintBaseUrl ?: "", type, id) ?: return emptyList()
            val sections = mutableListOf<RelatedSection>()

            if (meta.genres.isNotEmpty() && metaAddons.isNotEmpty()) {
                val genre = meta.genres.first()
                val similar = LinkedHashMap<String, MetaPreview>()
                for (addon in metaAddons.take(2)) {
                    val genreCatalogs =
                        addon.manifest.catalogs
                            .filter {
                                it.type == type && it.extra.any { e -> e.equals("genre", true) }
                            }.take(2)
                    for (catalog in genreCatalogs) {
                        val metas =
                            withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                                runCatching {
                                    api.fetchCatalogGenre(addon.baseUrl, type, catalog.id, genre)
                                }.getOrNull()
                            } ?: continue
                        metas.forEach { m -> if (m.id != id) similar.putIfAbsent(m.id, m) }
                    }
                }
                runCatching { searchCatalogs(genre) }.getOrDefault(emptyList())
                    .forEach { cm ->
                        if (cm.meta.type == type && cm.meta.id != id) {
                            similar.putIfAbsent(cm.meta.id, cm.meta)
                        }
                    }
                val genreSet = meta.genres.map { it.lowercase() }.toSet()
                val picks =
                    similar.values
                        .filter { m ->
                            m.genres.isEmpty() || m.genres.any { it.lowercase() in genreSet }
                        }.take(20)
                if (picks.isNotEmpty()) {
                    sections +=
                        RelatedSection(id = "fallback_similar", title = "More like this", metas = picks)
                }
            }

            val leadActor = meta.cast.firstOrNull { it.name.isNotBlank() }
            if (leadActor != null) {
                val seen = sections.flatMap { s -> s.metas.map { it.id } }.toSet() + id
                val fromActor =
                    runCatching { searchCatalogs(leadActor.name) }
                        .getOrDefault(emptyList())
                        .map { it.meta }
                        .filter { it.id !in seen }
                        .distinctBy { it.id }
                        .take(20)
                if (fromActor.isNotEmpty()) {
                    sections +=
                        RelatedSection(
                            id = "fallback_actor",
                            title = "More from ${leadActor.name}",
                            metas = fromActor,
                        )
                }
            }
            return sections
        }

        /**
         * Actor filmography. /person is tried on every meta addon in
         * preference order; when none serves it, [name] unlocks the
         * generic fallback: the addons' own search by actor name, split
         * into movies/series.
         */
        suspend fun getPerson(
            personId: Int,
            name: String? = null,
        ): PersonDetail? {
            if (personId > 0) {
                for (addon in metaAddonsByRank()) {
                    val person =
                        withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                            runCatching { api.fetchPerson(addon.baseUrl, personId) }.getOrNull()
                        }
                    if (person != null && (person.movies.isNotEmpty() || person.series.isNotEmpty())) {
                        return person
                    }
                }
            }
            val personName = name?.takeIf { it.isNotBlank() } ?: return null
            val found = runCatching { searchCatalogs(personName) }.getOrDefault(emptyList())
            if (found.isEmpty()) return null
            val movies =
                found.filter { it.meta.type == "movie" }.map { it.meta }.distinctBy { it.id }.take(40)
            val series =
                found.filter { it.meta.type == "series" }.map { it.meta }.distinctBy { it.id }.take(40)
            if (movies.isEmpty() && series.isEmpty()) return null
            return PersonDetail(
                id = personId,
                name = personName,
                photo = null,
                movies = movies,
                series = series,
            )
        }

        /**
         * One person's photo from the meta addons' /person route
         * (v0.3.13): the Detail cast arrives as names + TMDB ids (the
         * ids ride the meta's actor links), and the photo lives on
         * /person/<id>. First addon that answers with a photo wins;
         * null when none serves one — the chip keeps its initial.
         */
        suspend fun fetchPersonPhoto(personId: Int): String? {
            if (personId <= 0) return null
            for (addon in metaAddonsByRank()) {
                val person =
                    withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                        runCatching { api.fetchPerson(addon.baseUrl, personId) }.getOrNull()
                    }
                val photo = person?.photo?.takeIf { it.isNotBlank() }
                if (photo != null) return photo
            }
            return null
        }

        /**
         * People matching a search query (search by actor). The
         * /person-search route is asked on every meta addon in
         * preference order — an answer from a supporting addon, even an
         * empty one, is final. Only when NO meta addon serves the route
         * does the cast-scan fallback run.
         */
        suspend fun searchPeople(query: String): List<CastMember> {
            val q = query.trim()
            if (q.length < 2) return emptyList()
            for (addon in metaAddonsByRank()) {
                val found =
                    withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                        runCatching { api.fetchPersonSearch(addon.baseUrl, q) }.getOrNull()
                    }
                if (found != null) return found.take(10)
            }
            return searchPeopleFromCast(q)
        }

        /** Cast-scan fallback for installs whose meta addons don't serve /person-search. */
        private suspend fun searchPeopleFromCast(q: String): List<CastMember> {
            val results = runCatching { searchCatalogs(q) }.getOrDefault(emptyList()).take(6)
            if (results.isEmpty()) return emptyList()
            val people = LinkedHashMap<String, CastMember>()
            for (cm in results) {
                val meta =
                    runCatching { loadMeta(cm.baseUrl, cm.meta.type, cm.meta.id) }.getOrNull()
                        ?: continue
                for (member in meta.cast) {
                    if (member.name.isBlank()) continue
                    if (!member.name.contains(q, ignoreCase = true)) continue
                    val key =
                        if (member.id > 0) "id:${member.id}" else "name:${member.name.lowercase()}"
                    val existing = people[key]
                    if (existing == null) {
                        people[key] = member
                    } else if (existing.photo.isNullOrBlank() && !member.photo.isNullOrBlank()) {
                        people[key] = member
                    }
                }
                if (people.size >= 10) break
            }
            return people.values.take(10)
        }

        // --------------------------------------------------------------
        // Live TV
        // --------------------------------------------------------------

        /** Addons that can serve Live rows right now. */
        fun liveAddons(): List<InstalledAddon> =
            enabledAddons.filter { addon ->
                addon.manifest.catalogs.any { it.type == "tv" }
            }

        /**
         * One row per TV catalog of every enabled addon. Sports
         * categories stay separate top-level rows (the house rule from
         * the phone's Live tab) — rows are never merged or filtered.
         */
        suspend fun loadLiveRows(): List<CatalogRow> =
            coroutineScope {
                val jobs =
                    liveAddons().flatMap { addon ->
                        addon.manifest.catalogs
                            .filter { it.type == "tv" }
                            .map { catalog ->
                                async {
                                    val items =
                                        runCatching {
                                            api.fetchCatalog(addon.baseUrl, catalog.type, catalog.id)
                                        }.onFailure {
                                            Timber.v(it, "Live catalog %s from %s failed", catalog.id, addon.name)
                                        }.getOrNull()
                                    if (items.isNullOrEmpty()) {
                                        null
                                    } else {
                                        CatalogRow(
                                            addonId = addon.id,
                                            addonName = addon.name,
                                            baseUrl = addon.baseUrl,
                                            catalogName = catalog.name,
                                            type = catalog.type,
                                            catalogId = catalog.id,
                                            items = items,
                                        )
                                    }
                                }
                            }
                    }
                jobs.awaitAll().filterNotNull()
            }

        private companion object {
            val IMDB_ID_REGEX = Regex("""tt\d+""")
            const val META_FETCH_TIMEOUT_MS = 8_000L

            /** PrePlay pocket cap — oldest entries evict first. */
            const val POCKET_MAX_ENTRIES = 8
        }
    }

/** Quality rank for autoplay's best-stream pick (higher wins). */
fun streamQualityRank(stream: StreamItem): Int =
    when (streamQualityLabel(stream)?.uppercase()) {
        "2160P", "4K" -> 6
        "1440P" -> 5
        "1080P" -> 4
        "720P" -> 3
        "480P" -> 2
        "360P" -> 1
        else -> 0
    }

/**
 * Autoplay's best-stream pick (the phone's behaviour in TV form): the
 * highest-quality direct stream; ties keep the addons' own order.
 */
fun pickBestStream(streams: List<StreamItem>): StreamItem? =
    streams
        .withIndex()
        .maxWithOrNull(
            compareBy<IndexedValue<StreamItem>> { streamQualityRank(it.value) }
                .thenBy { -(it.value.videoSize ?: 0L) }
                .thenBy { -it.index },
        )?.value

/** HDR class for the weak-device guard: SDR (0) before HDR10 (1) before Dolby Vision (2). */
fun streamHdrClass(stream: StreamItem): Int =
    when (HdrFallback.tierOf(stream)) {
        HdrTier.SDR -> 0
        HdrTier.HDR10 -> 1
        HdrTier.DOLBY_VISION -> 2
    }

/**
 * Container class for the weak-device guard: 0 = light (MP4 / HLS —
 * the formats every TV decoder starts cheaply), 1 = unknown, 2 =
 * heavy (MKV / WebM / AVI — the REMUX wrappers). Read from the
 * filename first (the addon's own label for the file), then the
 * URL path, then the MIME hint.
 */
fun streamContainerClass(stream: StreamItem): Int {
    fun pathOf(raw: String): String =
        raw.substringBefore('?').substringBefore('#').lowercase()
    val paths = listOfNotNull(stream.filename?.let { pathOf(it) }, pathOf(stream.url))
    return when {
        paths.any { it.endsWith(".mp4") || it.endsWith(".m3u8") } ||
            stream.mimeType?.contains("mpegurl", ignoreCase = true) == true ||
            stream.mimeType?.equals("video/mp4", ignoreCase = true) == true -> 0
        paths.any {
            it.endsWith(".mkv") || it.endsWith(".webm") || it.endsWith(".avi")
        } -> 2
        else -> 1
    }
}

/** Quality class for the weak-device guard: ≤1080p first (1080p best), then down the ladder, unknown, then the >1080p classes last. */
private fun weakGuardQualityClass(stream: StreamItem): Int =
    when (streamQualityRank(stream)) {
        4 -> 0 // 1080p
        3 -> 1 // 720p
        2 -> 2 // 480p
        1 -> 3 // 360p
        0 -> 4 // unknown
        5 -> 5 // 1440p
        else -> 6 // 2160p / 4K
    }

/**
 * Weak-device auto pick (v0.3.32, the owner's Moana report): the
 * plain [pickBestStream] takes the highest quality and then the
 * LARGEST file — on a 512 MB TV that lands on a 48.77 GB Dolby
 * Vision REMUX the device cannot start, while a healthy 1080p copy
 * sits further down the same list. This pick ranks the SAME list
 * for startability instead: quality capped at 1080p first, SDR
 * before HDR10 before DV, MP4/HLS before MKV-class wrappers, and
 * file size as a COST (smaller wins) within a class. It is a pure
 * ranking over the full list — never a filter — so it cannot
 * dead-end: a title whose only copies are DV REMUXes still gets
 * its best one. The DV-support gate itself is unchanged (the
 * caller's HdrFallback still steps a DV pick down on chains
 * without DV support).
 */
fun pickBestStreamWeakGuarded(streams: List<StreamItem>): StreamItem? =
    streams
        .withIndex()
        .minWithOrNull(
            compareBy<IndexedValue<StreamItem>> { weakGuardQualityClass(it.value) }
                .thenBy { streamHdrClass(it.value) }
                .thenBy { streamContainerClass(it.value) }
                .thenBy { it.value.videoSize ?: Long.MAX_VALUE }
                .thenBy { it.index },
        )?.value
