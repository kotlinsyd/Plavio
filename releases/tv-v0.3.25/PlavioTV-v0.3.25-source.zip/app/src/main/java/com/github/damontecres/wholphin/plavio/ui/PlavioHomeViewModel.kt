package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.content.Context
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.CatalogRow
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.EpisodeAlert
import com.github.damontecres.wholphin.plavio.EpisodeAlertStore
import com.github.damontecres.wholphin.plavio.EpisodeAlerts
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlayerActivity
import com.github.damontecres.wholphin.plavio.PlavioProgressStore
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioHomeUiState {
    data object Loading : PlavioHomeUiState

    data class Content(
        val rows: List<CatalogRow>,
        val continueWatching: List<ContinueWatchingEntry> = emptyList(),
        /**
         * False for the progressive load's partial emissions, true
         * once every catalog has settled and [rows] is final
         * (v0.3.13). Display ignores it — partial rows render the
         * moment they exist, per the progressive principle — but
         * Home's entry focus waits for it: partial snapshots are
         * re-sorted as later catalogs settle, so the first row can
         * be REPLACED mid-startup, and landing the entry claim on a
         * provisional first card left that card unmounting under
         * focus when the true first row arrived — the owner's
         * startup flicker ("some card flicker small like its
         * freezing or going to crash").
         */
        val settled: Boolean = false,
    ) : PlavioHomeUiState

    /** Nothing installed yet — send the user to the addon setup. */
    data object NoAddons : PlavioHomeUiState

    /** Addons exist, but none enabled can serve catalogs. */
    data object NoCatalogs : PlavioHomeUiState

    /** Catalog addons exist but every catalog failed or came back empty. */
    data object LoadFailed : PlavioHomeUiState
}

@HiltViewModel
class PlavioHomeViewModel
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        private val addonStore: AddonStore,
        private val repository: AddonCatalogRepository,
        private val progressStore: PlavioProgressStore,
        private val uiPrefs: PlavioUiPrefs,
        private val watchlistStore: com.github.damontecres.wholphin.plavio.PlavioWatchlistStore,
        private val followedActorsStore: com.github.damontecres.wholphin.plavio.PlavioFollowedActorsStore,
    ) : ViewModel() {
        /** My List membership ("type|metaId") for the hero's + My List button (v0.3.21). */
        val myListKeys: StateFlow<Set<String>> = watchlistStore.keys

        fun toggleMyList(item: MetaPreview) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                watchlistStore.toggle(
                    com.github.damontecres.wholphin.plavio.WatchlistEntry(
                        type = item.type,
                        metaId = item.id,
                        name = item.name,
                        poster = item.poster,
                    ),
                )
            }
        }
        private val _state = MutableStateFlow<PlavioHomeUiState>(PlavioHomeUiState.Loading)
        val state: StateFlow<PlavioHomeUiState> = _state

        /**
         * Hero trailer lookups (v0.3.26): "type|id" -> YouTube
         * trailer id from the title's meta (PlavioMeta
         * `trailerStreams`), cached for the visit — focus returning
         * to a card must never refetch its meta just to restart a
         * preview. A cached null means "checked, this title has no
         * trailer" (the hero keeps the static backdrop).
         */
        private val trailerYtIdCache =
            java.util.concurrent.ConcurrentHashMap<String, String>()

        suspend fun trailerYtId(
            row: CatalogRow,
            item: MetaPreview,
        ): String? {
            val key = "${item.type}|${item.id}"
            trailerYtIdCache[key]?.let { return it.takeIf { yt -> yt.isNotEmpty() } }
            val meta =
                runCatching { repository.loadMeta(row.baseUrl, item.type, item.id) }
                    .getOrNull()
            val ytId = meta?.trailerStreams?.firstOrNull()?.ytId
            trailerYtIdCache[key] = ytId ?: ""
            return ytId
        }

        private var refreshJob: Job? = null

        /** Pending new-episode alerts for the Home rail. */
        val episodeAlerts: StateFlow<List<EpisodeAlert>> = EpisodeAlertStore.alerts

        private var lastEpisodeCheckMs = 0L

        /**
         * In-app episode check (phone parity, throttled to 6 h): the
         * WorkManager worker is the background path; this keeps alerts
         * fresh while the TV app is actually open.
         */
        private fun maybeCheckEpisodes() {
            if (!uiPrefs.episodeAlertsEnabled.value) return
            val now = System.currentTimeMillis()
            if (now - lastEpisodeCheckMs < EPISODE_CHECK_THROTTLE_MS) return
            lastEpisodeCheckMs = now
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching { EpisodeAlerts.runCheck(context, repository, progressStore) }
            }
        }

        fun clearEpisodeAlert(metaId: String) {
            EpisodeAlertStore.clearFor(context, metaId)
        }

        /**
         * Hero Watch Now (v0.3.16, note 9 — Instant Play): the
         * STREAM resolution no longer happens here. A series still
         * resolves its target EPISODE (next unwatched when known —
         * one meta fetch), then hands the player an unresolved
         * request; the player finds the streams and makes the
         * autoplay pick inside itself, exactly like the detail
         * page's Watch Now.
         */
        fun watchNow(
            row: CatalogRow,
            item: MetaPreview,
            onResolved: (PlaybackRequest?) -> Unit,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val request =
                    runCatching {
                        if (item.type == "series") {
                            val meta = repository.loadMeta(row.baseUrl, "series", item.id)
                            val videos =
                                (meta?.videos ?: emptyList())
                                    .sortedWith(compareBy({ it.season }, { it.episode }))
                            val watched =
                                progressStore.entries.value
                                    .firstOrNull { it.metaId == item.id && it.type == "series" }
                            val target =
                                if (watched != null) {
                                    videos.firstOrNull {
                                        it.season > watched.season ||
                                            (it.season == watched.season && it.episode > watched.episode)
                                    } ?: videos.firstOrNull { it.id == watched.videoId }
                                } else {
                                    videos.firstOrNull()
                                } ?: return@runCatching null
                            val ref =
                                StreamsRef(
                                    type = "series",
                                    videoId = target.id,
                                    metaId = item.id,
                                    title = item.name,
                                    poster = target.thumbnail ?: item.poster,
                                    backdrop = item.background,
                                    season = target.season,
                                    episode = target.episode,
                                    episodeTitle = target.title,
                                    seriesName = item.name,
                                    logo = item.logo,
                                    releaseInfo = item.releaseInfo,
                                    genres = item.genres,
                                    imdbRating = item.imdbRating,
                                )
                            com.github.damontecres.wholphin.plavio.buildPendingPlaybackRequest(
                                ref,
                                videos,
                            )
                        } else {
                            val ref =
                                StreamsRef(
                                    type = item.type,
                                    videoId = item.id,
                                    metaId = item.id,
                                    title = item.name,
                                    poster = item.poster,
                                    backdrop = item.background,
                                    logo = item.logo,
                                    releaseInfo = item.releaseInfo,
                                    genres = item.genres,
                                    imdbRating = item.imdbRating,
                                )
                            com.github.damontecres.wholphin.plavio.buildPendingPlaybackRequest(ref)
                        }
                    }.getOrNull()
                onResolved(request)
            }
        }

        /**
         * The newest progress emission held back while the player
         * is up (v0.3.27, see the collectors in init): applied the
         * moment the player closes, never dropped.
         */
        private var pendingProgressEntries: List<ContinueWatchingEntry>? = null

        private fun applyProgressEntries(entries: List<ContinueWatchingEntry>) {
            val current = _state.value
            if (current is PlavioHomeUiState.Content &&
                current.continueWatching != entries
            ) {
                _state.value = current.copy(continueWatching = entries)
            }
        }

        init {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore.ensureHouseAddons()
            }
            // Reload whenever the set of enabled addons changes (first
            // launch installs, toggles in the setup screen, removals).
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore.addons
                    .map { list -> list.filter { it.enabled }.map { it.id }.toSet() }
                    .distinctUntilChanged()
                    .collect { refresh() }
            }
            // Keep the Continue Watching row current while the home is
            // showing (e.g. right after returning from the player).
            // v0.3.27: while the player is up (PlayerActivity), the
            // player's own progress saves (every ~90 s of playback)
            // must not rebuild this row — Home stays composed under
            // the video, so each save used to recompose the browse
            // tree mid-playback. Emissions during playback are held
            // (latest wins) and applied by the collector below the
            // moment the player closes; nothing is lost, and the
            // initial load is unaffected (the player starts down).
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                progressStore.entries.collect { entries ->
                    if (PlayerActivity.active.value) {
                        pendingProgressEntries = entries
                    } else {
                        applyProgressEntries(entries)
                    }
                }
            }
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                PlayerActivity.active.collect { active ->
                    if (!active) {
                        pendingProgressEntries?.let { pending ->
                            pendingProgressEntries = null
                            applyProgressEntries(pending)
                        }
                    }
                }
            }
        }

        /**
         * "New from your people" (batch 5, mobile parity): titles
         * newer than each followed actor's follow-time baseline,
         * fetched per person through the meta addons and appended
         * as one Home row AFTER the catalog rows settle — the
         * progressive principle: the row joins when ready and never
         * holds Home up. [settledRows] pins the append to this
         * refresh cycle: if a newer refresh has already replaced
         * the rows, this cycle's row is dropped (the new cycle runs
         * its own pass).
         */
        private fun loadFollowedPeopleRow(settledRows: List<CatalogRow>) {
            val followed = followedActorsStore.actors.value
            if (followed.isEmpty()) return
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val year = java.time.Year.now().value
                val seen = mutableSetOf<String>()
                val items = mutableListOf<MetaPreview>()
                for (actor in followed.take(MAX_FOLLOWED_ACTORS)) {
                    val person =
                        runCatching { repository.getPerson(actor.id, actor.name) }
                            .getOrNull() ?: continue
                    for (meta in com.github.damontecres.wholphin.plavio.FollowActorsSupport
                        .newTitles(person, actor, year)) {
                        if (seen.add("${meta.type}|${meta.id}")) items += meta
                    }
                    if (items.size >= MAX_FOLLOWED_ROW_ITEMS) break
                }
                if (items.isEmpty()) return@launch
                val current = _state.value
                if (current is PlavioHomeUiState.Content &&
                    current.settled &&
                    current.rows == settledRows &&
                    current.rows.none { it.catalogId == FOLLOWED_ROW_ID }
                ) {
                    _state.value =
                        current.copy(
                            rows =
                                current.rows +
                                    CatalogRow(
                                        addonId = "plavio-followed",
                                        addonName = "",
                                        baseUrl = repository.primaryMetaBaseUrl() ?: "",
                                        catalogName =
                                            context.getString(
                                                com.github.damontecres.wholphin.R.string
                                                    .plavio_home_new_from_people,
                                            ),
                                        type = "movie",
                                        catalogId = FOLLOWED_ROW_ID,
                                        items = items.take(MAX_FOLLOWED_ROW_ITEMS),
                                    ),
                        )
                }
            }
        }

        fun refresh() {
            refreshJob?.cancel()
            refreshJob =
                viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                    when {
                        addonStore.addons.value.isEmpty() -> {
                            _state.value = PlavioHomeUiState.NoAddons
                        }

                        repository.catalogAddons().isEmpty() -> {
                            _state.value = PlavioHomeUiState.NoCatalogs
                        }

                        else -> {
                            _state.value = PlavioHomeUiState.Loading
                            // Progressive (v0.3.10): the first catalog
                            // that answers puts its row on screen; the
                            // rest join as they settle instead of the
                            // whole Home waiting on the slowest catalog.
                            val rows =
                                repository.loadHomeRowsProgressive { partial ->
                                    _state.value =
                                        PlavioHomeUiState.Content(
                                            rows = partial,
                                            continueWatching = progressStore.entries.value,
                                        )
                                }
                            val continueWatching = progressStore.entries.value
                            _state.value =
                                if (rows.isEmpty() && continueWatching.isEmpty()) {
                                    PlavioHomeUiState.LoadFailed
                                } else {
                                    PlavioHomeUiState.Content(
                                        rows = rows,
                                        continueWatching = continueWatching,
                                        settled = true,
                                    )
                                }
                            maybeCheckEpisodes()
                            loadFollowedPeopleRow(rows)
                        }
                    }
                }
        }
    }

private const val EPISODE_CHECK_THROTTLE_MS = 6 * 60 * 60 * 1000L

/** Batch 5: the followed-people row's identity + caps. */
private const val FOLLOWED_ROW_ID = "followed-people"
private const val MAX_FOLLOWED_ACTORS = 6
private const val MAX_FOLLOWED_ROW_ITEMS = 20
