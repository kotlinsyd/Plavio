package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports
import com.github.damontecres.wholphin.plavio.PlavioProfile
import com.github.damontecres.wholphin.plavio.PlavioProfileState

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlavioProgressStore
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.PlavioUpdater
import com.github.damontecres.wholphin.plavio.TvChannelRef
import com.github.damontecres.wholphin.plavio.TvUpdate
import com.github.damontecres.wholphin.plavio.UpdateInstallResult
import com.github.damontecres.wholphin.services.DownloadCallback
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Owns the launch-time update check for the Plavio flow: runs on every
 * cold start (the feed is a few hundred bytes), gated on the user's
 * auto-check setting, and silent only when the feed is missing or
 * unreachable.
 *
 * v0.3.2 fix: the old 12-hour throttle stamped the check time BEFORE
 * fetching, so a day of normal use consumed the one allowed check long
 * before a same-day release was published — v0.3.1 (shipped 16:35) was
 * never even looked for that evening. Install outcomes are surfaced in
 * the dialog now instead of being swallowed.
 */
@HiltViewModel
class PlavioRootViewModel
    @Inject
    constructor(
        private val uiPrefs: PlavioUiPrefs,
        private val updater: PlavioUpdater,
        private val repository: AddonCatalogRepository,
        progressStore: PlavioProgressStore,
        private val profileState: PlavioProfileState,
        private val downloadManager: com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager,
        @param:dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context,
    ) : ViewModel() {
        /**
         * In-progress titles (most recent first) — drives the
         * launch resume prompt (v0.3.26): the first entry is the
         * title that was mid-play when the app was last used.
         */
        val progressEntries: StateFlow<List<ContinueWatchingEntry>> = progressStore.entries

        // ---- Profiles (v0.3.26 batch 6) ----

        /** All profiles + the active one, for the launch picker. */
        val profiles: StateFlow<List<PlavioProfile>> = profileState.profiles
        val activeProfileId: StateFlow<String> = profileState.activeId

        fun setActiveProfile(id: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                profileState.setActive(id)
            }
        }

        // ---- v0.3.26: What's New + announcements + the Wi-Fi gate ----

        /**
         * The What's New entry to show once after an update, or
         * null. Fresh installs are stamped silently (the sheet is
         * for people who UPDATED); Settings → About can re-open the
         * newest entry any time via [showWhatsNew].
         */
        private val _whatsNewEntry =
            MutableStateFlow<com.github.damontecres.wholphin.plavio.WhatsNew.Entry?>(null)
        val whatsNewEntry: StateFlow<com.github.damontecres.wholphin.plavio.WhatsNew.Entry?> =
            _whatsNewEntry

        /** The shared app config (announcements) — fetched by the Application. */
        val appConfigState: StateFlow<com.github.damontecres.wholphin.plavio.PlavioAppConfigSupport.AppConfigData> =
            com.github.damontecres.wholphin.plavio.PlavioAppConfig.state

        private val _announcementSeenId = MutableStateFlow<String?>(null)
        val announcementSeenId: StateFlow<String?> = _announcementSeenId

        fun dismissWhatsNew() {
            _whatsNewEntry.value = null
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setWhatsNewLastSeenCode(com.github.damontecres.wholphin.BuildConfig.VERSION_CODE)
            }
        }

        /** The Settings door: re-open the newest entry on demand. */
        fun showWhatsNew() {
            _whatsNewEntry.value =
                com.github.damontecres.wholphin.plavio.WhatsNew.entries.firstOrNull()
        }

        fun markAnnouncementSeen(id: String) {
            com.github.damontecres.wholphin.plavio.PlavioAppConfig
                .markAnnouncementSeen(appContext, id)
            _announcementSeenId.value = id
        }

        /** True while the active network is Wi-Fi or Ethernet (the downloads gate). */
        @Volatile
        private var onUnmeteredNetwork = false

        init {
            // What's New arming: show once when the stored
            // last-seen code is older than this build AND an entry
            // exists for it; stamp silently otherwise (fresh
            // installs and entry-less bumps never see the sheet).
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val current = com.github.damontecres.wholphin.BuildConfig.VERSION_CODE
                val seen = uiPrefs.whatsNewLastSeenCode.value
                if (com.github.damontecres.wholphin.plavio.WhatsNew.shouldShow(seen, current)) {
                    _whatsNewEntry.value =
                        com.github.damontecres.wholphin.plavio.WhatsNew.entryFor(current)
                } else if (seen < current) {
                    uiPrefs.setWhatsNewLastSeenCode(current)
                }
            }
            _announcementSeenId.value =
                com.github.damontecres.wholphin.plavio.PlavioAppConfig
                    .seenAnnouncementId(appContext)
            // Wi-Fi-only downloads gate (app-wide from here,
            // because downloads enqueue from screens whose view
            // models do not own the gate): the manager asks this
            // lambda before and during every transfer.
            val cm =
                appContext.getSystemService(android.content.Context.CONNECTIVITY_SERVICE)
                    as? android.net.ConnectivityManager
            fun refreshTransports() {
                val caps =
                    runCatching { cm?.getNetworkCapabilities(cm?.activeNetwork) }.getOrNull()
                onUnmeteredNetwork =
                    caps != null &&
                        (
                            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
                                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
                            )
                if (onUnmeteredNetwork && uiPrefs.wifiOnlyDownloads.value) {
                    downloadManager.recheckQueued()
                }
            }
            refreshTransports()
            if (cm != null) {
                runCatching {
                    cm.registerDefaultNetworkCallback(
                        object : android.net.ConnectivityManager.NetworkCallback() {
                            override fun onAvailable(network: android.net.Network) =
                                refreshTransports()

                            override fun onLost(network: android.net.Network) = refreshTransports()

                            override fun onCapabilitiesChanged(
                                network: android.net.Network,
                                caps: android.net.NetworkCapabilities,
                            ) = refreshTransports()
                        },
                    )
                }
            }
            downloadManager.transferAllowed = {
                !uiPrefs.wifiOnlyDownloads.value || onUnmeteredNetwork
            }
        }
        /** In-player channel zapping: resolve the target channel and hand back its request. */
        fun zapToChannel(
            channel: TvChannelRef,
            siblings: List<TvChannelRef>,
            onResolved: (PlaybackRequest) -> Unit,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val resolved =
                    runCatching { repository.loadChannelRequest(channel, siblings) }
                        .onFailure { Timber.v(it, "Channel zap resolve failed") }
                        .getOrNull()
                if (resolved != null) onResolved(resolved)
            }
        }
        private val _pendingUpdate = MutableStateFlow<TvUpdate?>(null)
        val pendingUpdate: StateFlow<TvUpdate?> = _pendingUpdate

        /** TV look (owner design 2026-11-04): null = never chosen, renders as Full. */
        val lookMode: StateFlow<String?> = uiPrefs.lookMode

        /** Text size (v0.3.26 batch 5): the root scales fonts by this choice. */
        val textSize: StateFlow<String> = uiPrefs.textSize

        /** Idle screen delay in minutes (v0.3.26 batch 5); 0 = Off. */
        val idleScreenMinutes: StateFlow<Int> = uiPrefs.idleScreenMinutes

        private val _installing = MutableStateFlow(false)
        val installing: StateFlow<Boolean> = _installing

        /**
         * Why the last install attempt did not finish, shown inside the
         * update dialog: a download/verification problem (Failed) or
         * the unknown-sources detour (PermissionNeeded). Null = nothing
         * to report.
         */
        private val _updateProblem = MutableStateFlow<UpdateProblem?>(null)
        val updateProblem: StateFlow<UpdateProblem?> = _updateProblem

        private var checkedThisLaunch = false

        fun maybeCheckOnLaunch() {
            if (checkedThisLaunch) return
            checkedThisLaunch = true
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                if (!uiPrefs.autoUpdateCheck.value) return@launch
                // Every cold start checks (v0.3.2): the 12-hour
                // throttle that hid v0.3.1 is gone. The timestamp is
                // bookkeeping only, stamped after a successful fetch.
                runCatching { updater.checkForUpdate() }
                    .onSuccess {
                        uiPrefs.setLastUpdateCheckMs(System.currentTimeMillis())
                        if (it != null) _pendingUpdate.value = it
                    }.onFailure { Timber.v(it, "Launch update check failed") }
            }
        }

        fun dismissUpdate() {
            _pendingUpdate.value = null
            _updateProblem.value = null
        }

        /**
         * The app came back to the foreground while the update dialog
         * waits on the unknown-sources detour: if the permission is
         * granted now, continue straight into the installer — the
         * verified download is still on disk, so the detour costs the
         * user no second tap (v0.3.6).
         */
        fun onResumed() {
            if (_pendingUpdate.value == null) return
            if (_updateProblem.value != UpdateProblem.PermissionNeeded) return
            if (updater.canInstallPackages()) installPendingUpdate()
        }

        fun installPendingUpdate() {
            val update = _pendingUpdate.value ?: return
            if (_installing.value) return
            _installing.value = true
            _updateProblem.value = null
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val result =
                    runCatching {
                        updater.install(
                            update,
                            object : DownloadCallback {
                                override fun contentLength(contentLength: Long) {}

                                override fun bytesDownloaded(bytes: Long) {}
                            },
                        )
                    }.getOrElse {
                        Timber.w(it, "Update install failed")
                        UpdateInstallResult.Failed(it.message)
                    }
                _installing.value = false
                when (result) {
                    UpdateInstallResult.Launched -> {
                        _pendingUpdate.value = null
                        _updateProblem.value = null
                    }
                    // Keep the dialog (and the downloaded file): after
                    // allowing installs in Settings, Update retries
                    // straight into the installer.
                    UpdateInstallResult.NeedsInstallPermission ->
                        _updateProblem.value = UpdateProblem.PermissionNeeded
                    is UpdateInstallResult.Failed ->
                        _updateProblem.value = UpdateProblem.Failed
                }
            }
        }

        enum class UpdateProblem { Failed, PermissionNeeded }
    }
