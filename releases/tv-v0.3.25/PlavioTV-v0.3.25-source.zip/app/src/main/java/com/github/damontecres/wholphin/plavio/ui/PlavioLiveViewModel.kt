package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.CatalogRow
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.TvChannelRef
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import com.github.damontecres.wholphin.plavio.pickBestStream
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioLiveUiState {
    data object Loading : PlavioLiveUiState

    data object Empty : PlavioLiveUiState

    data class Content(
        val rows: List<CatalogRow>,
    ) : PlavioLiveUiState
}

@HiltViewModel
class PlavioLiveViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val liveStore: com.github.damontecres.wholphin.plavio.PlavioLiveStore,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioLiveUiState>(PlavioLiveUiState.Loading)
        val state: StateFlow<PlavioLiveUiState> = _state

        /** Favourite channel keys (v0.3.26) — the screen stars from these. */
        val favouriteKeys: StateFlow<Set<String>> = liveStore.favouriteKeys

        /** The last channel watched (v0.3.26) — Live opens back on it. */
        val lastChannel: StateFlow<com.github.damontecres.wholphin.plavio.StoredLiveChannel?> =
            liveStore.lastChannel

        /** Star/unstar a channel (v0.3.26). */
        fun toggleFavourite(ref: com.github.damontecres.wholphin.plavio.StoredLiveChannel) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val isFav = ref.favouriteKey in liveStore.favouriteKeys.value
                liveStore.setFavourite(ref.favouriteKey, !isFav)
            }
        }

        /** Hidden channel keys (v0.3.26 batch 5) — the screen filters by these. */
        val hiddenKeys: StateFlow<Set<String>> = liveStore.hiddenKeys

        /** Hide/unhide a channel (v0.3.26 batch 5). */
        fun toggleHidden(ref: com.github.damontecres.wholphin.plavio.StoredLiveChannel) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val isHidden = ref.favouriteKey in liveStore.hiddenKeys.value
                liveStore.setHidden(ref.favouriteKey, !isHidden)
            }
        }

        /** Set when a channel's request is ready — the screen hands it to the player. */
        private val _resolving = MutableStateFlow<PlaybackRequest?>(null)
        val resolving: StateFlow<PlaybackRequest?> = _resolving

        init {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val rows =
                    runCatching { repository.loadLiveRows() }.getOrDefault(emptyList())
                _state.value =
                    if (rows.isEmpty()) {
                        PlavioLiveUiState.Empty
                    } else {
                        PlavioLiveUiState.Content(rows)
                    }
            }
        }

        /** Zaps straight into the channel: best stream, played immediately. */
        fun playChannel(
            row: CatalogRow,
            item: MetaPreview,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val bundle =
                    runCatching { repository.loadStreams("tv", item.id, item.id) }
                        .getOrNull() ?: return@launch
                val best = pickBestStream(bundle.streams) ?: return@launch
                val ref =
                    StreamsRef(
                        type = "tv",
                        videoId = item.id,
                        metaId = item.id,
                        title = item.name,
                        poster = item.poster ?: item.background,
                    )
                val self =
                    TvChannelRef(
                        addonId = row.addonId,
                        metaId = item.id,
                        name = item.name,
                        poster = item.poster,
                        type = "tv",
                        catalogId = row.catalogId,
                    )
                // Last-channel recall (v0.3.26): every zap is
                // remembered, so the next Live visit opens back on
                // this channel (the screen seeds its hand-back key
                // from the store).
                runCatching { liveStore.setLastChannel(self) }
                _resolving.value =
                    buildPlaybackRequest(ref, bundle, best).copy(
                        liveChannel = self,
                        liveChannels =
                            row.items.map { sibling ->
                                TvChannelRef(
                                    addonId = row.addonId,
                                    metaId = sibling.id,
                                    name = sibling.name,
                                    poster = sibling.poster,
                                    type = "tv",
                                    catalogId = row.catalogId,
                                )
                            },
                    )
            }
        }

        fun consumeResolving() {
            _resolving.value = null
        }
    }
