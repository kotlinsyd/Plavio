package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import kotlinx.coroutines.launch
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CastMember
import com.github.damontecres.wholphin.plavio.MetaDetail
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.RelatedSection
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.ui.components.Button

/**
 * Detail page for a catalog item — phone parity in TV form: backdrop
 * header, poster card + fact pills (year, ★ rating, runtime,
 * certification, status, network), Watch Now (autoplays the best
 * stream, like the phone) + Sources, the synopsis, the cast (→ actor
 * pages), episodes for series, and the More Like This / More From rows
 * that follow whichever addon serves the title.
 */
@Composable
fun PlavioDetailScreen(
    destination: PlavioDestination.Detail,
    onWatchNow: (PlaybackRequest) -> Unit,
    onWatchMovie: (MetaDetail) -> Unit,
    onEpisodeClick: (MetaDetail, Video) -> Unit,
    onActorClick: (CastMember) -> Unit,
    onRelatedClick: (MetaPreview) -> Unit,
    modifier: Modifier = Modifier,
    /** v0.3.14 (focus rebuild): the armed restore record for this
     * page, held by the root so it survives this screen being
     * disposed under a pushed child; [onArmRestore] writes/clears
     * it. See PlavioFocus.kt — arm-at-click, fire-once-on-return,
     * cancelled by any focus the user takes himself. */
    restoreRecord: DetailRestore? = null,
    onArmRestore: (DetailRestore?) -> Unit = {},
    viewModel: PlavioDetailViewModel =
        hiltViewModel(key = "detail|${destination.baseUrl}|${destination.type}|${destination.id}"),
) {
    LaunchedEffect(destination) {
        viewModel.load(destination.baseUrl, destination.type, destination.id)
    }
    val state by viewModel.state.collectAsState()
    val watchNow by viewModel.watchNow.collectAsState()
    val autoplay by viewModel.autoplayBestStream.collectAsState()
    val myListKeys by viewModel.myListKeys.collectAsState()
    val episodeProgress by viewModel.episodeProgress.collectAsState()
    val watchedKeys by viewModel.watchedKeys.collectAsState()
    val progressEntries by viewModel.progressEntries.collectAsState()
    val sourcesState by viewModel.sources.collectAsState()
    val blurUnwatched by viewModel.blurUnwatchedEpisodes.collectAsState()
    // Batch 5: download-season feedback + custom lists + the Lists panel.
    val seasonNotice by viewModel.seasonNotice.collectAsState()
    val customLists by viewModel.customLists.collectAsState()
    val customListItems by viewModel.customListItems.collectAsState()
    var listsOpen by remember { mutableStateOf(false) }
    // Batch 7 (the owner's button clean-up): the 3-dots overflow
    // popup — My List / Play from Beginning / Mark as Watched /
    // Remove from Continue Watching / Lists live there now, behind
    // the action row's last button.
    var moreOpen by remember { mutableStateOf(false) }
    LaunchedEffect(seasonNotice) {
        if (seasonNotice != null) {
            kotlinx.coroutines.delay(6_000)
            viewModel.consumeSeasonNotice()
        }
    }

    // The Sources popup owns Back while it is open (v0.3.22).
    androidx.activity.compose.BackHandler(enabled = sourcesState is DetailSourcesState.Open) {
        viewModel.closeSources()
    }
    // The Lists panel owns Back while it is open (batch 5) — the
    // detail page's restore machine lands focus back on the 3-dots
    // button when it closes (Opener("lists"), see DetailContent;
    // batch 7 moved the Lists button itself into the overflow).
    androidx.activity.compose.BackHandler(enabled = listsOpen) {
        listsOpen = false
    }
    // The overflow popup owns Back while it is open (batch 7) —
    // closing it lands focus back on the 3-dots button
    // (Opener("more"), see DetailContent).
    androidx.activity.compose.BackHandler(enabled = moreOpen) {
        moreOpen = false
    }
    // The episode watched menu (v0.3.33 — the owner's "do like
    // Nuvio" order): HOLD OK on an episode row opens it (the row
    // arms its Episode restore first, so closing the menu — by an
    // action or by Back — lands focus back on that row through
    // DetailContent's close-firing effect). It owns Back while
    // open, like the page's other overlays.
    var episodeMenuTarget by remember { mutableStateOf<Video?>(null) }
    androidx.activity.compose.BackHandler(enabled = episodeMenuTarget != null) {
        episodeMenuTarget = null
    }

    // The full-summary overlay (v0.3.11): owns Back while open, and
    // closing it returns focus to the Read more button that opened
    // it — the same trap/restore discipline as the Sources popup.
    var summaryOpen by remember { mutableStateOf(false) }
    val readMoreFocus = remember { FocusRequester() }
    androidx.activity.compose.BackHandler(enabled = summaryOpen) {
        summaryOpen = false
    }
    // Focus anchors for the page's armed-restore discipline
    // (v0.3.14 — see the machine in DetailContent). The Watch button
    // is the page's home position and the universal fallback: it is
    // ALWAYS composed on a loaded page, so a restore that ends there
    // can never strand the remote. The Read more button exists only
    // while a long synopsis is actually composed, so its presence
    // and landed state are tracked explicitly — a restore may aim
    // at it only while it is verifiably on screen.
    val watchFocus = remember { FocusRequester() }
    // State OBJECTS, not plain values: the retry loops read them
    // live from inside coroutines, where a captured value snapshot
    // would go stale the moment it matters most.
    val watchLandedState = remember { mutableStateOf(false) }
    val readMoreAttachedState = remember { mutableStateOf(false) }
    val readMoreLandedState = remember { mutableStateOf(false) }
    // The claim (v0.3.13's gate, v0.3.14's form — a FocusClaim from
    // the shared focus system, PlavioFocus.kt): it trips the moment
    // focus verifiably sits ANYWHERE inside this page (the root's
    // onFocusChanged below) or the viewer presses a navigation key
    // (the root's preview key handler — a Left press heading for the
    // rail is delivered to the in-page focused control first, so the
    // claim trips BEFORE focus leaves). Every landing on this page
    // runs through landFocus against this claim, so a landing stands
    // down the instant the viewer takes the remote — and an armed
    // restore (below) is cancelled by the same signal. There is no
    // standing restore/watchdog code on this page anymore: the
    // v0.3.12 helper that fought live navigation and the v0.3.13
    // loops that could strand focus on an off-screen Play button
    // are both deleted; returns are armed records, fired once.
    val detailClaim = remember { FocusClaim() }
    // The local mirror of the armed record: click handlers write it
    // (and the root's copy, via onArmRestore) at arm time; the
    // firing effects in DetailContent read and consume it.
    val armState = remember { mutableStateOf<DetailRestore?>(null) }
    fun arm(record: DetailRestore) {
        armState.value = record
        onArmRestore(record)
    }

    // Watch Now (v0.3.16, note 9 — Instant Play): the press is
    // Ready on the same frame with an unresolved request — the
    // player opens immediately and finds the streams inside itself.
    // (The picker fallback for "nothing playable" now lives in the
    // player: it swaps its Play entry for the Streams destination.)
    LaunchedEffect(watchNow) {
        val wn = watchNow
        if (wn is WatchNowState.Ready) {
            viewModel.consumeWatchNow()
            onWatchNow(wn.request)
        }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                // The claim gate's sensors (v0.3.13, see the states
                // above): focus anywhere inside the page claims it,
                // and any navigation key pressed while a page control
                // holds focus claims it too — the preview handler
                // sees the key on its way to the focused control,
                // before focus moves, so a landing loop can never
                // fire one more shot after the viewer has taken over.
                // Neither handler ever consumes an event.
                .onFocusChanged { if (it.hasFocus) detailClaim.claim() }
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        (
                            event.key == Key.DirectionUp ||
                                event.key == Key.DirectionDown ||
                                event.key == Key.DirectionLeft ||
                                event.key == Key.DirectionRight ||
                                event.key == Key.DirectionCenter ||
                                event.key == Key.Enter ||
                                event.key == Key.NumPadEnter
                        )
                    ) {
                        detailClaim.stampKey()
                    }
                    false
                },
    ) {
        when (val st = state) {
            PlavioDetailUiState.Loading -> {
                // v0.3.13: no more full-black "Loading…" screen. The
                // tapped card's own backdrop + name are already known
                // (they ride the destination), so the page opens on
                // the title's art with a skeleton where the facts and
                // actions will land — the loaded content then replaces
                // it in place.
                DetailLoadingLayer(destination = destination)
            }

            PlavioDetailUiState.Unavailable -> {
                Text(
                    text = stringResource(R.string.plavio_detail_unavailable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            is PlavioDetailUiState.Loaded -> {
                DetailContent(
                    meta = st.meta,
                    // Batch 5: a collection section the addon serves
                    // leads the related block (see splitFranchiseSections).
                    related = splitFranchiseSections(st.related, st.meta.id),
                    episodeProgress = episodeProgress,
                    episodeWatchedIds =
                        watchedKeys
                            .filter { it.startsWith("${st.meta.type}|") }
                            .map { it.substringAfter('|') }
                            .toSet(),
                    blurUnwatched = blurUnwatched,
                    episodeMenuOpen = episodeMenuTarget != null,
                    onEpisodeMenuClick = { video -> episodeMenuTarget = video },
                    onWatchNowClick = {
                        if (autoplay) {
                            viewModel.watchNow(st.meta, firstEpisode(st.meta))
                        } else {
                            val target = firstEpisode(st.meta)
                            if (st.meta.type == "series" && target != null) {
                                onEpisodeClick(st.meta, target)
                            } else {
                                onWatchMovie(st.meta)
                            }
                        }
                    },
                    onSourcesClick = {
                        val target = firstEpisode(st.meta)
                        if (st.meta.type == "series" && target != null) {
                            onEpisodeClick(st.meta, target)
                        } else {
                            onWatchMovie(st.meta)
                        }
                    },
                    sourcesOpen = sourcesState is DetailSourcesState.Open,
                    listsOpen = listsOpen,
                    moreOpen = moreOpen,
                    onMoreClick = { moreOpen = true },
                    seasonNotice = seasonNotice,
                    onDownloadSeasonClick = { season ->
                        viewModel.downloadSeason(st.meta, season)
                    },
                    summaryOpen = summaryOpen,
                    onReadMoreClick = { summaryOpen = true },
                    readMoreFocus = readMoreFocus,
                    watchFocus = watchFocus,
                    watchLandedState = watchLandedState,
                    readMoreLandedState = readMoreLandedState,
                    readMoreAttachedState = readMoreAttachedState,
                    claim = detailClaim,
                    armState = armState,
                    initialRecord = restoreRecord,
                    onConsumeRecord = { onArmRestore(null) },
                    arm = ::arm,
                    onReadMorePresenceChange = { attached ->
                        readMoreAttachedState.value = attached
                        if (!attached) readMoreLandedState.value = false
                    },
                    onReadMoreLanded = { readMoreLandedState.value = true },
                    onSourcesButtonClick = {
                        viewModel.openSources(st.meta, firstEpisode(st.meta))
                    },
                    autoplay = autoplay,
                    onEpisodePlay = { m, v -> viewModel.watchNow(m, v) },
                    onEpisodeClick = onEpisodeClick,
                    onActorClick = onActorClick,
                    onRelatedClick = onRelatedClick,
                )
            }
        }

        // The Sources popup (v0.3.22): the player's OWN SourcesPanel
        // component, overlaid on the page exactly as it overlays the
        // player — the owner's word was same way, same style, not a
        // separate screen. A pick plays through the Watch Now path.
        val openSources = sourcesState as? DetailSourcesState.Open
        val loadedMeta = (state as? PlavioDetailUiState.Loaded)?.meta
        if (openSources != null && loadedMeta != null) {
            if (openSources.streams.isEmpty() && openSources.loading) {
                Row(
                    modifier =
                        Modifier
                            .align(Alignment.CenterEnd)
                            .width(440.dp)
                            .padding(end = 48.dp)
                            .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                            .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                            .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    OrbitLoader(modifier = Modifier.size(28.dp), alwaysAnimate = true)
                    Text(
                        text = stringResource(R.string.plavio_detail_finding_stream),
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                    )
                }
            } else {
                SourcesPanel(
                    streams = openSources.streams,
                    currentUrl = "",
                    onPick = { stream ->
                        // Arm BEFORE leaving (v0.3.14): this pick
                        // goes straight to the player; the return
                        // lands on the page's home position.
                        arm(DetailRestore.Watch)
                        val request = viewModel.pickSource(loadedMeta, stream)
                        viewModel.closeSources()
                        if (request != null) onWatchNow(request)
                    },
                    onReload = {
                        viewModel.reloadSources(loadedMeta, firstEpisode(loadedMeta))
                    },
                    modifier = Modifier.align(Alignment.CenterEnd),
                )
            }
        }

        // The full-summary overlay (v0.3.11): the whole synopsis in a
        // scrollable panel over a scrim — see SummaryOverlay.
        val summaryText = loadedMeta?.description?.takeIf { it.isNotBlank() }
        if (summaryOpen && summaryText != null) {
            SummaryOverlay(
                title = stringResource(R.string.plavio_detail_summary),
                text = summaryText,
                onClose = { summaryOpen = false },
            )
        }

        // The Lists panel (batch 5): custom-list membership for this
        // title + list management, overlaid on the page exactly like
        // the Sources popup. Writes go to the synced store, so a
        // list made here shows on the phone after the next sync.
        if (listsOpen && loadedMeta != null) {
            ListsPanel(
                lists = customLists,
                memberListIds =
                    com.github.damontecres.wholphin.plavio.PlavioCustomLists.listsContaining(
                        customListItems,
                        loadedMeta.type,
                        loadedMeta.id,
                    ),
                onToggleList = { listId ->
                    viewModel.toggleCustomListMembership(loadedMeta, listId)
                },
                onCreateList = { name -> viewModel.createCustomList(name) },
                onRenameList = { id, name -> viewModel.renameCustomList(id, name) },
                onDeleteList = { id -> viewModel.deleteCustomList(id) },
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }

        // The overflow popup (batch 7): everything that used to
        // crowd the Details action rows as its own button — My List,
        // Play from Beginning, Mark as Watched, Remove from Continue
        // Watching, Lists — behind the row's 3-dots button. Same
        // handlers the buttons called, same labels, same state;
        // choosing a row closes the popup (the Lists row instead
        // hands over to the Lists panel, armed on the same 3-dots
        // button, so closing THAT lands back here too).
        if (moreOpen && loadedMeta != null) {
            DetailMorePanel(
                inMyList = "${loadedMeta.type}|${loadedMeta.id}" in myListKeys,
                hasTitleProgress = progressEntries.any { it.metaId == loadedMeta.id },
                isSeries = loadedMeta.type == "series",
                titleWatched = "${loadedMeta.type}|${loadedMeta.id}" in watchedKeys,
                onToggleMyList = {
                    moreOpen = false
                    viewModel.toggleMyList(loadedMeta)
                },
                onPlayFromBeginning = {
                    moreOpen = false
                    arm(DetailRestore.Watch)
                    viewModel.playFromBeginning(loadedMeta, firstEpisode(loadedMeta))
                },
                onToggleTitleWatched = {
                    moreOpen = false
                    viewModel.setMovieWatched(
                        loadedMeta,
                        "${loadedMeta.type}|${loadedMeta.id}" !in watchedKeys,
                    )
                },
                onRemoveFromContinueWatching = {
                    moreOpen = false
                    viewModel.removeFromContinueWatching(loadedMeta)
                },
                onLists = {
                    arm(DetailRestore.Opener("lists"))
                    moreOpen = false
                    listsOpen = true
                },
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }

        // The episode watched menu (v0.3.33): the panel for the
        // episode a HOLD OK landed on. Its range sets and counts
        // come from EpisodeWatchedMenu — the same sets the writes
        // below consume — and its direction follows the focused
        // episode's watched state (watched → the menu unmarks).
        // Choosing a row writes through the watched store (marking
        // clears the episodes' Continue Watching progress, the
        // item-7 behaviour) and closes; the row that opened it was
        // armed at the hold, so DetailContent's close effect lands
        // focus back on it.
        val menuTarget = episodeMenuTarget
        if (menuTarget != null && loadedMeta != null) {
            val today = remember { java.time.LocalDate.now() }
            val upToHere =
                remember(menuTarget.id, loadedMeta.id) {
                    com.github.damontecres.wholphin.plavio.EpisodeWatchedMenu
                        .upToHere(loadedMeta.videos, menuTarget, today)
                }
            val wholeSeason =
                remember(menuTarget.id, loadedMeta.id) {
                    com.github.damontecres.wholphin.plavio.EpisodeWatchedMenu
                        .wholeSeason(loadedMeta.videos, menuTarget, today)
                }
            val unmark =
                com.github.damontecres.wholphin.plavio.EpisodeWatchedMenu
                    .unmarkDirection(
                        focusMarked = "${loadedMeta.type}|${menuTarget.id}" in watchedKeys,
                        focusProgress = episodeProgress[menuTarget.id],
                    )
            EpisodeWatchedPanel(
                unmark = unmark,
                upToHereCount = upToHere.size,
                wholeSeasonCount = wholeSeason.size,
                onThisEpisode = {
                    episodeMenuTarget = null
                    viewModel.setEpisodeWatched(loadedMeta, menuTarget, !unmark)
                },
                onUpToHere = {
                    episodeMenuTarget = null
                    viewModel.setEpisodesWatched(loadedMeta, upToHere, !unmark)
                },
                onWholeSeason = {
                    episodeMenuTarget = null
                    viewModel.setEpisodesWatched(loadedMeta, wholeSeason, !unmark)
                },
                onSources = {
                    episodeMenuTarget = null
                    // The row's own click, unchanged (v0.3.10):
                    // autoplay plays the episode, otherwise the
                    // picker opens for it.
                    if (autoplay) {
                        viewModel.watchNow(loadedMeta, menuTarget)
                    } else {
                        onEpisodeClick(loadedMeta, menuTarget)
                    }
                },
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }
    }
}

/**
 * The episode watched menu (v0.3.33 — the owner's "do like Nuvio"
 * order, EPISODE-WATCHED-MENU-SPEC.md): opened by HOLD OK on an
 * episode row. One solid panel (the DetailMorePanel shell — same
 * PlavioOnyx.Panel, same shape, same first-row landing through the
 * shared primitive) whose header states the direction up front —
 * the menu MARKS while the focused episode is unwatched and
 * UNMARKS once it is watched — followed by this episode / up to
 * here (N episodes) / whole season (N episodes), the counts read
 * from the exact sets the actions write (EpisodeWatchedMenu,
 * aired episodes only). A bulk row whose set is just the focused
 * episode itself is not repeated — "this episode" already says
 * it. "Sources for this episode" rides last: the hold took over
 * the row's press, so the door to the episode's streams stays in
 * the menu too (a short press on the row still opens them, as
 * before). Choosing any row closes the menu; Back closes it too
 * (the screen's BackHandler) — either way the page's restore
 * machine returns focus to the episode row that opened it.
 */
@Composable
private fun EpisodeWatchedPanel(
    unmark: Boolean,
    upToHereCount: Int,
    wholeSeasonCount: Int,
    onThisEpisode: () -> Unit,
    onUpToHere: () -> Unit,
    onWholeSeason: () -> Unit,
    onSources: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    var landed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        landFocus(firstFocus, isClaimed = { landed }, attempts = 8, delayMs = 120)
    }
    Column(
        modifier =
            modifier
                .width(460.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text =
                stringResource(
                    if (unmark) {
                        R.string.plavio_episode_menu_unmark_header
                    } else {
                        R.string.plavio_detail_mark_watched
                    },
                ),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White,
        )
        PlavioFixedButton(
            text =
                stringResource(
                    if (unmark) {
                        R.string.plavio_episode_menu_unmark_this
                    } else {
                        R.string.plavio_episode_menu_mark_this
                    },
                ),
            onClick = onThisEpisode,
            whiteFocus = true,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .focusRequester(firstFocus)
                    .onFocusChanged { if (it.isFocused) landed = true },
        )
        if (upToHereCount > 1) {
            PlavioFixedButton(
                text =
                    stringResource(
                        if (unmark) {
                            R.string.plavio_episode_menu_unmark_up_to_here
                        } else {
                            R.string.plavio_episode_menu_mark_up_to_here
                        },
                        upToHereCount,
                    ),
                onClick = onUpToHere,
                whiteFocus = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (wholeSeasonCount > 1) {
            PlavioFixedButton(
                text =
                    stringResource(
                        if (unmark) {
                            R.string.plavio_episode_menu_unmark_whole_season
                        } else {
                            R.string.plavio_episode_menu_mark_whole_season
                        },
                        wholeSeasonCount,
                    ),
                onClick = onWholeSeason,
                whiteFocus = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PlavioFixedButton(
            text = stringResource(R.string.plavio_episode_menu_sources),
            onClick = onSources,
            whiteFocus = true,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/**
 * The Details overflow popup (batch 7 — the owner's button
 * clean-up): the actions that used to crowd the Details action
 * rows as their own capsules, one labelled row each in the app's
 * standard solid panel (the ListsPanel shell: PlavioOnyx.Panel,
 * same shape, same first-row landing through the shared
 * primitive). Rows carry the same labels and state the old
 * buttons showed — My List reads "+ My List" / "✓ In My List",
 * the watched row reads "Mark as watched" / "Watched" — and the
 * conditional rows keep the old buttons' conditions (Play from
 * Beginning and Remove from Continue Watching only while the
 * title has saved progress; the watched toggle is a movie's own,
 * series mark per episode on the rows). Choosing a row runs the
 * old button's handler and closes the popup; Back closes it too
 * (the screen's BackHandler) — either way the page's restore
 * machine returns focus to the 3-dots button. The Lists row
 * hands over to the Lists panel instead of acting itself.
 */
@Composable
private fun DetailMorePanel(
    inMyList: Boolean,
    hasTitleProgress: Boolean,
    isSeries: Boolean,
    titleWatched: Boolean,
    onToggleMyList: () -> Unit,
    onPlayFromBeginning: () -> Unit,
    onToggleTitleWatched: () -> Unit,
    onRemoveFromContinueWatching: () -> Unit,
    onLists: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    var landed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        landFocus(firstFocus, isClaimed = { landed }, attempts = 8, delayMs = 120)
    }
    Column(
        modifier =
            modifier
                .width(460.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // My List always rides first — it was the row's second
        // capsule — so the landing target never moves.
        PlavioFixedButton(
            text =
                stringResource(
                    if (inMyList) {
                        R.string.plavio_in_my_list
                    } else {
                        R.string.plavio_add_my_list
                    },
                ),
            onClick = onToggleMyList,
            whiteFocus = true,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .focusRequester(firstFocus)
                    .onFocusChanged { if (it.isFocused) landed = true },
        )
        if (hasTitleProgress) {
            PlavioFixedButton(
                text = stringResource(R.string.plavio_detail_play_from_beginning),
                onClick = onPlayFromBeginning,
                whiteFocus = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (!isSeries) {
            PlavioFixedButton(
                text =
                    stringResource(
                        if (titleWatched) {
                            R.string.plavio_detail_watched
                        } else {
                            R.string.plavio_detail_mark_watched
                        },
                    ),
                onClick = onToggleTitleWatched,
                whiteFocus = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (hasTitleProgress) {
            PlavioFixedButton(
                text = stringResource(R.string.plavio_detail_remove_continue),
                onClick = onRemoveFromContinueWatching,
                whiteFocus = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PlavioFixedButton(
            text = stringResource(R.string.plavio_detail_lists),
            onClick = onLists,
            whiteFocus = true,
            leadingIcon = Icons.AutoMirrored.Filled.List,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/**
 * The custom-lists panel (batch 5): one row per list — the row's
 * click adds/removes THIS title (a ✓ rides the row when the title
 * is in), Rename/Delete ride each row as their own small capsules,
 * and a name field + Create button at the bottom starts a new list.
 * Focus lands on the first row (or the field when there are no
 * lists yet) through the shared landing primitive; Back closes the
 * panel (the screen's BackHandler) and the page's restore machine
 * returns focus to the 3-dots button (batch 7: the Lists button
 * itself lives in the overflow popup now).
 */
@Composable
private fun ListsPanel(
    lists: List<com.github.damontecres.wholphin.plavio.PlavioCustomList>,
    memberListIds: Set<String>,
    onToggleList: (String) -> Unit,
    onCreateList: (String) -> Unit,
    onRenameList: (String, String) -> Unit,
    onDeleteList: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    var landed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        landFocus(firstFocus, isClaimed = { landed }, attempts = 8, delayMs = 120)
    }
    var newName by remember { mutableStateOf("") }
    var renameTarget by remember {
        mutableStateOf<com.github.damontecres.wholphin.plavio.PlavioCustomList?>(null)
    }
    var renameText by remember { mutableStateOf("") }
    var deleteTarget by remember {
        mutableStateOf<com.github.damontecres.wholphin.plavio.PlavioCustomList?>(null)
    }
    Column(
        modifier =
            modifier
                .width(460.dp)
                .fillMaxHeight(0.88f)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_lists_title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White,
        )
        if (lists.isEmpty()) {
            Text(
                text = stringResource(R.string.plavio_lists_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(lists, key = { _, list -> "list|${list.id}" }) { index, list ->
                    val member = list.id in memberListIds
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PlavioFixedButton(
                            text = (if (member) "✓  " else "") + list.name,
                            onClick = { onToggleList(list.id) },
                            whiteFocus = true,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .then(
                                        if (index == 0) {
                                            Modifier
                                                .focusRequester(firstFocus)
                                                .onFocusChanged {
                                                    if (it.isFocused) landed = true
                                                }
                                        } else {
                                            Modifier
                                        },
                                    ),
                        )
                        PlavioFilterCapsule(
                            text = stringResource(R.string.plavio_lists_rename),
                            selected = renameTarget?.id == list.id,
                            onClick = {
                                renameTarget = list
                                renameText = list.name
                            },
                        )
                        PlavioFilterCapsule(
                            text = stringResource(R.string.plavio_lists_delete),
                            selected = false,
                            onClick = { deleteTarget = list },
                        )
                    }
                }
            }
        }
        val renaming = renameTarget
        if (renaming != null) {
            PlavioClickToEditField(
                value = renameText,
                onValueChange = { renameText = it },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions =
                    androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
                        imeAction = androidx.compose.ui.text.input.ImeAction.Done,
                    ),
                emptyHint = stringResource(R.string.plavio_lists_rename_hint),
            )
            PlavioFixedButton(
                text = stringResource(R.string.plavio_lists_save),
                onClick = {
                    if (renameText.isNotBlank()) onRenameList(renaming.id, renameText)
                    renameTarget = null
                },
                enabled = renameText.isNotBlank(),
                kind = PlavioButtonKind.Primary,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        PlavioClickToEditField(
            value = newName,
            onValueChange = { newName = it },
            modifier =
                Modifier
                    .fillMaxWidth()
                    .then(
                        if (lists.isEmpty()) {
                            Modifier
                                .focusRequester(firstFocus)
                                .onFocusChanged { if (it.isFocused) landed = true }
                        } else {
                            Modifier
                        },
                    ),
            keyboardOptions =
                androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
                    imeAction = androidx.compose.ui.text.input.ImeAction.Done,
                ),
            emptyHint = stringResource(R.string.plavio_lists_new_name_hint),
        )
        PlavioFixedButton(
            text = stringResource(R.string.plavio_lists_create),
            onClick = {
                if (newName.isNotBlank()) {
                    onCreateList(newName)
                    newName = ""
                }
            },
            enabled = newName.isNotBlank(),
            kind = PlavioButtonKind.Primary,
            modifier = Modifier.fillMaxWidth(),
        )
    }
    deleteTarget?.let { target ->
        PlavioConfirmDialog(
            title = stringResource(R.string.plavio_lists_delete_title),
            message = stringResource(R.string.plavio_lists_delete_message, target.name),
            confirmText = stringResource(R.string.plavio_lists_delete),
            dismissText = stringResource(R.string.plavio_cancel),
            danger = true,
            onConfirm = {
                onDeleteList(target.id)
                if (renameTarget?.id == target.id) renameTarget = null
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null },
        )
    }
}

/**
 * The full synopsis, readable by remote (v0.3.11). The page's summary
 * block used to expand IN PLACE as one giant focusable surface: the
 * expanded item grew taller than the viewport, focus landed on the
 * text box itself, and Up/Left from the Play row had nowhere sane to
 * go — users backed out of the page to escape (the owner's report).
 * Now the page's text is never a focus stop; this overlay carries the
 * full text in a focusable scroll area (D-pad Up/Down scrolls while
 * there is more to scroll, then falls through to the Close button),
 * Back closes it, and focus returns to the Read more button.
 */
@Composable
private fun SummaryOverlay(
    title: String,
    text: String,
    onClose: () -> Unit,
) {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val textFocus = remember { FocusRequester() }
    // Landed-checked entry (v0.3.12): stop the moment the text
    // verifiably holds focus — the v0.3.11 loop fired all 8 shots
    // blind, and a shot landing AFTER the user had already moved to
    // the Close button dragged focus back onto the text.
    var textLanded by remember { mutableStateOf(false) }
    // v0.3.13: the loop also stands down the moment the viewer
    // presses a navigation key (the overlay root's preview handler
    // stamps it) — pressing Down toward Close inside the landing
    // window must never be answered by another shot at the text.
    var lastKeyMs by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        // v0.3.14: the shared landing primitive — same semantics as
        // the hand-rolled loop it replaces (stop on the text's own
        // landed flag or on any navigation keypress).
        val keyAtStart = lastKeyMs
        landFocus(
            requester = textFocus,
            isClaimed = { textLanded || lastKeyMs != keyAtStart },
            attempts = 10,
            delayMs = 120,
        )
    }
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        (
                            event.key == Key.DirectionUp ||
                                event.key == Key.DirectionDown ||
                                event.key == Key.DirectionLeft ||
                                event.key == Key.DirectionRight ||
                                event.key == Key.DirectionCenter ||
                                event.key == Key.Enter ||
                                event.key == Key.NumPadEnter
                        )
                    ) {
                        lastKeyMs = android.os.SystemClock.uptimeMillis()
                    }
                    false
                },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier =
                Modifier
                    .width(760.dp)
                    .fillMaxHeight(0.84f)
                    .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                    .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                    .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier =
                    Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .focusRequester(textFocus)
                        .onFocusChanged { if (it.isFocused) textLanded = true }
                        .focusable()
                        .onPreviewKeyEvent { event ->
                            if (event.type != KeyEventType.KeyDown) {
                                false
                            } else {
                                when (event.key) {
                                    Key.DirectionDown ->
                                        if (scrollState.canScrollForward) {
                                            scope.launch(CrashReports.backgroundScopeHandler) {
                                                scrollState.scrollBy(160f)
                                            }
                                            true
                                        } else {
                                            false
                                        }
                                    Key.DirectionUp ->
                                        if (scrollState.canScrollBackward) {
                                            scope.launch(CrashReports.backgroundScopeHandler) {
                                                scrollState.scrollBy(-160f)
                                            }
                                            true
                                        } else {
                                            false
                                        }
                                    else -> false
                                }
                            }
                        },
            )
            PlavioFixedButton(
                text = stringResource(R.string.plavio_close),
                onClick = onClose,
                modifier = Modifier.width(150.dp),
            )
        }
    }
}

/**
 * Detail's loading face (v0.3.13): the preview backdrop/poster from
 * the tapped card under the same scrims the loaded header uses, the
 * title's name, and static skeleton bars where the fact pills and
 * action buttons will appear. Static on purpose — no shimmer tax on
 * a weak TV box.
 */
@Composable
private fun DetailLoadingLayer(destination: PlavioDestination.Detail) {
    val background = MaterialTheme.colorScheme.background
    // v0.3.29: the loading face stands in for the Sample B band,
    // so it wears the band's own geometry (top ~42%) — the swap
    // to the loaded page must not change the picture's shape.
    // v0.3.30: the melt point moves with the band's (0.85f).
    val bandHeight = LocalConfiguration.current.screenHeightDp.dp * 0.42f
    val bandHeightPx = with(LocalDensity.current) { bandHeight.toPx() }
    Box(modifier = Modifier.fillMaxSize()) {
        val art = destination.previewBackground ?: destination.previewPoster
        if (art != null) {
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalContext.current)
                        .data(art)
                        .size(1280, 720)
                        .crossfade(false)
                        .build(),
                contentDescription = destination.previewName,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(bandHeight)
                        .align(Alignment.TopStart),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(bandHeight)
                        .align(Alignment.TopStart)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, background),
                                startY = bandHeightPx * 0.85f,
                            ),
                        ),
            )
        }
        Column(
            modifier =
                Modifier
                    .align(Alignment.TopStart)
                    .padding(end = 48.dp, top = 24.dp, bottom = 24.dp)
                    // v0.3.12: the old extra 190dp top pad existed
                    // only to clear the brand lockup; the lockup
                    // floats now (reserves nothing), so the loading
                    // face starts at the normal top margin like the
                    // loaded hero.
                    .padding(top = 46.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (!destination.previewName.isNullOrBlank()) {
                Text(
                    text = destination.previewName ?: "",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            // Skeleton: fact-pill row + synopsis lines.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(4) {
                    Box(
                        modifier =
                            Modifier
                                .size(width = 64.dp, height = 26.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.10f)),
                    )
                }
            }
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth(0.62f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth(0.45f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.padding(top = 6.dp),
            ) {
                OrbitLoader(modifier = Modifier.size(32.dp))
                Text(
                    text = stringResource(R.string.plavio_detail_loading),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * v0.3.14: the old restoreDetailFocus helper that lived here is
 * DELETED. It was the v0.3.12 mechanism (primary/fallback request
 * bursts with landed flags) that fought live navigation on the
 * owner's TV, and its v0.3.13 claim-gated descendants could still
 * strand focus on an off-screen target. All Detail landings now go
 * through the armed-restore machine in DetailContent (arm-at-click
 * records fired once via the shared landFocus primitive — see
 * PlavioFocus.kt).
 */

/** The episode Watch Now targets: the first regular episode (season 1+ when present). */
private fun firstEpisode(meta: MetaDetail): Video? {
    if (meta.type != "series") return null
    val sorted = meta.videos.sortedWith(compareBy({ it.season }, { it.episode }))
    return sorted.firstOrNull { it.season >= 1 } ?: sorted.firstOrNull()
}

@Composable
private fun DetailContent(
    meta: MetaDetail,
    related: List<RelatedSection>,
    episodeProgress: Map<String, Float>,
    episodeWatchedIds: Set<String>,
    /** Batch 6: the Playback spoiler-blur switch, threaded to the episode rows. */
    blurUnwatched: Boolean,
    /** v0.3.33: the episode watched menu (EpisodeWatchedPanel, at
     * the screen level) — its open state joins the overlay trap
     * below, a row's HOLD OK reports the episode here, and the
     * menu's close fires the Episode restore the hold armed. */
    episodeMenuOpen: Boolean,
    onEpisodeMenuClick: (Video) -> Unit,
    onWatchNowClick: () -> Unit,
    onSourcesClick: () -> Unit,
    sourcesOpen: Boolean,
    /** Batch 5: the Lists panel + download season. */
    listsOpen: Boolean,
    /** Batch 7: the 3-dots overflow popup (DetailMorePanel, at the
     * screen level) — its open state joins the overlay trap below,
     * and its close fires the Opener("more") restore. */
    moreOpen: Boolean,
    onMoreClick: () -> Unit,
    seasonNotice: String?,
    onDownloadSeasonClick: (Int) -> Unit,
    summaryOpen: Boolean,
    onReadMoreClick: () -> Unit,
    readMoreFocus: FocusRequester,
    watchFocus: FocusRequester,
    watchLandedState: androidx.compose.runtime.MutableState<Boolean>,
    readMoreLandedState: androidx.compose.runtime.MutableState<Boolean>,
    readMoreAttachedState: androidx.compose.runtime.MutableState<Boolean>,
    claim: FocusClaim,
    armState: androidx.compose.runtime.MutableState<DetailRestore?>,
    initialRecord: DetailRestore?,
    onConsumeRecord: () -> Unit,
    arm: (DetailRestore) -> Unit,
    onReadMorePresenceChange: (Boolean) -> Unit,
    onReadMoreLanded: () -> Unit,
    onSourcesButtonClick: () -> Unit,
    autoplay: Boolean,
    onEpisodePlay: (MetaDetail, Video) -> Unit,
    onEpisodeClick: (MetaDetail, Video) -> Unit,
    onActorClick: (CastMember) -> Unit,
    onRelatedClick: (MetaPreview) -> Unit,
) {
    val background = MaterialTheme.colorScheme.background
    // Backdrop band height: a percentage of the actual screen
    // height, per the owner's adaptive-layout rule, never a fixed
    // dp tuned to one TV. v0.3.29 (Sample B): 42%, title only
    // inside. v0.3.32 (owner's Sample A pick, 2026-11-17): the
    // band becomes the full hero — 76% of the screen — carrying
    // the whole bottom-anchored stack (logo → fact pills →
    // buttons → 2-line synopsis) over the full-bleed backdrop,
    // with Cast and the sections below it; the band is a
    // LazyColumn item, so the whole hero scrolls away with the
    // page exactly as the owner ordered. v0.3.33 (owner, from his
    // .32 photo — the backdrop still read SMALL): the band grows
    // by a relative 20% — 0.76 × 1.2 = 0.912 of the screen. The
    // stack stays bottom-anchored inside the band, so it simply
    // rides lower with the same shape; the melt (0.45 of the
    // band, below) scales with it; the sections below scroll as
    // before.
    val bandHeight = LocalConfiguration.current.screenHeightDp.dp * 0.912f
    // Hero text margin (v0.3.12): v0.3.11 pushed this column to a
    // 190dp absolute start so it would clear the top-left brand
    // lockup. The lockup floats now and reserves nothing; the page
    // content starts at the shared margin (the root pad — exactly
    // beside the capsule), and the hero text keeps only its own
    // 24dp inset inside the hero, like the Home hero's. It sits at
    // the hero's bottom — far below the lockup's band — so no text
    // ever runs under the floating logo or the capsule.
    val seasons = meta.videos.groupBy { it.season }.toSortedMap()
    // Season capsule state lives HERE, in the composable body —
    // LazyListScope is not a composable context, so remember()
    // cannot be called from inside the list block.
    val seasonNumbers = seasons.keys.toList()
    var selectedSeason by remember(meta.id) {
        mutableStateOf(seasonNumbers.firstOrNull { it >= 1 } ?: seasonNumbers.firstOrNull() ?: 1)
    }
    // ---- The armed-restore machine (v0.3.14, the focus rebuild) --
    // Everything the v0.3.12 helper and the v0.3.13 loops did is
    // replaced by this: click handlers ARM a typed record (see the
    // arm() calls on the buttons/rows below) naming the exact target
    // to return to; the four sanctioned moments — page entry, the
    // playing→stopped flip, an overlay's close, the capsule's return
    // transfer — FIRE the record exactly once through landFocus.
    // Firing scrolls the target into the window BEFORE requesting
    // it, so a landing is never on an off-screen/invisible node (the
    // v0.3.13 failure: focus sat on a Play button nobody could see).
    // The claim cancels everything the moment the viewer takes the
    // remote himself. No other code on this page requests focus.
    val detailListState = androidx.compose.foundation.lazy.rememberLazyListState()
    val detailScope = rememberCoroutineScope()
    val sourcesBtnFocus = remember { FocusRequester() }
    var sourcesBtnLanded by remember { mutableStateOf(false) }
    // Batch 7: the Lists button is gone — the 3-dots button is the
    // focus anchor for BOTH opener records now: Opener("more")
    // (the overflow popup) and Opener("lists") (the Lists panel,
    // reached through the popup) land here.
    val moreBtnFocus = remember { FocusRequester() }
    var moreBtnLanded by remember { mutableStateOf(false) }
    val episodeRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val castRequesters = remember { mutableMapOf<Int, FocusRequester>() }
    val relatedRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val castRowState = androidx.compose.foundation.lazy.rememberLazyListState()
    val relatedRowStates =
        remember { mutableMapOf<String, androidx.compose.foundation.lazy.LazyListState>() }
    fun episodeRequester(id: String): FocusRequester =
        episodeRequesters.getOrPut(id) { FocusRequester() }

    // LazyColumn item indexes, mirroring the item order emitted
    // below (v0.3.32, Sample A): spacer (0), hero band (1 —
    // carries logo, pills, actions AND the synopsis since this
    // build; the old poster/actions item and the standalone
    // summary item are gone), cast?, season header?, episode
    // rows…, related sections…
    fun episodeItemIndex(position: Int): Int {
        var idx = 2
        if (meta.cast.isNotEmpty()) idx++
        idx++ // season capsules header
        return idx + position
    }

    fun castItemIndex(): Int = 2

    fun relatedItemIndex(sectionPos: Int): Int {
        var idx = 2
        if (meta.cast.isNotEmpty()) idx++
        if (meta.type == "series") {
            idx +=
                if (meta.videos.isEmpty()) {
                    1
                } else {
                    1 + (seasons[selectedSeason]?.size ?: 0)
                }
        }
        return idx + sectionPos
    }

    suspend fun fireRestore(record: DetailRestore) {
        claim.release()
        val stampAtStart = claim.lastKeyMs.value
        watchLandedState.value = false
        sourcesBtnLanded = false
        moreBtnLanded = false
        readMoreLandedState.value = false
        val done = { claim.claimed.value || claim.lastKeyMs.value != stampAtStart }
        suspend fun landWatch() {
            // v0.3.16 (note 7): INSTANT scroll, not animated. The
            // animated scroll took tens of frames on a scrolled-deep
            // page; the capsule exit's geometric rescue pushes began
            // mid-animation, landed on transient rows the scroll then
            // disposed, tripped this page's claim, and stood the
            // landing down — RIGHT from the capsule's lower buttons
            // "did nothing" (from Home it worked: its rescue landed
            // on the hero row the scroll never disposes). An instant
            // scroll puts the target in composition on the spot, the
            // landing fires while the list is still, and the rescue
            // is never needed. All restore branches scroll instantly
            // now; the landing TARGETS are unchanged (episode-exact
            // returns keep their exact rows).
            runCatching { detailListState.scrollToItem(1) }
            landFocus(watchFocus, isClaimed = { done() || watchLandedState.value })
        }
        when (record) {
            DetailRestore.Watch -> landWatch()

            is DetailRestore.Episode -> {
                var settled = false
                if (seasons.containsKey(record.season)) {
                    if (selectedSeason != record.season) {
                        selectedSeason = record.season
                        // Let the episode list recompose for the
                        // newly selected season before addressing it.
                        kotlinx.coroutines.delay(180)
                    }
                    val eps = (seasons[record.season] ?: emptyList()).sortedBy { it.episode }
                    val pos = eps.indexOfFirst { it.id == record.videoId }
                    if (pos >= 0) {
                        runCatching { detailListState.scrollToItem(episodeItemIndex(pos)) }
                        settled =
                            landFocus(episodeRequester(record.videoId), isClaimed = done)
                    }
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.CastMember -> {
                var settled = false
                val pos = meta.cast.indexOfFirst { it.id == record.memberId }
                if (pos >= 0) {
                    runCatching { detailListState.scrollToItem(castItemIndex()) }
                    runCatching { castRowState.scrollToItem(pos) }
                    settled =
                        landFocus(
                            castRequesters.getOrPut(record.memberId) { FocusRequester() },
                            isClaimed = done,
                        )
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.Related -> {
                var settled = false
                for ((sectionPos, section) in related.withIndex()) {
                    val pos =
                        section.metas.indexOfFirst {
                            it.type == record.type && it.id == record.id
                        }
                    if (pos < 0) continue
                    runCatching {
                        detailListState.scrollToItem(relatedItemIndex(sectionPos))
                    }
                    runCatching {
                        relatedRowStates
                            .getOrPut(section.id) {
                                androidx.compose.foundation.lazy.LazyListState()
                            }
                            .scrollToItem(pos)
                    }
                    settled =
                        landFocus(
                            relatedRequesters.getOrPut("${record.type}|${record.id}") {
                                FocusRequester()
                            },
                            isClaimed = done,
                        )
                    break
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.Opener -> {
                val settled =
                    when (record.which) {
                        "sources" ->
                            landFocus(
                                sourcesBtnFocus,
                                isClaimed = { done() || sourcesBtnLanded },
                            )
                        "lists", "more" ->
                            landFocus(
                                moreBtnFocus,
                                isClaimed = { done() || moreBtnLanded },
                            )
                        else ->
                            if (readMoreAttachedState.value) {
                                landFocus(
                                    readMoreFocus,
                                    isClaimed = { done() || readMoreLandedState.value },
                                )
                            } else {
                                false
                            }
                    }
                if (!settled && !done()) landWatch()
            }
        }
    }

    fun consume(record: DetailRestore?) {
        if (record != null) {
            armState.value = null
            onConsumeRecord()
        }
    }

    // Sanctioned moment 1 — page entry: fire the record a pushed
    // child left armed (return from Streams/Actor/related Detail),
    // else the default home-position landing.
    LaunchedEffect(meta.id) {
        val record = armState.value ?: initialRecord
        fireRestore(record ?: DetailRestore.Watch)
        consume(record)
    }
    // Sanctioned moment 2 — the playing→stopped flip: the player
    // tree took focus away with it; fire what the play click armed
    // (the played episode's own row for episodes, Watch otherwise).
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            val record = armState.value
            fireRestore(record ?: DetailRestore.Watch)
            consume(record)
        }
    }
    // Sanctioned moment 3 — an overlay closes: fire ONLY its opener
    // record. (A Sources pick arms Watch instead and closes into the
    // player; moment 2 owns that return, so this effect deliberately
    // leaves a Watch arm untouched.)
    var sourcesWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(sourcesOpen) {
        if (sourcesOpen) {
            sourcesWasOpen = true
        } else if (sourcesWasOpen) {
            sourcesWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "sources") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    var summaryWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(summaryOpen) {
        if (summaryOpen) {
            summaryWasOpen = true
        } else if (summaryWasOpen) {
            summaryWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "summary") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    var listsWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(listsOpen) {
        if (listsOpen) {
            listsWasOpen = true
        } else if (listsWasOpen) {
            listsWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "lists") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    // The overflow popup's close (batch 7): same discipline — fire
    // ONLY its own opener record. (Its Play from Beginning row arms
    // Watch and closes into the player, and its Lists row re-arms
    // "lists" and hands over to the Lists panel; both are left
    // untouched here, exactly like a Sources pick.)
    var moreWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(moreOpen) {
        if (moreOpen) {
            moreWasOpen = true
        } else if (moreWasOpen) {
            moreWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "more") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    // The episode watched menu's close (v0.3.33): same discipline —
    // fire ONLY the Episode record the row's HOLD OK armed, so
    // focus lands back on that episode's row. The menu's Sources
    // row is the one close that must NOT fire here: with autoplay
    // it opens the player over this page, and the playing→stopped
    // flip (moment 2, declared above, so it runs first on that
    // flip) owns the return to the same Episode arm; without
    // autoplay it pushes the Streams page, which disposes this
    // content and leaves the arm with the root for moment 1. The
    // playerActive gate below is what tells the two closes apart:
    // a mark/unmark row or a Back press closes the menu with the
    // player inactive; a Sources-into-player close never does.
    var episodeMenuWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(episodeMenuOpen, playerActive) {
        if (episodeMenuOpen) {
            episodeMenuWasOpen = true
        } else if (episodeMenuWasOpen && !playerActive) {
            episodeMenuWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Episode) {
                fireRestore(record)
                consume(record)
            }
        }
    }
    // Sanctioned moment 4 — the capsule's return transfer: the
    // scripted trip back from the side capsule lands HERE, on the
    // armed target or the visible home position (fireRestore
    // scrolls first) — never on geometric luck, never invisible.
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            detailScope.launch(CrashReports.backgroundScopeHandler) {
                val record = armState.value
                fireRestore(record ?: DetailRestore.Watch)
                consume(record)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    LazyColumn(
        state = detailListState,
        modifier =
            Modifier
                .fillMaxSize()
                .focusProperties {
                    canFocus =
                        !sourcesOpen && !summaryOpen && !listsOpen && !moreOpen && !episodeMenuOpen
                },
        contentPadding = PaddingValues(bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            // v0.3.29: this item used to be the clear-top strip
            // (the v0.3.20 D clear-space rule: title art kept
            // below the floating corner brand's band). The corner
            // brand is removed on every screen now, so the strip
            // is gone and the band starts at the page's very top
            // (Sample B). The item itself stays — at zero height —
            // because the restore machine's item-index arithmetic
            // counts it; removing the item would shift every
            // index below it.
            Spacer(Modifier.height(0.dp))
        }
        item {
            // The hero band (v0.3.32, Sample A — supersedes the
            // v0.3.29 Sample B band): the full-bleed backdrop
            // across the top ~91% of the screen (0.76 in .32,
            // ×1.2 in .33), melting into
            // the page background at its bottom edge; the whole
            // hero stack (logo → ratings/fact pills → actions →
            // 2-line synopsis) sits bottom-anchored inside it.
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(bandHeight),
            ) {
                val backdrop = meta.background ?: meta.poster
                if (backdrop != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(backdrop)
                                .size(1280, 720)
                                .crossfade(false)
                                .build(),
                        contentDescription = meta.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                val bandHeightPx = with(LocalDensity.current) { bandHeight.toPx() }
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, background),
                                    // v0.3.32 (Sample A): the hero
                                    // stack now lives INSIDE the
                                    // band's lower half, so the melt
                                    // starts at 45% of the band —
                                    // the art stays clear over the
                                    // top, deepens behind the stack
                                    // for legibility, and dissolves
                                    // into the page at the band's
                                    // bottom edge. (The .30 85%
                                    // start belonged to the
                                    // title-only band.)
                                    startY = bandHeightPx * 0.45f,
                                ),
                            ),
                )
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors =
                                        listOf(
                                            Color.Black.copy(alpha = 0.5f),
                                            Color.Transparent,
                                        ),
                                ),
                            ),
                )
                Column(
                    modifier =
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 24.dp, end = 48.dp, top = 24.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    // v0.3.32 (Sample A): no kicker line — the
                    // stack opens with the title/logo itself, and
                    // the genre rides the fact pills below (the
                    // type/genre kicker duplicated them).
                    // Title logo art, progressive (v0.3.17): the TEXT
                    // title renders first and the logo replaces it
                    // only once it has actually loaded — a slow or
                    // dead logo URL can never leave the title area
                    // blank, and the screen never waits on the image.
                    val logoPainter =
                        coil3.compose.rememberAsyncImagePainter(
                            model =
                                ImageRequest
                                    .Builder(LocalContext.current)
                                    .data(meta.logo)
                                    .size(600, 144)
                                    .crossfade(false)
                                    .build(),
                        )
                    val logoState by logoPainter.state.collectAsState()
                    if (meta.logo != null &&
                        logoState is coil3.compose.AsyncImagePainter.State.Success
                    ) {
                        androidx.compose.foundation.Image(
                            painter = logoPainter,
                            contentDescription = meta.name,
                            contentScale = ContentScale.Fit,
                            modifier =
                                Modifier
                                    .height(72.dp)
                                    .width(300.dp),
                        )
                    } else {
                        Text(
                            text = meta.name,
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    // v0.3.32 (Sample A): the hero carries the
                    // whole stack now — the blocks that used to
                    // live in the poster row below the band
                    // (ratings, fact pills, actions) and the
                    // standalone summary section move INTO the
                    // band, in the sample's order. Every fact
                    // still lives in exactly one place.
                    // Multi-source ratings row (v0.3.17): renders ONLY
                    // when the serving meta provides 2+ ratings — the
                    // badges then take the single IMDb pill's place.
                    // Single-rating titles keep today's display as-is.
                    val showRatings = meta.ratings.size >= 2
                    if (showRatings) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            meta.ratings.take(5).forEach { rating -> RatingBadge(rating) }
                        }
                    }
                    // Facts + genres in ONE flow row (v0.3.21, the
                    // sample's rule): every fact pill and every genre
                    // pill wraps in a single block — nothing dropped,
                    // nothing in a second row.
                    val pills =
                        listOfNotNull(
                            meta.releaseInfo,
                            meta.imdbRating?.takeIf { !showRatings }?.let { "★ $it IMDb" },
                            meta.runtime,
                            meta.certification,
                            meta.status,
                            meta.network,
                            meta.country,
                        ) + meta.genres
                    if (pills.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            pills.forEach { pill -> FactPill(text = pill) }
                        }
                    }
                    // The actions row (moved verbatim from the old
                    // below-band block): Watch Now / Download /
                    // Sources, and (batch 7) the 3-dots overflow at
                    // the end. v0.3.17 (owner note 3): the labelled
                    // actions share the row width by weight with a
                    // 150dp cap, so every button stays on screen on
                    // narrower panels too.
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        // v0.3.16 (notes 2 + 9): the Watch Now
                        // capsule rests ghost-style and takes the
                        // travelling white fill on focus (Sample A),
                        // and a press opens the player IMMEDIATELY —
                        // the button never shows a "Finding…" state
                        // and is never disabled by resolution; the
                        // finding happens inside the player.
                        // v0.3.29 (owner's ruling, 2026-11-16): the
                        // label is "Watch Now", same as mobile —
                        // the row's order is unchanged (Watch Now /
                        // Download / Sources / 3-dots).
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_detail_watch),
                            onClick = {
                                arm(DetailRestore.Watch)
                                onWatchNowClick()
                            },
                            kind = PlavioButtonKind.Primary,
                            whiteFocus = true,
                            leadingIcon = Icons.Filled.PlayArrow,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .widthIn(max = 150.dp)
                                    .onFocusChanged { if (it.isFocused) watchLandedState.value = true },
                            focusRequester = watchFocus,
                        )
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_download),
                            whiteFocus = true,
                            onClick = {
                                // Download leaves for the streams page
                                // of the first episode — arm its row.
                                val first = firstEpisode(meta)
                                arm(
                                    if (first != null) {
                                        DetailRestore.Episode(first.id, first.season)
                                    } else {
                                        DetailRestore.Watch
                                    },
                                )
                                onSourcesClick()
                            },
                            leadingIcon = PlavioIcons.Download,
                            modifier = Modifier.weight(1f).widthIn(max = 150.dp),
                        )
                        // Source (v0.3.22): opens the player's own
                        // sources popup over this page (see the
                        // overlay in PlavioDetailScreen) — a manual
                        // source pick without leaving the page.
                        // v0.3.20 (owner photo verdict): whiteFocus —
                        // same shared mechanism, same fill as the
                        // rest of the row.
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_player_sources),
                            onClick = {
                                arm(DetailRestore.Opener("sources"))
                                onSourcesButtonClick()
                            },
                            whiteFocus = true,
                            leadingIcon = Icons.AutoMirrored.Filled.List,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .widthIn(max = 150.dp)
                                    .onFocusChanged { if (it.isFocused) sourcesBtnLanded = true },
                            focusRequester = sourcesBtnFocus,
                        )
                        // The 3-dots overflow (batch 7): the row's
                        // last stop. Opens DetailMorePanel (My List,
                        // Play from Beginning, Mark as Watched,
                        // Remove from Continue Watching, Lists) and
                        // is the focus anchor its close lands on —
                        // and the Lists panel's close too, since the
                        // Lists button itself lives in the popup now.
                        // Same capsule, same travelling white fill;
                        // a fixed narrow width — it carries an icon,
                        // not a label.
                        PlavioFixedButton(
                            text = "",
                            onClick = {
                                arm(DetailRestore.Opener("more"))
                                onMoreClick()
                            },
                            whiteFocus = true,
                            leadingIcon = PlavioIcons.MoreHoriz,
                            modifier =
                                Modifier
                                    .width(64.dp)
                                    .onFocusChanged {
                                        if (it.isFocused) moreBtnLanded = true
                                    },
                            focusRequester = moreBtnFocus,
                        )
                    }
                    // Synopsis (v0.3.32, Sample A): TWO lines at
                    // ~60% width, directly under the actions — no
                    // heading, no separate section (the standalone
                    // Summary section is gone). The accent "more"
                    // suffix hints at overflow exactly as before,
                    // and the Read more button under the text —
                    // shown only when the text actually overflows,
                    // measured on the collapsed state — still opens
                    // the full SummaryOverlay, with the same
                    // presence/landed tracking the restore machine
                    // depends on (v0.3.12 discipline, unchanged).
                    meta.description?.takeIf { it.isNotBlank() }?.let { description ->
                        var synopsisOverflows by remember(meta.id) { mutableStateOf(false) }
                        val accent = LocalPlavioAccent.current.primary
                        val moreText = stringResource(R.string.plavio_more)
                        val shown =
                            remember(description, synopsisOverflows, accent, moreText) {
                                buildAnnotatedString {
                                    append(description.trim())
                                    if (synopsisOverflows) {
                                        append("  ")
                                        withStyle(
                                            SpanStyle(color = accent, fontWeight = FontWeight.SemiBold),
                                        ) {
                                            append(moreText)
                                        }
                                    }
                                }
                            }
                        Text(
                            text = shown,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            onTextLayout = { layout ->
                                synopsisOverflows = layout.hasVisualOverflow
                            },
                            modifier = Modifier.fillMaxWidth(0.60f),
                        )
                        if (synopsisOverflows) {
                            androidx.compose.runtime.DisposableEffect(meta.id) {
                                onReadMorePresenceChange(true)
                                onDispose { onReadMorePresenceChange(false) }
                            }
                            PlavioFixedButton(
                                text = stringResource(R.string.plavio_read_more),
                                onClick = {
                                    arm(DetailRestore.Opener("summary"))
                                    onReadMoreClick()
                                },
                                modifier =
                                    Modifier
                                        .width(170.dp)
                                        .onFocusChanged { if (it.isFocused) onReadMoreLanded() },
                                focusRequester = readMoreFocus,
                            )
                        }
                    }
                }
            }
        }

        if (meta.cast.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_detail_cast),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier =
                            Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                    )
                    LazyRow(
                        state = castRowState,
                        contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(
                            meta.cast,
                            key = { index, member -> "${member.id}|${member.name}|$index" },
                        ) { _, member ->
                            PersonCard(
                                member = member,
                                onClick = {
                                    arm(
                                        DetailRestore.CastMember(member.id, member.name),
                                    )
                                    onActorClick(member)
                                },
                                focusRequester =
                                    castRequesters.getOrPut(member.id) { FocusRequester() },
                            )
                        }
                    }
                }
            }
        }

        if (meta.type == "series") {
            if (meta.videos.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.plavio_detail_no_episodes),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 48.dp, top = 16.dp, bottom = 16.dp),
                    )
                }
            } else {
                // Season capsules (v0.3.21, the sample): one capsule
                // per season; the episode list shows the picked
                // season only. Default = the first regular season
                // (state hoisted to the composable body above).
                item(key = "season-capsules") {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = stringResource(R.string.plavio_detail_episodes),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier =
                                Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                        )
                        LazyRow(
                            contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(seasonNumbers, key = { "season|$it" }) { season ->
                                PlavioFilterCapsule(
                                    text =
                                        if (season == 0) {
                                            stringResource(R.string.plavio_detail_specials)
                                        } else {
                                            "S$season"
                                        },
                                    selected = season == selectedSeason,
                                    onClick = { selectedSeason = season },
                                )
                            }
                        }
                        // Download season (batch 5): queues every
                        // episode of the SELECTED season through the
                        // download manager (autoplay-pick quality
                        // rules; the Wi-Fi-only gate applies inside).
                        // The notice line reports the outcome in the
                        // streams screen's own words.
                        Row(
                            modifier = Modifier.padding(top = 10.dp, end = 48.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            PlavioFixedButton(
                                text =
                                    stringResource(R.string.plavio_detail_download_season),
                                onClick = { onDownloadSeasonClick(selectedSeason) },
                                whiteFocus = true,
                                leadingIcon = PlavioIcons.Download,
                                modifier = Modifier.widthIn(max = 220.dp),
                            )
                            if (seasonNotice != null) {
                                Text(
                                    text = seasonNotice ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
                val episodes = (seasons[selectedSeason] ?: emptyList()).sortedBy { it.episode }
                itemsIndexed(
                    episodes,
                    key = { index, video -> "${video.id}|$index" },
                ) { _, video ->
                    EpisodeRow(
                        video = video,
                        progress = episodeProgress[video.id],
                        watchedMarked = video.id in episodeWatchedIds,
                        spoilerBlurEnabled = blurUnwatched,
                        // HOLD OK opens the watched menu (v0.3.33):
                        // arm BEFORE opening, exactly like the
                        // click below — the menu's close (or the
                        // return from wherever its Sources row
                        // leads) lands back on THIS episode's row.
                        onLongClick = {
                            arm(DetailRestore.Episode(video.id, video.season))
                            onEpisodeMenuClick(video)
                        },
                        // Episode direct play (v0.3.10, user feedback):
                        // with autoplay on, tapping an episode PLAYS it
                        // (same rule as the Watch Now button) instead of
                        // opening the picker first. Autoplay off keeps
                        // today's behaviour — the picker for that episode.
                        onClick = {
                            // Arm BEFORE leaving (v0.3.14): whichever
                            // way this episode opens — direct play or
                            // the streams page — the return lands on
                            // THIS episode's row, not the page top.
                            arm(DetailRestore.Episode(video.id, video.season))
                            if (autoplay) {
                                onEpisodePlay(meta, video)
                            } else {
                                onEpisodeClick(meta, video)
                            }
                        },
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(end = 48.dp, top = 6.dp, bottom = 6.dp)
                                .focusRequester(episodeRequester(video.id)),
                    )
                }
            }
        }

        related.forEach { section ->
            item(key = "related|${section.id}") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = section.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier =
                            Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                    )
                    LazyRow(
                        state =
                            relatedRowStates.getOrPut(section.id) {
                                androidx.compose.foundation.lazy.LazyListState()
                            },
                        contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(
                            section.metas,
                            key = { index, item -> "${item.type}|${item.id}|$index" },
                        ) { _, item ->
                            SharedPosterCard(
                                item = item,
                                onClick = {
                                    arm(DetailRestore.Related(item.type, item.id))
                                    onRelatedClick(item)
                                },
                                focusRequester =
                                    relatedRequesters.getOrPut("${item.type}|${item.id}") {
                                        FocusRequester()
                                    },
                            )
                        }
                    }
                }
            }
        }
    }
}

/** One source + score rating badge (v0.3.17): the FactPill chrome, source muted, score bold. */
@Composable
private fun RatingBadge(rating: com.github.damontecres.wholphin.plavio.MetaRating) {
    Row(
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(PlavioOnyx.GlassFill)
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = rating.source,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
        Text(
            text = rating.score,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@Composable
private fun FactPill(text: String) {
    Box(
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(PlavioOnyx.GlassFill)
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 5.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@Composable
private fun EpisodeRow(
    video: Video,
    progress: Float?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    /** Watched via the watched store (a manual mark, or a finished play). */
    watchedMarked: Boolean = false,
    /** v0.3.33: HOLD OK on the row — opens the episode watched menu. */
    onLongClick: () -> Unit = {},
    /** Batch 6: the Playback spoiler-blur switch (Settings → Playback). */
    spoilerBlurEnabled: Boolean = false,
) {
    // HOLD OK (v0.3.33 — the owner's "do like Nuvio" order): the
    // remote's centre key held past the threshold opens the
    // watched menu; a short press stays the row's click, exactly
    // as before. The detector rides a preview key handler on the
    // card itself — it only ever CONSUMES the release of a press
    // that already fired the menu, so the held press cannot also
    // click the row underneath its own menu; every other event
    // passes through untouched (the page root's claim sensor, the
    // card's own press handling, D-pad movement — all unchanged).
    val rowScope = rememberCoroutineScope()
    var holdJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var holdFired by remember { mutableStateOf(false) }
    val holdModifier =
        Modifier.onPreviewKeyEvent { event ->
            val isCenter =
                event.key == Key.DirectionCenter ||
                    event.key == Key.Enter ||
                    event.key == Key.NumPadEnter
            if (!isCenter) {
                false
            } else {
                when (event.type) {
                    KeyEventType.KeyDown -> {
                        if (event.nativeKeyEvent.repeatCount == 0) {
                            holdFired = false
                            holdJob?.cancel()
                            holdJob =
                                rowScope.launch {
                                    kotlinx.coroutines.delay(550)
                                    holdFired = true
                                    onLongClick()
                                }
                        }
                        false
                    }
                    KeyEventType.KeyUp -> {
                        holdJob?.cancel()
                        holdJob = null
                        val fired = holdFired
                        holdFired = false
                        fired
                    }
                    else -> false
                }
            }
        }
    Card(
        onClick = onClick,
        modifier = modifier.then(holdModifier),
        shape = plavioCardShape(),
        colors = plavioCardColors(),
        border = plavioCardBorder(),
        scale = plavioCardScale(),
    ) {
        // Watched = finished progress OR a manual mark in the
        // watched store (v0.3.26) — computed here so both the state
        // line and the toggle capsule read the same value.
        val watched = watchedMarked || (progress != null && progress >= 0.95f)
        // Spoiler blur (batch 6): an unwatched, unstarted episode's
        // picture stays blurred — the decision is SpoilerBlur's
        // (watched and in-progress rows always render clear).
        val blurThumbnail =
            com.github.damontecres.wholphin.plavio.SpoilerBlur
                .shouldBlur(spoilerBlurEnabled, watched, progress)
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (video.thumbnail != null) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalContext.current)
                            .data(video.thumbnail)
                            .size(320, 180)
                            .crossfade(false)
                            .build(),
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .width(160.dp)
                            .height(90.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .then(
                                if (blurThumbnail) {
                                    Modifier.blur(16.dp)
                                } else {
                                    Modifier
                                },
                            ),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text =
                        stringResource(R.string.plavio_detail_episode, video.episode) +
                            " · " + video.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                // Rating + air date (v0.3.26): from the meta the
                // page already fetched — shown only when present.
                val episodeMetaLine =
                    listOfNotNull(
                        video.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" },
                        video.released?.takeIf { it.isNotBlank() }?.let { formatAirDate(it) },
                    ).joinToString(" · ")
                if (episodeMetaLine.isNotEmpty()) {
                    Text(
                        text = episodeMetaLine,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
                video.overview?.takeIf { it.isNotBlank() }?.let { overview ->
                    // v0.3.19 "view full": the episode overview is
                    // shown in FULL — the old 2-line ellipsis cut it
                    // with no way to read the rest (the row's click
                    // plays the episode, so there is no expand tap to
                    // give it; episode overviews are a few sentences,
                    // so the row simply grows).
                    Text(
                        text = overview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                // Watched state (v0.3.21, the sample): a progress
                // bar + word — "Watching · 62%" while part-seen,
                // "Watched" when finished, "Unwatched" when never
                // started. v0.3.26: a manual mark (the watched
                // store) reads as Watched too (see [watched] above).
                Text(
                    text =
                        when {
                            progress == null -> stringResource(R.string.plavio_detail_unwatched)
                            watched -> stringResource(R.string.plavio_detail_watched)
                            else ->
                                stringResource(
                                    R.string.plavio_detail_watching,
                                    (progress * 100).toInt(),
                                )
                        },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (watched) FontWeight.SemiBold else FontWeight.Normal,
                    color =
                        if (watched) {
                            PlavioOnyx.CachedGreen
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                )
                if (progress != null && !watched) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(0.4f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                                    .height(4.dp)
                                    .background(LocalPlavioAccent.current.primary, RoundedCornerShape(50)),
                        )
                    }
                }
            }
            // v0.3.33: the per-episode mark capsule that stood
            // here (v0.3.26) is REMOVED — the owner's "do like
            // Nuvio" order. The row now shows watched STATE only
            // (the state line above); marking lives behind HOLD
            // OK on the row (see the hold detector on the card).
        }
    }
}

/**
 * Air date for an episode row: ISO input ("2024-03-01" or a full
 * datetime) prints as "1 Mar 2024"; anything unparsable shows its
 * date part as served.
 */
internal fun formatAirDate(raw: String): String {
    val datePart = raw.trim().take(10)
    return runCatching {
        val parsed =
            java.time.LocalDate.parse(
                datePart,
                java.time.format.DateTimeFormatter.ISO_LOCAL_DATE,
            )
        parsed.format(
            java.time.format.DateTimeFormatter
                .ofPattern("d MMM yyyy", java.util.Locale.ENGLISH),
        )
    }.getOrDefault(datePart)
}
