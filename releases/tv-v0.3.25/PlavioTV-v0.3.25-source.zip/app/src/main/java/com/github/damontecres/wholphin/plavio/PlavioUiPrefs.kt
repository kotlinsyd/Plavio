package com.github.damontecres.wholphin.plavio

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.github.damontecres.wholphin.plavio.ui.PlavioAccent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioUiDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_ui")

/**
 * Plavio TV's own small preferences: the Onyx accent and the update
 * checker's switches. Kept apart from the proto AppPreferences (which
 * still carries the player/subtitle settings) in the same Preferences
 * DataStore style [AddonStore] uses.
 */
@Singleton
class PlavioUiPrefs
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioUiDataStore
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + CrashReports.backgroundScopeHandler)

        val accent: StateFlow<PlavioAccent> =
            dataStore.data
                .map { PlavioAccent.byName(it[KEY_ACCENT]) }
                .stateIn(scope, SharingStarted.Eagerly, PlavioAccent.WHITE)

        val autoUpdateCheck: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTO_UPDATE] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /** Watch Now auto-plays the best stream (phone parity); off = open the picker. */
        val autoplayBestStream: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTOPLAY_BEST] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /** Auto-play the next episode when one ends (phone parity, default on). */
        val autoPlayNextEpisode: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTOPLAY_NEXT] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /**
         * Preferred subtitle languages (up to 2, phone Settings
         * semantics): the player auto-selects the first matching
         * subtitle track when playback starts.
         */
        val subtitleLanguages: StateFlow<List<String>> =
            dataStore.data
                .map {
                    it[KEY_SUBTITLE_LANGUAGES]
                        ?.split(",")
                        ?.map { code -> code.trim() }
                        ?.filter { code -> code.isNotEmpty() }
                        ?.take(2)
                        ?: emptyList()
                }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        /** Preferred audio language (ISO 639-1) for first-track auto-pick, or null. */
        val preferredAudioLanguage: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PREFERRED_AUDIO_LANGUAGE] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        /** Show the Skip intro/recap/outro button when IntroDB knows the window (phone parity, default on). */
        val showSkipIntro: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_SHOW_SKIP_INTRO] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setSubtitleLanguages(languages: List<String>) {
            val cleaned = languages.map { it.trim() }.filter { it.isNotEmpty() }.take(2)
            dataStore.edit {
                if (cleaned.isEmpty()) {
                    it.remove(KEY_SUBTITLE_LANGUAGES)
                } else {
                    it[KEY_SUBTITLE_LANGUAGES] = cleaned.joinToString(",")
                }
            }
        }

        suspend fun setPreferredAudioLanguage(language: String?) {
            dataStore.edit {
                if (language.isNullOrBlank()) {
                    it.remove(KEY_PREFERRED_AUDIO_LANGUAGE)
                } else {
                    it[KEY_PREFERRED_AUDIO_LANGUAGE] = language.trim()
                }
            }
        }

        suspend fun setAccent(accent: PlavioAccent) {
            dataStore.edit { it[KEY_ACCENT] = accent.name }
        }

        suspend fun setAutoplayBestStream(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTOPLAY_BEST] = enabled }
        }

        suspend fun setAutoPlayNextEpisode(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTOPLAY_NEXT] = enabled }
        }

        suspend fun setAutoUpdateCheck(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTO_UPDATE] = enabled }
        }

        suspend fun setShowSkipIntro(enabled: Boolean) {
            dataStore.edit { it[KEY_SHOW_SKIP_INTRO] = enabled }
        }


        // ---- v0.2.2 parity batch ----

        /** Debrid API keys (Integrations; phone parity — same services, plain storage). */
        val torboxApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_TORBOX_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val realDebridApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_REALDEBRID_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setTorboxApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_TORBOX_API_KEY) else it[KEY_TORBOX_API_KEY] = cleaned
            }
        }

        suspend fun setRealDebridApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_REALDEBRID_API_KEY) else it[KEY_REALDEBRID_API_KEY] = cleaned
            }
        }

        // ---- Extra debrid providers (v0.3.26 batch 6, phone parity) ----
        // Same providers, endpoints and resolution order as the
        // phone: TorBox → Real-Debrid → Premiumize → AllDebrid →
        // Debrid-Link → Offcloud, cache-first always.

        val premiumizeApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PREMIUMIZE_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val allDebridApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_ALLDEBRID_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val debridLinkApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_DEBRIDLINK_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val offcloudApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_OFFCLOUD_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setPremiumizeApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_PREMIUMIZE_API_KEY) else it[KEY_PREMIUMIZE_API_KEY] = cleaned
            }
        }

        suspend fun setAllDebridApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_ALLDEBRID_API_KEY) else it[KEY_ALLDEBRID_API_KEY] = cleaned
            }
        }

        suspend fun setDebridLinkApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_DEBRIDLINK_API_KEY) else it[KEY_DEBRIDLINK_API_KEY] = cleaned
            }
        }

        suspend fun setOffcloudApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_OFFCLOUD_API_KEY) else it[KEY_OFFCLOUD_API_KEY] = cleaned
            }
        }

        // ---- Trakt / Simkl tokens (v0.3.26 batch 6) ----
        // Written by the Integrations linking flow (authorization
        // code + PKCE, the phone's method); read by the Library
        // (preferred over the account backup's tokens) and by the
        // player's watched-history push.

        val traktAccessToken: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_TRAKT_ACCESS_TOKEN]?.takeIf { token -> token.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val traktRefreshToken: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_TRAKT_REFRESH_TOKEN]?.takeIf { token -> token.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val simklToken: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_SIMKL_TOKEN]?.takeIf { token -> token.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setTraktTokens(
            accessToken: String?,
            refreshToken: String?,
        ) {
            dataStore.edit {
                val access = accessToken?.trim().orEmpty()
                if (access.isEmpty()) it.remove(KEY_TRAKT_ACCESS_TOKEN) else it[KEY_TRAKT_ACCESS_TOKEN] = access
                val refresh = refreshToken?.trim().orEmpty()
                if (refresh.isEmpty()) it.remove(KEY_TRAKT_REFRESH_TOKEN) else it[KEY_TRAKT_REFRESH_TOKEN] = refresh
            }
        }

        suspend fun setSimklToken(token: String?) {
            dataStore.edit {
                val cleaned = token?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_SIMKL_TOKEN) else it[KEY_SIMKL_TOKEN] = cleaned
            }
        }

        /** Simkl's refresh token (issued beside the access token). */
        val simklRefreshToken: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_SIMKL_REFRESH_TOKEN]?.takeIf { token -> token.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setSimklRefreshToken(token: String?) {
            dataStore.edit {
                val cleaned = token?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_SIMKL_REFRESH_TOKEN) else it[KEY_SIMKL_REFRESH_TOKEN] = cleaned
            }
        }

        /** Streams rules: quality sort priority, top = highest priority. */
        val qualityOrder: StateFlow<List<String>> =
            dataStore.data
                .map { prefs ->
                    val saved =
                        prefs[KEY_QUALITY_ORDER]
                            ?.split(",")
                            ?.map { it.trim() }
                            ?.filter { it in QUALITY_ORDER_OPTIONS }
                            ?: emptyList()
                    if (saved.isEmpty()) QUALITY_ORDER_OPTIONS else saved
                }.stateIn(scope, SharingStarted.Eagerly, QUALITY_ORDER_OPTIONS)

        suspend fun setQualityOrder(order: List<String>) {
            val cleaned = order.filter { it in QUALITY_ORDER_OPTIONS }
            dataStore.edit {
                if (cleaned.isEmpty()) {
                    it.remove(KEY_QUALITY_ORDER)
                } else {
                    it[KEY_QUALITY_ORDER] = cleaned.joinToString(",")
                }
            }
        }

        /** Streams rules: autoplay picks by the quality + size rule. */
        val streamAutoplay: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_STREAM_AUTOPLAY] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setStreamAutoplay(enabled: Boolean) {
            dataStore.edit { it[KEY_STREAM_AUTOPLAY] = enabled }
        }

        val autoplayQuality: StateFlow<String> =
            dataStore.data
                .map { prefs ->
                    (prefs[KEY_AUTOPLAY_QUALITY] ?: "Auto")
                        .takeIf { it == "Auto" || it in QUALITY_ORDER_OPTIONS } ?: "Auto"
                }.stateIn(scope, SharingStarted.Eagerly, "Auto")

        suspend fun setAutoplayQuality(value: String) {
            dataStore.edit {
                it[KEY_AUTOPLAY_QUALITY] =
                    if (value == "Auto" || value in QUALITY_ORDER_OPTIONS) value else "Auto"
            }
        }

        /** Home arrangement: addon ids in the user's row order (empty = natural order). */
        val homeAddonOrder: StateFlow<List<String>> =
            dataStore.data
                .map { prefs ->
                    prefs[KEY_HOME_ADDON_ORDER]
                        ?.split(",")
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?: emptyList()
                }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        suspend fun setHomeAddonOrder(ids: List<String>) {
            dataStore.edit {
                if (ids.isEmpty()) {
                    it.remove(KEY_HOME_ADDON_ORDER)
                } else {
                    it[KEY_HOME_ADDON_ORDER] = ids.joinToString(",")
                }
            }
        }

        /** Home arrangement: addons whose catalog rows are hidden from Home. */
        val homeHiddenAddons: StateFlow<Set<String>> =
            dataStore.data
                .map { prefs ->
                    prefs[KEY_HOME_HIDDEN_ADDONS]
                        ?.split(",")
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?.toSet()
                        ?: emptySet()
                }.stateIn(scope, SharingStarted.Eagerly, emptySet())

        suspend fun setHomeHiddenAddons(ids: Set<String>) {
            dataStore.edit {
                if (ids.isEmpty()) {
                    it.remove(KEY_HOME_HIDDEN_ADDONS)
                } else {
                    it[KEY_HOME_HIDDEN_ADDONS] = ids.joinToString(",")
                }
            }
        }

        /**
         * The user's chosen default catalog addon (v0.3.16, note 6):
         * the addon id picked in the Addons screen when two or more
         * catalog-providing addons are installed. Null = no choice
         * (the historic behaviour: the first meta addon wins). The
         * repository consults it wherever the app used to hard-pick
         * the first/PMeta addon as the default catalog source.
         */
        val defaultCatalogAddonId: StateFlow<String?> =
            dataStore.data
                .map { prefs -> prefs[KEY_DEFAULT_CATALOG_ADDON] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setDefaultCatalogAddonId(id: String?) {
            dataStore.edit {
                if (id.isNullOrBlank()) {
                    it.remove(KEY_DEFAULT_CATALOG_ADDON)
                } else {
                    it[KEY_DEFAULT_CATALOG_ADDON] = id
                }
            }
        }

        /** New-episode alerts for shows in Continue Watching (phone parity, default on). */
        val episodeAlertsEnabled: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_EPISODE_ALERTS] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setEpisodeAlertsEnabled(enabled: Boolean) {
            dataStore.edit { it[KEY_EPISODE_ALERTS] = enabled }
        }

        /** One-shot read of the episode-alerts toggle (app-start scheduling). */
        suspend fun episodeAlertsEnabledOnce(): Boolean =
            dataStore.data.first()[KEY_EPISODE_ALERTS] ?: true

        /**
         * Silent Plavio-account backup on app open (phone parity,
         * default ON — the phone's SettingsStore default). The switch
         * lives in Account → Sync & backup; the pass itself is armed
         * at app start by PlavioAutoBackup and re-checks this toggle
         * (and sign-in) before uploading anything.
         */
        val autoBackup: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTO_BACKUP] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setAutoBackup(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTO_BACKUP] = enabled }
        }

        /** One-shot read of the auto-backup toggle (app-start scheduling). */
        suspend fun autoBackupEnabledOnce(): Boolean =
            dataStore.data.first()[KEY_AUTO_BACKUP] ?: true

        /**
         * Hero trailers on Home (Settings → Playback, default ON):
         * when focus rests on a catalog card, that title's trailer
         * plays muted inside the hero as a 10-second clip, and
         * while no trailer is on screen the backdrop slowly zooms
         * (the living-photo fallback). ONE switch governs all hero
         * motion: off = a fully static hero and no trailer work at
         * all. Home and the Settings row read/write this through
         * [HeroTrailerPref] — their view models do not carry this
         * store; both paths use the same key, so they cannot
         * disagree.
         */
        val heroTrailers: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_HERO_TRAILERS] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setHeroTrailers(enabled: Boolean) {
            dataStore.edit { it[KEY_HERO_TRAILERS] = enabled }
        }

        /**
         * Auto-download the next episode when one finishes playing
         * (phone parity, default OFF — downloads spend the user's
         * data and storage). The switch lives on the Downloads
         * screen; the player VM reads this flow at episode end.
         */
        val autoDownloadNextEpisode: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTO_DOWNLOAD_NEXT] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setAutoDownloadNextEpisode(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTO_DOWNLOAD_NEXT] = enabled }
        }

        // ---- Stream badge styles (v0.3.0; phone parity) ----

        /**
         * How stream-card facts render: "GROUPED" (default, tinted-glass
         * capsules) / "ELITE" / "NARD" / "GOLD" / "MINIMALIST" (bundled
         * badge-pack artwork). Stored as the BadgeStyle enum name.
         */
        val badgeStyle: StateFlow<String> =
            dataStore.data
                .map { it[KEY_BADGE_STYLE] ?: "GROUPED" }
                .stateIn(scope, SharingStarted.Eagerly, "GROUPED")

        suspend fun setBadgeStyle(style: String) {
            dataStore.edit { it[KEY_BADGE_STYLE] = style }
        }

        /** Badge group visibility — one switch per fact family, all default ON. */
        val badgeGroupResolution: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_RESOLUTION] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupResolution(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_RESOLUTION] = enabled }
        }

        val badgeGroupHdr: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_HDR] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupHdr(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_HDR] = enabled }
        }

        val badgeGroupAudio: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_AUDIO] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupAudio(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_AUDIO] = enabled }
        }

        val badgeGroupLanguages: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_LANGUAGES] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupLanguages(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_LANGUAGES] = enabled }
        }

        val badgeGroupSourceCodec: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_SOURCE_CODEC] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupSourceCodec(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_SOURCE_CODEC] = enabled }
        }

        val badgeGroupSize: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_SIZE] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupSize(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_SIZE] = enabled }
        }

        // Profile identity for the Account screen + capsule avatar
        // (v0.3.21): display name and @username are local, editable on
        // the Account page; the photo rides the account backup's
        // profilePhoto field (the phone's format) so it syncs.
        val profileName: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_NAME] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val profileUsername: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_USERNAME] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        /** Base64 JPEG of the profile photo, or null for the initial-letter avatar. */
        val profilePhotoBase64: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_PHOTO] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setProfileName(value: String?) {
            dataStore.edit { prefs ->
                val cleaned = value?.trim().orEmpty()
                if (cleaned.isBlank()) prefs.remove(KEY_PROFILE_NAME) else prefs[KEY_PROFILE_NAME] = cleaned
            }
        }

        suspend fun setProfileUsername(value: String?) {
            dataStore.edit { prefs ->
                val cleaned = value?.trim()?.removePrefix("@").orEmpty()
                if (cleaned.isBlank()) prefs.remove(KEY_PROFILE_USERNAME) else prefs[KEY_PROFILE_USERNAME] = cleaned
            }
        }

        suspend fun setProfilePhotoBase64(value: String?) {
            dataStore.edit { prefs ->
                if (value.isNullOrBlank()) prefs.remove(KEY_PROFILE_PHOTO) else prefs[KEY_PROFILE_PHOTO] = value
            }
        }

        /**
         * TV look (owner design 2026-11-04): [PLAVIO_LOOK_FULL] = the
         * full frosted look, [PLAVIO_LOOK_LIGHT] = the same look drawn
         * cheap for low-end TVs. Null = never chosen (renders as Full);
         * the choice lives in Settings only (owner's cut, 2026-11-04).
         */
        val lookMode: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_LOOK_MODE]?.takeIf { mode -> mode == PLAVIO_LOOK_FULL || mode == PLAVIO_LOOK_LIGHT } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setLookMode(mode: String) {
            dataStore.edit { it[KEY_LOOK_MODE] = mode }
        }

        // ---- v0.3.26 batch: player / streams / downloads / system ----

        /**
         * Per-device audio delay in milliseconds (Playback panel):
         * positive = audio comes later (picture ahead), negative =
         * audio earlier. Applied by the player's audio sink (see
         * PlavioAudioDelay in PlayerFactory); 0 = off, the stock sink.
         * Subtitle delay is a separate per-title store and is NOT
         * touched by this.
         */
        val audioDelayMs: StateFlow<Int> =
            dataStore.data
                .map { (it[KEY_AUDIO_DELAY_MS] ?: 0).coerceIn(-AUDIO_DELAY_MAX_MS, AUDIO_DELAY_MAX_MS) }
                .stateIn(scope, SharingStarted.Eagerly, 0)

        suspend fun setAudioDelayMs(value: Int) {
            dataStore.edit {
                it[KEY_AUDIO_DELAY_MS] = value.coerceIn(-AUDIO_DELAY_MAX_MS, AUDIO_DELAY_MAX_MS)
            }
        }

        /**
         * Stream-wait budget in seconds (Streams panel): how long a
         * stream/addon resolution may run before the app shows what
         * it has. 0 = Default — today's behaviour (no overall cap;
         * each addon keeps its own HTTP timeout, the debrid pass its
         * 45 s). A picked value caps BOTH the stream fan-out wait and
         * the per-item debrid resolve in AddonCatalogRepository.
         */
        val streamWaitSeconds: StateFlow<Int> =
            dataStore.data
                .map { (it[KEY_STREAM_WAIT_SECONDS] ?: 0).coerceAtLeast(0) }
                .stateIn(scope, SharingStarted.Eagerly, 0)

        suspend fun setStreamWaitSeconds(value: Int) {
            dataStore.edit { it[KEY_STREAM_WAIT_SECONDS] = value.coerceAtLeast(0) }
        }

        /** Wi-Fi-only downloads (Downloads screen): queue but never transfer off Wi-Fi/Ethernet. */
        val wifiOnlyDownloads: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_WIFI_ONLY_DOWNLOADS] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setWifiOnlyDownloads(enabled: Boolean) {
            dataStore.edit { it[KEY_WIFI_ONLY_DOWNLOADS] = enabled }
        }

        /** Imported Fusion badge sources (JSON list; FusionBadges owns the shape). */
        val fusionBadgeSourcesJson: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_FUSION_BADGE_SOURCES] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setFusionBadgeSourcesJson(value: String?) {
            dataStore.edit {
                if (value.isNullOrBlank()) {
                    it.remove(KEY_FUSION_BADGE_SOURCES)
                } else {
                    it[KEY_FUSION_BADGE_SOURCES] = value
                }
            }
        }

        /** Last versionCode whose What's New entry was shown (0 = never; fresh installs stamp silently). */
        val whatsNewLastSeenCode: StateFlow<Int> =
            dataStore.data
                .map { it[KEY_WHATS_NEW_LAST_SEEN] ?: 0 }
                .stateIn(scope, SharingStarted.Eagerly, 0)

        suspend fun setWhatsNewLastSeenCode(value: Int) {
            dataStore.edit { it[KEY_WHATS_NEW_LAST_SEEN] = value }
        }

        /** Recent TV searches, newest first (Search screen; logic in PlavioRecentSearches). */
        val recentSearches: StateFlow<List<String>> =
            dataStore.data
                .map { prefs ->
                    prefs[KEY_RECENT_SEARCHES]
                        ?.split("\n")
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?: emptyList()
                }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        suspend fun setRecentSearches(values: List<String>) {
            dataStore.edit {
                if (values.isEmpty()) {
                    it.remove(KEY_RECENT_SEARCHES)
                } else {
                    it[KEY_RECENT_SEARCHES] = values.joinToString("\n")
                }
            }
        }

        // ---- v0.3.26 batch 5: text size + idle screen ----

        /**
         * Text size (Settings → Appearance): "standard" (today's
         * rendering), "large" or "extra". Stored as the option name;
         * the root multiplies the density font scale by
         * [PlavioTextSize.factorOf] so every Plavio screen scales
         * together. Layout sizes (dp) do not move — only text.
         */
        val textSize: StateFlow<String> =
            dataStore.data
                .map { prefs ->
                    (prefs[KEY_TEXT_SIZE] ?: PlavioTextSize.STANDARD)
                        .takeIf { it in PlavioTextSize.OPTIONS } ?: PlavioTextSize.STANDARD
                }.stateIn(scope, SharingStarted.Eagerly, PlavioTextSize.STANDARD)

        suspend fun setTextSize(value: String) {
            dataStore.edit {
                it[KEY_TEXT_SIZE] =
                    if (value in PlavioTextSize.OPTIONS) value else PlavioTextSize.STANDARD
            }
        }

        /**
         * Idle screen delay in minutes (Settings → Appearance):
         * 0 = Off (the default — no idle screen ever), else the
         * browse screens show the clock screen after that long
         * without a remote press. Never during playback, never
         * over a dialog (the root gates both).
         */
        val idleScreenMinutes: StateFlow<Int> =
            dataStore.data
                .map { prefs ->
                    (prefs[KEY_IDLE_SCREEN_MINUTES] ?: 0)
                        .takeIf { it in IDLE_SCREEN_OPTIONS } ?: 0
                }.stateIn(scope, SharingStarted.Eagerly, 0)

        suspend fun setIdleScreenMinutes(value: Int) {
            dataStore.edit {
                it[KEY_IDLE_SCREEN_MINUTES] =
                    if (value in IDLE_SCREEN_OPTIONS) value else 0
            }
        }

        // ---- v0.3.26 batch 6: spoiler blur + download defaults ----

        /**
         * Blur unwatched episode pictures (Playback panel, default
         * ON): an episode row's thumbnail renders blurred until the
         * episode is watched or in progress, so a still from later
         * in the episode can't spoil it. The decision itself is
         * [SpoilerBlur.shouldBlur]; this is only the switch.
         */
        val blurUnwatchedEpisodes: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BLUR_UNWATCHED] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBlurUnwatchedEpisodes(enabled: Boolean) {
            dataStore.edit { it[KEY_BLUR_UNWATCHED] = enabled }
        }

        /**
         * PrePlay (batch 6): resolve streams in the background when
         * a details page opens (and for the next episode while one
         * plays) so a Play press starts from the pocket instead of
         * a cold fan-out. Default OFF at first ship (the spec's
         * rule); the pocket itself lives in AddonCatalogRepository
         * and the freshness rules in [PrePlayLogic].
         */
        val prePlayEnabled: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_PREPLAY] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setPrePlayEnabled(enabled: Boolean) {
            dataStore.edit { it[KEY_PREPLAY] = enabled }
        }

        /**
         * Auto Frame Rate (batch 6): while a video plays, the
         * player asks the display for the mode whose refresh rate
         * matches the stream's frame rate (the window's
         * preferredDisplayModeId), restoring the previous mode when
         * playback ends. Default OFF — mode switching blinks the
         * panel on some TVs, so it is the owner's choice. The
         * matching rules are [FrameRateMatch].
         */
        val autoFrameRate: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTO_FRAME_RATE] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setAutoFrameRate(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTO_FRAME_RATE] = enabled }
        }

        /**
         * Default download quality (Downloads screen): "Auto" (the
         * normal autoplay pick) or one of [QUALITY_ORDER_OPTIONS].
         * Applies ONLY where a download starts without an explicit
         * pick — the season download and the auto-downloaded next
         * episode. A stream the user tapped Download on is always
         * downloaded exactly as picked. The pick logic is
         * [downloadPool] + the repository's pickForDownload.
         */
        val downloadQuality: StateFlow<String> =
            dataStore.data
                .map { prefs ->
                    (prefs[KEY_DOWNLOAD_QUALITY] ?: "Auto")
                        .takeIf { it == "Auto" || it in QUALITY_ORDER_OPTIONS } ?: "Auto"
                }.stateIn(scope, SharingStarted.Eagerly, "Auto")

        suspend fun setDownloadQuality(value: String) {
            dataStore.edit {
                it[KEY_DOWNLOAD_QUALITY] =
                    if (value == "Auto" || value in QUALITY_ORDER_OPTIONS) value else "Auto"
            }
        }

        /**
         * Download storage choice (Downloads screen): an index into
         * the device's app-specific external roots
         * (Context.getExternalFilesDirs) — 0 = the primary (internal)
         * root, 1+ = a removable card/drive when one exists. The row
         * only shows when more than one root exists; the download
         * manager falls back to the primary root when the saved
         * index no longer resolves. Existing downloads keep the
         * absolute path they were written to — the choice steers
         * NEW downloads only.
         */
        val downloadStorageIndex: StateFlow<Int> =
            dataStore.data
                .map { (it[KEY_DOWNLOAD_STORAGE_INDEX] ?: 0).coerceAtLeast(0) }
                .stateIn(scope, SharingStarted.Eagerly, 0)

        suspend fun setDownloadStorageIndex(value: Int) {
            dataStore.edit { it[KEY_DOWNLOAD_STORAGE_INDEX] = value.coerceAtLeast(0) }
        }

        suspend fun lastUpdateCheckMs(): Long = dataStore.data.first()[KEY_LAST_UPDATE_CHECK] ?: 0L

        suspend fun setLastUpdateCheckMs(value: Long) {
            dataStore.edit { it[KEY_LAST_UPDATE_CHECK] = value }
        }

        private companion object {
            val KEY_ACCENT = stringPreferencesKey("accent")
            val KEY_AUTO_UPDATE = booleanPreferencesKey("auto_update_check")
            val KEY_AUTOPLAY_BEST = booleanPreferencesKey("autoplay_best_stream")
            val KEY_AUTOPLAY_NEXT = booleanPreferencesKey("autoplay_next_episode")
            val KEY_SUBTITLE_LANGUAGES = stringPreferencesKey("subtitle_languages")
            val KEY_PREFERRED_AUDIO_LANGUAGE = stringPreferencesKey("preferred_audio_language")
            val KEY_LAST_UPDATE_CHECK = longPreferencesKey("last_update_check")
            val KEY_SHOW_SKIP_INTRO = booleanPreferencesKey("show_skip_intro")
            val KEY_TORBOX_API_KEY = stringPreferencesKey("torbox_api_key")
            val KEY_REALDEBRID_API_KEY = stringPreferencesKey("realdebrid_api_key")
            val KEY_PREMIUMIZE_API_KEY = stringPreferencesKey("premiumize_api_key")
            val KEY_ALLDEBRID_API_KEY = stringPreferencesKey("alldebrid_api_key")
            val KEY_DEBRIDLINK_API_KEY = stringPreferencesKey("debridlink_api_key")
            val KEY_OFFCLOUD_API_KEY = stringPreferencesKey("offcloud_api_key")
            val KEY_TRAKT_ACCESS_TOKEN = stringPreferencesKey("trakt_access_token")
            val KEY_TRAKT_REFRESH_TOKEN = stringPreferencesKey("trakt_refresh_token")
            val KEY_SIMKL_TOKEN = stringPreferencesKey("simkl_token")
            val KEY_SIMKL_REFRESH_TOKEN = stringPreferencesKey("simkl_refresh_token")
            val KEY_QUALITY_ORDER = stringPreferencesKey("quality_order")
            val KEY_STREAM_AUTOPLAY = booleanPreferencesKey("stream_autoplay")
            val KEY_AUTOPLAY_QUALITY = stringPreferencesKey("autoplay_quality")
            val KEY_HOME_ADDON_ORDER = stringPreferencesKey("home_addon_order")
            val KEY_HOME_HIDDEN_ADDONS = stringPreferencesKey("home_hidden_addons")
            val KEY_DEFAULT_CATALOG_ADDON = stringPreferencesKey("default_catalog_addon")
            val KEY_EPISODE_ALERTS = booleanPreferencesKey("episode_alerts")
            val KEY_AUTO_BACKUP = booleanPreferencesKey("auto_backup")
            val KEY_HERO_TRAILERS = booleanPreferencesKey("hero_trailers")
            val KEY_AUTO_DOWNLOAD_NEXT = booleanPreferencesKey("auto_download_next_episode")
            val KEY_BADGE_STYLE = stringPreferencesKey("badge_style")
            val KEY_BADGE_GROUP_RESOLUTION = booleanPreferencesKey("badge_group_resolution")
            val KEY_BADGE_GROUP_HDR = booleanPreferencesKey("badge_group_hdr")
            val KEY_BADGE_GROUP_AUDIO = booleanPreferencesKey("badge_group_audio")
            val KEY_BADGE_GROUP_LANGUAGES = booleanPreferencesKey("badge_group_languages")
            val KEY_BADGE_GROUP_SOURCE_CODEC = booleanPreferencesKey("badge_group_source_codec")
            val KEY_BADGE_GROUP_SIZE = booleanPreferencesKey("badge_group_size")
            val KEY_LOOK_MODE = stringPreferencesKey("look_mode")
            val KEY_AUDIO_DELAY_MS = intPreferencesKey("audio_delay_ms")
            val KEY_STREAM_WAIT_SECONDS = intPreferencesKey("stream_wait_seconds")
            val KEY_WIFI_ONLY_DOWNLOADS = booleanPreferencesKey("wifi_only_downloads")
            val KEY_FUSION_BADGE_SOURCES = stringPreferencesKey("fusion_badge_sources")
            val KEY_WHATS_NEW_LAST_SEEN = intPreferencesKey("whats_new_last_seen")
            val KEY_RECENT_SEARCHES = stringPreferencesKey("recent_searches")
            val KEY_TEXT_SIZE = stringPreferencesKey("text_size")
            val KEY_IDLE_SCREEN_MINUTES = intPreferencesKey("idle_screen_minutes")
            val KEY_BLUR_UNWATCHED = booleanPreferencesKey("blur_unwatched_episodes")
            val KEY_PREPLAY = booleanPreferencesKey("preplay_enabled")
            val KEY_AUTO_FRAME_RATE = booleanPreferencesKey("auto_frame_rate")
            val KEY_DOWNLOAD_QUALITY = stringPreferencesKey("download_quality")
            val KEY_DOWNLOAD_STORAGE_INDEX = intPreferencesKey("download_storage_index")
            val KEY_PROFILE_NAME = stringPreferencesKey("profile_name")
            val KEY_PROFILE_USERNAME = stringPreferencesKey("profile_username")
            val KEY_PROFILE_PHOTO = stringPreferencesKey("profile_photo")
        }
    }

/** Canonical quality buckets for the streams rules, best first (phone parity). */
val QUALITY_ORDER_OPTIONS: List<String> = listOf("2160p", "1080p", "720p", "480p")

/** Audio-delay bounds (ms) for the Playback panel stepper. */
const val AUDIO_DELAY_MAX_MS = 5_000
const val AUDIO_DELAY_STEP_MS = 50

/** Stream-wait choices (seconds) for the Streams panel cycle; 0 = Default. */
val STREAM_WAIT_OPTIONS: List<Int> = listOf(0, 20, 40, 60, 90)

/** TV look values stored under [PlavioUiPrefs.lookMode] (owner design 2026-11-04). */
const val PLAVIO_LOOK_FULL = "full"
const val PLAVIO_LOOK_LIGHT = "light"

/**
 * Text-size options (v0.3.26 batch 5): the stored name and the font
 * scale factor the root applies on top of the system density.
 * Pure Kotlin so the mapping unit-tests directly.
 */
object PlavioTextSize {
    const val STANDARD = "standard"
    const val LARGE = "large"
    const val EXTRA = "extra"
    val OPTIONS: List<String> = listOf(STANDARD, LARGE, EXTRA)

    fun factorOf(name: String?): Float =
        when (name) {
            LARGE -> 1.15f
            EXTRA -> 1.3f
            else -> 1f
        }

    /** The next option in the Settings cycle. */
    fun next(name: String?): String {
        val idx = OPTIONS.indexOf(name ?: STANDARD)
        return OPTIONS[(idx + 1) % OPTIONS.size]
    }
}

/** Idle-screen choices in minutes for the Settings cycle; 0 = Off. */
val IDLE_SCREEN_OPTIONS: List<Int> = listOf(0, 5, 10, 15)

/**
 * The idle screen's show decision (v0.3.26 batch 5), pure so it
 * unit-tests: the clock screen may appear only when the feature is
 * on, the idle time has fully elapsed, nothing is playing, and no
 * root dialog (update / announcement / What's New / resume prompt)
 * owns the screen.
 */
object IdleScreenLogic {
    fun shouldShow(
        idleMinutes: Int,
        idleForMs: Long,
        isPlaying: Boolean,
        dialogShowing: Boolean,
    ): Boolean {
        if (idleMinutes <= 0) return false
        if (isPlaying || dialogShowing) return false
        return idleForMs >= idleMinutes * 60_000L
    }
}

/**
 * The spoiler-blur decision (v0.3.26 batch 6), pure so it
 * unit-tests: an episode thumbnail blurs only while the feature is
 * on AND the episode is neither watched nor started. "In progress"
 * (any saved progress short of finished) stays clear — the viewer
 * has already seen into the episode themselves.
 */
object SpoilerBlur {
    fun shouldBlur(
        enabled: Boolean,
        watched: Boolean,
        progress: Float?,
    ): Boolean {
        if (!enabled || watched) return false
        return progress == null || progress <= 0f
    }
}

/**
 * PrePlay freshness rules (v0.3.26 batch 6), pure so they
 * unit-test: a pocket entry is fresh for [FRESH_MS] after it was
 * built; at a Play press only the addons whose data is older than
 * that (or never arrived) are re-fetched — the rest is served
 * from the pocket as-is.
 */
object PrePlayLogic {
    const val FRESH_MS = 5 * 60_000L

    fun isFresh(
        fetchedAtMs: Long,
        nowMs: Long,
    ): Boolean = fetchedAtMs > 0L && nowMs - fetchedAtMs < FRESH_MS

    /** Enabled addons whose pocket data is stale at [nowMs]. */
    fun staleAddons(
        enabledAddonIds: Set<String>,
        settledAtMs: Map<String, Long>,
        nowMs: Long,
    ): Set<String> =
        enabledAddonIds.filterTo(mutableSetOf()) { id ->
            !isFresh(settledAtMs[id] ?: 0L, nowMs)
        }
}

/**
 * The download-quality pool (v0.3.26 batch 6), pure so it
 * unit-tests: with a specific quality picked, the pool is the
 * streams AT that quality (quality is absolute — a pick never
 * silently becomes another quality); when no stream matches, or
 * the preference is "Auto", the pool is the full list and the
 * normal autoplay pick decides, so a download can never dead-end
 * on the preference alone.
 */
fun downloadPool(
    streams: List<StreamItem>,
    prefQuality: String,
): List<StreamItem> {
    if (prefQuality == "Auto") return streams
    val atQuality = streams.filter { canonicalStreamQuality(it) == prefQuality }
    return atQuality.ifEmpty { streams }
}

/**
 * Context-side access to the hero-trailers switch, for the two
 * screens that do not hold an injected [PlavioUiPrefs] (Home's
 * trailer gate and the Settings → Playback row) — the
 * AppStats / CrashReports pattern of reading a switch straight
 * from the screen. Reads and writes the same "plavio_ui" store
 * under the same key as [PlavioUiPrefs.heroTrailers], so the
 * injected flow and these reads can never disagree.
 */
object HeroTrailerPref {
    private val key = booleanPreferencesKey("hero_trailers")

    fun flow(context: Context): Flow<Boolean> =
        context.plavioUiDataStore.data.map { it[key] ?: true }

    suspend fun set(
        context: Context,
        enabled: Boolean,
    ) {
        context.plavioUiDataStore.edit { it[key] = enabled }
    }
}

/**
 * The hero trailer's remembered mute choice (v0.3.31, owner
 * order): trailers play WITH SOUND by default; once the user
 * mutes from the hero's toggle, trailers stay muted across
 * titles, sessions and app restarts until they unmute — and the
 * unmute sticks the same way. Default (fresh install) = NOT
 * muted (sound on). Same "plavio_ui" store as [HeroTrailerPref].
 */
object HeroTrailerMutePref {
    private val key = booleanPreferencesKey("hero_trailer_muted")

    fun flow(context: Context): Flow<Boolean> =
        context.plavioUiDataStore.data.map { it[key] ?: false }

    suspend fun set(
        context: Context,
        muted: Boolean,
    ) {
        context.plavioUiDataStore.edit { it[key] = muted }
    }
}
