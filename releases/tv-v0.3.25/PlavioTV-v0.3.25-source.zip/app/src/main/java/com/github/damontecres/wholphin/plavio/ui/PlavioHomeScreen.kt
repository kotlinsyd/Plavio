package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CatalogRow
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.HeroTrailerMutePref
import com.github.damontecres.wholphin.plavio.HeroTrailerPref
import com.github.damontecres.wholphin.plavio.TrailerResolver
import com.github.damontecres.wholphin.ui.components.Button
import kotlinx.coroutines.launch
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type

/** Hero trailer dwell: focus must rest on a card this long (after
 * the hero's own ~350ms settle) before its trailer starts — fast
 * scrolling never starts a preview. */
private const val HERO_TRAILER_DWELL_MS = 1_500L

/**
 * Living-photo backdrop zoom duration. Before v0.3.31 this
 * constant ALSO capped the hero trailer at a 10-second clip
 * (batch A); the owner's v0.3.31 order removed the cap — trailers
 * play in full — and the constant now serves the zoom alone.
 */
private const val HERO_BACKDROP_ZOOM_MS = 10_000L

/** Living-photo backdrop zoom (batch A): while no trailer is on
 * screen for the settled title, the backdrop scales from 1.0 to
 * this over [HERO_BACKDROP_ZOOM_MS], once per settled title, then
 * holds. */
private const val HERO_BACKDROP_ZOOM_TARGET = 1.08f

/**
 * Plavio TV home: one poster row per catalog of every enabled addon, fed
 * by [AddonCatalogRepository]. The addon setup stays one click away via
 * the "Manage addons" entry in the header.
 */
@Composable
fun PlavioHomeScreen(
    onManageAddons: () -> Unit,
    onItemClick: (CatalogRow, MetaPreview) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onPlayRequest: (com.github.damontecres.wholphin.plavio.PlaybackRequest) -> Unit,
    onEpisodeAlertClick: (com.github.damontecres.wholphin.plavio.EpisodeAlert) -> Unit,
    modifier: Modifier = Modifier,
    /** v0.3.14: root-held focus memory (see PlavioFocus.kt). */
    focusMemory: HomeFocusMemory = HomeFocusMemory(),
    viewModel: PlavioHomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val episodeAlerts by viewModel.episodeAlerts.collectAsState()
    // Stable gate (v0.3.14, owner's override — he accepts the wait):
    // a Content state whose rows have not SETTLED yet renders as the
    // loading face, exactly like the reference's home. The first
    // composed frame of Home is therefore the real, final first row —
    // no provisional shelves composing under the remote and being
    // re-sorted out from under a landed focus (the v0.3.13 startup
    // flicker class, killed structurally instead of gated only at
    // the focus claim). A 5s safety timeout releases the gate with
    // whatever has arrived, so a hung addon can never hold Home
    // hostage. Once released for a given visit the rows only ever
    // refresh in place (identity keys — see CatalogRows).
    var gateTimedOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(5_000)
        gateTimedOut = true
    }
    val contentUnsettled = (state as? PlavioHomeUiState.Content)?.settled == false
    val effectiveState =
        if (contentUnsettled && !gateTimedOut) {
            PlavioHomeUiState.Loading
        } else {
            state
        }

    Column(
        modifier =
            modifier
                .background(MaterialTheme.colorScheme.background),
        // v0.3.28 (owner's order, 2026-11-16): NO top pad at all —
        // the hero is full-bleed and starts at the screen's very
        // top edge (the root also gives Home a zero-inset frame;
        // see PlavioRootScreen).
    ) {
        // v0.3.16 (owner order): the top-centre search capsule is
        // GONE — Search is a side-tray destination now, directly
        // under Home. Every button lives in the tray.
        when (val st = effectiveState) {
            PlavioHomeUiState.Loading -> {
                // v0.3.16 (note 8, owner's explicit order): a
                // SKELETON, not a spinner. This branch renders while
                // the first load is unsettled (the settle gate
                // above) — the page's shape (hero block, then row
                // title bars with poster blocks) stands in place,
                // and the COMPLETE page replaces it at once when
                // the load settles. Nothing here is focusable; the
                // entry landing already waits for the settled rows.
                HomeSkeleton()
            }

            is PlavioHomeUiState.Content -> {
                var heroFocus by remember {
                    mutableStateOf<Pair<CatalogRow, MetaPreview>?>(null)
                }
                // v0.3.12 perf (owner: "buttery movements, scroll"):
                // the hero follows SETTLED focus only. Round 1 swapped
                // the full-screen backdrop + logo on every single
                // D-pad step, so holding Right across a row decoded a
                // new backdrop per card and stuttered the scroll. The
                // hero now updates ~350ms after focus comes to rest —
                // the Nuvio-Modern behaviour.
                var settledHeroFocus by remember {
                    mutableStateOf<Pair<CatalogRow, MetaPreview>?>(null)
                }
                LaunchedEffect(heroFocus) {
                    val target = heroFocus
                    if (target != null) {
                        kotlinx.coroutines.delay(350)
                        settledHeroFocus = target
                    }
                }
                val hero =
                    settledHeroFocus
                        ?: st.rows.firstOrNull()?.let { row ->
                            row.items.firstOrNull()?.let { row to it }
                        }
                // Hero (v0.3.14, owner's order — the reference
                // behaviour): the hero is FIXED. It no longer
                // collapses or scrolls away (the v0.3.11–0.3.13
                // shrink-to-zero: "scrolling down it move up, and
                // only first cards show at hero" — owner verdict).
                // It sits at its resting height — 45% of the
                // available viewport (v0.3.1 proportional rule) —
                // for the whole visit, the rows scroll beneath it in
                // their own region (hero batch, v0.3.26: the region
                // now starts exactly at the hero's bottom edge — no
                // overlap — per the owner's fixed-hero samples), and
                // it FOLLOWS the focused card on
                // any catalog row (the settled-focus feed below), so
                // whichever title the remote rests on is the title
                // the hero shows. Its buttons are ordinary focus
                // stops the whole time: Up from the first row lands
                // on them, visibly, because the hero is always fully
                // on screen — the old focus gate for the collapsing
                // sliver is gone with the collapse itself.
                // The list state lives in the root-held focus memory
                // so a return to Home restores the scroll too.
                val listState = focusMemory.listState
                // ---- Hero trailer previews (hero batch, v0.3.26;
                // owner's approved samples, 2026-11-15) ----
                // When focus RESTS on a catalog card (~1.5s dwell
                // after the hero's own 350ms settle), that title's
                // trailer starts playing INSIDE the hero, replacing
                // its backdrop — always MUTED (volume pinned to 0 at
                // build and again before every play; sound lives only
                // in the real player), never a full-screen takeover:
                // the capsule and the rows stay visible and usable,
                // and the swap is a background-layer change only, so
                // focus stays exactly where it was — on the card.
                // The moment focus moves to another card, leaves this
                // screen's subtree (capsule, player), or the main
                // player opens, the trailer stops and the static
                // backdrop is restored. A title with no trailer (or a
                // failed resolution) simply keeps its backdrop —
                // there is no error state on screen (batch A: the
                // failure now leaves a Sentry breadcrumb instead, so
                // a dead trailer chain is visible in diagnostics).
                // Batch A (lag fix): the player is built LAZILY —
                // only when a trailer is actually about to play —
                // with a small buffer and a 720p cap, because a
                // second full-strength player living on Home
                // starved weak TVs. v0.3.31 (owner order,
                // superseding the batch-A light profile): the
                // trailer plays IN FULL and WITH SOUND — the audio
                // leg is enabled and merged in — unless the user
                // muted trailers from the hero's toggle, a choice
                // remembered across sessions (HeroTrailerMutePref,
                // default: sound on). While no trailer
                // is on screen the backdrop itself slowly zooms
                // (the living-photo fallback). The "Hero trailers"
                // switch (Settings → Playback) governs ALL of this
                // motion: off = no resolve, no player, no zoom.
                // ONE player instance serves the whole Home visit
                // and is released when this content leaves the
                // composition; it is entirely separate from the main
                // player's PlayerFactory stack, so the two can never
                // fight.
                val trailerContext = LocalContext.current
                val playerActive = LocalPlavioPlayerActive.current
                var homeFocused by remember { mutableStateOf(true) }
                // The "Hero trailers" switch (Settings → Playback):
                // off = no resolve, no player, no zoom — backdrop
                // only. Read through HeroTrailerPref (the same
                // "plavio_ui" store PlavioUiPrefs wraps; this
                // screen's view model does not carry that store).
                val heroTrailersFlow =
                    remember(trailerContext) {
                        HeroTrailerPref.flow(trailerContext.applicationContext)
                    }
                val heroTrailersEnabled by heroTrailersFlow.collectAsState(initial = true)
                // The remembered mute choice (v0.3.31): false =
                // sound ON (the fresh-install default). The hero's
                // toggle writes it through HeroTrailerMutePref;
                // the player volume follows it live (below).
                val heroTrailerMutedFlow =
                    remember(trailerContext) {
                        HeroTrailerMutePref.flow(trailerContext.applicationContext)
                    }
                val heroTrailerMuted by heroTrailerMutedFlow.collectAsState(initial = false)
                val heroScope = rememberCoroutineScope()
                // Batch A: the hero player is NOT built at
                // composition time any more. It is created lazily
                // inside the trailer effect, the first time a
                // trailer is actually about to play, and released
                // when this content leaves the composition.
                var heroPlayer by remember {
                    mutableStateOf<androidx.media3.exoplayer.ExoPlayer?>(null)
                }
                var trailerItemKey by remember { mutableStateOf<String?>(null) }
                var trailerOnScreen by remember { mutableStateOf(false) }
                val trailerListener =
                    remember {
                        object : androidx.media3.common.Player.Listener {
                            override fun onRenderedFirstFrame() {
                                trailerOnScreen = true
                            }

                            // v0.3.31: the trailer plays in full;
                            // when it ends on its own, the player
                            // stops and the still backdrop returns
                            // (the living-photo zoom then runs for
                            // the title, as after any trailer).
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                if (playbackState ==
                                    androidx.media3.common.Player.STATE_ENDED
                                ) {
                                    heroPlayer?.stop()
                                    heroPlayer?.clearMediaItems()
                                    trailerOnScreen = false
                                    trailerItemKey = null
                                }
                            }
                        }
                    }
                androidx.compose.runtime.DisposableEffect(Unit) {
                    onDispose {
                        heroPlayer?.let { player ->
                            player.removeListener(trailerListener)
                            player.release()
                        }
                        heroPlayer = null
                    }
                }
                LaunchedEffect(settledHeroFocus, playerActive, homeFocused, heroTrailersEnabled) {
                    heroPlayer?.stop()
                    heroPlayer?.clearMediaItems()
                    trailerItemKey = null
                    trailerOnScreen = false
                    val target = settledHeroFocus ?: return@LaunchedEffect
                    if (playerActive || !homeFocused || !heroTrailersEnabled) {
                        return@LaunchedEffect
                    }
                    // The dwell: fast scrolling must never thrash
                    // the preview — focus has to rest here first.
                    kotlinx.coroutines.delay(HERO_TRAILER_DWELL_MS)
                    val ytId = viewModel.trailerYtId(target.first, target.second)
                    if (ytId == null) {
                        // Silent on screen by design; visible in
                        // diagnostics (batch A).
                        CrashReports.addBreadcrumb(
                            "hero trailer: no trailer id for ${target.second.type}|${target.second.id}",
                        )
                        return@LaunchedEffect
                    }
                    val selection = TrailerResolver.resolvePlayback(ytId)
                    if (selection == null) {
                        CrashReports.addBreadcrumb(
                            "hero trailer: resolve failed for ytId $ytId",
                        )
                        return@LaunchedEffect
                    }
                    // The awaits above are cancellable, but re-check
                    // the world before touching the player: a stale
                    // resolution must never start under a new title.
                    if (settledHeroFocus != target || playerActive || !homeFocused || !heroTrailersEnabled) {
                        return@LaunchedEffect
                    }
                    // Build the player only now — a trailer is
                    // actually about to play (batch A: lazy + light:
                    // small buffer, video capped at 720p. v0.3.31:
                    // the audio track is NO LONGER disabled — the
                    // trailer plays with sound unless the user
                    // muted it; the volume below follows the
                    // remembered choice).
                    val player =
                        heroPlayer ?: run {
                            val trackSelector =
                                androidx.media3.exoplayer.trackselection
                                    .DefaultTrackSelector(
                                        trailerContext.applicationContext,
                                    ).apply {
                                        parameters =
                                            buildUponParameters()
                                                .setMaxVideoSize(1280, 720)
                                                .build()
                                    }
                            val loadControl =
                                androidx.media3.exoplayer.DefaultLoadControl
                                    .Builder()
                                    .setBufferDurationsMs(2_000, 8_000, 500, 1_000)
                                    .build()
                            androidx.media3.exoplayer.ExoPlayer
                                .Builder(trailerContext.applicationContext)
                                .setTrackSelector(trackSelector)
                                .setLoadControl(loadControl)
                                .build()
                                .apply {
                                    volume = if (heroTrailerMuted) 0f else 1f
                                    repeatMode =
                                        androidx.media3.common.Player.REPEAT_MODE_OFF
                                    addListener(trailerListener)
                                }
                        }
                    heroPlayer = player
                    // Sound follows the remembered mute choice
                    // (v0.3.31): unmuted by default, muted only if
                    // the user muted trailers before — and the
                    // live effect below keeps a playing trailer in
                    // step when the toggle flips mid-play.
                    player.volume = if (heroTrailerMuted) 0f else 1f
                    // The resolver prefers one muxed stream; when
                    // it hands back a separate audio leg instead,
                    // the two legs merge into one source so the
                    // sound plays with the picture.
                    val trailerAudioUrl = selection.audioUrl
                    if (trailerAudioUrl != null) {
                        val dataSourceFactory =
                            androidx.media3.datasource.DefaultDataSource
                                .Factory(trailerContext.applicationContext)
                        val videoSource =
                            androidx.media3.exoplayer.source.ProgressiveMediaSource
                                .Factory(dataSourceFactory)
                                .createMediaSource(
                                    androidx.media3.common.MediaItem
                                        .fromUri(selection.videoUrl),
                                )
                        val audioSource =
                            androidx.media3.exoplayer.source.ProgressiveMediaSource
                                .Factory(dataSourceFactory)
                                .createMediaSource(
                                    androidx.media3.common.MediaItem
                                        .fromUri(trailerAudioUrl),
                                )
                        player.setMediaSource(
                            androidx.media3.exoplayer.source.MergingMediaSource(
                                videoSource,
                                audioSource,
                            ),
                        )
                    } else {
                        player.setMediaItem(
                            androidx.media3.common.MediaItem
                                .fromUri(selection.videoUrl),
                        )
                    }
                    player.prepare()
                    player.play()
                    trailerItemKey = "${target.second.type}|${target.second.id}"
                }
                // v0.3.31 (owner order, superseding the batch-A
                // 10-second clip): NO clip cap remains — the
                // trailer plays in full and ends on its own (the
                // listener's STATE_ENDED branch stops the player
                // and returns the backdrop), or when focus moves
                // on (the effect above clears the item). This
                // effect only keeps the remembered mute choice
                // applied LIVE: flipping the hero's toggle
                // silences or un-silences the trailer that is
                // playing right now, not just the next one.
                LaunchedEffect(heroTrailerMuted) {
                    heroPlayer?.volume = if (heroTrailerMuted) 0f else 1f
                }
                // Living-photo fallback (batch A): while no trailer
                // is on screen for the settled title, the backdrop
                // slowly zooms 1.0 → 1.08 over ~10 s, once per
                // settled title, then holds. Any change of state —
                // a trailer starting, the main player opening,
                // focus leaving Home, the switch turning off —
                // resets the scale to 1 first; after a trailer clip
                // ends and the backdrop returns, the zoom runs
                // again for that title.
                val backdropZoom =
                    remember { androidx.compose.animation.core.Animatable(1f) }
                LaunchedEffect(hero, trailerOnScreen, playerActive, homeFocused, heroTrailersEnabled) {
                    backdropZoom.snapTo(1f)
                    if (hero == null || trailerOnScreen || playerActive || !homeFocused || !heroTrailersEnabled) {
                        return@LaunchedEffect
                    }
                    backdropZoom.animateTo(
                        targetValue = HERO_BACKDROP_ZOOM_TARGET,
                        animationSpec =
                            androidx.compose.animation.core.tween(
                                durationMillis = HERO_BACKDROP_ZOOM_MS.toInt(),
                                easing = androidx.compose.animation.core.LinearEasing,
                            ),
                    )
                }
                BoxWithConstraints(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .onFocusChanged { homeFocused = it.hasFocus },
                ) {
                    // Hero geometry (v0.3.29, owner's order,
                    // 2026-11-16 — supersedes the v0.3.28
                    // full-bleed hero): the hero is a BAND PINNED
                    // AT THE TOP, 55% of the screen height (his
                    // pick — "Perfect" on the 55% sample), and it
                    // is FIXED AND NEVER MOVING: it never scrolls,
                    // never shifts, never resizes. The rows live
                    // in their own region BELOW the band (the
                    // v0.3.26 arrangement at the new height) and
                    // only they move. The band's picture still
                    // runs full-bleed under the floating capsule;
                    // its info block sits LEFT-CENTRE inside the
                    // band (the approved hero-55-leftinfo sample).
                    val heroHeight = if (hero != null) maxHeight * 0.55f else 0.dp
                    // The capsule clearance, recomputed with the
                    // root's own formula (PlavioRootScreen): the
                    // adaptive inset + the 42dp pill + the 12dp
                    // breathing gap. Interactive content (hero
                    // text, buttons, every card) starts at or right
                    // of this line; only the hero PICTURE runs
                    // under the capsule.
                    val contentStart =
                        maxOf(28.dp, maxWidth * 0.03f) + 54.dp
                    if (hero != null) {
                        val myListKeys by viewModel.myListKeys.collectAsState()
                        HomeHero(
                            row = hero.first,
                            item = hero.second,
                            inMyList = "${hero.second.type}|${hero.second.id}" in myListKeys,
                            onWatchNow = {
                                viewModel.watchNow(hero.first, hero.second) { request ->
                                    if (request != null) onPlayRequest(request)
                                }
                            },
                            onDetails = { onItemClick(hero.first, hero.second) },
                            onToggleMyList = { viewModel.toggleMyList(hero.second) },
                            height = heroHeight,
                            // v0.3.29: the info block clears the
                            // capsule by the shared content line
                            // (+ its own 24dp). v0.3.32: it anchors
                            // to the band's bottom edge (see
                            // HomeHero), no longer centred.
                            startPad = contentStart + 24.dp,
                            trailerPlayer =
                                heroPlayer.takeIf {
                                    trailerItemKey == "${hero.second.type}|${hero.second.id}"
                                },
                            trailerOnScreen =
                                trailerOnScreen &&
                                    trailerItemKey == "${hero.second.type}|${hero.second.id}",
                            backdropScale = backdropZoom.value,
                            trailerMuted = heroTrailerMuted,
                            onToggleTrailerMute = {
                                heroScope.launch {
                                    HeroTrailerMutePref.set(
                                        trailerContext.applicationContext,
                                        !heroTrailerMuted,
                                    )
                                }
                            },
                        )
                    }
                    // Rows layer (v0.3.29 — the region below the
                    // band): the scrolling layer starts exactly
                    // at the band's bottom edge and fills the
                    // rest of the screen; rows can never slide
                    // up over the fixed band. The start pad is
                    // the capsule clearance: cards never slide
                    // under the capsule, only the hero picture
                    // does. Without a hero (no catalog rows at
                    // all) the region starts at the top and the
                    // list keeps its classic top pad.
                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .padding(start = contentStart, top = heroHeight),
                    ) {
                        CatalogRows(
                            rows = st.rows,
                            continueWatching = st.continueWatching,
                            rowsSettled = st.settled,
                            episodeAlerts = episodeAlerts,
                            onItemClick = onItemClick,
                            onItemFocus = { row, item -> heroFocus = row to item },
                            onContinueWatchingClick = onContinueWatchingClick,
                            onEpisodeAlertClick = { alert ->
                                viewModel.clearEpisodeAlert(alert.metaId)
                                onEpisodeAlertClick(alert)
                            },
                            listState = listState,
                            focusMemory = focusMemory,
                            listTopPadding =
                                if (hero != null) {
                                    20.dp
                                } else {
                                    PlavioChrome.topPad(24.dp)
                                },
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }

            PlavioHomeUiState.NoAddons -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_no_addons_text),
                    actionLabel = stringResource(R.string.plavio_home_add_addon),
                    onAction = onManageAddons,
                )
            }

            PlavioHomeUiState.NoCatalogs -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_no_catalogs),
                    actionLabel = stringResource(R.string.plavio_home_manage_addons),
                    onAction = onManageAddons,
                )
            }

            PlavioHomeUiState.LoadFailed -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_load_failed),
                    actionLabel = stringResource(R.string.plavio_home_retry),
                    onAction = { viewModel.refresh() },
                )
            }
        }
    }
}

@Composable
private fun CatalogRows(
    rows: List<CatalogRow>,
    continueWatching: List<ContinueWatchingEntry>,
    rowsSettled: Boolean,
    episodeAlerts: List<com.github.damontecres.wholphin.plavio.EpisodeAlert>,
    onItemClick: (CatalogRow, MetaPreview) -> Unit,
    onItemFocus: (CatalogRow, MetaPreview) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onEpisodeAlertClick: (com.github.damontecres.wholphin.plavio.EpisodeAlert) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
    focusMemory: HomeFocusMemory = HomeFocusMemory(),
    /** v0.3.28: the LazyColumn's top content pad — on Home this
     * parks the first row at the screen's bottom edge over the
     * full-bleed hero (see PlavioHomeScreen). */
    listTopPadding: Dp = 24.dp,
) {
    val firstCardFocus = remember { FocusRequester() }
    // Identity-keyed requesters (v0.3.14): one per card the user can
    // have focused — Continue Watching by entry key, catalog cards
    // by row key + item identity — so a return can land on the EXACT
    // card again instead of always the first card. Pruned implicitly:
    // the map lives and dies with this composition, and a requester
    // whose card left the data simply never gets attached again.
    val itemRequesters = remember { mutableMapOf<String, FocusRequester>() }
    fun requesterFor(key: String): FocusRequester = itemRequesters.getOrPut(key) { FocusRequester() }
    fun rowKeyOf(row: CatalogRow): String = "${row.addonId}/${row.type}/${row.catalogId}"
    fun itemKeyOf(item: MetaPreview): String = "${item.type}|${item.id}"
    // The claim: focus verifiably inside the list (the column's
    // onFocusChanged) OR the viewer pressing a navigation key (the
    // column's preview stamp). Every landing below goes through the
    // shared landFocus primitive against this claim — it can never
    // fight the user, and a landing is one-shot by construction.
    var listFocusEntered by remember { mutableStateOf(false) }
    var lastKeyMs by remember { mutableStateOf(0L) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    // The one landing for this screen (v0.3.14): the remembered card
    // when it still exists (scroll its row into the window first —
    // the row states ride in the focus memory, so the card is back
    // inside its row's window too), else the first card. Used by the
    // entry effect, the player-return flip and the capsule's return
    // transfer alike — one mechanism, three sanctioned moments.
    suspend fun landHome() {
        val stampAtStart = lastKeyMs
        // v0.3.15 (the capsule trap, root-caused): the claim must be
        // RELATIVE to this landing's start, like every other screen's
        // (they reset their flag; Detail releases its claim). The
        // v0.3.14 form read listFocusEntered RAW — a one-way latch
        // set at first entry and never cleared when focus leaves for
        // the capsule — so a capsule-return landing polled the claim,
        // saw the STALE "entered" from the original entry landing,
        // and landFocus stood down before issuing a single
        // requestFocus. The transfer reported success, the Right key
        // was consumed, and focus was welded into the capsule. The
        // latch half now counts only a RE-ENTRY after this landing
        // began; the key-stamp half was already relative.
        val enteredAtStart = listFocusEntered
        val claimed = { (listFocusEntered && !enteredAtStart) || lastKeyMs != stampAtStart }
        val memoryRowKey = focusMemory.rowKey
        val memoryItemKey = focusMemory.itemKey
        val memoryCwKey = focusMemory.continueWatchingKey
        val target: FocusRequester? =
            when {
                memoryCwKey != null &&
                    continueWatching.any { it.key == memoryCwKey } ->
                    requesterFor("cw|$memoryCwKey")
                memoryRowKey != null && memoryItemKey != null -> {
                    val rowIndex = rows.indexOfFirst { rowKeyOf(it) == memoryRowKey }
                    val row = rows.getOrNull(rowIndex)
                    if (row != null && row.items.any { itemKeyOf(it) == memoryItemKey }) {
                        val columnIndex =
                            (if (episodeAlerts.isNotEmpty()) 1 else 0) +
                                (if (continueWatching.isNotEmpty()) 1 else 0) + rowIndex
                        runCatching { listState.scrollToItem(columnIndex) }
                        requesterFor("$memoryRowKey|$memoryItemKey")
                    } else {
                        null
                    }
                }
                else -> null
            }
        if (target != null) {
            landFocus(target, isClaimed = claimed)
        }
        if (!claimed()) {
            landFocus(firstCardFocus, isClaimed = claimed)
        }
    }
    // Settle fallback (v0.3.13, kept): the entry landing waits for
    // the rows to settle, but a refresh whose final emission somehow
    // never lands must not leave the remote dead — after 4s the
    // landing proceeds against whatever first card exists by then.
    // (The screen-level stable gate in PlavioHomeScreen now covers
    // the display side; this remains the focus-side belt.)
    var settleTimedOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(4000)
        settleTimedOut = true
    }
    LaunchedEffect(rowsSettled, settleTimedOut) {
        if (!rowsSettled && !settleTimedOut) return@LaunchedEffect
        landHome()
    }
    // Focus hand-back on the playing→stopped flip (v0.3.10 pattern,
    // v0.3.14 mechanism): Home stays composed under the player, but
    // focus lives in the player tree and leaves with it — on the
    // flip, land deliberately once more, on the remembered card (a
    // Continue Watching play returns to the very entry played).
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            listFocusEntered = false
            landHome()
        }
    }
    // The capsule's return transfer lands here too (v0.3.14):
    // registered while this content is composed, removed on dispose
    // (the root's holder then reports no handler and geometry rules).
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = { scope.launch(CrashReports.backgroundScopeHandler) { landHome() } }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    LazyColumn(
        modifier =
            modifier
                // v0.3.15: a LIVE mirror (focus is inside the list
                // RIGHT NOW), not the v0.3.14 one-way latch — the
                // latch never cleared when focus left for the
                // capsule, which is what welded focus in there.
                .onFocusChanged { listFocusEntered = it.hasFocus }
                .onPreviewKeyEvent { event ->
                    if (event.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                        (
                            event.key == androidx.compose.ui.input.key.Key.DirectionUp ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionDown ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionLeft ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionRight ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionCenter ||
                                event.key == androidx.compose.ui.input.key.Key.Enter ||
                                event.key == androidx.compose.ui.input.key.Key.NumPadEnter
                        )
                    ) {
                        lastKeyMs = android.os.SystemClock.uptimeMillis()
                    }
                    false
                },
        state = listState,
        // Extra bottom room so the last row can scroll fully into
        // view, clear of the TV's overscan crop zone.
        contentPadding = PaddingValues(top = listTopPadding, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        if (episodeAlerts.isNotEmpty()) {
            item(key = "episode-alerts") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_home_new_episodes),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(end = PlavioChrome.endPad()),
                    )
                    LazyRow(
                        contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(episodeAlerts, key = { _, alert -> alert.metaId }) { _, alert ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                SharedPosterCard(
                                    item =
                                        MetaPreview(
                                            id = alert.metaId,
                                            type = "series",
                                            name = alert.showName,
                                            poster = alert.poster,
                                        ),
                                    onClick = { onEpisodeAlertClick(alert) },
                                )
                                Text(
                                    text =
                                        stringResource(
                                            R.string.plavio_home_new_episode_label,
                                            alert.season,
                                            alert.episode,
                                        ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LocalPlavioAccent.current.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        if (continueWatching.isNotEmpty()) {
            item(key = "continue-watching") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_home_continue_watching),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(end = 40.dp),
                    )
                    LazyRow(
                        state = focusMemory.rowState("continue-watching"),
                        contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(continueWatching, key = { _, entry -> entry.key }) { index, entry ->
                            ContinueWatchingCard(
                                entry = entry,
                                onClick = { onContinueWatchingClick(entry) },
                                modifier =
                                    Modifier
                                        .focusRequester(requesterFor("cw|${entry.key}"))
                                        .onFocusChanged { state ->
                                            if (state.isFocused) {
                                                focusMemory.continueWatchingKey = entry.key
                                                focusMemory.rowKey = null
                                                focusMemory.itemKey = null
                                            }
                                        }
                                        .then(
                                            if (index == 0) {
                                                Modifier.focusRequester(firstCardFocus)
                                            } else {
                                                Modifier
                                            },
                                        ),
                            )
                        }
                    }
                }
            }
        }
        itemsIndexed(rows, key = { rowIndex, row -> "${row.addonId}/${row.type}/${row.catalogId}|$rowIndex" }) { rowIndex, row ->
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.padding(end = 40.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = row.catalogName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    // v0.3.16 (note 5): the addon-name label that
                    // used to sit beside the catalog name is GONE —
                    // rows carry the catalog's own name only, clean
                    // like the mobile app (no "PMeta" branding on
                    // rows). Display layer only: the row's addon
                    // identity (addonId/baseUrl on the row model)
                    // still drives fetching, ordering and hiding
                    // exactly as before.
                }
                LazyRow(
                    state = focusMemory.rowState(rowKeyOf(row)),
                    contentPadding = PaddingValues(end = PlavioChrome.endPad()),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    // Identity keys with an OCCURRENCE suffix
                    // (v0.3.14): the suffix counts prior occurrences
                    // of the same title in this row (PLAVIO-8/5: the
                    // same title can legitimately appear twice in
                    // one rail; type|id alone crashed on it) — NOT
                    // the item's list position. An item inserted or
                    // removed elsewhere in the row therefore keeps
                    // every other card's key (and its focus node)
                    // stable across a refresh, where the old
                    // position suffix re-keyed every card after the
                    // change and could tear down the focused node
                    // mid-browse — the reference's identity-
                    // relocation rule, applied to our keys.
                    val occurrenceKeys =
                        run {
                            val seen = mutableMapOf<String, Int>()
                            row.items.map { item ->
                                val base = itemKeyOf(item)
                                val occurrence = seen.getOrDefault(base, 0)
                                seen[base] = occurrence + 1
                                "$base|$occurrence"
                            }
                        }
                    itemsIndexed(
                        row.items,
                        key = { index, _ -> occurrenceKeys[index] },
                    ) { itemIndex, item ->
                        SharedPosterCard(
                            item = item,
                            onClick = { onItemClick(row, item) },
                            onFocus = {
                                onItemFocus(row, item)
                                focusMemory.rowKey = rowKeyOf(row)
                                focusMemory.itemKey = itemKeyOf(item)
                                focusMemory.continueWatchingKey = null
                            },
                            focusRequester = requesterFor("${rowKeyOf(row)}|${itemKeyOf(item)}"),
                            modifier =
                                if (continueWatching.isEmpty() && rowIndex == 0 && itemIndex == 0) {
                                    Modifier.focusRequester(firstCardFocus)
                                } else {
                                    Modifier
                                },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    entry: ContinueWatchingEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.width(216.dp),
        shape = plavioCardShape(),
        colors = plavioCardColors(),
        border = plavioCardBorder(),
        scale = plavioCardScale(),
    ) {
        Column {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (entry.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(entry.poster)
                                .size(432, 243)
                                .crossfade(false)
                                .build(),
                        contentDescription = entry.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = entry.title.take(1),
                        style = MaterialTheme.typography.displaySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                // Progress bar along the bottom of the artwork: what is
                // left of the bar is how much of the title remains.
                Box(
                    modifier =
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(entry.progressFraction)
                                .height(4.dp)
                                .background(MaterialTheme.colorScheme.primary),
                    )
                }
            }
            Column(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = entry.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.plavio_home_time_left, formatTimeLeft(entry)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

/** "1h 5m" / "5m" / "<1m" for the time remaining on a continue-watching entry. */
private fun formatTimeLeft(entry: ContinueWatchingEntry): String {
    val remainingMs = (entry.durationMs - entry.positionMs).coerceAtLeast(0)
    val totalMinutes = (remainingMs / 60_000).toInt()
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return when {
        hours > 0 -> "${hours}h ${minutes}m"
        minutes > 0 -> "${minutes}m"
        else -> "<1m"
    }
}

@Composable
private fun EmptyState(
    title: String,
    text: String,
    actionLabel: String,
    onAction: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(8.dp))
            PlavioPrimaryButton(onClick = onAction) {
                Text(text = actionLabel)
            }
        }
    }
}


/**
 * Home hero (v0.3.29, the owner's approved hero-55-leftinfo
 * sample): the fixed 55% band pinned at the screen's top. Inside
 * it, the info block sits LEFT-CENTRE — a bigger title (logo art
 * when the metadata provides it, else the title text), a meta
 * line (year · genres · ★ rating), the 2-line synopsis, and the
 * buttons row: Watch Now (the owner's ruling — the mobile label,
 * never "Play"), Details, + My List. Before anything is focused
 * it shows the first title of the first rail. Down from the
 * buttons enters the rails; the capsule never traps focus.
 */
@Composable
private fun HomeHero(
    row: CatalogRow,
    item: MetaPreview,
    inMyList: Boolean,
    onWatchNow: () -> Unit,
    onDetails: () -> Unit,
    onToggleMyList: () -> Unit,
    height: Dp = 300.dp,
    /** Where the info block starts: the capsule clearance line +
     * its own inset, passed in by the caller. */
    startPad: Dp = 24.dp,
    /**
     * Hero trailer preview (hero batch, v0.3.26): the shared hero
     * player while a trailer is loading/playing for THIS item, and
     * whether its first frame has rendered (the backdrop then fades
     * out and the mute mark shows). Null/false = static hero.
     */
    trailerPlayer: androidx.media3.common.Player? = null,
    trailerOnScreen: Boolean = false,
    /**
     * The remembered trailer mute choice (v0.3.31) and its toggle:
     * while a trailer is on screen the hero's bottom-right mark is
     * a real button showing this state (waves = sound on, X =
     * muted); flipping it persists via the caller.
     */
    trailerMuted: Boolean = false,
    onToggleTrailerMute: () -> Unit = {},
    /**
     * Living-photo fallback (batch A): the backdrop's slow-zoom
     * scale, driven by the caller while no trailer is on screen.
     * 1f = still picture.
     */
    backdropScale: Float = 1f,
) {
    val context = LocalContext.current
    // v0.3.29 (owner's order, 2026-11-16): the hero is the fixed
    // 55% band at the top — full-bleed across the width, no end
    // inset, no rounded corners, no border. The backdrop and the
    // trailer surface run edge to edge and under the floating
    // capsule; only the info block keeps an inset (the capsule
    // clearance, passed in as startPad). The box is clipped to
    // its bounds so the living-photo zoom (1.08) can never bleed
    // below the band's bottom edge into the rows region.
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(height)
                .clipToBounds(),
    ) {
        // Static backdrop (v0.3.2 smoothness): the old parallax
        // translation + alpha fade repainted this full-screen image on
        // every scroll frame. The sheet sliding over it carries the
        // motion now; the backdrop itself never moves.
        // v0.3.20 ROOT-CAUSE FIX (owner: "posters in hero section are
        // missing, showing details but missing posters"): the image
        // was gated behind the LIGHT-LOOK preference —
        // `if (!LocalPlavioLightLook.current)` — a Settings-only
        // cheap-drawing mode for low-end TVs (owner design
        // 2026-11-04) whose whole contract is "the same look drawn
        // cheap". Under it the hero skipped its ONLY image entirely
        // while the title, facts and buttons (plain text/draw calls)
        // still rendered — exactly the owner's photo: details
        // showing, picture area blank. A performance preference
        // must never remove CONTENT: the backdrop is the hero's
        // picture, not an effect. The gate is gone; the image now
        // loads in both looks. What light look legitimately cheapens
        // (shadows, glass translucency, scrims elsewhere) is
        // untouched.
        // Trailer layer (hero batch, v0.3.26): UNDER the backdrop
        // image. While the preview loads, the static backdrop covers
        // it whole (no black flash); the moment its first frame
        // renders, the backdrop fades out and the trailer is the
        // hero's picture, crop-filled to the hero box — the hero
        // zone only, never the full screen. The view is a pure
        // background surface: controller off, focus refused at both
        // the view and the Compose node, so the swap can never take
        // or move the remote's focus from the focused card.
        if (trailerPlayer != null) {
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { viewContext ->
                    androidx.media3.ui.PlayerView(viewContext).apply {
                        useController = false
                        resizeMode =
                            androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        isFocusable = false
                        isFocusableInTouchMode = false
                        player = trailerPlayer
                    }
                },
                modifier =
                    Modifier
                        .fillMaxSize()
                        .focusProperties { canFocus = false },
            )
        }
        AsyncImage(
            model =
                ImageRequest
                    .Builder(context)
                    .data(item.background ?: item.poster)
                    // v0.3.12 perf: cap the hero decode —
                    // backdrops arrive at original size (often
                    // 2000px+). v0.3.15: 960×540, down from
                    // 1280×720 — the hero sits under two scrims
                    // and the rows sheet, and on the owner's TV
                    // the settled-hero backdrop swap lands while
                    // he is still scrolling: ~44% fewer decode
                    // pixels is ~44% less of that mid-scroll hit.
                    .size(960, 540)
                    .crossfade(false)
                    .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier =
                Modifier
                    .fillMaxSize()
                    // Hero trailer on screen: the static backdrop
                    // steps aside (the video layer beneath takes
                    // over the hero's picture).
                    .alpha(if (trailerOnScreen) 0f else 1f)
                    // Living-photo fallback (batch A): the slow
                    // zoom while no trailer is on screen; the hero
                    // box's clip keeps the scaled image inside the
                    // card. 1f = still.
                    .graphicsLayer {
                        scaleX = backdropScale
                        scaleY = backdropScale
                    },
        )
        // Legibility scrims: bottom fade into the app background + a
        // soft start-side shade behind the info block. v0.3.29: the
        // fade's start is a FRACTION of the band height — the
        // picture's upper half stays clear and the fade deepens
        // toward the band's bottom edge, where it melts into the
        // rows region's background (the sample's melt).
        val heroHeightPx = with(LocalDensity.current) { height.toPx() }
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors =
                                listOf(
                                    androidx.compose.ui.graphics.Color.Transparent,
                                    MaterialTheme.colorScheme.background,
                                ),
                            startY = heroHeightPx * 0.45f,
                        ),
                    ),
        )
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors =
                                listOf(
                                    androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f),
                                    androidx.compose.ui.graphics.Color.Transparent,
                                ),
                        ),
                    ),
        )
        Column(
            modifier =
                Modifier
                    .align(Alignment.BottomStart)
                    // v0.3.32 (owner's order, 2026-11-17 —
                    // supersedes the v0.3.29 left-centre seat):
                    // the info block anchors to the band's BOTTOM
                    // EDGE (bottom-left): start = the capsule
                    // clearance line + 24dp (passed in), bottom =
                    // a 26dp seat above the band's edge. The
                    // trailer owns the band's centre and top. No
                    // glass panel behind the text — the scrims
                    // alone carry legibility, as before. The block
                    // opens with the title itself (no kicker line).
                    .padding(start = startPad, end = 24.dp, bottom = 26.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Title logo art, progressive (v0.3.17): the TEXT title
            // renders first and the logo replaces it only once it has
            // actually loaded — a slow or dead logo URL never leaves
            // the hero title blank, and the hero never waits on it.
            // Adaptive logo size (owner order, v0.3.4) is preserved:
            // title logos arrive in wildly different shapes, so the
            // box follows the loaded image's own aspect (ContentScale
            // .Fit inside, never Crop). v0.3.29: the boxes grow a
            // step with the sample's bigger title.
            val heroLogoPainter =
                coil3.compose.rememberAsyncImagePainter(
                    model =
                        ImageRequest
                            .Builder(context)
                            .data(item.logo)
                            .size(680, 240)
                            .crossfade(false)
                            .build(),
                )
            val heroLogoState by heroLogoPainter.state.collectAsState()
            val heroLogoSuccess =
                heroLogoState as? coil3.compose.AsyncImagePainter.State.Success
            if (item.logo != null && heroLogoSuccess != null) {
                val loadedSize = heroLogoSuccess.painter.intrinsicSize
                val logoAspect =
                    if (loadedSize != androidx.compose.ui.geometry.Size.Unspecified &&
                        loadedSize.height > 0f
                    ) {
                        loadedSize.width / loadedSize.height
                    } else {
                        null
                    }
                val logoSize =
                    when (val aspect = logoAspect) {
                        null -> androidx.compose.ui.unit.DpSize(330.dp, 92.dp)
                        else ->
                            when {
                                aspect >= 2.6f -> androidx.compose.ui.unit.DpSize(380.dp, 100.dp)
                                aspect >= 1.8f -> androidx.compose.ui.unit.DpSize(330.dp, 104.dp)
                                aspect >= 1.2f -> androidx.compose.ui.unit.DpSize(240.dp, 118.dp)
                                else -> androidx.compose.ui.unit.DpSize(170.dp, 128.dp)
                            }
                    }
                androidx.compose.foundation.Image(
                    painter = heroLogoPainter,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart,
                    modifier = Modifier.size(logoSize),
                )
            } else {
                Text(
                    text = item.name,
                    // v0.3.29: the sample's bigger title.
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            // The ONE small details line (v0.3.32, owner's
            // minimal-hero order): year · ★ rating — nothing
            // else. (MetaPreview carries no runtime, so the line
            // is built from what the data has — never invented.)
            // The overview paragraph and every other fact are OFF
            // the hero from this build: the trailer gets the
            // picture, and the full facts live on the Details
            // page, one tap away.
            val facts =
                listOfNotNull(
                    item.releaseInfo?.take(4)?.takeIf { it.isNotBlank() },
                    item.imdbRating?.takeIf { it.isNotBlank() }?.let { "★ $it" },
                ).joinToString("  ·  ")
            if (facts.isNotBlank()) {
                Text(
                    text = facts,
                    style = MaterialTheme.typography.bodyLarge,
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f),
                )
            }
            // The sample's three fixed capsules (v0.3.29):
            // Watch Now + Details + My List. Watch Now carries
            // the owner's label ruling (same as mobile — never
            // "Play"); Details opens this title's detail page,
            // the same landing a card click gives; My List
            // toggles this title in the store (v0.3.21) and
            // says so.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_detail_watch),
                    onClick = onWatchNow,
                    kind = PlavioButtonKind.Primary,
                    whiteFocus = true,
                    leadingIcon = androidx.compose.material.icons.Icons.Filled.PlayArrow,
                    modifier = Modifier.width(150.dp),
                )
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_details),
                    onClick = onDetails,
                    whiteFocus = true,
                    modifier = Modifier.width(150.dp),
                )
                PlavioFixedButton(
                    text =
                        stringResource(
                            if (inMyList) {
                                R.string.plavio_in_my_list
                            } else {
                                R.string.plavio_add_my_list
                            },
                        ),
                    onClick = onToggleMyList,
                    whiteFocus = true,
                    modifier = Modifier.width(150.dp),
                )
            }
        }
        // The trailer sound toggle (v0.3.31, owner order —
        // supersedes the v0.3.26 decorative mute mark): while a
        // trailer plays in the hero, a small speaker button sits
        // at the hero's bottom-right. It shows the CURRENT state —
        // waves when the sound is on, the X when muted — and
        // Centre/Enter flips it; the caller persists the choice
        // (HeroTrailerMutePref), so it holds across titles,
        // sessions and restarts. It is a real focus stop, built on
        // the player's own focusable + key pattern; focused it
        // fills white with an ink glyph, like the hero's buttons,
        // resting it keeps the mark's dark disc.
        if (trailerOnScreen) {
            var muteFocused by remember { mutableStateOf(false) }
            Box(
                modifier =
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(14.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            if (muteFocused) {
                                androidx.compose.ui.graphics.Color.White
                            } else {
                                androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f)
                            },
                        )
                        .onFocusChanged { muteFocused = it.isFocused }
                        .focusable()
                        .onKeyEvent { event ->
                            if (event.type != KeyEventType.KeyDown) {
                                false
                            } else {
                                when (event.key) {
                                    Key.DirectionCenter, Key.Enter -> {
                                        onToggleTrailerMute()
                                        true
                                    }
                                    else -> false
                                }
                            }
                        },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector =
                        if (trailerMuted) PlavioIcons.VolumeOff else PlavioIcons.VolumeUp,
                    contentDescription = null,
                    tint =
                        if (muteFocused) {
                            androidx.compose.ui.graphics.Color.Black
                        } else {
                            androidx.compose.ui.graphics.Color.White
                        },
                    modifier = Modifier.size(19.dp),
                )
            }
        }
    }
}

/**
 * The Home first-load skeleton (v0.3.16, note 8): the page's own
 * shape in quiet glass blocks — the hero block at its real
 * resting height (55% since v0.3.29) with title/action shapes
 * inside, then two catalog
 * rows (title bar + poster blocks). Pure decoration: nothing
 * focusable, no text. It stands only while the first load is
 * unsettled; the complete page replaces it at once.
 */
@Composable
private fun HomeSkeleton() {
    val block = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.06f)
    val line = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.10f)
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(end = 40.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.55f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(block),
        ) {
            Column(
                modifier =
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier =
                        Modifier
                            .width(340.dp)
                            .height(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(line),
                )
                Box(
                    modifier =
                        Modifier
                            .width(220.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(block),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier =
                            Modifier
                                .width(150.dp)
                                .height(40.dp)
                                .clip(PlavioCapsuleShape)
                                .background(line),
                    )
                    Box(
                        modifier =
                            Modifier
                                .width(150.dp)
                                .height(40.dp)
                                .clip(PlavioCapsuleShape)
                                .background(block),
                    )
                }
            }
        }
        repeat(2) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier =
                        Modifier
                            .width(180.dp)
                            .height(22.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(line),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    repeat(6) {
                        Box(
                            modifier =
                                Modifier
                                    .width(124.dp)
                                    .height(186.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(block),
                        )
                    }
                }
            }
        }
    }
}
