package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.util.TypedValue
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.SubtitleStyle
import com.github.damontecres.wholphin.plavio.TvChannelRef
import com.github.damontecres.wholphin.plavio.Video
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import com.github.damontecres.wholphin.plavio.StreamItem
import com.github.damontecres.wholphin.plavio.buttonLabel
import com.github.damontecres.wholphin.plavio.streamQualityLabel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import timber.log.Timber
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private enum class PlayerPicker { NONE, SUBTITLES, AUDIO, EPISODES, SPEED, AUDIO_PREF, SOURCES, SLEEP }

// Sources auto-popup budget (v0.3.10, owner's rule; v0.3.18:
// 35s → 30s on the owner's word): a play start that has produced
// no picture within this long gets the Sources panel opened over
// the still-running load, so the user can take over by hand. The
// popup switches nothing itself — it hands the user the wheel.
private const val SOURCES_AUTO_POPUP_MS = 30_000L

/**
 * v0.3.15 (the retry-loop fix): the STALL bound on one load session —
 * how long a start may make NO PROGRESS WHATSOEVER before it is
 * declared dead. v0.3.14 ran this as a plain wall clock from first
 * composition: 45s, whether or not the start was actually feeding.
 * On the owner's slow routes a healthy start spends its first tens
 * of seconds in connect + read waits (the HTTP stack allows 5s
 * connect / 20s read per attempt, and a ladder hop starts a fresh
 * attempt inside the SAME clock), so the deadline fired mid-load on
 * starts that were progressing fine — stop(), error surface, retry,
 * same wall — "retry retry, nothing play". The stall form only
 * accrues time while the player exists, has not reached READY, and
 * its buffered position has not advanced at all; any forward feed,
 * any player swap (a ladder hop is activity), and any moment the
 * user owns the screen (picker, error surface, resume prompt)
 * resets the clock to zero. A start that is genuinely wedged —
 * error-free but frozen, no bytes moving — still dies at the bound
 * and hands the remote back, which is all the deadline was for.
 */
private const val LOAD_STALL_LIMIT_MS = 45_000L

/** Stall-detector poll interval (v0.3.15, see LOAD_STALL_LIMIT_MS). */
private const val LOAD_STALL_POLL_MS = 5_000L

/**
 * v0.3.17 (owner note 1 — the source-switch crash): the automatic
 * recovery budget, mirroring the reference player's method the
 * owner ordered ("same to same"): the player NEVER advances to
 * another source on its own — a failure retries THE SAME source,
 * bounded, with a real pause between attempts, and then hands the
 * remote back. MAX_AUTO_RETRIES = 2 and RETRY_DELAY_MS = 1,500 are
 * the reference's own constants; the budget refills only after
 * STABLE_PROGRESS_RESET_MS of healthy READY + playing progress
 * (the reference's stable-progress reset rule), never the instant
 * a state flag flickers to READY.
 */
private const val MAX_AUTO_RETRIES = 2
private const val RETRY_DELAY_MS = 1_500L
private const val STABLE_PROGRESS_RESET_MS = 5_000L

/**
 * HTTP statuses a retry of the same request gets again, so retrying
 * only delays the error (v0.3.17: the reference player's rule,
 * adopted with its recovery method).
 */
private fun isPermanentHttpStatus(code: Int): Boolean =
    code == 400 || code == 401 || code == 403 || code == 404 || code == 410

/** The HTTP status behind a playback error, when it carries one. */
private fun httpStatusOf(error: PlaybackException): Int? {
    var cause: Throwable? = error
    while (cause != null) {
        if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
            return cause.responseCode
        }
        cause = cause.cause
    }
    return null
}

/**
 * Whether a playback error is worth retrying THE SAME source for
 * (v0.3.17: the reference player's classification, adopted with its
 * recovery method — transient IO, parsing glitches and decoder
 * failures retry; a permanent HTTP status and everything else is
 * fatal and surfaces at once). Replaces the v0.3.9–0.3.13 helpers
 * that sorted errors into source-hopping lanes.
 */
private fun isRetryablePlaybackError(error: PlaybackException): Boolean =
    when (error.errorCode) {
        PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION,
        PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED,
        PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE,
        -> true
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> {
            val status = httpStatusOf(error)
            status == null || !isPermanentHttpStatus(status)
        }
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        -> true
        PlaybackException.ERROR_CODE_UNSPECIFIED ->
            error.cause is IllegalStateException || error.cause is NullPointerException
        else -> false
    }

/**
 * Full-screen playback for an addon stream with a remote-first control
 * layer, mirroring the phone player's control set: play/pause, seek bar
 * (D-pad left/right seek by the configured skip amounts), current/total
 * time, the three-rail subtitle panel (Languages | Subtitles | Style),
 * an audio picker, next-episode autoplay with a countdown, an episodes
 * picker and a Sources shortcut back to the stream list. Controls
 * auto-hide while playing; any key wakes them, and focus is always on a
 * visible control while they're up.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlavioPlayerScreen(
    request: PlaybackRequest,
    modifier: Modifier = Modifier,
    resumePositionMs: Long = 0,
    onResumeFailed: (() -> Unit)? = null,
    onPlayNextEpisode: ((PlaybackRequest) -> Unit)? = null,
    onZapChannel: ((TvChannelRef) -> Unit)? = null,
    viewModel: PlavioPlayerViewModel = hiltViewModel(),
) {
    val player by viewModel.player.collectAsState()
    val resumeFailed by viewModel.resumeFailed.collectAsState()
    val subtitleStyle by viewModel.subtitleStyle.collectAsState()
    val autoPlayNext by viewModel.autoPlayNextEpisode.collectAsState()
    val subtitleLanguages by viewModel.subtitleLanguages.collectAsState()
    val preferredAudioLanguage by viewModel.preferredAudioLanguage.collectAsState()
    val localSubtitles by viewModel.localSubtitles.collectAsState()
    val subtitleDelayMs by viewModel.subtitleDelayMs.collectAsState()
    val skipForwardMs by viewModel.skipForwardMs.collectAsState()
    val skipBackMs by viewModel.skipBackMs.collectAsState()
    val skipSegments by viewModel.skipSegments.collectAsState()
    val showSkipIntro by viewModel.showSkipIntro.collectAsState()
    val creationError by viewModel.creationError.collectAsState()
    val sidecarSubtitle by viewModel.sidecarSubtitle.collectAsState()
    // v0.3.31: the subtitle switch is never silent (the phone's
    // rule) — a picked subtitle still downloading/preparing (the
    // sidecar fetch, or a libass rebuild's pending pick) is named
    // on the seek line until it lands.
    val subtitlePreparing by viewModel.subtitlePreparing.collectAsState()
    val pendingLibassSubtitle by viewModel.pendingLibassSubtitle.collectAsState()
    val subtitleDownloading = subtitlePreparing || pendingLibassSubtitle != null
    val liveRequest by viewModel.currentRequestFlow.collectAsState()
    val displayRequest = liveRequest ?: request
    var errorMessage by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // Parity state (v0.2.1): speed + aspect are per-title session state,
    // reset whenever a new title starts.
    var speed by remember(request.streamUrl) { mutableFloatStateOf(1f) }
    var resizeMode by remember(request.streamUrl) { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    // v0.3.21 (study fix #3): the playing video's display aspect,
    // fed by the player listener below — it drives the SURFACE
    // frame sizing in the AndroidView block (the SmartTube way:
    // the frame the surface lives in is sized by aspect + mode,
    // not a content frame inside a full-screen PlayerView).
    var videoAspect by remember(request.streamUrl) { mutableFloatStateOf(0f) }
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }
    // Sleep timer (v0.3.26, phone parity): a wall-clock deadline
    // (sleepPreset = minutes picked, sleepDeadlineMs its target) or
    // an end-of-episode arm. At expiry playback pauses AND the
    // screen hold is released (sleepScreenReleased) — a paused
    // player must not keep the TV awake all night (the phone's
    // v0.14.49 fix, the same rule here). Playing again restores the
    // hold (see the isPlaying effect below).
    var sleepPreset by remember(request.streamUrl) { mutableIntStateOf(0) }
    var sleepDeadlineMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var sleepAtEpisodeEnd by remember(request.streamUrl) { mutableStateOf(false) }
    var sleepRemainingSec by remember(request.streamUrl) { mutableIntStateOf(0) }
    var sleepScreenReleased by remember(request.streamUrl) { mutableStateOf(false) }
    // Latched when a sleep expiry consumed this play's end, so the
    // autoplay countdown never starts behind it.
    var sleepEndConsumed by remember(request.streamUrl) { mutableStateOf(false) }

    // Per-title player memory (v0.3.26): the ViewModel store's entry
    // for THIS title (series share one entry across episodes — the
    // picks are show-level choices). Restored once per player
    // instance by the effects below; picks save through the
    // ViewModel at the panels' onPick points.
    val playerMemories by viewModel.playerMemories.collectAsState()
    // Batch 6: the DV-fallback notice (rendered in the transient
    // message slot) and the Auto Frame Rate switch (applied by the
    // window effect below).
    val playerNotice by viewModel.playerNotice.collectAsState()
    val autoFrameRate by viewModel.autoFrameRate.collectAsState()
    val memoryKey = remember(request) { viewModel.memoryKeyFor(request) }
    val titleMemory = playerMemories[memoryKey]
    // Same-source recovery state (v0.3.17, the reference method —
    // see MAX_AUTO_RETRIES): how many automatic retries THE CURRENT
    // SOURCE has spent, the pending retry job (a second failure
    // arriving while one is scheduled must not spend budget twice —
    // the v0.3.16 crash shape), and the safe-mode rebuild latch
    // (attempt two's configuration change, at most once per title).
    // The note tells the user a recovery is running instead of
    // leaving a silent spinner.
    var autoRetryCount by remember(request.streamUrl) { mutableIntStateOf(0) }
    var recoveryJob by remember(request.streamUrl) { mutableStateOf<Job?>(null) }
    var backendSwitched by remember(request.streamUrl) { mutableStateOf(false) }
    var failoverNote by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // [loadGen] keys the load-stall detector below: each fresh start
    // (and each manual retry from the error surface) earns one full
    // stall budget, never an endless spinner.
    var loadGen by remember(request.streamUrl) { mutableIntStateOf(0) }
    // Resume prompt: playback waits until the user picks Resume / Start over.
    var resumeDecided by remember(request.streamUrl) { mutableStateOf(resumePositionMs <= 0) }
    var startOver by remember(request.streamUrl) { mutableStateOf(false) }
    val showResumePrompt =
        resumePositionMs > 0 && !resumeDecided && !request.isLive && !request.isTrailer
    val shownError = errorMessage ?: creationError
    // Live zapping context: siblings + this channel's place among them.
    val liveSiblings = displayRequest.liveChannels
    val liveIndex =
        liveSiblings.indexOfFirst { it.metaId == displayRequest.liveChannel?.metaId }
    val canZap = request.isLive && liveSiblings.size > 1 && onZapChannel != null
    fun zap(delta: Int) {
        if (!canZap || liveIndex < 0) return
        val target = liveSiblings.getOrNull(liveIndex + delta) ?: return
        onZapChannel?.invoke(target)
    }
    var buffering by remember(request.streamUrl) { mutableStateOf(true) }
    var reachedReady by remember(request.streamUrl) { mutableStateOf(false) }
    var resumeFallbackDone by remember(request.streamUrl) { mutableStateOf(false) }
    var playbackEnded by remember(request.streamUrl) { mutableStateOf(false) }
    // Sources auto-popup bookkeeping (v0.3.10): sourcesStartGen
    // counts play STARTS within this screen — a pick from the Sources
    // panel is a new start and bumps it, earning a fresh 30s clock;
    // auto-failovers in between do NOT touch it, so the clock runs
    // across them, as the owner's rule states. sourcesAutoOpened is
    // the once-per-start latch: set when the popup fires (or when the
    // panel is already up by hand at fire time), never reset except
    // by a pick starting a new clock — a manual close after an
    // auto-open therefore stays closed for that start.
    var sourcesStartGen by remember(request.streamUrl) { mutableIntStateOf(0) }
    var sourcesAutoOpened by remember(request.streamUrl) { mutableStateOf(false) }

    var controlsVisible by remember(request.streamUrl) { mutableStateOf(true) }
    var picker by remember(request.streamUrl) { mutableStateOf(PlayerPicker.NONE) }

    /** Sleep-timer expiry: pause, clear the arm, release the screen hold. */
    fun expireSleepTimer() {
        sleepPreset = 0
        sleepDeadlineMs = 0L
        sleepAtEpisodeEnd = false
        sleepRemainingSec = 0
        runCatching { player?.pause() }
        sleepScreenReleased = true
        controlsVisible = true
    }
    var isPlaying by remember(request.streamUrl) { mutableStateOf(false) }
    // v0.3.31 (spec §5.1 item 2, the phone's loading gate): a
    // resume after a user pause re-enters the heartbeat loading
    // face while it buffers. Set by togglePlay's play branch,
    // cleared the moment playback is rolling again (effect below)
    // or on a fresh pause.
    var resumeBuffering by remember(request.streamUrl) { mutableStateOf(false) }
    var positionMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var durationMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var bufferedMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var tracksVersion by remember(request.streamUrl) { mutableIntStateOf(0) }
    // The IntroDB segment under the playhead, if the toggle is on.
    // v0.3.23: derivedStateOf — reading positionMs directly here
    // subscribed this whole screen body to every ticker write (500ms
    // with the controls up), recomposing the video container, scrims
    // and control stack on a box that can ill afford it. Now the body
    // only recomposes when the segment actually changes; the ticker
    // still writes positionMs at the same rate, but only the seek
    // bar (below, lambda-fed) and this derived value observe it.
    val skipIntroEnabled by rememberUpdatedState(showSkipIntro)
    val skipSegmentsNow by rememberUpdatedState(skipSegments)
    val activeSegment by
        remember(request.streamUrl) {
            derivedStateOf {
                if (skipIntroEnabled) {
                    skipSegmentsNow.firstOrNull {
                        positionMs >= it.startMs && positionMs <= it.endMs
                    }
                } else {
                    null
                }
            }
        }
    val seekFocus = remember { FocusRequester() }
    // v0.3.19 focus trap: every picker-opening control carries its
    // own FocusRequester so that closing a picker can return focus
    // to the exact control that opened it (see the restore effect
    // below). AUDIO_PREF is reached from inside the Audio panel, so
    // it returns to the Audio control — the chain's root opener.
    val episodesBtnFocus = remember { FocusRequester() }
    val subtitlesBtnFocus = remember { FocusRequester() }
    val audioBtnFocus = remember { FocusRequester() }
    val sourcesBtnFocus = remember { FocusRequester() }
    val speedBtnFocus = remember { FocusRequester() }
    val sleepBtnFocus = remember { FocusRequester() }
    // The picker that was open most recently — its opener regains
    // focus when the picker closes. NONE = nothing to restore to.
    var pickerOpener by remember(request.streamUrl) { mutableStateOf(PlayerPicker.NONE) }
    // v0.3.8: focus holder of last resort for the root Box — armed
    // whenever the control layer is un-composed (see the effect below).
    val keyCatcherFocus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    // Next-episode state (autoplay countdown + manual picks).
    var nextUpRequest by remember(request.streamUrl) { mutableStateOf<PlaybackRequest?>(null) }
    // v0.3.31 (spec item 25): cancelling the next-episode
    // countdown demotes it to the standing suggestion pill
    // instead of dismissing it; a fresh next-up resets the demote.
    var nextUpDemoted by remember(request.streamUrl) { mutableStateOf(false) }
    LaunchedEffect(nextUpRequest) { nextUpDemoted = false }
    var nextUpVideo by remember(request.streamUrl) { mutableStateOf<Video?>(null) }
    var nextUpSeconds by remember(request.streamUrl) { mutableIntStateOf(10) }
    var resolvingNext by remember(request.streamUrl) { mutableStateOf(false) }
    // Early resolve (v0.3.26): the next episode's streams are
    // resolved while the current one is still playing (see the
    // near-end effect below), so the countdown at the end starts
    // with the pick already in hand instead of resolving on the
    // spot. preResolveAttempted is the once-per-episode latch: a
    // failed early resolve is retried by the classic at-end path,
    // never in a loop.
    var preResolvedNext by remember(request.streamUrl) { mutableStateOf<PlaybackRequest?>(null) }
    var preResolvingNext by remember(request.streamUrl) { mutableStateOf(false) }
    var preResolveAttempted by remember(request.streamUrl) { mutableStateOf(false) }
    var episodeError by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // In-player Download outcome (v0.3.16), shown as the same
    // transient centre message as episodeError.
    var downloadNotice by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    val hasEpisodes = request.episodes.isNotEmpty() && !request.isMovie && !request.isLive
    val nextVideo = remember(request) { viewModel.nextEpisode(request) }

    fun playEpisode(video: Video) {
        if (resolvingNext || onPlayNextEpisode == null) return
        resolvingNext = true
        scope.launch(CrashReports.backgroundScopeHandler) {
            val resolved = viewModel.resolveEpisode(request, video)
            resolvingNext = false
            if (resolved != null) {
                onPlayNextEpisode(resolved)
            } else {
                episodeError = "No streams for that episode."
            }
        }
    }

    // Early resolve (v0.3.26): once the playhead is near the end —
    // 2 minutes remaining OR 98% played, whichever comes first —
    // resolve the next episode in the background through the same
    // autoplay path the at-end effect uses. No UI changes: the
    // countdown card and its timing are untouched; the resolve is
    // simply already done (or in flight) when the end arrives. The
    // clock mirror publishes position at least every ~2 s even with
    // the controls hidden, so the trigger cannot be slept through.
    val nearEnd by
        remember(request.streamUrl) {
            derivedStateOf {
                durationMs > 0 && !playbackEnded &&
                    (
                        durationMs - positionMs <= 120_000L ||
                            positionMs * 100 >= durationMs * 98
                        )
            }
        }
    LaunchedEffect(nearEnd, autoPlayNext, nextVideo) {
        if (nearEnd && autoPlayNext && nextVideo != null && onPlayNextEpisode != null &&
            !preResolveAttempted && !resolvingNext && nextUpRequest == null
        ) {
            preResolveAttempted = true
            preResolvingNext = true
            val resolved = viewModel.resolveEpisode(request, nextVideo)
            preResolvingNext = false
            if (resolved != null) {
                preResolvedNext = resolved
            }
        }
    }

    // Autoplay: when playback ends and the switch is on, start the
    // countdown card — from the early resolve when it landed, from
    // an in-flight early resolve when it lands (the preResolvingNext
    // key re-runs this effect as it settles), or by resolving on the
    // spot exactly as before.
    // Sleep timer, end-of-episode arm (v0.3.26): when the episode
    // ends armed, the end is consumed by the timer — the autoplay
    // countdown below stands down (its condition checks the arm and
    // the latch), playback stops here and the screen is released.
    LaunchedEffect(playbackEnded, sleepAtEpisodeEnd) {
        if (playbackEnded && sleepAtEpisodeEnd) {
            sleepEndConsumed = true
            expireSleepTimer()
        }
    }
    LaunchedEffect(playbackEnded, autoPlayNext, nextVideo, preResolvingNext, sleepAtEpisodeEnd, sleepEndConsumed) {
        if (playbackEnded && autoPlayNext && nextVideo != null &&
            nextUpRequest == null && !resolvingNext && onPlayNextEpisode != null &&
            !sleepAtEpisodeEnd && !sleepEndConsumed
        ) {
            val pre = preResolvedNext
            when {
                pre != null -> {
                    nextUpVideo = nextVideo
                    nextUpRequest = pre
                    nextUpSeconds = 10
                }
                // Early resolve still in flight: stand down — this
                // effect re-runs when it settles and takes the
                // branch above (or resolves on the spot if it
                // failed).
                preResolvingNext -> Unit
                else -> {
                    resolvingNext = true
                    val resolved = viewModel.resolveEpisode(request, nextVideo)
                    resolvingNext = false
                    if (resolved != null) {
                        nextUpVideo = nextVideo
                        nextUpRequest = resolved
                        nextUpSeconds = 10
                    }
                }
            }
        }
    }
    // The countdown itself: ticks to zero, then jumps. A sleep
    // end-of-episode arm set while the card is up consumes the end
    // instead (v0.3.26): the jump never happens. v0.3.31: a
    // demoted countdown (the user cancelled it into the standing
    // suggestion) never jumps either — the suggestion just stands.
    LaunchedEffect(nextUpRequest, sleepAtEpisodeEnd, nextUpDemoted) {
        val target = nextUpRequest ?: return@LaunchedEffect
        if (sleepAtEpisodeEnd) {
            sleepEndConsumed = true
            nextUpRequest = null
            expireSleepTimer()
            return@LaunchedEffect
        }
        if (nextUpDemoted) return@LaunchedEffect
        while (nextUpSeconds > 0) {
            delay(1_000)
            nextUpSeconds--
        }
        onPlayNextEpisode?.invoke(target)
    }
    // The same-source recovery coordinator (v0.3.17 — replaces the
    // v0.3.12–0.3.16 source-hopping ladder; see MAX_AUTO_RETRIES).
    // One entry point for every automatic failure: the player-error
    // listener and both ViewModel watchdogs (through the
    // watchdogRecovery hook) come through here, so a hard error, a
    // silent hang and an audio-but-black stream all recover the
    // reference player's way:
    //   · classify first — a non-retryable failure (a permanent
    //     HTTP status above all) returns false at once and the
    //     caller shows the error surface; the source NEVER changes
    //     on its own, so there is nothing to "skip fast" through;
    //   · retryable → at most MAX_AUTO_RETRIES retries of THE SAME
    //     source, each after RETRY_DELAY_MS of patience: attempt
    //     one re-prepares the live player, attempt two fully
    //     rebuilds it — in the safe configuration when that hasn't
    //     been tried yet (our one-engine analogue of the reference's
    //     second-chance configuration), a plain rebuild otherwise;
    //   · single-flight: while a retry is scheduled or running,
    //     further failure calls return true WITHOUT spending budget
    //     again — the v0.3.16 crash came from two callers (error
    //     listener + watchdog) stepping the old ladder in the same
    //     instant and racing two starts against each other.
    // Manual choices are untouched: the error surface keeps Retry /
    // Next source / Sources, and the Sources panel pick still
    // switches — those are the USER's switches, not the player's.
    val safeRetryNote = stringResource(R.string.plavio_player_safe_retry)
    val retryingNote = stringResource(R.string.plavio_player_retrying)
    fun attemptRecovery(retryable: Boolean): Boolean {
        if (!retryable) return false
        if (recoveryJob?.isActive == true) return true
        if (autoRetryCount >= MAX_AUTO_RETRIES) return false
        val attempt = autoRetryCount
        autoRetryCount++
        errorMessage = null
        buffering = true
        recoveryJob =
            scope.launch(CrashReports.backgroundScopeHandler) {
                delay(RETRY_DELAY_MS)
                if (attempt == 0) {
                    failoverNote = retryingNote
                    // Light recovery first (the reference's attempt
                    // one): re-prepare the same player. A watchdog
                    // failure on a start that never produced a
                    // player falls through to a full same-source
                    // restart instead.
                    if (!viewModel.reprepareCurrentStream(positionMs)) {
                        viewModel.retry(positionMs)
                    }
                } else {
                    // Full rebuild (the reference's attempt two),
                    // in the safe configuration when untried.
                    if (!backendSwitched && viewModel.recreateInSafeMode(positionMs)) {
                        backendSwitched = true
                        failoverNote = safeRetryNote
                    } else {
                        failoverNote = retryingNote
                        viewModel.retry(positionMs)
                    }
                }
            }
        return true
    }

    LaunchedEffect(episodeError) {
        if (episodeError != null) {
            delay(3_000)
            episodeError = null
        }
    }
    LaunchedEffect(downloadNotice) {
        if (downloadNotice != null) {
            delay(3_000)
            downloadNotice = null
        }
    }
    LaunchedEffect(playerNotice) {
        if (playerNotice != null) {
            delay(4_000)
            viewModel.clearPlayerNotice()
        }
    }

    // Auto Frame Rate (batch 6): with the switch on, while a video
    // plays, ask the window for the display mode whose refresh rate
    // matches the stream's frame rate (FrameRateMatch decides), and
    // restore the previous mode when the player goes away. The
    // request goes through the activity window's
    // preferredDisplayModeId — the display path this
    // single-activity player's surface offers; the panel may blink
    // briefly when the mode actually changes.
    val afrContext = LocalContext.current
    DisposableEffect(player, autoFrameRate) {
        val activePlayer = player
        if (!autoFrameRate || activePlayer == null) {
            return@DisposableEffect onDispose { }
        }
        val activity =
            generateSequence(afrContext) {
                (it as? android.content.ContextWrapper)?.baseContext
            }.filterIsInstance<android.app.Activity>()
                .firstOrNull()
        val window = activity?.window
        val display =
            afrContext
                .getSystemService(android.hardware.display.DisplayManager::class.java)
                ?.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        if (window == null || display == null) {
            return@DisposableEffect onDispose { }
        }
        val originalModeId = window.attributes.preferredDisplayModeId

        fun applyFrameRate(tracks: Tracks) {
            // The selected video track's frame rate (the Player
            // interface exposes no direct video-format callback;
            // track selection is where the format becomes known).
            val frameRate =
                tracks.groups
                    .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                    ?.let { group ->
                        (0 until group.length)
                            .firstOrNull { group.isTrackSelected(it) }
                            ?.let { group.getTrackFormat(it).frameRate }
                    }
                    ?: return
            val modes =
                display.supportedModes.map {
                    com.github.damontecres.wholphin.plavio.FrameRateMatch.ModeInfo(
                        it.modeId,
                        it.physicalWidth,
                        it.physicalHeight,
                        it.refreshRate,
                    )
                }
            val target =
                com.github.damontecres.wholphin.plavio.FrameRateMatch
                    .pickModeId(modes, display.mode.modeId, frameRate)
            if (target != null) {
                val attrs = window.attributes
                attrs.preferredDisplayModeId = target
                window.attributes = attrs
            }
        }
        val listener =
            object : Player.Listener {
                override fun onTracksChanged(tracks: Tracks) {
                    applyFrameRate(tracks)
                }
            }
        activePlayer.addListener(listener)
        // Tracks may already be selected (switch toggled mid-play).
        applyFrameRate(activePlayer.currentTracks)
        onDispose {
            activePlayer.removeListener(listener)
            val attrs = window.attributes
            if (attrs.preferredDisplayModeId != originalModeId) {
                attrs.preferredDisplayModeId = originalModeId
                window.attributes = attrs
            }
        }
    }

    // The stored stream is gone (or never got going): hand the user the
    // item's streams screen instead of leaving them on an error.
    LaunchedEffect(resumeFailed) {
        if (resumeFailed && !resumeFallbackDone) {
            resumeFallbackDone = true
            onResumeFailed?.invoke()
        }
    }

    LaunchedEffect(request.streamUrl, resumePositionMs, resumeDecided) {
        if (resumeDecided) {
            viewModel.start(request, if (startOver) 0 else resumePositionMs)
        }
    }
    // Sources auto-popup timer (v0.3.10): armed once the start is
    // real (resume decided — before that the clock hasn't begun) and
    // cancelled the moment this start first reaches READY
    // (reachedReady flips true on the first STATE_READY, the
    // "playing picture" proxy the rest of this screen uses) or when
    // the screen leaves composition. Failovers don't re-key it —
    // switchStream keeps the same request.streamUrl and generation —
    // so the 30s runs across them. At fire time it re-checks the UI:
    // an error surface or another open picker owns the screen by
    // then, and the popup stays out of their way.
    LaunchedEffect(request.streamUrl, sourcesStartGen, resumeDecided, reachedReady) {
        if (!resumeDecided || reachedReady || sourcesAutoOpened) return@LaunchedEffect
        delay(SOURCES_AUTO_POPUP_MS)
        if (picker == PlayerPicker.SOURCES) {
            // Opened by hand during the wait: that counts as this
            // start's one fire — no re-open after a manual close.
            sourcesAutoOpened = true
        } else if (shownError == null && !showResumePrompt && picker == PlayerPicker.NONE) {
            sourcesAutoOpened = true
            picker = PlayerPicker.SOURCES
        }
    }
    // Load stall detector (v0.3.15 — replaces the v0.3.14 wall-clock
    // deadline; see LOAD_STALL_LIMIT_MS for why the wall clock killed
    // healthy starts): poll the feeding player; time only accrues
    // while NOTHING is progressing. Progress = the buffered position
    // advancing, or the player instance changing (a ladder hop or a
    // fresh start is activity, not stall). The clock also rests
    // while anything else owns the screen (the sources picker counts
    // as control returned; an error surface and the resume prompt
    // own it outright) and while no player exists yet (creation is
    // quick and its failures surface as creation errors). A manual
    // Retry / Next source bumps [loadGen] and restarts the detector.
    // When the bound is hit the session is stopped and the error
    // surface takes the screen with focus — the user always gets
    // the remote back, and Back never needed help from here: no
    // step in the load path blocks the UI thread (factory gate).
    val loadTimeoutMessage = stringResource(R.string.plavio_player_load_timeout)
    LaunchedEffect(request.streamUrl, loadGen) {
        if (reachedReady) return@LaunchedEffect
        var stalledMs = 0L
        var lastPlayer: Player? = null
        var lastBufferedMs = -1L
        while (isActive && !reachedReady) {
            delay(LOAD_STALL_POLL_MS)
            if (reachedReady) break
            val current = player
            val userOwnsScreen =
                picker != PlayerPicker.NONE || shownError != null || showResumePrompt
            val progressed =
                when {
                    userOwnsScreen -> true
                    current == null -> true
                    current !== lastPlayer -> true
                    current.bufferedPosition > lastBufferedMs -> true
                    else -> false
                }
            lastPlayer = current
            if (current != null) lastBufferedMs = current.bufferedPosition
            if (progressed) {
                stalledMs = 0L
                continue
            }
            stalledMs += LOAD_STALL_POLL_MS
            if (stalledMs >= LOAD_STALL_LIMIT_MS) {
                // v0.3.17: a wedged load gets the same bounded
                // same-source recovery as a hard error before the
                // session is declared dead — the recovery's own
                // restart counts as progress on the next polls.
                // Only when the budget is spent (or a recovery is
                // somehow refused) does the old stop + error
                // surface path run: the user always gets the
                // remote back.
                if (attemptRecovery(retryable = true)) {
                    stalledMs = 0L
                    continue
                }
                Timber.w(
                    "Load stalled: no buffering progress for %dms; returning control",
                    stalledMs,
                )
                viewModel.stop()
                buffering = false
                errorMessage = loadTimeoutMessage
                break
            }
        }
    }
    // Re-apply the session speed whenever the player instance changes
    // (fresh start, failover, episode switch all build a new player).
    LaunchedEffect(player, speed) {
        val active = player ?: return@LaunchedEffect
        runCatching { active.playbackParameters = PlaybackParameters(speed) }
    }
    DisposableEffect(Unit) {
        onDispose { viewModel.stop() }
    }

    // Sleep timer, timed arm (v0.3.26): tick the button's remaining
    // label down once a second; at zero the timer expires (pause +
    // screen release — see expireSleepTimer).
    LaunchedEffect(sleepDeadlineMs) {
        if (sleepDeadlineMs <= 0L) return@LaunchedEffect
        while (isActive) {
            val remaining = sleepDeadlineMs - System.currentTimeMillis()
            if (remaining <= 0L) {
                expireSleepTimer()
                break
            }
            sleepRemainingSec = ((remaining + 999L) / 1_000L).toInt()
            delay(1_000)
        }
    }
    // Waking from a sleep release: playing again re-takes the
    // screen hold (the phone's rule — resume restores keepScreenOn).
    LaunchedEffect(isPlaying) {
        if (isPlaying && sleepScreenReleased) sleepScreenReleased = false
    }

    val view = LocalView.current
    DisposableEffect(sleepScreenReleased) {
        view.keepScreenOn = !sleepScreenReleased
        onDispose { view.keepScreenOn = false }
    }

    // The recovery coordinator itself (attemptRecovery) is defined
    // with the session state above — it must precede the load-stall
    // detector, which also routes through it. What remains here is
    // its wiring: the note's auto-clear, and the ViewModel watchdog
    // hook (a silent hang or an audio-but-black stream is a
    // retryable failure of THE SAME source — never a source hop).
    LaunchedEffect(failoverNote) {
        if (failoverNote != null) {
            delay(3_500)
            failoverNote = null
        }
    }

    DisposableEffect(viewModel) {
        viewModel.watchdogRecovery = { attemptRecovery(retryable = true) }
        onDispose { viewModel.watchdogRecovery = null }
    }

    DisposableEffect(player) {
        val active = player
        if (active == null) {
            onDispose { }
        } else {
            val listener =
                object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        if (resumePositionMs > 0 && !reachedReady &&
                            onResumeFailed != null && !resumeFallbackDone
                        ) {
                            resumeFallbackDone = true
                            onResumeFailed()
                            return
                        }
                        // v0.3.17, the reference method: classify,
                        // then retry THE SAME source (bounded, with
                        // patience) — the player never advances to
                        // another source on its own. A non-retryable
                        // failure (permanent HTTP status, DRM, …)
                        // or a spent budget shows the error surface,
                        // where Retry / Next source / Sources stay
                        // manual, as they were.
                        if (!attemptRecovery(isRetryablePlaybackError(error))) {
                            errorMessage = error.message
                            buffering = false
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        // v0.3.18: buffering/isPlaying are written by
                        // the ViewModel clock alone now (see the
                        // mirror effect below) — this listener keeps
                        // only the edge events: ready, ended, error.
                        if (playbackState == Player.STATE_READY) {
                            reachedReady = true
                            errorMessage = null
                            // v0.3.17: NO instant budget reset here —
                            // the retry budget refills only after
                            // STABLE_PROGRESS_RESET_MS of sustained
                            // healthy playing (see the effect below),
                            // the reference's stable-progress rule. A
                            // stream that flickers READY between
                            // failures must not regain a full budget
                            // on every flicker.
                        }
                        if (playbackState == Player.STATE_ENDED) {
                            playbackEnded = true
                        }
                    }

                    override fun onTracksChanged(tracks: Tracks) {
                        tracksVersion++
                    }

                    override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                        // v0.3.21 (study fix #3): feed the surface
                        // frame sizing in the AndroidView block.
                        videoAspect =
                            if (videoSize.height > 0) {
                                videoSize.width * videoSize.pixelWidthHeightRatio /
                                    videoSize.height
                            } else {
                                0f
                            }
                    }
                }
            active.addListener(listener)
            onDispose { active.removeListener(listener) }
        }
    }

    // Stable-progress budget refill (v0.3.17, the reference's rule):
    // the automatic-retry budget resets only after
    // STABLE_PROGRESS_RESET_MS of sustained READY + playing. The
    // effect re-keys on every playing/ready flip, so any stumble
    // restarts the 5s proof — a stream oscillating between READY
    // and error keeps the budget it has left.
    LaunchedEffect(player, isPlaying, reachedReady) {
        if (player != null && isPlaying && reachedReady) {
            delay(STABLE_PROGRESS_RESET_MS)
            if (isPlaying) {
                autoRetryCount = 0
            }
        }
    }

    // Preferred-language auto-pick, once per title: first audio
    // track matching the preferred audio language. v0.3.18: the
    // subtitle half of this effect is REMOVED on the owner's order
    // — subtitles are OFF by default, no auto-selected subtitle on
    // play, whatever the preferred languages say. (The preferred
    // languages still order the panel's Languages rail; they just
    // never turn a subtitle on by themselves.)
    var preferredApplied by remember(request.streamUrl) { mutableStateOf(false) }
    LaunchedEffect(tracksVersion, player) {
        val active = player ?: return@LaunchedEffect
        if (preferredApplied) return@LaunchedEffect
        val audioOptions = trackOptions(active, text = false)
        if (audioOptions.isEmpty()) return@LaunchedEffect
        preferredApplied = true
        preferredAudioLanguage?.let { lang ->
            audioOptions
                .firstOrNull { it.language == lang }
                ?.let { applyTrackOption(active, text = false, it) }
        }
    }

    // Per-title memory restore (v0.3.26): once per player instance.
    // Speed + aspect apply as soon as the memory is known; the track
    // picks wait for the player's tracks and route exactly like the
    // panels' picks (sidecar / libass / media track). A remembered
    // audio pick also satisfies the preferred-language latch above —
    // the memory outranks the language default. Live channels and
    // trailers remember nothing.
    var memorySpeedAppliedFor by remember(request.streamUrl) { mutableStateOf<Player?>(null) }
    LaunchedEffect(player, titleMemory) {
        val active = player ?: return@LaunchedEffect
        val memory = titleMemory ?: return@LaunchedEffect
        if (memorySpeedAppliedFor === active) return@LaunchedEffect
        memorySpeedAppliedFor = active
        if (request.isLive || request.isTrailer) return@LaunchedEffect
        speed = memory.speed
        resizeMode = memory.resizeMode
        playerViewRef?.resizeMode = memory.resizeMode
    }
    var memoryTracksAppliedFor by remember(request.streamUrl) { mutableStateOf<Player?>(null) }
    LaunchedEffect(player, tracksVersion, titleMemory) {
        val active = player ?: return@LaunchedEffect
        val memory = titleMemory ?: return@LaunchedEffect
        if (memoryTracksAppliedFor === active) return@LaunchedEffect
        if (request.isLive || request.isTrailer) {
            memoryTracksAppliedFor = active
            return@LaunchedEffect
        }
        var settled = true
        if (memory.audioKey != null) {
            val audioOptions = trackOptions(active, text = false)
            if (audioOptions.isEmpty()) {
                settled = false
            } else {
                val idx =
                    com.github.damontecres.wholphin.plavio.PlayerMemoryKeys.matchIndex(
                        memory.audioKey,
                        audioOptions.map { it.formatId to it.language },
                    )
                if (idx >= 0) {
                    applyTrackOption(active, text = false, audioOptions[idx])
                    preferredApplied = true
                }
            }
        }
        when (val subKey = memory.subtitleKey) {
            null -> Unit
            com.github.damontecres.wholphin.plavio.PlayerMemoryKeys.SUBTITLE_OFF -> {
                trackOptions(active, text = true).firstOrNull { it.isOff }?.let { off ->
                    viewModel.stopSidecar()
                    applyTrackOption(active, text = true, off)
                }
            }
            else ->
                if (subKey.startsWith("url:")) {
                    val url = subKey.removePrefix("url:")
                    val sub = displayRequest.subtitles.firstOrNull { it.url == url }
                    if (sub != null) {
                        when {
                            viewModel.needsLibassForPick(sub) ->
                                viewModel.rebuildWithLibassFor(
                                    sub,
                                    viewModel.currentPositionMs(),
                                )
                            viewModel.sidecarEligible(sub) ->
                                viewModel.selectSidecarSubtitle(sub)
                            else -> {
                                val index = displayRequest.subtitles.indexOf(sub)
                                val option =
                                    trackOptions(active, text = true)
                                        .firstOrNull { it.formatId == "e:$index" }
                                if (option?.group != null) {
                                    viewModel.stopSidecar()
                                    applyTrackOption(active, text = true, option)
                                } else {
                                    viewModel.selectSidecarSubtitle(sub)
                                }
                            }
                        }
                    }
                } else if (subKey.startsWith("emb|")) {
                    val embedded =
                        trackOptions(active, text = true).filter { !it.isOff }
                    if (embedded.isEmpty()) {
                        settled = false
                    } else {
                        val idx =
                            com.github.damontecres.wholphin.plavio.PlayerMemoryKeys.matchIndex(
                                subKey,
                                embedded.map { it.formatId to it.language },
                            )
                        if (idx >= 0) {
                            viewModel.stopSidecar()
                            applyTrackOption(active, text = true, embedded[idx])
                        }
                    }
                }
        }
        if (settled) memoryTracksAppliedFor = active
    }

    // Player clock mirror (v0.3.18, diagnosis cause #3): the 500 ms
    // position ticker that used to run in THIS composition is gone.
    // The ViewModel polls the player on its own clock and publishes
    // PlayerClock snapshots; they are mirrored into the state the
    // seek bar, time labels and spinner read — same values at the
    // same rate. The buffering rule (an advancing position counts
    // as playing even when the state flag sticks at BUFFERING)
    // moved with the polling, into the ViewModel.
    // v0.3.27: the mirror lives in PlayerClockSync (below) — this
    // root used to collect the flow itself and key this effect on
    // the snapshot, so every tick (500 ms with the controls up,
    // ~2 s hidden) re-executed the WHOLE screen body just to
    // compare keys. Now only the tiny sync composable recomposes
    // per tick; the writes land in the same root states, and only
    // their genuine readers (the lambda-fed seek bar, the derived
    // segment / near-end values, the spinner gates) observe them.
    PlayerClockSync(playerClock = viewModel.playerClock) { clock ->
        positionMs = clock.positionMs
        durationMs = clock.durationMs
        bufferedMs = clock.bufferedMs
        isPlaying = clock.isPlaying
        buffering = clock.buffering
    }

    // v0.3.21 (study fix #4): tell the ViewModel whether the
    // control layer is presented, so its clock can drop the
    // 500 ms publish rate while nothing is on screen to read it.
    // An open picker counts as presented (its panels read the
    // mirrored position).
    LaunchedEffect(controlsVisible, picker) {
        viewModel.setControlsPresented(controlsVisible || picker != PlayerPicker.NONE)
    }

    // Focus the seek bar whenever the controls come up.
    //
    // v0.3.26 FOCUS FIX (owner report 2026-11-15: "when player opens,
    // buttons and seek bar display, but remote focus never works
    // until they hide and come back"): the old effect was keyed on
    // (controlsVisible, player) only, so its one shot fired the
    // moment the player OBJECT existed — before STATE_READY, while
    // the control layer's gate (reachedReady || !buffering) was
    // still closed and the seek bar did not exist. requestFocus()
    // threw, runCatching swallowed it, and no key ever changed again
    // on the open path, so the request was never retried: controls
    // on screen, nothing focused, dead remote. The hide → wake cycle
    // "fixed" it because waking flipped controlsVisible, re-running
    // the effect with the layer composed. The effect is now keyed on
    // the layer's own gate, so it fires when the layer actually
    // composes — and only then (the gate is a stable boolean once
    // READY lands, so rebuffering can't re-fire it and yank focus
    // off a control the user has since walked to). The control
    // stack ALSO arms the same request from inside the layer on its
    // first composition (below), covering the paths where the layer
    // re-composes without any of these keys changing (the next-up
    // card going away). The wake-press behaviour is untouched —
    // while the controls are hidden a D-pad press still only wakes
    // them (the owner's call: standard TV behaviour).
    val controlLayerGateOpen = reachedReady || !buffering
    LaunchedEffect(controlsVisible, player, controlLayerGateOpen) {
        if (controlsVisible && player != null && controlLayerGateOpen &&
            picker == PlayerPicker.NONE && nextUpRequest == null && !showResumePrompt
        ) {
            runCatching { seekFocus.requestFocus() }
        }
    }
    // v0.3.26: arm the root key catcher the moment a player exists,
    // so SOME node in this screen holds focus from the first frame —
    // the media keys and the wake handler ride its preview handler,
    // and before this arm the first press of anything after opening
    // the player was spent on the framework's focus search instead
    // of acting (the second half of the owner's report: "back
    // forward need more attempts, all over every function"). The
    // seek-bar request above moves focus into the controls the
    // moment the layer composes; the resume prompt, when it shows,
    // requests its own focus after this arm and keeps it.
    LaunchedEffect(player) {
        if (player != null) {
            runCatching { keyCatcherFocus.requestFocus() }
        }
    }
    // v0.3.8 REGRESSION FIX (controls never woke after the first
    // auto-hide): the wake-up keys are handled by the root Box's
    // onPreviewKeyEvent, and a preview handler only receives events
    // dispatched to a FOCUSED descendant. While the controls are up
    // that descendant is the seek bar — but the seek bar lives inside
    // the control layer, which v0.3.7 un-composes when hidden, and a
    // focused node leaving composition takes focus with it. The
    // PlayerView is isFocusable=false, so after the first hide no
    // node in this screen could hold focus and no key ever reached
    // the wake-up handler again. Fix: whenever the controls go down
    // (and no picker / next-up card / error / resume prompt owns the
    // UI — those request their own focus), hand focus to the root Box
    // itself, which is always composed and carries the wake handler.
    // Re-armed on every hide, so hide -> wake works repeatedly; the
    // layer stays un-composed while hidden (the v0.3.7 perf win is
    // untouched).
    LaunchedEffect(controlsVisible, player, picker, nextUpRequest, shownError, showResumePrompt) {
        if (!controlsVisible && player != null && picker == PlayerPicker.NONE &&
            nextUpRequest == null && shownError == null && !showResumePrompt
        ) {
            runCatching { keyCatcherFocus.requestFocus() }
        }
    }
    // v0.3.19: closing a picker (a pick, or Back) returns focus to
    // the control that opened it. Before this, the panel row holding
    // focus left composition together with the panel and focus fell
    // to wherever the next focus search happened to land — the
    // seek bar or another control, seemingly at random ("it also
    // goes back to the video player controls"). Skipped when another
    // overlay (error, next-up card, resume prompt) owns the UI, and
    // on the very first composition (picker starts at NONE).
    LaunchedEffect(picker) {
        if (picker != PlayerPicker.NONE) {
            pickerOpener = picker
            return@LaunchedEffect
        }
        if (pickerOpener == PlayerPicker.NONE) return@LaunchedEffect
        val opener = pickerOpener
        pickerOpener = PlayerPicker.NONE
        if (!controlsVisible || shownError != null || nextUpRequest != null || showResumePrompt) {
            return@LaunchedEffect
        }
        runCatching {
            when (opener) {
                PlayerPicker.SUBTITLES -> subtitlesBtnFocus.requestFocus()
                PlayerPicker.AUDIO, PlayerPicker.AUDIO_PREF -> audioBtnFocus.requestFocus()
                PlayerPicker.EPISODES -> episodesBtnFocus.requestFocus()
                PlayerPicker.SOURCES -> sourcesBtnFocus.requestFocus()
                PlayerPicker.SPEED -> speedBtnFocus.requestFocus()
                PlayerPicker.SLEEP -> sleepBtnFocus.requestFocus()
                PlayerPicker.NONE -> seekFocus.requestFocus()
            }
        }
    }
    // Auto-hide while playing. v0.3.31 (spec item 11): the delay
    // is the phone's 3.5s — a timing alignment only; the hide
    // CONDITIONS are TV's, unchanged.
    LaunchedEffect(controlsVisible, isPlaying, picker, nextUpRequest) {
        if (controlsVisible && isPlaying && picker == PlayerPicker.NONE &&
            shownError == null && nextUpRequest == null
        ) {
            delay(3_500)
            controlsVisible = false
        }
    }
    // Back hides the controls / closes a picker before leaving playback.
    BackHandler(enabled = picker != PlayerPicker.NONE) { picker = PlayerPicker.NONE }
    BackHandler(enabled = nextUpRequest != null) { nextUpRequest = null }
    BackHandler(
        enabled = picker == PlayerPicker.NONE && nextUpRequest == null && controlsVisible && shownError == null,
    ) {
        controlsVisible = false
    }

    fun togglePlay() {
        val active = player ?: return
        if (active.isPlaying) {
            resumeBuffering = false
            active.pause()
        } else {
            resumeBuffering = true
            active.play()
        }
        controlsVisible = true
    }
    LaunchedEffect(isPlaying) {
        if (isPlaying) resumeBuffering = false
    }

    // Seek coalescing (v0.3.7): D-pad taps used to fire one full
    // re-buffer per key-down, so holding/repeating left/right stacked
    // several cold seeks. Now presses accumulate for ~300ms of quiet
    // and fire as ONE seekTo to the summed target; the seek bar shows
    // the pending target immediately. The skip-intro button below
    // still seeks directly — it is a single deliberate jump.
    var pendingSeekDeltaMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var pendingSeekJob by remember(request.streamUrl) { mutableStateOf<Job?>(null) }

    fun seekBy(deltaMs: Long) {
        val active = player ?: return
        pendingSeekDeltaMs += deltaMs
        val optimistic =
            (active.currentPosition + pendingSeekDeltaMs).coerceAtLeast(0)
        val dur = active.duration
        positionMs =
            if (dur != C.TIME_UNSET && dur > 0) optimistic.coerceAtMost(dur) else optimistic
        controlsVisible = true
        pendingSeekJob?.cancel()
        pendingSeekJob =
            scope.launch(CrashReports.backgroundScopeHandler) {
                delay(300)
                val delta = pendingSeekDeltaMs
                pendingSeekDeltaMs = 0L
                val base = runCatching { active.currentPosition }.getOrDefault(0L)
                val target = (base + delta).coerceAtLeast(0)
                val d = active.duration
                active.seekTo(
                    if (d != C.TIME_UNSET && d > 0) target.coerceAtMost(d) else target,
                )
            }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(Color.Black)
                // v0.3.8: the root Box itself is focusable so it can
                // hold focus while the control layer is un-composed
                // (armed by the effect above). focusable() draws
                // nothing, and a full-screen containing rect is never
                // a directional focus-search target from its own
                // children, so navigation while the controls are up
                // is unchanged.
                // v0.3.22: while a picker popup is open the catcher
                // is OUT of the focus graph entirely — a full-screen
                // focusable behind the popup was a landing spot for
                // focus leaving the popup, and from it the wake
                // handler + focus search could walk back into the
                // player (the owner's subs-popup escape).
                .focusRequester(keyCatcherFocus)
                .focusable(enabled = picker == PlayerPicker.NONE)
                .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (event.key) {
                        Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> {
                            togglePlay()
                            true
                        }
                        Key.MediaFastForward -> {
                            seekBy(skipForwardMs)
                            true
                        }
                        Key.MediaRewind -> {
                            seekBy(-skipBackMs)
                            true
                        }
                        Key.MediaStop -> {
                            player?.pause()
                            controlsVisible = true
                            true
                        }
                        Key.ChannelUp -> {
                            zap(1)
                            true
                        }
                        Key.ChannelDown -> {
                            zap(-1)
                            true
                        }
                        Key.DirectionCenter, Key.DirectionLeft, Key.DirectionRight,
                        Key.DirectionUp, Key.DirectionDown,
                        -> {
                            if (!controlsVisible && shownError == null && nextUpRequest == null) {
                                controlsVisible = true
                                true
                            } else {
                                false
                            }
                        }
                        else -> false
                    }
                },
    ) {
        val activePlayer = player
        // v0.3.7: the 500ms ticker recomposes this screen, so the
        // AndroidView update lambda re-runs at 2 Hz. The subtitle
        // style is only re-applied when it actually changed — the old
        // code re-touched the SubtitleView's style, size and padding
        // on every tick.
        var lastAppliedSubtitleStyle by remember(request.streamUrl) { mutableStateOf<SubtitleStyle?>(null) }
        // v0.3.21 (study fix #3): the last (resizeMode, videoAspect)
        // spec the surface's fixed size was driven for — the holder
        // is only re-sized when the spec actually changes.
        var lastSurfaceSpec by remember(request.streamUrl) { mutableStateOf<Pair<Int, Float>?>(null) }
        if (activePlayer != null) {
            // v0.3.21 (study fix #3 — the SurfaceView retry, shaped
            // the SmartTube way): the PlayerView's FRAME is sized by
            // the video aspect + the Aspect mode and centred on the
            // screen — Fit = the aspect rect inside the screen,
            // Fill = the full screen, Zoom = the aspect rect
            // COVERING the screen (the display crops the overflow).
            // The v0.3.7 attempt resized a content frame INSIDE a
            // full-screen PlayerView, which this class of MediaTek
            // firmware ignores; sizing the frame the surface lives
            // in — plus the holder's fixed size, driven in update
            // below — is the level the firmware honours. Until the
            // video size is known the view fills the screen, as
            // before. The subtitle view and the control layer are
            // separate layers and are untouched by the frame size.
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val frameModifier =
                    if (videoAspect > 0f) {
                        val screenAspect = maxWidth / maxHeight
                        val frameSize =
                            when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FILL ->
                                    DpSize(maxWidth, maxHeight)
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM ->
                                    if (screenAspect > videoAspect) {
                                        DpSize(maxWidth, maxWidth / videoAspect)
                                    } else {
                                        DpSize(maxHeight * videoAspect, maxHeight)
                                    }
                                else ->
                                    if (screenAspect > videoAspect) {
                                        DpSize(maxHeight * videoAspect, maxHeight)
                                    } else {
                                        DpSize(maxWidth, maxWidth / videoAspect)
                                    }
                            }
                        Modifier
                            .align(Alignment.Center)
                            .requiredSize(frameSize)
                    } else {
                        Modifier.fillMaxSize()
                    }
                AndroidView(
                    factory = { context ->
                        // v0.3.21: the surface is a SurfaceView
                        // again — see res/layout/plavio_player_view.xml
                        // for the one-line revert if this build shows
                        // a BLACK PICTURE on the owner's TV.
                        val inflated =
                            android.view.LayoutInflater
                                .from(context)
                                .inflate(R.layout.plavio_player_view, null) as PlayerView
                        inflated.apply {
                            useController = false
                            isFocusable = false
                            this.player = activePlayer
                            this.resizeMode = resizeMode
                            playerViewRef = this
                            applySubtitleStyle(this, subtitleStyle)
                            lastAppliedSubtitleStyle = subtitleStyle
                            // v0.3.18: the sidecar renders into this
                            // view's own SubtitleView (the reference's
                            // binding shape) — bind it so a pick made
                            // before the view existed still lands.
                            subtitleView?.let { viewModel.bindSubtitleView(it) }
                        }
                    },
                    update = { playerView ->
                        playerView.player = activePlayer
                        playerView.resizeMode = resizeMode
                        if (lastAppliedSubtitleStyle != subtitleStyle) {
                            runCatching { applySubtitleStyle(playerView, subtitleStyle) }
                            lastAppliedSubtitleStyle = subtitleStyle
                        }
                        // v0.3.21 (study fix #3): drive the
                        // surface's own fixed size from the frame's
                        // laid-out size — the second half of sizing
                        // at the surface level. Posted so it reads
                        // the post-layout size; runs only when the
                        // (mode, aspect) spec changed.
                        val spec = resizeMode to videoAspect
                        if (lastSurfaceSpec != spec) {
                            lastSurfaceSpec = spec
                            playerView.post {
                                runCatching {
                                    (playerView.videoSurfaceView as? android.view.SurfaceView)
                                        ?.holder
                                        ?.setFixedSize(
                                            playerView.width.coerceAtLeast(1),
                                            playerView.height.coerceAtLeast(1),
                                        )
                                }
                            }
                        }
                    },
                    // v0.3.12 guard: never leave a dangling PlayerView
                    // reference behind when the surface detaches — the
                    // aspect button writes through it.
                    onRelease = {
                        it.player = null
                        playerViewRef = null
                        viewModel.bindSubtitleView(null)
                    },
                    modifier = frameModifier,
                )
            }
        }

        if (shownError != null) {
            val retryFocus = remember { FocusRequester() }
            LaunchedEffect(shownError) { runCatching { retryFocus.requestFocus() } }
            // v0.3.19: if the Sources panel below closes without a
            // pick (Back), hand focus back to the error actions — the
            // screen-level opener-restore deliberately skips the
            // error state, and the panel row that held focus leaves
            // composition with the panel.
            LaunchedEffect(picker) {
                if (picker == PlayerPicker.NONE) {
                    runCatching { retryFocus.requestFocus() }
                }
            }
            // v0.3.31 (spec item 27, the phone's form): the error
            // surface sits on a full-screen black 78% scrim.
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.78f)),
            )
            Column(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        // Same focus gate as the control stack: while
                        // a picker is open, nothing behind it is a
                        // focus-search candidate.
                        .focusProperties { canFocus = picker == PlayerPicker.NONE },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_error),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                )
                shownError?.takeIf { it.isNotBlank() }?.let { detail ->
                    Text(
                        text = detail,
                        style = MaterialTheme.typography.bodyMedium,
                        color = PlavioOnyx.TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = PlavioChrome.sidePad(64.dp)),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ControlButton(
                        icon = PlavioIcons.Restart,
                        label = stringResource(R.string.plavio_player_retry),
                        onClick = {
                            errorMessage = null
                            // A manual retry is a fresh load session:
                            // full retry budget, full stall deadline,
                            // and any pending automatic retry is
                            // cancelled so it can't fire into the
                            // user's own restart.
                            recoveryJob?.cancel()
                            autoRetryCount = 0
                            loadGen++
                            viewModel.retry(positionMs)
                        },
                        modifier = Modifier.focusRequester(retryFocus),
                    )
                    if (viewModel.nextStream() != null) {
                        ControlButton(
                            icon = PlavioIcons.SkipNext,
                            label = stringResource(R.string.plavio_player_next_source),
                            onClick = {
                                val next = viewModel.nextStream()
                                errorMessage = null
                                recoveryJob?.cancel()
                                autoRetryCount = 0
                                loadGen++
                                if (next != null) viewModel.switchStream(next, positionMs)
                            },
                        )
                    }
                    // The phone's third action: an accent TEXT
                    // button opening the sources panel.
                    Surface(
                        onClick = { picker = PlayerPicker.SOURCES },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = LocalPlavioAccent.current.primary,
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = LocalPlavioAccent.current.primary,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = LocalPlavioAccent.current.primary,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(50)),
                    ) {
                        Text(
                            text = stringResource(R.string.plavio_player_browse_sources),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
            }
            if (picker == PlayerPicker.SOURCES) {
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                )
            }
            // v0.3.19: the Sources button above used to be dead — it
            // set the picker, but the only Sources panel lived in the
            // control layer, which is un-composed while an error
            // shows. Compose the same panel here, above the error
            // actions; a pick clears the error and switches through
            // the same switchStream path as the panel in the control
            // layer (and as this layer's own Next-source button).
            if (picker == PlayerPicker.SOURCES) {
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                )
                PlayerSourcesPanel(
                    streams = displayRequest.streams,
                    currentUrl = displayRequest.streamUrl,
                    backdrop = displayRequest.backdrop ?: displayRequest.poster,
                    title = displayRequest.title,
                    onPick = { stream ->
                        errorMessage = null
                        // A manual pick supersedes any pending
                        // automatic retry (v0.3.17).
                        recoveryJob?.cancel()
                        autoRetryCount = 0
                        viewModel.switchStream(stream, positionMs)
                        picker = PlayerPicker.NONE
                        // A pick is a new start: fresh 30s clock.
                        sourcesAutoOpened = false
                        sourcesStartGen++
                    },
                    onReload = { viewModel.refreshStreams() },
                    modifier =
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 48.dp)
                                .width(640.dp)
                                .fillMaxHeight(0.92f),
                )
            }
        } else if (
            (activePlayer == null || (buffering && !reachedReady) ||
                (resumeBuffering && buffering)) && !showResumePrompt
        ) {
            // v0.3.13: the loading face of the player. v0.3.12 showed a
            // bare spinner on pure black for the whole start (6s+ on
            // the owner's TV read as a hang) — now the title's own art
            // + name + source are up from the first frame, and the
            // layer also covers the initial buffering stretch (and a
            // failover's, since reachedReady is keyed by stream URL)
            // until the first READY.
            PlayerLoadingLayer(
                request = displayRequest,
                // Staged loading line (v0.3.26): the status under
                // the title walks the same stages the phone's locked
                // loading look names — finding, picking, preparing —
                // derived from what the start has actually reached.
                stage =
                    playerLoadStage(
                        streamsKnown =
                            displayRequest.streamUrl.isNotBlank() ||
                                displayRequest.streams.isNotEmpty(),
                        hasPlayer = activePlayer != null,
                    ),
                modifier = Modifier.fillMaxSize(),
            )
            // v0.3.10: the control layer that normally hosts the
            // Sources panel is un-composed in this state (its gate
            // needs a first READY), so a hung start could never show
            // the panel the 30s auto-popup opens. The loading face
            // composes the same panel itself — exactly the error
            // layer's precedent above — with loading still running
            // behind it; a pick switches through the same path.
            if (picker == PlayerPicker.SOURCES) {
                PlayerSourcesPanel(
                    streams = displayRequest.streams,
                    currentUrl = displayRequest.streamUrl,
                    backdrop = displayRequest.backdrop ?: displayRequest.poster,
                    title = displayRequest.title,
                    onPick = { stream ->
                        errorMessage = null
                        // A manual pick supersedes any pending
                        // automatic retry (v0.3.17).
                        recoveryJob?.cancel()
                        autoRetryCount = 0
                        viewModel.switchStream(stream, positionMs)
                        picker = PlayerPicker.NONE
                        // A pick is a new start: fresh 30s clock.
                        sourcesAutoOpened = false
                        sourcesStartGen++
                    },
                    onReload = { viewModel.refreshStreams() },
                    modifier =
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 48.dp)
                                .width(640.dp)
                                .fillMaxHeight(0.92f),
                )
            }
        }

        // Recovery note (v0.3.12 shape, v0.3.17 method): while an
        // automatic same-source recovery runs, say so — the old behaviour was a silent spinner
        // that read as a hang. Non-focusable, auto-clears.
        if (failoverNote != null && shownError == null) {
            Box(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .padding(top = 120.dp)
                        .background(
                            Color(0xFF0B0B11),
                            RoundedCornerShape(12.dp),
                        ),
            ) {
                Text(
                    text = failoverNote ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                )
            }
        }

        // Resume prompt (phone parity): ask before starting when a
        // saved position exists; playback only begins on a choice.
        if (showResumePrompt) {
            val resumeFocus = remember { FocusRequester() }
            LaunchedEffect(Unit) { runCatching { resumeFocus.requestFocus() } }
            Column(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .width(440.dp)
                        .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                        .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                        .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_resume_playback),
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                )
                Text(
                    text =
                        stringResource(
                            R.string.plavio_player_resume_question,
                            displayRequest.title,
                            formatTime(resumePositionMs),
                        ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = PlavioOnyx.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ControlButton(
                        icon = Icons.Filled.PlayArrow,
                        label = stringResource(R.string.plavio_player_resume),
                        onClick = { resumeDecided = true },
                        modifier = Modifier.focusRequester(resumeFocus),
                    )
                    ControlButton(
                        icon = PlavioIcons.Restart,
                        label = stringResource(R.string.plavio_player_start_over),
                        onClick = {
                            viewModel.clearProgress()
                            startOver = true
                            resumeDecided = true
                        },
                    )
                }
            }
        }

        // v0.3.21 (study fix #4): the buffering spinner lives
        // OUTSIDE the control layer now — buffering alone no longer
        // composes the full control stack. While buffering with the
        // controls hidden, this spinner is the only thing composed
        // over the video; its visibility matches the old in-layer
        // spinner exactly (ready + buffering + no next-up card).
        if (activePlayer != null && shownError == null && reachedReady && buffering &&
            nextUpRequest == null && !resumeBuffering
        ) {
            OrbitLoader(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .size(64.dp),
                alwaysAnimate = true,
            )
        }

        // Subtitle download strip (v0.3.31, spec item 21 — the
        // phone's strip): while a picked subtitle is downloading,
        // this strip rides above the seek row — OUTSIDE the
        // auto-hiding controls, so it shows even with the controls
        // hidden — and clears the moment the subtitle renders
        // (the preparing signal drops). A failed pick pokes the
        // centre notice instead (the ViewModel's playerNotice).
        if (subtitleDownloading && shownError == null && !showResumePrompt &&
            picker != PlayerPicker.SUBTITLES
        ) {
            Column(
                modifier =
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 128.dp)
                        .widthIn(max = 340.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0B0B11))
                        .border(
                            1.dp,
                            Color(0xFFC7CCD6).copy(alpha = 0.30f),
                            RoundedCornerShape(12.dp),
                        )
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_loading_subtitles),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                )
                Box(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(50)),
                ) {
                    val stripTransition =
                        rememberInfiniteTransition(label = "subtitleStripProgress")
                    val stripSlide by stripTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 1f,
                        animationSpec =
                            infiniteRepeatable(
                                animation = tween(durationMillis = 1200, easing = LinearEasing),
                                repeatMode = RepeatMode.Restart,
                            ),
                        label = "subtitleStripSlide",
                    )
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val segmentWidth = maxWidth * 0.35f
                        Box(
                            modifier =
                                Modifier
                                    .offset(x = (maxWidth - segmentWidth) * stripSlide)
                                    .width(segmentWidth)
                                    .height(3.dp)
                                    .background(
                                        LocalPlavioAccent.current.primary,
                                        RoundedCornerShape(50),
                                    ),
                        )
                    }
                }
            }
        }

        // Control layer (v0.3.7): fully UN-COMPOSED when hidden —
        // the old alpha(0f) kept the full-screen scrims, seek bar and
        // buttons laid out and drawn over every video frame, plus a
        // 2 Hz recomposition tax. v0.3.21: the old `|| buffering`
        // exception is gone (see the spinner above) — buffering no
        // longer keeps this whole layer composed.
        if (activePlayer != null && shownError == null &&
            (reachedReady || !buffering) &&
            !(resumeBuffering && buffering) &&
            (controlsVisible || picker != PlayerPicker.NONE || nextUpRequest != null)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
            ) {
                // Subtitles on/off at a glance (v0.3.31, the
                // phone's dot + badge): a media subtitle selected
                // (the panel's own test), or a sidecar subtitle
                // active. Computed once here — the header's subs
                // badge and the pill's Subs dot both read it.
                val subsOn =
                    remember(activePlayer, tracksVersion, sidecarSubtitle) {
                        sidecarSubtitle != null ||
                            trackOptions(activePlayer, text = true)
                                .any { it.selected && !it.isOff }
                    }
                // Top bar (v0.3.31, the phone's arrangement — spec
                // §5.2 item 6; the v0.3.10 no-scrim rule stands):
                // the title directly on the video (bold, shadowed),
                // a meta line under it, and the badges row (quality
                // UPPERCASE / source / subs). The LIVE chip adopts
                // the phone's red. No right-side icon cluster —
                // Back is the remote's Back key (spec §6 omits the
                // phone's touch cluster).
                Column(
                    modifier =
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(horizontal = PlavioChrome.sidePad(48.dp), vertical = PlavioChrome.topPad(28.dp)),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = displayRequest.title,
                            style =
                                MaterialTheme.typography.titleLarge.copy(
                                    shadow =
                                        androidx.compose.ui.graphics.Shadow(
                                            Color.Black.copy(alpha = 0.65f),
                                            offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                                            blurRadius = 14f,
                                        ),
                                ),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (displayRequest.isLive) {
                            Box(
                                modifier =
                                    Modifier
                                        .background(Color(0xFFE5484D), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                            ) {
                                Text(
                                    text = stringResource(R.string.plavio_player_live_badge),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                )
                            }
                        }
                    }
                    // Meta line: the episode line (series) and/or
                    // the runtime, in the phone's form.
                    val metaLine =
                        listOfNotNull(
                            if (!displayRequest.isMovie && displayRequest.episode > 0) {
                                "S${displayRequest.season} E${displayRequest.episode}" +
                                    (displayRequest.episodeTitle?.let { " — $it" } ?: "")
                            } else {
                                null
                            },
                            formatLoadingRuntime(displayRequest.runtime),
                        ).joinToString(" · ")
                    if (metaLine.isNotBlank()) {
                        Text(
                            text = metaLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = PlavioOnyx.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    // Badges row: quality (UPPERCASE) / source /
                    // subs — the phone's PlayerBadge chips.
                    val qualityBadge = displayRequest.streamLabel?.takeIf { it.isNotBlank() }
                    if (qualityBadge != null || displayRequest.sourceName != null || subsOn) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (qualityBadge != null) {
                                PlayerBadge(qualityBadge.uppercase())
                            }
                            displayRequest.sourceName?.takeIf { it.isNotBlank() }?.let {
                                PlayerBadge(it)
                            }
                            if (subsOn) {
                                PlayerBadge(
                                    stringResource(R.string.plavio_player_subs).uppercase(),
                                )
                            }
                        }
                    }
                }
                (episodeError ?: downloadNotice ?: playerNotice)?.let { message ->
                    Box(
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .background(
                                    Color(0xFF0B0B11),
                                    RoundedCornerShape(12.dp),
                                ),
                    ) {
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                }

                // Sleep chip (v0.3.31, spec item 24): while the
                // sleep timer is armed, a small chip rides the top
                // centre and fades WITH the controls (it lives in
                // this layer). Purely informational — cancelling
                // stays in the Sleep menu; the Sleep button's own
                // countdown label stays as well.
                if (sleepDeadlineMs > 0L || sleepAtEpisodeEnd) {
                    Box(
                        modifier =
                            Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 84.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.Black.copy(alpha = 0.55f))
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text =
                                if (sleepAtEpisodeEnd) {
                                    stringResource(R.string.plavio_player_sleep_episode_short)
                                } else {
                                    stringResource(
                                        R.string.plavio_player_sleep_in,
                                        formatSleepRemaining(sleepRemainingSec),
                                    )
                                },
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White,
                        )
                    }
                }

                // Centre transport (v0.3.31, the phone's arrangement
                // — spec §5.2 item 7): bare shadow glyphs at the
                // screen's centre — skip-back / play-pause in its
                // light glass disc / skip-forward; for live, the
                // channel pair takes the skips' place (the zap
                // machinery itself is unchanged). Focus-gated
                // exactly like the bottom stack (the v0.3.19 trap):
                // while a picker is open this group leaves the
                // focus graph too.
                if (nextUpRequest == null) {
                    Row(
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .focusProperties { canFocus = picker == PlayerPicker.NONE }
                                .focusGroup(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(36.dp),
                    ) {
                        if (canZap) {
                            BareTransportButton(
                                icon = PlavioIcons.SkipPrevious,
                                glyphSize = 48.dp,
                                onClick = { zap(-1) },
                            )
                        } else if (!displayRequest.isLive) {
                            BareTransportButton(
                                icon = PlavioIcons.Rewind,
                                glyphSize = 56.dp,
                                onClick = { seekBy(-skipBackMs) },
                            )
                        }
                        CentrePlayButton(
                            isPlaying = isPlaying,
                            onClick = { togglePlay() },
                        )
                        if (canZap) {
                            BareTransportButton(
                                icon = PlavioIcons.SkipNext,
                                glyphSize = 48.dp,
                                onClick = { zap(1) },
                            )
                        } else if (!displayRequest.isLive) {
                            BareTransportButton(
                                icon = PlavioIcons.FastForward,
                                glyphSize = 56.dp,
                                onClick = { seekBy(skipForwardMs) },
                            )
                        }
                    }
                }

                // Bottom column (v0.3.31, the phone's arrangement —
                // spec §5.2 items 5/8; supersedes the v0.3.19 single
                // capsule that held everything): the seek row
                // floats BARE, and ONE fitted frost pill under it
                // carries the buttons in the phone's order — Aspect
                // (label = the current mode), Speed (label = the
                // current speed), Sleep, Subs, Audio, Sources,
                // Episodes — with TV's Download kept at the end
                // (TV-only, spec §5.9). The transport group and the
                // channel pair moved to the centre transport above;
                // the pill's separate Next-episode button is gone
                // (the Episodes panel and the next-episode surface
                // cover it). Focus lands on the seek bar when the
                // layer appears, as before, and the stack's focus
                // trap is the v0.3.19 one, unchanged.
                if (nextUpRequest == null) {
                    // v0.3.26: the seek bar's focus request, armed
                    // from INSIDE the layer — this Column composes
                    // exactly when the control layer is on screen
                    // with no next-up card, so the request fires at
                    // the first moment the seek bar exists, and
                    // again whenever the stack re-composes (the
                    // next-up card going away). The outer effect
                    // (keyed on the layer gate) covers the plain
                    // open/wake paths; this one cannot fire early,
                    // because an un-composed layer has no Column to
                    // run it. Guarded like the outer one: a picker
                    // owns focus while it is open (and this stack is
                    // out of the focus graph then anyway).
                    LaunchedEffect(Unit) {
                        if (picker == PlayerPicker.NONE && !showResumePrompt) {
                            runCatching { seekFocus.requestFocus() }
                        }
                    }
                    Column(
                        modifier =
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = PlavioChrome.sidePad(48.dp), vertical = PlavioChrome.bottomPad(18.dp))
                                // v0.3.19 FOCUS TRAP: while any picker
                                // popup is open, this whole control
                                // stack leaves the focus graph — D-pad
                                // navigation inside the popup can then
                                // never land on the controls sitting
                                // behind it (the owner's "it also goes
                                // back to the video player controls").
                                // The stack stays fully VISIBLE; only
                                // its focusability is gated. The popup's
                                // own subtree is a sibling of this
                                // Column, never a child, so the popup
                                // itself is unaffected.
                                .focusProperties { canFocus = picker == PlayerPicker.NONE }
                                .focusGroup()
                                .fillMaxWidth()
                                .widthIn(max = 880.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        SeekBar(
                            // v0.3.23: lambda-fed so the ticker's
                            // writes recompose only the seek bar,
                            // not this whole screen body.
                            positionMs = { positionMs },
                            durationMs = { durationMs },
                            bufferedMs = { bufferedMs },
                            isLive = displayRequest.isLive,
                            onSeekKey = { delta -> seekBy(delta) },
                            onTogglePlay = { togglePlay() },
                            skipForwardMs = skipForwardMs,
                            skipBackMs = skipBackMs,
                            focusRequester = seekFocus,
                            liveTitle = displayRequest.title,
                            liveStatus =
                                if (buffering) {
                                    stringResource(R.string.plavio_player_buffering)
                                } else {
                                    stringResource(R.string.plavio_player_on_air)
                                },
                        )
                        Spacer(Modifier.height(10.dp))
                        // The button pill: the phone's dock pure
                        // frost — black 50% tint, silver outline,
                        // radius 50 — fitted to its buttons.
                        Row(
                            modifier =
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.Black.copy(alpha = 0.50f))
                                    .border(
                                        1.dp,
                                        Color(0xFFC7CCD6).copy(alpha = 0.30f),
                                        RoundedCornerShape(50),
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            PlayerRowButton(
                                icon = PlavioIcons.Aspect,
                                label =
                                    stringResource(
                                        when (resizeMode) {
                                            AspectRatioFrameLayout.RESIZE_MODE_FILL ->
                                                R.string.plavio_player_aspect_fill
                                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM ->
                                                R.string.plavio_player_aspect_zoom
                                            else -> R.string.plavio_player_aspect_fit
                                        },
                                    ),
                                onClick = {
                                    resizeMode =
                                        when (resizeMode) {
                                            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                            AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        }
                                    playerViewRef?.resizeMode = resizeMode
                                    // Per-title memory (v0.3.26).
                                    viewModel.savePlayerResizeMode(request, resizeMode)
                                },
                            )
                            PlayerRowButton(
                                icon = PlavioIcons.Speed,
                                label = formatSpeed(speed),
                                onClick = { picker = PlayerPicker.SPEED },
                                modifier = Modifier.focusRequester(speedBtnFocus),
                            )
                            // Sleep timer (v0.3.26): the label
                            // counts down while a timed arm runs.
                            PlayerRowButton(
                                icon = PlavioIcons.Sleep,
                                label =
                                    when {
                                        sleepAtEpisodeEnd ->
                                            stringResource(R.string.plavio_player_sleep_episode_short)
                                        sleepDeadlineMs > 0L ->
                                            formatSleepRemaining(sleepRemainingSec)
                                        else ->
                                            stringResource(R.string.plavio_player_sleep)
                                    },
                                onClick = { picker = PlayerPicker.SLEEP },
                                modifier = Modifier.focusRequester(sleepBtnFocus),
                            )
                            PlayerRowButton(
                                icon = PlavioIcons.Subtitles,
                                label = stringResource(R.string.plavio_player_subs),
                                onClick = { picker = PlayerPicker.SUBTITLES },
                                modifier = Modifier.focusRequester(subtitlesBtnFocus),
                                showDot = subsOn,
                            )
                            PlayerRowButton(
                                icon = PlavioIcons.Audiotrack,
                                label = stringResource(R.string.plavio_player_audio),
                                onClick = { picker = PlayerPicker.AUDIO },
                                modifier = Modifier.focusRequester(audioBtnFocus),
                            )
                            PlayerRowButton(
                                icon = Icons.AutoMirrored.Filled.List,
                                label = stringResource(R.string.plavio_player_sources),
                                onClick = { picker = PlayerPicker.SOURCES },
                                modifier = Modifier.focusRequester(sourcesBtnFocus),
                            )
                            if (hasEpisodes && onPlayNextEpisode != null) {
                                PlayerRowButton(
                                    icon = PlavioIcons.PlaylistPlay,
                                    label = stringResource(R.string.plavio_player_episodes),
                                    onClick = { picker = PlayerPicker.EPISODES },
                                    modifier = Modifier.focusRequester(episodesBtnFocus),
                                )
                            }
                            // Download (v0.3.16 behaviour, unchanged):
                            // same engine the Streams screen feeds,
                            // fed from the playing request. VOD only —
                            // a live channel has nothing to save.
                            if (!displayRequest.isLive) {
                                val downloadStartedText =
                                    stringResource(R.string.plavio_player_download_started)
                                val downloadDashText =
                                    stringResource(R.string.plavio_player_download_dash)
                                PlayerRowButton(
                                    icon = PlavioIcons.Download,
                                    label = stringResource(R.string.plavio_download),
                                    onClick = {
                                        downloadNotice =
                                            when (
                                                viewModel.downloadCurrent(displayRequest)
                                            ) {
                                                PlavioPlayerViewModel.PlayerDownloadResult.STARTED ->
                                                    downloadStartedText
                                                PlavioPlayerViewModel.PlayerDownloadResult.DASH ->
                                                    downloadDashText
                                            }
                                    },
                                )
                            }
                        }
                    }
                }

                // Skip intro / recap / outro capsule (IntroDB, phone
                // placement: bottom-right above the controls). Takes
                // focus when it appears so it is one press away.
                val segment = activeSegment
                if (segment != null && picker == PlayerPicker.NONE && nextUpRequest == null) {
                    val skipFocus = remember { FocusRequester() }
                    LaunchedEffect(segment) {
                        if (controlsVisible) runCatching { skipFocus.requestFocus() }
                    }
                    ControlButton(
                        icon = PlavioIcons.FastForward,
                        label = segment.type.buttonLabel(),
                        onClick = {
                            val target = segment.endMs + 400
                            player?.seekTo(target)
                            positionMs = target
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                // v0.3.19: re-seated for the single
                                // capsule stack — the v0.3.16 lift
                                // to 312dp matched the old three-row
                                // stack and would leave this floating.
                                // v0.3.22: +14dp for the button row's
                                // new under-glyph labels.
                                .padding(end = 24.dp, bottom = 170.dp)
                                .focusRequester(skipFocus),
                    )
                }

                // Popup scrim (v0.3.31, spec item 13): every
                // player popup sits over a black 45% scrim. It is
                // a plain background box — never a focus target.
                if (picker != PlayerPicker.NONE) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.45f)),
                    )
                }

                // Audio track picker (single rail, like before) — now
                // with the phone's "Auto" row on top and the preferred
                // audio language at the bottom (its home is the player).
                if (picker == PlayerPicker.AUDIO) {
                    val autoLabel = stringResource(R.string.plavio_player_auto)
                    val options =
                        remember(activePlayer, tracksVersion, picker) {
                            val tracks = trackOptions(activePlayer, text = false)
                            val hasOverride =
                                runCatching {
                                    activePlayer.trackSelectionParameters.overrides.keys
                                        .any { it.type == C.TRACK_TYPE_AUDIO }
                                }.getOrDefault(false)
                            listOf(
                                TrackOption(
                                    label = autoLabel,
                                    group = null,
                                    trackIndex = -1,
                                    selected = !hasOverride,
                                    isAuto = true,
                                ),
                            ) + tracks
                        }
                    TrackPickerPanel(
                        title = stringResource(R.string.plavio_player_audio),
                        emptyText = stringResource(R.string.plavio_player_no_audio),
                        options = options,
                        onPick = { option ->
                            applyTrackOption(activePlayer, text = false, option)
                            // Per-title memory (v0.3.26): "Auto"
                            // clears the remembered pick.
                            viewModel.savePlayerAudioKey(
                                request,
                                if (option.isAuto) {
                                    null
                                } else {
                                    com.github.damontecres.wholphin.plavio.PlayerMemoryKeys
                                        .audioKey(option.formatId, option.language)
                                },
                            )
                            tracksVersion++
                            picker = PlayerPicker.NONE
                        },
                        footer = {
                            PanelFooterRow(
                                label =
                                    stringResource(R.string.plavio_settings_audio_lang) + " — " +
                                        (preferredAudioLanguage?.let { languageDisplayName(it) }
                                            ?: stringResource(R.string.plavio_settings_lang_none)),
                                onClick = { picker = PlayerPicker.AUDIO_PREF },
                            )
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 170.dp),
                    )
                }

                // Preferred audio language picker (from the Audio panel).
                if (picker == PlayerPicker.AUDIO_PREF) {
                    PreferredLanguagePanel(
                        title = stringResource(R.string.plavio_settings_audio_lang),
                        current = preferredAudioLanguage,
                        onPick = { code ->
                            viewModel.setPreferredAudioLanguage(code)
                            picker = PlayerPicker.NONE
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 48.dp, bottom = 170.dp),
                    )
                }

                // Playback speed panel (phone's 0.5×–2× set).
                if (picker == PlayerPicker.SPEED) {
                    SpeedPanel(
                        current = speed,
                        onPick = { picked ->
                            speed = picked
                            runCatching {
                                activePlayer.playbackParameters = PlaybackParameters(picked)
                            }
                            // Per-title memory (v0.3.26): the pick
                            // is this title's speed from now on.
                            viewModel.savePlayerSpeed(request, picked)
                            picker = PlayerPicker.NONE
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 170.dp),
                    )
                }

                // Sleep timer panel (v0.3.26, phone parity presets).
                if (picker == PlayerPicker.SLEEP) {
                    SleepTimerPanel(
                        currentPreset = sleepPreset,
                        episodeEndArmed = sleepAtEpisodeEnd,
                        onPick = { minutes ->
                            if (minutes <= 0) {
                                sleepPreset = 0
                                sleepDeadlineMs = 0L
                                sleepAtEpisodeEnd = false
                                sleepRemainingSec = 0
                            } else {
                                sleepPreset = minutes
                                sleepAtEpisodeEnd = false
                                sleepDeadlineMs =
                                    System.currentTimeMillis() + minutes * 60_000L
                                sleepRemainingSec = minutes * 60
                            }
                            picker = PlayerPicker.NONE
                        },
                        onPickEpisodeEnd = {
                            sleepPreset = 0
                            sleepDeadlineMs = 0L
                            sleepRemainingSec = 0
                            sleepAtEpisodeEnd = true
                            picker = PlayerPicker.NONE
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = 170.dp),
                    )
                }

                // Episodes picker
                if (picker == PlayerPicker.EPISODES) {
                    EpisodesPanel(
                        episodes = request.episodes,
                        currentVideoId = request.videoId,
                        onPick = { video ->
                            picker = PlayerPicker.NONE
                            playEpisode(video)
                        },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }

                // Sources panel (v0.3.18): an overlay INSIDE the player —
                // picking a row switches the playing source through the
                // ViewModel's position-keeping switchStream path; the
                // player screen never leaves composition and playback is
                // not torn down. (The old capsule navigated away to the
                // Streams destination, replacing the Play entry.)
                if (picker == PlayerPicker.SOURCES) {
                    PlayerSourcesPanel(
                        streams = displayRequest.streams,
                        currentUrl = displayRequest.streamUrl,
                        backdrop = displayRequest.backdrop ?: displayRequest.poster,
                        title = displayRequest.title,
                        onPick = { stream ->
                            errorMessage = null
                            // A manual pick supersedes any pending
                            // automatic retry (v0.3.17).
                            recoveryJob?.cancel()
                            autoRetryCount = 0
                            viewModel.switchStream(stream, positionMs)
                            picker = PlayerPicker.NONE
                            // A pick is a new start: fresh 30s clock.
                            sourcesAutoOpened = false
                            sourcesStartGen++
                        },
                        onReload = { viewModel.refreshStreams() },
                        modifier =
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 48.dp)
                                .width(640.dp)
                                .fillMaxHeight(0.92f),
                    )
                }

                // Subtitle panel (v0.3.16: Sample B bottom strip —
                // see PlavioSubtitlePanel)
                if (picker == PlayerPicker.SUBTITLES) {
                    val textOptions =
                        remember(activePlayer, tracksVersion, localSubtitles) {
                            trackOptions(activePlayer, text = true)
                        }
                    // v0.3.18 rows: Off + one row per ADDON subtitle
                    // (from the live request — addon subtitles no
                    // longer ride the media item, so most have no
                    // player track at all; the old rows were built
                    // from the track list alone, which is why a
                    // broken track meant a broken panel) + the
                    // player's EMBEDDED text tracks. An addon row's
                    // option carries its "e:<index>" id and, when a
                    // libass media track exists for it, that track's
                    // group/index; pickSubtitleRow below routes the
                    // pick: sidecar for everything except libass ASS
                    // on its media track.
                    val addonSubs = displayRequest.subtitles
                    val embeddedOptions =
                        textOptions.filter { option ->
                            !option.isOff && option.formatId?.startsWith("e:") != true
                        }
                    val mediaOptionByIndex =
                        textOptions
                            .filter { !it.isOff }
                            .mapNotNull { option ->
                                option.formatId
                                    ?.takeIf { it.startsWith("e:") }
                                    ?.removePrefix("e:")
                                    ?.toIntOrNull()
                                    ?.let { it to option }
                            }.toMap()
                    // v0.3.21 (study fix #1): a libass pick that
                    // rebuilt the player applies its media track as
                    // soon as the rebuilt player's tracks land.
                    val pendingLibass by viewModel.pendingLibassSubtitle.collectAsState()
                    LaunchedEffect(activePlayer, textOptions, pendingLibass) {
                        val pending = pendingLibass ?: return@LaunchedEffect
                        val index = addonSubs.indexOfFirst { it.url == pending.url }
                        if (index < 0) {
                            viewModel.clearPendingLibassSubtitle()
                            return@LaunchedEffect
                        }
                        val option = mediaOptionByIndex[index]
                        if (option?.group != null) {
                            viewModel.stopSidecar()
                            applyTrackOption(activePlayer, text = true, option)
                            tracksVersion++
                            viewModel.clearPendingLibassSubtitle()
                        }
                    }
                    val offOption =
                        textOptions.firstOrNull { it.isOff }
                            ?: TrackOption(
                                label = "Off",
                                group = null,
                                trackIndex = -1,
                                selected = false,
                                isOff = true,
                            )
                    val languages =
                        remember(addonSubs, textOptions, subtitleLanguages) {
                            val present =
                                (
                                    addonSubs.map { it.lang } +
                                        embeddedOptions.mapNotNull { it.language }
                                    )
                                    .filter { it.isNotBlank() && it != "und" }
                                    .distinct()
                            val preferred = subtitleLanguages.filter { it in present }
                            preferred + present.filter { it !in preferred }
                        }
                    val rows =
                        buildList {
                            add(
                                SubtitleRow(
                                    option =
                                        offOption.copy(
                                            // The sidecar disables the
                                            // media text type too, so
                                            // "disabled" alone does not
                                            // mean Off any more.
                                            selected =
                                                offOption.selected && sidecarSubtitle == null,
                                        ),
                                    title = offOption.label,
                                    source = null,
                                ),
                            )
                            addonSubs.forEachIndexed { index, sub ->
                                val mediaOption = mediaOptionByIndex[index]
                                val selected =
                                    if (viewModel.sidecarEligible(sub)) {
                                        sidecarSubtitle?.url == sub.url
                                    } else {
                                        mediaOption?.selected == true
                                    }
                                add(
                                    SubtitleRow(
                                        option =
                                            TrackOption(
                                                label = languageDisplayName(sub.lang),
                                                group = mediaOption?.group,
                                                trackIndex = mediaOption?.trackIndex ?: -1,
                                                selected = selected,
                                                language = sub.lang,
                                                formatId = "e:$index",
                                                forced = mediaOption?.forced ?: false,
                                            ),
                                        title = languageDisplayName(sub.lang),
                                        source = subtitleHost(sub.url),
                                        format =
                                            sub.url
                                                .substringBefore('?')
                                                .substringAfterLast('.', "")
                                                .uppercase()
                                                .takeIf {
                                                    it in setOf("SRT", "VTT", "ASS", "SSA", "SUB")
                                                },
                                    ),
                                )
                            }
                            embeddedOptions.forEach { option ->
                                add(
                                    SubtitleRow(
                                        option = option,
                                        title = option.label,
                                        source = stringResource(R.string.plavio_sub_embedded),
                                    ),
                                )
                            }
                        }
                    fun pickSubtitleRow(row: SubtitleRow) {
                        val option = row.option
                        val addonIndex =
                            option.formatId
                                ?.takeIf { it.startsWith("e:") }
                                ?.removePrefix("e:")
                                ?.toIntOrNull()
                        val sub = addonIndex?.let { addonSubs.getOrNull(it) }
                        // v0.3.21: any pick that is not itself a
                        // libass rebuild abandons a pending one.
                        if (sub == null || !viewModel.needsLibassForPick(sub)) {
                            viewModel.clearPendingLibassSubtitle()
                        }
                        when {
                            option.isOff -> {
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                            sub != null && viewModel.needsLibassForPick(sub) -> {
                                // v0.3.21 (study fix #1): an ASS/SSA
                                // pick on a player built without
                                // libass (start() builds it on pick
                                // only now) — rebuild with libass at
                                // the current position; the pending
                                // pick applies itself when the new
                                // player's tracks land (effect above).
                                viewModel.rebuildWithLibassFor(sub, positionMs)
                            }
                            sub != null && viewModel.sidecarEligible(sub) -> {
                                viewModel.selectSidecarSubtitle(sub)
                            }
                            sub != null && option.group != null -> {
                                // libass ASS on its media track.
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                            sub != null -> {
                                // No media track and not
                                // sidecar-eligible (defensive — the
                                // eligibility sweep covers every
                                // non-libass format): the sidecar
                                // attempt is the best route left.
                                viewModel.selectSidecarSubtitle(sub)
                            }
                            else -> {
                                // Embedded track.
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                        }
                        // Per-title memory (v0.3.26): remember the
                        // pick — Off, the addon file's URL, or the
                        // embedded track's identity.
                        viewModel.savePlayerSubtitleKey(
                            request,
                            when {
                                option.isOff ->
                                    com.github.damontecres.wholphin.plavio.PlayerMemoryKeys
                                        .SUBTITLE_OFF
                                sub != null ->
                                    com.github.damontecres.wholphin.plavio.PlayerMemoryKeys
                                        .subtitleAddonKey(sub.url)
                                else ->
                                    com.github.damontecres.wholphin.plavio.PlayerMemoryKeys
                                        .subtitleEmbeddedKey(option.formatId, option.language)
                            },
                        )
                        tracksVersion++
                    }
                    val selectedOption = rows.firstOrNull { it.option.selected }?.option
                    val selectedSub =
                        when {
                            sidecarSubtitle != null -> sidecarSubtitle
                            else ->
                                selectedOption?.formatId
                                    ?.takeIf { it.startsWith("e:") }
                                    ?.removePrefix("e:")
                                    ?.toIntOrNull()
                                    ?.let { addonSubs.getOrNull(it) }
                        }
                    val selectedLocal =
                        selectedSub?.let { sub ->
                            localSubtitles.firstOrNull { it.sub.url == sub.url }
                        }
                    val downloadingFormatId =
                        run {
                            val pending = pendingLibass
                            val sidecar = sidecarSubtitle
                            when {
                                pending != null ->
                                    addonSubs.indexOfFirst { it.url == pending.url }
                                        .takeIf { it >= 0 }?.let { "e:$it" }
                                subtitlePreparing && sidecar != null ->
                                    addonSubs.indexOfFirst { it.url == sidecar.url }
                                        .takeIf { it >= 0 }?.let { "e:$it" }
                                else -> null
                            }
                        }
                    PlavioSubtitlePanel(
                        languages = languages,
                        selectedLanguage = selectedOption?.language,
                        onSelectLanguage = { code ->
                            // The Languages rail routes through the
                            // same pick as the track rows (v0.3.18):
                            // first row of that language, sidecar
                            // included.
                            if (code == null) {
                                rows.firstOrNull { it.option.isOff }?.let { pickSubtitleRow(it) }
                            } else {
                                rows
                                    .firstOrNull { !it.option.isOff && it.option.language == code }
                                    ?.let { pickSubtitleRow(it) }
                            }
                        },
                        rows = rows,
                        onPickRow = { row -> pickSubtitleRow(row) },
                        style = subtitleStyle,
                        onStyleChange = { style -> viewModel.updateSubtitleStyle { style } },
                        delayMs = subtitleDelayMs,
                        delayEnabled = selectedLocal != null,
                        onDelayChange = { viewModel.setSubtitleDelay(it) },
                        onReloadSubtitles = { viewModel.reloadSubtitles() },
                        onCaptureCues = {
                            val at = viewModel.currentPositionMs()
                            val cues =
                                selectedLocal?.let { viewModel.captureCues(it) }
                                    ?: emptyList()
                            at to cues
                        },
                        onCuePicked = { capturedAtMs, cueStartMs ->
                            // The phone's rule: the heard line should
                            // have started 300ms before the tap.
                            viewModel.setSubtitleDelay(capturedAtMs - cueStartMs - 300)
                        },
                        onResetDefaults = { viewModel.resetSubtitleStyle() },
                        preferredLanguages = subtitleLanguages,
                        onPreferredLanguagesChange = { viewModel.setSubtitleLanguages(it) },
                        onFetchOnlineSubtitles = { viewModel.fetchOnlineSubtitles() },
                        onAttachOnlineSubtitle = { viewModel.attachOnlineSubtitle(it) },
                        downloadingFormatId = downloadingFormatId,
                        onClose = { picker = PlayerPicker.NONE },
                        modifier =
                            Modifier
                                // v0.3.31 (spec §5.4 item 17): the
                                // stepped card docks LEFT, vertically
                                // centred — the phone's placement —
                                // with the video playing behind it
                                // and style edits previewing live on
                                // the captions.
                                .align(Alignment.CenterStart)
                                .padding(start = 48.dp)
                                .width(460.dp)
                                .fillMaxHeight(0.92f),
                    )
                }

                // Next-episode pill (v0.3.31: bottom-centre, the
                // phone's surface — see NextEpisodePill)
                val upNext = nextUpRequest
                if (upNext != null && nextUpVideo != null) {
                    NextEpisodePill(
                        video = nextUpVideo!!,
                        seriesName = request.seriesName ?: request.title,
                        secondsLeft = nextUpSeconds,
                        demoted = nextUpDemoted,
                        onPlayNow = { onPlayNextEpisode?.invoke(upNext) },
                        onDemote = { nextUpDemoted = true },
                        onDismiss = { nextUpRequest = null },
                        grabFocus = picker == PlayerPicker.NONE,
                        modifier =
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 120.dp)
                                // v0.3.19: same trap as the control
                                // stack — while a picker popup is open
                                // the next-up card is not a focus
                                // target either (and its focus grab
                                // below is ignored while gated), so a
                                // countdown ending mid-popup cannot
                                // pull focus out of the popup.
                                .focusProperties { canFocus = picker == PlayerPicker.NONE }
                                .focusGroup(),
                    )
                }
            }
        }
    }
}

/** The Typeface for a [com.github.damontecres.wholphin.plavio.SubtitleFont] family. */
private fun subtitleFontTypeface(fontFamily: Int): Typeface =
    when (fontFamily) {
        com.github.damontecres.wholphin.plavio.SubtitleFont.SANS -> Typeface.SANS_SERIF
        com.github.damontecres.wholphin.plavio.SubtitleFont.SERIF -> Typeface.SERIF
        com.github.damontecres.wholphin.plavio.SubtitleFont.MONO -> Typeface.MONOSPACE
        else -> Typeface.DEFAULT
    }

/** Applies the shared subtitle style to the ExoPlayer subtitle view, live. */
@OptIn(UnstableApi::class)
private fun applySubtitleStyle(
    playerView: PlayerView,
    style: SubtitleStyle,
) {
    val subtitleView = playerView.subtitleView ?: return
    subtitleView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, style.fontSizeSp.toFloat())
    subtitleView.setStyle(
        CaptionStyleCompat(
            style.textColorArgb,
            // v0.3.22: the caption background is the user's style
            // choice now (colour + opacity; opacity 0 keeps the
            // historic no-box look). The window colour stays clear.
            style.backgroundColorArgb,
            AndroidColor.TRANSPARENT,
            // v0.3.22: the full edge set (none / outline / drop
            // shadow / raised / depressed), not just outline on/off.
            // SubtitleEdge mirrors these CaptionStyleCompat values.
            when (style.edgeType) {
                com.github.damontecres.wholphin.plavio.SubtitleEdge.NONE ->
                    CaptionStyleCompat.EDGE_TYPE_NONE
                com.github.damontecres.wholphin.plavio.SubtitleEdge.DROP_SHADOW ->
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                com.github.damontecres.wholphin.plavio.SubtitleEdge.RAISED ->
                    CaptionStyleCompat.EDGE_TYPE_RAISED
                com.github.damontecres.wholphin.plavio.SubtitleEdge.DEPRESSED ->
                    CaptionStyleCompat.EDGE_TYPE_DEPRESSED
                else -> CaptionStyleCompat.EDGE_TYPE_OUTLINE
            },
            style.outlineColorArgb,
            // v0.3.31: the stepped card's FONT chips — the family
            // comes from the style store; bold composes on top.
            if (style.bold) {
                Typeface.create(subtitleFontTypeface(style.fontFamily), Typeface.BOLD)
            } else {
                subtitleFontTypeface(style.fontFamily)
            },
        ),
    )
    subtitleView.setApplyEmbeddedStyles(false)
    // v0.3.18: the base bottom fraction is the reference player's
    // 0.06 (ours was two thirds of SubtitleView's 0.0533 default
    // ≈ 0.0355, which sat the captions lower than the reference's);
    // the user's Position offset still adds on top.
    val fraction =
        (0.06f + style.bottomOffset / 1000f).coerceIn(0f, 0.35f)
    subtitleView.setBottomPaddingFraction(fraction)
}

/** Display host for an addon subtitle URL ("Addon" when it doesn't parse). */
private fun subtitleHost(url: String): String? =
    runCatching { java.net.URI(url).host }
        .getOrNull()
        ?.removePrefix("www.")
        ?.takeIf { it.isNotBlank() }

@Composable
private fun NextEpisodePill(
    video: Video,
    seriesName: String,
    secondsLeft: Int,
    demoted: Boolean,
    onPlayNow: () -> Unit,
    onDemote: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    // False while a picker popup is open (the pill is focus-gated
    // then — see the call site). Keyed into the grab effect so the
    // pill takes focus when the popup closes over it, not just
    // when it first composes.
    grabFocus: Boolean = true,
) {
    val playFocus = remember { FocusRequester() }
    // The countdown form grabs focus on its Play action (as the
    // card did); the demoted suggestion NEVER steals focus
    // (spec §5.6 item 25).
    LaunchedEffect(grabFocus, demoted) {
        if (grabFocus && !demoted) runCatching { playFocus.requestFocus() }
    }
    val episodeLine =
        "S${video.season} E${video.episode}" +
            (video.title?.let { " — $it" } ?: "")
    // v0.3.31 (spec §5.6 item 25, the phone's surface): a
    // bottom-centre pill, black 78%, radius 24 — not the old
    // bottom-end card. Countdown form: "Next episode in Ns —
    // <title>" + Cancel; cancelling DEMOTES to the standing
    // suggestion form (Play + ✕) instead of dismissing outright.
    Row(
        modifier =
            modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color.Black.copy(alpha = 0.78f))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(24.dp))
                .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (!demoted) {
            Text(
                text =
                    stringResource(
                        R.string.plavio_next_episode_in,
                        secondsLeft,
                        episodeLine,
                    ),
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            ControlButton(
                icon = Icons.Filled.PlayArrow,
                label = stringResource(R.string.plavio_play_now),
                onClick = onPlayNow,
                modifier = Modifier.focusRequester(playFocus),
            )
            ControlButton(
                icon = Icons.Filled.Close,
                label = stringResource(R.string.plavio_cancel),
                onClick = onDemote,
            )
        } else {
            Text(
                text = episodeLine,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            ControlButton(
                icon = Icons.Filled.PlayArrow,
                label = stringResource(R.string.plavio_play_now),
                onClick = onPlayNow,
            )
            Surface(
                onClick = onDismiss,
                shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
                scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                colors =
                    ClickableSurfaceDefaults.colors(
                        containerColor = Color.Transparent,
                        contentColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        focusedContentColor = Color.White,
                        pressedContainerColor = Color.Transparent,
                        pressedContentColor = Color.White,
                    ),
                border = plavioRowFocusBorder(CircleShape),
            ) {
                Box(
                    modifier = Modifier.size(40.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun EpisodesPanel(
    episodes: List<Video>,
    currentVideoId: String,
    onPick: (Video) -> Unit,
    modifier: Modifier = Modifier,
) {
    val sorted = remember(episodes) { episodes.sortedWith(compareBy({ it.season }, { it.episode })) }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    // v0.3.31 (spec §5.3 item 16, the phone's form): season filter
    // chips on top (season 0 reads "Specials"), episode rows with
    // 64×44 stills and a 1-line overview, the current episode on an
    // accent wash with the accent play glyph. The chip row sits
    // above the list in D-pad travel; focus still lands on the
    // current episode, and the list opens on its season.
    val seasons = remember(sorted) { sorted.map { it.season }.distinct() }
    val currentSeason =
        remember(sorted, currentVideoId) {
            sorted.firstOrNull { it.id == currentVideoId }?.season ?: seasons.firstOrNull()
        }
    var seasonFilter by remember(sorted) { mutableStateOf<Int?>(null) }
    val activeSeason = seasonFilter ?: currentSeason
    val visible =
        remember(sorted, activeSeason) {
            if (activeSeason == null) sorted else sorted.filter { it.season == activeSeason }
        }
    Column(
        modifier =
            modifier
                .width(440.dp)
                .padding(end = 48.dp)
                .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_episodes),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        if (seasons.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(seasons) { season ->
                    SourceFilterChip(
                        text =
                            if (season == 0) {
                                stringResource(R.string.plavio_player_specials)
                            } else {
                                "S$season"
                            },
                        selected = activeSeason == season,
                        onClick = { seasonFilter = season },
                    )
                }
            }
        }
        LazyColumn(
            modifier = Modifier.fillMaxWidth().height(420.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            itemsIndexed(
                visible,
                key = { index, video -> "${video.id}|$index" },
            ) { _, video ->
                val isCurrent = video.id == currentVideoId
                val accent = LocalPlavioAccent.current.primary
                Surface(
                    onClick = { onPick(video) },
                    modifier =
                        if (isCurrent) Modifier.focusRequester(firstFocus) else Modifier,
                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                    colors =
                        ClickableSurfaceDefaults.colors(
                            containerColor =
                                if (isCurrent) accent.copy(alpha = 0.14f) else Color.Transparent,
                            contentColor = Color.White,
                            focusedContainerColor =
                                if (isCurrent) accent.copy(alpha = 0.14f) else Color.Transparent,
                            focusedContentColor = Color.White,
                            pressedContainerColor =
                                if (isCurrent) accent.copy(alpha = 0.14f) else Color.Transparent,
                            pressedContentColor = Color.White,
                        ),
                    border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        if (video.thumbnail != null) {
                            AsyncImage(
                                model = video.thumbnail,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier =
                                    Modifier
                                        .size(width = 64.dp, height = 44.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text =
                                    "${video.episode}. " +
                                        (video.title ?: ""),
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            video.overview?.takeIf { it.isNotBlank() }?.let { overview ->
                                Text(
                                    text = overview,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PlavioOnyx.TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        if (isCurrent) {
                            Icon(
                                Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * The player's loading face (v0.3.13): the title's backdrop (poster
 * as fallback) under a scrim, with the source line, the title and
 * the spinner — composed from the first frame of a start, so a slow
 * stream never presents as a pure-black void. The recovery-ladder
 * note composes on top of this layer while a failover runs.
 */
/** The player loading layer's stages, in the order a start walks them. */
enum class PlayerLoadStage {
    FINDING_STREAMS,
    PICKING_QUALITY,
    PREPARING,
}

/**
 * Which stage a start is in (pure, unit-tested): streams not found
 * yet → finding; streams known but no player built → picking the
 * best quality / building; a player exists and is buffering its
 * first frame → preparing.
 */
fun playerLoadStage(
    streamsKnown: Boolean,
    hasPlayer: Boolean,
): PlayerLoadStage =
    when {
        !streamsKnown -> PlayerLoadStage.FINDING_STREAMS
        !hasPlayer -> PlayerLoadStage.PICKING_QUALITY
        else -> PlayerLoadStage.PREPARING
    }

/** "m:ss" for the sleep button's countdown label. */
fun formatSleepRemaining(totalSeconds: Int): String {
    val s = totalSeconds.coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

// ---------------------------------------------------------------------------
// The loading face (v0.3.31 — the phone player's locked loading look,
// "Poster Heartbeat + Status Line", mirrored on the owner's order
// "same to same"): static backdrop under the Onyx grades, the title
// NAME (logo art bare, styled text as fallback) breathing at the
// DEAD CENTRE on the lub-dub heartbeat, and a bottom-centre group —
// the quiet status line ("Finding streams…" → "Picking best
// quality…" → the picked "Source · Quality"), the fixed-width
// capsule carrying ONLY the rotating "Starring …" cast line, and
// the details line (year · runtime · genres · ★ rating) under it.
// No spinner, no progress bar, no elapsed counter — the phone's
// design, whole. This layer still composes only where it did
// before (a start that has not reached its first READY, and a
// failover's restart of that stretch); mid-playback rebuffering
// keeps its plain spinner, and the focus machinery is untouched —
// nothing in this layer is focusable.
// ---------------------------------------------------------------------------

/** Heartbeat cycle (the phone's pinned value): H1's 2 s lub-dub stretched ×1.6 to a calm 3.2 s. */
private const val LOADING_HEARTBEAT_CYCLE_MS = 3200

/** Heartbeat keyframes (timeMs in cycle → scale) — the phone's table, verbatim. */
private val LOADING_HEARTBEAT_KEYFRAMES: List<Pair<Int, Float>> =
    listOf(
        0 to 1.000f,
        224 to 1.028f,
        416 to 1.010f,
        704 to 1.040f,
        1088 to 1.006f,
        1408 to 1.000f,
        LOADING_HEARTBEAT_CYCLE_MS to 1.000f,
    )

/** The loading capsule's fixed width (the phone's pinned value — it never hugs its text). */
private const val LOADING_CAPSULE_WIDTH_DP = 280

/** The bottom-centre group's lift off the player's bottom edge (the phone's pinned value). */
private const val LOADING_CAPSULE_BOTTOM_PADDING_DP = 56

/** How long each cast name rests before the next (the phone's pinned value). */
private const val LOADING_CAST_ROTATE_MS = 2200L

/** The cast rotation never runs past the top-billed few (the phone's cap). */
private const val LOADING_CAST_MAX = 6

/** The loading logo's height / widest reach (the heroes' language, the phone's pinned values). */
private const val LOADING_LOGO_HEIGHT_DP = 76
private const val LOADING_LOGO_MAX_WIDTH_DP = 300

/** "148 min" → "2h 28m"; "45 min" stays; anything unrecognised passes through (the phone's formatter). */
private fun formatLoadingRuntime(runtime: String?): String? {
    val raw = runtime?.trim()?.takeIf { it.isNotBlank() } ?: return null
    val minutes =
        Regex("""^(\d+)\s*min""").find(raw)?.groupValues?.get(1)?.toIntOrNull()
            ?: return raw
    return if (minutes >= 60) {
        val h = minutes / 60
        val m = minutes % 60
        if (m > 0) "${h}h ${m}m" else "${h}h"
    } else {
        "$minutes min"
    }
}

/**
 * The quiet details line: year · runtime · top genres · ★ rating,
 * built ONLY from fields the request actually carried — a missing
 * field simply doesn't render, and with nothing at all the line
 * itself is absent (the phone's rule).
 */
private fun playerLoadingMetaLine(request: PlaybackRequest): String? {
    val parts = mutableListOf<String>()
    request.releaseInfo?.let { info ->
        Regex("""\d{4}""").find(info)?.value?.let { parts += it }
    }
    formatLoadingRuntime(request.runtime)?.let { parts += it }
    request.genres.map { it.trim() }.filter { it.isNotBlank() }.take(2).forEach { parts += it }
    request.imdbRating?.trim()?.takeIf { it.isNotBlank() }?.let { parts += "★ $it" }
    return parts.takeIf { it.isNotEmpty() }?.joinToString(" · ")
}

/** The rotating "Starring …" line at [elapsedMs], or null when the title carried no cast. */
private fun playerLoadingCastLine(
    cast: List<String>,
    elapsedMs: Long,
): String? {
    val names =
        cast.map { it.trim() }.filter { it.isNotBlank() }.take(LOADING_CAST_MAX)
    if (names.isEmpty()) return null
    val index = (elapsedMs.coerceAtLeast(0L) / LOADING_CAST_ROTATE_MS).toInt() % names.size
    return "Starring ${names[index]}"
}

@Composable
private fun PlayerLoadingLayer(
    request: PlaybackRequest,
    stage: PlayerLoadStage = PlayerLoadStage.PREPARING,
    modifier: Modifier = Modifier,
) {
    val onyx = Color(0xFF070707)

    // The heartbeat: the phone's lub-dub keyframes, rises attacking
    // expo-out, falls easing away — riding the NAME, never the art.
    val beatTransition = rememberInfiniteTransition(label = "playerLoadingHeartbeat")
    val riseEasing = remember { CubicBezierEasing(0.16f, 1f, 0.3f, 1f) }
    val fallEasing = remember { CubicBezierEasing(0.4f, 0f, 0.2f, 1f) }
    val beatScale by beatTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec =
            infiniteRepeatable(
                animation =
                    keyframes {
                        durationMillis = LOADING_HEARTBEAT_CYCLE_MS
                        LOADING_HEARTBEAT_KEYFRAMES.forEachIndexed { index, (timeMs, scale) ->
                            if (index == LOADING_HEARTBEAT_KEYFRAMES.lastIndex) {
                                scale at timeMs
                            } else if (LOADING_HEARTBEAT_KEYFRAMES[index + 1].second > scale) {
                                scale at timeMs with riseEasing
                            } else {
                                scale at timeMs with fallEasing
                            }
                        }
                    },
                repeatMode = RepeatMode.Restart,
            ),
        label = "playerLoadingHeartbeatScale",
    )

    // Live elapsed wait — drives the cast rotation; restarts each
    // time this layer composes (a fresh start).
    var elapsedMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val startMs = SystemClock.elapsedRealtime()
        while (true) {
            elapsedMs = SystemClock.elapsedRealtime() - startMs
            delay(50)
        }
    }

    // The quiet line: the wait's real stage word until a stream is
    // truly picked — a pick counts only once the request carries
    // its stream — then the picked source + quality takes over.
    val pickedLine =
        if (request.streamUrl.isNotBlank()) {
            listOfNotNull(request.sourceName, request.streamLabel)
                .joinToString(" · ")
                .takeIf { it.isNotBlank() }
        } else {
            null
        }
    val infoLine =
        pickedLine
            ?: stringResource(
                when (stage) {
                    PlayerLoadStage.FINDING_STREAMS -> R.string.plavio_player_stage_finding
                    PlayerLoadStage.PICKING_QUALITY -> R.string.plavio_player_stage_picking
                    PlayerLoadStage.PREPARING -> R.string.plavio_player_stage_preparing
                },
            )
    val castLine = playerLoadingCastLine(request.castNames, elapsedMs)
    val metaLine = playerLoadingMetaLine(request)

    Box(modifier = modifier.background(onyx)) {
        val art = request.backdrop ?: request.poster
        if (art != null) {
            // STATIC art — the heartbeat rides the name below.
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalContext.current)
                        .data(art)
                        .size(1280, 720)
                        .crossfade(false)
                        .build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        // The Onyx grades (the phone sample's two gradients).
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0f to onyx.copy(alpha = 0.42f),
                        0.55f to Color.Transparent,
                    ),
                ),
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to onyx.copy(alpha = 0.50f),
                        0.42f to onyx.copy(alpha = 0.14f),
                        1f to onyx.copy(alpha = 0.68f),
                    ),
                ),
        )

        // The name block at the DEAD CENTRE: the title logo bare
        // (no wash, shade or panel — the heroes' treatment), the
        // styled title text as fallback, breathing with the beat.
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier =
                Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .widthIn(max = 560.dp),
        ) {
            LoadingTitleName(
                title = request.title,
                logo = request.logo,
                beatScale = beatScale,
            )
        }

        // The bottom-centre group: the quiet status line, the
        // details-only capsule, the details line under it — lifted
        // off the edge by the one pinned padding.
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier =
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = LOADING_CAPSULE_BOTTOM_PADDING_DP.dp),
        ) {
            Crossfade(
                targetState = infoLine,
                animationSpec = tween(durationMillis = 350),
                label = "playerLoadingInfoLine",
            ) { line ->
                Text(
                    line,
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (castLine != null) {
                Spacer(Modifier.height(8.dp))
                // The capsule carries DETAILS ONLY (the phone's
                // completed design): the rotating "Starring …"
                // line, centred in a FIXED-width frosted pill. No
                // cast on the request — no capsule at all.
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier =
                        Modifier
                            .width(LOADING_CAPSULE_WIDTH_DP.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.White.copy(alpha = 0.07f))
                            .border(
                                1.dp,
                                Color.White.copy(alpha = 0.14f),
                                RoundedCornerShape(50),
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Crossfade(
                        targetState = castLine,
                        animationSpec = tween(durationMillis = 350),
                        label = "playerLoadingCapsuleCast",
                        modifier = Modifier.fillMaxWidth(),
                    ) { line ->
                        Text(
                            line,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            // The details line: horizontally centred, directly
            // UNDER the capsule — the dark grade at the poster's
            // bottom edge keeps it readable.
            if (metaLine != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    metaLine,
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/**
 * The loading face's title name: the title LOGO rendered BARE — a
 * plain image with no wash, shade or panel behind it, the exact
 * treatment of the Home/Details heroes — when the request carries
 * one and its load has not failed; the styled title text otherwise
 * (including on logo load failure). Whichever form shows, the NAME
 * breathes with the heartbeat; the backdrop stays static.
 */
@Composable
private fun LoadingTitleName(
    title: String,
    logo: String?,
    beatScale: Float,
) {
    var logoFailed by remember(logo) { mutableStateOf(false) }
    val breathing =
        Modifier.graphicsLayer {
            scaleX = beatScale
            scaleY = beatScale
        }
    if (!logo.isNullOrBlank() && !logoFailed) {
        AsyncImage(
            model = logo,
            contentDescription = title,
            contentScale = ContentScale.Fit,
            onError = { logoFailed = true },
            modifier =
                breathing
                    .height(LOADING_LOGO_HEIGHT_DP.dp)
                    .widthIn(max = LOADING_LOGO_MAX_WIDTH_DP.dp),
        )
    } else {
        Text(
            title,
            color = Color.White,
            style =
                MaterialTheme.typography.titleLarge.copy(
                    shadow =
                        androidx.compose.ui.graphics.Shadow(
                            Color.Black.copy(alpha = 0.65f),
                            offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                            blurRadius = 14f,
                        ),
                ),
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = breathing,
        )
    }
}

/**
 * Player clock sync (v0.3.27): the ONLY collector of the
 * ViewModel's PlayerClock flow in this screen. It exists as its
 * own tiny composable so a clock tick recomposes these few lines
 * instead of the PlavioPlayerScreen root — the root previously
 * collected the flow and keyed its mirror effect on each
 * snapshot, re-executing the entire screen body at every tick
 * (500 ms with the controls presented, ~2 s hidden). The sync
 * writes each snapshot through [onClock] into the root's mirrored
 * states, unchanged in values and rate.
 */
@Composable
private fun PlayerClockSync(
    playerClock: StateFlow<PlayerClock>,
    onClock: (PlayerClock) -> Unit,
) {
    val clock by playerClock.collectAsState()
    LaunchedEffect(clock) { onClock(clock) }
}

@Composable
private fun SeekBar(
    positionMs: () -> Long,
    durationMs: () -> Long,
    bufferedMs: () -> Long,
    isLive: Boolean,
    onSeekKey: (Long) -> Unit,
    onTogglePlay: () -> Unit,
    skipForwardMs: Long,
    skipBackMs: Long,
    focusRequester: FocusRequester,
    /** Live only: the title + status the LIVE row carries. */
    liveTitle: String = "",
    liveStatus: String = "",
) {
    val accent = LocalPlavioAccent.current
    // v0.3.23: snapshot the lambda-fed progress values once per pass.
    // (bufferedMs is no longer drawn — v0.3.31 dropped the buffered
    // segment for the phone's single-track seek line — but the
    // caller's lambda contract is unchanged.)
    val pos = positionMs()
    val dur = durationMs()
    var focused by remember { mutableStateOf(false) }
    // ONE focusable box carries the whole row — and its focus ring,
    // key handling (Left/Right seek by the skip amounts, Centre /
    // Enter toggles play) and landing are exactly as they were
    // (frozen machinery, spec §1.1). v0.3.31 changed only what the
    // box DRAWS: the phone's one-line seek row for VOD, the phone's
    // LIVE row for live.
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .focusRequester(focusRequester)
                .onFocusChanged { focused = it.isFocused }
                .focusable()
                .onKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onKeyEvent false
                    when (event.key) {
                        Key.DirectionLeft -> {
                            onSeekKey(-skipBackMs)
                            true
                        }
                        Key.DirectionRight -> {
                            onSeekKey(skipForwardMs)
                            true
                        }
                        Key.DirectionCenter, Key.Enter -> {
                            onTogglePlay()
                            true
                        }
                        else -> false
                    }
                }
                .border(
                    // The focus ring in the user's accent (v0.3.14).
                    width = if (focused) 2.5.dp else 0.dp,
                    color = if (focused) accent.primary else Color.Transparent,
                    shape = RoundedCornerShape(50),
                )
                .padding(horizontal = 4.dp, vertical = 8.dp),
    ) {
        if (isLive) {
            // The LIVE row (v0.3.31, the phone's form — spec §5.7):
            // the red chip, the title, the status text. No track,
            // no fill; the keys above still seek by the skip
            // amounts (timeshift) and toggle play, as before.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            ) {
                Box(
                    modifier =
                        Modifier
                            .background(Color(0xFFE5484D), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                ) {
                    Text(
                        text = stringResource(R.string.plavio_player_live_badge),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
                Text(
                    text = liveTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = liveStatus,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PlavioOnyx.TextSecondary,
                    maxLines = 1,
                )
            }
        } else {
            // One line (v0.3.31, the phone's seek row): current
            // time — the bar — total time.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = formatTime(pos),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
                // The phone's SlimSeekBar drawing: ONE track line
                // at a whisper of white (the phone's item-35
                // alpha), the played fill in the accent, and the
                // playhead a white orb wrapped in a soft halo of
                // the accent. No separate buffered segment (the
                // phone draws none). Unknown duration keeps the
                // indeterminate sliding segment (v0.3.13's honest
                // third state).
                BoxWithConstraints(
                    modifier =
                        Modifier
                            .weight(1f)
                            .height(6.dp),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Color.White.copy(alpha = 0.09f),
                                    RoundedCornerShape(50),
                                ),
                    ) {
                        when {
                            dur > 0 -> {
                                Box(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth(
                                                (pos.toFloat() / dur).coerceIn(0f, 1f),
                                            )
                                            .height(6.dp)
                                            .background(
                                                accent.primary,
                                                RoundedCornerShape(50),
                                            ),
                                )
                            }
                            else -> {
                                val slideTransition =
                                    rememberInfiniteTransition(
                                        label = "seekIndeterminate",
                                    )
                                val slide by slideTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = 1f,
                                    animationSpec =
                                        infiniteRepeatable(
                                            animation =
                                                tween(
                                                    durationMillis = 1400,
                                                    easing = LinearEasing,
                                                ),
                                            repeatMode = RepeatMode.Restart,
                                        ),
                                    label = "seekIndeterminateSlide",
                                )
                                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                                    val segmentWidth = maxWidth * 0.3f
                                    Box(
                                        modifier =
                                            Modifier
                                                .offset(
                                                    x = (maxWidth - segmentWidth) * slide,
                                                )
                                                .width(segmentWidth)
                                                .height(6.dp)
                                                .background(
                                                    accent.primary,
                                                    RoundedCornerShape(50),
                                                ),
                                    )
                                }
                            }
                        }
                    }
                    if (dur > 0) {
                        // The orb playhead (the phone's accent
                        // light-orb): a white core wrapped in a
                        // soft radial halo of the accent, centred
                        // on the played fraction, clamped so the
                        // core never leaves the line.
                        val frac = (pos.toFloat() / dur).coerceIn(0f, 1f)
                        val coreCx =
                            (maxWidth * frac).coerceIn(7.dp, maxWidth - 7.dp)
                        Box(
                            modifier =
                                Modifier
                                    .offset(x = coreCx - 17.dp, y = -14.dp)
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors =
                                                listOf(
                                                    accent.primary.copy(alpha = 0.55f),
                                                    accent.primary.copy(alpha = 0f),
                                                ),
                                        ),
                                    ),
                        )
                        Box(
                            modifier =
                                Modifier
                                    .offset(x = coreCx - 7.dp, y = -4.dp)
                                    .size(14.dp)
                                    .background(Color.White, CircleShape),
                        )
                    }
                }
                Text(
                    text = if (dur > 0) formatTime(dur) else "--:--",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = PlavioOnyx.TextSecondary,
                )
            }
        }
    }
}

/**
 * A bare centre-transport glyph (v0.3.31, the phone's centre
 * transport — spec §5.2 item 7): no disc, no fill — the glyph
 * itself, drawn twice (a black duplicate offset 2dp under the
 * white glyph, the phone's shadow treatment). Focus is the frozen
 * accent ring on an invisible circle; scale pinned like every
 * Plavio surface.
 */
@Composable
private fun BareTransportButton(
    icon: ImageVector,
    glyphSize: Dp,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = Color.White,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = Color.White,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(CircleShape),
    ) {
        Box(
            modifier = Modifier.size(glyphSize + 16.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = Color.Black.copy(alpha = 0.55f),
                modifier = Modifier.size(glyphSize).offset(x = 2.dp, y = 2.dp),
            )
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(glyphSize),
            )
        }
    }
}

/**
 * The centre play/pause (v0.3.31, the phone's): the glyph inside a
 * light liquid-glass disc — a pale frost fill with a silver rim.
 * Focus is the frozen accent ring; scale pinned.
 */
@Composable
private fun CentrePlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.White.copy(alpha = 0.12f),
                contentColor = Color.White,
                focusedContainerColor = Color.White.copy(alpha = 0.12f),
                focusedContentColor = Color.White,
                pressedContainerColor = Color.White.copy(alpha = 0.12f),
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(CircleShape),
    ) {
        Box(
            modifier =
                Modifier
                    .size(92.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.28f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (isPlaying) PlavioIcons.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(76.dp),
            )
        }
    }
}

@Composable
private fun ControlButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                contentColor = Color.White,
                // v0.3.13: focus = pink ring only, no white fill.
                focusedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                focusedContentColor = Color.White,
                pressedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(50)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            // One line, never wrapped: in v0.3.3 the controls row could
            // overrun the screen width and Compose crushed the LAST
            // button ("Sources") into the leftover sliver, soft-wrapping
            // its label one letter per line into a fake vertical "tab".
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.plavioCentred(),
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/**
 * One action capsule in the player's single button row: the same
 * glass pill language as [ControlButton] — PanelVariant step over
 * the capsule's Panel fill, accent ring on focus, scale pinned.
 * v0.3.22 (owner's word on v0.3.21, superseding the 2026-11-02
 * icon-only rule): every button carries its title under the glyph —
 * Subs, Audio, Sources, Aspect and the rest say what they are.
 * Icon + label are centred as one column inside the capsule.
 */
/** A top-bar badge chip (v0.3.31, the phone's PlayerBadge): white
 * 16% fill, white 28% rim, small bold text. */
@Composable
private fun PlayerBadge(text: String) {
    Box(
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.16f))
                .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(50))
                .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
        )
    }
}

@Composable
private fun PlayerRowButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    /**
     * A small accent dot at the icon's top-end corner (v0.3.31 —
     * the phone's subs-on signal on its Subtitles button). Purely
     * visual; the button's focus and click are untouched.
     */
    showDot: Boolean = false,
) {
    val accent = LocalPlavioAccent.current
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                // v0.3.31: the pill buttons are BARE inside the
                // dock-frost pill (the phone's PillBarButton) —
                // the pill carries the surface; the button is
                // icon + label only. Focus = the accent ring only,
                // like every Plavio surface.
                containerColor = Color.Transparent,
                contentColor = Color.White,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = Color.White,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(50)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Box {
                Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
                if (showDot) {
                    Box(
                        modifier =
                            Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 3.dp, y = (-3).dp)
                                .size(7.dp)
                                .background(accent.primary, CircleShape),
                    )
                }
            }
            Text(
                text = label,
                style =
                    MaterialTheme.typography.labelSmall.copy(
                        platformStyle =
                            androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                    ),
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/** The phone player's speed set. */
private val PLAYER_SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

private fun formatSpeed(speed: Float): String {
    val text =
        if (speed % 1f == 0f) {
            speed.toInt().toString()
        } else {
            speed.toString().trimEnd('0').trimEnd('.')
        }
    return "$text×"
}

@Composable
private fun SpeedPanel(
    current: Float,
    onPick: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    Column(
        modifier =
            modifier
                .width(400.dp)
                .padding(end = 48.dp)
                .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_speed),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(PLAYER_SPEEDS) { index, value ->
                val selected = value == current
                Surface(
                    onClick = { onPick(value) },
                    modifier =
                        if (selected) {
                            Modifier.focusRequester(firstFocus)
                        } else {
                            Modifier
                        },
                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                    colors =
                        ClickableSurfaceDefaults.colors(
                            containerColor = Color.Transparent,
                            contentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                            // v0.3.13: focus = pink ring only.
                            focusedContainerColor = Color.Transparent,
                            focusedContentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                            pressedContainerColor = Color.Transparent,
                            pressedContentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                        ),
                    border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                ) {
                    Text(
                        text = formatSpeed(value),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
            }
        }
    }
}

/** Sleep timer presets (phone parity): minutes, 0 = Off. */
private val SLEEP_PRESETS_MINUTES = listOf(15, 30, 45, 60)

@Composable
private fun SleepTimerPanel(
    currentPreset: Int,
    episodeEndArmed: Boolean,
    onPick: (Int) -> Unit,
    onPickEpisodeEnd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    Column(
        modifier =
            modifier
                .width(400.dp)
                .padding(end = 48.dp)
                .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_sleep),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                SleepTimerRow(
                    label = stringResource(R.string.plavio_player_sleep_off),
                    selected = currentPreset == 0 && !episodeEndArmed,
                    focusRequester = if (currentPreset == 0 && !episodeEndArmed) firstFocus else null,
                    onClick = { onPick(0) },
                )
            }
            itemsIndexed(SLEEP_PRESETS_MINUTES) { _, minutes ->
                SleepTimerRow(
                    label = stringResource(R.string.plavio_player_sleep_minutes, minutes),
                    selected = currentPreset == minutes && !episodeEndArmed,
                    focusRequester = if (currentPreset == minutes && !episodeEndArmed) firstFocus else null,
                    onClick = { onPick(minutes) },
                )
            }
            item {
                SleepTimerRow(
                    label = stringResource(R.string.plavio_player_sleep_episode_end),
                    selected = episodeEndArmed,
                    focusRequester = if (episodeEndArmed) firstFocus else null,
                    onClick = onPickEpisodeEnd,
                )
            }
        }
    }
}

@Composable
private fun SleepTimerRow(
    label: String,
    selected: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier =
            if (focusRequester != null) {
                Modifier.focusRequester(focusRequester)
            } else {
                Modifier
            },
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor =
                    if (selected) {
                        LocalPlavioAccent.current.primary
                    } else {
                        Color.White
                    },
                focusedContainerColor = Color.Transparent,
                focusedContentColor =
                    if (selected) {
                        LocalPlavioAccent.current.primary
                    } else {
                        Color.White
                    },
                pressedContainerColor = Color.Transparent,
                pressedContentColor =
                    if (selected) {
                        LocalPlavioAccent.current.primary
                    } else {
                        Color.White
                    },
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
    }
}

/** A footer row inside a picker panel (e.g. the Audio panel's preferred-language entry). */
@Composable
private fun PanelFooterRow(
    label: String,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = PlavioOnyx.TextSecondary,
                // v0.3.13: focus = pink ring only.
                focusedContainerColor = Color.Transparent,
                focusedContentColor = PlavioOnyx.TextSecondary,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = PlavioOnyx.TextSecondary,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun TrackPickerPanel(
    title: String,
    emptyText: String,
    options: List<TrackOption>,
    onPick: (TrackOption) -> Unit,
    modifier: Modifier = Modifier,
    footer: (@Composable () -> Unit)? = null,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(options) {
        runCatching { firstFocus.requestFocus() }
    }
    Column(
        modifier =
            modifier
                .width(400.dp)
                .padding(end = 48.dp)
                .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        if (options.isEmpty()) {
            Text(
                text = emptyText,
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(options) { index, option ->
                    Surface(
                        onClick = { onPick(option) },
                        modifier =
                            if (index == 0) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                                // v0.3.13: focus = pink ring only.
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Text(
                            text = option.label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
            }
        }
        if (footer != null) {
            Spacer(modifier = Modifier.height(4.dp))
            footer()
        }
    }
}

/** One filter chip in the player's sources panel (addon tab / quality pill). */
@Composable
private fun SourceFilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalPlavioAccent.current.primary
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor =
                    if (selected) accent.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.07f),
                contentColor = if (selected) accent else Color.White,
                focusedContainerColor =
                    if (selected) accent.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.07f),
                focusedContentColor = if (selected) accent else Color.White,
                pressedContainerColor =
                    if (selected) accent.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.07f),
                pressedContentColor = if (selected) accent else Color.White,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(50)),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            maxLines = 1,
        )
    }
}

/** "1.4 GB" / "850 MB" for a stream's declared size. */
private fun sourceSizeLabel(bytes: Long): String {
    val gb = bytes / 1_000_000_000.0
    if (gb >= 1.0) return "%.1f GB".format(gb)
    val mb = bytes / 1_000_000.0
    if (mb >= 1.0) return "%.0f MB".format(mb)
    return "$bytes B"
}

/**
 * The player's own Sources panel (v0.3.31 — the phone's Design-I
 * form, spec §5.3 item 15): a wide centre-right panel on the solid
 * popup surface — a banner (the title's art grading into the
 * panel, the title, and the stream-count capsule; tapping the
 * capsule force-refreshes), addon tabs, quality pills, the count
 * line, and compact stream cards with size badges. Pick / reload /
 * auto-popup behaviours are the panel's own, unchanged from
 * [SourcesPanel] (which stays as the Detail page's shared panel —
 * Detail is out of this build's scope). The phone's live
 * sources-timer capsule has no TV counterpart state and is not
 * faked; the count capsule carries the loading orbit while the
 * fetch is still empty-handed.
 */
@Composable
internal fun PlayerSourcesPanel(
    streams: List<StreamItem>,
    currentUrl: String,
    backdrop: String?,
    title: String,
    onPick: (StreamItem) -> Unit,
    onReload: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(streams.isNotEmpty()) {
        runCatching { firstFocus.requestFocus() }
    }
    var sourceTab by remember { mutableStateOf<String?>(null) }
    var qualityTab by remember { mutableStateOf<String?>(null) }
    val sourceNames =
        remember(streams) { streams.mapNotNull { it.sourceName?.takeIf { n -> n.isNotBlank() } }.distinct() }
    val qualities =
        remember(streams) { streams.mapNotNull { streamQualityLabel(it) }.distinct() }
    val activeSource = sourceTab?.takeIf { it in sourceNames }
    val activeQuality = qualityTab?.takeIf { it in qualities }
    val filtered =
        remember(streams, activeSource, activeQuality) {
            streams.filter { stream ->
                (activeSource == null || stream.sourceName == activeSource) &&
                    (activeQuality == null || streamQualityLabel(stream) == activeQuality)
            }
        }
    Column(
        modifier =
            modifier
                .background(Color(0xFF0B0B11), RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFFC7CCD6).copy(alpha = 0.30f), RoundedCornerShape(22.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Banner: art + gradient + title + the count capsule.
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF14141F)),
        ) {
            if (backdrop != null) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalContext.current)
                            .data(backdrop)
                            .size(1280, 720)
                            .crossfade(false)
                            .build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors =
                                    listOf(
                                        Color.Transparent,
                                        Color(0xFF14141F),
                                    ),
                            ),
                        ),
            )
            Column(
                modifier =
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                // The count capsule: total streams (+ the orbit
                // while the fetch is still empty-handed); a tap
                // force-refreshes the fetch.
                Surface(
                    onClick = onReload,
                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                    colors =
                        ClickableSurfaceDefaults.colors(
                            containerColor = Color.Black.copy(alpha = 0.55f),
                            contentColor = Color.White,
                            focusedContainerColor = Color.Black.copy(alpha = 0.55f),
                            focusedContentColor = Color.White,
                            pressedContainerColor = Color.Black.copy(alpha = 0.55f),
                            pressedContentColor = Color.White,
                        ),
                    border = plavioRowFocusBorder(RoundedCornerShape(50)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (streams.isEmpty()) {
                            OrbitLoader(
                                modifier = Modifier.size(16.dp),
                                alwaysAnimate = true,
                            )
                        }
                        Text(
                            text = stringResource(R.string.plavio_player_sources_count, streams.size),
                            style = MaterialTheme.typography.labelLarge,
                        )
                    }
                }
            }
        }
        // Addon tabs (only when more than one addon contributed).
        if (sourceNames.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SourceFilterChip(
                        text = stringResource(R.string.plavio_player_all),
                        selected = activeSource == null,
                        onClick = { sourceTab = null },
                    )
                }
                items(sourceNames) { name ->
                    SourceFilterChip(
                        text = name,
                        selected = activeSource == name,
                        onClick = { sourceTab = name },
                    )
                }
            }
        }
        // Quality pills (only when more than one quality is on offer).
        if (qualities.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SourceFilterChip(
                        text = stringResource(R.string.plavio_player_all),
                        selected = activeQuality == null,
                        onClick = { qualityTab = null },
                    )
                }
                items(qualities) { quality ->
                    SourceFilterChip(
                        text = quality,
                        selected = activeQuality == quality,
                        onClick = { qualityTab = quality },
                    )
                }
            }
        }
        if (streams.isEmpty()) {
            Text(
                text = stringResource(R.string.plavio_player_no_sources),
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
            Surface(
                onClick = onReload,
                modifier = Modifier.focusRequester(firstFocus),
                shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                colors =
                    ClickableSurfaceDefaults.colors(
                        containerColor = Color.Transparent,
                        contentColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        focusedContentColor = Color.White,
                        pressedContainerColor = Color.Transparent,
                        pressedContentColor = Color.White,
                    ),
                border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_reload_sources),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        } else {
            Text(
                text = stringResource(R.string.plavio_player_sources_count, filtered.size),
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(filtered) { index, stream ->
                    val isCurrent = stream.url == currentUrl
                    val accent = LocalPlavioAccent.current.primary
                    Surface(
                        onClick = { onPick(stream) },
                        modifier =
                            if (index == 0) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = if (isCurrent) accent else Color.White,
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = if (isCurrent) accent else Color.White,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = if (isCurrent) accent else Color.White,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = sourcePanelLine(stream),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isCurrent) accent else Color.White,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                                val size = stream.videoSize
                                if (size != null && size > 0) {
                                    Text(
                                        text = sourceSizeLabel(size),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = PlavioOnyx.TextSecondary,
                                    )
                                    Spacer(Modifier.width(10.dp))
                                }
                                if (isCurrent) {
                                    Text(
                                        text = stringResource(R.string.plavio_player_now_playing),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = accent,
                                    )
                                }
                            }
                            val detail = stream.title ?: stream.filename
                            if (!detail.isNullOrBlank()) {
                                Text(
                                    text = detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PlavioOnyx.TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Streams-screen labelling for one source row: "Source · 1080p". */
internal fun sourcePanelLine(stream: StreamItem): String {
    val source = stream.sourceName ?: stream.name ?: "Source"
    val quality = streamQualityLabel(stream)
    return if (quality != null) "$source · $quality" else source
}

/**
 * In-player Sources panel (v0.3.18): the title's fetched streams as a
 * right-side overlay in the player's own panel language (same chrome
 * as [TrackPickerPanel]). The currently playing stream is marked in
 * the accent colour; OK on a row switches through the ViewModel's
 * position-keeping switch path without leaving the player. When the
 * request carries no streams (resumed items), the panel says so and
 * offers a reload through the ViewModel instead of navigating away.
 * Rows carry the Streams screen's labelling (source · quality over
 * the stream's own title line); no Download capsule in here.
 *
 * v0.3.22: shared with the Detail page — its Source button opens
 * THIS panel (same component, same chrome), per the owner's word
 * that Detail sources open exactly like the player's.
 */
@Composable
internal fun SourcesPanel(
    streams: List<StreamItem>,
    currentUrl: String,
    onPick: (StreamItem) -> Unit,
    onReload: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(streams.isNotEmpty()) {
        runCatching { firstFocus.requestFocus() }
    }
    Column(
        modifier =
            modifier
                .width(440.dp)
                .padding(end = 48.dp)
                // NOTE (v0.3.31): this panel is shared with the
                // Detail page (v0.3.22) and keeps its chrome — the
                // player's own sources surface is PlayerSourcesPanel
                // below; Detail is out of this build's scope.
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_sources),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        if (streams.isEmpty()) {
            Text(
                text = stringResource(R.string.plavio_player_no_sources),
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
            Surface(
                onClick = onReload,
                modifier = Modifier.focusRequester(firstFocus),
                shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                colors =
                    ClickableSurfaceDefaults.colors(
                        containerColor = Color.Transparent,
                        contentColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        focusedContentColor = Color.White,
                        pressedContainerColor = Color.Transparent,
                        pressedContentColor = Color.White,
                    ),
                border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_reload_sources),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(streams) { index, stream ->
                    val isCurrent = stream.url == currentUrl
                    val accent = LocalPlavioAccent.current.primary
                    Surface(
                        onClick = { onPick(stream) },
                        modifier =
                            if (index == 0) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = if (isCurrent) accent else Color.White,
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = if (isCurrent) accent else Color.White,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = if (isCurrent) accent else Color.White,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = sourcePanelLine(stream),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isCurrent) accent else Color.White,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                                if (isCurrent) {
                                    Text(
                                        text = stringResource(R.string.plavio_player_now_playing),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = accent,
                                    )
                                }
                            }
                            val detail = stream.title ?: stream.filename
                            if (!detail.isNullOrBlank()) {
                                Text(
                                    text = detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PlavioOnyx.TextSecondary,
                                    maxLines = 2,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}
