package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.BoundedHttp
import com.github.damontecres.wholphin.plavio.InstalledAddon
import com.github.damontecres.wholphin.plavio.cloud.PlavioAccountManager
import com.github.damontecres.wholphin.plavio.cloud.PlavioBackup
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.SerializationException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject

data class PlavioSetupUiState(
    val adding: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    /** Ids of addons with a manifest refresh in flight (v0.3.1). */
    val refreshingIds: Set<String> = emptySet(),
    /** Outcome of the last refresh, shown under the addon list header. */
    val refreshNote: String? = null,
    val refreshNoteIsError: Boolean = false,
    /** Account addons-sync in flight (v0.3.16 "Sync from account"). */
    val syncing: Boolean = false,
)

/** "Manage from phone" pairing session state (batch 6). */
data class PairUiState(
    val active: Boolean = false,
    val pairUrl: String? = null,
    val code: String? = null,
    val error: String? = null,
    /** Latest phone-side events, newest first (max 5). */
    val events: List<String> = emptyList(),
)

@HiltViewModel
class PlavioSetupViewModel
    @Inject
    constructor(
        @param:ApplicationContext context: Context,
        backup: PlavioBackup,
        private val addonStore: AddonStore,
        private val uiPrefs: com.github.damontecres.wholphin.plavio.PlavioUiPrefs,
        private val changeLog: com.github.damontecres.wholphin.plavio.AddonChangeLog,
    ) : ViewModel() {
        // PlavioAccountManager has no @Inject constructor — built by
        // hand exactly like PlavioAccountsViewModel builds it.
        private val accountManager = PlavioAccountManager(context, backup)
        val addons: StateFlow<List<InstalledAddon>> = addonStore.addons

        /** The chosen default catalog addon (v0.3.16, note 6). */
        val defaultCatalogAddonId: StateFlow<String?> = uiPrefs.defaultCatalogAddonId

        fun setDefaultCatalogAddon(id: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setDefaultCatalogAddonId(id) }
        }

        private val _uiState = MutableStateFlow(PlavioSetupUiState())
        val uiState: StateFlow<PlavioSetupUiState> = _uiState

        init {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore.ensureHouseAddons()
            }
        }

        fun addAddon(url: String) {
            if (_uiState.value.adding) return
            _uiState.update { it.copy(adding = true, statusMessage = null, errorMessage = null) }
            // Batch 6: a re-add of an installed addon is an update,
            // not a change worth reviewing — snapshot the ids first.
            val installedBefore = addons.value.map { it.id }.toSet()
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore
                    .addAddon(url)
                    .onSuccess { addon ->
                        if (addon.id !in installedBefore) {
                            changeLog.recordInstalled(addon)
                        }
                        _uiState.update {
                            it.copy(adding = false, statusMessage = addon.name)
                        }
                    }.onFailure { e ->
                        _uiState.update {
                            it.copy(adding = false, errorMessage = e.message)
                        }
                    }
            }
        }

        fun removeAddon(id: String) {
            // Batch 6: capture the addon BEFORE it goes — the
            // review entry (and its undo) needs the name + base URL.
            val removed = addons.value.firstOrNull { it.id == id }
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore.removeAddon(id)
                if (removed != null) changeLog.recordRemoved(removed)
            }
        }

        // ---- Batch 6: change review + manage from phone ----

        /** This session's addon changes, for the review panel. */
        val changes: StateFlow<List<com.github.damontecres.wholphin.plavio.AddonChange>> =
            changeLog.changes

        /**
         * Undo one reviewed change: an install is removed again; a
         * removal is re-installed from its recorded base URL. The
         * undo itself is NOT recorded (it answers the review, it
         * isn't a new change), and the entry drops either way the
         * store call lands — a failed re-install surfaces through
         * the screen's normal refresh, not a stuck review row.
         */
        fun undoChange(change: com.github.damontecres.wholphin.plavio.AddonChange) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                when (change.kind) {
                    com.github.damontecres.wholphin.plavio.AddonChange.Kind.INSTALLED ->
                        addonStore.removeAddon(change.addonId)
                    com.github.damontecres.wholphin.plavio.AddonChange.Kind.REMOVED ->
                        addonStore.addAddon(change.baseUrl.trimEnd('/') + "/manifest.json")
                }
                changeLog.drop(change)
            }
        }

        /** Keep: every listed change stands; the review empties. */
        fun keepAllChanges() {
            changeLog.clear()
        }

        private val _pairState = MutableStateFlow(PairUiState())
        val pairState: StateFlow<PairUiState> = _pairState
        private var pairServer: com.github.damontecres.wholphin.plavio.PlavioPairServer? = null

        /**
         * Opens the pairing session: the LAN server runs while the
         * "Manage from phone" panel is open and stops with it. The
         * panel renders [pairState] — URL + code once listening, or
         * the plain reason it couldn't start.
         */
        fun startPhoneManage() {
            if (pairServer != null) return
            val ip = com.github.damontecres.wholphin.plavio.getLanIpAddress()
            if (ip == null) {
                _pairState.value =
                    PairUiState(error = "Couldn't find this TV on your Wi-Fi. Make sure it's connected.")
                return
            }
            val server =
                com.github.damontecres.wholphin.plavio.PlavioPairServer(
                    ip,
                    addonStore,
                    changeLog,
                ) { msg ->
                    _pairState.update { state ->
                        state.copy(events = (listOf(msg) + state.events).take(5))
                    }
                }
            pairServer = server
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        server.start()
                    }
                }.onSuccess {
                    _pairState.value =
                        PairUiState(active = true, pairUrl = server.pairUrl(), code = server.code)
                }.onFailure { e ->
                    pairServer = null
                    _pairState.value =
                        PairUiState(error = "Couldn't start the setup server: ${e.message}")
                }
            }
        }

        fun stopPhoneManage() {
            val server = pairServer ?: return
            pairServer = null
            _pairState.value = PairUiState()
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        server.stop()
                    }
                }
            }
        }

        override fun onCleared() {
            stopPhoneManage()
        }

        /**
         * Short, honest reason a manifest refresh failed (v0.3.24).
         * Until now EVERY failure — an HTTP status from the addon's
         * server, an unreadable reply, a timeout — was reported as
         * "Check your connection", which blamed the user's network
         * for faults that were never his (proven live 2026-11-09:
         * PlavioLive's manifest answers HTTP 402, deployment
         * disabled, while the other factory addons answer 200 — one
         * such addon failed every Refresh and the note lied about
         * why). The reason is read off the real exception; the
         * connection is only named when the addon genuinely could
         * not be reached.
         */
        private fun refreshFailureReason(error: Throwable): String {
            val chain = generateSequence(error) { it.cause }.toList()
            chain.filterIsInstance<BoundedHttp.HttpFailure>().firstOrNull()?.let {
                return "the server answered HTTP ${it.statusCode}"
            }
            if (chain.any { it is SocketTimeoutException || it is InterruptedIOException }) {
                return "it timed out"
            }
            if (chain.any { it is UnknownHostException || it is ConnectException }) {
                return "it couldn't be reached"
            }
            if (chain.any { it is SerializationException }) {
                return "it sent a reply the app couldn't read"
            }
            return "it failed"
        }

        /**
         * Refresh one addon's manifest from its server (v0.3.1, phone
         * parity). The note mirrors the phone's wording: updated to a
         * new version, already up to date, or the failure.
         */
        fun refreshAddon(addon: InstalledAddon) {
            if (addon.id in _uiState.value.refreshingIds) return
            _uiState.update {
                it.copy(
                    refreshingIds = it.refreshingIds + addon.id,
                    refreshNote = null,
                )
            }
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val oldVersion = addon.manifest.version
                val note: Pair<String, Boolean> =
                    addonStore
                        .refreshAddon(addon.id)
                        .fold(
                            onSuccess = { updated ->
                                val newVersion = updated.manifest.version
                                if (oldVersion.isNotBlank() && newVersion.isNotBlank() &&
                                    oldVersion != newVersion
                                ) {
                                    "${addon.name} updated: v$oldVersion → v$newVersion" to false
                                } else if (newVersion.isNotBlank()) {
                                    "${addon.name} is already up to date (v$newVersion)" to false
                                } else {
                                    "${addon.name} refreshed" to false
                                }
                            },
                            onFailure = { e ->
                                "Couldn't refresh ${addon.name} — ${refreshFailureReason(e)}." to true
                            },
                        )
                _uiState.update {
                    it.copy(
                        refreshingIds = it.refreshingIds - addon.id,
                        refreshNote = note.first,
                        refreshNoteIsError = note.second,
                    )
                }
            }
        }

        /** Refresh every installed addon's manifest (the header Refresh button). */
        fun refreshAllAddons() {
            val targets = addons.value.filter { it.id !in _uiState.value.refreshingIds }
            if (targets.isEmpty()) return
            _uiState.update {
                it.copy(
                    refreshingIds = it.refreshingIds + targets.map { a -> a.id },
                    refreshNote = null,
                )
            }
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                // v0.3.24: a failure names its addon and its real
                // reason, and the addons that DID refresh are
                // reported as refreshed — until now one dead addon
                // made the whole refresh read as a network failure
                // (see refreshFailureReason).
                val failures = mutableListOf<String>()
                targets.forEach { addon ->
                    addonStore.refreshAddon(addon.id).onFailure { e ->
                        failures += "${addon.name} (${refreshFailureReason(e)})"
                    }
                    _uiState.update {
                        it.copy(refreshingIds = it.refreshingIds - addon.id)
                    }
                }
                _uiState.update {
                    it.copy(
                        refreshNote =
                            if (failures.isEmpty()) {
                                "Addons refreshed"
                            } else {
                                "Refreshed ${targets.size - failures.size} of ${targets.size} addons. " +
                                    "Couldn't refresh: ${failures.joinToString(", ")}."
                            },
                        refreshNoteIsError = failures.isNotEmpty(),
                    )
                }
            }
        }

        fun setAddonEnabled(
            id: String,
            enabled: Boolean,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                addonStore.setEnabled(id, enabled)
            }
        }

        /**
         * "Sync from account" (v0.3.16, Sample B addons layout): the
         * same addons-only account sync the Account screen runs
         * (v0.3.14) — the phone's addons merge into this TV through
         * [PlavioAccountManager.syncAddonsFromAccount]; the note
         * wording matches the account screen's exactly.
         */
        fun syncAddonsFromAccount() {
            if (_uiState.value.syncing) return
            _uiState.update { it.copy(syncing = true, refreshNote = null) }
            // Batch 6: account-synced installs join the change
            // review too — diff the store before/after.
            val installedBefore = addons.value.map { it.id }.toSet()
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val note: Pair<String, Boolean> =
                    accountManager
                        .syncAddonsFromAccount()
                        .fold(
                            onSuccess = { added ->
                                if (added != null && added > 0) {
                                    addons.value
                                        .filter { it.id !in installedBefore }
                                        .forEach { changeLog.recordInstalled(it) }
                                }
                                when {
                                    added == null ->
                                        "No backup found on this account yet." to false
                                    added == 0 ->
                                        "No new addons — this TV already has them all." to false
                                    added == 1 ->
                                        "1 addon added from your account." to false
                                    else ->
                                        "$added addons added from your account." to false
                                }
                            },
                            onFailure = { e ->
                                if (e.message?.contains("Not signed in") == true) {
                                    "Sign in from the tray's Account first, then sync." to true
                                } else {
                                    "Couldn't sync addons from your account. Check your connection and try again." to true
                                }
                            },
                        )
                _uiState.update {
                    it.copy(
                        syncing = false,
                        refreshNote = note.first,
                        refreshNoteIsError = note.second,
                    )
                }
            }
        }
    }
