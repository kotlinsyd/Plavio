package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports
import kotlinx.coroutines.CoroutineScope

import androidx.datastore.core.DataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.PlavioUpdater
import com.github.damontecres.wholphin.plavio.TvUpdate
import com.github.damontecres.wholphin.plavio.UpdateInstallResult
import com.github.damontecres.wholphin.preferences.AppPreferences
import com.github.damontecres.wholphin.services.DownloadCallback
import com.github.damontecres.wholphin.preferences.updatePlaybackOverrides
import com.github.damontecres.wholphin.services.UserPreferencesService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Update-check state shown in Settings → About / Updates. */
sealed interface PlavioUpdateUiState {
    data object Idle : PlavioUpdateUiState

    data object Checking : PlavioUpdateUiState

    data object UpToDate : PlavioUpdateUiState

    data object Failed : PlavioUpdateUiState

    data class Available(
        val update: TvUpdate,
    ) : PlavioUpdateUiState

    data class Downloading(
        val fraction: Float?,
    ) : PlavioUpdateUiState

    /** The download finished but the install stopped (network/verify). */
    data class InstallFailed(
        val update: TvUpdate,
    ) : PlavioUpdateUiState

    /** Downloaded and verified; waiting on the unknown-sources allow. */
    data class NeedsPermission(
        val update: TvUpdate,
    ) : PlavioUpdateUiState
}

@HiltViewModel
class PlavioSettingsViewModel
    @Inject
    constructor(
        private val uiPrefs: PlavioUiPrefs,
        private val updater: PlavioUpdater,
        addonStore: com.github.damontecres.wholphin.plavio.AddonStore,
        userPreferencesService: UserPreferencesService,
        private val appPreferencesDataStore: DataStore<AppPreferences>,
        private val subtitleStyleStore: com.github.damontecres.wholphin.plavio.SubtitleStyleStore,
        private val fusionStore: com.github.damontecres.wholphin.plavio.PlavioFusionBadgeStore,
    ) : ViewModel() {
        val accent: StateFlow<PlavioAccent> = uiPrefs.accent

        /** Installed addons — the landing page's Addons row summary (v0.3.21). */
        val addons: StateFlow<List<com.github.damontecres.wholphin.plavio.InstalledAddon>> =
            addonStore.addons
        val autoUpdateCheck: StateFlow<Boolean> = uiPrefs.autoUpdateCheck

        /** Phone parity: Watch Now auto-plays the best stream. */
        val autoplayBestStream: StateFlow<Boolean> = uiPrefs.autoplayBestStream

        /** Phone parity: auto-play the next episode when one ends. */
        val autoPlayNextEpisode: StateFlow<Boolean> = uiPrefs.autoPlayNextEpisode

        /** Phone parity: preferred subtitle languages (up to 2) + audio language. */
        val subtitleLanguages: StateFlow<List<String>> = uiPrefs.subtitleLanguages
        val preferredAudioLanguage: StateFlow<String?> = uiPrefs.preferredAudioLanguage

        /** Phone parity: show the Skip intro/recap/outro button (Playback section). */
        val showSkipIntro: StateFlow<Boolean> = uiPrefs.showSkipIntro

        fun setShowSkipIntro(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setShowSkipIntro(enabled) }
        }

        /** Spoiler blur for unwatched episode pictures (Playback section; batch 6). */
        val blurUnwatchedEpisodes: StateFlow<Boolean> = uiPrefs.blurUnwatchedEpisodes

        fun setBlurUnwatchedEpisodes(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBlurUnwatchedEpisodes(enabled) }
        }

        /** TV look (owner design 2026-11-04): PLAVIO_LOOK_FULL / PLAVIO_LOOK_LIGHT; null = never chosen (full look renders). */
        val lookMode: StateFlow<String?> = uiPrefs.lookMode

        fun setLookMode(mode: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setLookMode(mode) }
        }

        /** Text size (v0.3.26 batch 5): the root scales fonts by this choice. */
        val textSize: StateFlow<String> = uiPrefs.textSize

        fun cycleTextSize() {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                uiPrefs.setTextSize(
                    com.github.damontecres.wholphin.plavio.PlavioTextSize.next(uiPrefs.textSize.value),
                )
            }
        }

        /** Idle screen delay in minutes (v0.3.26 batch 5); 0 = Off. */
        val idleScreenMinutes: StateFlow<Int> = uiPrefs.idleScreenMinutes

        fun cycleIdleScreen() {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val options = com.github.damontecres.wholphin.plavio.IDLE_SCREEN_OPTIONS
                val idx = options.indexOf(uiPrefs.idleScreenMinutes.value)
                uiPrefs.setIdleScreenMinutes(options[(idx + 1) % options.size])
            }
        }

        /**
         * Audio passthrough (Adrian's ask): the value lives in the
         * shared AppPreferences playback overrides — the same store
         * the PlayerFactory reads when building the player. It was
         * first wired only into the stock Wholphin settings pages,
         * which this app's UI never shows, so the switch existed but
         * could not be found anywhere (owner report 2026-11-04).
         * This page is its real home. Turning it on clears downmix,
         * same as the stock preference: passthrough means the app
         * does not touch the audio at all.
         */
        val audioPassthrough: StateFlow<Boolean> =
            appPreferencesDataStore.data
                .map { it.playbackPreferences.overrides.audioPassthrough }
                .stateIn(CoroutineScope(viewModelScope.coroutineContext + CrashReports.backgroundScopeHandler), SharingStarted.Eagerly, false)

        fun setAudioPassthrough(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                runCatching {
                    appPreferencesDataStore.updateData { prefs ->
                        prefs.updatePlaybackOverrides {
                            if (enabled) downmixStereo = false
                            audioPassthrough = enabled
                        }
                    }
                }
            }
        }

        /** Streams rules (phone parity). */
        val qualityOrder: StateFlow<List<String>> = uiPrefs.qualityOrder
        val streamAutoplay: StateFlow<Boolean> = uiPrefs.streamAutoplay
        val autoplayQuality: StateFlow<String> = uiPrefs.autoplayQuality

        fun setQualityOrder(order: List<String>) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setQualityOrder(order) }
        }

        fun setStreamAutoplay(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setStreamAutoplay(enabled) }
        }

        fun setAutoplayQuality(value: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAutoplayQuality(value) }
        }

        /** Stream badge style + group toggles (phone parity). */
        val badgeStyle: StateFlow<String> = uiPrefs.badgeStyle
        val badgeGroupResolution: StateFlow<Boolean> = uiPrefs.badgeGroupResolution
        val badgeGroupHdr: StateFlow<Boolean> = uiPrefs.badgeGroupHdr
        val badgeGroupAudio: StateFlow<Boolean> = uiPrefs.badgeGroupAudio
        val badgeGroupLanguages: StateFlow<Boolean> = uiPrefs.badgeGroupLanguages
        val badgeGroupSourceCodec: StateFlow<Boolean> = uiPrefs.badgeGroupSourceCodec
        val badgeGroupSize: StateFlow<Boolean> = uiPrefs.badgeGroupSize

        fun setBadgeStyle(style: BadgeStyle) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeStyle(style.name) }
        }

        fun setBadgeGroupResolution(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupResolution(enabled) }
        }

        fun setBadgeGroupHdr(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupHdr(enabled) }
        }

        fun setBadgeGroupAudio(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupAudio(enabled) }
        }

        fun setBadgeGroupLanguages(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupLanguages(enabled) }
        }

        fun setBadgeGroupSourceCodec(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupSourceCodec(enabled) }
        }

        fun setBadgeGroupSize(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setBadgeGroupSize(enabled) }
        }

        // ---- v0.3.26 batch ----

        /** Per-device audio delay (Playback panel; the player sink applies it). */
        val audioDelayMs: StateFlow<Int> = uiPrefs.audioDelayMs

        fun setAudioDelayMs(value: Int) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAudioDelayMs(value) }
        }

        /** Stream-wait budget in seconds, 0 = Default (Streams panel). */
        val streamWaitSeconds: StateFlow<Int> = uiPrefs.streamWaitSeconds

        fun setStreamWaitSeconds(value: Int) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setStreamWaitSeconds(value) }
        }

        /** PrePlay background stream resolution (Playback panel, batch 6). */
        val prePlayEnabled: StateFlow<Boolean> = uiPrefs.prePlayEnabled

        fun setPrePlayEnabled(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setPrePlayEnabled(enabled) }
        }

        /** Auto Frame Rate display matching (Playback panel, batch 6). */
        val autoFrameRate: StateFlow<Boolean> = uiPrefs.autoFrameRate

        fun setAutoFrameRate(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAutoFrameRate(enabled) }
        }

        /** Fusion badge sources (badges panel) + their operation state. */
        val fusionSources: StateFlow<List<com.github.damontecres.wholphin.plavio.FusionBadgeSource>> =
            fusionStore.sources

        private val _fusionBusy = MutableStateFlow(false)
        val fusionBusy: StateFlow<Boolean> = _fusionBusy

        private val _fusionNote = MutableStateFlow<String?>(null)
        val fusionNote: StateFlow<String?> = _fusionNote

        private val _fusionNoteIsError = MutableStateFlow(false)
        val fusionNoteIsError: StateFlow<Boolean> = _fusionNoteIsError

        fun addFusionFromUrl(url: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                _fusionBusy.value = true
                fusionStore.addFromUrl(url)
                    .onSuccess { source ->
                        _fusionNoteIsError.value = false
                        _fusionNote.value = "Added ${source.label} — ${source.badgeCount} badges"
                    }
                    .onFailure { e ->
                        _fusionNoteIsError.value = true
                        _fusionNote.value = e.message ?: "That link didn't work"
                    }
                _fusionBusy.value = false
            }
        }

        fun addFusionFromText(text: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                _fusionBusy.value = true
                fusionStore.addFromText(text)
                    .onSuccess { source ->
                        _fusionNoteIsError.value = false
                        _fusionNote.value = "Added ${source.label} — ${source.badgeCount} badges"
                    }
                    .onFailure { e ->
                        _fusionNoteIsError.value = true
                        _fusionNote.value = e.message ?: "That JSON didn't work"
                    }
                _fusionBusy.value = false
            }
        }

        fun updateFusionSource(id: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                _fusionBusy.value = true
                fusionStore.update(id)
                    .onSuccess { source ->
                        _fusionNoteIsError.value = false
                        _fusionNote.value = "Updated ${source.label} — ${source.badgeCount} badges"
                    }
                    .onFailure { e ->
                        _fusionNoteIsError.value = true
                        _fusionNote.value = e.message ?: "Update failed"
                    }
                _fusionBusy.value = false
            }
        }

        fun deleteFusionSource(id: String) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                fusionStore.delete(id)
                _fusionNoteIsError.value = false
                _fusionNote.value = null
            }
        }

        /** New-episode alerts (phone parity, default on). */
        val episodeAlertsEnabled: StateFlow<Boolean> = uiPrefs.episodeAlertsEnabled

        fun setEpisodeAlertsEnabled(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setEpisodeAlertsEnabled(enabled) }
        }

        /** The shared subtitle style (same store the player's Style rail edits). */
        val subtitleStyle: StateFlow<com.github.damontecres.wholphin.plavio.SubtitleStyle> =
            subtitleStyleStore.style

        fun setAutoplayBestStream(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAutoplayBestStream(enabled) }
        }

        fun setAutoPlayNextEpisode(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAutoPlayNextEpisode(enabled) }
        }

        fun setSubtitleLanguages(languages: List<String>) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setSubtitleLanguages(languages) }
        }

        fun setPreferredAudioLanguage(language: String?) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setPreferredAudioLanguage(language) }
        }

        fun updateSubtitleStyle(
            transform: (com.github.damontecres.wholphin.plavio.SubtitleStyle) ->
                com.github.damontecres.wholphin.plavio.SubtitleStyle,
        ) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { runCatching { subtitleStyleStore.update(transform) } }
        }

        private val _updateState = MutableStateFlow<PlavioUpdateUiState>(PlavioUpdateUiState.Idle)
        val updateState: StateFlow<PlavioUpdateUiState> = _updateState

        fun installedVersionName(): String = updater.installedVersionName()

        fun setAccent(accent: PlavioAccent) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAccent(accent) }
        }

        fun setAutoUpdateCheck(enabled: Boolean) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) { uiPrefs.setAutoUpdateCheck(enabled) }
        }

        fun setSubtitleSize(sizeSp: Int) {
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                appPreferencesDataStore.updateData { prefs ->
                    val iface = prefs.interfacePreferences
                    prefs
                        .toBuilder()
                        .setInterfacePreferences(
                            iface
                                .toBuilder()
                                .setSubtitlesPreferences(
                                    iface.subtitlesPreferences
                                        .toBuilder()
                                        .setFontSize(sizeSp)
                                        .build(),
                                ).setHdrSubtitlesPreferences(
                                    iface.hdrSubtitlesPreferences
                                        .toBuilder()
                                        .setFontSize(sizeSp)
                                        .build(),
                                ).build(),
                        ).build()
                }
            }
        }

        fun checkForUpdate() {
            if (_updateState.value is PlavioUpdateUiState.Checking ||
                _updateState.value is PlavioUpdateUiState.Downloading
            ) {
                return
            }
            _updateState.value = PlavioUpdateUiState.Checking
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                val update =
                    runCatching { updater.checkForUpdate() }
                        .getOrElse {
                            _updateState.value = PlavioUpdateUiState.Failed
                            return@launch
                        }
                _updateState.value =
                    if (update != null) {
                        PlavioUpdateUiState.Available(update)
                    } else {
                        PlavioUpdateUiState.UpToDate
                    }
            }
        }

        fun installUpdate(update: TvUpdate) {
            _updateState.value = PlavioUpdateUiState.Downloading(null)
            viewModelScope.launch(CrashReports.backgroundScopeHandler) {
                var total = -1L
                val result =
                    runCatching {
                        updater.install(
                            update,
                            object : DownloadCallback {
                                override fun contentLength(contentLength: Long) {
                                    total = contentLength
                                }

                                override fun bytesDownloaded(bytes: Long) {
                                    _updateState.value =
                                        PlavioUpdateUiState.Downloading(
                                            if (total > 0) (bytes.toFloat() / total).coerceIn(0f, 1f) else null,
                                        )
                                }
                            },
                        )
                    }.getOrElse { UpdateInstallResult.Failed(it.message) }
                // Every outcome lands in a visible terminal state —
                // v0.3.x left this screen stuck on "Downloading…"
                // forever because install() swallowed its failures.
                _updateState.value =
                    when (result) {
                        UpdateInstallResult.Launched -> PlavioUpdateUiState.Idle
                        UpdateInstallResult.NeedsInstallPermission ->
                            PlavioUpdateUiState.NeedsPermission(update)
                        is UpdateInstallResult.Failed ->
                            PlavioUpdateUiState.InstallFailed(update)
                    }
            }
        }

        companion object {
            const val DEFAULT_SUBTITLE_SIZE_SP = 24
        }
    }
