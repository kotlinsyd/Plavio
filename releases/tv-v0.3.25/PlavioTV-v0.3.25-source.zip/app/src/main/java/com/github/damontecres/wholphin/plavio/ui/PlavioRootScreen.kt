package com.github.damontecres.wholphin.plavio.ui
import com.github.damontecres.wholphin.plavio.CrashReports

import androidx.compose.foundation.border
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlayerActivity
import kotlinx.coroutines.launch

/**
 * In-app destinations for the Plavio flow. v0.3.21 (the redesign):
 * ONE global stack for every browse destination — the root
 * destinations (Home, Search, Live, Library, Addons, Downloads,
 * Settings, Account) sit at the bottom and Detail / Actor / Streams
 * push on top of whichever root opened them, so Back always unwinds
 * to the opener and the capsule's selection is simply the nearest
 * root under the stack top. Play is rendered full-screen above
 * everything, as before.
 */
sealed interface PlavioDestination {
    data object Home : PlavioDestination

    data object Search : PlavioDestination

    data object Live : PlavioDestination

    data object Library : PlavioDestination

    data object Addons : PlavioDestination

    data object Downloads : PlavioDestination

    data object Settings : PlavioDestination

    data object Account : PlavioDestination

    data class Detail(
        val baseUrl: String,
        val type: String,
        val id: String,
        /** Preview art/name from the tapped card (v0.3.13): the Detail
         * loading state shows the title's own backdrop + name from the
         * first frame instead of a black "Loading…" screen. */
        val previewName: String? = null,
        val previewPoster: String? = null,
        val previewBackground: String? = null,
    ) : PlavioDestination

    data class Actor(
        val personId: Int,
        val name: String,
    ) : PlavioDestination

    data class Streams(
        val ref: StreamsRef,
    ) : PlavioDestination

    data class Play(
        val request: PlaybackRequest,
        /** Continue Watching resumes seek here; fresh plays start at 0. */
        val resumePositionMs: Long = 0,
    ) : PlavioDestination
}

/** True for the destinations the capsule's five buttons + profile own. */
private fun PlavioDestination.isRoot(): Boolean =
    when (this) {
        PlavioDestination.Home, PlavioDestination.Search, PlavioDestination.Live,
        PlavioDestination.Library, PlavioDestination.Addons, PlavioDestination.Downloads,
        PlavioDestination.Settings, PlavioDestination.Account,
        -> true
        else -> false
    }

/** The streams-screen reference for the item a [PlaybackRequest] belongs to. */
private fun streamsRefFor(request: PlaybackRequest): StreamsRef =
    StreamsRef(
        type = request.type,
        videoId = request.videoId,
        metaId = request.metaId,
        title = request.seriesName ?: request.title,
        poster = request.poster,
        backdrop = request.backdrop,
        season = request.season,
        episode = request.episode,
        episodeTitle = request.episodeTitle,
        seriesName = request.seriesName,
    )

/** Everything the streams screen (and the player after it) needs about a playable item. */
data class StreamsRef(
    val type: String,
    val videoId: String,
    val metaId: String,
    val title: String,
    val poster: String?,
    /** Wide art for the player's loading layer (v0.3.13); poster is the fallback. */
    val backdrop: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    val episodeTitle: String? = null,
    val seriesName: String? = null,
    /**
     * Player loading-face facts (v0.3.31 — the phone player's
     * locked loading look): the title logo, the quiet meta line's
     * parts (year source, runtime, genres, ★ rating) and the
     * "Starring …" cast names. Populated where a meta is at hand
     * (detail page, home hero); every other producer leaves the
     * defaults and the loading face simply omits what it lacks —
     * the phone's rule: a missing field never renders, nothing is
     * invented.
     */
    val logo: String? = null,
    val releaseInfo: String? = null,
    val runtime: String? = null,
    val genres: List<String> = emptyList(),
    val imdbRating: String? = null,
    val castNames: List<String> = emptyList(),
)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun PlavioRootScreen(
    modifier: Modifier = Modifier,
    rootViewModel: PlavioRootViewModel = hiltViewModel(),
    playerViewModel: PlavioPlayerViewModel = hiltViewModel(),
) {
    var showSplash by remember { mutableStateOf(true) }
    if (showSplash) {
        PlavioSplashScreen(
            onDone = { showSplash = false },
            modifier = modifier,
        )
        return
    }

    val stack =
        remember { mutableStateListOf<PlavioDestination>(PlavioDestination.Home) }
    // Settings can be opened straight onto a sub-page (Account's
    // "Connected services" row opens Integrations this way).
    var settingsStartPage by remember { mutableStateOf("main") }

    fun goRoot(dest: PlavioDestination) {
        stack.clear()
        stack.add(PlavioDestination.Home)
        if (dest != PlavioDestination.Home) stack.add(dest)
    }

    fun push(dest: PlavioDestination) {
        stack.add(dest)
    }

    val pendingUpdate by rootViewModel.pendingUpdate.collectAsState()
    val installing by rootViewModel.installing.collectAsState()
    // What's New (v0.3.26): shown under the update dialog in
    // priority — update first, then What's New, then the resume
    // prompt. v0.3.33 (owner order, EPISODE-WATCHED-MENU-SPEC item
    // 7): the server announcement no longer pops at open — the
    // remote config is still fetched and its seen-id still
    // tracked in the VM, but nothing here raises it as a dialog;
    // a server message must not interrupt app open.
    val whatsNewEntry by rootViewModel.whatsNewEntry.collectAsState()
    // TV look (owner design 2026-11-04, final shape): a Settings-only
    // choice — no first-start popup, no in-app offer (owner's cut).
    val lookMode by rootViewModel.lookMode.collectAsState()
    val lightLook = lookMode == com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_LIGHT
    val updateProblem by rootViewModel.updateProblem.collectAsState()
    LaunchedEffect(Unit) {
        rootViewModel.maybeCheckOnLaunch()
    }
    // Returning from the unknown-sources detour with the permission
    // granted continues into the installer on its own (v0.3.6).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        rootViewModel.onResumed()
        // v0.3.21 (study fix #5): re-open a play the ON_STOP standby
        // teardown tore down, if one is waiting — a no-op otherwise.
        runCatching { playerViewModel.resumeFromStandby() }
    }
    // The app left the foreground mid-playback (Home button, app
    // switch, TV standby): snapshot the play and tear the player
    // FULLY down through the release funnel (v0.3.21, study fix
    // #5 — the standby case file). The sound still dies on the
    // spot (stop() pauses synchronously — the 2026-11-04 "audio
    // keep playing back" fix holds), the position is saved, and
    // ON_RESUME above re-opens the play from the snapshot.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        if (stack.lastOrNull() is PlavioDestination.Play) {
            runCatching { playerViewModel.teardownForStandby() }
        }
    }
    // The update dialog's confirm button takes focus when it appears,
    // so the remote's centre press lands on Update (v0.3.6).
    // v0.3.14: the landing goes through the shared primitive — a
    // bounded retry that stands down when the dialog goes away —
    // instead of the old single blind shot.
    val updateButtonFocus = remember { FocusRequester() }
    LaunchedEffect(pendingUpdate) {
        if (pendingUpdate != null) {
            landFocus(
                requester = updateButtonFocus,
                isClaimed = { pendingUpdate == null },
                attempts = 6,
                delayMs = 120,
            )
        }
    }

    // ---- The focus scaffold (v0.3.14, the focus rebuild) -----------
    // The root owns the three things screens used to improvise:
    // (1) a requester per capsule destination, so focus can be sent
    //     INTO the capsule deterministically (edge door, Back door);
    // (2) the content-entry transfer holder screens register their
    //     own landing with (the return door — PlavioFocus.kt);
    // (3) the cross-screen memories that must outlive the
    //     AnimatedContent disposing a screen under a pushed child:
    //     Detail's armed restore records and Home's focus memory.
    val contentEntry = remember { ContentEntryFocus() }
    val capsuleRequesters =
        remember {
            listOf(
                PlavioDestination.Home,
                PlavioDestination.Search,
                PlavioDestination.Live,
                PlavioDestination.Library,
                PlavioDestination.Downloads,
                PlavioDestination.Settings,
                PlavioDestination.Account,
            ).associateWith { FocusRequester() }
        }
    var capsuleHasFocus by remember { mutableStateOf(false) }
    val detailRestores = remember { mutableMapOf<String, DetailRestore>() }
    val homeFocusMemory = remember { HomeFocusMemory() }
    val focusManager = LocalFocusManager.current
    val rootScope = rememberCoroutineScope()

    // ---- The capsule exit (v0.3.15 — HARD mechanism, three doors) --
    // v0.3.14's return door was a single hop of faith: the capsule
    // called the current screen's registered landing and trusted its
    // boolean. On Home that landing silently no-opped (its claim
    // read a stale latch — see CatalogRows.landHome), the transfer
    // still reported success, the Right key was consumed so geometry
    // never ran, and focus was welded into the capsule until a power
    // cycle. The exit is therefore no longer a hop of faith:
    //   step 1 — fire the screen's own scripted landing (it knows
    //     the remembered/exact target and scrolls it into view);
    //   step 2 — VERIFY, frame by frame, that focus actually LEFT
    //     the capsule. If it is still inside after a short head
    //     start, take it out GEOMETRICALLY (a Right move from the
    //     leftmost strip can only land in the content), retrying on
    //     later frames, and ask the screen once more at the end.
    // The ladder depends on nothing a screen can fail to register:
    // screens with no handler at all (Settings, Account) are rescued
    // by step 2 alone. All three doors — Right in the capsule,
    // re-selecting the current section, Back in the capsule — call
    // this one function.
    fun exitCapsuleToContent() {
        contentEntry.transfer()
        rootScope.launch(CrashReports.backgroundScopeHandler) {
            var nudges = 0
            repeat(20) { frame ->
                withFrameNanos { }
                if (!capsuleHasFocus) return@launch
                // Head start: frames 0–9 belong to the screen's own
                // landing. v0.3.16 (note 7): the window doubled from
                // 0–4 — Detail's restore scroll is instant now, but
                // its landing still composes a beat after the scroll,
                // and the geometric pushes that fired at frame 5 used
                // to land mid-flight, trip the page's claim sensor
                // and stand the scripted landing down (RIGHT from
                // the capsule's lower buttons "did nothing"; from
                // Home the rescue happened to land on stable hero
                // nodes, so it read as working). From frame 10, push
                // geometrically every 3 frames, at most 3 pushes —
                // the rescue still exists, it just speaks last.
                if (frame >= 10 && (frame - 10) % 3 == 0 && nudges < 3) {
                    focusManager.moveFocus(FocusDirection.Right)
                    nudges++
                }
            }
            if (capsuleHasFocus) {
                // Last resort: the screen may have registered late —
                // ask once more, then one final geometric push.
                contentEntry.transfer()
                withFrameNanos { }
                if (capsuleHasFocus) {
                    focusManager.moveFocus(FocusDirection.Right)
                }
            }
        }
    }

    BackHandler(enabled = stack.size > 1) {
        // Leaving the player: stop playback FIRST, synchronously, so
        // the picture and sound die on the press itself (owner report
        // 2026-11-04: closing the player took time and the video kept
        // playing in the background for a few seconds). The old order
        // popped first and let the player screen's onDispose stop the
        // player — but that only runs after the browse tree's heavy
        // first compose finishes, which on a weak TV is exactly those
        // few seconds, and sometimes reads as "back is stuck".
        // stop() pauses now and releases on a background thread; the
        // screen's own onDispose stop() remains as a harmless second
        // pass. Same activity-scoped instance the player screen uses
        // (this app keeps a custom back stack, not NavHost entries).
        if (stack.lastOrNull() is PlavioDestination.Play) {
            runCatching { playerViewModel.stop() }
        }
        stack.removeAt(stack.lastIndex)
    }

    // Back at a root destination opens the capsule (v0.3.14, the
    // reference behaviour the owner ordered): the landing is the
    // CURRENT section's own capsule button, via its requester —
    // deterministic, not geometric luck. When the capsule already
    // holds focus this handler stands down and Back falls through
    // to exit, exactly like the reference's open-panel Back.
    BackHandler(enabled = stack.size == 1 && !capsuleHasFocus) {
        val currentRoot = stack.lastOrNull { it.isRoot() } ?: PlavioDestination.Home
        capsuleRequesters[currentRoot]?.let { requester ->
            runCatching { requester.requestFocus() }
        }
    }

    pendingUpdate?.let { update ->
        AlertDialog(
            onDismissRequest = { rootViewModel.dismissUpdate() },
            title = {
                androidx.compose.material3.Text(
                    text = stringResource(R.string.plavio_update_available_title),
                )
            },
            text = {
                androidx.compose.material3.Text(
                    text =
                        when {
                            installing -> stringResource(R.string.plavio_update_downloading)
                            updateProblem == PlavioRootViewModel.UpdateProblem.PermissionNeeded ->
                                stringResource(R.string.plavio_update_permission_needed)
                            updateProblem == PlavioRootViewModel.UpdateProblem.Failed ->
                                stringResource(R.string.plavio_update_launch_failed)
                            else ->
                                stringResource(R.string.plavio_update_available_text, update.versionName) +
                                    (update.notes?.let { "\n\n$it" } ?: "")
                        },
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = { rootViewModel.installPendingUpdate() },
                    enabled = !installing,
                    modifier = Modifier.focusRequester(updateButtonFocus),
                ) {
                    androidx.compose.material3.Text(stringResource(R.string.plavio_update_now))
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { rootViewModel.dismissUpdate() },
                    enabled = !installing,
                ) {
                    androidx.compose.material3.Text(stringResource(R.string.plavio_update_later))
                }
            },
        )
    }

    // Announcements: REMOVED at open (v0.3.33, owner order — spec
    // item 7). The v0.3.26 one-shot server announcement dialog
    // that stood here is gone: the message must not interrupt app
    // open. The fetch + seen-id tracking stay in the VM/config;
    // no surface in this tree raises the announcement anymore.

    // What's New (v0.3.26, phone parity): shown once after an
    // update (the VM arms it), and re-openable from Settings →
    // About. Plain words, one Got it.
    val whatsNewFocus = remember { FocusRequester() }
    LaunchedEffect(whatsNewEntry, pendingUpdate) {
        if (whatsNewEntry != null && pendingUpdate == null) {
            landFocus(
                requester = whatsNewFocus,
                isClaimed = { whatsNewEntry == null },
                attempts = 6,
                delayMs = 120,
            )
        }
    }
    if (pendingUpdate == null &&
        stack.none { it is PlavioDestination.Play }
    ) {
        whatsNewEntry?.let { entry ->
            AlertDialog(
                onDismissRequest = { rootViewModel.dismissWhatsNew() },
                title = {
                    androidx.compose.material3.Text(
                        text = stringResource(R.string.plavio_whats_new_title),
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.Text(
                            text =
                                stringResource(
                                    R.string.plavio_whats_new_version,
                                    entry.versionName,
                                ),
                            fontWeight = FontWeight.SemiBold,
                        )
                        entry.lines.forEach { line ->
                            androidx.compose.material3.Text(text = "•  $line")
                        }
                    }
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(
                        onClick = { rootViewModel.dismissWhatsNew() },
                        modifier = Modifier.focusRequester(whatsNewFocus),
                    ) {
                        androidx.compose.material3.Text(
                            stringResource(R.string.plavio_whats_new_ok),
                        )
                    }
                },
            )
        }
    }

    // Profile picker (v0.3.26 batch 6): when more than one profile
    // exists, launch asks who's watching — once per launch, under
    // the update / What's New dialogs, and ABOVE
    // the resume prompt (the prompt reads the ACTIVE profile's
    // progress, so the pick comes first). Skippable: dismissing
    // keeps the remembered profile, which is the pre-focused row.
    val profiles by rootViewModel.profiles.collectAsState()
    val activeProfileId by rootViewModel.activeProfileId.collectAsState()
    var profilePickerOpen by remember { mutableStateOf(false) }
    var profilePickerHandled by remember { mutableStateOf(false) }
    val profilePickerFocus = remember { FocusRequester() }
    LaunchedEffect(profiles, pendingUpdate, whatsNewEntry) {
        if (!profilePickerHandled && !profilePickerOpen && profiles.size > 1 &&
            pendingUpdate == null && whatsNewEntry == null &&
            stack.none { it is PlavioDestination.Play }
        ) {
            profilePickerOpen = true
        }
    }
    LaunchedEffect(profilePickerOpen) {
        if (profilePickerOpen) {
            landFocus(
                requester = profilePickerFocus,
                isClaimed = { !profilePickerOpen },
                attempts = 6,
                delayMs = 120,
            )
        }
    }
    if (profilePickerOpen) {
        AlertDialog(
            onDismissRequest = {
                profilePickerOpen = false
                profilePickerHandled = true
            },
            title = {
                androidx.compose.material3.Text(
                    text = stringResource(R.string.plavio_profiles_picker_title),
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    profiles.forEach { profile ->
                        androidx.compose.material3.TextButton(
                            onClick = {
                                rootViewModel.setActiveProfile(profile.id)
                                profilePickerOpen = false
                                profilePickerHandled = true
                            },
                            modifier =
                                if (profile.id == activeProfileId) {
                                    Modifier.focusRequester(profilePickerFocus)
                                } else {
                                    Modifier
                                },
                        ) {
                            androidx.compose.material3.Text(
                                text =
                                    profile.name +
                                        if (profile.id == activeProfileId) " ✓" else "",
                            )
                        }
                    }
                }
            },
            confirmButton = {},
        )
    }

    // Launch resume prompt (v0.3.26): when the most recent
    // in-progress title exists at launch, offer to pick it back up
    // — once per launch, after the splash, and never while the
    // update dialog or a (standby-resumed) player owns the screen.
    // Continue takes the exact Continue Watching path: the entry's
    // own rebuilt request plus its saved position, so the player's
    // in-player resume prompt behaves identically.
    val progressEntries by rootViewModel.progressEntries.collectAsState()
    var launchResumeEntry by remember { mutableStateOf<ContinueWatchingEntry?>(null) }
    var launchResumeHandled by remember { mutableStateOf(false) }
    LaunchedEffect(
        progressEntries,
        pendingUpdate,
        whatsNewEntry,
        profilePickerOpen,
        profilePickerHandled,
        profiles,
    ) {
        if (!launchResumeHandled && launchResumeEntry == null && pendingUpdate == null &&
            whatsNewEntry == null &&
            // Batch 6: never race the profile picker — the prompt
            // must reflect the profile the user just picked (the
            // scoped progress flow re-emits on a switch).
            !profilePickerOpen && (profiles.size <= 1 || profilePickerHandled) &&
            stack.none { it is PlavioDestination.Play }
        ) {
            launchResumeEntry = progressEntries.firstOrNull()
        }
    }
    launchResumeEntry?.let { entry ->
        PlavioConfirmDialog(
            title =
                stringResource(
                    R.string.plavio_launch_resume_title,
                    entry.seriesName ?: entry.title,
                ),
            message =
                if (entry.type != "movie" && entry.episode > 0) {
                    stringResource(
                        R.string.plavio_launch_resume_episode,
                        entry.season,
                        entry.episode,
                    ) + (entry.episodeTitle?.let { " — $it" } ?: "")
                } else {
                    null
                },
            confirmText = stringResource(R.string.continue_string),
            dismissText = stringResource(R.string.plavio_launch_resume_dismiss),
            onConfirm = {
                launchResumeHandled = true
                launchResumeEntry = null
                push(
                    PlavioDestination.Play(
                        request = entry.toPlaybackRequest(),
                        resumePositionMs = entry.positionMs,
                    ),
                )
            },
            onDismiss = {
                launchResumeHandled = true
                launchResumeEntry = null
            },
        )
    }

    val top = stack.lastOrNull() ?: PlavioDestination.Home
    // The destination the BROWSE tree shows: the topmost non-Play
    // entry. While the player runs, browse keeps showing (and keeps
    // alive) exactly this screen underneath (v0.3.26 hang fix).
    val browseTop =
        stack.lastOrNull { it !is PlavioDestination.Play } ?: PlavioDestination.Home
    // The capsule's selection: the nearest root destination at or
    // below the stack top (Detail/Streams opened from Library keep
    // Library lit, and so on).
    val selectedRoot =
        stack.lastOrNull { it.isRoot() } ?: PlavioDestination.Home
    // The last Play destination, kept so the player stays composed (and
    // keeps playing) through its fade-out when playback closes and the
    // stack top has already moved on to the streams screen.
    var lastPlay by remember { mutableStateOf<PlavioDestination.Play?>(null) }
    LaunchedEffect(top) {
        if (top is PlavioDestination.Play) lastPlay = top
    }
    val reducedMotion = com.github.damontecres.wholphin.plavio.rememberReducedMotion()
    val isPlaying = top is PlavioDestination.Play
    // Text size + idle screen (v0.3.26 batch 5): the density wrap
    // below scales every Plavio screen's text by the Appearance
    // choice (Standard = today's rendering). The idle screen rests
    // browsing on a minimal clock after the chosen silence — the
    // pure IdleScreenLogic gates it: never while playing, never
    // over a root dialog. Any remote press (tracked on the root
    // box below) restarts the clock; the first press while it
    // shows only dismisses it, focus untouched.
    val textSize by rootViewModel.textSize.collectAsState()
    val idleMinutes by rootViewModel.idleScreenMinutes.collectAsState()
    var lastInteractionMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var idleVisible by remember { mutableStateOf(false) }
    val anyRootDialogShowing =
        pendingUpdate != null ||
            whatsNewEntry != null || launchResumeEntry != null
    LaunchedEffect(idleMinutes, isPlaying, anyRootDialogShowing) {
        while (true) {
            kotlinx.coroutines.delay(1_000)
            idleVisible =
                com.github.damontecres.wholphin.plavio.IdleScreenLogic.shouldShow(
                    idleMinutes = idleMinutes,
                    idleForMs = System.currentTimeMillis() - lastInteractionMs,
                    isPlaying = isPlaying,
                    dialogShowing = anyRootDialogShowing,
                )
        }
    }
    // Door three of the capsule exit (v0.3.15): Back while focus
    // sits in the capsule is a RETURN TO CONTENT, nothing else — it
    // must not pop the stack, must not fall through to the
    // Back-at-root-opens-capsule handler (disabled in this state
    // anyway), and must never exit the app out from under a user
    // who was only trying to leave the rail. Registered after the
    // two handlers above, so while enabled it is the one Back
    // consults first; while the capsule does not hold focus (or
    // the player owns the screen) it stands down completely.
    // v0.3.16 (note 12): the door now requires a page UNDER the
    // current one (stack.size > 1). At a root destination it used
    // to bounce Back into the content, the root handler then sent
    // the next Back into the capsule, and so on forever — Back at
    // the top level never exited and read as "not listened to,
    // needs many presses". At root with the capsule focused, Back
    // now falls through every handler to the system: the app exits,
    // the reference behaviour for an open panel at the top level.
    // Pushed pages (Detail, Streams…) keep the door exactly as
    // 0.3.15 built it.
    BackHandler(enabled = capsuleHasFocus && !isPlaying && stack.size > 1) {
        exitCapsuleToContent()
    }
    // Adaptive safe margins (owner's rule 2026-11-04: "should never
    // crop in small tv and in big screens — should be adaptive").
    // The edge insets are a PERCENTAGE of this TV's own screen, with
    // the hand-tuned values as the floor: a TV that crops its edges
    // (overscan) or a very large screen automatically gets more
    // room, a clean small screen keeps the designed look. Nothing
    // important ever sits in the crop zone, on any TV.
    val screenConfig = androidx.compose.ui.platform.LocalConfiguration.current
    val capsuleInset = maxOf(28.dp, screenConfig.screenWidthDp.dp * 0.03f)
    val browseBottomPad = maxOf(16.dp, screenConfig.screenHeightDp.dp * 0.03f)
    // Floating chrome, exact clearance (v0.3.12, owner's orders):
    // the side capsule and the top-left brand lockup are overlays —
    // the layout tree reserves no column for either — but NO card,
    // text or button may ever slide under the capsule's strip, and
    // the owner's verdict on both earlier builds was that the gap
    // left for it was too much. The browse start pad is therefore
    // EXACTLY the capsule's right edge + a 12dp breathing gap:
    // capsuleInset (its left offset) + 42dp (its slimmed width) +
    // 12dp. Since every card's left edge sits at or right of this
    // line and the capsule never extends past it, a card can never
    // intersect the capsule at any scroll position — and there is
    // no dead band either. The screens' own left insets were
    // normalised to zero where they merely repeated this margin
    // (their right insets stay), so the visible gap beside the
    // capsule really is ~12dp on every screen. Backdrop imagery
    // may still run full-bleed under the floating glass (the
    // Detail hero) — picture under glass is intended; cards, text
    // and buttons are what the clearance protects. The logo keeps
    // its exact spot, size and look, floating over the artwork;
    // text stays out from under it by sitting below its band (the
    // screens' top offsets) or right of it (hero text).
    // Focus hand-back (v0.3.10): no ROOT focus requester/restorer and
    // no rail focus groups (both stay removed — the focusGroup
    // experiment was the scroll-freeze suspect). But the v0.3.26
    // claim below that "focus survives the player on its own" proved
    // wrong on the owner's TV: the player's focused node leaves with
    // it and the landing screen holds nothing (his "scroll got
    // stuck" after Back). The hand-back lives in the browse screens:
    // they watch LocalPlavioPlayerActive and re-request their own
    // first focus target on the playing→stopped flip.
    // v0.3.26 (the owner's hang fix): the browse tree is NEVER thrown
    // away while the player runs — it stays composed underneath and
    // the player layers over it. The old swap disposed the whole
    // browse tree at Play and rebuilt it at Back; on a weak TV that
    // rebuild, landing in the same moment as the player's teardown,
    // was the "closing sticks / everything heavy after playing"
    // hang. Player open/close stays a HARD CUT (v0.3.5 fix) — no
    // alpha-animating layer ever wraps the player (the v0.3.3
    // crossfade put the SurfaceView under a fading layer and it
    // never composited: sound, black picture). Layering static
    // browse UNDER an opaque, non-animated player breaks neither
    // rule: the surface is born in the top layer at full alpha.
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    // Player activity mirror (v0.3.27): keep the process-wide
    // PlayerActivity signal in lockstep with the
    // LocalPlavioPlayerActive provided below, so ViewModels (which
    // live outside this composition) see the same player open /
    // close edges the browse screens see.
    LaunchedEffect(isPlaying) { PlayerActivity.set(isPlaying) }
    CompositionLocalProvider(
        LocalPlavioLightLook provides lightLook,
        LocalPlavioPlayerActive provides isPlaying,
        LocalPlavioContentEntry provides contentEntry,
        // Text size (v0.3.26 batch 5): font scale only — dp layout
        // sizes never move, so focus geometry and layouts hold.
        androidx.compose.ui.platform.LocalDensity provides
            androidx.compose.ui.unit.Density(
                density = baseDensity.density,
                fontScale =
                    baseDensity.fontScale *
                        com.github.damontecres.wholphin.plavio.PlavioTextSize.factorOf(textSize),
            ),
    ) {
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .onPreviewKeyEvent { event ->
                    // Idle bookkeeping (v0.3.26 batch 5): every
                    // remote press restarts the idle clock. While
                    // the idle screen shows, the first press is
                    // consumed by the dismissal alone — it never
                    // reaches the screen underneath, so the user
                    // returns to exactly where they were.
                    if (event.type == KeyEventType.KeyDown) {
                        lastInteractionMs = System.currentTimeMillis()
                        if (idleVisible) {
                            idleVisible = false
                            true
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                },
    ) {
        if (isPlaying) {
            // Playback owns the whole screen — no capsule, no brand.
            val playDest = (top as? PlavioDestination.Play) ?: lastPlay
            if (playDest != null) {
                PlavioPlayerScreen(
                    request = playDest.request,
                    resumePositionMs = playDest.resumePositionMs,
                    onResumeFailed = {
                        stack[stack.lastIndex] =
                            PlavioDestination.Streams(streamsRefFor(playDest.request))
                    },
                    onPlayNextEpisode = { next ->
                        stack[stack.lastIndex] = PlavioDestination.Play(next)
                    },
                    onZapChannel = { channel ->
                        rootViewModel.zapToChannel(channel, playDest.request.liveChannels) { resolved ->
                            stack[stack.lastIndex] = PlavioDestination.Play(resolved)
                        }
                    },
                    modifier = Modifier.fillMaxSize().zIndex(2f),
                )
            } else {
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .zIndex(2f)
                            .background(Color.Black),
                )
            }
        }
        Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
            ) {
                // Browse content: starts exactly at the capsule's
                // right edge + 12dp (see the geometry note at
                // capsuleInset above) — no card, text or button can
                // ever slide under the capsule strip, and no dead
                // band is left either.
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            // v0.3.28 (owner's order, 2026-11-16): on
                            // HOME this frame carries NO insets at
                            // all — the hero is full-bleed, spanning
                            // the entire screen underneath the
                            // floating capsule, and Home applies the
                            // capsule clearance inside its own layers
                            // (hero text, rows). Every other
                            // destination keeps the exact clearance
                            // geometry it has always had.
                            .padding(
                                start =
                                    if (browseTop == PlavioDestination.Home) {
                                        0.dp
                                    } else {
                                        capsuleInset + 54.dp
                                    },
                                bottom =
                                    if (browseTop == PlavioDestination.Home) {
                                        0.dp
                                    } else {
                                        browseBottomPad
                                    },
                            )
                            // The edge door (v0.3.14): a Left key that
                            // reaches this box unconsumed first tries
                            // an ordinary geometric move; only when
                            // NOTHING focusable sits further left does
                            // the door fire and send focus to the
                            // capsule button of the current section —
                            // deterministically, via its requester.
                            // Keys the focused control consumed itself
                            // (sliders, seek bars) never arrive here,
                            // and no focusGroup/focusRestorer is
                            // involved (the 2026-11-04 ban stands).
                            .onKeyEvent { event ->
                                if (event.type == KeyEventType.KeyDown &&
                                    event.key == Key.DirectionLeft
                                ) {
                                    if (focusManager.moveFocus(FocusDirection.Left)) {
                                        true
                                    } else {
                                        capsuleRequesters[selectedRoot]?.let { requester ->
                                            runCatching { requester.requestFocus() }
                                        }
                                        true
                                    }
                                } else {
                                    false
                                }
                            }
                            // NO focusGroup / focusRestorer here, and
                            // none on the capsule either (removed
                            // 2026-11-04): the groups added in v0.3.25
                            // to "help" rail crossing are what stopped
                            // the remote reaching the side rail at all
                            // on the owner's TV. Plain geometry — the
                            // v0.3.24 behaviour — is what worked there.
                ) {
                    AnimatedContent(
                        targetState = browseTop,
                        transitionSpec = {
                            if (reducedMotion) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else {
                                fadeIn(
                                    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                                ) togetherWith
                                    fadeOut(
                                        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                                    )
                            }
                        },
                        label = "destination",
                        modifier = Modifier.fillMaxSize(),
                    ) { dest ->
                        when (dest) {
                            PlavioDestination.Home -> {
                                PlavioHomeScreen(
                                    onManageAddons = { goRoot(PlavioDestination.Addons) },
                                    onItemClick = { row, item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = row.baseUrl,
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    onContinueWatchingClick = { entry ->
                                        push(
                                            PlavioDestination.Play(
                                                request = entry.toPlaybackRequest(),
                                                resumePositionMs = entry.positionMs,
                                            ),
                                        )
                                    },
                                    onPlayRequest = { request ->
                                        push(PlavioDestination.Play(request))
                                    },
                                    onEpisodeAlertClick = { alert ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = alert.baseUrl,
                                                type = "series",
                                                id = alert.metaId,
                                                previewName = alert.showName,
                                                previewPoster = alert.poster,
                                            ),
                                        )
                                    },
                                    focusMemory = homeFocusMemory,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Search -> {
                                PlavioSearchScreen(
                                    onItemClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = item.baseUrl,
                                                type = item.meta.type,
                                                id = item.meta.id,
                                                previewName = item.meta.name,
                                                previewPoster = item.meta.poster,
                                                previewBackground = item.meta.background,
                                            ),
                                        )
                                    },
                                    onPersonClick = { member ->
                                        push(
                                            PlavioDestination.Actor(
                                                personId = member.id,
                                                name = member.name,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Live -> {
                                PlavioLiveScreen(
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Library -> {
                                PlavioLibraryScreen(
                                    onItemClick = { type, metaId, name, poster, background ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = "",
                                                type = type,
                                                id = metaId,
                                                previewName = name,
                                                previewPoster = poster,
                                                previewBackground = background,
                                            ),
                                        )
                                    },
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    onOpenDownloads = { goRoot(PlavioDestination.Downloads) },
                                    onConnectServices = { goRoot(PlavioDestination.Account) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Addons -> {
                                PlavioSetupScreen(modifier = Modifier.fillMaxSize())
                            }

                            PlavioDestination.Downloads -> {
                                PlavioDownloadsScreen(
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Settings -> {
                                PlavioSettingsScreen(
                                    onOpenAddons = { goRoot(PlavioDestination.Addons) },
                                    onOpenAccount = { goRoot(PlavioDestination.Account) },
                                    startPage = settingsStartPage,
                                    onShowWhatsNew = { rootViewModel.showWhatsNew() },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Account -> {
                                PlavioAccountScreen(
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Actor -> {
                                PlavioActorScreen(
                                    destination = dest,
                                    onItemClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = "",
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Detail -> {
                                val detailKey = "${dest.baseUrl}|${dest.type}|${dest.id}"
                                PlavioDetailScreen(
                                    destination = dest,
                                    restoreRecord = detailRestores[detailKey],
                                    onArmRestore = { record ->
                                        if (record == null) {
                                            detailRestores.remove(detailKey)
                                        } else {
                                            detailRestores[detailKey] = record
                                        }
                                    },
                                    onWatchNow = { request ->
                                        push(PlavioDestination.Play(request))
                                    },
                                    onWatchMovie = { meta ->
                                        push(
                                            PlavioDestination.Streams(
                                                StreamsRef(
                                                    type = meta.type,
                                                    videoId = meta.id,
                                                    metaId = meta.id,
                                                    title = meta.name,
                                                    poster = meta.poster,
                                                    backdrop = meta.background,
                                                ),
                                            ),
                                        )
                                    },
                                    onEpisodeClick = { meta, video ->
                                        push(
                                            PlavioDestination.Streams(
                                                StreamsRef(
                                                    type = meta.type,
                                                    videoId = video.id,
                                                    metaId = meta.id,
                                                    title = meta.name,
                                                    poster = video.thumbnail ?: meta.poster,
                                                    backdrop = meta.background,
                                                    season = video.season,
                                                    episode = video.episode,
                                                    episodeTitle = video.title,
                                                    seriesName = meta.name,
                                                ),
                                            ),
                                        )
                                    },
                                    onActorClick = { member ->
                                        push(
                                            PlavioDestination.Actor(
                                                personId = member.id,
                                                name = member.name,
                                            ),
                                        )
                                    },
                                    onRelatedClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = dest.baseUrl,
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Streams -> {
                                PlavioStreamsScreen(
                                    ref = dest.ref,
                                    // The panel's saved resume position
                                    // rides into the Play destination —
                                    // the player's existing resume
                                    // prompt/start path consumes it.
                                    onPlay = { request, resumeMs ->
                                        push(
                                            PlavioDestination.Play(
                                                request = request,
                                                resumePositionMs = resumeMs,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Play -> {
                                // Handled above (full-screen).
                            }
                        }
                    }
                }
                // The floating capsule, vertically centred at the
                // left, drawn OVER the content (v0.3.12 — it
                // reserves no width; content runs beneath it). Its
                // inset is the adaptive safe margin (see
                // capsuleInset above) — at the old fixed 14dp the
                // TV's edge crop glued it to the corner and it
                // stopped reading as floating (owner photo
                // 2026-11-04).
                PlavioCapsule(
                    selected = selectedRoot,
                    onSelect = { dest ->
                        settingsStartPage = "main"
                        if (dest == selectedRoot && browseTop == dest) {
                            // Same-section click while already there:
                            // NOT a navigation — the scaffold must not
                            // rebuild the screen. It is door two of
                            // the capsule exit (v0.3.15): focus goes
                            // back into the content through the hard
                            // exit (the screen's landing, verified,
                            // with the geometric rescue behind it).
                            exitCapsuleToContent()
                        } else {
                            // A different destination owns its own
                            // landing — the scaffold never competes
                            // with the new screen's entry focus.
                            goRoot(dest)
                        }
                    },
                    requesters = capsuleRequesters,
                    onFocusWithin = { capsuleHasFocus = it },
                    onReturnToContent = { exitCapsuleToContent() },
                    modifier =
                        Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = capsuleInset),
                )
                // Brand (v0.3.26, the owner's approved lockup of
                // 2026-11-15 — wordmark-with-icon.png, "Perfect"):
                // on Home, the FULL lockup (Weave icon at the
                // front at PLAVIO cap height + the signature master
                // + tiny TV clear of the O) as ONE baked asset;
                // every other page carries the plain Weave icon
                // alone — no name, no disc, no background — at
                // 36dp. Both forms float (no space reserved,
                // nothing focusable). Placement (owner's correction,
                // 2026-11-15 evening): the LOCKUP's LEFT EDGE sits
                // exactly on the side capsule's LEFT EDGE — one
                // vertical line down the left side (capsuleInset,
                // passed in below). The plain icon on the other
                // pages keeps the older centre-line rule (its centre
                // on PlavioChrome.centreLine). The top gap keeps the
                // same adaptive floor as before so the art always
                // shows whole, never clipped, on the owner's TV.
                // Home rule (owner, 2026-11-15, corrected the same
                // evening): the lockup is STATIC — pinned at the
                // top-left at 60% of the last stable's size, always
                // shown. (An earlier same-day rule had it hide on
                // scroll; he superseded that — a fixed-hero Home
                // redesign is coming in a later batch, samples
                // first, and the small static lockup fits both.)
                // v0.3.29 (owner's order, 2026-11-16 — supersedes
                // the v0.3.28 Home-only removal): the top-left
                // corner brand (BrandBlock) is removed on EVERY
                // screen. His TV photo of the .28 Details page
                // showed the double logo — the corner icon above
                // the capsule's own Weave mark. The capsule's mark
                // is now the ONLY weave anywhere in the browse
                // tree; BrandBlock itself is gone entirely.
                // The version line is GONE (v0.3.30, owner's
                // order, 2026-11-16): the floating bottom-left
                // "V…" line (v0.3.16; kept off Home only in
                // v0.3.29 — his correction: the narrowing was
                // wrong) is drawn on NO screen at all. The
                // version detail is not needed anywhere in the
                // browse tree. The deliberate Settings → About
                // entry (a settings row, not this floating line)
                // is untouched.
            }
        // The idle screen (v0.3.26 batch 5): above browse, below
        // the player layer (zIndex 2) — and the logic above never
        // raises it during playback or over a dialog anyway. It is
        // not focusable; the root's preview key handler dismisses
        // it on the first press without moving focus.
        if (idleVisible) {
            PlavioIdleScreen(
                capsuleInset = capsuleInset,
                modifier =
                    Modifier
                        .fillMaxSize()
                        .zIndex(1.5f),
            )
        }
        }
    }
}

/**
 * The idle screen (v0.3.26 batch 5): a minimal black rest screen —
 * the signature wordmark small at the top-left (on the capsule's
 * line), a large clock and the date in the centre. Nothing here is
 * focusable and nothing here takes input; the root dismisses it on
 * any remote press. The clock re-reads the time every second.
 */
@Composable
private fun PlavioIdleScreen(
    capsuleInset: Dp,
    modifier: Modifier = Modifier,
) {
    var now by remember { mutableStateOf(java.time.LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = java.time.LocalDateTime.now()
            kotlinx.coroutines.delay(1_000)
        }
    }
    Box(modifier = modifier.background(Color.Black)) {
        Image(
            painter = painterResource(R.drawable.plavio_wordmark_signature),
            contentDescription = null,
            modifier =
                Modifier
                    .align(Alignment.TopStart)
                    .padding(start = capsuleInset, top = 36.dp)
                    .height(26.dp),
        )
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text =
                    now.format(
                        java.time.format.DateTimeFormatter.ofPattern("HH:mm"),
                    ),
                style =
                    MaterialTheme.typography.displayLarge.copy(
                        fontSize = 84.sp,
                    ),
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Text(
                text =
                    now.format(
                        java.time.format.DateTimeFormatter.ofPattern(
                            "EEEE d MMMM",
                            java.util.Locale.ENGLISH,
                        ),
                    ),
                style = MaterialTheme.typography.titleLarge,
                color = Color.White.copy(alpha = 0.7f),
            )
        }
    }
}

/*
 * v0.3.29: BrandBlock — the floating top-left corner brand (the
 * full lockup on Home in v0.3.26, the plain Weave icon elsewhere,
 * Home-only removal in v0.3.28) — is DELETED. The owner's order of
 * 2026-11-16 removes the corner logo on EVERY screen: his .28
 * Details photo showed it doubling the capsule's own Weave mark.
 * The capsule's mark is the only weave in the browse tree now.
 * The plavio_lockup_tv / plavio_mark drawables stay in res (the
 * capsule and the idle screen still use the mark/wordmark assets).
 */

/**
 * The floating glass capsule (v0.3.21, the owner's approved chrome):
 * a vertical glass pill floating over the content — icon-only
 * buttons in the mobile dock's icons (Home, Search, Live TV,
 * Library, Downloads since v0.3.26, Settings), and the user's
 * profile picture below a divider (opens Account). The pill is STATIC (v0.3.15, owner's
 * order): the slim icon strip at all times — no fold/unfold, no
 * labels on focus, no size animation anywhere near the focus
 * path (the v0.3.14 unfold experiment is cancelled; the owner
 * feared the animation could stick). NO brand
 * lockup (v0.3.29: the floating top-left corner block is removed
 * on every screen — this rail's own Weave mark, capping it, is
 * the only logo) — and, since v0.3.16 (note 3), NO version line either: the
 * version sits at the screen's bottom-left corner. Focus = the
 * travelling white fill (v0.3.16, note 2, Sample A "Slide"): a
 * white disc GLIDES inside the pill to the focused button; the
 * selected section carries no fill of its own — focus lives in
 * exactly one place at a time. Slimmed in v0.3.12 (owner's order): the
 * rail is 42dp wide in total — 32dp buttons + 2×5dp padding —
 * down from 64dp (48dp buttons + 2×8dp padding), ≈35% narrower;
 * it reserves no layout width either way.
 */
@Composable
private fun PlavioCapsule(
    selected: PlavioDestination,
    onSelect: (PlavioDestination) -> Unit,
    requesters: Map<PlavioDestination, FocusRequester>,
    onFocusWithin: (Boolean) -> Unit,
    onReturnToContent: () -> Unit,
    modifier: Modifier = Modifier,
    accountsViewModel: PlavioAccountsViewModel = hiltViewModel(),
    profileViewModel: PlavioProfileViewModel = hiltViewModel(),
) {
    val accountState by accountsViewModel.state.collectAsState()
    val photoBase64 by profileViewModel.profilePhotoBase64.collectAsState()
    val photoBitmap =
        remember(photoBase64) {
            photoBase64?.let { encoded ->
                runCatching {
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }.getOrNull()
            }
        }
    val email = accountState.plavioEmail
    // STATIC strip (v0.3.15, owner's order cancelling the
    // v0.3.14 unfold): the pill never changes size or content with
    // focus — no fold/unfold state, no labels appearing, no
    // animateContentSize. The container's onFocusChanged only
    // REPORTS focus entry/exit to the root (which arms the
    // capsule's Back door and the content's Left door).
    // The capsule carries NO brand lockup (v0.3.15, owner's order):
    // 0.3.14 showed the full lockup here AND the floating top-left
    // brand block at the same time — two logos on one screen.
    //
    // Travelling white (v0.3.16, note 2 — Sample A "Slide", the
    // owner's pick): a white disc GLIDES inside the pill to the
    // button that holds focus, eased; every button rests ghost and
    // the current section carries no fill of its own. Each button
    // reports its focus + its Y inside the pill through [glideTrack];
    // the disc is drawn behind the buttons and animates between the
    // reported positions. When focus leaves the rail the disc fades
    // out entirely — the white is never left standing on the last
    // button (the owner's report: "side buttons when i press it
    // stay white there, i need same like before, moving").
    var glideDest by remember { mutableStateOf<PlavioDestination?>(null) }
    val glideOffsets = remember { mutableMapOf<PlavioDestination, Float>() }
    val glideDensity = androidx.compose.ui.platform.LocalDensity.current
    val glideTargetY =
        with(glideDensity) { (glideDest?.let { glideOffsets[it] } ?: 0f).toDp() }
    val glideY by
        androidx.compose.animation.core.animateDpAsState(
            targetValue = glideTargetY,
            animationSpec =
                androidx.compose.animation.core.tween(
                    durationMillis = 240,
                    easing = FastOutSlowInEasing,
                ),
            label = "capsuleGlideY",
        )
    val glideAlpha by
        androidx.compose.animation.core.animateFloatAsState(
            targetValue = if (glideDest != null) 1f else 0f,
            animationSpec = androidx.compose.animation.core.tween(durationMillis = 160),
            label = "capsuleGlideAlpha",
        )
    fun glideTrack(dest: PlavioDestination): Modifier =
        Modifier
            .onGloballyPositioned { coords ->
                glideOffsets[dest] = coords.positionInParent().y
            }.onFocusChanged { if (it.isFocused) glideDest = dest }
    Column(
        modifier =
            modifier
                .onFocusChanged { state ->
                    onFocusWithin(state.hasFocus)
                    if (!state.hasFocus) glideDest = null
                }
                // Door one of the capsule exit (v0.3.15): Right from
                // any capsule item is the trip back into the page,
                // through the root's hard exit (the screen's own
                // landing, verified frame by frame, with a geometric
                // rescue that cannot be registered away). A PREVIEW
                // handler, so the door sees the key in the capture
                // phase — before the focused button or anything
                // under it can consume it — and the key is consumed
                // ALWAYS: Right inside the rail has no other sane
                // destination, and letting an unverified transfer
                // decide consumption was the v0.3.14 trap (the
                // transfer "succeeded", the key died, geometry
                // never ran).
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        event.key == Key.DirectionRight
                    ) {
                        onReturnToContent()
                        true
                    } else {
                        false
                    }
                },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(
            modifier =
                Modifier
                    .shadow(
                        // Light look: no shadow pass under the rail.
                        // 18dp (was 14): a clearer lift so the capsule
                        // reads as floating, not fixed to the edge.
                        elevation = if (LocalPlavioLightLook.current) 0.dp else 18.dp,
                        shape = RoundedCornerShape(50),
                        ambientColor = Color.Black,
                        spotColor = Color.Black,
                    )
                    .clip(RoundedCornerShape(50))
                    .background(
                        // Light look: the rail fill goes solid — no
                        // translucency to blend over moving rows.
                        if (LocalPlavioLightLook.current) {
                            PlavioOnyx.RailSolid
                        } else {
                            PlavioOnyx.RailGlass
                        },
                    )
                    .border(
                        1.dp,
                        PlavioOnyx.GlassBorder,
                        RoundedCornerShape(50),
                    )
                    // Width (v0.3.12, owner's order — "shrink it
                    // 35 percent"): the rail was 64dp wide in total
                    // (48dp buttons + 2×8dp padding); it is 42dp
                    // now (32dp buttons + 2×5dp padding) — the
                    // buttons shrink with it, icons and the profile
                    // photo scaled inside, focus rings unchanged
                    // (they draw inside the button bounds). That
                    // 42dp is the pill's width at ALL times
                    // (v0.3.15: the unfold is cancelled, so the pill
                    // can never reach toward the hero buttons the
                    // way the v0.3.14 unfolded pill did).
                    .padding(horizontal = 5.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box {
                // The travelling white disc (v0.3.16, note 2):
                // drawn behind the buttons, its Y animated to the
                // focused button's Y inside this box (the buttons'
                // own positions are reported in the same coordinate
                // space — the inner column below shares this box's
                // origin). Alpha 0 whenever focus is outside the
                // rail.
                Box(
                    modifier =
                        Modifier
                            .offset(y = glideY)
                            .size(32.dp)
                            .alpha(glideAlpha)
                            .background(Color.White, CircleShape),
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
            // The brand header (v0.3.28, owner's order,
            // 2026-11-16): the Weave mark ALONE caps the rail —
            // the mark on transparency, no tile, no background,
            // no text — in a slot the same 32dp width as every
            // button slot, so the pill does NOT widen. It is a
            // pure visual header: not focusable, not clickable,
            // no glide tracking — first focus in the rail stays
            // on Home, directly below it. The button order below
            // is unchanged.
            Image(
                painter = painterResource(R.drawable.plavio_mark),
                contentDescription = null,
                modifier = Modifier.size(32.dp),
            )
            CapsuleButton(
                icon = Icons.Filled.Home,
                selected = selected == PlavioDestination.Home,
                onClick = { onSelect(PlavioDestination.Home) },
                focusRequester = requesters[PlavioDestination.Home],
                glideModifier = glideTrack(PlavioDestination.Home),
            )
            CapsuleButton(
                icon = Icons.Filled.Search,
                selected = selected == PlavioDestination.Search,
                onClick = { onSelect(PlavioDestination.Search) },
                focusRequester = requesters[PlavioDestination.Search],
                glideModifier = glideTrack(PlavioDestination.Search),
            )
            CapsuleButton(
                icon = PlavioIcons.LiveTv,
                selected = selected == PlavioDestination.Live,
                onClick = { onSelect(PlavioDestination.Live) },
                focusRequester = requesters[PlavioDestination.Live],
                glideModifier = glideTrack(PlavioDestination.Live),
            )
            CapsuleButton(
                icon = PlavioIcons.MenuBook,
                selected = selected == PlavioDestination.Library,
                onClick = { onSelect(PlavioDestination.Library) },
                focusRequester = requesters[PlavioDestination.Library],
                glideModifier = glideTrack(PlavioDestination.Library),
            )
            // Downloads (v0.3.26, owner's order — Samples 4+5): the
            // Downloads screen existed since v0.3.19 but its only
            // door was a Library section that renders only after a
            // download COMPLETES, so running/paused downloads were
            // unreachable. It sits in the capsule like every other
            // section — after Library, before Settings — with the
            // app's own Download glyph, and takes the same
            // travelling-disc active treatment as its neighbours.
            CapsuleButton(
                icon = PlavioIcons.Download,
                selected = selected == PlavioDestination.Downloads,
                onClick = { onSelect(PlavioDestination.Downloads) },
                focusRequester = requesters[PlavioDestination.Downloads],
                glideModifier = glideTrack(PlavioDestination.Downloads),
            )
            CapsuleButton(
                icon = Icons.Filled.Settings,
                selected = selected == PlavioDestination.Settings,
                onClick = { onSelect(PlavioDestination.Settings) },
                focusRequester = requesters[PlavioDestination.Settings],
                glideModifier = glideTrack(PlavioDestination.Settings),
            )
            // Divider above the profile picture.
            Box(
                modifier =
                    Modifier
                        .width(22.dp)
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.18f)),
            )
            CapsuleProfileButton(
                photoBitmap = photoBitmap,
                initial = email?.firstOrNull()?.uppercase(),
                selected = selected == PlavioDestination.Account,
                onClick = { onSelect(PlavioDestination.Account) },
                focusRequester = requesters[PlavioDestination.Account],
                glideModifier = glideTrack(PlavioDestination.Account),
            )
            // v0.3.16 (note 3): the version line is OUT of the
            // pill again — the capsule carries no version at all.
            // It lives at the screen's bottom-left corner now (see
            // the root overlay), in the owner's picked SUBTLE form.
                }
            }
        }
    }
}

@Composable
private fun CapsuleButton(
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    glideModifier: Modifier = Modifier,
) {
    // Icon-only at all times (v0.3.15: the unfold is cancelled —
    // no labels ever render in the rail).
    // v0.3.16 (note 2, Sample A): the button itself NEVER fills —
    // it rests ghost (muted glyph on transparency) whether it is
    // the current section or not. Focus is drawn by the capsule's
    // travelling white disc BEHIND the buttons (see PlavioCapsule);
    // the focused button only flips its glyph to ink so it reads
    // dark on the white disc. No ring, no accent fill: the white
    // lives in exactly one place at a time.
    val ghost = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = Color(0xFF131320)
    Surface(
        onClick = onClick,
        modifier =
            Modifier
                .size(32.dp)
                .then(glideModifier)
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                ),
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = ghost,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = ink,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = ink,
            ),
    ) {
        // Centering: the frame is fixed (32dp since the v0.3.12
        // slimming) — the content box fills it outright and centres
        // the glyph in the frame.
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(19.dp),
            )
        }
    }
}

/** The capsule's bottom stop: the user's profile picture (or the
 * account initial / person glyph), opening the Account screen. */
@Composable
private fun CapsuleProfileButton(
    photoBitmap: android.graphics.Bitmap?,
    initial: String?,
    selected: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    glideModifier: Modifier = Modifier,
) {
    val accent = LocalPlavioAccent.current
    // Icon-only at all times, like CapsuleButton (v0.3.15: the
    // unfold is cancelled). v0.3.16 (note 2): same travelling-white
    // treatment — the button never fills; the capsule's white disc
    // glides behind it on focus (reading as a white ring around the
    // 24dp photo/initial), and the fallback glyph flips to ink.
    val ghost = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = Color(0xFF131320)
    Surface(
        onClick = onClick,
        modifier =
            Modifier
                .size(32.dp)
                .then(glideModifier)
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                ),
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = ghost,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = ink,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = ink,
            ),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            if (photoBitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = photoBitmap.asImageBitmap(),
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier =
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape),
                )
            } else if (initial != null) {
                Box(
                    modifier =
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(accent.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = initial,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = accent.onAccent(),
                    )
                }
            } else {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    modifier = Modifier.size(19.dp),
                )
            }
        }
    }
}
