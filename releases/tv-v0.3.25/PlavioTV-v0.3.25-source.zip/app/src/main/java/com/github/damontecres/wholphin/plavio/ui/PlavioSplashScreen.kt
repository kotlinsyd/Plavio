package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.rememberReducedMotion
import kotlinx.coroutines.delay

/**
 * Launch splash — the mobile startup, ported to TV (v0.3.25,
 * owner's order 2026-11-15: "new start animations use in tv as
 * well", superseding the TV-only Sample G clip rule).
 *
 * The composition is the mobile splash exactly (locked
 * 2026-11-13/14 on the phone): the PLAVIO signature wordmark
 * settled from the first frame on the flat (3,3,3) background,
 * the tagline "Your streaming universe" fading in once beneath
 * it and HOLDING, and the travelling pulse looping in its seat
 * under the tagline until the splash ends. No video, no poster,
 * no Weave mark. The wordmark asset is this tree's signature
 * wordmark (`plavio_wordmark_signature`) — the same brand
 * lettering the mobile splash draws. The only TV adaptation is
 * size: the wordmark spans 35% of the screen width, the width
 * the outgoing clip's lockup measured on the 1080p frame, so the
 * stack keeps its established TV scale.
 *
 * The Sample G clip (res/raw/splash_g_orbit_build.mp4) is
 * retired from the TV launch by this port; the asset stays in
 * the tree untouched, as it does on mobile.
 *
 * Exit rule (the TV splash's own, unchanged): a plain timer —
 * 2,400 ms, or 600 ms under reduced motion. The root shows this
 * splash INSTEAD of the browse tree (there is no feed-ready
 * signal to wait for on TV), so the pulse loops until the timer
 * ends the splash and Home appears.
 */
@Composable
fun PlavioSplashScreen(
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val reducedMotion = rememberReducedMotion()
    LaunchedEffect(reducedMotion) {
        delay(if (reducedMotion) 600 else 2_400)
        onDone()
    }

    // Tagline fade: starts invisible, fades in over ~0.8s once
    // the wordmark has had its beat (~0.5s in), then holds.
    val taglineAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(500)
        taglineAlpha.animateTo(1f, animationSpec = tween(durationMillis = 800))
    }

    Box(
        modifier
            .fillMaxSize()
            .background(Color(0xFF030303)),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier =
                Modifier
                    .align(Alignment.Center)
                    .offset(y = (-24).dp)
                    .fillMaxWidth(),
        ) {
            Image(
                painter = painterResource(R.drawable.plavio_wordmark_signature),
                contentDescription = "PLAVIO",
                modifier = Modifier.fillMaxWidth(0.35f),
            )
            Spacer(Modifier.height(18.dp))
            Text(
                text = "Your streaming universe",
                fontSize = 16.sp,
                letterSpacing = 1.5.sp,
                color = Color(0xFFC9C9D4),
                modifier = Modifier.alpha(taglineAlpha.value),
            )
            Spacer(Modifier.height(26.dp))
            TravellingPulse(modifier = Modifier.width(96.dp).height(16.dp))
        }
    }
}

/**
 * Travelling pulse — the mobile splash's loader, verbatim
 * (v0.14.47 on the phone, owner's pick): a faint resting line
 * spans the 96dp seat; one soft pulse of light travels along it
 * left→right and dissolves, rests a calm beat, and travels
 * again — period 1.5s (travel 40/45 of the period, rest 5/45),
 * looping seamlessly until the splash ends. The brightness
 * envelope is sin(π·p), zero at both travel ends, so the loop
 * point is invisible. Colours are the sample's: pale
 * lavender-white line (216,208,245) and pulse (222,214,252),
 * peak alpha 150/255. The wordmark and tagline are NOT part of
 * this animation — they arrive once and hold; only the pulse
 * loops. Reduced motion shows the resting line alone, static.
 */
@Composable
private fun TravellingPulse(modifier: Modifier = Modifier) {
    val reduced = rememberReducedMotion()
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(reduced) {
        if (reduced) {
            phase = 0f
            return@LaunchedEffect
        }
        val anim = Animatable(0f)
        while (true) {
            anim.snapTo(0f)
            anim.animateTo(
                1f,
                animationSpec = tween(durationMillis = 1500, easing = LinearEasing),
            ) { phase = value }
        }
    }
    Canvas(modifier) {
        val cy = size.height / 2f
        val lineColor = Color(0xFFD8D0F5)
        // The faint resting line, in the sample's two layers: a
        // wide, very faint glow pass under a thin core pass
        // (glow alpha 22/255, core alpha 52/255).
        drawLine(
            lineColor.copy(alpha = 22f / 255f),
            Offset(0f, cy),
            Offset(size.width, cy),
            strokeWidth = 3.5.dp.toPx(),
            cap = StrokeCap.Round,
        )
        drawLine(
            lineColor.copy(alpha = 52f / 255f),
            Offset(0f, cy),
            Offset(size.width, cy),
            strokeWidth = 1.dp.toPx(),
            cap = StrokeCap.Round,
        )
        if (reduced) return@Canvas
        // Travel occupies the first 40/45 of the period; the rest
        // is the calm beat with the envelope at zero.
        val travelFraction = 40f / 45f
        if (phase >= travelFraction) return@Canvas
        val p = phase / travelFraction
        val env = kotlin.math.sin(kotlin.math.PI * p).toFloat()
        if (env <= 0.02f) return@Canvas
        // The pulse: an elliptical radial sprite, 60×22dp in this
        // seat, travelling between 6dp margins with EaseInOutCubic
        // on its position.
        val margin = 6.dp.toPx()
        val x = margin + (size.width - 2 * margin) * EaseInOutCubic.transform(p)
        val blobW = 60.dp.toPx()
        val blobH = 22.dp.toPx()
        val peak = (150f / 255f) * env
        val blobColor = Color(0xFFDED6FC)
        withTransform({
            translate(x, cy)
            scale(1f, blobH / blobW, Offset.Zero)
        }) {
            drawCircle(
                brush =
                    Brush.radialGradient(
                        colorStops =
                            arrayOf(
                                0f to blobColor.copy(alpha = peak),
                                0.5f to blobColor.copy(alpha = peak * 0.60f),
                                0.75f to blobColor.copy(alpha = peak * 0.22f),
                                1f to Color.Transparent,
                            ),
                        center = Offset.Zero,
                        radius = blobW / 2f,
                    ),
                radius = blobW / 2f,
                center = Offset.Zero,
            )
        }
    }
}
