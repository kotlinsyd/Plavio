package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder

/**
 * Glyphs the tree's trimmed material-icons-core doesn't ship (Pause,
 * Subtitles, Audiotrack, and an apps grid for the Addons tray entry),
 * drawn as vectors in the same 24dp Material grid.
 */
object PlavioIcons {
    val Pause: ImageVector =
        materialIcon(name = "PlavioIcons.Pause") {
            materialPath {
                moveTo(6f, 19f)
                lineTo(10f, 19f)
                lineTo(10f, 5f)
                lineTo(6f, 5f)
                close()
                moveTo(14f, 5f)
                lineTo(14f, 19f)
                lineTo(18f, 19f)
                lineTo(18f, 5f)
                close()
            }
        }

    val Audiotrack: ImageVector =
        materialIcon(name = "PlavioIcons.Audiotrack") {
            materialPath {
                moveTo(12f, 3f)
                verticalLineTo(13.55f)
                curveToRelative(-0.59f, -0.34f, -1.27f, -0.55f, -2f, -0.55f)
                curveToRelative(-2.21f, 0f, -4f, 1.79f, -4f, 4f)
                reflectiveCurveToRelative(1.79f, 4f, 4f, 4f)
                reflectiveCurveToRelative(4f, -1.79f, 4f, -4f)
                verticalLineTo(7f)
                horizontalLineTo(18f)
                verticalLineTo(3f)
                lineTo(12f, 3f)
                close()
            }
        }

    val Subtitles: ImageVector =
        materialIcon(name = "PlavioIcons.Subtitles") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                roundedRect(3f, 4f, 18f, 16f, 2f)
                rect(6.8f, 9.8f, 3.4f, 1.7f)
                rect(12f, 9.8f, 5.2f, 1.7f)
                rect(6.8f, 13.4f, 3.4f, 1.7f)
                rect(12f, 13.4f, 5.2f, 1.7f)
            }
        }

    val AppsGrid: ImageVector =
        materialIcon(name = "PlavioIcons.AppsGrid") {
            materialPath {
                roundedRect(4f, 4f, 7f, 7f, 1.5f)
                roundedRect(13f, 4f, 7f, 7f, 1.5f)
                roundedRect(4f, 13f, 7f, 7f, 1.5f)
                roundedRect(13f, 13f, 7f, 7f, 1.5f)
            }
        }

    /** Arrow down into a tray — the Downloads tray entry and download actions. */
    val Download: ImageVector =
        materialIcon(name = "PlavioIcons.Download") {
            materialPath {
                moveTo(11f, 3f)
                lineTo(11f, 11.17f)
                lineTo(8.41f, 8.59f)
                lineTo(7f, 10f)
                lineTo(12f, 15f)
                lineTo(17f, 10f)
                lineTo(15.59f, 8.59f)
                lineTo(13f, 11.17f)
                lineTo(13f, 3f)
                close()
                moveTo(5f, 19f)
                lineTo(19f, 19f)
                lineTo(19f, 21f)
                lineTo(5f, 21f)
                close()
            }
        }

    /** Microphone — the Search screen's voice-search button. */
    val Mic: ImageVector =
        materialIcon(name = "PlavioIcons.Mic") {
            materialPath {
                // Capsule
                roundedRect(9f, 2f, 6f, 12f, 3f)
                // Holder: two arms and the curved bottom
                rect(5f, 10f, 2f, 6f)
                rect(17f, 10f, 2f, 6f)
                roundedRect(5f, 14f, 14f, 5f, 2.5f)
                // Stem and base
                rect(11f, 19f, 2f, 2f)
                rect(8f, 21f, 8f, 1.6f)
            }
        }

    /** TV with antenna — the Live tray entry. The glyph used to
     * span y 2.5→20 (its ink centre sat ~0.75dp above the 24dp
     * canvas centre — the one off-centre glyph in the set, found in
     * the v0.3.22 centering pass); every y is shifted +0.75 so the
     * ink centre lands on 12. */
    val LiveTv: ImageVector =
        materialIcon(name = "PlavioIcons.LiveTv") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                roundedRect(3f, 7.75f, 18f, 13f, 2f)
                rect(6f, 10.75f, 12f, 7f)
            }
            materialPath {
                moveTo(12f, 7.75f)
                lineTo(7.5f, 3.25f)
                lineTo(6.09f, 4.66f)
                lineTo(10.59f, 9.16f)
                close()
                moveTo(12f, 7.75f)
                lineTo(16.5f, 3.25f)
                lineTo(17.91f, 4.66f)
                lineTo(13.41f, 9.16f)
                close()
            }
        }

    /**
     * Open book — the Library capsule entry (the mobile dock's
     * MenuBook glyph, drawn in this file's EvenOdd style: cover
     * outline, centre spine, two page lines per side).
     */
    val MenuBook: ImageVector =
        materialIcon(name = "PlavioIcons.MenuBook") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                roundedRect(3f, 4.5f, 18f, 15f, 2f)
                roundedRect(5f, 6.5f, 14f, 11f, 1f)
            }
            materialPath {
                rect(11.4f, 6.5f, 1.2f, 11f)
                rect(6.8f, 9f, 3.4f, 1.1f)
                rect(6.8f, 11.6f, 3.4f, 1.1f)
                rect(13.8f, 9f, 3.4f, 1.1f)
                rect(13.8f, 11.6f, 3.4f, 1.1f)
            }
        }

    /** Skip-to-next — next episode actions. */
    val SkipNext: ImageVector =
        materialIcon(name = "PlavioIcons.SkipNext") {
            materialPath {
                moveTo(6f, 18f)
                lineTo(14.5f, 12f)
                lineTo(6f, 6f)
                close()
                moveTo(16f, 6f)
                lineTo(18f, 6f)
                lineTo(18f, 18f)
                lineTo(16f, 18f)
                close()
            }
        }

    /** Skip-to-previous — previous channel zapping. */
    val SkipPrevious: ImageVector =
        materialIcon(name = "PlavioIcons.SkipPrevious") {
            materialPath {
                moveTo(18f, 18f)
                lineTo(9.5f, 12f)
                lineTo(18f, 6f)
                close()
                moveTo(6f, 6f)
                lineTo(8f, 6f)
                lineTo(8f, 18f)
                lineTo(6f, 18f)
                close()
            }
        }

    /**
     * Material PlaylistPlay glyph — stacked episode lines with a
     * play triangle at the lower right. Used for the player's
     * Episodes button so it never reads as Sources' bullet List.
     */
    val PlaylistPlay: ImageVector =
        materialIcon(name = "PlavioIcons.PlaylistPlay") {
            materialPath {
                rect(3f, 6f, 11f, 2f)
                rect(3f, 10f, 11f, 2f)
                rect(3f, 14f, 7f, 2f)
                moveTo(16f, 13f)
                lineTo(16f, 21f)
                lineTo(22f, 17f)
                close()
            }
        }

    /** Double left chevrons — the visible seek-back button. */
    val Rewind: ImageVector =
        materialIcon(name = "PlavioIcons.Rewind") {
            materialPath {
                moveTo(11f, 18f)
                lineTo(11f, 6f)
                lineTo(3.5f, 12f)
                close()
                moveTo(20.5f, 18f)
                lineTo(20.5f, 6f)
                lineTo(13f, 12f)
                close()
            }
        }

    /** Double right chevrons — the visible seek-forward button. */
    val FastForward: ImageVector =
        materialIcon(name = "PlavioIcons.FastForward") {
            materialPath {
                moveTo(13f, 6f)
                lineTo(13f, 18f)
                lineTo(20.5f, 12f)
                close()
                moveTo(3.5f, 6f)
                lineTo(3.5f, 18f)
                lineTo(11f, 12f)
                close()
            }
        }

    /** Gauge needle — the playback speed button. */
    val Speed: ImageVector =
        materialIcon(name = "PlavioIcons.Speed") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                moveTo(12f, 4f)
                arcTo(8f, 8f, 0f, false, true, 20f, 12f)
                lineTo(18.2f, 12f)
                arcTo(6.2f, 6.2f, 0f, true, false, 12f, 5.8f)
                close()
                moveTo(13.4f, 8.6f)
                lineTo(11.2f, 13.4f)
                lineTo(12.6f, 14.8f)
                lineTo(14.8f, 10f)
                close()
            }
        }

    /** Rectangle in rectangle — the aspect/zoom button. */
    val Aspect: ImageVector =
        materialIcon(name = "PlavioIcons.Aspect") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                roundedRect(3f, 5f, 18f, 14f, 2f)
                rect(6f, 8f, 12f, 8f)
            }
        }

    /** Circular arrow — the Retry button. */
    val Restart: ImageVector =
        materialIcon(name = "PlavioIcons.Restart") {
            materialPath {
                moveTo(12f, 5f)
                verticalLineTo(1f)
                lineTo(7f, 6f)
                lineTo(12f, 11f)
                verticalLineTo(7f)
                curveTo(15.31f, 7f, 18f, 9.69f, 18f, 13f)
                curveToRelative(0f, 3.31f, -2.69f, 6f, -6f, 6f)
                curveToRelative(-3.31f, 0f, -6f, -2.69f, -6f, -6f)
                horizontalLineTo(4f)
                curveToRelative(0f, 4.42f, 3.58f, 8f, 8f, 8f)
                curveToRelative(4.42f, 0f, 8f, -3.58f, 8f, -8f)
                curveToRelative(0f, -4.42f, -3.58f, -8f, -8f, -8f)
                close()
            }
        }

    /**
     * Crescent moon — the player's Sleep timer button (v0.3.26).
     * One subpath built from cubic arcs: the outer circle (centre
     * 12,12, r 9) from its top-right tip around the left to the
     * bottom tip, closed by the inner circle's arc (centre 17,12,
     * r 7.5) bulging back through the middle — the two circles
     * meet at the tips (16.98, 4.5) and (16.98, 19.5).
     */
    val Sleep: ImageVector =
        materialIcon(name = "PlavioIcons.Sleep") {
            materialPath {
                moveTo(16.98f, 4.5f)
                curveTo(14.5f, 3.6f, 13f, 3.1f, 12f, 3f)
                curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f)
                curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
                curveTo(13f, 20.9f, 14.5f, 20.4f, 16.98f, 19.5f)
                curveTo(12.84f, 19.5f, 9.5f, 16.14f, 9.5f, 12f)
                curveTo(9.5f, 7.86f, 12.84f, 4.5f, 16.98f, 4.5f)
                close()
            }
        }

    /** Bar chart — the player's stats toggle (v0.3.26 batch 6). */
    val Stats: ImageVector =
        materialIcon(name = "PlavioIcons.Stats") {
            materialPath {
                moveTo(5f, 9.2f)
                lineTo(8f, 9.2f)
                lineTo(8f, 19f)
                lineTo(5f, 19f)
                close()
                moveTo(10.6f, 5f)
                lineTo(13.4f, 5f)
                lineTo(13.4f, 19f)
                lineTo(10.6f, 19f)
                close()
                moveTo(16.2f, 2f)
                lineTo(19f, 2f)
                lineTo(19f, 19f)
                lineTo(16.2f, 19f)
                close()
            }
        }

    /** Three horizontal dots — the Details page "more" button (v0.3.27). */
    val MoreHoriz: ImageVector =
        materialIcon(name = "PlavioIcons.MoreHoriz") {
            materialPath {
                moveTo(3f, 12f)
                arcTo(2f, 2f, 0f, false, true, 7f, 12f)
                arcTo(2f, 2f, 0f, false, true, 3f, 12f)
                close()
                moveTo(10f, 12f)
                arcTo(2f, 2f, 0f, false, true, 14f, 12f)
                arcTo(2f, 2f, 0f, false, true, 10f, 12f)
                close()
                moveTo(17f, 12f)
                arcTo(2f, 2f, 0f, false, true, 21f, 12f)
                arcTo(2f, 2f, 0f, false, true, 17f, 12f)
                close()
            }
        }

    /** Five-point star — the Live favourite marker + toggle (v0.3.26). */
    val Star: ImageVector =
        materialIcon(name = "PlavioIcons.Star") {
            materialPath {
                moveTo(12f, 2f)
                lineTo(14.65f, 8.36f)
                lineTo(21.51f, 8.91f)
                lineTo(16.28f, 13.39f)
                lineTo(17.88f, 20.09f)
                lineTo(12f, 16.5f)
                lineTo(6.12f, 20.09f)
                lineTo(7.72f, 13.39f)
                lineTo(2.49f, 8.91f)
                lineTo(9.35f, 8.36f)
                close()
            }
        }

    /** Speaker with an X — the Home hero's muted-trailer mark (v0.3.26). */
    val VolumeOff: ImageVector =
        materialIcon(name = "PlavioIcons.VolumeOff") {
            materialPath {
                // Speaker body.
                moveTo(3f, 9f)
                lineTo(7f, 9f)
                lineTo(12f, 4f)
                lineTo(12f, 20f)
                lineTo(7f, 15f)
                lineTo(3f, 15f)
                close()
                // The X: two crossing bars right of the speaker.
                moveTo(16.1f, 9.9f)
                lineTo(17.1f, 8.9f)
                lineTo(21.1f, 12.9f)
                lineTo(20.1f, 13.9f)
                close()
                moveTo(20.1f, 8.9f)
                lineTo(21.1f, 9.9f)
                lineTo(17.1f, 13.9f)
                lineTo(16.1f, 12.9f)
                close()
            }
        }

    /** Speaker with sound waves — the Home hero's trailer-sound-on mark (v0.3.31). */
    val VolumeUp: ImageVector =
        materialIcon(name = "PlavioIcons.VolumeUp") {
            materialPath {
                // Speaker body (same body as VolumeOff).
                moveTo(3f, 9f)
                lineTo(7f, 9f)
                lineTo(12f, 4f)
                lineTo(12f, 20f)
                lineTo(7f, 15f)
                lineTo(3f, 15f)
                close()
                // Inner wave.
                moveTo(15.5f, 8.7f)
                curveTo(16.6f, 9.5f, 17.3f, 10.7f, 17.3f, 12f)
                curveTo(17.3f, 13.3f, 16.6f, 14.5f, 15.5f, 15.3f)
                lineTo(14.7f, 14.5f)
                curveTo(15.5f, 13.8f, 15.9f, 13f, 15.9f, 12f)
                curveTo(15.9f, 11f, 15.5f, 10.2f, 14.7f, 9.5f)
                close()
                // Outer wave.
                moveTo(18.1f, 6.1f)
                curveTo(20.2f, 7.6f, 21.5f, 9.6f, 21.5f, 12f)
                curveTo(21.5f, 14.4f, 20.2f, 16.4f, 18.1f, 17.9f)
                lineTo(17.3f, 17.1f)
                curveTo(19f, 15.9f, 20f, 14.1f, 20f, 12f)
                curveTo(20f, 9.9f, 19f, 8.1f, 17.3f, 6.9f)
                close()
            }
        }

    /** Open eye — the Live "unhide channel" mark (v0.3.26). */
    val Eye: ImageVector =
        materialIcon(name = "PlavioIcons.Eye") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                // Eye outline.
                moveTo(2f, 12f)
                curveTo(5f, 6.5f, 8.5f, 4.5f, 12f, 4.5f)
                curveTo(15.5f, 4.5f, 19f, 6.5f, 22f, 12f)
                curveTo(19f, 17.5f, 15.5f, 19.5f, 12f, 19.5f)
                curveTo(8.5f, 19.5f, 5f, 17.5f, 2f, 12f)
                close()
                // Pupil, punched out by the even-odd fill.
                moveTo(12f, 9f)
                curveTo(13.66f, 9f, 15f, 10.34f, 15f, 12f)
                curveTo(15f, 13.66f, 13.66f, 15f, 12f, 15f)
                curveTo(10.34f, 15f, 9f, 13.66f, 9f, 12f)
                curveTo(9f, 10.34f, 10.34f, 9f, 12f, 9f)
                close()
            }
        }

    /** Eye with a slash — the Live "hide channel" mark (v0.3.26). */
    val EyeOff: ImageVector =
        materialIcon(name = "PlavioIcons.EyeOff") {
            materialPath(pathFillType = PathFillType.EvenOdd) {
                moveTo(2f, 12f)
                curveTo(5f, 6.5f, 8.5f, 4.5f, 12f, 4.5f)
                curveTo(15.5f, 4.5f, 19f, 6.5f, 22f, 12f)
                curveTo(19f, 17.5f, 15.5f, 19.5f, 12f, 19.5f)
                curveTo(8.5f, 19.5f, 5f, 17.5f, 2f, 12f)
                close()
                moveTo(12f, 9f)
                curveTo(13.66f, 9f, 15f, 10.34f, 15f, 12f)
                curveTo(15f, 13.66f, 13.66f, 15f, 12f, 15f)
                curveTo(10.34f, 15f, 9f, 13.66f, 9f, 12f)
                curveTo(9f, 10.34f, 10.34f, 9f, 12f, 9f)
                close()
                // Slash: filled outside the eye, a cut through it (even-odd).
                moveTo(4.6f, 3.1f)
                lineTo(20.9f, 19.4f)
                lineTo(19.4f, 20.9f)
                lineTo(3.1f, 4.6f)
                close()
            }
        }

    private fun PathBuilder.roundedRect(
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        r: Float,
    ) {
        moveTo(x + r, y)
        lineTo(x + w - r, y)
        curveToRelative(r, 0f, r, r, r, r)
        lineTo(x + w, y + h - r)
        curveToRelative(0f, r, -r, r, -r, r)
        lineTo(x + r, y + h)
        curveToRelative(-r, 0f, -r, -r, -r, -r)
        lineTo(x, y + r)
        curveToRelative(0f, -r, r, -r, r, -r)
        close()
    }

    private fun PathBuilder.rect(
        x: Float,
        y: Float,
        w: Float,
        h: Float,
    ) {
        moveTo(x, y)
        lineTo(x + w, y)
        lineTo(x + w, y + h)
        lineTo(x, y + h)
        close()
    }
}
