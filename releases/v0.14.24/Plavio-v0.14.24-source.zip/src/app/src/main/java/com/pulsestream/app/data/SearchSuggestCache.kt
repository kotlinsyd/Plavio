package com.pulsestream.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * On-device persistence for the Search landing grids (v0.14.28,
 * owner's Search-cache fix): the finished "You May Like This" grid
 * — and the "Popular now" backup grid — are saved the moment a fresh
 * grid lands, so the next Search open shows the saved grid INSTANTLY
 * instead of starting from zero while the background refresh runs.
 * A failed or empty refresh never overwrites the saved grid: the
 * only writes happen with a non-empty finished grid, and clearing
 * the search history clears these with it.
 *
 * The suggestions grid is keyed by the exact history terms it was
 * built from (the last five searches, in order): if the terms have
 * moved on, the saved grid is stale and is not shown — the fresh
 * build for the new terms replaces it when it lands.
 */
object SearchSuggestCache {
    private const val PREFS = "plavio_search_suggest"
    private const val KEY_TERMS = "like_terms"
    private const val KEY_LIKE = "like_grid"
    private const val KEY_LIKE_AT = "like_at"
    private const val KEY_POPULAR = "popular_grid"
    private const val KEY_POPULAR_AT = "popular_at"
    private const val MAX_ITEMS = 120

    private fun encode(items: List<CachedMeta>): String {
        val arr = JSONArray()
        for (item in items.take(MAX_ITEMS)) {
            val meta = item.meta
            val obj = JSONObject()
            obj.put("addonId", item.addonId)
            obj.put("addonName", item.addonName)
            obj.put("baseUrl", item.baseUrl)
            obj.put("id", meta.id)
            obj.put("type", meta.type)
            obj.put("name", meta.name)
            meta.poster?.let { obj.put("poster", it) }
            meta.background?.let { obj.put("background", it) }
            meta.logo?.let { obj.put("logo", it) }
            meta.description?.let { obj.put("description", it) }
            meta.releaseInfo?.let { obj.put("releaseInfo", it) }
            meta.imdbRating?.let { obj.put("imdbRating", it) }
            obj.put("genres", JSONArray(meta.genres))
            obj.put("popularity", meta.popularity)
            meta.originalLanguage?.let { obj.put("originalLanguage", it) }
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun decode(raw: String?): List<CachedMeta> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            val out = ArrayList<CachedMeta>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id").takeIf { it.isNotBlank() } ?: continue
                val type = obj.optString("type").takeIf { it.isNotBlank() } ?: continue
                val genres = mutableListOf<String>()
                val g = obj.optJSONArray("genres")
                if (g != null) for (j in 0 until g.length()) {
                    g.optString(j).takeIf { it.isNotBlank() }?.let { genres += it }
                }
                out += CachedMeta(
                    addonId = obj.optString("addonId"),
                    addonName = obj.optString("addonName"),
                    baseUrl = obj.optString("baseUrl"),
                    meta = MetaPreview(
                        id = id,
                        type = type,
                        name = obj.optString("name"),
                        poster = obj.optString("poster").ifBlank { null },
                        background = obj.optString("background").ifBlank { null },
                        logo = obj.optString("logo").ifBlank { null },
                        description = obj.optString("description").ifBlank { null },
                        releaseInfo = obj.optString("releaseInfo").ifBlank { null },
                        imdbRating = obj.optString("imdbRating").ifBlank { null },
                        genres = genres,
                        popularity = obj.optDouble("popularity", 0.0),
                        originalLanguage = obj.optString("originalLanguage")
                            .ifBlank { null }
                    )
                )
            }
            out
        }.getOrDefault(emptyList())
    }

    private fun termsKey(terms: List<String>): String =
        terms.map { it.trim().lowercase() }.joinToString("\n")

    /** The saved suggestions grid for exactly these [terms], or empty. */
    fun loadLike(context: Context, terms: List<String>): List<CachedMeta> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_TERMS, null) != termsKey(terms)) return emptyList()
        return decode(prefs.getString(KEY_LIKE, null))
    }

    /** Save a finished, non-empty suggestions grid. Empty grids never wipe. */
    fun saveLike(context: Context, terms: List<String>, items: List<CachedMeta>) {
        if (items.isEmpty()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TERMS, termsKey(terms))
            .putString(KEY_LIKE, encode(items))
            .putLong(KEY_LIKE_AT, System.currentTimeMillis())
            .apply()
    }

    fun loadPopular(context: Context): List<CachedMeta> =
        decode(
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_POPULAR, null)
        )

    fun savePopular(context: Context, items: List<CachedMeta>) {
        if (items.isEmpty()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_POPULAR, encode(items))
            .putLong(KEY_POPULAR_AT, System.currentTimeMillis())
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
