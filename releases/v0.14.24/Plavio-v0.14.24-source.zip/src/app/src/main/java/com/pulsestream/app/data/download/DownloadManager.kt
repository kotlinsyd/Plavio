package com.pulsestream.app.data.download

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.StatFs
import android.util.Log
import androidx.media3.common.MimeTypes
import com.pulsestream.app.data.PlaybackHeaders
import com.pulsestream.app.data.ResolvedSubtitle
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.Subtitle
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.DownloadItem
import com.pulsestream.app.data.detectSubtitleMimeType
import com.pulsestream.app.data.rankAutoPickCandidates
import com.pulsestream.app.data.resolveSubtitleFiles
import com.pulsestream.app.data.subtitleLangMatches
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.HttpUrl.Companion.toHttpUrl
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Downloader: progressive files (single-stream with Range resume, or
 * multi-connection segmented when the server honours Range), plus HLS
 * and DASH (segments fetched, then remuxed to one MP4). Live
 * manifests, SAMPLE-AES HLS and DRM-protected DASH are refused with
 * the reason on the download row.
 */
class DownloadManager private constructor(private val appContext: Context) {
    companion object {
        private const val TAG = "DownloadManager"
        const val LARGE_FILE_WARNING_BYTES = 500L * 1024 * 1024
        private const val STORAGE_RESERVE_BYTES = 32L * 1024 * 1024
        private const val MIN_SEGMENTED_BYTES = 16L * 1024 * 1024
        private const val SEGMENT_TARGET_BYTES = 8L * 1024 * 1024
        private const val SEGMENT_SPLIT_MIN_BYTES = 8L * 1024 * 1024
        private const val INITIAL_SEGMENT_WORKERS = 4
        private const val MAX_SEGMENT_WORKERS = 8
        private const val MAX_SEGMENT_FAILURES = 12
        private const val MAX_CONCURRENT_DOWNLOADS = 3
        private const val PREFS = "download_policy"
        private const val KEY_WIFI_ONLY = "wifi_only"

        @Volatile private var instance: DownloadManager? = null
        fun get(context: Context): DownloadManager = instance ?: synchronized(this) {
            instance ?: DownloadManager(context.applicationContext).also { instance = it }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val db: AppDatabase by lazy {
        (appContext as? com.pulsestream.app.PulseApp)?.database
            ?: throw IllegalStateException("PulseApp.database not available")
    }
    private val dao get() = db.downloadDao()
    private val prefs by lazy { appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followSslRedirects(false)
        .addNetworkInterceptor { chain ->
            chain.proceed(com.pulsestream.app.data.PlaybackHttp.scopedRequest(chain.request(), chain.call().request().url))
        }
        .connectionPool(okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES))
        .build()
    // Dedicated poster client (2026-10-28): plain GET with 10 s
    // timeouts — the main client above is playback-shaped (scoped
    // request interceptor, no SSL redirects), which poster CDNs
    // don't need and may not survive.
    private val posterClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()
    private val jobs = mutableMapOf<String, Job>()
    private val downloadPermits = Semaphore(MAX_CONCURRENT_DOWNLOADS)
    private val recoveryLock = Any()
    @Volatile private var recoveryRunning = false

    // Wi-Fi auto-resume (v0.12.1 fix): a download parked by the Wi-Fi-only
    // policy (or paused by a mid-download Wi-Fi drop) used to sit forever
    // until the user manually resumed it — nothing re-triggered it when
    // Wi-Fi returned. This callback relaunches exactly those items.
    @Volatile private var wifiCallbackRegistered = false
    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            if (isOnWifi()) resumeWifiBlockedDownloads()
        }
    }

    private fun ensureWifiCallback() {
        if (wifiCallbackRegistered) return
        wifiCallbackRegistered = true
        runCatching {
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(wifiCallback)
        }.onFailure { wifiCallbackRegistered = false }
    }

    private fun resumeWifiBlockedDownloads() {
        // P2 (v0.14.22): the Wi-Fi-blocked job ended itself and the
        // foreground service stopped with it — restart the service on
        // this resume path so the resumed downloads run protected
        // again, not on bare process lifetime.
        runCatching { DownloadService.start(appContext) }
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                dao.getAll().filter {
                    it.status == "QUEUED" ||
                        (it.status == "PAUSED" && it.error?.startsWith("Wi-Fi disconnected") == true)
                }
            }
            items.forEach { resumeDownload(it.id) }
        }
    }

    private val _activeDownloads = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val activeDownloads: StateFlow<Map<String, DownloadProgress>> = _activeDownloads.asStateFlow()

    data class DownloadProgress(val id: String, val downloadedBytes: Long, val totalBytes: Long, val status: String) {
        val fraction: Float get() = if (totalBytes > 0) (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f
    }

    fun downloadsDir(): File = File(appContext.getExternalFilesDir(null), "downloads").apply { mkdirs() }

    /**
     * Poster files for downloads (owner's order, 2026-10-28): a
     * `posters` folder NEXT TO the downloads folder — same
     * external-files root the media lives under, so posters persist
     * alongside the downloads and are removed with the app. One
     * "<downloadId>_poster.jpg" file per download.
     */
    fun downloadPostersDir(): File = File(downloadsDir().parentFile, "posters").apply { mkdirs() }

    /**
     * Best-effort poster fetch (2026-10-28): runs on the manager
     * scope after the download row exists, never on the download's
     * own path — any failure just leaves posterPath null and the
     * tiles fall back to the remote URL / placeholder.
     */
    private fun fetchAndStorePoster(downloadId: String, posterUrl: String) {
        scope.launch {
            runCatching {
                val request = Request.Builder().url(posterUrl).get().build()
                posterClient.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val bytes = resp.body?.bytes() ?: return@use
                    if (bytes.isEmpty()) return@use
                    val file = File(downloadPostersDir(), "${downloadId}_poster.jpg")
                    file.writeBytes(bytes)
                    dao.updatePoster(downloadId, posterUrl, file.absolutePath)
                }
            }.onFailure { Log.w(TAG, "Poster fetch failed for $downloadId: ${it.message}") }
        }
    }
    /**
     * Folder holding one download's saved subtitles (v0.14.14):
     * `downloads/subtitles/<downloadId>/<lang>_<n>.srt|.vtt`.
     */
    fun downloadSubtitlesDir(downloadId: String): File =
        File(downloadsDir(), "subtitles/$downloadId").apply { mkdirs() }

    private fun deleteSavedSubtitles(downloadId: String) {
        runCatching { File(downloadsDir(), "subtitles/$downloadId").deleteRecursively() }
    }

    /**
     * Subtitles saved beside a downloaded media file ("Save subtitles
     * with downloads"). Accepts the media file's file:// URL or plain
     * path — startDownload names media files "<downloadId>_<title>",
     * which is how the folder is found again. Every file is re-sniffed
     * with the resolver's content check, so a corrupt or foreign file
     * in the folder is never attached to the player.
     */
    fun savedSubtitlesForFile(mediaUrlOrPath: String): List<ResolvedSubtitle> {
        val mediaFile = File(mediaUrlOrPath.removePrefix("file://"))
        val downloadId = mediaFile.name.substringBefore("_", "")
        if (downloadId.isBlank()) return emptyList()
        val dir = File(downloadsDir(), "subtitles/$downloadId")
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && it.length() > 0L }
            ?.sortedBy { it.name }
            ?.mapNotNull { file ->
                runCatching {
                    val head = file.inputStream().use { input ->
                        val buf = ByteArray(4096)
                        val n = input.read(buf)
                        if (n <= 0) return@runCatching null
                        String(buf, 0, n, Charsets.UTF_8)
                    } ?: return@runCatching null
                    val mime = detectSubtitleMimeType(head) ?: return@runCatching null
                    val lang = file.name.substringBefore("_").ifBlank { "und" }
                    ResolvedSubtitle(
                        Subtitle(url = "file://" + file.absolutePath, lang = lang),
                        file,
                        mime
                    )
                }.getOrNull()
            }
            ?: emptyList()
    }

    /**
     * Picks the subtitles worth saving with a download: with language
     * preferences set, the best file of each preferred language (in
     * priority order); without, the best file of every language,
     * capped. Ranking reuses the player's auto-pick order — forced
     * files are still saved when they're all a language has (the
     * forced rule is an auto-SELECTION rule, not a saving rule).
     */
    private fun chooseDownloadSubtitles(
        candidates: List<Subtitle>,
        settings: SettingsStore
    ): List<Subtitle> {
        val prefs = settings.subtitleLanguages
        val preferSdh = settings.subtitlePreferSdh
        return if (prefs.isNotEmpty()) {
            prefs.mapNotNull { pref ->
                val inLang = candidates.filter { subtitleLangMatches(it.lang, pref) }
                rankAutoPickCandidates(inLang, { 0 }, preferSdh, forcedAutoShow = true)
                    .firstOrNull()
            }
        } else {
            candidates.groupBy { it.lang.lowercase() }
                .values
                .mapNotNull { inLang ->
                    rankAutoPickCandidates(inLang, { 0 }, preferSdh, forcedAutoShow = true)
                        .firstOrNull()
                }
                .take(12)
        }
    }

    /**
     * Best-effort subtitle fetch for a fresh download (v0.14.14): runs
     * on the manager scope after the row exists, never on the
     * download's own path — any failure just leaves the download
     * without saved subtitles. Candidates are the stream's bundled
     * subtitles plus, when the caller provided a search, the online
     * subtitle addons' results for the title.
     */
    private fun fetchAndStoreSubtitles(
        downloadId: String,
        type: String?,
        imdbId: String?,
        bundledSubtitles: List<Subtitle>,
        subtitleSearch: (suspend (String, String) -> List<Subtitle>)?
    ) {
        scope.launch {
            runCatching {
                val settings = SettingsStore(appContext)
                var candidates = bundledSubtitles
                if (!type.isNullOrBlank() && !imdbId.isNullOrBlank() && subtitleSearch != null) {
                    val found = runCatching { subtitleSearch(type, imdbId) }
                        .getOrDefault(emptyList())
                    candidates = (candidates + found).distinctBy { it.url }
                }
                if (candidates.isEmpty()) return@launch
                val chosen = chooseDownloadSubtitles(candidates, settings)
                if (chosen.isEmpty()) return@launch
                // Resolve into the shared subtitle cache first (download
                // + format sniff), then copy into the download's own
                // folder — the cache is pruned by version, the copy is
                // what offline playback reads.
                val resolved = resolveSubtitleFiles(chosen, appContext.cacheDir)
                if (resolved.isEmpty()) return@launch
                val dir = downloadSubtitlesDir(downloadId)
                resolved.forEachIndexed { index, r ->
                    val ext = if (r.mimeType == MimeTypes.TEXT_VTT) "vtt" else "srt"
                    val safeLang = r.sub.lang.lowercase()
                        .replace(Regex("[^a-z0-9-]"), "_")
                        .ifBlank { "und" }
                    val dest = File(dir, "${safeLang}_$index.$ext")
                    r.file.copyTo(dest, overwrite = true)
                }
            }.onFailure { Log.w(TAG, "Subtitle save failed for $downloadId: ${it.message}") }
        }
    }

    fun observeAll() = dao.observeAll()
    suspend fun getByUrl(url: String): DownloadItem? = dao.getByUrl(url)
    fun isWifiOnlyDownloads(): Boolean = prefs.getBoolean(KEY_WIFI_ONLY, false)
    fun setWifiOnlyDownloads(enabled: Boolean) { prefs.edit().putBoolean(KEY_WIFI_ONLY, enabled).apply() }
    fun storagePreflight(sizeBytes: Long?): Boolean =
        sizeBytes == null || sizeBytes <= 0 || DownloadProtocol.fitsWithReserve(
            availableBytes(), sizeBytes, STORAGE_RESERVE_BYTES
        )

    /** Used by confirmation UI; response Content-Type is also checked before saving. */
    fun isAdaptiveDownloadUrl(url: String): Boolean = DownloadProtocol.isAdaptive(decodeUrlForDetection(url))

    fun isHlsDownloadUrl(url: String): Boolean = DownloadProtocol.isHls(decodeUrlForDetection(url))

    fun isDashDownloadUrl(url: String): Boolean = DownloadProtocol.isDash(decodeUrlForDetection(url))

    /**
     * [posterUrl] (owner's order, 2026-10-28): the title's poster,
     * stored on the new row and fetched to a local file right after
     * the row is upserted, so Downloads/Library tiles show artwork
     * fully offline. Optional — callers with no poster in scope
     * pass nothing and the download behaves exactly as before.
     */
    suspend fun startDownload(
        url: String,
        title: String,
        headers: Map<String, String> = emptyMap(),
        posterUrl: String? = null,
        type: String? = null,
        imdbId: String? = null,
        bundledSubtitles: List<Subtitle> = emptyList(),
        subtitleSearch: (suspend (String, String) -> List<Subtitle>)? = null
    ): String {
        // Drop stale CANCELLED rows for this URL (left by older versions
        // whose cancel kept the row) so re-downloading starts clean.
        withContext(Dispatchers.IO) {
            dao.getAll().filter { it.url == url && it.status == "CANCELLED" }.forEach { stale ->
                runCatching { File(stale.filePath).delete() }
                runCatching { metadataFile(stale).delete() }
                runCatching { stale.posterPath?.let { poster -> File(poster).delete() } }
                deleteSavedSubtitles(stale.id)
                dao.deleteById(stale.id)
            }
        }
        val existing = withContext(Dispatchers.IO) { dao.getByUrl(url) }
        if (existing != null && existing.status != "CANCELLED") {
            when (existing.status) {
                "PAUSED", "FAILED" -> resumeDownload(existing.id)
                "QUEUED", "DOWNLOADING", "COMPLETED" -> Unit
            }
            return existing.id
        }
        val id = UUID.randomUUID().toString()
        val fileName = sanitizeFileName(title) + if (isHlsDownloadUrl(url) || isDashDownloadUrl(url)) ".mp4" else guessExtension(url)
        val file = File(downloadsDir(), "${id}_$fileName")
        val normalizedHeaders = normalizeRequestHeaders(headers)
        val item = DownloadItem(
            id = id, url = url, title = title, fileName = fileName,
            filePath = file.absolutePath,
            headersJson = JSONObject(normalizedHeaders as Map<*, *>).toString(),
            createdAt = System.currentTimeMillis(),
            posterUrl = posterUrl?.takeIf { it.isNotBlank() }
        )
        withContext(Dispatchers.IO) { dao.upsert(item) }
        // Poster fetch is asynchronous and best-effort (2026-10-28):
        // it never delays or fails the download itself.
        if (!item.posterUrl.isNullOrBlank()) fetchAndStorePoster(id, item.posterUrl)
        // Subtitle save is likewise async and best-effort (v0.14.14),
        // and only when the user turned "Save subtitles with
        // downloads" on in Settings > Subtitles.
        if (SettingsStore(appContext).subtitleSaveWithDownloads) {
            fetchAndStoreSubtitles(id, type, imdbId, bundledSubtitles, subtitleSearch)
        }
        launchDownload(item)
        return id
    }

    fun pauseDownload(id: String) {
        val activeJob = synchronized(jobs) {
            jobs.remove(id).also { it?.cancel() }
        }
        scope.launch {
            activeJob?.join()
            withContext(Dispatchers.IO) {
                val item = dao.getById(id)
                if (item != null && item.status in listOf("DOWNLOADING", "QUEUED")) dao.updateStatus(id, "PAUSED")
            }
            updateProgressFlow(id)
        }
    }

    fun pauseAll() {
        scope.launch {
            val items = withContext(Dispatchers.IO) { dao.getAll().filter { it.status == "DOWNLOADING" || it.status == "QUEUED" } }
            items.forEach { pauseDownload(it.id) }
        }
    }

    fun resumeQueuedDownloads() {
        scope.launch {
            val items = withContext(Dispatchers.IO) { dao.getAll().filter { it.status == "PAUSED" || it.status == "FAILED" || it.status == "QUEUED" } }
            items.forEach { resumeDownload(it.id) }
        }
    }

    fun resumeDownload(id: String) {
        scope.launch {
            val item = withContext(Dispatchers.IO) { dao.getById(id) } ?: return@launch
            if (item.status in listOf("PAUSED", "FAILED", "QUEUED")) {
                withContext(Dispatchers.IO) { dao.updateStatus(id, "QUEUED") }
                launchDownload(item.copy(status = "QUEUED"))
            }
        }
    }

    /** Requeue interrupted jobs after process/service death; paused jobs stay paused. */
    suspend fun recoverInterruptedDownloads() {
        synchronized(recoveryLock) {
            if (recoveryRunning) return
            recoveryRunning = true
        }
        try {
            val activeIds = synchronized(jobs) { jobs.filterValues { it.isActive }.keys.toSet() }
            val interrupted = withContext(Dispatchers.IO) {
                dao.getAll().filter { (it.status == "DOWNLOADING" || it.status == "QUEUED") && it.id !in activeIds }
            }
            for (item in interrupted) {
                withContext(Dispatchers.IO) { dao.updateStatus(item.id, "QUEUED") }
                launchDownload(item.copy(status = "QUEUED"))
            }
        } finally {
            synchronized(recoveryLock) { recoveryRunning = false }
        }
    }

    /**
     * Cancel = remove entirely (v0.12.1 fix): stop the job, delete the
     * partial file AND the database row. Previously the row was left
     * behind as an invisible CANCELLED zombie that nothing ever cleaned
     * up, while the UI's ✕ button didn't even call this (it opened the
     * delete dialog — see DownloadsScreen fix).
     */
    fun cancelDownload(id: String) {
        val active = synchronized(jobs) { jobs.remove(id).also { it?.cancel() } }
        scope.launch {
            active?.join()
            withContext(Dispatchers.IO) {
                val item = dao.getById(id)
                if (item != null) {
                    runCatching { File(item.filePath).delete() }
                    runCatching { metadataFile(item).delete() }
                    deleteDownloadWorkdirs(item)
                    runCatching { item.posterPath?.let { poster -> File(poster).delete() } }
                    deleteSavedSubtitles(id)
                    dao.deleteById(id)
                }
            }
            _activeDownloads.value = _activeDownloads.value - id
        }
    }

    suspend fun deleteDownload(id: String) {
        val active = synchronized(jobs) { jobs.remove(id).also { it?.cancel() } }
        active?.join()
        withContext(Dispatchers.IO) {
            val item = dao.getById(id)
            if (item != null) {
                runCatching { File(item.filePath).delete() }
                runCatching { metadataFile(item).delete() }
                deleteDownloadWorkdirs(item)
                runCatching { item.posterPath?.let { poster -> File(poster).delete() } }
                deleteSavedSubtitles(id)
                dao.deleteById(id)
            }
        }
        _activeDownloads.value = _activeDownloads.value - id
    }

    /** Recursive size of a download workdir (0 when absent). */
    private fun dirSizeBytes(dir: File): Long = runCatching {
        if (!dir.exists()) 0L
        else dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }.getOrDefault(0L)

    /** Deletes a download's segment sidecar + HLS/DASH workdirs (P14). */
    private fun deleteDownloadWorkdirs(item: DownloadItem) {
        runCatching { segmentsFile(item).delete() }
        runCatching { File(item.filePath + ".hls").deleteRecursively() }
        runCatching { File(item.filePath + ".dash").deleteRecursively() }
    }

    suspend fun storageUsedBytes(): Long = withContext(Dispatchers.IO) {
        dao.getAll().sumOf { item ->
            // P14 (v0.14.22): account for EVERYTHING a download owns —
            // main file, resume/segment sidecars, HLS/DASH segment
            // workdirs and the poster — not just the main file, which
            // under-reported worst exactly during big adaptive downloads.
            var total = runCatching {
                File(item.filePath).takeIf { it.exists() }?.length() ?: 0L
            }.getOrDefault(0L)
            total += runCatching { segmentsFile(item).takeIf { it.exists() }?.length() ?: 0L }.getOrDefault(0L)
            total += runCatching { metadataFile(item).takeIf { it.exists() }?.length() ?: 0L }.getOrDefault(0L)
            total += dirSizeBytes(File(item.filePath + ".hls"))
            total += dirSizeBytes(File(item.filePath + ".dash"))
            total += runCatching {
                item.posterPath?.let { File(it).takeIf { f -> f.exists() }?.length() } ?: 0L
            }.getOrDefault(0L)
            total
        }
    }

    /** True when free space exceeds the safety reserve (adaptive preflight). */
    fun hasStorageReserve(): Boolean = availableBytes() > STORAGE_RESERVE_BYTES

    suspend fun probeSize(url: String, headers: Map<String, String> = emptyMap()): Long = withContext(Dispatchers.IO) {
        try {
            val builder = Request.Builder().url(url).head()
            normalizeRequestHeaders(headers).forEach { (k, v) -> builder.header(k, v) }
            cancellableExecute(client.newCall(builder.build())).use { response ->
                if (response.isSuccessful) response.header("Content-Length")?.toLongOrNull() ?: -1L else -1L
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { Log.w(TAG, "Size probe failed: ${e.message}"); -1L }
    }

    private fun launchDownload(item: DownloadItem) {
        ensureWifiCallback()
        synchronized(jobs) {
            if (jobs[item.id]?.isActive == true) return
            _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                put(item.id, DownloadProgress(item.id, item.downloadedBytes, item.totalBytes, "QUEUED"))
            }
            val job = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    downloadPermits.withPermit {
                        if (isWifiOnlyDownloads() && !isOnWifi()) {
                            withContext(Dispatchers.IO) { dao.updateStatus(item.id, "QUEUED", "Waiting for Wi-Fi") }
                            updateProgressFlow(item.id)
                            _activeDownloads.value = _activeDownloads.value - item.id
                            return@withPermit
                        }
                        withContext(Dispatchers.IO) { dao.updateStatus(item.id, "DOWNLOADING") }
                        _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                            put(item.id, DownloadProgress(item.id, item.downloadedBytes, item.totalBytes, "DOWNLOADING"))
                        }
                        downloadFile(item)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "Download failed: ${item.id}", e)
                    withContext(Dispatchers.IO) { dao.updateStatus(item.id, "FAILED", e.message?.take(200)) }
                    updateProgressFlow(item.id)
                } finally {
                    synchronized(jobs) { jobs.remove(item.id) }
                }
            }
            jobs[item.id] = job
            job.start()
        }
    }

    private suspend fun downloadFile(item: DownloadItem) {
        val file = File(item.filePath)
        file.parentFile?.mkdirs()
        val headers = runCatching {
            JSONObject(item.headersJson).let { json -> buildMap { json.keys().forEach { k -> put(k, json.getString(k)) } } }
        }.getOrDefault(emptyMap())
        val normalizedHeaders = normalizeRequestHeaders(headers)
        if (DownloadProtocol.isHls(decodeUrlForDetection(item.url))) {
            downloadHls(item, file, normalizedHeaders)
            return
        }
        if (DownloadProtocol.isDash(decodeUrlForDetection(item.url))) {
            downloadDash(item, file, normalizedHeaders)
            return
        }
        val old = readMetadata(item)
        val segSidecar = segmentsFile(item)
        val hasSingleStreamPartial = file.exists() && file.length() > 0L && !segSidecar.exists() &&
            DownloadProtocol.ifRange(old.etag, old.lastModified) != null
        if (!hasSingleStreamPartial) {
            val probe = probeRangeSupport(item, normalizedHeaders)
            if (probe != null && (probe.total >= MIN_SEGMENTED_BYTES || segSidecar.exists())) {
                downloadSegmented(item, file, normalizedHeaders, probe)
                return
            }
            if (segSidecar.exists()) {
                // Segmented state exists but ranges are no longer honoured:
                // the pre-allocated file can't be trusted — start clean.
                segSidecar.delete()
                file.delete()
                metadataFile(item).delete()
            }
        }
        // Without a strong validator we cannot prove the resource is unchanged.
        val offset = if (file.exists() && DownloadProtocol.ifRange(old.etag, old.lastModified) != null) file.length() else 0L
        performDownload(item, file, normalizedHeaders, offset, old, allowCleanRestart = true)
    }

    private data class ResumeMetadata(val etag: String? = null, val lastModified: String? = null)

    private suspend fun performDownload(
        item: DownloadItem,
        file: File,
        headers: Map<String, String>,
        offset: Long,
        previous: ResumeMetadata,
        allowCleanRestart: Boolean
    ): Unit = coroutineScope {
        val request = Request.Builder().url(item.url).apply {
            headers.forEach { (key, value) -> header(key, value) }
            if (offset > 0) {
                header("Range", "bytes=$offset-")
                DownloadProtocol.ifRange(previous.etag, previous.lastModified)?.let { header("If-Range", it) }
            }
        }.build()
        val call = client.newCall(request)
        val cancellationWatcher = launch(start = CoroutineStart.UNDISPATCHED) {
            try { awaitCancellation() } finally { call.cancel() }
        }
        try {
            val response = withContext(Dispatchers.IO) { call.execute() }
            response.use { resp ->
            val responseType = resp.header("Content-Type")
            if (DownloadProtocol.isAdaptive(item.url, responseType)) {
                throw IOException("Unsupported offline format: this URL serves an HLS/DASH adaptive manifest, not a complete media file.")
            }
            val etag = resp.header("ETag")
            val modified = resp.header("Last-Modified")
            val isPartial = resp.code == 206
            val range = if (isPartial) DownloadProtocol.parseContentRange(resp.header("Content-Range"), offset) else null
            val rangeBytes = range?.let { it.endInclusive - it.start + 1 }
            val bodyLength = resp.body?.contentLength() ?: -1L
            val validatorMismatch = offset > 0 && DownloadProtocol.changedValidator(previous.etag, previous.lastModified, etag, modified)
            val invalidRange = isPartial && (range == null || (rangeBytes != null && bodyLength >= 0 && bodyLength != rangeBytes))

            if (offset > 0 && (!resp.isSuccessful || (isPartial && (invalidRange || validatorMismatch)))) {
                if (allowCleanRestart) {
                    Log.i(TAG, "Resume rejected; restarting ${item.id} from byte zero")
                    resp.close()
                    file.delete()
                    metadataFile(item).delete()
                    return@coroutineScope performDownload(item, file, headers, 0L, ResumeMetadata(), allowCleanRestart = false)
                }
                throw IOException("Server returned an invalid or inconsistent byte range; restart required")
            }
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: ${resp.message}")
            if (isPartial && (range == null || range.total == null)) throw IOException("Invalid Content-Range; refusing to append response bytes")

            // A successful 200 after a Range request means the server ignored
            // the range (or If-Range detected a changed object): overwrite safely.
            val startByte = if (isPartial) offset else 0L
            val totalBytes = if (isPartial) range?.total ?: -1L else bodyLength
            val body = resp.body ?: throw IOException("Empty response body")
            if (startByte == 0L) {
                val source = body.source()
                source.request(512L)
                val prefix = source.buffer.clone().readByteArray(minOf(512L, source.buffer.size))
                if (DownloadProtocol.isUnsupportedPayload(prefix)) throw IOException("This response is a playlist or error page, not a complete offline video.")
            }
            checkStorageSpace(totalBytes, startByte)
            val freshMetadata = ResumeMetadata(etag ?: previous.etag, modified ?: previous.lastModified)
            writeMetadata(item, freshMetadata)
            withContext(Dispatchers.IO) { dao.upsert(item.copy(totalBytes = totalBytes, downloadedBytes = startByte, status = "DOWNLOADING", error = null)) }

            var downloaded = startByte
            var lastDbUpdate = System.currentTimeMillis()
            RandomAccessFile(file, "rw").use { raf ->
                if (startByte == 0L) raf.setLength(0L)
                raf.seek(startByte)
                val buffer = ByteArray(256 * 1024)
                body.byteStream().use { input ->
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        if (isWifiOnlyDownloads() && !isOnWifi()) {
                            withContext(Dispatchers.IO) { dao.updateStatus(item.id, "PAUSED", "Wi-Fi disconnected; resume when Wi-Fi is available") }
                            _activeDownloads.value = _activeDownloads.value - item.id
                            return@coroutineScope
                        }
                        val count = input.read(buffer)
                        if (count == -1) break
                        if (availableBytes() < count + STORAGE_RESERVE_BYTES) throw IOException("Not enough free storage to continue this download.")
                        raf.write(buffer, 0, count)
                        downloaded += count
                        val now = System.currentTimeMillis()
                        if (now - lastDbUpdate > 500) {
                            lastDbUpdate = now
                            val bytesNow = downloaded
                            withContext(Dispatchers.IO) { dao.updateProgress(item.id, bytesNow, "DOWNLOADING") }
                            _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                                put(item.id, DownloadProgress(item.id, bytesNow, totalBytes, "DOWNLOADING"))
                            }
                        }
                    }
                }
                raf.fd.sync()
            }
            if (downloaded == startByte) throw IOException("The server returned no media bytes")
            if (bodyLength >= 0 && downloaded - startByte != bodyLength) throw IOException("Incomplete response body (${downloaded - startByte} of $bodyLength bytes)")
            if (range != null && downloaded != range.endInclusive + 1) throw IOException("Incomplete range response ending at byte ${downloaded - 1}")
            if (totalBytes > 0 && downloaded < totalBytes) throw IOException("Incomplete download: $downloaded / $totalBytes bytes")
            withContext(Dispatchers.IO) {
                // Room's markCompleted copies totalBytes into downloadedBytes;
                // persist the measured size first when the server gave no length.
                dao.upsert(item.copy(totalBytes = downloaded, downloadedBytes = downloaded, status = "DOWNLOADING", error = null))
                dao.markCompleted(item.id, System.currentTimeMillis())
                com.pulsestream.app.data.notifications.DownloadNotifications.postDownloadFinished(appContext, item.id, item.title)
            }
            _activeDownloads.value = _activeDownloads.value - item.id
            Log.i(TAG, "Download completed: ${item.id} ($downloaded bytes)")
            }
        } finally {
            cancellationWatcher.cancel()
        }
    }

    // ---------------------------------------------------------------------
    // Segmented (multi-connection) downloads
    //
    // When the server honours Range requests and the file is large enough,
    // the file is pre-allocated and fetched in parallel ranges: 4 workers
    // at first, ramping to 8 by splitting the largest unfinished range.
    // Per-range progress lives in a sidecar JSON so a paused or killed
    // download resumes each range where it stopped (validators checked).
    // ---------------------------------------------------------------------

    private data class RangeProbe(val total: Long, val etag: String?, val lastModified: String?)

    private class Segment(val start: Long, var end: Long, var done: Long = 0L) {
        var active: Boolean = false
        val remaining: Long get() = end - (start + done) + 1
        val complete: Boolean get() = remaining <= 0
    }

    private fun segmentsFile(item: DownloadItem) = File(item.filePath + ".segments.json")

    private suspend fun probeRangeSupport(item: DownloadItem, headers: Map<String, String>): RangeProbe? {
        val request = Request.Builder().url(item.url).apply {
            headers.forEach { (k, v) -> header(k, v) }
            header("Range", "bytes=0-0")
        }.build()
        val call = client.newCall(request)
        return try {
            val resp = withContext(Dispatchers.IO) { call.execute() }
            resp.use {
                if (it.code != 206) null
                else {
                    val range = DownloadProtocol.parseContentRange(it.header("Content-Range"), 0)
                    val total = range?.total
                    if (range == null || total == null) null
                    else RangeProbe(total, it.header("ETag"), it.header("Last-Modified"))
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Range probe failed: ${e.message}")
            null
        }
    }

    private fun loadSegments(sidecar: File, probe: RangeProbe, target: File): List<Segment>? = runCatching {
        if (!sidecar.exists() || !target.exists() || target.length() != probe.total) return null
        val json = JSONObject(sidecar.readText())
        if (json.getLong("total") != probe.total) return null
        val oldEtag = json.optString("etag").takeIf { it.isNotBlank() }
        val oldModified = json.optString("lastModified").takeIf { it.isNotBlank() }
        if (DownloadProtocol.changedValidator(oldEtag, oldModified, probe.etag, probe.lastModified)) return null
        val arr = json.getJSONArray("segments")
        val list = List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Segment(o.getLong("start"), o.getLong("end"), o.getLong("done"))
        }
        if (list.isEmpty() || list.first().start != 0L || list.last().end != probe.total - 1) null else list
    }.getOrNull()

    private fun saveSegments(sidecar: File, probe: RangeProbe, segments: List<Segment>, lock: Any) {
        runCatching {
            val snapshot = synchronized(lock) { segments.map { Triple(it.start, it.end, it.done) } }
            val arr = JSONArray()
            snapshot.forEach { (st, en, dn) ->
                arr.put(JSONObject().put("start", st).put("end", en).put("done", dn))
            }
            val json = JSONObject()
                .put("total", probe.total)
                .put("etag", probe.etag)
                .put("lastModified", probe.lastModified)
                .put("segments", arr)
            sidecar.writeText(json.toString())
        }
    }

    private suspend fun downloadSegmented(
        item: DownloadItem,
        file: File,
        headers: Map<String, String>,
        probe: RangeProbe
    ): Unit = coroutineScope {
        val sidecar = segmentsFile(item)
        val lock = Any()
        val segments = mutableListOf<Segment>()
        val resumed = loadSegments(sidecar, probe, file)
        if (resumed != null) {
            segments.addAll(resumed)
        } else {
            sidecar.delete()
            val count = (probe.total / SEGMENT_TARGET_BYTES).toInt().coerceIn(1, MAX_SEGMENT_WORKERS)
            val size = (probe.total + count - 1) / count
            var start = 0L
            while (start < probe.total) {
                val end = minOf(probe.total - 1, start + size - 1)
                segments.add(Segment(start, end))
                start = end + 1
            }
            withContext(Dispatchers.IO) {
                RandomAccessFile(file, "rw").use { it.setLength(probe.total) }
            }
        }
        writeMetadata(item, ResumeMetadata(probe.etag, probe.lastModified))
        saveSegments(sidecar, probe, segments, lock)
        fun downloadedNow(): Long = synchronized(lock) { segments.sumOf { it.done } }
        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = probe.total, downloadedBytes = downloadedNow(), status = "DOWNLOADING", error = null))
        }
        _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
            put(item.id, DownloadProgress(item.id, downloadedNow(), probe.total, "DOWNLOADING"))
        }

        val failures = AtomicBoolean(false)
        var failureCount = 0
        val wifiStop = AtomicBoolean(false)
        val workers = mutableListOf<Job>()

        suspend fun runWorker() {
            while (true) {
                currentCoroutineContext().ensureActive()
                if (wifiStop.get()) return
                val seg = synchronized(lock) {
                    segments.firstOrNull { !it.active && !it.complete }?.apply { active = true }
                } ?: return
                try {
                    downloadSegmentRange(item, file, headers, seg, lock, probe)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val n = synchronized(lock) { ++failureCount }
                    Log.w(TAG, "Segment at ${seg.start} failed: ${e.message}")
                    if (n > MAX_SEGMENT_FAILURES) {
                        failures.set(true)
                        throw IOException("Too many failed connections — download stopped")
                    }
                    delay(500)
                } finally {
                    synchronized(lock) { seg.active = false }
                }
            }
        }

        synchronized(lock) {
            repeat(INITIAL_SEGMENT_WORKERS) { workers += launch { runWorker() } }
        }
        val supervisor = launch {
            while (true) {
                delay(1000)
                if (isWifiOnlyDownloads() && !isOnWifi()) {
                    wifiStop.set(true)
                    break
                }
                saveSegments(sidecar, probe, segments, lock)
                val downloaded = downloadedNow()
                withContext(Dispatchers.IO) { dao.updateProgress(item.id, downloaded, "DOWNLOADING") }
                _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                    put(item.id, DownloadProgress(item.id, downloaded, probe.total, "DOWNLOADING"))
                }
                // Ramp: split the largest unfinished range and add a worker.
                val activeWorkers = synchronized(lock) { workers.count { it.isActive } }
                if (activeWorkers in 1 until MAX_SEGMENT_WORKERS) {
                    val split = synchronized(lock) {
                        val biggest = segments.filter { !it.complete }.maxByOrNull { it.remaining }
                        if (biggest != null && biggest.remaining > SEGMENT_SPLIT_MIN_BYTES) {
                            val mid = biggest.start + biggest.done + biggest.remaining / 2
                            val tail = Segment(mid, biggest.end)
                            biggest.end = mid - 1
                            segments.add(tail)
                            true
                        } else false
                    }
                    if (split) synchronized(lock) { workers += launch { runWorker() } }
                }
            }
        }
        try {
            while (true) {
                if (synchronized(lock) { segments.all { it.complete } }) break
                if (wifiStop.get()) {
                    saveSegments(sidecar, probe, segments, lock)
                    withContext(Dispatchers.IO) {
                        dao.updateStatus(item.id, "PAUSED", "Wi-Fi disconnected; resume when Wi-Fi is available")
                    }
                    _activeDownloads.value = _activeDownloads.value - item.id
                    return@coroutineScope
                }
                val anyWorkerAlive = synchronized(lock) { workers.any { it.isActive } }
                if (!anyWorkerAlive) throw IOException("Download stalled")
                delay(400)
            }
        } finally {
            supervisor.cancel()
            synchronized(lock) { workers.forEach { it.cancel() } }
        }
        if (failures.get()) throw IOException("Too many failed connections — download stopped")
        val downloaded = downloadedNow()
        if (downloaded != probe.total) throw IOException("Incomplete segmented download: $downloaded / ${probe.total} bytes")
        runCatching { withContext(Dispatchers.IO) { RandomAccessFile(file, "rw").use { it.fd.sync() } } }
        sidecar.delete()
        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = probe.total, downloadedBytes = probe.total, status = "DOWNLOADING", error = null))
            dao.markCompleted(item.id, System.currentTimeMillis())
                com.pulsestream.app.data.notifications.DownloadNotifications.postDownloadFinished(appContext, item.id, item.title)
        }
        _activeDownloads.value = _activeDownloads.value - item.id
        Log.i(TAG, "Download completed (segmented): ${item.id} (${probe.total} bytes)")
    }

    private suspend fun downloadSegmentRange(
        item: DownloadItem,
        file: File,
        headers: Map<String, String>,
        seg: Segment,
        lock: Any,
        probe: RangeProbe
    ) {
        val from = synchronized(lock) { seg.start + seg.done }
        val to = synchronized(lock) { seg.end }
        if (from > to) return
        val request = Request.Builder().url(item.url).apply {
            headers.forEach { (k, v) -> header(k, v) }
            header("Range", "bytes=$from-$to")
            // Resume verification (mobile overhaul): the same
            // If-Range discipline as the single-stream path — if the
            // file changed on the server since the probe, the server
            // answers 200 instead of 206 and the 206 check below
            // fails the segment loudly instead of splicing bytes from
            // two different files into one download.
            DownloadProtocol.ifRange(probe.etag, probe.lastModified)
                ?.let { header("If-Range", it) }
        }.build()
        val call = client.newCall(request)
        coroutineScope {
            val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
                try { awaitCancellation() } finally { call.cancel() }
            }
            try {
            val resp = withContext(Dispatchers.IO) { call.execute() }
            resp.use {
                if (it.code != 206) throw IOException("Range refused (HTTP ${it.code})")
                DownloadProtocol.parseContentRange(it.header("Content-Range"), from)
                    ?: throw IOException("Invalid Content-Range for segment")
                val body = it.body ?: throw IOException("Empty segment body")
                var written = synchronized(lock) { seg.done }
                var hitSplitEnd = false
                RandomAccessFile(file, "rw").use { raf ->
                    raf.seek(from)
                    val buffer = ByteArray(256 * 1024)
                    body.byteStream().use { input ->
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val allowed = synchronized(lock) { seg.end - (seg.start + written) + 1 }
                            if (allowed <= 0) {
                                hitSplitEnd = true
                                break
                            }
                            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), allowed).toInt())
                            if (count == -1) break
                            raf.write(buffer, 0, count)
                            written += count
                            synchronized(lock) { seg.done = written }
                        }
                    }
                }
                val remaining = synchronized(lock) { seg.remaining }
                if (!hitSplitEnd && remaining > 0) throw IOException("Segment ended early ($remaining bytes left)")
            }
            } finally {
                watcher.cancel()
            }
        }
    }

    // ---------------------------------------------------------------------
    // HLS downloads
    //
    // Fetch the playlist (highest-bandwidth variant of a master), download
    // every segment (3 at a time, AES-128 decrypted when keyed), join the
    // segments and remux to a single MP4 via MediaExtractor/MediaMuxer.
    // If the remux fails the joined stream is kept as-is — the player
    // sniffs the real format. VOD only: live playlists are refused.
    // ---------------------------------------------------------------------

    /**
     * R4 (v0.14.23): one media segment with the encryption state that
     * was in effect at its position in the playlist — HLS keys rotate
     * mid-playlist (#EXT-X-KEY applies to every segment that follows
     * it until the next one), so the key state is snapshotted per
     * segment at parse time instead of kept playlist-wide.
     */
    private data class HlsSegment(
        val url: String,
        val keyUrl: String?,
        val keyIv: ByteArray?
    )

    private data class HlsMedia(
        val segments: List<HlsSegment>,
        val initUrl: String?,
        val mediaSequence: Long,
        val sampleAes: Boolean
    ) {
        val segmentUrls: List<String> get() = segments.map { it.url }
    }

    private fun resolveHttpUrl(base: String, ref: String): String =
        runCatching { base.toHttpUrl().resolve(ref)?.toString() }.getOrNull() ?: ref

    /**
     * The download quality ceiling from the owner's stream settings
     * (P14, v0.14.22): the explicit autoplay quality bucket, or the
     * adaptive cap when quality is "Auto". Returns (maxHeightPx,
     * maxBandwidth) — Int.MAX_VALUE / Long.MAX_VALUE = no ceiling.
     */
    private fun downloadQualityCeiling(): Pair<Int, Long> {
        val settings = runCatching { SettingsStore(appContext) }.getOrNull()
            ?: return Int.MAX_VALUE to Long.MAX_VALUE
        val bucket = if (settings.autoplayQuality == "Auto") {
            settings.adaptiveQualityCap()
        } else {
            settings.autoplayQuality
        }
        return when (bucket) {
            "2160p" -> 2160 to Long.MAX_VALUE
            "1080p" -> 1080 to 12_000_000L
            "720p" -> 720 to 6_000_000L
            "480p" -> 480 to 2_500_000L
            else -> Int.MAX_VALUE to Long.MAX_VALUE
        }
    }

    private fun parseMasterPlaylist(text: String, base: String): String? {
        data class Variant(val bandwidth: Long, val height: Int, val url: String)
        val variants = mutableListOf<Variant>()
        var pendingBandwidth: Long? = null
        var pendingHeight = 0
        for (raw in text.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXT-X-STREAM-INF") -> {
                    pendingBandwidth = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull()
                    pendingHeight = Regex("RESOLUTION=\\d+x(\\d+)").find(line)
                        ?.groupValues?.get(1)?.toIntOrNull() ?: 0
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    variants += Variant(
                        pendingBandwidth ?: 0L, pendingHeight, resolveHttpUrl(base, line)
                    )
                    pendingBandwidth = null
                    pendingHeight = 0
                }
            }
        }
        if (variants.isEmpty()) return null
        // P14: honour the quality ceiling — the best variant AT or
        // BELOW it wins; only when everything is above it does the
        // lightest variant download (step down, never silently up).
        val (maxHeight, maxBandwidth) = downloadQualityCeiling()
        val under = variants.filter {
            (it.height == 0 || it.height <= maxHeight) && it.bandwidth <= maxBandwidth
        }
        return if (under.isNotEmpty()) {
            under.maxWithOrNull(compareBy({ it.height }, { it.bandwidth }))?.url
        } else {
            variants.minWithOrNull(compareBy({ it.height }, { it.bandwidth }))?.url
        }
    }

    private fun parseMediaPlaylist(text: String, base: String): HlsMedia {
        // R4 (v0.14.23): key state is a running snapshot — each
        // #EXT-X-KEY replaces it (METHOD=NONE clears it: following
        // segments are plain), and every segment records the state in
        // effect at its own position. The old single playlist-wide
        // keyUrl/keyIv made earlier segments decrypt with the LAST
        // key after a rotation, and kept a key active past METHOD=NONE.
        var keyUrl: String? = null
        var keyIv: ByteArray? = null
        var sampleAes = false
        var mediaSequence = 0L
        var initUrl: String? = null
        val segs = mutableListOf<HlsSegment>()
        for (raw in text.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:") ->
                    mediaSequence = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                line.startsWith("#EXT-X-KEY:") -> {
                    when (Regex("METHOD=([A-Z0-9-]+)").find(line)?.groupValues?.get(1)) {
                        "NONE" -> {
                            keyUrl = null
                            keyIv = null
                        }
                        "SAMPLE-AES" -> sampleAes = true
                        "AES-128" -> {
                            Regex("URI=\"([^\"]+)\"").find(line)?.groupValues?.get(1)
                                ?.let { keyUrl = resolveHttpUrl(base, it) }
                            // A rotated key without its own IV falls
                            // back to the media-sequence IV — never to
                            // the previous key's IV.
                            keyIv = Regex("IV=0x([0-9A-Fa-f]+)").find(line)?.groupValues?.get(1)?.let { hex ->
                                hex.padStart(32, '0').takeLast(32).chunked(2)
                                    .map { it.toInt(16).toByte() }.toByteArray()
                            }
                        }
                    }
                }
                line.startsWith("#EXT-X-MAP:") ->
                    Regex("URI=\"([^\"]+)\"").find(line)?.groupValues?.get(1)
                        ?.let { initUrl = resolveHttpUrl(base, it) }
                line.isNotEmpty() && !line.startsWith("#") ->
                    segs.add(HlsSegment(resolveHttpUrl(base, line), keyUrl, keyIv?.copyOf()))
            }
        }
        return HlsMedia(segs, initUrl, mediaSequence, sampleAes)
    }

    private suspend fun fetchBytes(url: String, headers: Map<String, String>): ByteArray? = coroutineScope {
        val request = Request.Builder().url(url).apply {
            headers.forEach { (k, v) -> header(k, v) }
        }.build()
        val call = client.newCall(request)
        val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
            try { awaitCancellation() } finally { call.cancel() }
        }
        try {
            withContext(Dispatchers.IO) { call.execute() }.use { resp ->
                if (!resp.isSuccessful) null else resp.body?.bytes()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } finally {
            watcher.cancel()
        }
    }

    private suspend fun fetchText(url: String, headers: Map<String, String>): String? =
        fetchBytes(url, headers)?.toString(Charsets.UTF_8)

    private fun decryptAes128(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return cipher.doFinal(data)
    }

    private fun sequenceIv(sequence: Long): ByteArray {
        val iv = ByteArray(16)
        var v = sequence
        for (i in 15 downTo 8) {
            iv[i] = (v and 0xFF).toByte()
            v = v shr 8
        }
        return iv
    }

    private suspend fun downloadHls(item: DownloadItem, target: File, headers: Map<String, String>) {
        val workDir = File(item.filePath + ".hls").apply { mkdirs() }
        var playlistUrl = item.url
        var text = fetchText(playlistUrl, headers)
            ?: throw IOException("Could not fetch the HLS playlist")
        if (text.contains("#EXT-X-STREAM-INF")) {
            playlistUrl = parseMasterPlaylist(text, playlistUrl)
                ?: throw IOException("No playable variant in the HLS playlist")
            text = fetchText(playlistUrl, headers)
                ?: throw IOException("Could not fetch the HLS variant playlist")
        }
        if (!text.contains("#EXT-X-ENDLIST")) {
            throw IOException("Live HLS streams can't be saved offline — only finished streams can.")
        }
        val media = parseMediaPlaylist(text, playlistUrl)
        if (media.segmentUrls.isEmpty()) throw IOException("The HLS playlist has no segments")
        if (media.sampleAes) throw IOException("This HLS stream uses SAMPLE-AES encryption, which can't be downloaded yet.")
        // R4 (v0.14.23): key bytes are cached per keyUrl — a playlist
        // that rotates keys fetches each distinct key once, and every
        // segment decrypts with its own snapshotted key.
        val keyBytesByUrl = mutableMapOf<String, ByteArray>()
        for (segmentKeyUrl in media.segments.mapNotNull { it.keyUrl }.distinct()) {
            keyBytesByUrl[segmentKeyUrl] = fetchBytes(segmentKeyUrl, headers)
                ?: throw IOException("Could not fetch the HLS encryption key")
        }

        // Resume state: segment index -> saved byte size.
        val sizesFile = File(workDir, "sizes.json")
        val sizes = mutableMapOf<Int, Long>()
        runCatching {
            val json = JSONObject(sizesFile.readText())
            json.keys().forEach { k -> sizes[k.toInt()] = json.getLong(k) }
        }
        val sizesLock = Any()
        fun saveSizes() {
            runCatching {
                val snapshot = synchronized(sizesLock) { sizes.toMap() }
                val json = JSONObject()
                snapshot.forEach { (k, v) -> json.put(k.toString(), v) }
                sizesFile.writeText(json.toString())
            }
        }
        fun segmentFile(index: Int) = File(workDir, "seg-%05d".format(index))
        fun downloadedNow(): Long = synchronized(sizesLock) { sizes.values.sum() }

        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = -1, downloadedBytes = downloadedNow(), status = "DOWNLOADING", error = null))
        }

        // Init segment (fMP4) first when present.
        if (media.initUrl != null) {
            val initFile = File(workDir, "seg-init")
            val known = synchronized(sizesLock) { sizes[-1] }
            if (known == null || !initFile.exists() || initFile.length() != known) {
                val bytes = fetchBytes(media.initUrl, headers)
                    ?: throw IOException("Could not fetch the HLS init segment")
                withContext(Dispatchers.IO) { initFile.writeBytes(bytes) }
                synchronized(sizesLock) { sizes[-1] = bytes.size.toLong() }
                saveSizes()
            }
        }

        val semaphore = Semaphore(3)
        coroutineScope {
            val jobs = media.segmentUrls.mapIndexed { index, segUrl ->
                async {
                    val out = segmentFile(index)
                    val known = synchronized(sizesLock) { sizes[index] }
                    if (known != null && out.exists() && out.length() == known) return@async
                    semaphore.withPermit {
                        if (availableBytes() < STORAGE_RESERVE_BYTES) {
                            throw IOException("Not enough free storage to continue this download.")
                        }
                        val raw = fetchBytes(segUrl, headers)
                            ?: throw IOException("Segment ${index + 1} of ${media.segmentUrls.size} failed to download")
                        val segment = media.segments[index]
                        val segmentKeyBytes = segment.keyUrl?.let { keyBytesByUrl[it] }
                        val plain = if (segmentKeyBytes != null) {
                            decryptAes128(raw, segmentKeyBytes, segment.keyIv ?: sequenceIv(media.mediaSequence + index))
                        } else raw
                        withContext(Dispatchers.IO) { out.writeBytes(plain) }
                        synchronized(sizesLock) { sizes[index] = plain.size.toLong() }
                        saveSizes()
                        val total = downloadedNow()
                        withContext(Dispatchers.IO) { dao.updateProgress(item.id, total, "DOWNLOADING") }
                        _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                            put(item.id, DownloadProgress(item.id, total, -1, "DOWNLOADING"))
                        }
                    }
                }
            }
            jobs.forEach { it.await() }
        }

        // Join segments (init first) and remux to MP4.
        val joined = File(item.filePath + ".joined")
        withContext(Dispatchers.IO) {
            FileOutputStream(joined).use { out ->
                if (media.initUrl != null) {
                    File(workDir, "seg-init").inputStream().use { it.copyTo(out) }
                }
                media.segmentUrls.indices.forEach { i ->
                    segmentFile(i).inputStream().use { it.copyTo(out) }
                }
            }
        }
        val remuxed = runCatching { remuxToMp4(joined, target) }.getOrDefault(false)
        if (!remuxed) {
            withContext(Dispatchers.IO) { joined.copyTo(target, overwrite = true) }
        }
        joined.delete()
        workDir.deleteRecursively()
        val size = target.length()
        if (size <= 0L) throw IOException("The HLS download produced an empty file")
        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = size, downloadedBytes = size, status = "DOWNLOADING", error = null))
            dao.markCompleted(item.id, System.currentTimeMillis())
                com.pulsestream.app.data.notifications.DownloadNotifications.postDownloadFinished(appContext, item.id, item.title)
        }
        _activeDownloads.value = _activeDownloads.value - item.id
        Log.i(TAG, "Download completed (HLS): ${item.id} ($size bytes)")
    }

    // ================= DASH (v0.14.13, item 5b) =================
    //
    // Supported manifest shapes (stated plainly, per the brief):
    //  - Static (VOD) MPDs, FIRST Period only.
    //  - SegmentTemplate with a fixed segment duration, or with a
    //    SegmentTimeline ($Number$ and $Time$ addressing both work).
    //  - SegmentList with explicit Initialization + SegmentURLs.
    //  - SegmentBase (single-file representations; the bytes from
    //    the init segment's start to EOF are kept, which is the
    //    whole standalone fMP4).
    //  - Best video representation + best audio representation,
    //    remuxed into one MP4 (stream copy, no re-encode).
    // Refused honestly: live/dynamic MPDs, DRM (ContentProtection),
    // multi-period MPDs beyond the first period, text/subtitle
    // representations (not downloaded), and templates whose segment
    // count can't be determined.

    private data class DashSegPlan(
        val initUrl: String?,
        val segmentUrls: List<String>,
        val singleFileUrl: String? = null,
        val singleFileSkip: Long = 0L
    )

    private data class DashTrackPlan(val kind: String, val plan: DashSegPlan)

    /** One source track chosen for the multi-source remux. */
    private data class RemuxPick(val ex: Int, val track: Int, val format: MediaFormat)

    private fun dashChildren(el: org.w3c.dom.Element, tag: String): List<org.w3c.dom.Element> {
        val out = mutableListOf<org.w3c.dom.Element>()
        val nodes = el.childNodes
        for (i in 0 until nodes.length) {
            val n = nodes.item(i)
            if (n is org.w3c.dom.Element && (tag == "*" || n.tagName == tag || n.tagName.endsWith(":$tag"))) {
                out += n
            }
        }
        return out
    }

    private fun dashFirst(el: org.w3c.dom.Element, tag: String): org.w3c.dom.Element? =
        dashChildren(el, tag).firstOrNull()

    private fun dashAttr(el: org.w3c.dom.Element?, name: String): String? =
        el?.getAttribute(name)?.takeIf { it.isNotBlank() }

    /** ISO-8601 duration ("PT1H2M3.5S", "P1DT…") → seconds, or null. */
    private fun parseIsoDuration(raw: String?): Double? {
        if (raw.isNullOrBlank()) return null
        val m = Regex("""P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?""")
            .matchEntire(raw.trim()) ?: return null
        val d = m.groupValues[1].toDoubleOrNull() ?: 0.0
        val h = m.groupValues[2].toDoubleOrNull() ?: 0.0
        val min = m.groupValues[3].toDoubleOrNull() ?: 0.0
        val s = m.groupValues[4].toDoubleOrNull() ?: 0.0
        return d * 86400 + h * 3600 + min * 60 + s
    }

    private fun dashSubstitute(
        template: String, repId: String?, bandwidth: Long, number: Long?, time: Long?
    ): String {
        var out = template.replace("$$", "")
        out = out.replace("$" + "RepresentationID$", repId ?: "")
        out = out.replace("$" + "Bandwidth$", bandwidth.toString())
        out = Regex("[$]Number%0(\\d+)d[$]").replace(out) {
            (number ?: 0).toString().padStart(it.groupValues[1].toIntOrNull() ?: 0, '0')
        }
        out = out.replace("$" + "Number$", (number ?: 0).toString())
        out = Regex("[$]Time%0(\\d+)d[$]").replace(out) {
            (time ?: 0).toString().padStart(it.groupValues[1].toIntOrNull() ?: 0, '0')
        }
        out = out.replace("$" + "Time$", (time ?: 0).toString())
        return out.replace("", "$")
    }

    /** Parse an MPD into per-kind track plans. Throws honest IOExceptions. */
    private fun parseDashMpd(xml: String, mpdUrl: String): List<DashTrackPlan> {
        val doc = runCatching {
            val factory = javax.xml.parsers.DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = false
                runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
                runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            }
            factory.newDocumentBuilder().parse(java.io.ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        }.getOrElse { throw IOException("Could not parse the DASH manifest") }
        val mpd = doc.documentElement ?: throw IOException("Empty DASH manifest")
        if (dashAttr(mpd, "type") == "dynamic") {
            throw IOException("Live DASH streams can't be saved offline — only finished streams can.")
        }
        val mpdDuration = parseIsoDuration(dashAttr(mpd, "mediaPresentationDuration"))
        var base = dashFirst(mpd, "BaseURL")?.textContent?.trim()
            ?.let { resolveHttpUrl(mpdUrl, it) } ?: mpdUrl

        val period = dashFirst(mpd, "Period")
            ?: throw IOException("The DASH manifest has no period")
        dashFirst(period, "BaseURL")?.textContent?.trim()?.let { base = resolveHttpUrl(base, it) }
        val periodDuration = parseIsoDuration(dashAttr(period, "duration")) ?: mpdDuration

        fun segTemplateOf(parent: org.w3c.dom.Element): org.w3c.dom.Element? =
            dashFirst(parent, "SegmentTemplate")
        fun segListOf(parent: org.w3c.dom.Element): org.w3c.dom.Element? =
            dashFirst(parent, "SegmentList")
        fun segBaseOf(parent: org.w3c.dom.Element): org.w3c.dom.Element? =
            dashFirst(parent, "SegmentBase")
        fun hasDrm(el: org.w3c.dom.Element): Boolean =
            dashChildren(el, "ContentProtection").isNotEmpty()

        data class RepChoice(
            val kind: String,
            val bandwidth: Long,
            val height: Int,
            val plan: DashSegPlan
        )
        val choices = mutableListOf<RepChoice>()

        for (asEl in dashChildren(period, "AdaptationSet")) {
            var asBase = base
            dashFirst(asEl, "BaseURL")?.textContent?.trim()?.let { asBase = resolveHttpUrl(asBase, it) }
            val asMime = dashAttr(asEl, "mimeType") ?: dashAttr(asEl, "contentType")
            val asTemplate = segTemplateOf(asEl) ?: segTemplateOf(period)
            val asList = segListOf(asEl) ?: segListOf(period)
            val asBaseSeg = segBaseOf(asEl) ?: segBaseOf(period)
            val asDrm = hasDrm(asEl)

            val reps = dashChildren(asEl, "Representation")
            val repEls = if (reps.isEmpty()) listOf(asEl) else reps
            for (repEl in repEls) {
                val isRep = repEl !== asEl
                var repBase = asBase
                if (isRep) {
                    dashFirst(repEl, "BaseURL")?.textContent?.trim()
                        ?.let { repBase = resolveHttpUrl(repBase, it) }
                }
                val mime = dashAttr(repEl, "mimeType") ?: asMime ?: ""
                val kind = when {
                    mime.startsWith("video") || dashAttr(repEl, "contentType") == "video" ||
                        dashAttr(asEl, "contentType") == "video" -> "video"
                    mime.startsWith("audio") || dashAttr(repEl, "contentType") == "audio" ||
                        dashAttr(asEl, "contentType") == "audio" -> "audio"
                    else -> continue // text/other representations are not downloaded
                }
                if (asDrm || (isRep && hasDrm(repEl))) continue // handled below via DRM check
                val repId = if (isRep) dashAttr(repEl, "id") else dashAttr(asEl, "id")
                val bandwidth = (if (isRep) dashAttr(repEl, "bandwidth") else null)
                    ?.toLongOrNull() ?: 0L
                val height = (if (isRep) dashAttr(repEl, "height") else null)
                    ?.toIntOrNull() ?: 0

                val template = (if (isRep) segTemplateOf(repEl) else null) ?: asTemplate
                val segList = (if (isRep) segListOf(repEl) else null) ?: asList
                val segBase = (if (isRep) segBaseOf(repEl) else null) ?: asBaseSeg

                val plan: DashSegPlan = when {
                    segBase != null -> {
                        val range = dashFirst(segBase, "Initialization")
                            ?.let { dashAttr(it, "range") }
                        val start = range?.substringBefore('-')?.toLongOrNull() ?: 0L
                        DashSegPlan(null, emptyList(), singleFileUrl = repBase, singleFileSkip = start)
                    }
                    segList != null -> {
                        val init = dashFirst(segList, "Initialization")
                            ?.let { dashAttr(it, "sourceURL") }
                            ?.let { resolveHttpUrl(repBase, it) }
                        val urls = dashChildren(segList, "SegmentURL")
                            .mapNotNull { dashAttr(it, "media") }
                            .map { resolveHttpUrl(repBase, it) }
                        if (urls.isEmpty()) continue
                        DashSegPlan(init, urls)
                    }
                    template != null -> {
                        val media = dashAttr(template, "media")
                            ?: continue
                        val startNumber = dashAttr(template, "startNumber")?.toLongOrNull() ?: 1L
                        val timescale = dashAttr(template, "timescale")?.toLongOrNull() ?: 1L
                        val initTpl = dashAttr(template, "initialization")
                        val init = initTpl?.let {
                            resolveHttpUrl(repBase, dashSubstitute(it, repId, bandwidth, null, null))
                        }
                        val timeline = dashFirst(template, "SegmentTimeline")
                        val urls = mutableListOf<String>()
                        if (timeline != null) {
                            var t: Long? = null
                            var number = startNumber
                            for (s in dashChildren(timeline, "S")) {
                                val st = dashAttr(s, "t")?.toLongOrNull()
                                if (st != null) t = st
                                val d = dashAttr(s, "d")?.toLongOrNull() ?: continue
                                val r = dashAttr(s, "r")?.toLongOrNull() ?: 0L
                                var cur = t ?: 0L
                                repeat((r + 1).toInt().coerceIn(1, 100_000)) {
                                    urls += resolveHttpUrl(
                                        repBase,
                                        dashSubstitute(media, repId, bandwidth, number, cur)
                                    )
                                    number++
                                    cur += d
                                }
                                t = cur
                            }
                        } else {
                            val segDur = dashAttr(template, "duration")?.toDoubleOrNull()
                                ?: continue
                            val durSec = periodDuration
                                ?: throw IOException("Can't tell how many segments this DASH stream has")
                            val secondsPerSeg = segDur / timescale.toDouble()
                            if (secondsPerSeg <= 0) continue
                            val count = kotlin.math.ceil(durSec / secondsPerSeg).toLong()
                                .coerceIn(1L, 10_000L)
                            var number = startNumber
                            for (i in 0 until count) {
                                val time = (i * segDur).toLong()
                                urls += resolveHttpUrl(
                                    repBase,
                                    dashSubstitute(media, repId, bandwidth, number, time)
                                )
                                number++
                            }
                        }
                        if (urls.isEmpty()) continue
                        DashSegPlan(init, urls)
                    }
                    else -> continue
                }
                choices += RepChoice(kind, bandwidth, height, plan)
            }
        }

        if (choices.isEmpty()) {
            // Distinguish "everything was DRM" from "nothing usable".
            val anyDrm = dashChildren(period, "AdaptationSet").any { asEl ->
                hasDrm(asEl) || dashChildren(asEl, "Representation").any { hasDrm(it) }
            }
            if (anyDrm) {
                throw IOException("This DASH stream is DRM-protected and can't be saved offline.")
            }
            throw IOException("No downloadable video or audio track in this DASH manifest")
        }
        // P14: same quality ceiling as HLS — best video AT or BELOW
        // the owner's settings; lightest above when nothing fits.
        val (dashMaxHeight, _) = downloadQualityCeiling()
        val videoChoices = choices.filter { it.kind == "video" }
        val videoUnder = videoChoices.filter { it.height == 0 || it.height <= dashMaxHeight }
        val video = if (videoUnder.isNotEmpty()) {
            videoUnder.maxWithOrNull(compareBy({ it.height }, { it.bandwidth }))
        } else {
            videoChoices.minWithOrNull(compareBy({ it.height }, { it.bandwidth }))
        }
        val audio = choices.filter { it.kind == "audio" }
            .maxWithOrNull(compareBy({ it.bandwidth }, { it.height }))
        val tracks = listOfNotNull(
            video?.let { DashTrackPlan("video", it.plan) },
            audio?.let { DashTrackPlan("audio", it.plan) }
        )
        if (tracks.isEmpty()) throw IOException("No downloadable video or audio track in this DASH manifest")
        return tracks
    }

    /** Stream a URL to a file, optionally keeping only bytes from [skipBytes] on. */
    private suspend fun fetchFileSlice(
        url: String, headers: Map<String, String>, skipBytes: Long, dest: File
    ): Boolean = coroutineScope {
        val request = Request.Builder().url(url).apply {
            headers.forEach { (k, v) -> header(k, v) }
            if (skipBytes > 0) header("Range", "bytes=$skipBytes-")
        }.build()
        val call = client.newCall(request)
        val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
            try { awaitCancellation() } finally { call.cancel() }
        }
        try {
            withContext(Dispatchers.IO) { call.execute() }.use { resp ->
                if (!resp.isSuccessful) return@use false
                val body = resp.body ?: return@use false
                // A 200 to a Range request means the server ignored
                // the range: skip the prefix by hand while streaming.
                var toSkip = if (skipBytes > 0 && resp.code == 200) skipBytes else 0L
                withContext(Dispatchers.IO) {
                    body.byteStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        FileOutputStream(dest).use { out ->
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                if (toSkip > 0) {
                                    val s = minOf(toSkip, n.toLong())
                                    toSkip -= s
                                    if (s == n.toLong()) continue
                                    out.write(buf, s.toInt(), n - s.toInt())
                                } else {
                                    out.write(buf, 0, n)
                                }
                            }
                        }
                    }
                }
                true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        } finally {
            watcher.cancel()
        }
    }

    private suspend fun downloadDash(item: DownloadItem, target: File, headers: Map<String, String>) {
        val xml = fetchText(item.url, headers)
            ?: throw IOException("Could not fetch the DASH manifest")
        if (!xml.contains("<MPD")) throw IOException("This URL did not serve a DASH manifest")
        val tracks = parseDashMpd(xml, item.url)

        val workDir = File(item.filePath + ".dash").apply { mkdirs() }
        val sizesFile = File(workDir, "sizes.json")
        val sizes = mutableMapOf<String, Long>()
        runCatching {
            val json = JSONObject(sizesFile.readText())
            json.keys().forEach { k -> sizes[k] = json.getLong(k) }
        }
        val sizesLock = Any()
        fun saveSizes() {
            runCatching {
                val snapshot = synchronized(sizesLock) { sizes.toMap() }
                val json = JSONObject()
                snapshot.forEach { (k, v) -> json.put(k, v) }
                sizesFile.writeText(json.toString())
            }
        }
        fun downloadedNow(): Long = synchronized(sizesLock) { sizes.values.sum() }

        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = -1, downloadedBytes = downloadedNow(), status = "DOWNLOADING", error = null))
        }

        // Build the job list: per track an optional init segment,
        // then its media segments — or one single-file fetch for
        // SegmentBase representations.
        data class Job(val key: String, val file: File, val url: String?, val sliceOf: DashSegPlan?)
        val jobs = mutableListOf<Job>()
        for (track in tracks) {
            val prefix = track.kind.first().toString() // "v" / "a"
            val plan = track.plan
            if (plan.singleFileUrl != null) {
                jobs += Job("$prefix-file", File(workDir, "$prefix-file"), null, plan)
            } else {
                if (plan.initUrl != null) {
                    jobs += Job("$prefix-init", File(workDir, "$prefix-init"), plan.initUrl, null)
                }
                plan.segmentUrls.forEachIndexed { index, segUrl ->
                    jobs += Job("$prefix-$index", File(workDir, "$prefix-%05d".format(index)), segUrl, null)
                }
            }
        }

        val semaphore = Semaphore(3)
        coroutineScope {
            jobs.map { job ->
                async {
                    val known = synchronized(sizesLock) { sizes[job.key] }
                    if (known != null && job.file.exists() && job.file.length() == known) return@async
                    semaphore.withPermit {
                        if (availableBytes() < STORAGE_RESERVE_BYTES) {
                            throw IOException("Not enough free storage to continue this download.")
                        }
                        val ok = if (job.sliceOf != null) {
                            fetchFileSlice(
                                job.sliceOf.singleFileUrl!!, headers,
                                job.sliceOf.singleFileSkip, job.file
                            )
                        } else {
                            val bytes = fetchBytes(job.url!!, headers)
                                ?: throw IOException("A DASH segment failed to download (${job.key})")
                            withContext(Dispatchers.IO) { job.file.writeBytes(bytes) }
                            true
                        }
                        if (!ok) throw IOException("A DASH segment failed to download (${job.key})")
                        val len = withContext(Dispatchers.IO) { job.file.length() }
                        synchronized(sizesLock) { sizes[job.key] = len }
                        saveSizes()
                        val total = downloadedNow()
                        withContext(Dispatchers.IO) { dao.updateProgress(item.id, total, "DOWNLOADING") }
                        _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
                            put(item.id, DownloadProgress(item.id, total, -1, "DOWNLOADING"))
                        }
                    }
                }
            }.forEach { it.await() }
        }

        // Join each track, then remux the track files into one MP4.
        val trackFiles = mutableListOf<File>()
        for (track in tracks) {
            val prefix = track.kind.first().toString()
            val plan = track.plan
            if (plan.singleFileUrl != null) {
                trackFiles += File(workDir, "$prefix-file")
            } else {
                val joined = File(workDir, "$prefix-joined")
                withContext(Dispatchers.IO) {
                    FileOutputStream(joined).use { out ->
                        if (plan.initUrl != null) {
                            File(workDir, "$prefix-init").inputStream().use { it.copyTo(out) }
                        }
                        plan.segmentUrls.indices.forEach { i ->
                            File(workDir, "$prefix-%05d".format(i)).inputStream().use { it.copyTo(out) }
                        }
                    }
                }
                trackFiles += joined
            }
        }
        val remuxed = runCatching { remuxFilesToMp4(trackFiles, target) }.getOrDefault(false)
        if (!remuxed) {
            if (trackFiles.size == 1) {
                // Same fallback as HLS: keep the joined stream as-is.
                withContext(Dispatchers.IO) { trackFiles[0].copyTo(target, overwrite = true) }
            } else {
                throw IOException("Downloaded the DASH segments but couldn't combine them into one MP4")
            }
        }
        workDir.deleteRecursively()
        val size = target.length()
        if (size <= 0L) throw IOException("The DASH download produced an empty file")
        withContext(Dispatchers.IO) {
            dao.upsert(item.copy(totalBytes = size, downloadedBytes = size, status = "DOWNLOADING", error = null))
            dao.markCompleted(item.id, System.currentTimeMillis())
                com.pulsestream.app.data.notifications.DownloadNotifications.postDownloadFinished(appContext, item.id, item.title)
        }
        _activeDownloads.value = _activeDownloads.value - item.id
        Log.i(TAG, "Download completed (DASH): ${item.id} ($size bytes)")
    }

    /**
     * Stream-copy remux of 1–2 track files (e.g. DASH video + audio)
     * into one MP4, interleaved by presentation time. Returns false
     * when a container or codec refuses.
     */
    private fun remuxFilesToMp4(sources: List<File>, target: File): Boolean {
        if (sources.size == 1) return remuxToMp4(sources[0], target)
        val extractors = sources.map {
            MediaExtractor().apply { setDataSource(it.absolutePath) }
        }
        var muxer: MediaMuxer? = null
        return try {
            val picks = mutableListOf<RemuxPick>()
            var haveVideo = false
            var haveAudio = false
            extractors.forEachIndexed { ei, ex ->
                for (t in 0 until ex.trackCount) {
                    val format = ex.getTrackFormat(t)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") && !haveVideo) {
                        picks += RemuxPick(ei, t, format); haveVideo = true
                    } else if (mime.startsWith("audio/") && !haveAudio) {
                        picks += RemuxPick(ei, t, format); haveAudio = true
                    }
                }
            }
            if (picks.isEmpty()) return false
            val mx = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            val muxTrack = HashMap<RemuxPick, Int>()
            picks.forEach { pick ->
                muxTrack[pick] = mx.addTrack(pick.format)
                extractors[pick.ex].selectTrack(pick.track)
            }
            mx.start()
            val buffers = Array(extractors.size) { ByteBuffer.allocate(1024 * 1024) }
            val firstPts = LongArray(extractors.size) { -1L }
            val done = BooleanArray(extractors.size)
            val info = MediaCodec.BufferInfo()
            while (true) {
                var bestEx = -1
                var bestTime = Long.MAX_VALUE
                for (pick in picks) {
                    if (done[pick.ex]) continue
                    val ex = extractors[pick.ex]
                    if (ex.sampleTrackIndex != pick.track && picks.any { it.ex == pick.ex && it.track == ex.sampleTrackIndex }) {
                        continue // this extractor currently sits on its other picked track
                    }
                    val time = ex.sampleTime
                    if (time < 0) { done[pick.ex] = true; continue }
                    if (time < bestTime) { bestTime = time; bestEx = pick.ex }
                }
                if (bestEx < 0) break
                val ex = extractors[bestEx]
                val pick = picks.firstOrNull { it.ex == bestEx && it.track == ex.sampleTrackIndex }
                if (pick == null) { ex.advance(); continue }
                var buffer = buffers[bestEx]
                var size = ex.readSampleData(buffer, 0)
                if (size < 0) { done[bestEx] = true; continue }
                if (size > buffer.capacity()) {
                    buffer = ByteBuffer.allocate(size + 64 * 1024)
                    buffers[bestEx] = buffer
                    size = ex.readSampleData(buffer, 0)
                    if (size < 0) { done[bestEx] = true; continue }
                }
                val pts = ex.sampleTime
                if (firstPts[bestEx] < 0) firstPts[bestEx] = pts
                info.offset = 0
                info.size = size
                info.presentationTimeUs = (pts - firstPts[bestEx]).coerceAtLeast(0)
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else 0
                buffer.position(0)
                mx.writeSampleData(muxTrack.getValue(pick), buffer, info)
                ex.advance()
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Multi-track remux failed: ${e.message}")
            false
        } finally {
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            extractors.forEach { runCatching { it.release() } }
        }
    }

    /** Stream-copy remux (no re-encode). Returns false when the container or codecs refuse. */
    private fun remuxToMp4(source: File, target: File): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        return try {
            extractor.setDataSource(source.absolutePath)
            if (extractor.trackCount == 0) return false
            val mx = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mx
            val trackMap = HashMap<Int, Int>()
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    trackMap[i] = mx.addTrack(format)
                    extractor.selectTrack(i)
                }
            }
            if (trackMap.isEmpty()) return false
            mx.start()
            val buffer = ByteBuffer.allocate(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var firstPts = -1L
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val track = trackMap[extractor.sampleTrackIndex]
                if (track == null) {
                    extractor.advance()
                    continue
                }
                val pts = extractor.sampleTime
                if (firstPts < 0) firstPts = pts
                info.offset = 0
                info.size = sampleSize
                info.presentationTimeUs = (pts - firstPts).coerceAtLeast(0)
                info.flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else 0
                buffer.position(0)
                mx.writeSampleData(track, buffer, info)
                extractor.advance()
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Remux failed, keeping joined stream: ${e.message}")
            false
        } finally {
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            extractor.release()
        }
    }

    private suspend fun cancellableExecute(call: okhttp3.Call): Response = coroutineScope {
        val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
            try { awaitCancellation() } finally { call.cancel() }
        }
        try { withContext(Dispatchers.IO) { call.execute() } }
        finally { watcher.cancel() }
    }

    private fun isOnWifi(): Boolean = try {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        cm.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    } catch (_: Exception) { false }

    private fun availableBytes(): Long = runCatching { StatFs(downloadsDir().absolutePath).availableBytes }.getOrDefault(0L)
    private fun checkStorageSpace(totalBytes: Long, offset: Long) {
        val remainingPayload = if (totalBytes > offset) totalBytes - offset else 0L
        val available = availableBytes()
        if (!DownloadProtocol.fitsWithReserve(available, remainingPayload, STORAGE_RESERVE_BYTES)) {
            throw IOException("Not enough free storage for this download (${formatBytes(available)} available).")
        }
    }

    private fun metadataFile(item: DownloadItem) = File(item.filePath + ".resume.json")
    private fun readMetadata(item: DownloadItem): ResumeMetadata = runCatching {
        val json = JSONObject(metadataFile(item).readText())
        ResumeMetadata(json.optString("etag").takeIf { it.isNotBlank() }, json.optString("lastModified").takeIf { it.isNotBlank() })
    }.getOrDefault(ResumeMetadata())
    private fun writeMetadata(item: DownloadItem, metadata: ResumeMetadata) {
        runCatching {
            metadataFile(item).writeText(JSONObject().put("etag", metadata.etag).put("lastModified", metadata.lastModified).toString())
        }.onFailure { Log.w(TAG, "Could not store download validators") }
    }

    private suspend fun updateProgressFlow(id: String) {
        val item = withContext(Dispatchers.IO) { dao.getById(id) } ?: run { _activeDownloads.value -= id; return }
        if (item.status in listOf("COMPLETED", "CANCELLED", "PAUSED", "FAILED")) _activeDownloads.value -= id
        else _activeDownloads.value = _activeDownloads.value.toMutableMap().apply {
            put(id, DownloadProgress(id, File(item.filePath).takeIf { it.exists() }?.length() ?: item.downloadedBytes, item.totalBytes, item.status))
        }
    }

    private fun decodeUrlForDetection(url: String): String = runCatching {
        URLDecoder.decode(url, StandardCharsets.UTF_8.name())
    }.getOrDefault(url)

    private fun normalizeRequestHeaders(headers: Map<String, String>): Map<String, String> {
        val clean = LinkedHashMap<String, String>()
        headers.forEach { (rawKey, rawValue) ->
            val key = rawKey.trim()
            val value = rawValue.trim()
            if (key.isNotEmpty() && value.isNotEmpty() && !key.equals("Range", ignoreCase = true)) {
                clean[key] = value
            }
        }
        return PlaybackHeaders.buildPlaybackHeaders(clean, isTv = false)
            .mapKeys { it.key.trim() }
            .mapValues { it.value.trim() }
            .filter { (key, value) -> key.isNotEmpty() && value.isNotEmpty() }
    }

    private fun sanitizeFileName(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(80).ifBlank { "download" }
    private fun guessExtension(url: String): String {
        val path = url.substringBefore("?").substringAfterLast("/")
        val ext = path.substringAfterLast(".", "")
        return if (ext.length in 2..4 && ext.all { it.isLetterOrDigit() }) ".$ext" else ".mp4"
    }
    fun formatBytes(bytes: Long): String = when {
        bytes < 0 -> "Unknown"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024f)
        bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024f * 1024f))
        else -> "%.2f GB".format(bytes / (1024f * 1024f * 1024f))
    }

    fun shutdown() { scope.cancel(); instance = null }
}
