package com.pulsestream.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.pulsestream.app.ui.components.AddToListSheet
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsestream.app.data.CustomListsRepository
import com.pulsestream.app.data.MetaPreview
import com.pulsestream.app.data.PlavioStatuses
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.WatchedMarks
import com.pulsestream.app.data.cloud.PlavioAccountManager
import com.pulsestream.app.data.download.DownloadManager
import com.pulsestream.app.data.db.CustomList
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.data.trakt.TraktManager
import androidx.compose.foundation.layout.aspectRatio
import com.pulsestream.app.ui.components.PosterCard
import com.pulsestream.app.ui.components.SafePosterImage
import com.pulsestream.app.ui.components.SectionTitle
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit
import java.io.File

/**
 * Library (owner's design, 2026-10-24): one home for everything that is
 * the user's — Up Next from Trakt/Simkl progress (continue where you
 * left in any app; the player already scrobbles back), the Trakt and
 * Simkl watchlists, the local watchlist, and custom lists. Replaces
 * the Live tab in the dock; the old Watchlist/Lists screens stay as
 * the "See all" destinations.
 */
/**
 * Process-wide Library meta cache (owner's speed fix, 2026-10-27):
 * resolved metas by "type|imdb id". The Library used to re-fetch
 * every poster's meta from the addons on EVERY visit — behind a
 * fully serial chain of section loads — which is why it sat
 * buffering for so long (Rohit's report). Each meta is resolved
 * once per process now and reused instantly on later visits.
 */
private val libraryMetaCache =
    java.util.concurrent.ConcurrentHashMap<String, com.pulsestream.app.data.MetaDetail>()

/**
 * Cache-prime pass for LOCAL Library rows (2026-10-28,
 * display-side guarantee): the Plavio view and the on-device
 * watchlist row draw poster/logo cache-first from
 * [libraryMetaCache], but a row the DB backfill could not fill
 * (its per-process cap, an addon that was offline) would still
 * render blank unless something resolves its meta into the cache.
 * This walks the still-posterless local rows (type|metaId pairs)
 * through the same getMetaFromAny walk the service views use,
 * each item hard-capped at 30 s like metaFor in the service load,
 * all of them concurrent and off the critical path — it never
 * gates `loading`, and a row that resolves simply appears on the
 * next repaint of its tab.
 */
private suspend fun primeLibraryMetaCacheForLocalRows(
    repository: StreamRepository,
    rows: List<Pair<String, String>>
) {
    val missing = rows.distinct()
        .filter { (type, metaId) -> libraryMetaCache["$type|$metaId"]?.poster.isNullOrBlank() }
        .take(40)
    if (missing.isEmpty()) return
    coroutineScope {
        missing.map { (type, metaId) ->
            async {
                val meta = kotlinx.coroutines.withTimeoutOrNull(30_000) {
                    runCatching { repository.getMetaFromAny(null, type, metaId) }.getOrNull()
                }
                if (meta != null) {
                    libraryMetaCache["$type|$metaId"] = meta
                    com.pulsestream.app.data.LogoResolver.prime(type, metaId, meta.logo)
                }
            }
        }.awaitAll()
    }
}

/**
 * Shared Library meta resolver (v0.14.11): process cache first,
 * then the repository walk — which is itself disk-cache-first via
 * the meta_cache funnel, so a title that ever resolved answers
 * from disk even on a cold process. The overall cap is 30 s: two
 * full per-addon budgets (15 s each). The pre-v0.14.11 cap was
 * 12 s — SHORTER than one addon's own budget — so a slow first
 * addon's answer was killed before any fallback could run; that
 * inversion is the diagnosed root cause of the blank Trakt
 * posters. 30 s still bounds the walk; it just no longer inverts
 * the per-addon budget.
 */
private suspend fun resolveLibraryMeta(
    repository: StreamRepository,
    type: String,
    imdb: String
): com.pulsestream.app.data.MetaDetail? {
    libraryMetaCache["$type|$imdb"]?.let { return it }
    val meta = kotlinx.coroutines.withTimeoutOrNull(30_000) {
        runCatching { repository.getMetaFromAny(null, type, imdb) }.getOrNull()
    }
    if (meta != null) {
        libraryMetaCache["$type|$imdb"] = meta
        // Feed the shared logo cache too (items 14/15): a meta
        // resolved here gives its logo to every poster tile for free.
        com.pulsestream.app.data.LogoResolver.prime(type, imdb, meta.logo)
    }
    return meta
}

/**
 * One service-list entry for the Library loaders (v0.14.19): the
 * entry's best key (imdb → tmdb:… → simkl:/trakt:), the service's own
 * title, and its poster when the service provides one. Entries whose
 * key no addon can resolve still display with title + poster.
 */
private data class SvcEntry(val key: String, val title: String, val poster: String? = null)

/** True when a meta addon could resolve this key (tt or tmdb: ids). */
private fun isResolvableServiceKey(key: String): Boolean =
    key.startsWith("tt") || key.startsWith("tmdb:")

private data class UpNextCard(
    val imdbId: String,
    val showTitle: String,
    val service: String,
    val nextLabel: String,
    val metaLine: String,
    val progress: Float?,
    val poster: String?,
    val still: String?,
    val lastWatchedMs: Long
)

/**
 * One candidate series for the Upcoming scan (v0.14.11): an IMDb
 * id plus the best name/poster the source list already had, so a
 * row can render before its meta lands.
 */
private data class UpcomingCandidate(
    val addonId: String,
    val metaId: String,
    val name: String,
    val poster: String?
)

/**
 * One upcoming (not yet aired) episode of a series the user
 * follows (item 36, owner's UX pass 2026-10-28; union scan since
 * v0.14.11). Built from the serving meta's own episode release
 * dates — generic meta data, any addon. Headed "Upcoming"
 * (owner's name pick, v0.14.11) — distinct from the "Up Next"
 * Trakt/Simkl in-progress rail above it; two identical headings
 * would read as a bug.
 */
private data class ComingUpEntry(
    val addonId: String,
    val metaId: String,
    val showName: String,
    val poster: String?,
    val season: Int,
    val episode: Int,
    val episodeTitle: String?,
    val airDate: java.time.LocalDate,
    val badge: String
)

/**
 * Process-retained Library state (notes item 17, the reload
 * diagnosis): the screen used to hold EVERYTHING in plain
 * `remember`, which NavHost's saveState cannot save — every tab
 * switch (and every Detail drill-in) disposed the composition
 * and the screen restarted from zero behind a fresh spinner,
 * even the selected service reset. The loaded lists now live in
 * this retained snapshot: the screen initialises from it and
 * mirrors every update back, so a return repaints the previous
 * screen instantly. [loadedAtMs] + [signature] drive the
 * freshness window — a return within ~5 min with unchanged link
 * state / library sizes skips the network load entirely.
 */
private object LibrarySnapshot {
    var upNext: List<UpNextCard> = emptyList()
    var comingUp: List<ComingUpEntry> = emptyList()
    var traktWatchlist: List<MetaPreview> = emptyList()
    var simklWatchlist: List<MetaPreview> = emptyList()
    var simklSections: List<Pair<String, List<MetaPreview>>> = emptyList()
    var traktListSections: List<Pair<String, List<MetaPreview>>> = emptyList()
    var traktHistory: List<MetaPreview> = emptyList()
    var simklCustomListSections: List<Pair<String, List<MetaPreview>>> = emptyList()
    var plavioListTabs: List<Triple<String, String, List<MetaPreview>>> = emptyList()
    var plavioWatched: List<MetaPreview> = emptyList()
    var selectedService: String? = null
    var loadedAtMs: Long = 0L
    var signature: String = ""

    fun hasContent(): Boolean =
        upNext.isNotEmpty() || traktWatchlist.isNotEmpty() || simklWatchlist.isNotEmpty() ||
            simklSections.isNotEmpty() || traktListSections.isNotEmpty() ||
            traktHistory.isNotEmpty() ||
            simklCustomListSections.isNotEmpty() || plavioListTabs.isNotEmpty() ||
            plavioWatched.isNotEmpty()

    fun isFresh(signature: String, nowMs: Long): Boolean =
        loadedAtMs > 0L && nowMs - loadedAtMs < 5 * 60_000L && this.signature == signature
}

@Composable
fun LibraryScreen(
    repository: StreamRepository,
    listsRepository: CustomListsRepository,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    onOpenList: (listId: String) -> Unit,
    onGoToWatchlist: () -> Unit,
    onGoToLists: () -> Unit,
    onGoToDownloads: () -> Unit = {},
    onPlayDownload: (filePath: String, title: String) -> Unit = { _, _ -> },
    onConnect: () -> Unit
) {
    val settings = repository.settings
    val palette = LocalPalette.current
    val traktLinked = !settings.traktAccessToken.isNullOrBlank()
    val simklLinked = !settings.simklToken.isNullOrBlank()

    // State initialises from the retained snapshot (item 17): a
    // tab return repaints the previous screen instantly instead
    // of restarting behind a spinner.
    var loading by remember {
        mutableStateOf((traktLinked || simklLinked) && !LibrarySnapshot.hasContent())
    }
    var upNext by remember { mutableStateOf(LibrarySnapshot.upNext) }
    var comingUp by remember { mutableStateOf(LibrarySnapshot.comingUp) }
    var traktWatchlist by remember { mutableStateOf(LibrarySnapshot.traktWatchlist) }
    var simklWatchlist by remember { mutableStateOf(LibrarySnapshot.simklWatchlist) }
    // Phase 1 service sections (v0.14.6): status-grouped Simkl library,
    // Trakt personal lists — (section title, posters).
    var simklSections by remember { mutableStateOf(LibrarySnapshot.simklSections) }
    var traktListSections by remember { mutableStateOf(LibrarySnapshot.traktListSections) }
    // Trakt watched history (v0.14.19) — its own tab in the Trakt view.
    var traktHistory by remember { mutableStateOf(LibrarySnapshot.traktHistory) }
    // Simkl CUSTOM lists (v0.14.7-test): the read direction of list
    // sync — the user's own Simkl lists as Library sections. (The
    // write direction doesn't exist in Simkl's API — see SimklApi.)
    var simklCustomListSections by remember {
        mutableStateOf(LibrarySnapshot.simklCustomListSections)
    }
    // Plavio view tabs (v0.14.9): the user's own lists resolved to
    // posters, and the Watched tab resolved from the local watched
    // store. MDBList left the Library switcher for this view — it
    // still works in Integrations, the detail ratings row and the
    // hold sheet, untouched.
    // (listId, name, posters) — the id rides along so the tab view
    // can offer Delete list for exactly the list being shown.
    var plavioListTabs by remember { mutableStateOf(LibrarySnapshot.plavioListTabs) }
    var plavioWatched by remember { mutableStateOf(LibrarySnapshot.plavioWatched) }
    val watchedKeys by WatchedMarks.keys.collectAsState()
    // Three-level Library (v0.14.7, owner's fix #4): null = the
    // on-device library; "trakt" / "simkl" / "plavio" = that view
    // (tabs -> cards). Replaces the v0.14.6 everything-stacked
    // sections the owner called "very bad organized".
    var selectedService by remember { mutableStateOf(LibrarySnapshot.selectedService) }
    var sheetTarget by remember { mutableStateOf<MetaPreview?>(null) }

    // Mirror every state update into the retained snapshot, so
    // the next composition of this screen (tab return, drill-in
    // back) starts from exactly what was last shown.
    androidx.compose.runtime.SideEffect {
        LibrarySnapshot.upNext = upNext
        LibrarySnapshot.comingUp = comingUp
        LibrarySnapshot.traktWatchlist = traktWatchlist
        LibrarySnapshot.simklWatchlist = simklWatchlist
        LibrarySnapshot.simklSections = simklSections
        LibrarySnapshot.traktListSections = traktListSections
        LibrarySnapshot.traktHistory = traktHistory
        LibrarySnapshot.simklCustomListSections = simklCustomListSections
        LibrarySnapshot.plavioListTabs = plavioListTabs
        LibrarySnapshot.plavioWatched = plavioWatched
        LibrarySnapshot.selectedService = selectedService
    }

    val context = LocalContext.current
    // Plavio Sync sign-in state: the Plavio view works either way
    // (local data); signed-out only adds the one sync hint line.
    val plavioSignedIn = remember {
        PlavioAccountManager(context, repository).isSignedIn()
    }
    val downloadManager = remember { DownloadManager.get(context) }
    val downloads by downloadManager.observeAll().collectAsState(initial = emptyList())
    val completedDownloads = remember(downloads) {
        downloads.filter { it.status == "COMPLETED" }
    }
    // Downloads section content (item 18): completed downloads
    // grouped by title — a series is one card, not one per episode.
    val downloadGroups = remember(completedDownloads) {
        groupDownloads(completedDownloads)
    }

    val myWatchlist by repository.watchlist.collectAsState(initial = emptyList())

    // Upcoming (item 36; union + incremental since v0.14.11): the
    // next UNAIRED episode per series the user follows ANYWHERE —
    // the on-device watchlist, the Trakt watchlist, Trakt
    // watching/progress (the Up Next rail), the Simkl
    // plan-to-watch, Simkl watching/by-status sections and Simkl
    // custom lists — deduped by IMDb id, capped at 30. The v0.14.10
    // scan read ONLY the on-device watchlist, ran serially with no
    // timeout and published all-or-nothing after the whole loop,
    // so on a real (Trakt-followed) library the section simply
    // never appeared. Now each show's entry publishes the moment
    // ITS meta resolves, and metas come through the repository's
    // disk meta cache — a warm open renders the section from
    // last-known episode dates instantly. Soonest first.
    val upcomingCandidates = remember(
        myWatchlist, traktWatchlist, simklWatchlist,
        simklSections, simklCustomListSections, upNext
    ) {
        val seen = LinkedHashMap<String, UpcomingCandidate>()
        fun add(addonId: String, type: String, id: String, name: String, poster: String?) {
            if (type != "series" || !id.startsWith("tt")) return
            if (id !in seen) seen[id] = UpcomingCandidate(addonId, id, name, poster)
        }
        myWatchlist.forEach { add(it.addonId, it.type, it.metaId, it.name, it.poster) }
        upNext.filter { it.service == "Trakt" }
            .forEach { add("", "series", it.imdbId, it.showTitle, it.poster) }
        traktWatchlist.forEach { add("", it.type, it.id, it.name, it.poster) }
        upNext.filter { it.service == "Simkl" }
            .forEach { add("", "series", it.imdbId, it.showTitle, it.poster) }
        simklWatchlist.forEach { add("", it.type, it.id, it.name, it.poster) }
        simklSections.forEach { (_, previews) ->
            previews.forEach { add("", it.type, it.id, it.name, it.poster) }
        }
        simklCustomListSections.forEach { (_, previews) ->
            previews.forEach { add("", it.type, it.id, it.name, it.poster) }
        }
        seen.values.take(30)
    }
    val upcomingKey = remember(upcomingCandidates) {
        upcomingCandidates.joinToString("|") { it.metaId }
    }
    LaunchedEffect(upcomingKey) {
        if (upcomingCandidates.isEmpty()) {
            comingUp = emptyList()
            return@LaunchedEffect
        }
        val today = java.time.LocalDate.now()
        val found = mutableListOf<ComingUpEntry>()
        val publishLock = Any()
        coroutineScope {
            val gate = kotlinx.coroutines.sync.Semaphore(4)
            upcomingCandidates.map { cand ->
                async {
                    gate.withPermit {
                        val meta = runCatching {
                            repository.getMetaFromAny(
                                cand.addonId.takeIf { it.isNotBlank() },
                                "series",
                                cand.metaId
                            )
                        }.getOrNull() ?: return@withPermit
                        val next = meta.videos.mapNotNull { video ->
                            val date = video.released?.take(10)?.let {
                                runCatching { java.time.LocalDate.parse(it) }.getOrNull()
                            } ?: return@mapNotNull null
                            if (date.isAfter(today)) video to date else null
                        }.minByOrNull { it.second } ?: return@withPermit
                        val (video, date) = next
                        val days = java.time.temporal.ChronoUnit.DAYS.between(today, date)
                        val badge = when {
                            days == 1L -> "Tomorrow"
                            days in 2..7 -> date.format(
                                java.time.format.DateTimeFormatter.ofPattern(
                                    "EEE d MMM", java.util.Locale.ENGLISH
                                )
                            )
                            else -> "in $days days"
                        }
                        val entry = ComingUpEntry(
                            addonId = cand.addonId,
                            metaId = cand.metaId,
                            showName = cand.name.ifBlank { meta.name },
                            poster = cand.poster ?: meta.poster,
                            season = video.season,
                            episode = video.episode,
                            episodeTitle = video.title.takeIf { it.isNotBlank() },
                            airDate = date,
                            badge = badge
                        )
                        // Incremental publish: this show appears
                        // NOW, not after the slowest lookup.
                        synchronized(publishLock) {
                            found += entry
                            comingUp = found.sortedBy { it.airDate }
                        }
                    }
                }
            }.awaitAll()
        }
    }
    // Plavio statuses + favorites (v0.14.10): tabs resolve by the
    // same rule as the hold sheet — an explicit status row wins,
    // watchlist membership reads as Next to Watch.
    val myFavorites by repository.favorites.collectAsState(initial = emptyList())
    val myStatuses by repository.titleStatuses.collectAsState(initial = emptyList())
    val myLists by listsRepository.lists.collectAsState(initial = emptyList())
    val syncedIds = remember(settings.librarySyncedKeys) {
        settings.librarySyncedKeys.map { it.substringAfter('|') }.toSet()
    }

    LaunchedEffect(traktLinked, simklLinked) {
        if (!traktLinked && !simklLinked) {
            loading = false
            return@LaunchedEffect
        }
        // Freshness window (notes item 17): a return within ~5
        // minutes with unchanged link state / library sizes reuses
        // the retained snapshot as-is — no network load runs and
        // the spinner never appears over data already shown.
        val loadSignature = "$traktLinked|$simklLinked|${myWatchlist.size}|" +
            "${myFavorites.size}|${myStatuses.size}|${myLists.size}|${watchedKeys.size}"
        if (LibrarySnapshot.isFresh(loadSignature, System.currentTimeMillis())) {
            loading = false
            return@LaunchedEffect
        }
        // Root cause of the "spinner never stops" device report
        // (v0.14.7-test, 2026-10-27): `loading` was cleared only
        // after this ENTIRE tree settled — both services' Up Next
        // card jobs AND every section load, each section resolving
        // up to 20 posters through getMetaFromAny (serial across
        // meta addons at up to 15 s each, plus an unbounded TMDB
        // enrichment). One slow addon held the whole screen's
        // spinner indefinitely. Now: the flag lives in a finally,
        // each branch is hard-capped, Up Next publishes per service
        // as it lands, and the section loads run off the critical
        // path entirely (background children of this effect).
        val effectScope = this
        loading = true
        try {
        val traktApi = TraktApi()
        val simklApi = SimklApi()
        val traktToken = if (traktLinked) {
            runCatching { TraktManager(settings).validAccessToken() }.getOrNull()
        } else null
        val simklToken = if (simklLinked) {
            runCatching { SimklManager(settings).validAccessToken() }.getOrNull()
        } else null

        // Posters/stills by IMDb id — CACHE-FIRST (owner's speed
        // fix, 2026-10-27): a meta resolved once this process is
        // reused instantly; only misses go to the addons. Since
        // v0.14.11 the walk itself is disk-cache-first and the
        // overall cap is 30 s (see resolveLibraryMeta — the old
        // 12 s cap was shorter than one addon's 15 s budget and
        // killed slow answers before any fallback could run).
        suspend fun metaFor(type: String, imdb: String): com.pulsestream.app.data.MetaDetail? =
            resolveLibraryMeta(repository, type, imdb)

        // Two-phase previews: the section renders IMMEDIATELY with
        // the titles the service already gave us (plus any cached
        // posters), then each resolved poster/name/rating swaps in
        // THE MOMENT its own meta lands (v0.14.11 — per-item
        // publish; the old wholesale awaitAll replacement kept
        // early finishers invisible until the slowest lookup in
        // the section settled). The Library no longer sits on a
        // spinner while addons answer (Rohit's report).
        suspend fun loadPreviews(
            entries: List<Pair<String, SvcEntry>>,
            apply: (List<MetaPreview>) -> Unit
        ) {
            val resolved = entries.map { (type, entry) ->
                val cached = libraryMetaCache["$type|${entry.key}"]
                MetaPreview(
                    id = entry.key, type = type,
                    name = cached?.name ?: entry.title,
                    poster = cached?.poster ?: entry.poster,
                    logo = cached?.logo,
                    imdbRating = cached?.imdbRating
                )
            }.toMutableList()
            apply(resolved.toList())
            val applyLock = Any()
            coroutineScope {
                entries.mapIndexed { index, (type, entry) ->
                    async {
                        // simkl:/trakt:-keyed entries have no addon
                        // resolution — they keep the service's own
                        // title/poster (v0.14.19 all-lists display).
                        if (!isResolvableServiceKey(entry.key)) return@async
                        val meta = metaFor(type, entry.key) ?: return@async
                        synchronized(applyLock) {
                            resolved[index] = MetaPreview(
                                id = entry.key, type = type,
                                name = meta.name,
                                poster = meta.poster ?: entry.poster,
                                logo = meta.logo,
                                imdbRating = meta.imdbRating
                            )
                            apply(resolved.toList())
                        }
                    }
                }.awaitAll()
            }
        }

        // Loads several sections CONCURRENTLY, publishing each as
        // soon as its own data lands (declared order preserved).
        suspend fun loadSections(
            grouped: List<Pair<String, List<Pair<String, SvcEntry>>>>,
            apply: (List<Pair<String, List<MetaPreview>>>) -> Unit
        ) {
            val acc = mutableMapOf<String, List<MetaPreview>>()
            coroutineScope {
                grouped.map { (label, entries) ->
                    launch {
                        loadPreviews(entries) { resolved ->
                            acc[label] = resolved
                            apply(grouped.mapNotNull { (l, _) -> acc[l]?.let { l to it } })
                        }
                    }
                }
            }
        }

        // ALL branches run CONCURRENTLY now (Trakt, Simkl, and the
        // section loads used to run one after another — the wait
        // Rohit reported). Each publishes its own state as it lands.
        coroutineScope {
            val traktCards = async {
                val list = mutableListOf<UpNextCard>()
                if (traktToken != null) {
                    runCatching { traktApi.getWatchlist(traktToken) }.getOrNull()?.let { entries ->
                        loadPreviews(entries.take(20).map { it.type to SvcEntry(it.key, it.title) }) {
                            traktWatchlist = it
                        }
                    }
                    runCatching { traktApi.getUpNext(traktToken) }.getOrNull()?.let { entries ->
                        list += coroutineScope {
                            entries.map { e ->
                                async {
                                    val meta = metaFor("series", e.imdbId)
                                    val still = meta?.videos?.firstOrNull {
                                        it.season == e.nextSeason && it.episode == e.nextEpisode
                                    }?.thumbnail
                                    UpNextCard(
                                        imdbId = e.imdbId,
                                        showTitle = meta?.name ?: e.title,
                                        service = "Trakt",
                                        nextLabel = "S${e.nextSeason} · E${e.nextEpisode}" +
                                            (e.nextTitle?.let { " — $it" } ?: ""),
                                        metaLine = "You watched S${e.lastSeason} · E${e.lastEpisode} · on Trakt",
                                        progress = if (e.airedCount > 0) {
                                            e.watchedCount.toFloat() / e.airedCount.toFloat()
                                        } else null,
                                        poster = meta?.poster,
                                        still = still,
                                        lastWatchedMs = e.lastWatchedAtMs
                                    )
                                }
                            }.awaitAll()
                        }
                    }
                }
                list
            }
            val simklCards = async {
                val list = mutableListOf<UpNextCard>()
                if (simklToken != null) {
                    runCatching { simklApi.getPlanToWatch(simklToken) }.getOrNull()?.let { entries ->
                        loadPreviews(entries.take(20).map { it.type to SvcEntry(it.key, it.title, it.poster) }) {
                            simklWatchlist = it
                        }
                    }
                    runCatching { simklApi.getWatching(simklToken) }.getOrNull()?.let { entries ->
                        list += coroutineScope {
                            entries.map { e ->
                                async {
                                    val meta = if (isResolvableServiceKey(e.key)) {
                                        metaFor("series", e.key)
                                    } else null
                                    val lastMs = e.lastWatchedAt?.let {
                                        runCatching { java.time.Instant.parse(it).toEpochMilli() }.getOrNull()
                                    } ?: 0L
                                    val counts = if (e.watchedEpisodes != null && e.totalEpisodes != null) {
                                        "${e.watchedEpisodes} of ${e.totalEpisodes} episodes watched · on Simkl"
                                    } else "In progress · on Simkl"
                                    UpNextCard(
                                        imdbId = e.key,
                                        showTitle = meta?.name ?: e.title,
                                        service = "Simkl",
                                        nextLabel = "Continue watching",
                                        metaLine = counts,
                                        progress = if (e.watchedEpisodes != null && e.totalEpisodes != null && e.totalEpisodes > 0) {
                                            e.watchedEpisodes.toFloat() / e.totalEpisodes.toFloat()
                                        } else null,
                                        poster = meta?.poster ?: e.poster,
                                        still = null,
                                        lastWatchedMs = lastMs
                                    )
                                }
                            }.awaitAll()
                        }
                    }
                }
                list
            }
            // Sections run as background children of the EFFECT —
            // deliberately NOT awaited by the block below, so their
            // per-item poster resolution can never hold the loading
            // flag (the v0.14.7-test "spinner never stops" defect).
            effectScope.launch {
                // Phase 1 sections (v0.14.6): full Simkl library by
                // status, Trakt personal lists. Best-effort — a
                // failed section just stays out; the sheet surfaces
                // write errors.
                val tw = repository.trackingWrites()
                coroutineScope {
                    if (tw.simklLinked) {
                        launch {
                            runCatching { tw.simklAllWithStatus() }.getOrNull()?.let { all ->
                                val byStatus = all.groupBy { it.status }
                                loadSections(
                                    SimklApi.Statuses.ALL.mapNotNull { status ->
                                        val entries = byStatus[status].orEmpty()
                                        if (entries.isEmpty()) null
                                        else status to entries.take(20).map {
                                            it.type to SvcEntry(it.key, it.title, it.poster)
                                        }
                                    }
                                ) { simklSections = it }
                            }
                        }
                        launch {
                            // Simkl CUSTOM lists → Library sections
                            // (read direction of list sync — the
                            // only direction Simkl's API offers).
                            runCatching { tw.simklCustomLists() }.getOrNull()?.let { lists ->
                                val grouped = coroutineScope {
                                    lists.map { list ->
                                        async {
                                            val items = runCatching {
                                                tw.simklCustomListItems(list.id)
                                            }.getOrNull().orEmpty()
                                            if (items.isEmpty()) null
                                            else list.name to items.take(20).map {
                                                it.type to SvcEntry(it.key, it.title, it.poster)
                                            }
                                        }
                                    }.awaitAll().filterNotNull()
                                }
                                if (grouped.isNotEmpty()) {
                                    loadSections(grouped) { simklCustomListSections = it }
                                }
                            }
                        }
                    }
                    if (tw.traktLinked) {
                        launch {
                            runCatching { tw.traktLists() }.getOrNull()?.let { lists ->
                                val grouped = coroutineScope {
                                    lists.map { list ->
                                        async {
                                            val items = runCatching {
                                                tw.traktListItems(list.id)
                                            }.getOrNull().orEmpty()
                                            if (items.isEmpty()) null
                                            else list.name to items.take(20).map {
                                                it.type to SvcEntry(it.key, it.title)
                                            }
                                        }
                                    }.awaitAll().filterNotNull()
                                }
                                if (grouped.isNotEmpty()) {
                                    loadSections(grouped) { traktListSections = it }
                                }
                            }
                        }
                        launch {
                            // Trakt watched history (v0.14.19) — its
                            // own tab next to Watchlist + lists.
                            runCatching { tw.traktWatchedHistory() }.getOrNull()?.let { entries ->
                                if (entries.isNotEmpty()) {
                                    loadPreviews(
                                        entries.take(40).map {
                                            it.type to SvcEntry(it.key, it.title)
                                        }
                                    ) { traktHistory = it }
                                }
                            }
                        }
                    }
                }
            }
            val traktUpNext = traktCards.await()
            // Publish Trakt's cards the moment they land; the Simkl
            // branch no longer holds them back.
            upNext = traktUpNext.sortedByDescending { it.lastWatchedMs }.take(10)
            val simklUpNext = simklCards.await()
                .filter { it.imdbId !in traktUpNext.map { c -> c.imdbId }.toSet() }
            upNext = (traktUpNext + simklUpNext)
                .sortedByDescending { it.lastWatchedMs }.take(10)
        }
        // Stamp the successful load for the freshness window.
        LibrarySnapshot.loadedAtMs = System.currentTimeMillis()
        LibrarySnapshot.signature = loadSignature
        } finally {
            // The spinner ALWAYS terminates — success, failure or
            // cancellation alike.
            loading = false
        }
    }

    // Poster re-attempt on tab re-entry (v0.14.11 — the blank
    // Trakt posters fix): a service row whose meta walk failed
    // during the main load kept its blank tile for the whole
    // session; nothing ever retried it, and the 5-minute freshness
    // gate blocked the main load from running again. Entering the
    // Trakt/Simkl segment now re-resolves JUST the posterless rows
    // of that service, incrementally as each meta lands, through
    // resolveLibraryMeta — with the disk meta cache underneath, a
    // row that ever resolved answers from disk instantly, so this
    // is a read-path pass, not a network storm. Skipped while the
    // main load runs (it owns resolution then).
    LaunchedEffect(selectedService, loading) {
        if (loading) return@LaunchedEffect
        suspend fun reResolve(
            previews: List<MetaPreview>,
            apply: (List<MetaPreview>) -> Unit
        ) {
            val missing = previews.withIndex()
                .filter {
                    it.value.poster.isNullOrBlank() && isResolvableServiceKey(it.value.id)
                }
            if (missing.isEmpty()) return
            val working = previews.toMutableList()
            val lock = Any()
            coroutineScope {
                missing.map { (index, preview) ->
                    async {
                        val meta = resolveLibraryMeta(repository, preview.type, preview.id)
                            ?: return@async
                        if (meta.poster.isNullOrBlank()) return@async
                        synchronized(lock) {
                            working[index] = working[index].copy(
                                name = meta.name,
                                poster = meta.poster,
                                logo = meta.logo ?: working[index].logo,
                                imdbRating = meta.imdbRating ?: working[index].imdbRating
                            )
                            apply(working.toList())
                        }
                    }
                }.awaitAll()
            }
        }
        when (selectedService) {
            "trakt" -> {
                reResolve(traktWatchlist) { traktWatchlist = it }
                reResolve(traktHistory) { traktHistory = it }
                traktListSections.toList().forEach { (label, previews) ->
                    reResolve(previews) { updated ->
                        traktListSections = traktListSections.map {
                            if (it.first == label) label to updated else it
                        }
                    }
                }
            }
            "simkl" -> {
                reResolve(simklWatchlist) { simklWatchlist = it }
                simklSections.toList().forEach { (label, previews) ->
                    reResolve(previews) { updated ->
                        simklSections = simklSections.map {
                            if (it.first == label) label to updated else it
                        }
                    }
                }
                simklCustomListSections.toList().forEach { (label, previews) ->
                    reResolve(previews) { updated ->
                        simklCustomListSections = simklCustomListSections.map {
                            if (it.first == label) label to updated else it
                        }
                    }
                }
            }
        }
    }

    // Plavio view data (v0.14.9): each local custom list's items as a
    // tab of posters — the same rows the hold sheet's ON THIS DEVICE
    // section writes to, and part of the Plavio account backup payload.
    LaunchedEffect(myLists) {
        plavioListTabs = myLists.map { list ->
            val items = runCatching { listsRepository.observeItems(list.id).first() }
                .getOrDefault(emptyList())
            Triple(list.id, list.name, items.sortedByDescending { it.addedAt }.map {
                MetaPreview(
                    id = it.metaId, type = it.type, name = it.name,
                    poster = it.poster ?: libraryMetaCache["${it.type}|${it.metaId}"]?.poster, logo = it.logo ?: libraryMetaCache["${it.type}|${it.metaId}"]?.logo
                )
            })
        }
    }

    // Poster/logo backfill (owner's Library report, 2026-10-27):
    // rows the sync paths wrote without artwork — Trakt/Simkl
    // library pulls store poster=null BY DESIGN, and an account
    // restore preserves whatever the source device had — rendered
    // as blank grey tiles forever, because the local views draw
    // rows straight from the DB and nothing ever resolved their
    // meta (the Detail page looked fine — it fetches meta live).
    // Resolve each missing poster/logo once in the background and
    // cache it IN the row (StreamRepository.backfillLibraryArtwork);
    // the flows above repaint the tiles as rows fill in. Never
    // gates the spinner.
    LaunchedEffect(myWatchlist.size, myFavorites.size, myStatuses.size, myLists.size) {
        // Once per process now (item 17): the pass is parallel
        // and gated inside the repository — re-entries no longer
        // re-burn serial meta fetches behind the foreground load.
        runCatching { repository.backfillLibraryArtworkOnce() }
        // Cache-prime extension (2026-10-28): after the DB
        // backfill, any local row STILL posterless (backfill cap,
        // an addon that was offline) is resolved into
        // libraryMetaCache, which the Plavio tabs and the watchlist
        // row now read cache-first — so a poster the DB never got
        // still shows. Background only, same effect, never gates
        // the spinner.
        runCatching {
            val posterless = buildList {
                myWatchlist.filter { it.poster.isNullOrBlank() }
                    .forEach { add(it.type to it.metaId) }
                myFavorites.filter { it.poster.isNullOrBlank() }
                    .forEach { add(it.type to it.metaId) }
                myStatuses.filter { it.poster.isNullOrBlank() }
                    .forEach { add(it.type to it.metaId) }
                myLists.forEach { list ->
                    runCatching { listsRepository.observeItems(list.id).first() }
                        .getOrDefault(emptyList())
                        .filter { it.poster.isNullOrBlank() }
                        .forEach { add(it.type to it.metaId) }
                }
            }
            primeLibraryMetaCacheForLocalRows(repository, posterless)
        }
    }

    // Watched tab (v0.14.9): titles from the local watched store
    // (WatchedRecord keys — "m|<id>" title marks, "e|<id>|s|e" episode
    // marks). Keys carry no title/poster, so posters resolve through
    // the installed addons like the service views do; unresolvable
    // ids simply stay out.
    LaunchedEffect(watchedKeys) {
        val ids = watchedKeys.mapNotNull { key ->
            when {
                key.startsWith("e|") -> key.split("|").getOrNull(1)
                key.startsWith("m|") -> key.removePrefix("m|")
                else -> null
            }
        }.distinct().take(12)
        if (ids.isEmpty()) {
            plavioWatched = emptyList()
            return@LaunchedEffect
        }
        plavioWatched = coroutineScope {
            ids.map { id ->
                async {
                    // Hard cap like every other Library resolver
                    // (item 17): this walk used to call
                    // getMetaFromAny UNCAPPED — up to #addons ×
                    // 15 s serially per id, the worst background
                    // churn on the screen. 30 s since v0.14.11 —
                    // the old 12 s cap was shorter than one addon's
                    // own 15 s budget (the cap-inversion fix).
                    val meta = kotlinx.coroutines.withTimeoutOrNull(30_000) {
                        runCatching { repository.getMetaFromAny(null, "series", id) }.getOrNull()
                            ?: runCatching { repository.getMetaFromAny(null, "movie", id) }.getOrNull()
                    }
                    meta?.let {
                        MetaPreview(
                            id = id, type = it.type, name = it.name,
                            poster = it.poster, logo = it.logo
                        )
                    }
                }
            }.awaitAll().filterNotNull()
        }
    }

    // Tabs for the selected view (fix #4): Simkl by status, Trakt
    // Watchlist + personal lists, Plavio = the user's own library —
    // since v0.14.10 by Plavio status (Watching, Next to Watch,
    // On Hold, Dropped — the Completed tab was removed in
    // v0.14.11 by the owner's order; Watched covers it), then
    // Favorite, then each local custom list, then Watched.
    // Computed from the same loaded data the stacked sections used.
    val serviceTabs: List<Pair<String, List<MetaPreview>>> = when (selectedService) {
        "simkl" -> SimklApi.Statuses.ALL.map { status ->
            val fromSections = simklSections.firstOrNull { it.first == status }?.second
            val metas = fromSections
                ?: if (status == SimklApi.Statuses.PLAN_TO_WATCH) simklWatchlist else emptyList()
            SimklApi.Statuses.label(status) to metas
        } + simklCustomListSections
        "trakt" -> listOf("Watchlist" to traktWatchlist) + traktListSections +
            listOf("Watched History" to traktHistory)
        "plavio" -> buildList {
            // Local rows read poster/logo cache-first (2026-10-28):
            // DB value wins; libraryMetaCache (primed by the
            // backfill effect above) fills rows the DB never got.
            val explicitKeys = myStatuses.map { it.key }.toSet()
            // Owner's order (v0.14.11): no "Completed" tab in the
            // Plavio segment — the Watched tab below already covers
            // finished titles, so Completed was a duplicate path.
            // The status itself is untouched: rows keep their
            // stored status and the hold sheet still offers it;
            // only this tab is gone.
            PlavioStatuses.ALL
                .filter { it != PlavioStatuses.COMPLETED }
                .forEach { status ->
                if (status == PlavioStatuses.NEXT_TO_WATCH) {
                    // Backed by the watchlist store; titles carrying
                    // an explicit status show under that status only.
                    add(
                        "Next to Watch" to myWatchlist.filter { it.key !in explicitKeys }.map {
                            MetaPreview(
                                id = it.metaId, type = it.type, name = it.name,
                                poster = it.poster ?: libraryMetaCache["${it.type}|${it.metaId}"]?.poster, logo = it.logo ?: libraryMetaCache["${it.type}|${it.metaId}"]?.logo
                            )
                        }
                    )
                } else {
                    add(
                        PlavioStatuses.label(status) to
                            myStatuses.filter { it.status == status }.map {
                                MetaPreview(
                                    id = it.metaId, type = it.type, name = it.name,
                                    poster = it.poster ?: libraryMetaCache["${it.type}|${it.metaId}"]?.poster, logo = it.logo ?: libraryMetaCache["${it.type}|${it.metaId}"]?.logo
                                )
                            }
                    )
                }
            }
            add(
                "Favorite" to myFavorites.map {
                    MetaPreview(
                        id = it.metaId, type = it.type, name = it.name,
                        poster = it.poster ?: libraryMetaCache["${it.type}|${it.metaId}"]?.poster, logo = it.logo ?: libraryMetaCache["${it.type}|${it.metaId}"]?.logo
                    )
                }
            )
            addAll(plavioListTabs.map { it.second to it.third })
            add("Watched" to plavioWatched)
        }
        else -> emptyList()
    }

    // Custom-list identity per tab, aligned with serviceTabs
    // (v0.14.11): null for status/Favorite/Watched tabs, the list's
    // id for a custom-list tab — drives the visible Delete list
    // control in the tab view.
    val serviceTabListIds: List<String?> = if (selectedService == "plavio") {
        buildList {
            PlavioStatuses.ALL
                .filter { it != PlavioStatuses.COMPLETED }
                .forEach { _ -> add(null) }
            add(null) // Favorite
            addAll(plavioListTabs.map { it.first })
            add(null) // Watched
        }
    } else emptyList()

    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        // Header + the Sample C switcher stay on top in both views.
        // Tapping a segment switches the whole view to that service;
        // tapping the active one again returns to the on-device
        // library. Unconnected integrations get no segment at all.
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp)) {
            Text(
                "Library",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Spacer(Modifier.height(10.dp))
            // Switcher (Sample C — owner's pick, 2026-10-27): ONE
            // frosted segmented capsule, slightly bigger than the
            // old chips — Plavio / Simkl / Trakt, the active segment
            // a white pill. Tapping the active segment again returns
            // to the on-device library. HARD RULE (owner's order):
            // an integration that is NOT connected does not appear
            // at all — no segment, no name: Simkl's and Trakt's
            // segments exist only while linked. Plavio's segment is
            // the on-device library itself (always available since
            // v0.14.9 — a Plavio account only adds sync on top).
            // v0.14.12 (owner's correction): the switcher carries
            // SERVICES ONLY — the "Upcoming" capsule that rode at
            // the end of this capsule in v0.14.11 is gone. Upcoming
            // now lives UNDER Plavio: the Plavio segment view opens
            // with an "Upcoming" button as its first element (see
            // the segment branch below), and that button switches
            // the body to the same dedicated Upcoming view; any
            // service segment returns to the normal Library body.
            val segments = buildList {
                add("plavio" to "Plavio")
                if (simklLinked) add("simkl" to "Simkl")
                if (traktLinked) add("trakt" to "Trakt")
            }
            if (segments.isNotEmpty()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .liquidGlass(RoundedCornerShape(50))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    segments.forEach { (key, label) ->
                        val active = selectedService == key
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(50))
                                .background(if (active) Color.White else Color.Transparent)
                                .clickable {
                                    selectedService = if (active) null else key
                                }
                                .padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val segmentColor =
                                if (active) Color(0xFF101018) else TextPrimary
                            Text(
                                label,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = segmentColor,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        if (selectedService == "upcoming") {
            UpcomingView(
                entries = comingUp,
                onOpenDetail = onOpenDetail,
                modifier = Modifier.weight(1f)
            )
        } else if (selectedService != null) {
            Column(Modifier.weight(1f)) {
                if (selectedService == "plavio") {
                    // v0.14.12 (owner's order): the Plavio view OPENS
                    // with the Upcoming button as its FIRST element —
                    // the switcher's old end capsule moved here, same
                    // frost, same calendar icon + label, full width.
                    // Tapping it switches the body to the dedicated
                    // Upcoming view (the branch above); any service
                    // segment in the header returns.
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 4.dp)
                            .liquidGlass(RoundedCornerShape(50))
                            .clip(RoundedCornerShape(50))
                            .clickable { selectedService = "upcoming" }
                            .padding(vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Filled.DateRange,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = TextPrimary
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "Upcoming",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1
                        )
                    }
                }
                ServiceTabsView(
                    tabs = serviceTabs,
                    loading = loading && selectedService != "plavio",
                    onOpenDetail = onOpenDetail,
                    onLongPress = { sheetTarget = it },
                    modifier = Modifier.weight(1f),
                    headerNote = if (selectedService == "plavio" && !plavioSignedIn) {
                        "Plavio Sync — sign in via Settings → Account and this library syncs to your other devices."
                    } else null,
                    tabListIds = serviceTabListIds,
                    onDeleteList = if (selectedService == "plavio") {
                        { listId -> scope.launch { listsRepository.deleteList(listId) } }
                    } else null
                )
            }
        } else {
    LazyColumn(
        modifier = Modifier.weight(1f),
        contentPadding = PaddingValues(bottom = 110.dp)
    ) {

        if (!traktLinked && !simklLinked) {
            item(key = "connect_card") {
                ConnectCard(onConnect)
            }
        }

        if (loading && upNext.isEmpty()) {
            item(key = "lib_loading") {
                // Style B skeleton rows (v0.14.32), behind the
                // ~300ms guard. (Was the centred OrbitDots.)
                if (com.pulsestream.app.ui.components.rememberDelayedLoading(true)) {
                    Column(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        repeat(2) {
                            com.pulsestream.app.ui.components.ShimmerEpisodeRowCard()
                        }
                    }
                }
            }
        }

        if (upNext.isNotEmpty()) {
            item(key = "upnext_title") {
                SectionTitle("Up Next")
            }
            items(upNext, key = { "up_${it.service}_${it.imdbId}" }) { card ->
                UpNextRow(
                    card,
                    onClick = { onOpenDetail("", "series", card.imdbId) },
                    onLongClick = {
                        sheetTarget = MetaPreview(
                            id = card.imdbId, type = "series",
                            name = card.showTitle, poster = card.poster
                        )
                    }
                )
            }
        }

        // Upcoming (item 36; renamed from "Coming Up" by the
        // owner's pick, v0.14.11): next unaired episodes of
        // followed series, soonest first; the SECTION hides
        // entirely when nothing is upcoming — the dedicated
        // Upcoming view behind the Plavio view's Upcoming button
        // shows a calm empty state instead.
        if (comingUp.isNotEmpty()) {
            item(key = "upcoming_title") {
                SectionTitle("Upcoming")
            }
            items(comingUp, key = { "cu_${it.metaId}" }) { entry ->
                ComingUpRow(
                    entry,
                    onClick = { onOpenDetail(entry.addonId, "series", entry.metaId) }
                )
            }
        }

        // No service content in the on-device view (fix #4): Trakt /
        // Simkl watchlists and lists live behind their buttons at the
        // top now — nothing stacked, nothing repeated.

        if (myWatchlist.isNotEmpty()) {
            item(key = "my_wl_title") {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "My Watchlist",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "See all",
                        color = palette.accent,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.clickable { onGoToWatchlist() }
                    )
                }
            }
            item(key = "my_wl_row") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    items(myWatchlist.take(15), key = { it.key }) { item ->
                        PosterCard(
                            meta = MetaPreview(
                                id = item.metaId, type = item.type,
                                name = item.name, poster = item.poster ?: libraryMetaCache["${item.type}|${item.metaId}"]?.poster,
                                logo = item.logo ?: libraryMetaCache["${item.type}|${item.metaId}"]?.logo
                            ),
                            onClick = { onOpenDetail(item.addonId, item.type, item.metaId) },
                            onLongClick = {
                                sheetTarget = MetaPreview(
                                    id = item.metaId, type = item.type,
                                    name = item.name, poster = item.poster ?: libraryMetaCache["${item.type}|${item.metaId}"]?.poster,
                                    logo = item.logo ?: libraryMetaCache["${item.type}|${item.metaId}"]?.logo
                                )
                            }
                        )
                    }
                }
            }
        }

        if (completedDownloads.isNotEmpty()) {
            item(key = "dl_title") {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Downloads",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "See all",
                        color = palette.accent,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.clickable { onGoToDownloads() }
                    )
                }
            }
            item(key = "dl_row") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    // Grouped by title (item 18): a series' episodes
                    // collapse into ONE card; a lone download plays
                    // its file on tap, a group opens the Downloads
                    // screen where each file lives.
                    items(downloadGroups.take(15), key = { it.name.lowercase() }) { group ->
                        if (group.items.size == 1) {
                            val item = group.items.first()
                            DownloadCard(item) {
                                onPlayDownload(item.filePath, item.title)
                            }
                        } else {
                            DownloadGroupCard(group) { onGoToDownloads() }
                        }
                    }
                }
            }
        }

        if (myLists.isNotEmpty()) {
            item(key = "my_lists_title") {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "My Lists",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "See all",
                        color = palette.accent,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.clickable { onGoToLists() }
                    )
                }
            }
            item(key = "my_lists_cards") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    myLists.take(2).forEach { list ->
                        ListCollageCard(
                            list = list,
                            listsRepository = listsRepository,
                            modifier = Modifier.weight(1f)
                        ) { onOpenList(list.id) }
                    }
                    if (myLists.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (!loading && upNext.isEmpty() && myWatchlist.isEmpty() && myLists.isEmpty() &&
            completedDownloads.isEmpty()
        ) {
            item(key = "lib_empty") {
                Text(
                    if (traktLinked || simklLinked) {
                        "Nothing here yet — your watchlists and progress will show up once there is something to show."
                    } else {
                        "Nothing here yet — add something to your watchlist, or connect Trakt/Simkl above."
                    },
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 28.dp)
                )
            }
        }
    }
        }
    }

    // Hold sheet (v0.14.6): long-press any service poster.
    sheetTarget?.let { meta ->
        AddToListSheet(
            listsRepository = listsRepository,
            addonId = "",
            type = meta.type,
            metaId = meta.id,
            name = meta.name,
            poster = meta.poster,
            onDismiss = { sheetTarget = null },
            repository = repository,
            year = meta.releaseInfo?.filter { it.isDigit() }?.take(4)?.toIntOrNull(),
            rating = meta.imdbRating
        )
    }
}

/**
 * One service's view (fix #4): a tab row (statuses for Simkl,
 * Watchlist + personal lists for Trakt, Watchlist + lists + Watched
 * for Plavio) over a poster grid that shows ONLY the active tab's
 * cards. Empty tabs get a short "Nothing here yet" line. [headerNote]
 * is one subtle line above the tabs (the Plavio Sync hint).
 */
@Composable
private fun ServiceTabsView(
    tabs: List<Pair<String, List<MetaPreview>>>,
    loading: Boolean,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    onLongPress: (MetaPreview) -> Unit,
    modifier: Modifier = Modifier,
    headerNote: String? = null,
    tabListIds: List<String?> = emptyList(),
    onDeleteList: ((String) -> Unit)? = null
) {
    var tabIndex by remember(tabs.map { it.first }) { mutableStateOf(0) }
    var confirmDeleteList by remember { mutableStateOf(false) }
    val activeListId = tabListIds.getOrNull(tabIndex)
    val activeMetas = tabs.getOrNull(tabIndex)?.second.orEmpty()
        .distinctBy { it.type + "|" + it.id }
    // Count + sort (Sample C, owner's pick 2026-10-27): the count
    // line under the chips, and a Sort control that cycles
    // Recent → A–Z → Rating. Recent keeps the service's own order.
    var sortMode by remember { mutableStateOf(0) }
    val sortLabels = listOf("Recent", "A–Z", "Rating")
    val displayMetas = when (sortMode) {
        1 -> activeMetas.sortedBy { it.name.lowercase() }
        2 -> activeMetas.sortedByDescending { it.imdbRating?.toFloatOrNull() ?: 0f }
        else -> activeMetas
    }
    val palette = LocalPalette.current
    Column(modifier) {
        if (headerNote != null) {
            Text(
                headerNote,
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp)
            )
        }
        if (tabs.size > 1) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
            ) {
                items(tabs.map { it.first }, key = { "tab_$it" }) { label ->
                    val index = tabs.indexOfFirst { it.first == label }
                    SimklFilterChip(label, tabIndex == index) { tabIndex = index }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (loading) "${displayMetas.size} items · syncing…"
                else "${displayMetas.size} items · synced ✓",
                color = TextSecondary,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "Sort: ${sortLabels[sortMode]} ▾",
                color = palette.accent,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { sortMode = (sortMode + 1) % sortLabels.size }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        // Delete list (v0.14.11): a plain visible control on a
        // custom list's own tab — no hidden gestures. Only the list
        // and its memberships go; the titles keep their statuses,
        // favorites and watched marks.
        if (activeListId != null && onDeleteList != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { confirmDeleteList = true }) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = null,
                        tint = Color(0xFFF87171),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Delete list", color = Color(0xFFF87171))
                }
            }
        }
        if (confirmDeleteList && activeListId != null && onDeleteList != null) {
            AlertDialog(
                onDismissRequest = { confirmDeleteList = false },
                title = { Text("Delete this list?", color = TextPrimary) },
                text = {
                    Text(
                        "The titles stay in your library.",
                        color = TextSecondary
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        onDeleteList(activeListId)
                        confirmDeleteList = false
                    }) { Text("Delete", color = Color(0xFFF87171)) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmDeleteList = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                },
                containerColor = Color(0xFF14141F)
            )
        }
        when {
            loading && displayMetas.isEmpty() -> {
                // Style B skeleton poster grid (v0.14.32), behind
                // the ~300ms guard. (Was the centred OrbitDots.)
                if (com.pulsestream.app.ui.components.rememberDelayedLoading(true)) {
                    Column(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        repeat(2) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                repeat(3) {
                                    com.pulsestream.app.ui.components.ShimmerPoster(
                                        Modifier.weight(1f).aspectRatio(2f / 3f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            displayMetas.isEmpty() -> {
                Text(
                    "Nothing here yet",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 28.dp)
                )
            }
            else -> {
                androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                    columns = androidx.compose.foundation.lazy.grid.GridCells.Adaptive(140.dp),
                    contentPadding = PaddingValues(
                        start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    gridItems(displayMetas, key = { "${it.type}_${it.id}" }) { meta ->
                        PosterCard(
                            meta = meta,
                            onClick = { onOpenDetail("", meta.type, meta.id) },
                            onLongClick = { onLongPress(meta) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SimklFilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) palette.accent else Color.White.copy(alpha = 0.07f))
            .border(
                1.dp,
                if (selected) palette.accent else Color.White.copy(alpha = 0.14f),
                RoundedCornerShape(50)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) palette.accentText else TextPrimary
        )
    }
}

/** Downloads grouped by title for the Library section (item 18). */
private data class DownloadGroup(
    val name: String,
    val items: List<com.pulsestream.app.data.db.DownloadItem>
) {
    val totalBytes: Long get() = items.sumOf { it.totalBytes.coerceAtLeast(0L) }
    val newestAt: Long get() = items.maxOf { it.createdAt }

    /**
     * The group's poster source (owner's order, 2026-10-28): the
     * first item in the group carrying saved poster art — every
     * episode of a series shares the title's poster, so the first
     * carrier speaks for the group.
     */
    val posterItem: com.pulsestream.app.data.db.DownloadItem?
        get() = items.firstOrNull {
            !it.posterPath.isNullOrBlank() || !it.posterUrl.isNullOrBlank()
        }
}

/**
 * Poster art for a Library Downloads tile (owner's order,
 * 2026-10-28): the download's locally saved poster file first
 * (offline-safe), then its remote poster URL, then the tile's
 * initial-letter placeholder. SafePosterImage accepts string
 * models only, so the local file goes through Coil directly with
 * a File model (the ProfileAvatar pattern).
 */
@Composable
private fun DownloadPosterArt(
    posterPath: String?,
    posterUrl: String?,
    fallbackLabel: String,
    modifier: Modifier = Modifier
) {
    val localFile = remember(posterPath) {
        posterPath?.let { File(it) }?.takeIf { it.exists() }
    }
    var localFailed by remember(posterPath) { mutableStateOf(false) }
    when {
        localFile != null && !localFailed -> AsyncImage(
            model = localFile,
            contentDescription = null,
            modifier = modifier,
            contentScale = ContentScale.Crop,
            onError = { localFailed = true }
        )
        !posterUrl.isNullOrBlank() -> SafePosterImage(
            model = posterUrl,
            contentDescription = null,
            modifier = modifier
        )
        else -> Box(modifier, contentAlignment = Alignment.Center) {
            Text(
                fallbackLabel.take(1).uppercase(),
                color = TextSecondary,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

private val DOWNLOAD_EPISODE_TOKEN = Regex("""(?i)\bS\d{1,2}E\d{1,3}\b""")

/**
 * Group name for one download's raw title: an episode's title
 * collapses to its series name (everything before the SxxExx
 * token); a movie's title stands as-is.
 */
private fun downloadGroupName(title: String): String {
    val m = DOWNLOAD_EPISODE_TOKEN.find(title) ?: return title
    val head = title.substring(0, m.range.first)
        .trim().trim('-', '•', '·', '.', '_', ' ').trim()
    return head.ifBlank { title }
}

private fun groupDownloads(
    items: List<com.pulsestream.app.data.db.DownloadItem>
): List<DownloadGroup> = items
    .groupBy { downloadGroupName(it.title).lowercase() }
    .values
    .map { group ->
        DownloadGroup(
            name = downloadGroupName(group.first().title),
            items = group.sortedByDescending { it.createdAt }
        )
    }
    .sortedByDescending { it.newestAt }

/**
 * One grouped Downloads tile (item 18): a series/movie with
 * several downloaded files — shows the title, the episode count
 * and the combined size; tap opens the Downloads screen.
 */
@Composable
private fun DownloadGroupCard(
    group: DownloadGroup,
    onClick: () -> Unit
) {
    val palette = LocalPalette.current
    Column(
        modifier = Modifier
            .width(104.dp)
            .liquidGlass(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(9.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center
        ) {
            DownloadPosterArt(
                posterPath = group.posterItem?.posterPath,
                posterUrl = group.posterItem?.posterUrl,
                fallbackLabel = group.name,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 6.dp, bottom = 6.dp)
                    .size(20.dp)
                    .clip(RoundedCornerShape(50))
                    .background(palette.accent),
                contentAlignment = Alignment.Center
            ) {
                Text("↓", color = Color(0xFF04140B), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            group.name,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            "${group.items.size} episodes · ${formatDownloadSize(group.totalBytes)}",
            color = TextSecondary,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun formatDownloadSize(totalBytes: Long): String {
    if (totalBytes <= 0L) return ""
    val gb = totalBytes / 1_073_741_824.0
    if (gb >= 1.0) return "%.1f GB".format(gb)
    val mb = totalBytes / 1_048_576.0
    if (mb >= 1.0) return "%d MB".format(mb.toLong())
    return "%d KB".format(totalBytes / 1024L)
}

/**
 * One download's Library tile: a glass card with the title's saved
 * poster (owner's order, 2026-10-28 — the initial-letter tile
 * remains as the no-poster fallback), a download badge and the
 * file size — tap plays the file, same as the Downloads screen.
 */
@Composable
private fun DownloadCard(
    item: com.pulsestream.app.data.db.DownloadItem,
    onClick: () -> Unit
) {
    val palette = LocalPalette.current
    Column(
        modifier = Modifier
            .width(104.dp)
            .liquidGlass(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(9.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center
        ) {
            DownloadPosterArt(
                posterPath = item.posterPath,
                posterUrl = item.posterUrl,
                fallbackLabel = item.title,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 6.dp, bottom = 6.dp)
                    .size(20.dp)
                    .clip(RoundedCornerShape(50))
                    .background(palette.accent),
                contentAlignment = Alignment.Center
            ) {
                Text("↓", color = Color(0xFF04140B), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            item.title,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        formatDownloadSize(item.totalBytes).takeIf { it.isNotBlank() }?.let { size ->
            Text(size, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ConnectCard(onConnect: () -> Unit) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        palette.accent.copy(alpha = 0.12f),
                        palette.accent2.copy(alpha = 0.12f)
                    )
                ),
                RoundedCornerShape(16.dp)
            )
            .border(1.dp, palette.accent.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Bring your Trakt & Simkl",
                color = TextPrimary,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(3.dp))
            Text(
                "Connect once and your watchlists, progress and next episodes follow you here — and back.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(listOf(palette.accent, palette.accent2)),
                    RoundedCornerShape(50)
                )
                .clickable { onConnect() }
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                "Connect",
                color = Color(0xFF04140B),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

/**
 * Dedicated Upcoming view (v0.14.11, owner's order): the FULL
 * union-scan list behind the Upcoming button — the same
 * rows and day badges as the default-view section, uncapped.
 * Unlike the section it never hides itself: with nothing upcoming
 * it shows a calm empty state. Rows open the series' detail via
 * the same onOpenDetail path the section uses.
 */
@Composable
private fun UpcomingView(
    entries: List<ComingUpEntry>,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (entries.isEmpty()) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "No upcoming episodes",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Episodes appear here when series in your Library have air dates ahead.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    } else {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(top = 6.dp, bottom = 110.dp)
        ) {
            items(entries, key = { "upv_${it.metaId}" }) { entry ->
                ComingUpRow(
                    entry,
                    onClick = { onOpenDetail(entry.addonId, "series", entry.metaId) }
                )
            }
        }
    }
}

/** One Upcoming row (item 36): poster, show + episode line, day badge. */
@Composable
private fun ComingUpRow(entry: ComingUpEntry, onClick: () -> Unit) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .liquidGlass(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SafePosterImage(
            model = entry.poster,
            contentDescription = entry.showName,
            modifier = Modifier
                .width(46.dp)
                .height(64.dp)
                .clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.showName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                buildString {
                    append("S%02d E%02d".format(entry.season, entry.episode))
                    entry.episodeTitle?.let { append(" \u00b7 ").append(it) }
                },
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .background(palette.accent.copy(alpha = 0.13f), RoundedCornerShape(50))
                .border(1.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(50))
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Text(
                entry.badge,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = palette.accent
            )
        }
    }
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun UpNextRow(card: UpNextCard, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .liquidGlass(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(104.dp)
                .height(62.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.05f))
        ) {
            SafePosterImage(
                model = card.still ?: card.poster,
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            )
            // Play badge — ONE anchor for every card (owner's
            // order, v0.14.12: badges "looked not arranged"): the
            // thumbnail box's bottom-end corner, 5dp in, in the
            // canonical form shared by every Library thumbnail
            // badge — align to the corner, inset with end/bottom
            // padding, then size + clip + fill, so the anchor is
            // defined by the container alone. The artwork can
            // never move it: episode stills and poster crops both
            // Crop-fill this fixed box, only the picture under
            // the badge changes.
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 5.dp, bottom = 5.dp)
                    .size(19.dp)
                    .clip(RoundedCornerShape(50))
                    .background(palette.accent),
                contentAlignment = Alignment.Center
            ) {
                Text("▶", color = Color(0xFF04140B), fontSize = 8.sp)
            }
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                card.showTitle,
                color = TextPrimary,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                card.nextLabel,
                color = TextPrimary,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                card.metaLine,
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1
            )
            card.progress?.let { p ->
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .background(Color.White.copy(alpha = 0.13f), RoundedCornerShape(50))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(p.coerceIn(0f, 1f))
                            .height(4.dp)
                            .background(
                                Brush.horizontalGradient(listOf(palette.accent, palette.accent2)),
                                RoundedCornerShape(50)
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun FeedRow(
    title: String,
    serviceTag: String,
    tagColor: Color,
    metas: List<MetaPreview>,
    onOpenDetail: (addonId: String, type: String, metaId: String) -> Unit,
    onLongPress: (MetaPreview) -> Unit = {}
) {
    Column(Modifier.padding(top = 10.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                serviceTag,
                color = tagColor,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
        }
        // A feed can repeat a title; LazyRow keys must stay unique or
        // Compose throws the duplicate-key crash (same class as ActorScreen).
        val uniqueMetas = metas.distinctBy { it.type + "|" + it.id }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(top = 8.dp)
        ) {
            items(uniqueMetas, key = { "${it.type}_${it.id}" }) { meta ->
                PosterCard(
                    meta = meta,
                    onClick = { onOpenDetail("", meta.type, meta.id) },
                    onLongClick = { onLongPress(meta) }
                )
            }
        }
    }
}

@Composable
private fun ListCollageCard(
    list: CustomList,
    listsRepository: CustomListsRepository,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val items by listsRepository.observeItems(list.id).collectAsState(initial = emptyList())
    val posters = items.mapNotNull { it.poster }.take(4)
    Column(
        modifier = modifier
            .liquidGlass(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(9.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(76.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.05f))
        ) {
            if (posters.isEmpty()) {
                Text(
                    list.name.take(1).uppercase(),
                    color = TextSecondary,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                Row(Modifier.fillMaxSize()) {
                    posters.forEach { poster ->
                        SafePosterImage(
                            model = poster,
                            contentDescription = null,
                            modifier = Modifier.weight(1f).fillMaxSize()
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            list.name,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            "${items.size} titles",
            color = TextSecondary,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
