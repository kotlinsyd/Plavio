package com.pulsestream.app.ui.screens.player

import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import kotlinx.coroutines.delay

/**
 * The initial-load presentation (v0.14.33, owner's locked sample
 * "Poster Heartbeat + Status Line", replacing the 2026-10-24
 * "Backdrop + orbit" treatment on this path only): the title's
 * backdrop full-screen under a dark Onyx grade; bottom-left the
 * title and one quiet meta line; bottom-centre, lifted off the
 * edge, one useful line — the cast one name at a time
 * ("Starring …") when the meta carried cast, else the phase word
 * giving way to the picked source + quality once a pick exists —
 * above a frosted capsule whose status word names the phase the
 * wait is really in (see [PlayerLoadingPhase]), with live
 * elapsed seconds and a bar that eases toward 90% and never
 * fakes 100%.
 *
 * v0.14.36 (item 4 + owner's amendment): the title shows the
 * same CLEAR way as Home and Details — the title LOGO as a plain
 * image with no wash, shade or panel behind it, the styled
 * title text as the fallback — and the lub-dub heartbeat rides
 * the NAME (logo or text), not the backdrop: the poster stays
 * static. Everything else in the locked design is unchanged.
 *
 * [active] is the initial-load gate (buffering/switching before
 * the first frame, no fatal error). When it drops, the overlay
 * fades out over the first frames instead of vanishing. The
 * rebuffer presentation is NOT here — it stays the plain orbit
 * over the video, untouched.
 */
@Composable
fun PlayerLoadingOverlay(
    active: Boolean,
    request: PlaybackRequest,
    phase: PlayerLoadingPhase,
    modifier: Modifier = Modifier
) {
    val overlayAlpha by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(durationMillis = 320),
        label = "playerLoadingOverlayAlpha"
    )
    if (!active && overlayAlpha == 0f) return

    val accent = LocalPalette.current.accent
    val onyx = Color(0xFF070707)

    // The heartbeat: H1's lub-dub keyframes from the locked
    // sample, rises attacking expo-out, falls easing away.
    val beatTransition = rememberInfiniteTransition(label = "playerLoadingHeartbeat")
    val riseEasing = remember {
        CubicBezierEasing(
            HEARTBEAT_RISE_EASING[0], HEARTBEAT_RISE_EASING[1],
            HEARTBEAT_RISE_EASING[2], HEARTBEAT_RISE_EASING[3]
        )
    }
    val fallEasing = remember {
        CubicBezierEasing(
            HEARTBEAT_FALL_EASING[0], HEARTBEAT_FALL_EASING[1],
            HEARTBEAT_FALL_EASING[2], HEARTBEAT_FALL_EASING[3]
        )
    }
    val beatScale by beatTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = HEARTBEAT_CYCLE_MS
                HEARTBEAT_KEYFRAMES.forEachIndexed { index, (timeMs, scale) ->
                    if (index == HEARTBEAT_KEYFRAMES.lastIndex) {
                        scale at timeMs
                    } else if (heartbeatSegmentIsRise(index)) {
                        scale at timeMs with riseEasing
                    } else {
                        scale at timeMs with fallEasing
                    }
                }
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "playerLoadingHeartbeatScale"
    )

    // Live elapsed wait — restarts each time the load gate opens.
    var elapsedMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(active) {
        if (active) {
            val startMs = SystemClock.elapsedRealtime()
            while (true) {
                elapsedMs = SystemClock.elapsedRealtime() - startMs
                delay(50)
            }
        }
    }

    // The meta line fades in just after the title (the sample's
    // factsIn behaviour), then simply stays.
    val factsAlpha by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(durationMillis = 700, delayMillis = 350),
        label = "playerLoadingFactsAlpha"
    )

    // The useful line above the capsule (v0.14.34, owner's
    // completed design): cast one by one when the request
    // carried cast; otherwise the real phase word, giving way to
    // the picked source + quality the moment a pick truly
    // exists. A pick counts only once the request carries its
    // stream — the source/quality are read off the picked
    // request itself, never guessed. The line rides the same
    // elapsed clock as the bar, so it dies with the overlay.
    val infoLine = playerLoadingInfoLine(
        cast = request.cast,
        phase = phase,
        elapsedMs = elapsedMs,
        pickedSource = request.sourceName.takeIf { request.streamUrl.isNotBlank() },
        pickedQuality = request.streamLabel.takeIf { request.streamUrl.isNotBlank() }
    )

    Box(modifier.fillMaxSize().graphicsLayer { alpha = overlayAlpha }) {
        val art = playerLoadingArt(request.background, request.poster)
        if (art != null) {
            // v0.14.36: the backdrop is STATIC — the heartbeat
            // moved to the title name below. playerLoadingBackdropScale
            // pins the art's scale at 1f whatever the beat does.
            AsyncImage(
                model = art,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val still = playerLoadingBackdropScale(beatScale)
                        scaleX = still
                        scaleY = still
                    }
            )
        } else {
            // No art at all: plain Onyx, same texts (the fallback).
            Box(Modifier.fillMaxSize().background(onyx))
        }
        // Dark Onyx grading (the sample's two gradients).
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(
                    0f to onyx.copy(alpha = 0.42f),
                    0.55f to Color.Transparent
                )
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to onyx.copy(alpha = 0.50f),
                    0.42f to onyx.copy(alpha = 0.14f),
                    1f to onyx.copy(alpha = 0.68f)
                )
            )
        )

        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 24.dp, end = 24.dp, bottom = 20.dp)
                .widthIn(max = 560.dp)
        ) {
            LoadingTitleName(
                title = request.title,
                logo = request.logo,
                beatScale = beatScale
            )
            val metaLine = playerLoadingMetaLine(
                request.releaseInfo, request.runtime, request.genres, request.imdbRating
            )
            if (metaLine != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    metaLine,
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.graphicsLayer { alpha = factsAlpha }
                )
            }
        }

        // The bottom-centre group (owner's placement, v0.14.34 —
        // the capsule used to sit tucked under the title at the
        // bottom-left): the quiet useful line directly above the
        // capsule, both lifted off the edge by the one pinned
        // padding, the capsule its bottom item.
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = LOADING_CAPSULE_BOTTOM_PADDING_DP.dp)
        ) {
            Crossfade(
                targetState = infoLine,
                animationSpec = tween(durationMillis = 350),
                label = "playerLoadingInfoLine"
            ) { line ->
                Text(
                    line,
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(8.dp))
            // The capsule: blinking dot, honest bar, status word +
            // real elapsed seconds (the seconds never blink — only
            // the word crossfades when the phase changes).
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.07f))
                    .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(50))
                    .padding(start = 10.dp, end = 14.dp, top = 8.dp, bottom = 8.dp)
            ) {
                val dotTransition = rememberInfiniteTransition(label = "playerLoadingDot")
                val dotAlpha by dotTransition.animateFloat(
                    initialValue = 0.35f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 550),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "playerLoadingDotAlpha"
                )
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = dotAlpha))
                )
                Spacer(Modifier.width(11.dp))
                Box(
                    Modifier
                        .width(104.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(99))
                        .background(Color.White.copy(alpha = 0.18f))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(
                                playerLoadingBarFraction(elapsedMs / 1000.0)
                            )
                            .height(4.dp)
                            .clip(RoundedCornerShape(99))
                            .background(accent)
                    )
                }
                Spacer(Modifier.width(11.dp))
                Crossfade(
                    targetState = phase,
                    animationSpec = tween(durationMillis = 250),
                    label = "playerLoadingStatus"
                ) { currentPhase ->
                    Text(
                        playerLoadingStatusText(currentPhase),
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.5.sp,
                            fontFeatureSettings = "tnum"
                        ),
                        maxLines = 1
                    )
                }
                Spacer(Modifier.width(5.dp))
                Text(
                    formatLoadingElapsed(elapsedMs),
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.5.sp,
                        fontFeatureSettings = "tnum"
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * The loading overlay's title name (v0.14.36, item 4): the title
 * LOGO rendered BARE — a plain AsyncImage with no wash, shade or
 * panel behind it, the exact treatment of the Details and Home
 * heroes — taking the title's place in the bottom-left block
 * when the request carries a logo. The styled title text is the
 * fallback, including when the logo's load fails. Whichever form
 * shows, the NAME breathes: the heartbeat scale rides this
 * element; the backdrop poster stays static.
 */
@Composable
private fun LoadingTitleName(title: String, logo: String?, beatScale: Float) {
    var logoFailed by remember(logo) { mutableStateOf(false) }
    val breathing = Modifier.graphicsLayer {
        val scale = playerLoadingNameScale(beatScale)
        scaleX = scale
        scaleY = scale
    }
    if (playerLoadingLogoShown(logo, logoFailed)) {
        AsyncImage(
            model = logo,
            contentDescription = title,
            contentScale = ContentScale.Fit,
            onError = { logoFailed = true },
            modifier = breathing
                .height(LOADING_LOGO_HEIGHT_DP.dp)
                .widthIn(max = LOADING_LOGO_MAX_WIDTH_DP.dp)
        )
    } else {
        Text(
            title,
            color = TextPrimary,
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = 17.sp,
                shadow = androidx.compose.ui.graphics.Shadow(
                    Color.Black.copy(alpha = 0.65f),
                    offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                    blurRadius = 14f
                )
            ),
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = breathing
        )
    }
}
