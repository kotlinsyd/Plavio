package com.pulsestream.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.SUB_DEFAULT_ALWAYS_ON
import com.pulsestream.app.data.SUB_DEFAULT_OFF
import com.pulsestream.app.data.SUB_DEFAULT_ON_IN_MY_LANGUAGES
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.formatOffsetMs
import com.pulsestream.app.data.subtitleColorName
import com.pulsestream.app.data.subtitleDefaultModeName
import com.pulsestream.app.data.subtitleEdgeName
import com.pulsestream.app.data.subtitleLanguageName
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary

/**
 * Settings > Subtitles (v0.14.14, the complete list): language priority
 * and automatic behaviour, the full appearance defaults (mirroring the
 * player's Style rail values), the global timing default, and the
 * downloads / auto-fetch behaviour. Per-title adjustments (delay,
 * Auto Sync, style tweaks) stay in the player — Settings holds the
 * defaults only.
 */
@Composable
fun SubtitleSettingsScreen(
    repository: StreamRepository,
    onBack: () -> Unit = {},
    onGoToIntegrations: () -> Unit = {}
) {
    val settings = repository.settings
    var subLangs by remember { mutableStateOf(settings.subtitleLanguages) }
    var subLangPickerOpen by remember { mutableStateOf(false) }
    var subStyleOpen by remember { mutableStateOf(false) }
    var subStyleVersion by remember { mutableIntStateOf(0) }
    var defaultMode by remember { mutableIntStateOf(settings.subtitleDefaultMode) }
    var defaultModePickerOpen by remember { mutableStateOf(false) }
    var onlyMyLangs by remember { mutableStateOf(settings.subtitleOnlyMyLanguages) }
    var preferSdh by remember { mutableStateOf(settings.subtitlePreferSdh) }
    var forcedAuto by remember { mutableStateOf(settings.subtitleForcedAutoShow) }
    var saveWithDownloads by remember { mutableStateOf(settings.subtitleSaveWithDownloads) }
    var autoFetch by remember { mutableStateOf(settings.subtitleAutoFetchOnline) }
    // Global subtitle timing offset (ms). Applied to every title on load;
    // fine-tune per title in the player.
    var subOffsetMs by remember { mutableLongStateOf(settings.subtitleOffsetMs) }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Subtitles",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Which subtitles turn on automatically, and how they look.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(start = 56.dp, end = 8.dp)
                    )
                }
            }
            item(key = "sub_lang_group") {
                SettingsGroup(
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.Translate,
                            title = "Preferred subtitle languages",
                            subtitle = if (subLangs.isEmpty()) {
                                "Not set — first available subtitle is used"
                            } else {
                                subLangs.joinToString(", ") { subtitleLanguageName(it) }
                            },
                            onClick = { subLangPickerOpen = true }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.AutoMode,
                            title = "Subtitles by default",
                            subtitle = subtitleDefaultModeName(defaultMode),
                            onClick = { defaultModePickerOpen = true }
                        )
                    }
                )
            }
            item(key = "sub_behaviour_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.FilterAlt,
                            title = "Show only my languages",
                            subtitle = "The player's subtitle list shows just your languages",
                            checked = onlyMyLangs,
                            onCheckedChange = {
                                settings.subtitleOnlyMyLanguages = it
                                onlyMyLangs = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Hearing,
                            title = "Prefer SDH subtitles",
                            subtitle = "Hearing-impaired subtitles win when there's a choice",
                            checked = preferSdh,
                            onCheckedChange = {
                                settings.subtitlePreferSdh = it
                                preferSdh = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Subtitles,
                            title = "Auto-show forced subtitles",
                            subtitle = "Forced subtitles in your languages can turn on by themselves",
                            checked = forcedAuto,
                            onCheckedChange = {
                                settings.subtitleForcedAutoShow = it
                                forcedAuto = it
                            }
                        )
                    }
                )
            }
            item(key = "sub_appearance_group") {
                val styleSummary = remember(subStyleVersion) {
                    if (settings.useSystemCaptions) {
                        "System default (Android caption settings)"
                    } else {
                        "${subtitleColorName(settings.subtitleTextColor)} • " +
                            "${settings.subtitleFontSizeSp}sp • " +
                            subtitleEdgeName(settings.subtitleEdgeType)
                    }
                }
                SettingsGroup(
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.ClosedCaption,
                            title = "Subtitle appearance",
                            subtitle = styleSummary,
                            onClick = { subStyleOpen = true }
                        )
                    }
                )
            }
            // Global subtitle timing offset (v0.9.0+). Positive = subtitles
            // appear later, negative = earlier. Fine-tune per title in the
            // player's Subtitles sheet.
            item(key = "subTiming") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Schedule,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Subtitle timing",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                            Text(
                                "Shift all subtitles earlier or later",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(start = 36.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val next = (subOffsetMs - 500L).coerceIn(-10_000L, 10_000L)
                                settings.subtitleOffsetMs = next
                                subOffsetMs = next
                            }
                        ) {
                            Text("−500 ms")
                        }
                        Text(
                            formatOffsetMs(subOffsetMs),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        OutlinedButton(
                            onClick = {
                                val next = (subOffsetMs + 500L).coerceIn(-10_000L, 10_000L)
                                settings.subtitleOffsetMs = next
                                subOffsetMs = next
                            }
                        ) {
                            Text("+500 ms")
                        }
                    }
                    if (subOffsetMs != 0L) {
                        androidx.compose.material3.TextButton(
                            onClick = {
                                settings.subtitleOffsetMs = 0L
                                subOffsetMs = 0L
                            },
                            modifier = Modifier.padding(start = 28.dp)
                        ) {
                            Text(
                                "Reset timing",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            item(key = "sub_downloads_group") {
                SettingsGroup(
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.Download,
                            title = "Save subtitles with downloads",
                            subtitle = "Downloads keep the best subtitles in your languages",
                            checked = saveWithDownloads,
                            onCheckedChange = {
                                settings.subtitleSaveWithDownloads = it
                                saveWithDownloads = it
                            }
                        )
                    },
                    {
                        SettingsToggleRow(
                            icon = Icons.Filled.CloudDownload,
                            title = "Auto-fetch subtitles online",
                            subtitle = "When a title has no subtitles, search for them automatically",
                            checked = autoFetch,
                            onCheckedChange = {
                                settings.subtitleAutoFetchOnline = it
                                autoFetch = it
                            }
                        )
                    },
                    {
                        SettingsNavRow(
                            icon = Icons.Filled.Extension,
                            title = "Subtitle sources",
                            subtitle = "Subtitle addons, in Addons & Integrations",
                            onClick = onGoToIntegrations
                        )
                    }
                )
            }
        }
    }

    if (subLangPickerOpen) {
        SubtitleLanguagePickerDialog(
            initial = subLangs,
            onDismiss = { subLangPickerOpen = false },
            onDone = { langs ->
                settings.subtitleLanguages = langs
                subLangs = langs
                subLangPickerOpen = false
            }
        )
    }

    if (subStyleOpen) {
        SubtitleStyleDialog(
            settings = settings,
            onDismiss = {
                subStyleOpen = false
                subStyleVersion++
            }
        )
    }

    if (defaultModePickerOpen) {
        SubtitleDefaultModeDialog(
            initial = defaultMode,
            onDismiss = { defaultModePickerOpen = false },
            onDone = { mode ->
                settings.subtitleDefaultMode = mode
                defaultMode = mode
                defaultModePickerOpen = false
            }
        )
    }
}

/** Single-choice dialog for the "Subtitles by default" behaviour. */
@Composable
private fun SubtitleDefaultModeDialog(
    initial: Int,
    onDismiss: () -> Unit,
    onDone: (Int) -> Unit
) {
    var selected by remember { mutableIntStateOf(initial) }
    val options = listOf(
        Triple(
            SUB_DEFAULT_ON_IN_MY_LANGUAGES,
            "On in my languages",
            "Subtitles turn on when they're in one of your preferred languages"
        ),
        Triple(
            SUB_DEFAULT_ALWAYS_ON,
            "Always on",
            "A subtitle always turns on — your languages first, otherwise the first available"
        ),
        Triple(
            SUB_DEFAULT_OFF,
            "Off",
            "Subtitles never turn on by themselves — pick one in the player when you want it"
        )
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Subtitles by default", color = TextPrimary) },
        text = {
            Column {
                options.forEach { (mode, label, blurb) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected == mode,
                            onClick = { selected = mode },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = LocalPalette.current.accent
                            )
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(label, color = TextPrimary)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                blurb,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDone(selected) }) {
                Text(
                    "Done",
                    color = LocalPalette.current.accent,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
