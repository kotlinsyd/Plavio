@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.pulsestream.app.ui.screens

import com.pulsestream.app.ui.screens.player.*

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.AlertDialog
import com.pulsestream.app.ui.components.OrbitDots
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Checkbox
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.focusable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.res.stringResource
import com.pulsestream.app.MainActivity
import com.pulsestream.app.R
import com.pulsestream.app.ui.tv.rememberIsTv
import com.pulsestream.app.ui.tv.tvSheetFocus
import com.pulsestream.app.ui.tv.tvFocusRing
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.PlaybackException
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import com.pulsestream.app.player.PlavioAudioRenderersFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import com.pulsestream.app.data.ASPECT_MODES
import com.pulsestream.app.data.IntroDbApi
import com.pulsestream.app.data.PlaybackHeaders
import com.pulsestream.app.data.PlaybackRequest
import com.pulsestream.app.util.ExternalPlayer
import com.pulsestream.app.data.TvChannelRef
import com.pulsestream.app.data.ResolvedSubtitle
import java.util.concurrent.TimeUnit
import com.pulsestream.app.data.SkipSegment
import com.pulsestream.app.data.StreamItem
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.Subtitle
import com.pulsestream.app.data.PlavioSubsClient
import com.pulsestream.app.data.autoPickSubtitleIndex
import com.pulsestream.app.data.resolveSubtitleFiles
import com.pulsestream.app.data.shiftSubtitles
import com.pulsestream.app.data.formatOffsetMs
import com.pulsestream.app.data.Video
import com.pulsestream.app.data.subtitleLangMatches
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.scrobble.ScrobbleManager
import com.pulsestream.app.data.trakt.TraktManager
import com.pulsestream.app.data.buttonLabel
import com.pulsestream.app.data.streamQualityLabel
import com.pulsestream.app.data.isUnseekableStreamUrl
import com.pulsestream.app.ui.components.AddonTabs
import com.pulsestream.app.ui.components.ErrorState
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.components.DotsLoadingIndicator
import com.pulsestream.app.ui.components.SafePosterImage
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.components.StreamCard
import com.pulsestream.app.ui.components.StreamList
import com.pulsestream.app.ui.components.rememberStreamBrowserState
import coil.compose.AsyncImage
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.io.File
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Reference-style player: title block top-left, icon cluster top-right,
 * big center transport, slim seekbar + time chips, bottom pill toolbar
 * (Aspect / Speed / Subs / Audio / Sources / Episodes), edge volume pill,
 * and a controls lock — with all of Pulse's gesture strengths kept.
 */

/** Control-flow stop for the background source refresh (v0.14.17). */
private class StopStreamRefresh :
    kotlinx.coroutines.CancellationException("source refresh settled")

/** How many subtitle files the first prepare downloads (v0.14.17). */
private const val INITIAL_SUB_DOWNLOAD_CAP = 10

/**
 * The subtitle subset the FIRST resolve downloads (v0.14.17 lag
 * fix, audit cause 5): the user's preferred languages first (in
 * their priority order), then the rest in original order, capped —
 * user-added subtitles always ride along. Everything else resolves
 * lazily when the subtitle panel opens.
 */
private fun initialSubtitleSubset(
    all: List<com.pulsestream.app.data.Subtitle>,
    added: List<com.pulsestream.app.data.Subtitle>,
    preferred: List<String>
): List<com.pulsestream.app.data.Subtitle> {
    if (all.size <= INITIAL_SUB_DOWNLOAD_CAP) return all
    val ranked = all.sortedBy { sub ->
        val idx = preferred.indexOfFirst { code -> subtitleLangMatches(sub.lang, code) }
        if (idx >= 0) idx else Int.MAX_VALUE
    }
    val chosen = LinkedHashSet<com.pulsestream.app.data.Subtitle>()
    chosen.addAll(added)
    chosen.addAll(ranked.take(INITIAL_SUB_DOWNLOAD_CAP))
    return all.filter { it in chosen }
}

/** Text shadow that carries the Sample C revised top block and the
 *  bare icons over any video frame (no scrim, no glass up top). */
private val PLAYER_TEXT_SHADOW = Shadow(
    color = Color.Black.copy(alpha = 0.85f),
    offset = Offset(0f, 2f),
    blurRadius = 12f
)

/**
 * A Sample C detail badge (v0.14.14, item 2): small frosted chip —
 * white 16% fill, white 28% rim, bold 10.5sp — QUALITY / SOURCE /
 * SUBS under the player's meta line.
 */
@Composable
private fun PlayerBadge(text: String) {
    Box(
        Modifier
            .background(Color.White.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp,
            color = TextPrimary,
            maxLines = 1
        )
    }
}

/**
 * A bare icon with ONLY a drop shadow (Sample C revised top-right /
 * centre style): a black copy of the glyph offset 2dp below the
 * white one — Compose icons take no shadow of their own, so the
 * shadow is drawn as the duplicate glyph.
 */
@Composable
private fun BareShadowIcon(
    imageVector: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    glyphSize: androidx.compose.ui.unit.Dp = 24.dp,
    tint: Color = TextPrimary
) {
    Box(modifier.size(glyphSize)) {
        Icon(
            imageVector, null,
            tint = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier.offset(y = 2.dp).size(glyphSize)
        )
        Icon(imageVector, contentDescription, tint = tint, modifier = Modifier.size(glyphSize))
    }
}

/**
 * The runtime tail of the Sample C meta line (" · 39 min"), read in
 * its own tiny composable so duration updates never recompose the
 * header block. Empty until the player reports a duration.
 */
@Composable
private fun PlayerRuntimeText(durationMsState: State<Long>, leadingSeparator: Boolean) {
    val durationMs = durationMsState.value
    if (durationMs <= 0L) return
    Text(
        (if (leadingSeparator) " · " else "") + "${durationMs / 60_000L} min",
        style = MaterialTheme.typography.bodyMedium.copy(
            fontSize = 13.sp,
            shadow = PLAYER_TEXT_SHADOW
        ),
        color = TextPrimary.copy(alpha = 0.8f),
        maxLines = 1
    )
}

/**
 * The seek ROW — current time, the track with its accent
 * light-orb, total time. Sample C (v0.14.14) gave it a frosted
 * capsule of its own; Aurora Dock v3 (v0.14.16) folds it into the
 * ONE bottom capsule, so the glass shell now lives with the
 * caller and this is just the row. Still reads the 500 ms-polled
 * position states INSIDE this small composable (v0.14.17 lag fix,
 * audit cause 5), so the poll's writes recompose only this
 * cluster.
 */
@Composable
private fun PlayerSeekControls(
    positionMsState: State<Long>,
    durationMsState: State<Long>,
    onSeek: (Long) -> Unit,
    isTv: Boolean,
    onSeekDelta: (Long) -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onScrubChanged: ((Boolean) -> Unit)? = null
) {
    val positionMs = positionMsState.value
    val durationMs = durationMsState.value
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            formatMs(positionMs),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        SlimSeekBar(
            positionMs = positionMs,
            durationMs = durationMs,
            onSeek = onSeek,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            isTv = isTv,
            onSeekDelta = onSeekDelta,
            onFocusChanged = onFocusChanged,
            onScrubChanged = onScrubChanged
        )
        Text(
            formatMs(durationMs),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    repository: StreamRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val initialRequest = repository.pendingPlayback
    val settings = repository.settings

    // Sources dressing (Sample 1): addon logos for the Sources sheet tabs.
    var playerAddonLogos by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    LaunchedEffect(Unit) { playerAddonLogos = repository.addonLogosByName() }

    // PiP (v0.9.0+): track whether the video floats so overlay UI can hide,
    // and mark the player active so MainActivity.onUserLeaveHint auto-enters
    // PiP when Home/recents is pressed mid-playback.
    val inPip by MainActivity.pipMode.collectAsState()
    // PiP dismissed via its X button: MainActivity bumps the counter (the
    // screen never leaves composition on its own in that path) — exit
    // through the normal back path so onDispose stops and releases.
    val pipDismissCount by MainActivity.pipDismissedCount.collectAsState()
    val pipDismissBaseline = remember { pipDismissCount }
    LaunchedEffect(pipDismissCount) {
        if (pipDismissCount != pipDismissBaseline) onBack()
    }
    DisposableEffect(Unit) {
        MainActivity.isPlayerActive = true
        // Cross-audit D-c: auto-PiP arms on CONFIRMED playback only. A
        // freshly composed player is still loading, so the shared flag
        // starts false here; the player listener's onIsPlayingChanged
        // flips it via updatePipActions as play state becomes real.
        MainActivity.pipIsPlaying = false
        onDispose { MainActivity.isPlayerActive = false }
    }

    // (Back handling is registered below, after the UI state it depends on.)

    if (initialRequest == null) {
        GlowBackground { ErrorState("Nothing to play.", onRetry = onBack) }
        return
    }

    val audioManager = remember {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    val ioScope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    /** Main-thread poster for the progress-save path (v0.14.24 crash fix). */
    val mainHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    val isTv = rememberIsTv()
    /**
     * Set in onDispose. Background work (zap, episode load, source switch)
     * checks this before building a new ExoPlayer so no player is ever
     * created on disposed state (#9).
     */
    val disposed = remember { AtomicBoolean(false) }
    /** Monotonic generation: a stale subtitle transform may never overwrite a newer selection/offset. */
    val subtitleShiftGeneration = remember { AtomicInteger(0) }
    /** Non-null while the current stream is in a failed state (#4). */
    var playerError by remember { mutableStateOf<String?>(null) }
    /** Auto-failover count; generic playback caps at 3, mobile Live uses its policy cap. */
    var autoFailoverCount by remember { mutableStateOf(0) }
    /** Bounded recovery budget for streams that play and later stall, per channel session. */
    var liveRebufferRecoveries by remember { mutableIntStateOf(0) }
    /** Invalidates callbacks from listeners attached to released/replaced players. */
    val activePlayerListenerGeneration = remember { AtomicInteger(0) }

    // ---- Playback feedback (v0.14.28) ----
    // Anonymous per-attempt outcomes to PlavioHD /feedback, so source
    // health is measured from real playback. The tracker is a pure
    // state machine (FeedbackSupport.Tracker); this screen only feeds
    // it facts — attempt boundaries (the effect beside
    // currentRequest), poll ticks, and errors at the death points —
    // and ships what it emits through sendFeedback, off the playback
    // path, every failure swallowed. Trailers and Live are never
    // tracked (YouTube and the live policy keep their own health
    // systems); the reporter itself is gated on the AppConfig
    // "feedback" switch inside PlavioFeedback + sendFeedback.
    val feedbackTracker = remember { com.pulsestream.app.data.FeedbackSupport.Tracker() }

    fun sendFeedback(outcome: com.pulsestream.app.data.FeedbackSupport.Outcome) {
        if (!com.pulsestream.app.data.AppConfig.feedbackEnabled()) return
        ioScope.launch {
            val base = runCatching { repository.plavioHdBaseUrl() }.getOrNull()
                ?: return@launch
            com.pulsestream.app.data.PlavioFeedback.report(
                context.applicationContext, base, outcome
            )
        }
    }
    feedbackTracker.sink = { outcome -> sendFeedback(outcome) }

    /** Feedback title identity for a request: the IMDb id when the
     *  title carries one, else the meta id / video id's own prefix. */
    fun feedbackTitleId(req: PlaybackRequest): String =
        req.imdbId?.takeIf { it.isNotBlank() }
            ?: req.metaId.takeIf { it.startsWith("tt") }
            ?: req.videoId.substringBefore(":")

    /**
     * Extracts the classifier facts from a player error: the HTTP
     * status when the chain carries one, the root-cause kinds, and
     * the error-code family (symbolic Media3 constants — the numeric
     * mapping lives here, never in the pure classifier).
     */
    fun feedbackErrorFacts(error: PlaybackException): com.pulsestream.app.data.FeedbackSupport.RawError {
        var httpStatus: Int? = null
        val kinds = mutableSetOf<com.pulsestream.app.data.FeedbackSupport.CauseKind>()
        generateSequence<Throwable>(error) { it.cause }.take(12).forEach { t ->
            when (t) {
                is HttpDataSource.InvalidResponseCodeException -> httpStatus = t.responseCode
                is SocketTimeoutException -> kinds += com.pulsestream.app.data.FeedbackSupport.CauseKind.TIMEOUT
                is InterruptedIOException -> kinds += com.pulsestream.app.data.FeedbackSupport.CauseKind.TIMEOUT
                is UnknownHostException -> kinds += com.pulsestream.app.data.FeedbackSupport.CauseKind.DNS
                is ConnectException -> kinds += com.pulsestream.app.data.FeedbackSupport.CauseKind.CONNECT
                is SSLException -> kinds += com.pulsestream.app.data.FeedbackSupport.CauseKind.SSL
            }
        }
        val family = when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.BAD_HTTP_STATUS
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.FILE_NOT_FOUND
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.NETWORK_TIMEOUT
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.NETWORK_CONNECTION_FAILED
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODING_RESOURCES_RECLAIMED ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.DECODER
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.AUDIO_TRACK
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
                com.pulsestream.app.data.FeedbackSupport.ErrorFamily.PARSING
            else -> com.pulsestream.app.data.FeedbackSupport.ErrorFamily.OTHER
        }
        return com.pulsestream.app.data.FeedbackSupport.RawError(family, httpStatus, kinds)
    }

    // Leaving the player settles the live attempt (a pre-playback
    // exit is the user's cancellation; anything already reported
    // stands). Runs alongside the other dispose hooks, never instead.
    DisposableEffect(Unit) {
        onDispose { feedbackTracker.onScreenExit() }
    }

    /** Nuvio parity: self-heal — probe Content-Type and retry once on format errors. */
    var mimeHealAttempted by remember { mutableStateOf(false) }
    /**
     * Set after player state exists; invoked by errorListener for the
     * self-heal path. Indirection avoids forward-reference issues.
     */
    var healOnFormatError: ((PlaybackException) -> Unit)? by remember { mutableStateOf(null) }
    /**
     * Set after the local helpers below are declared; invoked by errorListener
     * for the auto-failover path. Indirection avoids forward-reference issues
     * (same pattern as healOnFormatError).
     */
    var failoverToNextSource: ((attempt: Int) -> Unit)? by remember { mutableStateOf(null) }
    /**
     * Error ladder, rung 0 (mobile overhaul): set after the player
     * helpers exist; invoked by errorListener for decoder-family
     * errors — rebuilds the player once with fresh decoders at the
     * failure position. Returns true when it handled the error.
     */
    var decoderRebuildHook: (() -> Boolean)? by remember { mutableStateOf(null) }
    /**
     * Error ladder entry (mobile overhaul): assigned once the ladder
     * helpers exist; the Exo error listener (above) and the MPV engine
     * both call it. Declared here, with the other hooks, because the
     * error listener sits before the engine block in this composable.
     */
    var fatalErrorHook: ((com.pulsestream.app.player.PlaybackEngine, String, Boolean) -> Unit)? by remember {
        mutableStateOf(null)
    }
    /** Indirection: assigned once the subtitle plumbing exists; the
     *  MPV engine calls it when a file finishes loading. */
    var mpvFileLoadedHook: (() -> Unit)? by remember { mutableStateOf(null) }
    /** Indirection: assigned next to savePosition(); early helpers
     *  (seek paths) request progress saves through it. */
    var savePositionHook: (() -> Unit)? by remember { mutableStateOf(null) }
    /** Indirection: the credential-refresh rung calls replaceStream
     *  through this — replaceStream is declared further down. */
    var replaceStreamHook: ((PlaybackRequest, Long, Boolean) -> Unit)? by remember {
        mutableStateOf(null)
    }
    /**
     * Item 14 (v0.14.24): set after the player helpers exist; the
     * error listener calls it for retryable errors — it re-prepares
     * the SAME stream on the same engine (patient same-source
     * retries) before the ladder's later rungs are considered.
     * Returns true when a retry was launched.
     */
    var sameStreamRetryHook: (() -> Boolean)? by remember { mutableStateOf(null) }
    /**
     * Item 16 (end-as-error fix): set after the next-episode helpers are
     * declared; invoked by errorListener when a playback error lands in
     * the tail of a series episode. Returns true when the error was
     * treated as the episode's END (next-episode suggestion/countdown
     * armed) and the error panel must NOT show. Same indirection
     * pattern as [failoverToNextSource].
     */
    var armNextEpisodeAtTail: (() -> Boolean)? by remember { mutableStateOf(null) }
    /**
     * Registered on every player instance we build (#4). ExoPlayer invokes
     * listeners on the player's application thread (main here), so touching
     * Compose state directly is safe.
     */
    val errorListener = remember {
        object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (disposed.get()) return
                val cause = generateSequence<Throwable>(error) { it.cause }.firstOrNull {
                    it::class.java.simpleName == "UnrecognizedInputFormatException"
                }
                if (cause != null && !mimeHealAttempted) {
                    mimeHealAttempted = true
                    healOnFormatError?.invoke(error)
                    return
                }
                // Item 16 (end-as-error): a series episode whose stream
                // dies in its last ~2% (or past the outro) has EFFECTIVELY
                // FINISHED — fragile hosts error on the final bytes
                // instead of reaching STATE_ENDED, and the Skip-outro
                // seek used to manufacture exactly this. Arm the
                // next-episode suggestion/countdown instead of failing
                // over or landing on the Retry/Source panel. Genuine
                // mid-episode errors fall through to the normal paths.
                if (armNextEpisodeAtTail?.invoke() == true) {
                    autoFailoverCount = 0
                    return
                }
                // Mobile Live keeps its separate bounded forward-only
                // policy (house system, untouched by the overhaul).
                val mobileLiveFallback = com.pulsestream.app.data.LivePlaybackPolicy.shouldRetry(
                    isLive = initialRequest.isLive,
                    isTv = isTv,
                    errorCode = error.errorCode,
                    attemptsSoFar = autoFailoverCount
                )
                if (mobileLiveFallback) {
                    // Feedback: this attempt died — report before failing over.
                    feedbackTracker.onAttemptError(feedbackErrorFacts(error))
                    autoFailoverCount++
                    if (initialRequest.isLive && !isTv) {
                        com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_attempt", 0)
                    }
                    failoverToNextSource?.invoke(autoFailoverCount)
                    return
                }
                if (initialRequest.isLive && !isTv &&
                    com.pulsestream.app.data.LivePlaybackPolicy.isRecoverableSourceError(error.errorCode)) {
                    com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_exhausted", 0)
                }
                // Error ladder (mobile overhaul, 2026-11-06) for VOD:
                // the MIME heal above was rung 0; a decoder-family
                // error gets ONE in-place decoder rebuild; everything
                // else enters the ladder — credential refresh, then
                // the one silent engine failover, then a plain error
                // screen with one Back. A playback error NEVER
                // auto-switches the source any more (the silent-stall
                // watchdog below keeps its own pre-existing behaviour:
                // it handles streams that hang without ever erroring).
                if (!initialRequest.isLive && !initialRequest.isTrailer) {
                    // Item 14 (v0.14.24, owner's source-switch rule):
                    // the player never moves on until the current
                    // source is 100% proven dead. A permanent HTTP
                    // status (400/401/403/404/410) proves THIS link
                    // dead instantly — no same-link retry is wasted
                    // on it, and the ladder's same-provider refresh
                    // (which can mint a NEW link) decides next. Any
                    // other error first gets patient retries of the
                    // SAME stream (below), and only then the ladder.
                    val permanentHttpStatus = feedbackErrorFacts(error).httpStatus
                        ?.takeIf { it in setOf(400, 401, 403, 404, 410) }
                    val isDecoderError = error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODING_FAILED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_DECODING_RESOURCES_RECLAIMED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
                    // Item 11 classification (v0.14.26): a PLAYER
                    // fault is the engine failing on the stream —
                    // decoder/codec, audio-track, or an unparseable /
                    // unsupported container or manifest format.
                    // Everything else (IO, HTTP, network, timeouts)
                    // is a SOURCE fault. The classification travels
                    // with the fatal call so the ladders never cross.
                    val isParsingError = error.errorCode ==
                        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
                        error.errorCode ==
                        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
                    val playerFault = permanentHttpStatus == null &&
                        (isDecoderError || isParsingError)
                    if (permanentHttpStatus == null) {
                        if (isDecoderError && decoderRebuildHook?.invoke() == true) {
                            return
                        }
                        // Patient same-source retries (item 14):
                        // re-prepare the SAME stream before the
                        // ladder spends its later rungs.
                        if (sameStreamRetryHook?.invoke() == true) {
                            return
                        }
                    }
                    feedbackTracker.onAttemptError(feedbackErrorFacts(error))
                    fatalErrorHook?.invoke(
                        com.pulsestream.app.player.PlaybackEngine.EXO,
                        error.message?.takeIf { it.isNotBlank() }
                            ?: "Playback failed (code ${error.errorCode})",
                        playerFault
                    )
                    return
                }
                // Feedback: terminal error — this attempt died here.
                feedbackTracker.onAttemptError(feedbackErrorFacts(error))
                autoFailoverCount = 0
                playerError = error.message?.takeIf { it.isNotBlank() }
                    ?: "Playback failed (code ${error.errorCode})"
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                // Keeps the PiP window's play/pause RemoteAction icon in sync.
                (activity as? MainActivity)?.updatePipActions(isPlaying)
                // Reset auto-failover counter on successful playback
                if (isPlaying) autoFailoverCount = 0
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                // Keeps the PiP aspect ratio current (portrait videos float
                // portrait like YouTube) for Home-press auto-PiP.
                if (videoSize.width > 0 && videoSize.height > 0) {
                    MainActivity.pipVideoW = videoSize.width
                    MainActivity.pipVideoH = videoSize.height
                }
            }
        }
    }

    /** Each player gets its own listener wrapper; stale instances become inert immediately. */
    fun guardedPlayerListener(): Player.Listener {
        val generation = activePlayerListenerGeneration.incrementAndGet()
        return object : Player.Listener {
            private fun isCurrent() = !disposed.get() && activePlayerListenerGeneration.get() == generation
            override fun onPlayerError(error: PlaybackException) {
                if (isCurrent()) errorListener.onPlayerError(error)
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isCurrent()) errorListener.onIsPlayingChanged(isPlaying)
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (isCurrent()) errorListener.onVideoSizeChanged(videoSize)
            }
        }
    }

    /**
     * Title key for the remembered subtitle choice (v0.14.15): the
     * series identity for episodes (IMDb id, else the series meta id,
     * else the video id's series prefix) so one manual pick covers
     * the whole series; the title identity for movies. Null for
     * trailers and live, which never remember.
     */
    fun subtitleMemoryKey(req: PlaybackRequest): String? {
        if (req.isTrailer || req.isLive) return null
        val id = req.imdbId?.takeIf { it.isNotBlank() }
            ?: req.metaId.takeIf { it.isNotBlank() }
            ?: req.videoId.substringBefore(":").takeIf { it.isNotBlank() }
            ?: return null
        return if (req.isMovie) "movie|$id" else "series|$id"
    }

    /** The subtitle choice the user hand-picked for [req]'s title/series, if any. */
    fun rememberedSubtitleChoice(req: PlaybackRequest): String? =
        subtitleMemoryKey(req)?.let { settings.subtitleChoiceFor(it) }

    /**
     * The index of the subtitle that should be showing by default:
     * an explicit URL from this session's panel tap wins, then the
     * remembered per-title pick (v0.14.15 — "off" keeps the title
     * subtitle-free, a remembered URL/language selects its file when
     * this playback offers it), then the automatic choice (v0.14.14:
     * the "Subtitles by default" mode, the language priority order,
     * the SDH preference and the forced-track rule from
     * Settings > Subtitles). -1 = no default subtitle.
     *
     * Since the overhaul the sidecar renderer (not the media item)
     * displays addon subtitles, so this index drives sidecar
     * activation; the media-item builder below is kept for shape
     * compatibility and no longer attaches anything.
     */
    fun defaultSubtitleIndex(
        resolved: List<ResolvedSubtitle>,
        defaultUrl: String? = null,
        req: PlaybackRequest
    ): Int {
        if (resolved.isEmpty()) return -1
        val autoIndex = autoPickSubtitleIndex(
            resolved.map { it.sub },
            settings.subtitleLanguages,
            settings.subtitleDefaultMode,
            settings.subtitlePreferSdh,
            settings.subtitleForcedAutoShow
        )
        val remembered = rememberedSubtitleChoice(req)
        return when {
            defaultUrl != null ->
                // The session's explicit tap (stored as a match key
                // since v0.14.30 — see addExternalSubtitle).
                resolved.indexOfFirst {
                    com.pulsestream.app.ui.screens.player.subtitleMatchKey(it.sub.url) ==
                        defaultUrl
                }.takeIf { it >= 0 } ?: -1
            remembered == "off" -> -1
            remembered?.startsWith("url:") == true -> {
                // Remembered picks are stored with the URL as listed
                // when picked; match spelling-tolerantly (v0.14.30),
                // exact-URL installs keep working via the fast path
                // inside findResolvedForPick.
                val target = remembered.removePrefix("url:")
                val hit = com.pulsestream.app.ui.screens.player
                    .findResolvedForPick(resolved, target)
                if (hit != null) resolved.indexOf(hit) else autoIndex
            }
            remembered?.startsWith("lang:") == true ->
                resolved.indexOfFirst {
                    it.sub.lang.equals(remembered.removePrefix("lang:"), ignoreCase = true)
                }.takeIf { it >= 0 } ?: autoIndex
            else -> autoIndex
        }
    }

    /**
     * Builds subtitle configurations from already-resolved (downloaded +
     * format-sniffed) subtitle files, with the same default-selection rules
     * as [attachResolvedSubtitles].
     */
    fun subtitleConfigs(
        resolved: List<ResolvedSubtitle>,
        defaultUrl: String? = null,
        req: PlaybackRequest
    ): List<MediaItem.SubtitleConfiguration> {
        if (resolved.isEmpty()) return emptyList()
        val defaultIndex = defaultSubtitleIndex(resolved, defaultUrl, req)
        return resolved.mapIndexed { index, r ->
            MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(r.file))
                .setMimeType(r.mimeType)
                .setLanguage(r.sub.lang)
                .setId(r.sub.url)
                .apply { if (index == defaultIndex) setSelectionFlags(C.SELECTION_FLAG_DEFAULT) }
                .build()
        }
    }

    /**
     * Builds the player for a request. Already-resolved side-loaded subtitles
     * can be passed in so the player carries them from its first prepare —
     * attaching them later would force a setMediaItem+prepare() and a visible
     * rebuffer (#29). Their URLs rarely carry a usable file extension, so
     * still-unresolved subtitle lists are resolved in the background and
     * attached via [attachResolvedSubtitles].
     */
    /** Builds the playback HTTP data source using platform TLS validation. */
    fun buildPlaybackDataSourceFactory(
        headers: Map<String, String>,
        originUrl: String
    ): androidx.media3.datasource.DataSource.Factory {
        // The force-seek pref is read HERE, at data-source construction
        // (owner order 2026-10-30), so toggling it in Settings applies to
        // the next title played with no other wiring.
        val httpFactory = com.pulsestream.app.data.PlaybackHttp.factory(
            originUrl,
            headers,
            forceSeek = settings.forceSeekAnyStream
        )
        // DefaultDataSource delegates per URI scheme: FileDataSource for
        // file:// (downloads), HttpDataSource for http(s):// (streams).
        return DefaultDataSource.Factory(context, httpFactory)
    }

    /**
     * MediaSource.Factory for a request (headers + optional disk cache).
     * Shared by [buildPlaybackMediaSource] and the player's own factory so
     * later setMediaItem calls use the same networking.
     */
    fun playbackMediaSourceFactory(req: PlaybackRequest): MediaSource.Factory {
        val playbackHeaders = PlaybackHeaders.buildPlaybackHeaders(req.headers, isTv)
        val dataSourceFactory = buildPlaybackDataSourceFactory(playbackHeaders, req.streamUrl)
        val cacheMb = settings.diskCacheMb
        // v0.14.19: PlavioExtractorsFactory — stock extractors with
        // the tail-cues Matroska fork (recovers tail-only Cues so
        // those MKVs get a seekable SeekMap; see media/mkv). Media3
        // 1.4.1 takes the extractors factory via the constructor.
        val extractorsFactory = com.pulsestream.app.media.PlavioExtractorsFactory()
        return if (cacheMb > 0) {
            val cacheDataSourceFactory = CacheDataSource.Factory()
                .setCache(PlaybackCache.get(context, cacheMb * 1024L * 1024L))
                .setUpstreamDataSourceFactory(dataSourceFactory)
            DefaultMediaSourceFactory(cacheDataSourceFactory, extractorsFactory)
        } else {
            DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)
        }
    }

    /**
     * Builds the MediaSource for a request. YouTube DASH qualities are
     * video-only — when [PlaybackRequest.mergeAudioUrl] is set, the video is
     * merged with that audio stream so every quality plays with sound.
     */
    fun buildPlaybackMediaSource(
        req: PlaybackRequest,
        subs: List<ResolvedSubtitle> = emptyList(),
        forcedMime: String? = null
    ): MediaSource {
        val mediaSourceFactory = playbackMediaSourceFactory(req)
        // Nuvio parity: infer HLS/DASH from the FULL URL (path + query) so
        // proxied URLs like /api/manifest?url=<encoded ...m3u8> play as HLS
        // instead of being misidentified as progressive.
        val inferredMime = forcedMime
            ?: com.pulsestream.app.data.PlaybackContentProbe.recognizedMime(req.mimeType)
            ?: PlaybackHeaders.inferMimeType(req.streamUrl)
        val videoItem = MediaItem.Builder()
            .setUri(req.streamUrl)
            .apply { inferredMime?.let { setMimeType(it) } }
            // Mobile overhaul (2026-11-06): addon subtitles NEVER ride
            // the media item any more — the sidecar renderer parses
            // them off-player and pushes cues into the SubtitleView on
            // its 100 ms loop, so picking/changing a subtitle (or its
            // delay) never re-prepares the media. Embedded tracks are
            // unaffected: they live inside the video file itself.
            .setSubtitleConfigurations(emptyList())
            .build()
        val mergeAudio = req.mergeAudioUrl
        return if (mergeAudio != null) {
            MergingMediaSource(
                mediaSourceFactory.createMediaSource(videoItem),
                mediaSourceFactory.createMediaSource(MediaItem.fromUri(mergeAudio))
            )
        } else {
            mediaSourceFactory.createMediaSource(videoItem)
        }
    }

    fun buildExo(
        req: PlaybackRequest,
        subs: List<ResolvedSubtitle> = emptyList(),
        forcedMime: String? = null
    ): ExoPlayer {
        val prefs = settings.subtitleLanguages
        val audioPref = settings.preferredAudioLanguage
        // Memory-conscious buffering: on low-RAM devices (e.g. 48MB-heap TVs)
        // the default ~50s HLS buffer exhausts the heap mid-playback and OOMs.
        // The user's buffer settings (Settings > Playback > Buffer & Cache)
        // apply here, capped to the safe low-memory window on such devices.
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val lowMemory = am.isLowRamDevice || am.memoryClass <= 64
        val minBufferMs = if (lowMemory) minOf(settings.bufferMinMs, 15_000) else settings.bufferMinMs
        // Player audit 2026-10-27 (finding 5): on the untouched "Balanced"
        // default (50 s), raise the VOD ceiling to 90 s of media so variable
        // Wi-Fi has more runway. An explicit user choice (Low / Aggressive /
        // custom) is always respected verbatim, and Live is untouched.
        val maxBufferMs = when {
            lowMemory -> minOf(settings.bufferMaxMs, 30_000)
            !req.isLive && settings.bufferMaxMs == 50_000 -> 90_000
            else -> settings.bufferMaxMs
        }
        val forPlaybackMs = if (lowMemory) minOf(settings.bufferForPlaybackMs, 2_500) else settings.bufferForPlaybackMs
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ minBufferMs,
                /* maxBufferMs = */ maxBufferMs,
                /* bufferForPlaybackMs = */ forPlaybackMs,
                /* bufferForPlaybackAfterRebufferMs = */ (forPlaybackMs * 2).coerceAtMost(30_000)
            )
            // Keep the last 30 s behind the playhead so a short seek back
            // replays instantly instead of re-downloading (audit finding 5).
            // Skipped on low-memory devices, where the heap is the constraint.
            .apply { if (!lowMemory) setBackBuffer(30_000, /* retainBackBufferFromKeyframe = */ true) }
            .build()
        val mediaSourceFactory = playbackMediaSourceFactory(req)
        return ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .setRenderersFactory(PlavioAudioRenderersFactory(context))
            .setMediaSourceFactory(mediaSourceFactory)
            // Belt and suspenders: also tell the track selector the preferred
            // subtitle languages, so his languages win even if the default
            // flag is ever ignored.
            .setTrackSelector(
                DefaultTrackSelector(context).apply {
                    val params = buildUponParameters()
                    // Player audit 2026-10-27 (finding 2): the Settings
                    // quality cap used to steer only which SOURCE got picked;
                    // an adaptive (HLS/DASH) set could still climb past it
                    // inside the player, and a heavy rendition judders on
                    // modest hardware. Apply the same cap here: a fixed
                    // autoplay-quality bucket wins, "Auto" follows the
                    // adaptive device+network cap. TrackSelectionParameters
                    // defaults (exceedVideoConstraintsIfNecessary) mean a
                    // lone over-cap progressive track still plays — the cap
                    // steers adaptive sets, it never black-screens a file.
                    val capBucket = settings.autoplayQuality.takeIf { it != "Auto" }
                        ?: settings.adaptiveQualityCap()
                    val (capHeightPx, capBitrateBps) = when (capBucket) {
                        "1080p" -> 1080 to 40_000_000
                        "720p" -> 720 to 12_000_000
                        "480p" -> 480 to 5_000_000
                        else -> Int.MAX_VALUE to Int.MAX_VALUE // 2160p / unknown: uncapped
                    }
                    if (capHeightPx != Int.MAX_VALUE) {
                        params.setMaxVideoSize(Int.MAX_VALUE, capHeightPx)
                        params.setMaxVideoBitrate(capBitrateBps)
                    }
                    // Remembered per-title pick (v0.14.15) outranks the
                    // global default for THIS title/series: "off" starts
                    // text disabled, a remembered language steers the
                    // selector (that's also how embedded picks return).
                    val rememberedSub = rememberedSubtitleChoice(req)
                    if (settings.subtitleDefaultMode ==
                        com.pulsestream.app.data.SUB_DEFAULT_OFF ||
                        rememberedSub == "off"
                    ) {
                        // "Subtitles by default: Off" (v0.14.14): text
                        // tracks start disabled — embedded ones included.
                        // Picking a track in the panel re-enables the
                        // type (applySubtitleSelection), "None" disables
                        // it again, so the choice stays a default, not
                        // a lock.
                        params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    } else if (rememberedSub?.startsWith("lang:") == true) {
                        params.setPreferredTextLanguages(
                            rememberedSub.removePrefix("lang:")
                        )
                    } else if (prefs.isNotEmpty()) {
                        params.setPreferredTextLanguages(*prefs.toTypedArray())
                    }
                    // Preferred audio language (Settings > Playback): when the
                    // title's audio tracks include it, ExoPlayer picks it
                    // automatically at playback start.
                    if (!audioPref.isNullOrBlank()) {
                        params.setPreferredAudioLanguages(audioPref)
                    }
                    setParameters(params)
                }
            )
            .build()
            .apply {
                // Background audio (v0.14.13, item 6): keep the CPU
                // (and Wi-Fi for network streams) awake so playback
                // continues with the screen off while the foreground
                // PlaybackService holds the media session.
                setWakeMode(
                    if (req.streamUrl.startsWith("file:", true) ||
                        req.streamUrl.startsWith("content:", true)
                    ) {
                        C.WAKE_MODE_LOCAL
                    } else {
                        C.WAKE_MODE_NETWORK
                    }
                )
                // YouTube DASH (video-only + merged audio) goes through
                // setMediaSource; everything else keeps the setMediaItem path.
                setMediaSource(buildPlaybackMediaSource(req, subs, forcedMime))
            }
    }


    /**
     * Applies the user's subtitle styling (Settings > Playback) to the
     * PlayerView's caption view: text color, size, background/shade and
     * edge style. Called when the view is created and on every update.
     *
     * SYSTEM-CAPTIONS HOOK (fix #20): when the user picked "System
     * default", skip setStyle() entirely so Android's
     * Settings > Accessibility > Captions preferences apply.
     */
    fun applySubtitleStyle(pv: PlayerView) {
        if (settings.useSystemCaptions) return
        val sv = pv.subtitleView ?: return
        val edge = when (settings.subtitleEdgeType) {
            0 -> CaptionStyleCompat.EDGE_TYPE_NONE
            1 -> CaptionStyleCompat.EDGE_TYPE_OUTLINE
            3 -> CaptionStyleCompat.EDGE_TYPE_RAISED
            4 -> CaptionStyleCompat.EDGE_TYPE_DEPRESSED
            else -> CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
        }
        // Style rail application (v0.14.5): embedded styling/font sizes
        // are overridden so the user's style always wins, the size is a
        // fixed sp (fractional in PiP, where the window is small and
        // captions must scale with it), and the bottom offset follows
        // the rail's 0–200 range.
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        // Font family (v0.14.14, Settings > Subtitles): CaptionStyleCompat
        // takes a real Typeface — the family choice combines with the
        // bold flag. Family "System" + no bold keeps the old null
        // typeface (renderer default), so untouched users see no change.
        // v0.14.31 (item 4): the decision lives in subtitleTypeface()
        // (PlayerHelpers) so the Bold flag's path into this renderer
        // call is unit-tested; the mapping itself is unchanged.
        val typeface = subtitleTypeface(
            settings.subtitleFontFamily, settings.subtitleBold
        )
        sv.setStyle(
            CaptionStyleCompat(
                settings.subtitleTextColor,
                settings.subtitleBackgroundColor,
                android.graphics.Color.TRANSPARENT,
                edge,
                settings.subtitleEdgeColor,
                typeface
            )
        )
        val fontSp = settings.subtitleFontSizeSp
        if (inPip) {
            sv.setFractionalTextSize(
                SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * (fontSp / 18f)
            )
        } else {
            sv.setFixedTextSize(
                android.util.TypedValue.COMPLEX_UNIT_SP, fontSp.toFloat()
            )
        }
        // Bottom offset: base fraction plus offset/1000 (the offset term
        // clamped to 0..0.2), the total clamped to 0..0.4.
        val offsetFraction = (settings.subtitleBottomOffset / 1000f).coerceIn(0f, 0.2f)
        sv.setBottomPaddingFraction(
            (SubtitleView.DEFAULT_BOTTOM_PADDING_FRACTION * (2f / 3f) + offsetFraction)
                .coerceIn(0f, 0.4f)
        )
    }


    var currentRequest by remember { mutableStateOf(initialRequest) }
    LaunchedEffect(currentRequest.videoId, currentRequest.liveChannel) {
        liveRebufferRecoveries = 0
    }
    // Feedback attempt boundary: a genuinely new stream on screen
    // (failover, manual source pick, episode switch, resume URL
    // refresh) settles the previous attempt in the tracker and starts
    // a fresh one. Context-only copies of the request (same URL +
    // source) never re-begin — the key is the stream's identity, not
    // the request object. Live and trailers begin a null attempt:
    // the previous one settles and nothing is tracked for them.
    LaunchedEffect(
        currentRequest.streamUrl, currentRequest.sourceId,
        currentRequest.sourceName, currentRequest.videoId
    ) {
        val req = currentRequest
        val identity = if (req.isLive || req.isTrailer) null else
            com.pulsestream.app.data.FeedbackSupport.AttemptIdentity(
                titleId = feedbackTitleId(req),
                source = req.sourceName?.takeIf { it.isNotBlank() }
                    ?: req.sourceId?.takeIf { it.isNotBlank() }
                    ?: "unknown",
                url = req.streamUrl
            )
        feedbackTracker.beginAttempt(identity)
    }
    // Resume context restore (owner's bug report 2026-10-27): a player
    // opened from Continue Watching historically arrived with
    // series-level data only — no episode list (so no Episodes button
    // and no autoplay-next) and no episode title in the header. New
    // saves carry the full context (DB v14), but rows saved earlier
    // don't; whenever a series request is missing pieces, fetch the
    // series meta once — from ANY installed meta addon, never
    // hardwired to one provider — and fill them in.
    LaunchedEffect(currentRequest.videoId) {
        // Item 4 completion (2026-10-28): the episode title can often
        // be derived from the session's OWN episode list — a resumed
        // session now carries it decoded from the DB (v16) — with no
        // network at all. Derive it before the completeness checks
        // below and on every retry pass, so a title that is already
        // in hand never waits on (or dies with) the meta fetch.
        fun withOwnEpisodeTitle(r: PlaybackRequest): PlaybackRequest {
            if (!r.episodeTitle.isNullOrBlank() || r.episodes.isEmpty()) return r
            val ownEp = r.episodes.firstOrNull { it.id == r.videoId }
                ?: r.episodes.firstOrNull { it.season == r.season && it.episode == r.episode }
            val ownTitle = ownEp?.title?.takeIf { it.isNotBlank() } ?: return r
            return r.copy(episodeTitle = ownTitle)
        }
        val req = withOwnEpisodeTitle(currentRequest)
        if (req !== currentRequest) currentRequest = req
        if (req.isMovie || req.isTrailer || req.isLive || req.liveChannel != null) return@LaunchedEffect
        if (req.episodes.isNotEmpty() && !req.episodeTitle.isNullOrBlank() &&
            !req.seriesName.isNullOrBlank()
        ) return@LaunchedEffect
        val metaKey = req.metaId.ifBlank { req.imdbId ?: req.videoId.substringBefore(":") }
        if (metaKey.isBlank()) return@LaunchedEffect
        // Hardened (notes item 16): this used to be ONE silent fetch
        // — if it failed, timed out, or the first answering addon
        // returned a meta with no episode list, the session stayed
        // episode-blind and autoplay-next never fired (the owner's
        // "no suggest, no autoplay" report). Now: the walk skips
        // video-less metas (requireVideos), and the whole restore
        // retries a few times over the session before giving up.
        var attempt = 0
        while (!disposed.get() && currentRequest.videoId == req.videoId) {
            // Same own-list derivation on every pass (2026-10-28): a
            // backfill may land the episode list mid-retry, and from
            // that moment the title is derivable locally even if the
            // fetch that carried the list had no title for this ep.
            val cur0 = withOwnEpisodeTitle(currentRequest)
            if (cur0 !== currentRequest) currentRequest = cur0
            val needsEpisodes = cur0.episodes.isEmpty()
            if (!needsEpisodes && !cur0.episodeTitle.isNullOrBlank() &&
                !cur0.seriesName.isNullOrBlank()
            ) break
            val meta = runCatching {
                repository.getMetaFromAny(null, "series", metaKey, requireVideos = needsEpisodes)
            }.getOrNull()
            if (meta != null) {
                if (disposed.get()) return@LaunchedEffect
                // Feedback evidence: a host answered this session, so
                // a later connect failure may be blamed on its host.
                feedbackTracker.markNetworkProven()
                val cur = currentRequest
                if (cur.videoId != req.videoId) return@LaunchedEffect
                val ep = meta.videos.firstOrNull { it.id == cur.videoId }
                    ?: meta.videos.firstOrNull { it.season == cur.season && it.episode == cur.episode }
                currentRequest = cur.copy(
                    episodes = if (cur.episodes.isEmpty()) meta.videos else cur.episodes,
                    episodeTitle = cur.episodeTitle?.takeIf { it.isNotBlank() } ?: ep?.title,
                    seriesName = cur.seriesName ?: meta.name,
                    metaId = if (cur.metaId.isBlank()) meta.id else cur.metaId,
                    logo = cur.logo ?: meta.logo
                )
                if (currentRequest.episodes.isNotEmpty()) break
            }
            attempt++
            if (attempt >= 3) break
            delay(if (attempt == 1) 15_000 else 30_000)
        }
    }
    var player by remember {
        mutableStateOf(buildExo(initialRequest).also { it.addListener(guardedPlayerListener()) })
    }
    val latestPlayer = rememberUpdatedState(player)
    val latestRequest = rememberUpdatedState(currentRequest)
    var playerView by remember { mutableStateOf<PlayerView?>(null) }

    // -----------------------------------------------------------------
    // Dual engine (mobile overhaul, 2026-11-06): ExoPlayer stays the
    // default engine; libmpv joins as the specialist. `activeEngine`
    // says which engine owns the current play; every position /
    // duration / transport read goes through the active* helpers so
    // the UI never talks to a parked engine. Per-play guards for the
    // error ladder (credential refresh, decoder rebuild, engine
    // failover) are keyed to the title identity and reset when it
    // changes — consecutive plays accumulate nothing.
    // -----------------------------------------------------------------
    var activeEngine by remember {
        mutableStateOf(com.pulsestream.app.player.PlaybackEngine.EXO)
    }
    var mpvEngine by remember { mutableStateOf<com.pulsestream.app.player.MpvPlayerEngine?>(null) }
    /** The MPV track list mirrored into UI state for the track panels. */
    var mpvTracksUi by remember {
        mutableStateOf<List<com.pulsestream.app.player.MpvPlayerEngine.Track>>(emptyList())
    }
    /** URL of the addon subtitle currently loaded into the MPV engine. */
    var mpvActiveSubUrl by remember { mutableStateOf<String?>(null) }
    /** Ladder guard: credential refresh already spent for this title. */
    var credentialRefreshUsed by remember { mutableStateOf(false) }
    /** Ladder guard (v0.14.24, item 14): same-stream retries spent
     *  for this title — the player retries the SAME source before
     *  anything else is even considered. */
    var sameStreamRetriesUsed by remember { mutableIntStateOf(0) }
    /** Ladder guard: decoder rebuild already spent for this title. */
    var decoderRebuildAttempted by remember { mutableStateOf(false) }
    /** Ladder guard: the one silent engine failover for this source. */
    var engineFailoverUsed by remember { mutableStateOf(false) }
    /** A manual in-player engine switch disarms the auto failover. */
    var engineFailoverArmed by remember { mutableStateOf(true) }
    /** True when the visible error came from the ladder's last rung —
     *  the error overlay then offers one Back and nothing else. */
    var ladderTerminal by remember { mutableStateOf(false) }
    /**
     * Source-switch cap (v0.14.26, batch item 12 — owner's order
     * 2026-11-07): the player auto-switches SOURCE at most ONCE per
     * play. The first stream proven dead (permanent error after the
     * engine ladder, or full patience exhausted on it) spends the
     * one switch; if the second stream also proves dead, NOTHING
     * auto-switches again — the "Stream won't play" popup shows
     * with the source picker at hand. [autoSourceSwitchesUsed]
     * counts auto switches spent for the current title identity
     * (reset beside the ladder guards); [streamWontPlayShown] is
     * the popup state itself. A MANUAL source pick by the user is
     * never capped — it clears the popup and playback continues on
     * the user's own choice.
     */
    var autoSourceSwitchesUsed by remember { mutableIntStateOf(0) }
    var streamWontPlayShown by remember { mutableStateOf(false) }
    /**
     * Indirection (same pattern as [failoverToNextSource]):
     * assigned once nextSource exists; the ladder helpers above it
     * spend the item-12 switch through this hook. Returns true when
     * a next source was actually switched to.
     */
    var autoSourceSwitchHook: (() -> Boolean)? by remember { mutableStateOf(null) }
    /** Title identity the ladder guards belong to. */
    var ladderGuardKey by remember { mutableStateOf("") }
    var seekSaveJob by remember { mutableStateOf<Job?>(null) }

    fun mpvActive(): Boolean =
        activeEngine == com.pulsestream.app.player.PlaybackEngine.MPV && mpvEngine != null

    fun activePositionMs(): Long =
        if (mpvActive()) {
            mpvEngine?.snapshot?.value?.positionMs ?: 0L
        } else {
            runCatching { player.currentPosition }.getOrDefault(0L)
        }

    fun activeDurationMs(): Long =
        if (mpvActive()) {
            mpvEngine?.snapshot?.value?.durationMs ?: 0L
        } else {
            runCatching { player.duration }.getOrDefault(0L).takeIf { it > 0 } ?: 0L
        }

    /**
     * Debounced (700 ms) progress flush after a seek.
     *
     * v0.14.24 crash fix: the flush used to invoke savePosition
     * directly on Dispatchers.IO, and savePosition reads the
     * ExoPlayer — during a fast Exo↔MPV switch that read landed on
     * a released/replaced player from the wrong thread and crashed
     * ("Player is accessed on the wrong thread"). The save now
     * captures the identity it was scheduled for (title + engine
     * kind + the exact player/engine instance) and fires on the
     * MAIN thread only if that exact playback is still the live
     * one; a switch or teardown in the debounce window makes it a
     * no-op (the switch/dispose paths do their own flush).
     */
    fun scheduleSeekProgressSave() {
        seekSaveJob?.cancel()
        val forVideoId = latestRequest.value.videoId
        val forPlayer = latestPlayer.value
        val forMpvEngine = mpvEngine
        val forEngineKind = activeEngine
        seekSaveJob = ioScope.launch {
            delay(700)
            withContext(Dispatchers.Main) {
                if (disposed.get()) return@withContext
                if (latestRequest.value.videoId != forVideoId) return@withContext
                if (activeEngine != forEngineKind) return@withContext
                if (forEngineKind == com.pulsestream.app.player.PlaybackEngine.MPV) {
                    if (mpvEngine !== forMpvEngine) return@withContext
                } else if (latestPlayer.value !== forPlayer) {
                    return@withContext
                }
                savePositionHook?.invoke()
            }
        }
    }

    /** Applies the shared subtitle style store to the MPV engine. */
    fun applyMpvSubtitleStyle() {
        mpvEngine?.applySubtitleStyle(
            textColor = settings.subtitleTextColor,
            backgroundColor = settings.subtitleBackgroundColor,
            edgeColor = settings.subtitleEdgeColor,
            edgeType = settings.subtitleEdgeType,
            fontSizeSp = settings.subtitleFontSizeSp,
            bottomOffset = settings.subtitleBottomOffset,
            bold = settings.subtitleBold
        )
    }

    /**
     * Starts (or restarts) the MPV engine on [req]. The previous
     * engine instance is released first — one engine per play, and
     * its release runs on its own thread (detach → destroy).
     */
    fun activateMpv(req: PlaybackRequest, startMs: Long, autoplay: Boolean) {
        // A pending seek flush belongs to the outgoing playback.
        seekSaveJob?.cancel()
        val engine = com.pulsestream.app.player.MpvPlayerEngine(
            context,
            hardwareDecoding = settings.mpvHardwareDecoding,
            yuv420pFilter = settings.mpvYuv420pFilter
        )
        engine.onFatalError = { message ->
            if (!disposed.get()) {
                // Item 11 classification at the MPV boundary: the
                // engine failing to START is an engine-init fault;
                // mpv's own format/codec/decode wording is a player
                // fault. Everything else mpv reports (network, HTTP,
                // load failures) is a SOURCE fault and must never
                // switch the engine.
                val playerFault = message == "Second engine failed to start" ||
                    message.contains("format", ignoreCase = true) ||
                    message.contains("codec", ignoreCase = true) ||
                    message.contains("decode", ignoreCase = true)
                fatalErrorHook?.invoke(
                    com.pulsestream.app.player.PlaybackEngine.MPV, message, playerFault
                )
            }
        }
        engine.onFileLoaded = { mpvFileLoadedHook?.invoke() }
        mpvEngine?.release()
        mpvEngine = engine
        mpvTracksUi = emptyList()
        mpvActiveSubUrl = null
        activeEngine = com.pulsestream.app.player.PlaybackEngine.MPV
        engine.initialize()
        engine.setPaused(!autoplay)
        engine.load(
            req.streamUrl,
            PlaybackHeaders.buildPlaybackHeaders(req.headers, isTv),
            startMs,
            req.mergeAudioUrl
        )
        applyMpvSubtitleStyle()
    }

    /** Releases the MPV engine (idempotent) and returns to Exo. */
    fun releaseMpv() {
        // A pending seek flush belongs to the outgoing playback.
        seekSaveJob?.cancel()
        mpvEngine?.release()
        mpvEngine = null
        mpvTracksUi = emptyList()
        mpvActiveSubUrl = null
        if (activeEngine == com.pulsestream.app.player.PlaybackEngine.MPV) {
            activeEngine = com.pulsestream.app.player.PlaybackEngine.EXO
        }
    }

    // Mirror the live MPV track list into UI state for the panels.
    LaunchedEffect(mpvEngine) {
        val engine = mpvEngine ?: return@LaunchedEffect
        engine.tracks.collect { mpvTracksUi = it }
    }

    // Per-title ladder guards: a new title/episode re-arms every
    // ladder rung; a mere source switch keeps them spent.
    LaunchedEffect(currentRequest.videoId, currentRequest.season, currentRequest.episode) {
        val key = "${currentRequest.videoId}|${currentRequest.season}|${currentRequest.episode}"
        if (key != ladderGuardKey) {
            ladderGuardKey = key
            credentialRefreshUsed = false
            sameStreamRetriesUsed = 0
            decoderRebuildAttempted = false
            engineFailoverUsed = false
            engineFailoverArmed = true
            ladderTerminal = false
            // Item 12: a new title/episode re-arms the ONE auto
            // source switch; a source switch (same identity) does not.
            autoSourceSwitchesUsed = 0
            streamWontPlayShown = false
        }
    }

    // PiP RemoteAction: the floating window's play/pause button toggles the
    // player here. The player listener's onIsPlayingChanged then refreshes
    // the RemoteAction icon via MainActivity.updatePipActions.
    // (Placed after `player` is declared — composable locals are positional.)
    LaunchedEffect(Unit) {
        MainActivity.pipToggleRequest.collect {
            player.playWhenReady = !player.playWhenReady
        }
    }
    // PrePlay trigger 2 (item 13, v0.14.24): while an episode plays,
    // prefetch the NEXT episode's streams into the session stream cache
    // (spec: triggers are Details-open + next-episode-while-playing;
    // failures silent; never re-prefetch a fresh pocket).
    LaunchedEffect(currentRequest.videoId, currentRequest.episodes.size) {
        val req = currentRequest
        if (!settings.prePlayEnabled || req.isMovie || req.isLive || req.isTrailer ||
            req.episodes.isEmpty()
        ) return@LaunchedEffect
        val idx = req.episodes.indexOfFirst { it.id == req.videoId }
            .takeIf { it >= 0 }
            ?: req.episodes.indexOfFirst {
                it.season == req.season && it.episode == req.episode
            }
        val next = if (idx >= 0) req.episodes.getOrNull(idx + 1) else null
        if (next == null) return@LaunchedEffect
        runCatching {
            repository.prePlayPrefetch(req.type, next.id)
        }
        // Navigating away cancels this effect — the collect inside
        // prePlayPrefetch is cancelled with it, per the spec's
        // "cancel shortly after navigating away".
    }
    /**
     * Side-loaded subtitles, resolved (downloaded + format-sniffed) in the
     * background for the current request. Kept in state so a rebuilt player
     * (source switch) can carry them from its first prepare instead of
     * re-preparing the video to attach them (#29).
     */
    var resolvedSubs by remember { mutableStateOf(emptyList<ResolvedSubtitle>()) }
    /**
     * Raw (unshifted) downloaded subtitles — the source of truth for timing
     * shifts. The in-player +/- timing buttons re-shift from these files,
     * never from already-shifted output (which would compound the offset).
     */
    var rawResolvedSubs by remember { mutableStateOf(emptyList<ResolvedSubtitle>()) }
    /**
     * Per-video subtitle delay (ms), added to the global
     * [SettingsStore.subtitleOffsetMs]. Set from the Style rail's delay
     * stepper / Auto Sync and persisted per video id
     * ([SettingsStore.subtitleDelayMsFor]); reloaded whenever the title
     * changes (see the load effect below the resolver).
     */
    var subOffsetOverrideMs by remember { mutableLongStateOf(0L) }
    /**
     * Effective subtitle timing offset for the current title: global default
     * plus the per-video delay, clamped to ±60s.
     */
    fun effectiveSubOffsetMs(): Long =
        (settings.subtitleOffsetMs + subOffsetOverrideMs).coerceIn(-60_000L, 60_000L)
    /**
     * Re-applies the effective timing offset to the raw subtitles and
     * publishes the shifted list (which re-attaches to the player via the
     * existing resolvedSubs effect). Runs on IO; no-op when there is nothing
     * to shift.
     */
    fun applySubtitleTiming() {
        val raw = rawResolvedSubs
        if (raw.isEmpty()) return
        val offset = effectiveSubOffsetMs()
        val generation = subtitleShiftGeneration.incrementAndGet()
        ioScope.launch {
            val shifted = withContext(Dispatchers.IO) { shiftSubtitles(raw, offset, context.cacheDir) }
            if (!disposed.get() && subtitleShiftGeneration.get() == generation) resolvedSubs = shifted
        }
    }
    // Self-heal handler: probe Content-Type, rebuild once with probed MIME.
    healOnFormatError = { error ->
        val req = latestRequest.value
        val old = latestPlayer.value
        ioScope.launch {
            val probed = probePlaybackContentType(
                req.streamUrl,
                PlaybackHeaders.buildPlaybackHeaders(req.headers, isTv)
            )
            // A source switch/zap can finish while the probe is in flight.
            // Never apply the old source's MIME (or release its replacement).
            withContext(Dispatchers.Main) {
                if (disposed.get() || latestRequest.value != req || latestPlayer.value !== old) return@withContext
                if (probed != null) {
                    val playWhenReady = old.playWhenReady
                    val position = old.currentPosition
                    val playbackSpeed = old.playbackParameters.speed
                    val fresh = buildExo(req, resolvedSubs, forcedMime = probed)
                        .also { it.addListener(guardedPlayerListener()) }
                    playerView?.player = null
                    old.release()
                    player = fresh
                    playerError = null
                    fresh.setPlaybackSpeed(playbackSpeed)
                    fresh.seekTo(position)
                    fresh.prepare()
                    fresh.playWhenReady = playWhenReady
                } else if (com.pulsestream.app.data.LivePlaybackPolicy.shouldRetry(
                        isLive = req.isLive,
                        isTv = isTv,
                        errorCode = error.errorCode,
                        attemptsSoFar = autoFailoverCount
                    )) {
                    autoFailoverCount++
                    com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_attempt", 0)
                    playerError = null
                    failoverToNextSource?.invoke(autoFailoverCount)
                } else {
                    if (req.isLive && !isTv &&
                        com.pulsestream.app.data.LivePlaybackPolicy.isRecoverableSourceError(error.errorCode)) {
                        com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_exhausted", 0)
                    }
                    // Feedback: the heal probe could not rescue this
                    // attempt — it died with the format error.
                    feedbackTracker.onAttemptError(feedbackErrorFacts(error))
                    playerError = error.message?.takeIf { it.isNotBlank() }
                        ?: "Playback failed (code ${error.errorCode})"
                }
            }
        }
    }
    /**
     * Which subtitle set is already attached to which player instance.
     * Attaching the same set twice would re-prepare the video for nothing.
     */
    var subsAttached by remember { mutableStateOf<Pair<ExoPlayer, String>?>(null) }

    // Sidecar subtitles (mobile overhaul, 2026-11-06): the addon
    // subtitle currently rendered by the sidecar engine, its parsed
    // cues, and whether the user made an explicit panel choice for
    // this title (a manual pick — including "None" — suppresses the
    // automatic default). Keyed to the title identity: a source
    // switch keeps the pick, a new episode/title starts clean.
    var sidecarSubUrl by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) { mutableStateOf<String?>(null) }
    var sidecarCues by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) { mutableStateOf<List<androidx.media3.extractor.text.CuesWithTiming>>(emptyList()) }
    var sidecarTouched by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) { mutableStateOf(false) }
    val sidecarGeneration = remember { AtomicInteger(0) }
    /**
     * Player audit 2026-10-27 (finding 1): the one-time init gives the
     * subtitle resolver a short bounded window BEFORE the first prepare and
     * folds whatever landed into the initial media item, so the common case
     * never pays a re-prepare seconds into playback. [initialSubsSignal]
     * completes when the resolver publishes its first result for the opening
     * title; [initialPrepareDone] gates the attach effect until the init
     * sequence owns the fold.
     */
    val initialSubsSignal = remember { CompletableDeferred<Unit>() }
    var initialPrepareDone by remember { mutableStateOf(false) }

    // Unified scrobbling: one pipeline fans playback events out to every
    // linked backend (Trakt, Simkl, …). Each service is enabled/disabled
    // independently via its own login state; auth flows are untouched.
    val simkl = remember { SimklManager(settings) }
    val trakt = remember { TraktManager(settings) }
    val scrobbler = remember { ScrobbleManager(listOf(simkl, trakt), ioScope) }

    // Clean start (v0.14.21, owner's order): the player NEVER opens
    // with the controls up — every play start, Continue Watching
    // resumes included, begins clean; a tap shows the controls and
    // the existing timeout hides them again.
    var showControls by remember { mutableStateOf(false) }
    var controlsTick by remember { mutableIntStateOf(0) }
    /** True while the user is scrubbing (gesture drag or seekbar drag) —
     *  the auto-hide gate reads it: controls never vanish mid-scrub. */
    var scrubbing by remember { mutableStateOf(false) }
    /** Subtitle card step (v0.14.29, owner's approved redesign):
     *  1 = Languages, 2 = Files, 3 = Style. One card at a time,
     *  opened by the pill bar's Subs chip; replaces both the TB
     *  quick popover and the old three-rails overlay as the Subs
     *  surface (same plumbing and store underneath). */
    var subCardStep by remember { mutableIntStateOf(1) }
    // PiP: drop the transport UI the moment the window floats (the system
    // draws its own PiP controls); restore the default on return.
    LaunchedEffect(inPip) {
        if (inPip) showControls = false
        // Caption sizing switches between fixed sp and fractional in
        // PiP — re-apply so the change lands without a player rebuild.
        playerView?.let { applySubtitleStyle(it) }
    }
    var locked by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    // v0.14.17 lag fix (audit cause 5): position/duration are held
    // as explicit State objects so the seek cluster can read them
    // inside its own small composable (PlayerSeekControls) — the
    // 500 ms poll's writes then recompose only that cluster instead
    // of this whole screen. All other reads/writes keep using the
    // delegated vars below, unchanged.
    val positionMsState = remember { mutableLongStateOf(0L) }
    var positionMs by positionMsState
    val durationMsState = remember { mutableLongStateOf(0L) }
    var durationMs by durationMsState
    var volumePercent by remember { mutableIntStateOf(0) }
    // Volume boost (past 100%): a LoudnessEnhancer on the player's audio
    // session adds up to +10 dB on top of the system max. volumeBoost is
    // 0f..1f; the shown percent is 100 + boost*100 while system is at max.
    var volumeBoost by remember { mutableFloatStateOf(0f) }
    val boostHolder = remember {
        object {
            var enhancer: LoudnessEnhancer? = null
            var sessionId: Int = -1
        }
    }
    fun applyVolumeBoost() {
        val sid = runCatching { player.audioSessionId }.getOrDefault(-1)
        if (sid <= 0) return
        if (boostHolder.enhancer == null || boostHolder.sessionId != sid) {
            runCatching { boostHolder.enhancer?.release() }
            boostHolder.enhancer = runCatching { LoudnessEnhancer(sid) }.getOrNull()
            boostHolder.sessionId = sid
        }
        runCatching {
            boostHolder.enhancer?.apply {
                setTargetGain((volumeBoost * 1000).roundToInt())
                enabled = volumeBoost > 0f
            }
        }
    }
    fun displayVolumePercent(): Int {
        val sys = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val sysPct = sys * 100 / maxVolume.coerceAtLeast(1)
        return if (sys >= maxVolume) sysPct + (volumeBoost * 100).roundToInt() else sysPct
    }
    var speed by remember { mutableFloatStateOf(1f) }
    var speedMenuOpen by remember { mutableStateOf(false) }
    // Sleep timer (v0.14.13, item 9): a wall-clock deadline for the
    // timed options, or [sleepAtEpisodeEnd] for "End of episode"
    // (consumed by armNextEpisodeIfEnded, which pauses instead of
    // arming the next episode). Lives in the player, per the
    // owner's playback-controls-in-player principle.
    var sleepMenuOpen by remember { mutableStateOf(false) }
    var sleepDeadlineMs by remember { mutableStateOf(0L) }
    var sleepAtEpisodeEnd by remember { mutableStateOf(false) }
    var sleepRemainingSec by remember { mutableStateOf(0) }
    val sleepTimerLabel = when {
        sleepDeadlineMs > 0L -> {
            val total = sleepRemainingSec
            "%d:%02d".format(total / 60, total % 60)
        }
        sleepAtEpisodeEnd -> "Ep. end"
        else -> "Sleep"
    }
    /** True while the hold-for-speed gesture is boosting playback (v0.12.0). */
    var holdSpeedActive by remember { mutableStateOf(false) }
    /** Current hold-boost step (2..5) shown in the hold pill (v0.12.1). */
    var holdSpeedStep by remember { mutableIntStateOf(2) }
    /** Main-thread scope for the delayed single-tap toggle in videoGestures. */
    val gestureUiScope = rememberCoroutineScope()
    var indicator by remember { mutableStateOf<PlayerIndicator?>(null) }
    var indicatorTick by remember { mutableIntStateOf(0) }

    // YouTube opens portrait-first (user rotates via the Rotate pill);
    // everything else opens landscape as before.
    var isPortrait by remember { mutableStateOf(initialRequest.sourceName == "YouTube") }
    // Aspect ratio (in-player only — cycles Fit → Fill → Zoom)
    var aspectMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    val aspectLabel = ASPECT_MODES.firstOrNull { it.first == aspectMode }?.second ?: "Fit"

    var isBuffering by remember { mutableStateOf(true) }
    var switchingMedia by remember { mutableStateOf(false) }
    /** True once the current title has actually played — gates the
     * startup presentation against a plain rebuffer orbit.
     * v0.14.34 LEAK FIX: keyed on the title's stable identity
     * (videoId + season + episode), NOT the whole request. It used
     * to be remember(currentRequest): PlaybackRequest is a data
     * class, so every mid-playback copy() — the metadata
     * enrichment at ~15–30 s, episode-title fills — counted as a
     * "new request", silently re-armed the startup overlay, and
     * the next network rebuffer rendered the heartbeat instead of
     * the plain orbit (owner's device proof, 2026-11-09). Copies
     * keep the identity, so the latch now survives them; only a
     * genuinely different title/episode resets it. */
    var hasStartedPlayback by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) { mutableStateOf(false) }
    /** Resume buffering (v0.14.34): the user pressed play after a
     * pause and the player is buffering back up — the one
     * mid-playback buffer the startup overlay may cover. Set in
     * togglePlay's resume branches, cleared when playing resumes
     * or on pause; keyed like [hasStartedPlayback]. */
    var resumeBuffering by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) { mutableStateOf(false) }
    /** The phase the initial wait is really in (v0.14.33) — drives
     * the loading capsule's status word. Starts at the request's
     * honest entry phase (see initialLoadingPhase); the init flow
     * below advances it as streams resolve and the pick lands, and
     * a fresh title resets it like [hasStartedPlayback]. */
    var loadingPhase by remember(
        currentRequest.videoId, currentRequest.season, currentRequest.episode
    ) {
        mutableStateOf(
            com.pulsestream.app.ui.screens.player.initialLoadingPhase(
                currentRequest.streamUrl.isBlank(),
                currentRequest.isLive,
                currentRequest.isTrailer
            )
        )
    }

    // Track switching
    var tracksOpen by remember { mutableStateOf(false) }
    // External-player protected-link warning (owner's order 2026-10-26):
    // non-null while the warning popup is up for that request.
    var externalWarningReq by remember { mutableStateOf<PlaybackRequest?>(null) }
    var externalWarningHide by remember { mutableStateOf(false) }
    var tracksMode by remember { mutableStateOf("subs") } // "subs" or "audio"
    var trackTick by remember { mutableIntStateOf(0) }
    /** Set when the user hand-picks an audio track — the preferred-language
     * auto-select then leaves their pick alone for this player session. */
    var userPickedAudio by remember { mutableStateOf(false) }

    /**
     * Attaches resolved (downloaded + format-sniffed) subtitles to the current
     * player, preserving position. Auto-picks the default: the explicitly
     * requested URL first, else the first track matching the preferred
     * languages, else the first subtitle (or none when a preference is set
     * but nothing matches).
     *
     * Skips silently when this exact set is already attached to this player
     * instance — re-attaching would call setMediaItem+prepare() again and
     * visibly rebuffer the video (#29). A fresh player built carrying the
     * same subtitles (source switch) never reaches the re-prepare path below.
     */
    /**
     * Points the current player at a media item carrying [resolved]
     * subtitles — WITHOUT preparing. Used by the one-time init to fold
     * subtitles into the initial item before the first (and only) prepare,
     * and by [attachResolvedSubtitles] for later attaches. The caller owns
     * prepare() and play state.
     */
    fun applySubtitleItem(resolved: List<ResolvedSubtitle>, defaultUrl: String? = null) {
        // YouTube DASH keeps its merged audio via the shared builder;
        // everything else keeps the setMediaItem path.
        if (currentRequest.mergeAudioUrl != null) {
            player.setMediaSource(
                buildPlaybackMediaSource(currentRequest, resolved, null),
                /* startPositionMs = */ player.currentPosition
            )
        } else {
            player.setMediaItem(
                MediaItem.Builder()
                    .setUri(currentRequest.streamUrl)
                    .apply {
                        (com.pulsestream.app.data.PlaybackContentProbe.recognizedMime(currentRequest.mimeType)
                            ?: PlaybackHeaders.inferMimeType(currentRequest.streamUrl))?.let { setMimeType(it) }
                    }
                    .setSubtitleConfigurations(subtitleConfigs(resolved, defaultUrl, currentRequest))
                    .build(),
                /* resetPosition = */ false
            )
        }
        subsAttached = player to subtitleIdentity(resolved)
        trackTick++
    }

    fun attachResolvedSubtitles(resolved: List<ResolvedSubtitle>, defaultUrl: String? = null) {
        if (resolved.isEmpty()) return
        val key = subtitleIdentity(resolved)
        val attached = subsAttached
        if (attached != null && attached.first === player && attached.second == key) return
        // Player audit 2026-10-27 (finding 1): swap the item at the current
        // position (resetPosition = false — no stop, no seek) and preserve
        // playWhenReady exactly. Subtitles that land before the first
        // prepare never reach this path at all (the init folds them in);
        // this remains for late arrivals and timing shifts, where Media3
        // offers no lighter way to change an item's subtitle configurations.
        val wasPlaying = player.playWhenReady
        applySubtitleItem(resolved, defaultUrl)
        player.prepare()
        player.playWhenReady = wasPlaying
    }

    // Sources + episodes sheets
    var sourcesOpen by remember { mutableStateOf(false) }
    var episodesOpen by remember { mutableStateOf(false) }
    var downloadStream by remember { mutableStateOf<com.pulsestream.app.data.StreamItem?>(null) }
    var zapping by remember { mutableStateOf(false) }
    var availableStreams by remember {
        mutableStateOf(com.pulsestream.app.ui.screens.player.mergePlayerSourceSet(
            emptyList(), initialRequest.streams, includeHeadersInIdentity = initialRequest.isLive && !isTv
        ))
    }
    /** Live fallback never retries the same URL/header tuple during this channel session. */
    var attemptedLiveSourceIds by remember { mutableStateOf(emptySet<String>()) }
    /**
     * VOD failover tried-set (stream-skip fix 1): each candidate is
     * failed over to at most once per title, so the health-ordered
     * walk terminates even though prober-proven corpses don't
     * consume the failover cap.
     */
    var attemptedVodSourceUrls by remember {
        mutableStateOf(setOf(initialRequest.streamUrl))
    }
    /** Count of streams hidden because the device can't decode them (e.g. 4K on budget phones). */
    var hiddenIncompatibleCount by remember { mutableStateOf(0) }
    var streamsLoading by remember { mutableStateOf(false) }
    var streamsJob by remember { mutableStateOf<Job?>(null) }
    /** A bounded late-source wait is invalidated by manual navigation and disposal. */
    val liveFallbackGeneration = remember { AtomicInteger(0) }
    var pendingLiveFallbackJob by remember { mutableStateOf<Job?>(null) }

    fun preemptPendingLiveFallback() {
        liveFallbackGeneration.incrementAndGet()
        pendingLiveFallbackJob?.cancel()
        pendingLiveFallbackJob = null
    }

    // Resume prompt
    var resumeOfferMs by remember { mutableStateOf<Long?>(null) }

    // Autoplay-next countdown (player audit 2026-10-27, finding 8): an ended
    // episode used to hand over to the next one instantly. Now the next
    // episode waits here for a 10 s CANCELABLE countdown — any interaction
    // (tap, seek, play/pause, manual source/episode change) cancels it.
    var autoplayNext by remember { mutableStateOf<Video?>(null) }
    var autoplayCountdownSec by remember { mutableIntStateOf(0) }
    /** videoId of the episode that ended and armed the countdown. */
    var autoplayArmedFor by remember { mutableStateOf<String?>(null) }
    /** videoId whose end (clean or error-tail) was already evaluated for the next-episode arm. */
    var endedHandledFor by remember { mutableStateOf<String?>(null) }
    /**
     * The next-episode SUGGESTION (notes item 16): set whenever an
     * episode ends and a next episode exists — independent of the
     * Auto-play setting, which gates only the countdown above.
     * When the countdown is interrupted (a screen tap used to kill
     * it silently), the armed episode DEMOTES to this suggestion,
     * whose pill stays on screen, tappable, until the user plays
     * it, dismisses it, or switches away.
     */
    var nextEpisodeSuggestion by remember { mutableStateOf<Video?>(null) }

    /** Stops the autoplay countdown but keeps the next episode on offer. */
    fun demoteAutoplayToSuggestion() {
        autoplayNext?.let { nextEpisodeSuggestion = it }
        autoplayNext = null
    }

    // Skip segments
    var skipSegments by remember { mutableStateOf(emptyList<SkipSegment>()) }
    var activeSegment by remember { mutableStateOf<SkipSegment?>(null) }

    /**
     * Item 16 (end-as-error fix): is playback sitting in the episode's
     * tail — the last ~2% of the runtime, or at/past the outro /
     * post-credits segment start? Errors and stalls THERE are the
     * episode effectively ending (fragile hosts fail on the final
     * bytes instead of signalling a clean end), never a reason to
     * fail over or show the error panel when a next episode exists.
     */
    fun isAtEpisodeTail(): Boolean {
        val req = currentRequest
        if (req.isMovie || req.isTrailer || req.isLive) return false
        val dur = player.duration
        if (dur <= 0) return false
        val pos = player.currentPosition
        val outroStart = skipSegments
            .filter {
                it.type == com.pulsestream.app.data.SegmentType.OUTRO ||
                    it.type == com.pulsestream.app.data.SegmentType.POST_CREDITS
            }
            .minOfOrNull { it.startMs }
        if (outroStart != null && pos >= outroStart) return true
        return pos >= dur - (dur * 2 / 100).coerceAtLeast(1_000L)
    }

    /**
     * Item 16: THE shared next-episode arm evaluation — called from
     * the poll loop's STATE_ENDED gate, the player error listener
     * (via [armNextEpisodeAtTail]) and the VOD stall watchdog, so an
     * episode that ends cleanly, errors at the tail, or stalls at
     * the tail all land in the same place: the SUGGESTION arms
     * whenever a next episode exists, and the Auto-play setting
     * gates only the 10 s countdown on top of it. Returns true when
     * a next episode was armed (or this end was already handled);
     * false when there is nothing to arm (movie/live/trailer, no
     * episode list yet — the poll gate re-evaluates when a backfill
     * lands — or no next episode exists).
     */
    fun armNextEpisodeIfEnded(): Boolean {
        val req = currentRequest
        if (req.isMovie || req.isTrailer || req.isLive) return false
        if (endedHandledFor == req.videoId) return nextEpisodeSuggestion != null || autoplayNext != null
        if (req.episodes.isEmpty()) return false
        val eps = req.episodes.sortedWith(
            compareBy({ it.season }, { it.episode })
        )
        // Item 24 tail (2026-10-28): locate the just-ended episode
        // in the list BEFORE consuming the end. Exact id first, then
        // the season/episode fallback the episode-title restore
        // already uses — a resumed session's saved videoId and its
        // episode list can come from different addons (the row was
        // saved under one addon's ids, the list backfilled from
        // another's meta) whose id forms differ, so an id-only
        // lookup can miss an episode that is plainly in the list.
        // The old code set endedHandledFor BEFORE this lookup, so
        // one miss poisoned the end permanently: the poll gate
        // never re-evaluated, and the next-episode suggestion /
        // countdown never armed on resume. A fresh Detail play
        // takes videoId and episodes from the same meta response,
        // so its id lookup cannot miss — which is why only resumed
        // sessions lost the notification. Now a miss leaves the
        // end unhandled (like the empty-list case above), so a
        // later backfill can still arm it.
        val idx = eps.indexOfFirst { it.id == req.videoId }
            .takeIf { it >= 0 }
            ?: eps.indexOfFirst {
                it.season == req.season && it.episode == req.episode
            }
        if (idx < 0) return false
        endedHandledFor = req.videoId
        // v0.9.0: shuffle mode picks a random episode instead of the
        // sequential next one (never the just-finished episode itself).
        val next = if (settings.shuffleEpisodes) {
            eps.filterIndexed { i, _ -> i != idx }.randomOrNull()
                ?: eps.getOrNull(idx)
        } else {
            eps.getOrNull(idx + 1)
        }
        if (next == null) return false
        if (sleepAtEpisodeEnd) {
            // Sleep timer (v0.14.13, item 9), "End of episode": the
            // episode finished — pause here instead of arming the
            // next one, and consume the timer. (Direct state writes:
            // pokeIndicator is declared further down this composable.)
            sleepAtEpisodeEnd = false
            if (mpvActive()) {
                mpvEngine?.setPaused(true)
            } else {
                runCatching { latestPlayer.value.pause() }
            }
            indicator = PlayerIndicator.Message("Sleep timer — stopped at the episode's end")
            indicatorTick++
            return true
        }
        nextEpisodeSuggestion = next
        if (settings.autoPlayNext) {
            // Finding 8: don't switch instantly — arm the 10 s
            // cancelable countdown (driver effect in the poll area).
            autoplayArmedFor = req.videoId
            autoplayNext = next
        }
        return true
    }

    // Subtitle search
    var subSearchOpen by remember { mutableStateOf(false) }
    var subSearchLoading by remember { mutableStateOf(false) }
    var subSearchResults by remember { mutableStateOf(emptyList<Subtitle>()) }
    var subSearchError by remember { mutableStateOf<String?>(null) }
    var addedSubs by remember { mutableStateOf(emptyList<Subtitle>()) }
    // PlavioSubs (v0.14.33): our built-in subtitle source — every
    // language it has for this title (listed in the subtitle panel,
    // labelled "PlavioSubs") and the single auto-pick winner that is
    // downloaded + applied without a tap.
    var plavioSubs by remember(currentRequest) { mutableStateOf(emptyList<Subtitle>()) }
    var plavioAutoSub by remember(currentRequest) { mutableStateOf<Subtitle?>(null) }
    // Subtitle overlay (v0.14.5): chosen language rail + the URL of the
    // subtitle the user last picked in the panel (drives the Style
    // rail's appearance before the player finishes attaching it).
    var panelLang by remember { mutableStateOf<String?>(null) }
    var panelPickedUrl by remember { mutableStateOf<String?>(null) }
    // Style-rail mirrors of the persisted style: font size (sp), text
    // colour (ARGB — its alpha is the opacity control), bold / outline /
    // outline colour / bottom offset, plus auto-sync capture state and
    // the reload tick that re-runs the subtitle resolver effect.
    val subFontSpUiState = remember { mutableIntStateOf(settings.subtitleFontSizeSp) }
    var subFontSpUi by subFontSpUiState
    val subColorUiState = remember { mutableIntStateOf(settings.subtitleTextColor) }
    var subColorUi by subColorUiState
    val subBoldUiState = remember { mutableStateOf(settings.subtitleBold) }
    var subBoldUi by subBoldUiState
    val subEdgeUiState = remember { mutableIntStateOf(settings.subtitleEdgeType) }
    var subEdgeUi by subEdgeUiState
    val subEdgeColorUiState = remember { mutableIntStateOf(settings.subtitleEdgeColor) }
    var subEdgeColorUi by subEdgeColorUiState
    val subBottomUiState = remember { mutableIntStateOf(settings.subtitleBottomOffset) }
    var subBottomUi by subBottomUiState
    // v0.14.28: background (ARGB — alpha is its opacity control) and
    // font family join the rail, completing the in-player set.
    val subBgUiState = remember { mutableIntStateOf(settings.subtitleBackgroundColor) }
    var subBgUi by subBgUiState
    // v0.14.31 (item 2): the background MODE (0 None / 1 Shade /
    // 2 Solid) as its own remembered selection, initialised from
    // the stored alpha. Until now the mode was re-derived from
    // the alpha on every recomposition, so dragging the Opacity
    // slider to 0 flipped the derived mode to None and the
    // slider vanished mid-use ("hide automatically"). The mode
    // now changes ONLY on a segment tap (or Reset defaults) —
    // never as a side effect of the opacity value.
    val subShadeModeUiState = remember {
        mutableIntStateOf(
            when {
                android.graphics.Color.alpha(settings.subtitleBackgroundColor) == 0 -> 0
                android.graphics.Color.alpha(settings.subtitleBackgroundColor) >= 250 -> 2
                else -> 1
            }
        )
    }
    val subFontFamilyUiState = remember { mutableIntStateOf(settings.subtitleFontFamily) }
    var subFontFamilyUi by subFontFamilyUiState
    var subReloadTick by remember { mutableIntStateOf(0) }
    // v0.14.17 lag fix (audit cause 5): the first subtitle resolve
    // downloads only a capped subset; [subResolveAll] flips when the
    // subtitle panel opens and the resolver effect re-runs in full.
    // [subsCapped] records that the current set was capped. Both
    // reset whenever the request changes.
    var subResolveAll by remember(currentRequest) { mutableStateOf(false) }
    var subsCapped by remember(currentRequest) { mutableStateOf(false) }
    val captureCuesState = remember { mutableStateOf<List<Pair<Long, String>>?>(null) }
    var captureCues by captureCuesState
    var captureLoading by remember { mutableStateOf(false) }
    /** Playback position stored when Auto Sync > Capture is pressed. */
    var capturePositionMs by remember { mutableLongStateOf(0L) }

    // Back hierarchy, in one handler so the order is explicit: sheets first,
    // then hide visible controls, and only then leave the player (#27).
    // (ModalBottomSheets register their own later-composed back handling, so
    // they still dismiss themselves before this runs.)
    BackHandler {
        when {
            tracksOpen || subSearchOpen || sourcesOpen || episodesOpen -> {
                tracksOpen = false
                subSearchOpen = false
                sourcesOpen = false
                episodesOpen = false
            }
            showControls && !locked -> showControls = false
            else -> onBack()
        }
    }

    val audioOpts = remember(trackTick, player) { trackOptions(player, C.TRACK_TYPE_AUDIO) }
    val textOpts = remember(trackTick, player) { trackOptions(player, C.TRACK_TYPE_TEXT) }
    // When preferred subtitle languages are set, the Subs picker only offers
    // tracks in those languages (plus Off and Search). Preferences are read
    // fresh every time the dialog opens. Falls back to all tracks if none
    // match, so the menu is never empty.
    val subOpts = remember(trackTick, player, tracksOpen) {
        val prefs = settings.subtitleLanguages
        // "Show only my languages" (Settings > Subtitles) gates this
        // filter; with the toggle off every track is listed.
        if (prefs.isEmpty() || !settings.subtitleOnlyMyLanguages) textOpts
        else textOpts.filter { opt ->
            prefs.any { pref ->
                subtitleLangMatches(opt.group.getFormat(opt.trackIndex).language, pref)
            }
        }.ifEmpty { textOpts }
    }
    // "Subtitles off" under the overhaul: no sidecar cue source, no
    // MPV sub-add, and no selected Exo text track.
    val subtitlesOff = remember(trackTick, player, sidecarSubUrl, mpvActiveSubUrl) {
        sidecarSubUrl == null && mpvActiveSubUrl == null &&
            !hasSelectedTrack(player, C.TRACK_TYPE_TEXT)
    }

    fun pokeIndicator(i: PlayerIndicator) {
        indicator = i
        indicatorTick++
    }

    // Sleep timer ticker (v0.14.13, item 9): counts the deadline
    // down for the chip; at zero it pauses and clears itself.
    // (Declared after pokeIndicator — composable locals are
    // positional.)
    LaunchedEffect(sleepDeadlineMs) {
        if (sleepDeadlineMs <= 0L) {
            sleepRemainingSec = 0
            return@LaunchedEffect
        }
        while (true) {
            val leftMs = sleepDeadlineMs - System.currentTimeMillis()
            if (leftMs <= 0L) {
                sleepDeadlineMs = 0L
                sleepRemainingSec = 0
                if (mpvActive()) {
                    mpvEngine?.setPaused(true)
                } else {
                    runCatching { latestPlayer.value.pause() }
                }
                pokeIndicator(PlayerIndicator.Message("Sleep timer — playback paused"))
                break
            }
            sleepRemainingSec = ((leftMs + 999L) / 1000L).toInt()
            delay(500)
        }
    }

    // Seek-snap detection (owner's notes item 5 completion,
    // 2026-10-28): some hosts IGNORE range requests yet still report
    // a seekable window, so guardedSeekTo cannot refuse their seeks
    // up front — the seek "succeeds" and the server silently restarts
    // the file at ~0. After any far seek, the poll loop verifies once
    // (~1.5 s later) that playback actually landed near the target;
    // a position back at the start means the host ignored the seek,
    // and its host joins [sessionUnseekableHosts] so guardedSeekTo
    // gives it the guarded treatment for the rest of the session.
    /** Target of the far seek awaiting verification; -1 = none pending. */
    var pendingSeekVerifyTargetMs by remember { mutableLongStateOf(-1L) }
    /** Wall-clock time the pending seek was issued. */
    var pendingSeekVerifyAtMs by remember { mutableLongStateOf(0L) }
    /** videoId / streamUrl the pending seek was issued against. */
    var pendingSeekVerifyVideoId by remember { mutableStateOf<String?>(null) }
    var pendingSeekVerifyStreamUrl by remember { mutableStateOf<String?>(null) }
    /** Hosts proven to ignore seeks (snap-detected). Seeded from the
     *  persisted set (v0.14.15) so a caught host stays guarded from
     *  the first seek of later sessions too, not only this one. */
    var sessionUnseekableHosts by remember {
        mutableStateOf(settings.unseekableHosts)
    }

    fun streamHostOf(url: String?): String? =
        runCatching { Uri.parse(url.orEmpty()).host }.getOrNull()
            ?.lowercase()?.takeIf { it.isNotBlank() }

    fun clearPendingSeekVerify() {
        pendingSeekVerifyTargetMs = -1L
        pendingSeekVerifyVideoId = null
        pendingSeekVerifyStreamUrl = null
    }

    // A new video or a new source invalidates any pending verification
    // (the position after a switch legitimately restarts).
    LaunchedEffect(currentRequest.videoId, currentRequest.streamUrl) {
        clearPendingSeekVerify()
    }

    /**
     * Seek guarded for sources that don't support seeking (owner's
     * order 2026-10-27). Some hosts serve a plain file with no range
     * support; ExoPlayer then reports an unseekable window and a seek
     * past the buffer silently snaps playback back to the start.
     * Here: seeking inside the already-buffered range is allowed
     * (ExoPlayer permits that even on unseekable windows); a seek
     * beyond it is refused and the user is TOLD on screen that this
     * source can't seek. Returns true when the seek was performed.
     */
    fun guardedSeekTo(targetMs: Long): Boolean {
        // Any new seek supersedes a still-pending verification.
        clearPendingSeekVerify()
        if (mpvActive()) {
            // The second engine seeks natively (absolute+exact); the
            // range-guard machinery below is ExoPlayer-specific.
            mpvEngine?.seekTo(targetMs)
            scheduleSeekProgressSave()
            return true
        }
        val c = player
        val req = currentRequest
        if (req.isTrailer || req.liveChannel != null) {
            c.seekTo(targetMs)
            scheduleSeekProgressSave()
            return true
        }
        val windowUnseekable = runCatching {
            val timeline = c.currentTimeline
            timeline.windowCount > 0 &&
                !timeline.getWindow(
                    c.currentWindowIndex,
                    androidx.media3.common.Timeline.Window()
                ).isSeekable
        }.getOrDefault(false)
        // Snap-detected hosts (item 5, 2026-10-28) get the same
        // guarded treatment as the known-unseekable list.
        val hostProvenUnseekable =
            streamHostOf(req.streamUrl)?.let { it in sessionUnseekableHosts } == true
        // Forced seek (owner order 2026-10-30): with the Settings toggle
        // ON, range-refusing hosts no longer refuse the seek — the data
        // source reads-and-discards to the seek point instead (see
        // ForceSeekHttp). Only a genuinely unseekable window (player has
        // no seek map at all) still refuses. Toggle OFF = the exact
        // pre-2026-10-30 guarded behaviour for every trigger.
        val hostRefusesRanges = isUnseekableStreamUrl(req.streamUrl) || hostProvenUnseekable
        val seekGuarded = if (settings.forceSeekAnyStream) {
            windowUnseekable
        } else {
            hostRefusesRanges || windowUnseekable
        }
        if (seekGuarded &&
            targetMs > c.bufferedPosition + 500L
        ) {
            pokeIndicator(PlayerIndicator.Message("This source doesn't support seeking"))
            return false
        }
        val positionBeforeMs = c.currentPosition
        c.seekTo(targetMs)
        scheduleSeekProgressSave()
        // Arm the snap verification only where a snap is both
        // possible and distinguishable: a far target, issued from
        // somewhere other than the start (a seek issued AT the start
        // or TO near the start can never be told apart from a snap).
        if (targetMs > 30_000L && positionBeforeMs > 5_000L) {
            pendingSeekVerifyTargetMs = targetMs
            pendingSeekVerifyAtMs = System.currentTimeMillis()
            pendingSeekVerifyVideoId = req.videoId
            pendingSeekVerifyStreamUrl = req.streamUrl
        }
        return true
    }

    fun seekBy(deltaMs: Long): Boolean {
        val dur = activeDurationMs().takeIf { it > 0 } ?: Long.MAX_VALUE
        return guardedSeekTo((activePositionMs() + deltaMs).coerceIn(0L, dur))
    }

    fun seekByWithFeedback(deltaMs: Long) {
        demoteAutoplayToSuggestion() // interaction stops the countdown, keeps the offer
        if (seekBy(deltaMs)) {
            pokeIndicator(PlayerIndicator.Seek(if (deltaMs >= 0) "+10s" else "−10s"))
        }
    }

    // Accumulating double-tap seek (mobile overhaul): rapid taps in
    // the same direction keep adding 10 s FROM the position of the
    // first tap (3 taps = 30 s), instead of each tap re-basing on a
    // playhead that hasn't landed yet. The accumulation resets
    // after 800 ms without a tap, or when the direction flips.
    var tapSeekBaselineMs by remember { mutableLongStateOf(-1L) }
    var tapSeekAccumulatedMs by remember { mutableLongStateOf(0L) }
    var tapSeekLastAtMs by remember { mutableLongStateOf(0L) }
    var tapSeekDirection by remember { mutableIntStateOf(0) }

    fun doubleTapSeek(forward: Boolean) {
        demoteAutoplayToSuggestion() // interaction stops the countdown, keeps the offer
        val now = System.currentTimeMillis()
        val dir = if (forward) 1 else -1
        if (now - tapSeekLastAtMs > 800L || tapSeekDirection != dir || tapSeekBaselineMs < 0L) {
            tapSeekBaselineMs = activePositionMs()
            tapSeekAccumulatedMs = 0L
            tapSeekDirection = dir
        }
        tapSeekLastAtMs = now
        tapSeekAccumulatedMs += 10_000L
        val dur = activeDurationMs()
        val target = (tapSeekBaselineMs + dir * tapSeekAccumulatedMs)
            .coerceIn(0L, if (dur > 0) dur else Long.MAX_VALUE)
        if (guardedSeekTo(target)) {
            // Live readout (v0.14.26, batch item 7): every tap
            // re-pokes the pill with the ACCUMULATED seconds and
            // the landing time, so the buildup (+10s → +20s →
            // +30s …) is visible in real time while tapping. The
            // indicator updates its content in place — no re-pop.
            val secs = tapSeekAccumulatedMs / 1000
            pokeIndicator(
                PlayerIndicator.Seek(
                    text = if (forward) "+${secs}s" else "−${secs}s",
                    subtext = "→ ${formatMs(target)}"
                )
            )
        }
    }

    fun toggleControls() {
        if (locked) return
        demoteAutoplayToSuggestion() // a wake tap must not silently kill the next-episode offer
        showControls = !showControls
        if (showControls) controlsTick++
    }

    fun togglePlay() {
        demoteAutoplayToSuggestion() // interaction stops the countdown, keeps the offer
        if (mpvActive()) {
            val engine = mpvEngine ?: return
            if (engine.snapshot.value.paused) {
                // Resume after a user pause (v0.14.34): the buffer
                // back up may wear the startup overlay.
                resumeBuffering = true
                engine.setPaused(false)
            } else {
                resumeBuffering = false
                engine.setPaused(true)
                // Progress flush on pause (overhaul): a crash after
                // pausing must not lose the session's progress.
                savePositionHook?.invoke()
            }
            return
        }
        val c = player
        if (c.isPlaying) {
            resumeBuffering = false
            c.pause()
            savePositionHook?.invoke()
        } else {
            // Only a play press that ends a real user pause counts
            // as a resume — a tap during a network rebuffer
            // (playWhenReady already true) must not promote that
            // rebuffer to the startup overlay.
            if (!c.playWhenReady) resumeBuffering = true
            c.play()
        }
    }

    // TV remote fallback: MainActivity.onKeyDown forwards Left/Right/FF/RW
    // here ONLY when Compose didn't consume the key (e.g. focus was lost).
    LaunchedEffect(Unit) {
        MainActivity.playerSeekRequest.collect { seekByWithFeedback(it) }
    }

    fun cycleAspect() {
        aspectMode = when (aspectMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        playerView?.resizeMode = aspectMode
        if (mpvActive()) mpvEngine?.setResizeMode(aspectMode)
        pokeIndicator(PlayerIndicator.Message("Aspect: $aspectLabel"))
    }

    fun startSeekPreview() {
    }

    /** MPV audio pick from the Audio sheet (track-list row). */
    fun applyMpvAudioSelection(track: com.pulsestream.app.player.MpvPlayerEngine.Track?) {
        userPickedAudio = true
        mpvEngine?.selectAudio(track?.id)
        trackTick++
        pokeIndicator(
            PlayerIndicator.Message(
                if (track == null) "Audio: Auto" else "Audio: ${track.title ?: track.lang ?: "Track ${track.id}"}"
            )
        )
    }

    fun applyAudioSelection(opt: TrackOption?) {
        // A manual pick (including "Auto", which hands selection back) is
        // the user's word for this session — auto-select steps aside.
        userPickedAudio = true
        val params = player.trackSelectionParameters.buildUpon()
        if (opt == null) params.clearOverridesOfType(C.TRACK_TYPE_AUDIO)
        else params.setOverrideForType(TrackSelectionOverride(opt.group, listOf(opt.trackIndex)))
        player.trackSelectionParameters = params.build()
        trackTick++
        pokeIndicator(PlayerIndicator.Message(if (opt == null) "Audio: Auto" else "Audio: ${opt.label}"))
    }

    /**
     * Tightened preferred-audio enforcement (v0.12.0): buildExo only passes
     * the Settings > Playback language as a track-selector *hint*, which
     * the selector could outvote (channel count / role flags), so the
     * chosen language sometimes didn't play even when present. Now the
     * preference is applied as a hard TrackSelectionOverride for the first
     * audio track whose language matches, re-applied whenever the track
     * set changes (playback start, source switch, late track arrivals).
     * No matching track → parameters stay untouched (graceful fallback to
     * the default selection).
     */
    fun applyPreferredAudioLanguage() {
        if (userPickedAudio) return
        val pref = settings.preferredAudioLanguage?.takeIf { it.isNotBlank() } ?: return
        val p = player
        // Already playing the preferred language — nothing to tighten.
        val alreadySelected = p.currentTracks.groups
            .filter { it.type == C.TRACK_TYPE_AUDIO && it.isSelected }
            .any { g ->
                (0 until g.length).any { i ->
                    g.isTrackSelected(i) && subtitleLangMatches(g.getTrackFormat(i).language, pref)
                }
            }
        if (alreadySelected) return
        val match = p.currentTracks.groups
            .filter { it.type == C.TRACK_TYPE_AUDIO }
            .firstNotNullOfOrNull { g ->
                (0 until g.length).firstOrNull { i ->
                    subtitleLangMatches(g.getTrackFormat(i).language, pref)
                }?.let { idx -> g to idx }
            } ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguages(pref)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .setOverrideForType(TrackSelectionOverride(match.first.mediaTrackGroup, listOf(match.second)))
            .build()
        trackTick++
    }

    // Apply the preferred audio language on player (re)creation and on
    // every track-set change for that player.
    LaunchedEffect(player) {
        userPickedAudio = false
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                applyPreferredAudioLanguage()
            }
        }
        player.addListener(listener)
        applyPreferredAudioLanguage()
        try {
            kotlinx.coroutines.awaitCancellation()
        } finally {
            player.removeListener(listener)
        }
    }

    /** MPV embedded-subtitle pick from the subtitle overlay. */
    fun applyMpvSubtitleSelection(track: com.pulsestream.app.player.MpvPlayerEngine.Track?) {
        sidecarTouched = true
        subtitleMemoryKey(currentRequest)?.let { key ->
            when {
                track == null -> settings.setSubtitleChoiceFor(key, "off")
                !track.lang.isNullOrBlank() ->
                    settings.setSubtitleChoiceFor(key, "lang:${track.lang}")
                else -> Unit
            }
        }
        mpvActiveSubUrl = null
        mpvEngine?.selectSubtitle(track?.id)
        trackTick++
        pokeIndicator(
            PlayerIndicator.Message(
                if (track == null) "Subtitles: Off"
                else "Subtitles: ${track.title ?: track.lang ?: "Track ${track.id}"}"
            )
        )
    }

    fun applySubtitleSelection(opt: TrackOption?) {
        // Picking an embedded track (or "None") hands rendering back
        // from the sidecar engine to the player's own text renderer.
        if (sidecarSubUrl != null) {
            sidecarGeneration.incrementAndGet()
            sidecarSubUrl = null
            sidecarCues = emptyList()
            playerView?.subtitleView?.setCues(emptyList())
        }
        sidecarTouched = true
        // Remember the manual pick for this title/series (v0.14.15,
        // owner's order): it wins over the auto-pick on the next
        // playback. Side-loaded tracks carry their subtitle URL as
        // the track id; embedded tracks are remembered by language.
        subtitleMemoryKey(currentRequest)?.let { key ->
            when {
                opt == null -> settings.setSubtitleChoiceFor(key, "off")
                else -> {
                    val format = runCatching {
                        opt.group.getFormat(opt.trackIndex)
                    }.getOrNull()
                    val trackId = format?.id
                    when {
                        trackId != null && trackId.startsWith("http") ->
                            settings.setSubtitleChoiceFor(key, "url:$trackId")
                        !format?.language.isNullOrBlank() ->
                            settings.setSubtitleChoiceFor(key, "lang:${format?.language}")
                        else -> Unit
                    }
                }
            }
        }
        val params = player.trackSelectionParameters.buildUpon()
        if (opt == null) {
            params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            params.setOverrideForType(TrackSelectionOverride(opt.group, listOf(opt.trackIndex)))
        }
        player.trackSelectionParameters = params.build()
        trackTick++
        pokeIndicator(
            PlayerIndicator.Message(if (opt == null) "Subtitles: Off" else "Subtitles: ${opt.label}")
        )
    }

    fun openSubtitleSearch() {
        // Panel-integrated (v0.14.2): results merge into the subtitle
        // panel's list instead of opening a separate sheet.

        subSearchLoading = true
        subSearchError = null
        subSearchResults = emptyList()
        // Capture request data on the main thread before hopping to IO.
        val imdb = currentRequest.imdbId
        val isMovie = currentRequest.isMovie
        val existingUrls = (currentRequest.subtitles + addedSubs).map { it.url }.toSet()
        ioScope.launch {
            try {
                if (imdb.isNullOrBlank()) {
                    withContext(Dispatchers.Main) {
                        subSearchError = "No title info available for subtitle search."
                    }
                } else {
                    val type = if (isMovie) "movie" else "series"
                    val results = repository.searchSubtitles(type, imdb)
                        .filter { it.url !in existingUrls }
                    withContext(Dispatchers.Main) {
                        subSearchResults = results
                        if (results.isEmpty()) subSearchError = "No subtitles found for this title."
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    subSearchError = e.message ?: "Subtitle search failed."
                }
            } finally {
                withContext(Dispatchers.Main + NonCancellable) { subSearchLoading = false }
            }
        }
    }

    var pendingDefaultSubUrl by remember { mutableStateOf<String?>(null) }
    // Subtitle switch fix (2026-11-09): the pure decision core for
    // panel picks (SubtitlePickTracker in PlayerHelpers) — pending
    // download state, failure state, activation hand-off. The two
    // mirrors below are its Compose-visible face for the panel: a
    // pick that is still downloading says so, and a pick whose
    // download/resolve failed says so — never silence while the
    // previous subtitle keeps rendering.
    val subPickTracker =
        remember { com.pulsestream.app.ui.screens.player.SubtitlePickTracker() }
    var subPickDownloadingLabel by remember { mutableStateOf<String?>(null) }
    var subPickFailedLabel by remember { mutableStateOf<String?>(null) }
    // True when side-loaded subtitles existed but none could be downloaded.
    var subLoadError by remember { mutableStateOf(false) }

    fun addExternalSubtitle(sub: Subtitle) {
        // A hand-picked online subtitle is a manual pick too
        // (v0.14.15): remember it for this title/series.
        subtitleMemoryKey(currentRequest)?.let { key ->
            settings.setSubtitleChoiceFor(key, "url:${sub.url}")
        }
        addedSubs = addedSubs + sub
        subSearchOpen = false
        // The resolver effect below picks this up, downloads it and makes it
        // the active subtitle. The pending pick is stored as a match
        // KEY (v0.14.30), not the raw listed URL: the resolver's
        // published copy of this same file may spell the URL
        // differently, and the pending match must survive that.
        pendingDefaultSubUrl =
            com.pulsestream.app.ui.screens.player.subtitleMatchKey(sub.url)
        // Subtitle switch fix (2026-11-09): the pick is NOT on yet —
        // it still has to download. The old code announced
        // "Subtitles: <lang>" here as if the switch had happened,
        // and if the download then failed, nothing ever corrected
        // it while the previous subtitle kept rendering. The
        // tracker now owns the pick: the panel shows the
        // downloading state, activation announces the language when
        // it actually lands, and a failed resolve surfaces as an
        // error (resolver effect + tracker).
        subPickTracker.beginPick(
            sub, displayLanguage(sub.lang) ?: sub.lang.uppercase()
        )
        subPickDownloadingLabel = subPickTracker.pendingLabel
        subPickFailedLabel = null
        pokeIndicator(PlayerIndicator.Message("Downloading subtitle…"))
    }

    // ---- Subtitle panel plumbing (v0.14.2, owner's reference design) ----

    /** Every subtitle the panel can offer, instantly: the request's own
     *  (straight from the addon response — no waiting), the user's
     *  additions and online-search results, deduped by URL. */
    fun panelSubs(): List<Subtitle> =
        (currentRequest.subtitles + plavioSubs + addedSubs + subSearchResults)
            .distinctBy { it.url }

    fun panelTrackId(opt: TrackOption): String? =
        runCatching { opt.group.getFormat(opt.trackIndex).id }.getOrNull()

    fun panelLangName(code: String?): String =
        displayLanguage(code) ?: code?.uppercase() ?: "Unknown"

    /** Player text tracks that did NOT come from the panel's subtitle
     *  list — i.e. tracks embedded in the video file itself. */
    fun panelEmbeddedOpts(): List<TrackOption> {
        val subs = panelSubs()
        return textOpts.filter { o -> subs.none { it.url == panelTrackId(o) } }
    }

    /** (language name, track count) pairs in first-seen order. */
    fun panelLanguages(): List<Pair<String, Int>> {
        val counts = linkedMapOf<String, Int>()
        panelSubs().forEach {
            val n = panelLangName(it.lang)
            counts[n] = (counts[n] ?: 0) + 1
        }
        panelEmbeddedOpts().forEach { o ->
            val n = panelLangName(
                runCatching { o.group.getFormat(o.trackIndex).language }.getOrNull()
            )
            counts[n] = (counts[n] ?: 0) + 1
        }
        return counts.entries.map { it.key to it.value }
    }

    // ---- Sidecar subtitle engine (mobile overhaul) ----

    /**
     * Renders [resolved] through the sidecar: parse off-player, then
     * the 100 ms render loop pushes the active cues into the
     * SubtitleView. The media item is never touched — no re-prepare,
     * no rebuffer. A file that parses to nothing deactivates the
     * sidecar quietly (never a media reload as a "fallback").
     */
    fun activateSidecarSubtitle(resolved: ResolvedSubtitle) {
        // Subtitle switch fix (2026-11-09): the previous subtitle
        // is deactivated FIRST (generation bump + cues cleared
        // below), then the new one takes over — a switch never
        // leaves the old language rendering underneath. The
        // tracker records what is actually activating, completing
        // a pending pick whose file this is.
        subPickTracker.markActivated(resolved)
        if (!subPickTracker.isDownloading) subPickDownloadingLabel = null
        val generation = sidecarGeneration.incrementAndGet()
        sidecarSubUrl = resolved.sub.url
        sidecarCues = emptyList()
        ioScope.launch {
            val parsed = withContext(Dispatchers.IO) {
                com.pulsestream.app.data.PlavioSidecarSubtitles.loadCues(resolved)
            }
            withContext(Dispatchers.Main) {
                if (disposed.get() || sidecarGeneration.get() != generation) {
                    return@withContext
                }
                if (parsed.cues.isEmpty()) {
                    // Downloaded but unusable (no cues parsed):
                    // say so — the old code just went dark silently.
                    sidecarSubUrl = null
                    sidecarCues = emptyList()
                    subPickFailedLabel =
                        displayLanguage(resolved.sub.lang)
                            ?: resolved.sub.lang.uppercase()
                    pokeIndicator(
                        PlayerIndicator.Message("Couldn't load this subtitle")
                    )
                } else {
                    sidecarCues = parsed.cues
                    subPickFailedLabel = null
                }
            }
        }
        // The player's own text renderer must not double up with the
        // sidecar — text tracks are disabled while the sidecar shows.
        runCatching {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
        }
        trackTick++
    }

    /** Stops sidecar rendering and clears the caption view. */
    fun deactivateSidecarSubtitle() {
        sidecarGeneration.incrementAndGet()
        sidecarSubUrl = null
        sidecarCues = emptyList()
        playerView?.subtitleView?.setCues(emptyList())
    }

    /**
     * The automatic/default sidecar activation, run when resolved
     * subtitles land: a pending panel tap wins first, then the
     * remembered/auto default — but never over an explicit manual
     * choice the user already made for this title. (Moved above
     * [applySubtitlesOff] / [reactivateSubtitles] in v0.14.30 —
     * composable local functions resolve in declaration order, and
     * the toggle's ON half calls this.)
     */
    fun maybeActivateDefaultSidecar() {
        val pending = pendingDefaultSubUrl
        if (pending != null) {
            // Subtitle switch fix (2026-11-09): the pending pick —
            // and only the pending pick — activates from a publish.
            // The remembered/default choice below can never
            // override a fresh tap, and while a pick is in flight
            // this branch runs first on every publish. The success
            // announcement lives here, at the moment the picked
            // subtitle actually takes over (it used to be announced
            // at tap time, before the download even started).
            val resolved = subPickTracker.activationFor(rawResolvedSubs)
                ?: com.pulsestream.app.ui.screens.player.findResolvedForPick(
                    rawResolvedSubs, pending
                )
            if (resolved != null) {
                pendingDefaultSubUrl = null
                subPickDownloadingLabel = null
                subPickFailedLabel = null
                activateSidecarSubtitle(resolved)
                pokeIndicator(
                    PlayerIndicator.Message(
                        "Subtitles: ${displayLanguage(resolved.sub.lang) ?: resolved.sub.lang.uppercase()}"
                    )
                )
            }
            return
        }
        if (sidecarSubUrl != null || sidecarTouched) return
        if (rawResolvedSubs.isEmpty()) return
        val index = defaultSubtitleIndex(rawResolvedSubs, null, currentRequest)
        if (index >= 0) activateSidecarSubtitle(rawResolvedSubs[index])
    }

    /**
     * "Subtitles: Off" for every engine (v0.14.30 fix, owner's
     * note 3b). The v0.14.29 card routed Off / the header toggle
     * through [applySubtitleSelection] — the EMBEDDED-track
     * selection path — but addon subtitles render through the
     * SIDECAR, which that path never stops when no sidecar pick is
     * live in its own bookkeeping, and which a pending pick could
     * re-activate afterwards: the Off tap wrote the store and
     * disabled the (unused) Exo text type, while the sidecar kept
     * painting cues — "on/off not working". Off now:
     *  - cancels any pending pick, so nothing re-activates later;
     *  - stops the sidecar and clears the caption view at once;
     *  - clears the MPV sub-add bookkeeping and deselects (the
     *    engine's select-subtitle call is the Off action's own —
     *    [applyMpvSubtitleSelection] stays the embedded-pick path);
     *  - disables the player's text type via the proven selection
     *    path, which also writes the remembered "off" choice.
     * A later file tap re-enables everything through
     * [activatePanelSubtitle] / [activateSidecarSubtitle] exactly
     * as before.
     */
    fun applySubtitlesOff() {
        pendingDefaultSubUrl = null
        // Subtitle switch fix (2026-11-09): Off also retires any
        // in-flight pick, so a download finishing after the Off tap
        // can never switch subtitles back on by itself.
        subPickTracker.cancel()
        subPickDownloadingLabel = null
        subPickFailedLabel = null
        panelPickedUrl = null
        deactivateSidecarSubtitle()
        if (mpvActive()) {
            mpvActiveSubUrl = null
            mpvEngine?.selectSubtitle(null)
            subtitleMemoryKey(currentRequest)?.let { key ->
                settings.setSubtitleChoiceFor(key, "off")
            }
            sidecarTouched = true
            trackTick++
            pokeIndicator(PlayerIndicator.Message("Subtitles: Off"))
        } else {
            applySubtitleSelection(null)
        }
    }

    /**
     * The card header toggle's re-enable half (v0.14.30): turning
     * subtitles back ON re-runs the default activation. The manual
     * "touched" latch is cleared FIRST — otherwise
     * [maybeActivateDefaultSidecar] refuses (it exists to protect
     * manual choices) and the toggle-on half silently does nothing,
     * the second half of the v0.14.29 dead-toggle bug. A remembered
     * "off" choice (just written by the Off half or an earlier
     * session) must not veto the explicit ON tap either, so the
     * remembered default for this title is resolved through the
     * same index the auto-activation uses, with "off" treated as
     * no-veto for this explicit action only.
     */
    fun reactivateSubtitles() {
        sidecarTouched = false
        if (mpvActive()) {
            mpvFileLoadedHook?.invoke()
            return
        }
        val pending = pendingDefaultSubUrl
        if (pending != null) {
            maybeActivateDefaultSidecar()
            return
        }
        if (sidecarSubUrl != null || rawResolvedSubs.isEmpty()) return
        val remembered = rememberedSubtitleChoice(currentRequest)
        val index = if (remembered == "off") {
            com.pulsestream.app.data.autoPickSubtitleIndex(
                rawResolvedSubs.map { it.sub },
                settings.subtitleLanguages,
                settings.subtitleDefaultMode,
                settings.subtitlePreferSdh,
                settings.subtitleForcedAutoShow
            ).takeIf { it >= 0 }
                ?: rawResolvedSubs.indices.first()
        } else {
            defaultSubtitleIndex(rawResolvedSubs, null, currentRequest)
        }
        if (index >= 0) activateSidecarSubtitle(rawResolvedSubs[index])
    }

    /** Tap-to-apply for a panel subtitle: addon subtitles render
     *  through the sidecar (Exo) or a sub-add (MPV); a subtitle that
     *  is not downloaded yet is added (download + apply) — never a
     *  silent no-op (v0.14.30). */
    fun activatePanelSubtitle(sub: Subtitle) {
        // Panel tap = manual pick (v0.14.15): remember it for this
        // title/series whichever way it gets applied below.
        subtitleMemoryKey(currentRequest)?.let { key ->
            settings.setSubtitleChoiceFor(key, "url:${sub.url}")
        }
        sidecarTouched = true
        if (mpvActive()) {
            val resolved =
                com.pulsestream.app.ui.screens.player.findResolvedForPick(
                    rawResolvedSubs, sub.url
                )
            if (resolved == null) {
                // Subtitle switch fix (2026-11-09): the old code
                // handed MPV the raw LISTED url (for PlavioSubs an
                // API-style address the engine may not be able to
                // load) and still marked the pick active + announced
                // it — when the load failed, the previously added
                // track kept rendering in silence. An undownloaded
                // pick now goes through the same add-and-resolve
                // path as Exo; the attach effect applies the
                // downloaded file to MPV the moment it publishes.
                addExternalSubtitle(sub)
                return
            }
            // A resolved tap is the newest intent: retire any older
            // pending pick so its late download can't override this.
            subPickTracker.cancel()
            pendingDefaultSubUrl = null
            subPickDownloadingLabel = null
            mpvEngine?.addExternalSubtitle(
                resolved.file.absolutePath,
                select = true
            )
            mpvActiveSubUrl = sub.url
            trackTick++
            pokeIndicator(
                PlayerIndicator.Message(
                    "Subtitles: ${displayLanguage(sub.lang) ?: sub.lang.uppercase()}"
                )
            )
            return
        }
        val resolved =
            com.pulsestream.app.ui.screens.player.findResolvedForPick(
                rawResolvedSubs, sub.url
            )
        when {
            resolved != null -> {
                // Newest tap wins: retire any older pending pick so
                // its late download can't override this switch.
                subPickTracker.cancel()
                pendingDefaultSubUrl = null
                subPickDownloadingLabel = null
                activateSidecarSubtitle(resolved)
                pokeIndicator(
                    PlayerIndicator.Message(
                        "Subtitles: ${displayLanguage(sub.lang) ?: sub.lang.uppercase()}"
                    )
                )
            }
            else -> {
                // Not downloaded yet (v0.14.30 fix, owner's note 3):
                // the panel lists EVERY subtitle, but the resolver
                // only downloads a capped subset up front (v0.14.17)
                // and the panel-open full resolve feeds a list whose
                // URLs are matched EXACTLY (bare `==`), so a file the
                // resolve step represents differently — above all a
                // PlavioSubs entry, whose listed URL is not the
                // resolver's download URL — never matched and the tap
                // died silently in the old "pending" branch (it only
                // fired when the resolver later happened to publish
                // that exact URL; for already-resolved titles it never
                // re-ran). The pick now ALWAYS goes through the
                // add-and-resolve path: the subtitle joins addedSubs,
                // the resolver effect re-runs keyed on addedSubs,
                // downloads the file, publishes it in rawResolvedSubs,
                // and maybeActivateDefaultSidecar activates the
                // pending pick by its match key. Nothing about the
                // tap can silently no-op any more.
                addExternalSubtitle(sub)
            }
        }
    }

    /**
     * Step-1 LANGUAGE tap (subtitle switch fix, 2026-11-09 — the
     * owner's exact report: "when I change to English the player
     * was showing same arabic"). The language row reads as a
     * selector (it carries the active language's check mark), but
     * its tap only navigated to the Files step and applied
     * nothing, so the previously selected language kept rendering.
     * A language tap now APPLIES the language: the best file of
     * that language — the shared auto-pick ranking over exactly
     * that language's panel files — goes through
     * [activatePanelSubtitle], so a downloaded file switches the
     * rendered subtitle at once and an undownloaded one downloads
     * with the visible state and auto-applies on arrival. A
     * language offered only by embedded tracks selects the
     * embedded track, exactly like its Files-step row. Tapping the
     * language already rendering is a no-op (no re-download, no
     * cue restart). The caller still advances to the Files step,
     * where the applied file is marked and the downloading/error
     * states show.
     */
    fun applyLanguagePick(langName: String) {
        val activeUrl = sidecarSubUrl
            ?: (if (mpvActive()) mpvActiveSubUrl else null)
        val activeLang = activeUrl?.let { url ->
            panelSubs().firstOrNull { it.url == url }
                ?.let { panelLangName(it.lang) }
        }
        if (activeLang == langName) return
        val langSubs = panelSubs().filter { panelLangName(it.lang) == langName }
        if (langSubs.isNotEmpty()) {
            val idx = com.pulsestream.app.data.autoPickSubtitleIndex(
                langSubs,
                settings.subtitleLanguages,
                settings.subtitleDefaultMode,
                settings.subtitlePreferSdh,
                settings.subtitleForcedAutoShow
            )
            val pick = langSubs.getOrNull(idx) ?: langSubs.first()
            panelPickedUrl = pick.url
            activatePanelSubtitle(pick)
            return
        }
        // Embedded-only language: mirror the Files-step rows.
        if (mpvActive()) {
            mpvTracksUi.firstOrNull {
                it.type == "sub" && !it.external &&
                    panelLangName(it.lang) == langName
            }?.let { track ->
                panelPickedUrl = "built-in"
                applyMpvSubtitleSelection(track)
            }
        } else {
            panelEmbeddedOpts().firstOrNull {
                panelLangName(
                    runCatching { it.group.getFormat(it.trackIndex).language }
                        .getOrNull()
                ) == langName
            }?.let { opt ->
                panelPickedUrl = "built-in"
                applySubtitleSelection(opt)
            }
        }
    }

    fun panelHostLabel(url: String): String {
        val host = runCatching { android.net.Uri.parse(url).host }.getOrNull()
            ?.removePrefix("www.")?.takeIf { it.isNotBlank() }
        return if (host == PlavioSubsClient.HOST) "PlavioSubs" else host ?: "Addon"
    }

    fun panelFileLabel(sub: Subtitle): String =
        sub.url.substringAfterLast('/').substringBefore('?')
            .ifBlank { displayLanguage(sub.lang) ?: sub.lang.uppercase() }

    fun panelFormatLabel(mimeType: String): String? = when (mimeType) {
        "application/x-subrip" -> "SRT"
        "text/vtt" -> "VTT"
        "application/ttml+xml" -> "TTML"
        else -> null
    }

    /** Panel delay readout in the reference format: "+0.500s". */
    fun panelDelayLabel(ms: Long): String =
        String.format(java.util.Locale.US, "%+.3fs", ms / 1000.0)

    /** Parses (startMs, text) cues out of a downloaded SRT/VTT file. */
    fun parseSubtitleCues(file: java.io.File): List<Pair<Long, String>> {
        val out = mutableListOf<Pair<Long, String>>()
        val timing = Regex("(\\d{1,2}):(\\d{2}):(\\d{2})[.,](\\d{3})\\s*-->")
        val lines = runCatching { file.readLines(Charsets.UTF_8) }.getOrDefault(emptyList())
        var i = 0
        while (i < lines.size && out.size < 4000) {
            val m = timing.find(lines[i])
            if (m == null) { i++; continue }
            val (h, min, sec, ms) = m.destructured
            val start = ((h.toLong() * 60 + min.toLong()) * 60 + sec.toLong()) * 1000 + ms.toLong()
            val text = StringBuilder()
            i++
            while (i < lines.size && lines[i].isNotBlank() && !timing.containsMatchIn(lines[i])) {
                val t = lines[i].replace(Regex("<[^>]+>"), "").trim()
                if (t.isNotEmpty() && !t.all { ch -> ch.isDigit() }) {
                    if (text.isNotEmpty()) text.append(' ')
                    text.append(t)
                }
                i++
            }
            if (text.isNotEmpty()) out.add(start to text.toString())
        }
        return out
    }

    /**
     * Style rail delay control: set the per-video delay (the stepper's
     * ±500ms — the owner's in-player principle — Reset's 0, or an Auto
     * Sync cue tap), persist it for this
     * video, cancel any in-progress auto-sync cue pick (a manual change
     * always wins), and re-shift the downloaded subtitles.
     */
    fun setSubtitleDelay(delayMs: Long) {
        val clamped = delayMs.coerceIn(-60_000L, 60_000L)
        subOffsetOverrideMs = clamped
        settings.setSubtitleDelayMsFor(currentRequest.videoId, clamped)
        captureCues = null
        // Sidecar + MPV apply the delay as a live render offset — no
        // file re-shift and no re-prepare (applySubtitleTiming below
        // now only feeds the legacy shifted list).
        if (mpvActive()) mpvEngine?.setSubtitleDelay(effectiveSubOffsetMs())
        applySubtitleTiming()
    }

    // MPV file-loaded hook (mobile overhaul): once the second engine
    // has the file, apply the track preferences the Exo path gets
    // from its track selector — preferred audio language, resize
    // mode, subtitle style + delay, and the default subtitle
    // (remembered pick, then the shared auto-pick; an addon winner
    // is sub-added from its resolved file, an embedded winner is
    // selected by track id).
    mpvFileLoadedHook = {
        val engine = mpvEngine
        if (engine != null && !disposed.get()) {
            engine.setResizeMode(aspectMode)
            if (!userPickedAudio) {
                settings.preferredAudioLanguage?.takeIf { it.isNotBlank() }?.let { pref ->
                    engine.tracks.value
                        .firstOrNull { track ->
                            track.type == "audio" && subtitleLangMatches(track.lang, pref)
                        }
                        ?.let { engine.selectAudio(it.id) }
                }
            }
            applyMpvSubtitleStyle()
            engine.setSubtitleDelay(effectiveSubOffsetMs())
            val remembered = rememberedSubtitleChoice(currentRequest)
            when {
                remembered?.startsWith("lang:") == true -> {
                    val lang = remembered.removePrefix("lang:")
                    engine.tracks.value
                        .firstOrNull { track ->
                            track.type == "sub" && subtitleLangMatches(track.lang, lang)
                        }
                        ?.let { engine.selectSubtitle(it.id) }
                }
                remembered == "off" -> engine.selectSubtitle(null)
                else -> {
                    val subs = panelSubs()
                    val winnerUrl = when {
                        remembered?.startsWith("url:") == true ->
                            remembered.removePrefix("url:")
                        subs.isNotEmpty() -> subs.getOrNull(
                            autoPickSubtitleIndex(
                                subs,
                                settings.subtitleLanguages,
                                settings.subtitleDefaultMode,
                                settings.subtitlePreferSdh,
                                settings.subtitleForcedAutoShow
                            )
                        )?.url
                        else -> null
                    }
                    if (winnerUrl != null) {
                        val resolved = rawResolvedSubs.firstOrNull { it.sub.url == winnerUrl }
                        engine.addExternalSubtitle(
                            resolved?.file?.absolutePath ?: winnerUrl,
                            select = true
                        )
                        mpvActiveSubUrl = winnerUrl
                    } else {
                        engine.selectSubtitle(null)
                    }
                }
            }
            trackTick++
        }
    }

    /** Auto Sync > Reload: drop the cached downloads + shifted copies
     *  and re-resolve every subtitle fresh from its source. */
    fun reloadPanelSubtitles() {
        rawResolvedSubs.forEach { raw ->
            runCatching { raw.file.delete() }
            val key = raw.file.absolutePath.hashCode().toUInt().toString(16)
            context.cacheDir.listFiles()?.forEach { f ->
                if (f.name.startsWith("shift_") && f.name.contains(key)) {
                    runCatching { f.delete() }
                }
            }
        }
        subReloadTick++
        pokeIndicator(PlayerIndicator.Message("Subtitles reloading…"))
    }

    /** Auto Sync > Capture: collect the cues of the active downloaded
     *  subtitle around the current position; the user then taps the
     *  line they are hearing and the delay is set from it. */
    fun startCaptureSync() {
        val selectedUrl = sidecarSubUrl
            ?: (if (mpvActive()) mpvActiveSubUrl else null)
            ?: textOpts.firstOrNull { it.selected }?.let { panelTrackId(it) }
        val raw = rawResolvedSubs.firstOrNull { it.sub.url == selectedUrl }
            ?: rawResolvedSubs.firstOrNull()
        if (raw == null) {
            pokeIndicator(PlayerIndicator.Message("Auto sync needs a downloaded subtitle track"))
            return
        }
        // The position is captured NOW (when the line is heard); a cue
        // tap later computes the delay from this stored position.
        capturePositionMs = player.currentPosition
        captureLoading = true
        ioScope.launch {
            val cues = parseSubtitleCues(raw.file)
            val center = (capturePositionMs - effectiveSubOffsetMs()).coerceAtLeast(0L)
            // The five cues nearest the captured position, in time order.
            val near = cues.sortedBy { kotlin.math.abs(it.first - center) }
                .take(5).sortedBy { it.first }
            withContext(Dispatchers.Main) {
                captureLoading = false
                captureCues = near
                if (near.isEmpty()) {
                    pokeIndicator(PlayerIndicator.Message("No subtitle lines found to sync from"))
                }
            }
        }
    }

    // URL of a just-added subtitle that should become active once resolved.

    // PlavioSubs (v0.14.33, owner's order): our own subtitle addon is
    // a BUILT-IN source in the player — on play, fetch its subtitles
    // for this title, no manual step. The panel lists every language
    // returned with the user's own languages first; the best match
    // under the user's subtitle rules (languages / default mode /
    // SDH / forced) becomes [plavioAutoSub] and the resolver below
    // downloads + applies it. Any other entry downloads only if the
    // user taps it in the panel. Fully off the playback path: the
    // site being unreachable or returning nothing changes nothing.
    LaunchedEffect(currentRequest) {
        val req = currentRequest
        if (req.isLive || req.isTrailer || req.streamUrl.startsWith("file:", true) ||
            req.imdbId.isNullOrBlank()
        ) {
            return@LaunchedEffect
        }
        val found = PlavioSubsClient.fetch(
            repository.api, req.type, req.imdbId!!, req.season, req.episode
        )
        if (found.isEmpty() || currentRequest != req || disposed.get()) {
            return@LaunchedEffect
        }
        // Entries the playing addon already carries for this title
        // (same file URL) are not duplicated.
        val fresh = found.filter { candidate ->
            req.subtitles.none { it.url == candidate.url }
        }
        // The user's own subtitle languages first (settings order,
        // stable); everything else keeps the server's order.
        val prefs = settings.subtitleLanguages
        val sorted = if (prefs.isEmpty()) {
            fresh
        } else {
            fresh.sortedBy { sub ->
                val idx = prefs.indexOfFirst { pref -> subtitleLangMatches(sub.lang, pref) }
                if (idx >= 0) idx else Int.MAX_VALUE
            }
        }
        plavioSubs = sorted
        val winner = autoPickSubtitleIndex(
            sorted,
            settings.subtitleLanguages,
            settings.subtitleDefaultMode,
            settings.subtitlePreferSdh,
            settings.subtitleForcedAutoShow
        )
        if (winner >= 0) plavioAutoSub = sorted[winner]
    }

    // Resolve side-loaded subtitles in the background once per request (or
    // when the user adds one via search): download, sniff the real format,
    // then attach. Files are cached so this is instant on repeat visits. The
    // resolved list goes into state; a separate effect attaches it, so a
    // source switch can carry the subtitles into the fresh player instead of
    // re-preparing the video (#29).
    LaunchedEffect(currentRequest, addedSubs, subReloadTick, plavioAutoSub) {
        val reqAtStart = currentRequest
        // The PlavioSubs auto-pick winner (v0.14.33) rides along
        // FIRST, so the shared auto-pick's stable ranking prefers it
        // on ties inside the user's top language; a remembered manual
        // pick still overrides it in subtitleConfigs.
        val all = listOfNotNull(plavioAutoSub) + reqAtStart.subtitles + addedSubs
        subLoadError = false
        resolvedSubs = emptyList()
        rawResolvedSubs = emptyList()
        // Downloaded titles (v0.14.14): subtitles saved beside the media
        // at download time ("Save subtitles with downloads") are already
        // local files — they join the resolved set directly instead of
        // being downloaded again.
        val localSubs = if (reqAtStart.streamUrl.startsWith("file:", true)) {
            withContext(Dispatchers.IO) {
                runCatching {
                    com.pulsestream.app.data.download.DownloadManager.get(context)
                        .savedSubtitlesForFile(reqAtStart.streamUrl)
                }.getOrDefault(emptyList())
            }
        } else {
            emptyList()
        }
        if (disposed.get()) {
            initialSubsSignal.complete(Unit)
            return@LaunchedEffect
        }
        // v0.14.17 lag fix (audit cause 5): the initial resolve no
        // longer downloads EVERY merged subtitle file (all addons'
        // subs combined, unbounded) before the first prepare — only
        // the preferred languages + best-ranked ~10, with user-added
        // subs always included. The remainder resolves lazily when
        // the subtitle panel opens (the tracksOpen effect below).
        val initialSet = if (subResolveAll) all
            else initialSubtitleSubset(all, addedSubs, settings.subtitleLanguages)
        subsCapped = initialSet.size < all.size
        var resolved = if (initialSet.isEmpty()) {
            emptyList()
        } else {
            resolveSubtitleFiles(
                initialSet, context.cacheDir,
                requestHeaders = reqAtStart.headers,
                streamOriginUrl = reqAtStart.streamUrl,
                isTv = isTv
            )
        }
        // Superseded while resolving (source/episode/zap switch) — the newer
        // effect run owns the result.
        if (currentRequest != reqAtStart || disposed.get()) return@LaunchedEffect
        // Auto-fetch (v0.14.14, Settings > Subtitles): the title arrived
        // with no usable subtitle — search online automatically and
        // resolve what it finds. The best match is then chosen by the
        // usual auto-pick rules. Source (v0.14.35): PlavioSubs, the
        // built-in client — since the addon trim no shipped
        // subtitle-search addon backs the old search, so it leads here;
        // any subtitle addon the user added by hand still contributes
        // via repository.searchSubtitles. The preferred languages are
        // applied by initialSubtitleSubset below, as before.
        if (resolved.isEmpty() && localSubs.isEmpty() &&
            settings.subtitleAutoFetchOnline &&
            !reqAtStart.isLive && !reqAtStart.imdbId.isNullOrBlank()
        ) {
            val found = runCatching {
                val fromPlavioSubs = PlavioSubsClient.fetch(
                    repository.api, reqAtStart.type, reqAtStart.imdbId!!,
                    reqAtStart.season, reqAtStart.episode
                )
                val fromAddons = repository.searchSubtitles(
                    reqAtStart.type, reqAtStart.imdbId!!
                )
                (fromPlavioSubs + fromAddons).distinctBy { it.url }
                    .filter { candidate -> all.none { it.url == candidate.url } }
            }.getOrDefault(emptyList())
            if (found.isNotEmpty() && currentRequest == reqAtStart && !disposed.get()) {
                // Same v0.14.17 cap as the main resolve: preferred
                // languages + best-ranked ~10 first; the panel-open
                // pass resolves any remainder.
                val foundSet = if (subResolveAll) found
                    else initialSubtitleSubset(found, emptyList(), settings.subtitleLanguages)
                if (foundSet.size < found.size) subsCapped = true
                resolved = resolveSubtitleFiles(
                    foundSet, context.cacheDir,
                    requestHeaders = reqAtStart.headers,
                    streamOriginUrl = reqAtStart.streamUrl,
                    isTv = isTv
                )
            }
        }
        if (currentRequest != reqAtStart || disposed.get()) return@LaunchedEffect
        val combined = localSubs + resolved
        subLoadError = combined.isEmpty() && all.isNotEmpty()
        // Store the raw files, then publish the timing-shifted list. The
        // separate attach effect picks up resolvedSubs.
        rawResolvedSubs = combined
        // Subtitle switch fix (2026-11-09): if this cycle attempted
        // the pending panel pick (the pick rides in `all` via
        // addedSubs) but did not publish it, its download/resolve
        // failed — resolveSubtitleFiles drops failures silently, so
        // without this the previous subtitle would keep rendering
        // forever with the pick pending in silence. Surface the
        // failure in the panel + indicator and retire the pending
        // slot so a later publish can't resurrect the dead pick.
        subPickTracker.resolveCycleFinished(all, combined)
        subPickTracker.failedLabel?.let { label ->
            if (subPickFailedLabel != label) {
                subPickFailedLabel = label
                subPickDownloadingLabel = null
                pendingDefaultSubUrl = null
                pokeIndicator(
                    PlayerIndicator.Message("Couldn't load this subtitle")
                )
            }
        }
        val generation = subtitleShiftGeneration.incrementAndGet()
        val shifted = withContext(Dispatchers.IO) {
            shiftSubtitles(combined, effectiveSubOffsetMs(), context.cacheDir)
        }
        if (currentRequest == reqAtStart && subtitleShiftGeneration.get() == generation && !disposed.get()) {
            resolvedSubs = shifted
        }
        // Releases the one-time init's bounded pre-prepare wait (finding 1),
        // whether the resolve produced files or came back empty-handed.
        initialSubsSignal.complete(Unit)
    }

    // v0.14.17: opening the subtitle panel completes a capped
    // initial subtitle set — the resolver effect above re-runs with
    // subResolveAll set and resolves the full merged list, exactly
    // as it used to before the first prepare.
    LaunchedEffect(tracksOpen, tracksMode) {
        if (tracksOpen && tracksMode == "subs" && subsCapped && !subResolveAll) {
            subResolveAll = true
            subReloadTick++
        }
    }

    // Load the persisted per-video delay only when the actual
    // title/episode changes; adding a subtitle or switching source does
    // not discard the user's delay.
    LaunchedEffect(currentRequest.metaId, currentRequest.videoId, currentRequest.season, currentRequest.episode) {
        subOffsetOverrideMs = settings.subtitleDelayMsFor(currentRequest.videoId)
        if (rawResolvedSubs.isNotEmpty()) applySubtitleTiming()
    }

    // Attach resolved subtitles to the player. Skips silently when the fresh
    // player was already built carrying them (source switch) — no re-prepare.
    // Until the one-time init finishes, the init owns subtitles (it folds
    // them into the first prepare, finding 1); this effect takes over after.
    // Sidecar activation (mobile overhaul): when resolved subtitles
    // land, the DEFAULT (or a pending panel tap) starts rendering
    // through the sidecar — the media item is never re-prepared for
    // subtitles. Until the one-time init finishes, the init owns the
    // first activation window (it waits for the resolver, finding 1).
    LaunchedEffect(player, rawResolvedSubs, initialPrepareDone) {
        if (!initialPrepareDone) return@LaunchedEffect
        if (rawResolvedSubs.isEmpty() || disposed.get()) return@LaunchedEffect
        if (mpvActive()) {
            // MPV renders subs natively (sub-add) — but a pending
            // panel pick (subtitle switch fix, 2026-11-09) still has
            // to be applied the moment its file publishes: sub-add
            // the downloaded file and select it, replacing whatever
            // track was rendering. No pending pick, no action (the
            // file-loaded hook owns MPV's default choice).
            val hit = subPickTracker.activationFor(rawResolvedSubs)
            if (hit != null) {
                pendingDefaultSubUrl = null
                subPickTracker.markActivated(hit)
                subPickDownloadingLabel = null
                subPickFailedLabel = null
                mpvEngine?.addExternalSubtitle(
                    hit.file.absolutePath,
                    select = true
                )
                mpvActiveSubUrl = hit.sub.url
                trackTick++
                pokeIndicator(
                    PlayerIndicator.Message(
                        "Subtitles: ${displayLanguage(hit.sub.lang) ?: hit.sub.lang.uppercase()}"
                    )
                )
            }
            return@LaunchedEffect
        }
        maybeActivateDefaultSidecar()
    }

    // Sidecar render loop (mobile overhaul): every 100 ms, push the
    // cues active at (position − subtitle delay) into the PlayerView's
    // SubtitleView. The delay is a render offset here — changing it
    // never re-shifts a file and never touches the media item.
    // Unchanged cue sets are never re-pushed (signature check).
    LaunchedEffect(player, sidecarSubUrl) {
        if (sidecarSubUrl == null) return@LaunchedEffect
        var lastSignature = Long.MIN_VALUE
        while (!disposed.get()) {
            val pv = playerView
            val cues = sidecarCues
            if (pv != null) {
                if (cues.isEmpty()) {
                    if (lastSignature != 0L) {
                        lastSignature = 0L
                        pv.subtitleView?.setCues(emptyList())
                    }
                } else {
                    val positionUs =
                        (player.currentPosition - effectiveSubOffsetMs())
                            .coerceAtLeast(0L) * 1000L
                    val active = com.pulsestream.app.data.PlavioSidecarSubtitles
                        .collectActiveCues(cues, positionUs)
                    val merged = com.pulsestream.app.data.PlavioSidecarSubtitles
                        .mergeOverlappingCues(active)
                    val signature = com.pulsestream.app.data.PlavioSidecarSubtitles
                        .activeCueSignature(merged)
                    if (signature != lastSignature) {
                        lastSignature = signature
                        pv.subtitleView?.setCues(merged)
                    }
                }
            }
            delay(com.pulsestream.app.data.PlavioSidecarSubtitles.RENDER_INTERVAL_MS)
        }
    }

    // -----------------------------------------------------------------
    // Error ladder (mobile overhaul, 2026-11-06). Rung 0 lives inside
    // the engines (Exo: the MIME heal + this decoder rebuild; MPV:
    // its own demuxer recovery). Then, once per title each: rung 1
    // credential refresh (re-poll the SAME provider for a fresh link,
    // resume at the failure position), rung 2 the one silent engine
    // failover (position carried), rung 3 a plain error screen with
    // one Back. A playback error NEVER auto-switches the source.
    // -----------------------------------------------------------------

    // Item 14 (v0.14.24): patient same-stream retry — re-prepare
    // the SAME stream on the same engine, at the failure position,
    // after a short pause. At most twice per title; a permanent
    // HTTP status never reaches here (the listener skips straight
    // to the ladder). Only when these retries are spent does the
    // ladder move to its provider-refresh rung — and no rung ever
    // auto-tries a DIFFERENT source.
    sameStreamRetryHook = {
        if (sameStreamRetriesUsed >= 2 || disposed.get()) {
            false
        } else {
            sameStreamRetriesUsed++
            val req = currentRequest
            val old = player
            val position = runCatching { old.currentPosition }.getOrDefault(0L)
            val wasReady = old.playWhenReady
            ioScope.launch {
                delay(2_000)
                withContext(Dispatchers.Main) {
                    if (disposed.get() || latestPlayer.value !== old ||
                        latestRequest.value != req
                    ) {
                        return@withContext
                    }
                    val fresh = buildExo(req, emptyList())
                        .also { it.addListener(guardedPlayerListener()) }
                    playerView?.player = null
                    old.release()
                    player = fresh
                    playerError = null
                    fresh.setPlaybackSpeed(speed)
                    fresh.seekTo(position)
                    fresh.prepare()
                    fresh.playWhenReady = wasReady
                }
            }
            true
        }
    }

    decoderRebuildHook = {
        if (decoderRebuildAttempted || disposed.get()) {
            false
        } else {
            decoderRebuildAttempted = true
            val req = currentRequest
            val old = player
            val position = runCatching { old.currentPosition }.getOrDefault(0L)
            val wasReady = old.playWhenReady
            val fresh = buildExo(req, emptyList())
                .also { it.addListener(guardedPlayerListener()) }
            playerView?.player = null
            old.release()
            player = fresh
            playerError = null
            fresh.setPlaybackSpeed(speed)
            fresh.seekTo(position)
            fresh.prepare()
            fresh.playWhenReady = wasReady
            true
        }
    }

    /** Swaps the playing engine mid-play, carrying the position. */
    fun switchPlaybackEngine(
        to: com.pulsestream.app.player.PlaybackEngine,
        resumeAtMs: Long
    ) {
        val req = currentRequest
        playerError = null
        ladderTerminal = false
        if (to == com.pulsestream.app.player.PlaybackEngine.MPV) {
            val old = player
            playerView?.player = null
            runCatching { old.release() }
            activateMpv(req, resumeAtMs, autoplay = true)
        } else {
            releaseMpv()
            val fresh = buildExo(req, emptyList())
                .also { it.addListener(guardedPlayerListener()) }
            fresh.setPlaybackSpeed(speed)
            player = fresh
            subsAttached = null
            fresh.seekTo(resumeAtMs)
            fresh.prepare()
            fresh.playWhenReady = true
        }
        pokeIndicator(
            PlayerIndicator.Message(
                if (to == com.pulsestream.app.player.PlaybackEngine.MPV) {
                    "Engine: MPV"
                } else {
                    "Engine: ExoPlayer"
                }
            )
        )
    }

    /**
     * Item 12's cap path (v0.14.26), shared by both ladders: the
     * current source stands CONFIRMED DEAD (permanent error with
     * the same-source rungs spent, an exhausted credential
     * refresh, or full patience exhausted — never a first or
     * transient failure). Spend the play's ONE auto source switch;
     * if it was already spent, stop everything and show the
     * owner's popup instead of a third stream.
     */
    fun proceedToSourceSwitchOrPopup(message: String) {
        if (!currentRequest.isLive && !currentRequest.isTrailer &&
            autoSourceSwitchesUsed < 1
        ) {
            autoSourceSwitchesUsed++
            if (autoSourceSwitchHook?.invoke() == true) return
            // No other source exists at all — the popup still
            // tells the truth better than a bare ladder error.
            streamWontPlayShown = true
            showControls = true
            controlsTick++
            return
        }
        if (!currentRequest.isLive && !currentRequest.isTrailer) {
            // The one switch is spent and the second stream is
            // dead too: no more auto changes, popup + picker.
            streamWontPlayShown = true
            showControls = true
            controlsTick++
            return
        }
        ladderTerminal = true
        playerError = message
        showControls = true
        controlsTick++
    }

    /**
     * ENGINE ladder only (v0.14.26, batch item 11 — owner's rule:
     * engines switch ONLY on player faults). This function is
     * reachable exclusively with a classified player fault
     * (decode / codec / format / engine-init): [handleFatalError]
     * routes source faults to the source ladder instead, so a
     * dead, slow, late or 404 source can never land here. When the
     * one engine failover is spent too, both engines have failed
     * this source — it counts as unsupported, i.e. confirmed dead,
     * and item 12's cap path decides what happens next.
     */
    fun proceedToEngineFailoverOrTerminal(
        fromEngine: com.pulsestream.app.player.PlaybackEngine,
        message: String
    ) {
        if (settings.autoEngineFailover && engineFailoverArmed && !engineFailoverUsed &&
            !currentRequest.isLive && !currentRequest.isTrailer
        ) {
            engineFailoverUsed = true
            switchPlaybackEngine(
                com.pulsestream.app.player.PlaybackEngineResolver.other(fromEngine),
                activePositionMs()
            )
            return
        }
        proceedToSourceSwitchOrPopup(message)
    }

    /**
     * Ladder rung 1: poll the provider's addon again (15 s at most)
     * for the same stream with a FRESH link — signed URLs expire, and
     * the session cache alone would just hand the dead one back.
     * Same provider is required; the same stream label scores best.
     * Resumes at the failure position on the refreshed link.
     */
    fun attemptCredentialRefresh(
        fromEngine: com.pulsestream.app.player.PlaybackEngine,
        message: String
    ) {
        val req = currentRequest
        val failedUrl = req.streamUrl
        val position = activePositionMs()
        ioScope.launch {
            var best: com.pulsestream.app.data.StreamItem? = null
            var bestScore = -1
            val collectJob = ioScope.launch {
                // v0.14.36 (defect 1): no cache seed — this rung exists
                // to poll for a FRESH link (see the doc above: "the
                // session cache alone would just hand the dead one
                // back"); the seed emission was exactly that hand-back.
                repository.streamResultsFlow(req.type, req.videoId, seedFromCache = false).collect { result ->
                    for (candidate in result.streams) {
                        if (!com.pulsestream.app.data.isPlayableLiveStreamUrl(candidate.url)) {
                            continue
                        }
                        val sameProvider =
                            (req.sourceId != null && candidate.sourceId == req.sourceId) ||
                                (req.sourceName != null && candidate.sourceName == req.sourceName)
                        if (!sameProvider) continue
                        var score = 0
                        if (!req.streamTitle.isNullOrBlank() &&
                            (candidate.title == req.streamTitle || candidate.name == req.streamTitle)
                        ) {
                            score += 40
                        }
                        if (candidate.url != failedUrl) score += 5
                        if (score > bestScore) {
                            bestScore = score
                            best = candidate
                        }
                    }
                }
            }
            val deadline = System.currentTimeMillis() + 15_000
            while (System.currentTimeMillis() < deadline && !disposed.get()) {
                val current = best
                if (current != null && current.url != failedUrl) break
                delay(500)
            }
            collectJob.cancel()
            val found = best
            withContext(Dispatchers.Main) {
                if (disposed.get()) return@withContext
                if (found != null && found.url != failedUrl) {
                    pokeIndicator(PlayerIndicator.Message("Refreshing link…"))
                    replaceStreamHook?.invoke(
                        req.copy(
                            streamUrl = found.url,
                            headers = found.headers,
                            mimeType = found.mimeType,
                            streamLabel = streamQualityLabel(found),
                            sourceName = found.sourceName,
                            sourceId = found.sourceId,
                            streamTitle = found.title ?: found.name
                        ),
                        position,
                        true
                    )
                } else {
                    // The refresh is a SOURCE-ladder rung: only
                    // source faults ever reach it (player faults
                    // route straight to the engine ladder in
                    // handleFatalError). A failed refresh therefore
                    // continues down the SOURCE ladder — item 12's
                    // cap — and never touches the engine (item 11).
                    proceedToSourceSwitchOrPopup(message)
                }
            }
        }
    }

    /**
     * The ladder entry point both engines call on a fatal error.
     * [playerFault] is the item-11 classification made at the
     * engine boundary (v0.14.26): TRUE only for player faults
     * (decode / codec / format / engine-init). The two ladders are
     * separate from here on:
     *  - PLAYER fault → the engine ladder (one silent Exo↔MPV
     *    failover; both engines failing = the source counts as
     *    unsupported → item 12's cap path).
     *  - SOURCE fault (dead / slow / late / no data / 404 /
     *    timeout / refused) → the source ladder ONLY: same-provider
     *    credential refresh, then item 12's cap path. The engine
     *    is NEVER switched for a source fault.
     */
    fun handleFatalError(
        fromEngine: com.pulsestream.app.player.PlaybackEngine,
        message: String,
        playerFault: Boolean
    ) {
        if (disposed.get()) return
        if (currentRequest.isLive || currentRequest.isTrailer) {
            ladderTerminal = true
            playerError = message
            showControls = true
            controlsTick++
            return
        }
        if (playerFault) {
            proceedToEngineFailoverOrTerminal(fromEngine, message)
            return
        }
        if (!credentialRefreshUsed) {
            credentialRefreshUsed = true
            attemptCredentialRefresh(fromEngine, message)
            return
        }
        proceedToSourceSwitchOrPopup(message)
    }

    fatalErrorHook = { engine, message, playerFault ->
        handleFatalError(engine, message, playerFault)
    }

    /**
     * Serializes player rebuilds (#5): rapid source switches/zaps used to
     * orphan the first fresh player (still playWhenReady → double audio) and
     * could complete out of order. Only the latest request wins; a superseded
     * request releases nothing — the winner owns the old player.
     */
    val replaceMutex = remember { Mutex() }
    val replaceGen = remember { AtomicInteger(0) }

    /** Rebuilds the ExoPlayer around a new stream, preserving position. */
    fun replaceStream(newReq: PlaybackRequest, startAtMs: Long, autoplay: Boolean) {
        if (disposed.get()) return
        preemptPendingLiveFallback()
        val gen = replaceGen.incrementAndGet()
        val old = player
        val oldReq = currentRequest
        // Read the old player's position on THIS thread (the player's own
        // thread, normally main). Touching it from a background thread crashes.
        // Under the second engine the position lives in its snapshot —
        // the parked ExoPlayer has nothing to say.
        val posMs = if (mpvActive()) activePositionMs() else old.currentPosition
        val durMs = if (mpvActive()) activeDurationMs() else old.duration.takeIf { it > 0 } ?: 0L
        ioScope.launch {
            replaceMutex.withLock {
                if (gen != replaceGen.get() || disposed.get()) return@withLock
                // #8: live TV never enters Continue Watching.
                if (!oldReq.isLive) {
                    repository.savePlayback(
                        title = oldReq.title,
                        poster = oldReq.poster,
                        videoId = oldReq.videoId,
                        streamUrl = oldReq.streamUrl,
                        positionMs = posMs,
                        durationMs = durMs,
                        imdbId = oldReq.imdbId,
                        season = oldReq.season,
                        episode = oldReq.episode,
                        seriesName = oldReq.seriesName,
                        episodeTitle = oldReq.episodeTitle,
                        metaId = oldReq.metaId,
                        // DB v15: persist WHICH stream this position
                        // belongs to, so a later resume re-selects it.
                        streamAddonId = oldReq.sourceId,
                        streamName = oldReq.sourceName,
                        streamTitle = oldReq.streamTitle,
                        streamQuality = oldReq.streamLabel,
                        logo = oldReq.logo,
                        // DB v16 (item 16): persist the episode
                        // list so a resume of this row starts with
                        // its episodes — no fetch needed.
                        episodeIdsJson = com.pulsestream.app.data.encodeEpisodeIds(oldReq.episodes)
                    )
                }
                // #17: positions are keyed by URL — the old source's entry is
                // kept, not deleted, so its progress survives a switch-back.
                // Everything below touches the player or Compose state, so it must
                // run on the main thread no matter which thread called us.
                withContext(Dispatchers.Main) {
                    if (gen != replaceGen.get() || disposed.get()) return@withContext
                    playerError = null
                    mimeHealAttempted = false
                    if (oldReq.type != newReq.type || oldReq.videoId != newReq.videoId || oldReq.liveChannel != newReq.liveChannel) {
                        streamsJob?.cancel()
                        availableStreams = com.pulsestream.app.ui.screens.player.mergePlayerSourceSet(
                            emptyList(), newReq.streams, includeHeadersInIdentity = newReq.isLive && !isTv
                        )
                        attemptedLiveSourceIds = emptySet()
                        attemptedVodSourceUrls = setOf(newReq.streamUrl)
                    }
                    currentRequest = newReq
                    repository.pendingPlayback = newReq
                    resumeOfferMs = null
                    autoplayNext = null // a switch supersedes any armed countdown
                    nextEpisodeSuggestion = null // ...and any standing suggestion
                    // Engine routing (mobile overhaul): resolve the
                    // engine for the NEW source. An MPV play never
                    // touches the Exo rebuild paths below; a switch
                    // back releases the MPV engine first and always
                    // rebuilds Exo fresh (the parked player was
                    // released when MPV took over).
                    val targetEngine = if (newReq.isLive || newReq.isTrailer) {
                        com.pulsestream.app.player.PlaybackEngine.EXO
                    } else {
                        com.pulsestream.app.player.PlaybackEngineResolver.resolve(
                            settings.playbackEngine, newReq
                        )
                    }
                    if (targetEngine == com.pulsestream.app.player.PlaybackEngine.MPV) {
                        if (!mpvActive()) {
                            val parked = player
                            playerView?.player = null
                            runCatching { parked.release() }
                        }
                        activateMpv(newReq, startAtMs, autoplay)
                        showControls = true
                        controlsTick++
                        return@withContext
                    }
                    val fromMpv = mpvActive()
                    if (fromMpv) releaseMpv()
                    // Player audit 2026-10-27 (finding 3): REUSE the running
                    // player when nothing it was BUILT with has to change —
                    // only the media source is swapped, so renderers, codecs
                    // and the surface survive and a switch/retry costs a
                    // rebuffer instead of a full player restart. Safe only
                    // when: same title (type + videoId — an episode change
                    // keeps the rebuild, its per-player listeners/effects are
                    // keyed to the session), not Live (each candidate's
                    // origin/headers are baked into the data-source factory),
                    // identical request headers, and the same merged-audio
                    // shape. Everything else keeps the rebuild below.
                    val reusable = !fromMpv && !oldReq.isLive && !newReq.isLive &&
                        oldReq.type == newReq.type && oldReq.videoId == newReq.videoId &&
                        oldReq.headers == newReq.headers &&
                        oldReq.mergeAudioUrl == newReq.mergeAudioUrl
                    if (reusable) {
                        val carrySubs =
                            newReq.subtitles == oldReq.subtitles && resolvedSubs.isNotEmpty()
                        val carried = if (carrySubs) resolvedSubs else emptyList()
                        old.setMediaSource(buildPlaybackMediaSource(newReq, carried))
                        subsAttached =
                            if (carried.isNotEmpty()) old to subtitleIdentity(carried) else null
                        old.seekTo(startAtMs)
                        old.prepare()
                        old.playWhenReady = autoplay
                        showControls = true
                        controlsTick++
                        return@withContext
                    }
                    // #29: carry already-resolved subtitles (same title) into
                    // the fresh player so the attach effect doesn't re-prepare
                    // the video just to add them back.
                    val carrySubs =
                        newReq.subtitles == oldReq.subtitles && resolvedSubs.isNotEmpty()
                    val carried = if (carrySubs) resolvedSubs else emptyList()
                    val fresh = buildExo(newReq, carried).also { it.addListener(guardedPlayerListener()) }
                    // #16: a fresh player defaults to 1x — re-apply the pill.
                    fresh.setPlaybackSpeed(speed)
                    subsAttached =
                        if (carried.isNotEmpty()) fresh to subtitleIdentity(carried) else null
                    // Detach the surface from the old player before releasing it.
                    playerView?.player = null
                    player = fresh
                    old.release()
                    seekToPlaybackStart(
                        isMobileLive = newReq.isLive && !isTv,
                        startAtMs = startAtMs,
                        seekToPosition = { fresh.seekTo(it) },
                        seekToDefaultPosition = { fresh.seekToDefaultPosition() }
                    )
                    fresh.prepare()
                    fresh.playWhenReady = autoplay
                    showControls = true
                    controlsTick++
                }
            }
        }
    }

    replaceStreamHook = { hookReq, hookStart, hookAutoplay ->
        replaceStream(hookReq, hookStart, hookAutoplay)
    }

    fun switchSource(stream: StreamItem) {
        if (!com.pulsestream.app.data.isPlayableLiveStreamUrl(stream.url)) return
        preemptPendingLiveFallback()
        val mobileLive = currentRequest.isLive && !isTv
        val sameCandidate = if (mobileLive) {
            com.pulsestream.app.data.LivePlaybackPolicy.isSameMobileLiveCandidate(
                currentRequest.streamUrl, currentRequest.headers, stream.url, stream.headers
            )
        } else stream.url == currentRequest.streamUrl
        if (sameCandidate) return
        sourcesOpen = false
        // Item 12: a MANUAL pick is the user's own choice — it
        // clears the "won't play" popup (the picker handed control
        // back). The auto-switch cap is untouched by manual picks.
        streamWontPlayShown = false
        pokeIndicator(
            PlayerIndicator.Message("Source: ${streamQualityLabel(stream) ?: stream.sourceName ?: "switched"}")
        )
        replaceStream(
            currentRequest.copy(
                streamUrl = stream.url,
                headers = stream.headers,
                mimeType = stream.mimeType,
                streamLabel = streamQualityLabel(stream),
                sourceName = stream.sourceName,
                // DB v15: the manual pick becomes the saved stream
                // identity, so a later resume returns to THIS stream.
                sourceId = stream.sourceId,
                streamTitle = stream.title ?: stream.name
            ),
            startAtMs = activePositionMs(),
            autoplay = true
        )
    }

    /**
     * Live TV channel zapping. The Live tab hands the visible channel list
     * over via [StreamRepository.setTvZapList]; zap targets wrap around.
     * M3U channels play directly (the URL is the stream); addon channels
     * re-resolve their stream first.
     */
    val zapChannels: List<TvChannelRef> = repository.pendingTvChannels

    fun canZap(): Boolean =
        currentRequest.isLive && zapChannels.size > 1

    fun zapTo(index: Int) {
        // #9: never start zap work on disposed state (ghost audio).
        if (disposed.get()) return
        val list = zapChannels
        if (list.size < 2) return
        val target = list[index.mod(list.size)]
        // Same channel tapped twice — nothing to do. M3U ids are URLs and
        // videoId holds the URL too, so this covers addon AND M3U channels:
        // double-tap CH+ must not rebuild the player (#19).
        if (target.metaId == currentRequest.videoId &&
            (currentRequest.liveChannel == null || currentRequest.liveChannel == target)) return
        preemptPendingLiveFallback()
        zapping = true
        ioScope.launch {
            try {
                val result = if (target.addonId == "m3u") {
                    com.pulsestream.app.data.StreamResult(
                        listOf(com.pulsestream.app.data.StreamItem(url = target.metaId)), emptyList())
                } else {
                    withTimeoutOrNull(20_000) {
                        repository.liveStreamResultsFlow(target)
                            .firstOrNull { it.streams.any { s -> com.pulsestream.app.data.isPlayableLiveStreamUrl(s.url) } }
                    }
                }
                val playable = result?.streams.orEmpty().filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
                val stream = playable.firstOrNull()
                if (stream == null) {
                    withContext(Dispatchers.Main) {
                        pokeIndicator(PlayerIndicator.Message("No stream for ${target.name}"))
                    }
                    return@launch
                }
                repository.pendingTvIndex = list.indexOf(target)
                withContext(Dispatchers.Main) {
                    pokeIndicator(PlayerIndicator.Message(target.name))
                    replaceStream(
                        currentRequest.copy(
                            streamUrl = stream.url,
                            headers = stream.headers,
                            mimeType = stream.mimeType,
                            title = target.name,
                            poster = target.poster,
                            videoId = target.metaId,
                            type = target.type,
                            liveChannel = target,
                            streamLabel = "LIVE",
                            sourceName = stream.sourceName,
                            streams = playable,
                            subtitles = result?.subtitles.orEmpty()
                        ),
                        startAtMs = 0L,
                        autoplay = true
                    )
                }
            } finally {
                withContext(Dispatchers.Main) { zapping = false }
            }
        }
    }

    fun zapDelta(delta: Int) {
        val list = zapChannels
        if (list.size < 2) return
        zapTo(repository.pendingTvIndex + delta)
    }

    /**
     * Watch Now rework (owner's order 2026-10-28): resolves a PENDING
     * request (blank streamUrl — the user tapped Watch Now while the
     * Detail page's background prefetch was still running) into a
     * concrete stream to auto-play.
     *
     * v0.14.26 (owner's player-fault verdict, 2026-10-31): the WAIT
     * itself — budgets, the confirmation collect, and the rule that
     * "No stream available" is a final state only — lives in
     * [awaitPendingAutoPick], which settles exactly like the Detail
     * loader behind the press-and-hold sheet. The old inline wait
     * capped the resolution at 30 s (below the repository's own 45 s
     * first-party leg budget) and made its first-playable fallback
     * unreachable before full flow completion, so the tap path
     * errored on cold titles the sheet path played. This function now
     * only supplies the pick precedence, identical to the Detail
     * page's: the saved resume stream, then the Settings > Streams
     * autoplay rule (when on), then the Plavio Pick probe — and
     * playback starts with the FIRST stream that pick returns, while
     * the load keeps filling the Sources/failover pool in the
     * background (see the init sequence's background refresh).
     */
    suspend fun resolvePendingAutoPick(req: PlaybackRequest): PlaybackRequest? {
        // Memoised by list size, exactly like the old inline loop:
        // repeat polls against an unchanged set skip the resume lookup
        // and the probe (whose session verdicts are reused anyway).
        var resumeCheckedFor = -1
        var probedFor = -1
        // Debrid hold bookkeeping (owner's order 2026-10-31): the
        // newest FULL snapshot (pending rows included), tracked via
        // the collect below, and when the hold window opened.
        val debridActive =
            com.pulsestream.app.data.debrid.DebridSupport.isActive(settings)
        val latestAll =
            java.util.concurrent.atomic.AtomicReference(req.streams)
        var debridHoldStartedAt = 0L
        val pick = awaitPendingAutoPick(
            initialStreams = req.streams,
            initialSubtitles = req.subtitles,
            openCollect = {
                repository.streamResultsFlow(req.type, req.videoId)
                    .onEach { latestAll.set(it.streams) }
            },
            pickWinner = { playable ->
                // v0.14.33: a snapshot is in hand and the pick is
                // running — the capsule's word follows the real phase.
                loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.PICKING_QUALITY
                var winner: com.pulsestream.app.data.StreamItem? = null
                if (resumeCheckedFor != playable.size) {
                    resumeCheckedFor = playable.size
                    val row = repository.playbackRowFor(
                        req.imdbId, req.season, req.episode, req.videoId
                    )
                    if (row != null && row.positionMs >= 10_000) {
                        winner = repository.matchResumeStream(row, playable)
                    }
                }
                if (winner == null && settings.streamAutoplay) {
                    winner = com.pulsestream.app.ui.components.pickAutoplayStream(playable, settings)
                }
                if (winner == null && !settings.streamAutoplay && probedFor != playable.size) {
                    probedFor = playable.size
                    // No adaptive quality cap on the pick (owner's 2
                    // autoplay rules, 2026-11-02, v0.14.39 — same fix
                    // as orderByAutoplayRules): only the user's size
                    // limit + explicit quality steer the probe.
                    val cap: String? = null
                    winner = com.pulsestream.app.data.StreamProber.findBest(
                        playable, isTv, cap,
                        maxSizeGb = settings.autoplayMaxSizeGb,
                        explicitQuality = settings.autoplayQuality.takeIf { it != "Auto" },
                        preferredLanguage = settings.preferredAudioLanguage
                    )
                }
                // Debrid hold: while the debrid lane still has rows
                // to resolve, a non-debrid winner waits — the cached
                // TorBox stream is about to land and must play first.
                // Bounded at 6 s: after that the best available plays.
                if (winner != null && winner.resolvedInfoHash == null && debridActive &&
                    com.pulsestream.app.data.debrid.DebridSupport.hasPending(latestAll.get())
                ) {
                    if (debridHoldStartedAt == 0L) {
                        debridHoldStartedAt = System.currentTimeMillis()
                    }
                    if (System.currentTimeMillis() - debridHoldStartedAt < 6_000L) {
                        winner = null
                    }
                }
                winner
            },
            isDisposed = { disposed.get() }
        ) ?: return null
        com.pulsestream.app.data.PlaybackHttp.warmUp(pick.stream.url)
        return req.copy(
            streamUrl = pick.stream.url,
            headers = pick.stream.headers,
            mimeType = pick.stream.mimeType,
            streamLabel = streamQualityLabel(pick.stream),
            sourceName = pick.stream.sourceName,
            sourceId = pick.stream.sourceId,
            streamTitle = pick.stream.title ?: pick.stream.name,
            subtitles = pick.subtitles,
            streams = pick.streams
        )
    }

    /** Quietly (re)fills the Sources list in the background, progressively. */
    fun refreshStreamsBackground(type: String, videoId: String) {
        streamsJob?.cancel()
        val requestAtStart = currentRequest
        val liveChannel = requestAtStart.liveChannel
        streamsJob = ioScope.launch {
            streamsLoading = true
            try {
                // v0.14.36 (defect 1): no cache seed — this pool is
                // allowed to settle on its first emission once playback
                // is under way (the v0.14.17 lag fix below), so that
                // emission must be network data. With the seed on, the
                // pool froze on whatever text the session cache held
                // when playback began (e.g. pre-style-change rows) for
                // the whole session.
                val results = if (liveChannel != null) repository.liveStreamResultsFlow(liveChannel, seedFromCache = false)
                    else repository.streamResultsFlow(type, videoId, seedFromCache = false)
                results.collect { result ->
                    if (result.streams.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            if (disposed.get() || currentRequest.type != type || currentRequest.videoId != videoId ||
                                currentRequest.liveChannel != liveChannel) return@withContext
                            val incoming = if (requestAtStart.isLive) result.streams.filter {
                                com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                            } else result.streams
                            val complete = com.pulsestream.app.ui.screens.player.mergePlayerSourceSet(
                                availableStreams, incoming,
                                includeHeadersInIdentity = requestAtStart.isLive && !isTv
                            )
                            // Preserve the original handoff while slow addons and debrid finish.
                            if (complete != availableStreams) {
                                availableStreams = complete
                                hiddenIncompatibleCount = 0
                            }
                        }
                        // v0.14.17 lag fix (audit cause 5): once
                        // playback is under way and the Sources
                        // sheet is closed, one settled emission is
                        // enough — stop collecting so the background
                        // refresh no longer re-merges (and re-parses)
                        // the full list on the main thread while the
                        // video plays. Opening the sheet restarts
                        // the refresh on demand: its open handlers
                        // call this function again.
                        if (hasStartedPlayback && !sourcesOpen) throw StopStreamRefresh()
                    }
                }
            } finally {
                // NonCancellable: a replaced job must still clear the spinner.
                withContext(Dispatchers.Main + NonCancellable) { streamsLoading = false }
            }
        }
    }

    /** Awaits late Live candidates instead of abandoning fallback after an empty first emission. */
    fun awaitMobileLiveFallbackCandidate() {
        if (pendingLiveFallbackJob?.isActive == true) return
        val requestAtStart = currentRequest
        val playerAtStart = player
        val generation = liveFallbackGeneration.incrementAndGet()
        val liveChannel = requestAtStart.liveChannel
        val current = StreamItem(url = requestAtStart.streamUrl, headers = requestAtStart.headers)
        val job = ioScope.launch {
            var selected: StreamItem? = null
            try {
                withTimeoutOrNull(20_000L) {
                    val results = if (liveChannel != null) repository.liveStreamResultsFlow(liveChannel)
                        else repository.streamResultsFlow(requestAtStart.type, requestAtStart.videoId)
                    results.firstOrNull { result ->
                        selected = withContext(Dispatchers.Main) {
                            if (disposed.get() || liveFallbackGeneration.get() != generation ||
                                currentRequest != requestAtStart || player !== playerAtStart) return@withContext null
                            val incoming = result.streams.filter {
                                com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                            }
                            if (incoming.isEmpty()) return@withContext null
                            val merged = com.pulsestream.app.ui.screens.player.mergePlayerSourceSet(
                                availableStreams, incoming, includeHeadersInIdentity = true
                            )
                            if (merged != availableStreams) availableStreams = merged
                            com.pulsestream.app.data.LivePlaybackPolicy.nextUntriedCandidate(
                                merged, current, attemptedLiveSourceIds
                            )?.also { candidate ->
                                attemptedLiveSourceIds = attemptedLiveSourceIds +
                                    com.pulsestream.app.data.LivePlaybackPolicy.candidateIdentity(candidate)
                            }
                        }
                        selected != null
                    }
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // A failed or completed source flow is equivalent to the bounded wait expiring.
            }
            withContext(Dispatchers.Main) {
                if (disposed.get() || liveFallbackGeneration.get() != generation ||
                    currentRequest != requestAtStart || player !== playerAtStart) return@withContext
                if (selected != null) {
                    switchSource(selected!!)
                } else {
                    playerError = "No other sources available"
                    pokeIndicator(PlayerIndicator.Message("No other sources available"))
                }
                pendingLiveFallbackJob = null
            }
        }
        pendingLiveFallbackJob = job
    }

    /** Re-prepares the current stream after a fatal error (#4). */
    fun retryCurrentStream() {
        if (disposed.get()) return
        playerError = null
        ladderTerminal = false
        replaceStream(
            currentRequest,
            startAtMs = activePositionMs().coerceAtLeast(0L),
            autoplay = true
        )
    }

    /**
     * Advances to the next available stream for this title (#4). When there is
     * nothing to advance to, says so and quietly refreshes the Sources list.
     * Returns the stream switched to (null when none), so the failover
     * caller can refund the attempt when the pick was a known corpse.
     */
    fun nextSource(automaticLiveFallback: Boolean = false): com.pulsestream.app.data.StreamItem? {
        val streams = availableStreams.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
        val mobileLive = currentRequest.isLive && !isTv
        val next = if (automaticLiveFallback && mobileLive) {
            val current = StreamItem(url = currentRequest.streamUrl, headers = currentRequest.headers)
            attemptedLiveSourceIds = attemptedLiveSourceIds +
                com.pulsestream.app.data.LivePlaybackPolicy.candidateIdentity(current)
            com.pulsestream.app.data.LivePlaybackPolicy.nextUntriedCandidate(
                streams, current, attemptedLiveSourceIds
            )?.also { candidate ->
                attemptedLiveSourceIds = attemptedLiveSourceIds +
                    com.pulsestream.app.data.LivePlaybackPolicy.candidateIdentity(candidate)
            }
        } else {
            // Stream-skip fix 1 (investigation 2026-10-27): walk by
            // PROBE HEALTH, not blind list order. The old walk took
            // the literal next stream — re-trying sources the
            // prober had already proved dead (426/500/no-response)
            // while healthy ones sat lower, and burned the 3-try
            // cap on corpses. Now: rotate after the current stream,
            // stable-sort by the session verdict (verified alive →
            // unprobed → proven dead), and take the first candidate
            // not yet tried for this title.
            val cur = streams.indexOfFirst {
                it.url == currentRequest.streamUrl && it.headers == currentRequest.headers
            }
            val rotated = when {
                streams.size < 2 -> emptyList()
                cur >= 0 -> streams.drop(cur + 1) + streams.take(cur)
                else -> streams
            }
            // P6 (v0.14.22): failover honours the owner's settings
            // too — probe health first, then the shared autoplay-rule
            // order (quality bucket + size + language tier), so a
            // replacement can't silently exceed the user's caps while
            // a compliant stream sits untried.
            val ruledIndex = com.pulsestream.app.ui.components
                .orderByAutoplayRules(rotated, settings)
                .withIndex().associate { (idx, s) -> s.url to idx }
            rotated
                .sortedWith(
                    compareBy(
                        { com.pulsestream.app.data.StreamProber.failoverRank(it.url) },
                        { ruledIndex[it.url] ?: Int.MAX_VALUE }
                    )
                )
                .firstOrNull { candidate ->
                    candidate.url !in attemptedVodSourceUrls &&
                        (settings.autoplayMaxSizeGb <= 0 ||
                            (com.pulsestream.app.ui.components.streamSizeGb(candidate)
                                ?.let { it <= settings.autoplayMaxSizeGb } ?: true) ||
                            rotated.all { other ->
                                other.url in attemptedVodSourceUrls ||
                                    (com.pulsestream.app.ui.components.streamSizeGb(other)
                                        ?.let { it > settings.autoplayMaxSizeGb } ?: false)
                            })
                }
                ?.also { attemptedVodSourceUrls = attemptedVodSourceUrls + it.url }
        }
        if (next == null) {
            if (automaticLiveFallback && mobileLive) {
                awaitMobileLiveFallbackCandidate()
                return null
            }
            pokeIndicator(PlayerIndicator.Message("No other sources available"))
            refreshStreamsBackground(currentRequest.type, currentRequest.videoId)
            return null
        }
        switchSource(next)
        return next
    }

    // Wire the end-as-error arm now that the helpers exist (item 16):
    // an error in the episode's tail arms the next episode instead of
    // surfacing on the Retry/Source panel.
    armNextEpisodeAtTail = {
        if (isAtEpisodeTail()) armNextEpisodeIfEnded() else false
    }

    // Wire the item-12 auto source switch now that nextSource
    // exists (the ladder helpers above spend the switch through
    // this hook).
    autoSourceSwitchHook = { nextSource() != null }

    // Wire the auto-failover path now that the helpers exist.
    failoverToNextSource = { attempt ->
        val maxAttempts = if (currentRequest.isLive && !isTv)
            com.pulsestream.app.data.LivePlaybackPolicy.MAX_MOBILE_LIVE_FAILOVERS else 3
        val picked = nextSource(automaticLiveFallback = currentRequest.isLive && !isTv)
        // Stream-skip fix 1: a failover that lands on a stream the
        // prober already proved dead does NOT consume the failover
        // cap — the attempt is refunded so healthy candidates lower
        // in the list still get their tries. (The tried-set in
        // nextSource keeps this from looping: each corpse is
        // walked to at most once per title.)
        if (picked != null &&
            com.pulsestream.app.data.StreamProber.isKnownDead(picked.url) &&
            autoFailoverCount > 0
        ) {
            autoFailoverCount--
        }
        pokeIndicator(PlayerIndicator.Message("Trying next source… (${autoFailoverCount}/$maxAttempts)"))
    }

    // A mobile Live source can stall in BUFFERING forever without producing a
    // Media3 error. Bound only first-start recovery: a source that has played
    // once, VOD, TV, or an intentionally paused player is never interrupted.
    LaunchedEffect(player, currentRequest, isTv) {
        if (!currentRequest.isLive || isTv) return@LaunchedEffect
        val watchedPlayer = player
        var waitingSinceMs: Long? = null
        val attemptsAtStart = autoFailoverCount
        val replacementAtStart = replaceGen.get()
        var hasEverPlayed = watchedPlayer.isPlaying
        while (true) {
            if (disposed.get() || watchedPlayer !== latestPlayer.value || currentRequest != latestRequest.value) {
                return@LaunchedEffect
            }
            if (autoFailoverCount != attemptsAtStart || replaceGen.get() != replacementAtStart) {
                return@LaunchedEffect
            }
            hasEverPlayed = hasEverPlayed || watchedPlayer.isPlaying
            if (hasEverPlayed) return@LaunchedEffect
            val state = watchedPlayer.playbackState
            val buffering = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE
            val nowMs = System.nanoTime() / 1_000_000L
            waitingSinceMs = liveStartupWaitingSince(
                waitingSinceMs, nowMs, watchedPlayer.playWhenReady, buffering
            )
            val elapsedMs = waitingSinceMs?.let { nowMs - it } ?: 0L
            if (shouldFailoverStalledLiveStartup(
                    isLive = true,
                    isTv = false,
                    playWhenReady = watchedPlayer.playWhenReady,
                    hasEverPlayed = hasEverPlayed,
                    isBuffering = buffering,
                    elapsedMs = elapsedMs
                )) {
                val maxAttempts = com.pulsestream.app.data.LivePlaybackPolicy.MAX_MOBILE_LIVE_FAILOVERS
                if (autoFailoverCount < maxAttempts) {
                    autoFailoverCount++
                    com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "startup_timeout", elapsedMs)
                    failoverToNextSource?.invoke(autoFailoverCount)
                } else {
                    com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_exhausted", 0)
                    playerError = "Live source did not start"
                }
                return@LaunchedEffect
            }
            delay(500)
        }
    }

    // Recovery after first successful playback: the startup watchdog above deliberately
    // stops once a stream has played. A separate bounded watchdog handles streams that
    // subsequently stall without a Media3 error. It never acts while paused or seeking.
    LaunchedEffect(player, currentRequest, isTv) {
        if (!currentRequest.isLive || isTv) return@LaunchedEffect
        val watchedPlayer = player
        var hasPlayed = watchedPlayer.isPlaying
        var rebufferSinceMs: Long? = null
        while (true) {
            if (disposed.get() || watchedPlayer !== latestPlayer.value || currentRequest != latestRequest.value) {
                return@LaunchedEffect
            }
            hasPlayed = hasPlayed || watchedPlayer.isPlaying
            if (!hasPlayed || !watchedPlayer.playWhenReady || watchedPlayer.playbackState != Player.STATE_BUFFERING) {
                rebufferSinceMs = null
            } else {
                val nowMs = System.nanoTime() / 1_000_000L
                rebufferSinceMs = rebufferSinceMs ?: nowMs
                if (com.pulsestream.app.ui.screens.player.shouldFailoverStalledLiveRebuffer(
                        isLive = currentRequest.isLive,
                        isTv = isTv,
                        playWhenReady = watchedPlayer.playWhenReady,
                        hasEverPlayed = hasPlayed,
                        isBuffering = watchedPlayer.playbackState == Player.STATE_BUFFERING,
                        elapsedMs = nowMs - rebufferSinceMs!!
                    )) {
                    val maxRecoveries = 2
                    if (liveRebufferRecoveries < maxRecoveries) {
                        liveRebufferRecoveries++
                        com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "rebuffer_timeout", nowMs - rebufferSinceMs!!)
                        pokeIndicator(PlayerIndicator.Message("Live stream stalled — trying another source…"))
                        nextSource(automaticLiveFallback = true)
                    } else {
                        com.pulsestream.app.data.SourceDiagnostics.record("Live playback", "fallback_exhausted", nowMs - rebufferSinceMs!!)
                        playerError = "Live stream stopped responding. Try Retry or choose another source."
                    }
                    return@LaunchedEffect
                }
            }
            delay(500)
        }
    }

    // VOD stall watchdog (owner's player round, 2026-10-23): a movie/episode
    // source that never starts, or freezes mid-play with no position
    // progress — hosts that ignore byte-range requests behave exactly like
    // this — fails over to the next source instead of spinning forever.
    // Bounded by the same generic failover cap as playback errors (3).
    // Startup runs the TV two-part model since v0.14.14 (item 7:
    // 30 s first-frame deadline + 15 s zero-data early failover, see
    // shouldFailoverVodStartup); the mid-play rebuffer rule below is
    // the audited 2026-10-27 one, unchanged.
    LaunchedEffect(player, currentRequest, isTv) {
        if (currentRequest.isLive) return@LaunchedEffect
        val watchedPlayer = player
        val replacementAtStart = replaceGen.get()
        var hasPlayed = watchedPlayer.isPlaying
        var lastPositionMs = -1L
        // Player audit 2026-10-27 (finding 4): the failover budget is spent
        // only by continuous ZERO forward progress. ANY playhead movement —
        // even a few hundred ms of trickle — resets the clock, so a
        // slow-but-alive stream is never abandoned mid-play. (Previously
        // progress required >1 s of movement and the clock ran on a 3 s
        // sub-window, which could discard a stream that was still creeping.)
        var lastProgressAtMs = System.nanoTime() / 1_000_000L
        // TV-model startup trackers (v0.14.14, item 7): DATA arrival
        // (the player's buffered position advancing) and accumulated
        // TRYING time (playWhenReady stretches only — paused time
        // burns neither startup clock). Both live only until the
        // first frame; the rebuffer rule below is untouched.
        var lastBufferedPosMs = -1L
        var lastDataAtMs = lastProgressAtMs
        var tryingSinceMs: Long? = null
        var tryingAccumMs = 0L
        while (true) {
            if (disposed.get() || watchedPlayer !== latestPlayer.value ||
                currentRequest != latestRequest.value || replaceGen.get() != replacementAtStart
            ) {
                return@LaunchedEffect
            }
            hasPlayed = hasPlayed || watchedPlayer.isPlaying
            val nowMs = System.nanoTime() / 1_000_000L
            val posMs = runCatching { watchedPlayer.currentPosition }.getOrDefault(0L)
            if (lastPositionMs < 0L || posMs > lastPositionMs) {
                lastPositionMs = posMs
                lastProgressAtMs = nowMs
            }
            // Data signal: any advance of the buffered position is
            // bytes arriving, even before the playhead can move.
            val bufferedPosMs = runCatching { watchedPlayer.bufferedPosition }.getOrDefault(0L)
            if (lastBufferedPosMs < 0L) {
                lastBufferedPosMs = bufferedPosMs
            } else if (bufferedPosMs > lastBufferedPosMs) {
                lastBufferedPosMs = bufferedPosMs
                lastDataAtMs = nowMs
            }
            if (!watchedPlayer.playWhenReady) lastDataAtMs = nowMs
            // Accumulated trying time for the first-frame deadline.
            val tryingElapsedMs = if (!hasPlayed) {
                if (watchedPlayer.playWhenReady) {
                    val since = tryingSinceMs ?: nowMs.also { tryingSinceMs = it }
                    tryingAccumMs + (nowMs - since)
                } else {
                    tryingSinceMs?.let { tryingAccumMs += nowMs - it }
                    tryingSinceMs = null
                    tryingAccumMs
                }
            } else 0L
            val buffering = watchedPlayer.playbackState == Player.STATE_BUFFERING ||
                watchedPlayer.playbackState == Player.STATE_IDLE
            val noProgressMs = nowMs - lastProgressAtMs
            val progressed = noProgressMs < 3_000L
            // Elapsed for the policy = the continuous zero-progress stretch,
            // counted only while the player is actually trying to buffer.
            val elapsedMs = if (watchedPlayer.playWhenReady && buffering) noProgressMs else 0L
            // Startup (TV model, item 7): the two-part rule replaces
            // the old 45 s trickle-reset startup clock (and its 15 s
            // host-marked-dead shortcut — a dead host delivers no
            // data, so the no-data arm catches it sooner anyway).
            // AFTER the first frame, ONLY the audited rebuffer rule
            // runs, with its exact old values (60 s, progress resets).
            val startupDead = com.pulsestream.app.ui.screens.player.shouldFailoverVodStartup(
                isLive = false,
                playWhenReady = watchedPlayer.playWhenReady,
                hasEverPlayed = hasPlayed,
                tryingElapsedMs = tryingElapsedMs,
                noDataElapsedMs = nowMs - lastDataAtMs
            )
            val failoverElapsedMs = if (startupDead) tryingElapsedMs else elapsedMs
            if (startupDead || (hasPlayed &&
                com.pulsestream.app.ui.screens.player.shouldFailoverStalledVod(
                    isLive = false,
                    playWhenReady = watchedPlayer.playWhenReady,
                    hasEverPlayed = true,
                    isBuffering = buffering,
                    positionProgressed = progressed,
                    elapsedMs = elapsedMs
                ))) {
                // Item 16 (end-as-error): a stall in the episode's
                // TAIL is the episode ending badly, not a dead source
                // worth failing over — arm the next-episode
                // suggestion/countdown instead of grinding through
                // failovers that re-attempt the same tail, and never
                // terminate on the stall error panel here.
                if (isAtEpisodeTail() && armNextEpisodeIfEnded()) {
                    return@LaunchedEffect
                }
                // Item 12 (v0.14.26): full patience exhausted on
                // this source (90 s first-frame / 60 s no-data at
                // startup; the 60 s zero-progress rebuffer budget
                // mid-play) — the source stands CONFIRMED DEAD, so
                // this is where the play's ONE auto source switch
                // may be spent. If it was already spent, the second
                // stream is dead too: stop and show the popup. (The
                // old cap of 3 auto failovers is superseded by the
                // owner's exactly-once rule.)
                if (autoSourceSwitchesUsed < 1) {
                    autoSourceSwitchesUsed++
                    com.pulsestream.app.data.SourceDiagnostics.record("VOD playback", "stall_timeout", failoverElapsedMs)
                    // Feedback: the replacement of this attempt is a
                    // stall death, not a user cancellation.
                    feedbackTracker.markStallFailover()
                    val picked = nextSource()
                    if (picked == null) {
                        streamWontPlayShown = true
                        showControls = true
                        controlsTick++
                    }
                } else {
                    com.pulsestream.app.data.SourceDiagnostics.record("VOD playback", "fallback_exhausted", failoverElapsedMs)
                    // Feedback: zero progress for the full budget is
                    // a timeout death by the watchdog's own evidence.
                    feedbackTracker.onAttemptError(
                        com.pulsestream.app.data.FeedbackSupport.RawError(
                            com.pulsestream.app.data.FeedbackSupport.ErrorFamily.NETWORK_TIMEOUT,
                            httpStatus = null,
                            causeKinds = emptySet()
                        )
                    )
                    streamWontPlayShown = true
                    showControls = true
                    controlsTick++
                }
                return@LaunchedEffect
            }
            delay(500)
        }
    }

    fun playEpisode(video: Video) {
        // #9: never start episode work on disposed state (ghost audio).
        if (disposed.get()) return
        episodesOpen = false
        switchingMedia = true
        ioScope.launch {
            val type = currentRequest.type
            // Sticky source (owner's order 2026-10-27): the next
            // episode should start on the SAME source the user just
            // watched, in the same quality lane when possible. Keep
            // collecting merged results until the previous source has
            // answered for this episode (or the flow completes), then
            // prefer: same source + same quality lane → same source →
            // first playable overall.
            val prevSource = currentRequest.sourceName
            val prevSourceId = currentRequest.sourceId
            val prevLane = currentRequest.streamLabel
            var latestResult: com.pulsestream.app.data.StreamResult? = null
            withTimeoutOrNull(20_000) {
                repository.streamResultsFlow(type, video.id)
                    .onEach { res ->
                        if (res.streams.any { s -> com.pulsestream.app.data.isPlayableLiveStreamUrl(s.url) }) {
                            latestResult = res
                        }
                    }
                    .firstOrNull { res ->
                        prevSource != null && res.streams.any { s ->
                            com.pulsestream.app.data.isPlayableLiveStreamUrl(s.url) &&
                                (s.sourceName ?: s.name) == prevSource
                        }
                    }
            }
            val result = latestResult
            // Back to the main thread: everything below touches Compose state.
            withContext(Dispatchers.Main) {
                val (playableStreams, hidden) = result?.streams?.let { ( it to 0 ) } ?: (emptyList<com.pulsestream.app.data.StreamItem>() to 0)
                val playable = playableStreams.filter { com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url) }
                // One mechanism with the resume fix (DB v15): the
                // identity saved with playback IS the sticky source —
                // prefer the same addon id first, then the same
                // source name, each in the same quality lane first.
                val stream = playable.firstOrNull { s ->
                        prevSourceId != null && s.sourceId == prevSourceId &&
                            streamQualityLabel(s) == prevLane
                    }
                    ?: playable.firstOrNull { s ->
                        prevSourceId != null && s.sourceId == prevSourceId
                    }
                    ?: playable.firstOrNull { s ->
                        prevSource != null && (s.sourceName ?: s.name) == prevSource &&
                            streamQualityLabel(s) == prevLane
                    }
                    ?: playable.firstOrNull { s ->
                        prevSource != null && (s.sourceName ?: s.name) == prevSource
                    }
                    // Final fallback (v0.14.14, item 6): the two-tier
                    // autoplay rule, same as every other entry point —
                    // the Settings stream rule decides first; only with
                    // no rule set does the best stream at the highest
                    // quality win. (Was a bare firstOrNull, which could
                    // start the next episode on any lane at all.)
                    ?: com.pulsestream.app.ui.components.pickAutoplayStream(playable, settings)
                if (stream == null) {
                    pokeIndicator(PlayerIndicator.Message("No sources found for this episode"))
                } else {
                    val showName = currentRequest.seriesName ?: currentRequest.title
                    availableStreams = playableStreams
                    hiddenIncompatibleCount = hidden
                    replaceStream(
                        currentRequest.copy(
                            streamUrl = stream.url,
                            headers = stream.headers,
                            mimeType = stream.mimeType,
                            title = "$showName S${video.season}E${video.episode}",
                            poster = video.thumbnail ?: currentRequest.poster,
                            background = video.thumbnail ?: currentRequest.background,
                            videoId = video.id,
                            subtitles = result?.subtitles ?: emptyList(),
                            season = video.season,
                            episode = video.episode,
                            episodeTitle = video.title,
                            streamLabel = streamQualityLabel(stream),
                            sourceName = stream.sourceName,
                            sourceId = stream.sourceId,
                            streamTitle = stream.title ?: stream.name,
                            streams = result?.streams ?: emptyList()
                        ),
                        startAtMs = 0L,
                        autoplay = true
                    )
                }
                switchingMedia = false
            }
        }
    }

    // Auto-select a freshly added subtitle track once ExoPlayer exposes it.
    LaunchedEffect(addedSubs.size) {
        val sub = addedSubs.lastOrNull() ?: return@LaunchedEffect
        repeat(15) {
            val group = player.currentTracks.groups.firstOrNull { g ->
                g.type == C.TRACK_TYPE_TEXT &&
                    (0 until g.length).any { i -> g.getTrackFormat(i).id == sub.url }
            }
            if (group != null) {
                val idx = (0 until group.length).first { i -> group.getTrackFormat(i).id == sub.url }
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(idx)))
                    .build()
                trackTick++
                return@LaunchedEffect
            }
            delay(300)
        }
    }

    /**
     * Full gesture set for the video surface in ONE pointerInput handler:
     * tap (toggle controls), double-tap (±10s seek), directional drags
     * (seek / volume / brightness) and hold-for-speed with slide steps.
     *
     * v0.12.1 regression fix: v0.12.0 stacked THREE separate detectors
     * (tap + a second detectTapGestures for the hold + drag) on this same
     * node. Concurrent detectors share PointerInputChange consumption, so
     * the tap detector's wait-for-up was cancelled by its siblings on every
     * tap — controls never appeared and every control (incl. Back) was
     * unreachable; only the hold still fired. A single unified state
     * machine removes that whole class of interference: nothing else on
     * this node consumes pointer changes.
     *
     * Hold-for-speed (GitHub issue #2 + owner's slide extension): a press
     * held ~350ms without dragging engages 2x; while still holding, each
     * ~60dp of rightward slide steps up (2x → 3x → 4x → max 5x), sliding
     * left steps back down (floor 2x). Release restores the exact speed
     * that was playing before the hold. Disabled while locked (tap only
     * shows the locked hint, as before).
     */
    fun Modifier.videoGestures(): Modifier = this.pointerInput(player, locked) {
        if (locked) {
            detectTapGestures(onTap = {
                pokeIndicator(PlayerIndicator.Message("Locked — tap the lock icon to unlock"))
            })
            return@pointerInput
        }
        var lastTapUpMs = 0L
        var pendingToggle: Job? = null
        awaitEachGesture {
            val down = awaitFirstDown()
            val downPos = down.position
            val downTime = down.uptimeMillis
            // Normal-rhythm activation (v0.14.26, batch item 7): a
            // second DOWN inside the double-tap window IS the
            // double-tap — fire the seek immediately on the press
            // instead of waiting for the second release, which made
            // the gesture feel like it only answered slow or
            // coaxed taps. This gesture's release then settles as a
            // no-op (see the dragMode == -1 branch below).
            var seekFiredThisGesture = false
            if (lastTapUpMs != 0L &&
                downTime - lastTapUpMs <= viewConfiguration.doubleTapTimeoutMillis
            ) {
                pendingToggle?.cancel()
                pendingToggle = null
                lastTapUpMs = 0L
                seekFiredThisGesture = true
                if (downPos.x < size.width / 2f) doubleTapSeek(forward = false)
                else doubleTapSeek(forward = true)
            }
            val slop = viewConfiguration.touchSlop
            val stepPx = 60.dp.toPx()
            val holdThresholdMs = 350L
            var lastEventMs = downTime
            var lastPos = downPos
            var accX = 0f
            var accY = 0f
            // Drag state (same semantics as the old drag detector):
            // -1 undecided, 0 = seek, 1 = volume, 2 = brightness.
            var dragMode = -1
            var seekBase = 0L
            var seekTarget = -1L
            var volBase = 0f
            var brightBase = 0.5f
            // Hold state.
            var holdEngaged = false
            var prevSpeed = 1f
            var slideBaseX = 0f
            var upChange: androidx.compose.ui.input.pointer.PointerInputChange? = null

            while (upChange == null) {
                val event = if (!holdEngaged && dragMode == -1) {
                    // Still a tap/hold candidate: wake up at the hold
                    // threshold even if no further pointer event arrives.
                    val remaining = (downTime + holdThresholdMs - lastEventMs).coerceAtLeast(0L)
                    withTimeoutOrNull(remaining) { awaitPointerEvent() }
                } else {
                    awaitPointerEvent()
                }
                if (event == null) {
                    // Threshold reached with the finger still down and no
                    // drag in progress: engage the speed hold.
                    holdEngaged = true
                    prevSpeed = speed
                    slideBaseX = accX
                    holdSpeedStep = 2
                    if (mpvActive()) {
                        mpvEngine?.setSpeed(2f)
                    } else {
                        runCatching { player.setPlaybackSpeed(2f) }
                    }
                    holdSpeedActive = true
                    continue
                }
                val change = event.changes.firstOrNull { it.id == down.id } ?: continue
                lastEventMs = change.uptimeMillis
                if (!change.pressed) {
                    // Pointer went up (Compose 1.7 no longer distinguishes
                    // a system cancel here — it also arrives as !pressed).
                    upChange = change
                    break
                }
                val delta = change.position - lastPos
                lastPos = change.position
                accX += delta.x
                accY += delta.y
                if (holdEngaged) {
                    // Slide right = step up, left = step down (floor 2x).
                    val step = 2 + ((accX - slideBaseX) / stepPx).toInt().coerceIn(0, 3)
                    if (step != holdSpeedStep) {
                        holdSpeedStep = step
                        if (mpvActive()) {
                            mpvEngine?.setSpeed(step.toFloat())
                        } else {
                            runCatching { player.setPlaybackSpeed(step.toFloat()) }
                        }
                    }
                } else {
                    if (dragMode == -1 && (abs(accX) > slop || abs(accY) > slop)) {
                        dragMode = if (abs(accX) > abs(accY)) 0
                        else if (downPos.x < size.width / 2f) 2 else 1
                        if (dragMode == 0) scrubbing = true
                        seekBase = activePositionMs()
                        seekTarget = -1L
                        volBase = displayVolumePercent().toFloat()
                        brightBase = activity?.window?.attributes
                            ?.screenBrightness?.takeIf { it >= 0 } ?: 0.5f
                    }
                    if (dragMode != -1) {
                        change.consume()
                        when (dragMode) {
                            0 -> { // horizontal swipe: seek, scaled by content duration
                                val dur = activeDurationMs()
                                if (dur > 0) {
                                    // Duration-scaled scrubbing (mobile
                                    // overhaul): a full-width swipe spans
                                    // 60 s of content under 30 min, 90 s
                                    // for 30–60 min, 120 s beyond that —
                                    // instead of the whole runtime, which
                                    // made small swipes jump minutes.
                                    val spanMs = when {
                                        dur < 30 * 60_000L -> 60_000L
                                        dur < 60 * 60_000L -> 90_000L
                                        else -> 120_000L
                                    }
                                    seekTarget = (seekBase + accX / size.width * spanMs)
                                        .toLong().coerceIn(0L, dur)
                                    val deltaMs = seekTarget - activePositionMs()
                                    // Slide-seek readout (v0.14.16,
                                    // owner's order): the jump in
                                    // plain units, live while sliding,
                                    // with the landing time under it.
                                    pokeIndicator(
                                        PlayerIndicator.Seek(
                                            text = seekJumpLabel(deltaMs),
                                            subtext = "→ ${formatMs(seekTarget)}"
                                        )
                                    )
                                }
                            }
                            1 -> { // vertical swipe, right half: volume (+ boost past max)
                                // Total range 0..200%: 0..100 drives the system
                                // volume; past 100 the system stays at max and
                                // the boost takes over. Swiping back down drains
                                // the boost first, then the system volume.
                                val total = (volBase - accY / size.height * 200f)
                                    .coerceIn(0f, 200f)
                                if (total >= 100f) {
                                    audioManager.setStreamVolume(
                                        AudioManager.STREAM_MUSIC, maxVolume, 0
                                    )
                                    volumeBoost = (total - 100f) / 100f
                                } else {
                                    volumeBoost = 0f
                                    val v = (total / 100f * maxVolume)
                                        .roundToInt().coerceIn(0, maxVolume)
                                    audioManager.setStreamVolume(
                                        AudioManager.STREAM_MUSIC, v, 0
                                    )
                                }
                                applyVolumeBoost()
                                volumePercent = displayVolumePercent()
                                pokeIndicator(PlayerIndicator.Volume(volumePercent))
                            }
                            2 -> { // vertical swipe, left half: brightness
                                val b = (brightBase - accY / size.height).coerceIn(0.01f, 1f)
                                activity?.window?.let { w ->
                                    val lp = w.attributes
                                    lp.screenBrightness = b
                                    w.attributes = lp
                                }
                                pokeIndicator(PlayerIndicator.Brightness((b * 100).toInt()))
                            }
                        }
                    }
                }
            }

            // Gesture finished — settle the outcome.
            scrubbing = false
            when {
                holdEngaged -> {
                    holdSpeedActive = false
                    if (mpvActive()) {
                        mpvEngine?.setSpeed(prevSpeed)
                    } else {
                        runCatching { player.setPlaybackSpeed(prevSpeed) }
                    }
                }
                dragMode == 0 -> {
                    if (seekTarget >= 0) guardedSeekTo(seekTarget)
                }
                dragMode == -1 -> {
                    // The seek already fired on this gesture's DOWN
                    // (item 7): its release settles quietly — no
                    // toggle, no second seek. The release time is
                    // still recorded as the last tap, so a third,
                    // fourth… tap at the same rhythm keeps pairing
                    // and the accumulation keeps building.
                    if (seekFiredThisGesture) {
                        lastTapUpMs = upChange?.uptimeMillis ?: downTime
                        return@awaitEachGesture
                    }
                    // A tap: a second tap inside the double-tap window
                    // seeks ±10s by side (accumulating — see
                    // doubleTapSeek); a lone tap toggles the controls
                    // once the window expires (same timing as the old
                    // detectTapGestures behaviour).
                    val now = upChange?.uptimeMillis ?: downTime
                    val window = viewConfiguration.doubleTapTimeoutMillis
                    if (lastTapUpMs != 0L && now - lastTapUpMs <= window) {
                        pendingToggle?.cancel()
                        pendingToggle = null
                        lastTapUpMs = 0L
                        if (downPos.x < size.width / 2f) doubleTapSeek(forward = false)
                        else doubleTapSeek(forward = true)
                    } else {
                        lastTapUpMs = now
                        pendingToggle = gestureUiScope.launch {
                            delay(window.toLong())
                            toggleControls()
                        }
                    }
                }
            }
        }
    }

    /** Tap-only gestures for the controls overlay (slider drags stay clean). */
    fun Modifier.tapGestures(): Modifier = this.pointerInput(player, locked) {
        detectTapGestures(
            onTap = {
                if (locked) pokeIndicator(PlayerIndicator.Message("Locked — tap the lock icon to unlock"))
                else toggleControls()
            },
            onDoubleTap = { offset ->
                if (!locked) {
                    if (offset.x < size.width / 2f) doubleTapSeek(forward = false)
                    else doubleTapSeek(forward = true)
                }
            }
        )
    }

    fun savePosition() {
        // v0.14.24 crash fix: ExoPlayer state may only be read on
        // the main thread. Any off-main caller (the seek flush used
        // to run on Dispatchers.IO) is re-posted to main and
        // returns; the snapshot below then runs where the player
        // lives, and only the database write goes to IO.
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            mainHandler.post { savePosition() }
            return
        }
        val pl: Player = latestPlayer.value
        val req = latestRequest.value
        // #8: live TV never enters Continue Watching.
        if (req.isLive) return
        // Trailers never enter Continue Watching either.
        if (req.isTrailer) return
        // The position comes from the ACTIVE engine (overhaul): under
        // MPV the parked ExoPlayer's position is meaningless.
        val pos = if (mpvActive()) {
            mpvEngine?.snapshot?.value?.positionMs ?: 0L
        } else {
            pl.currentPosition
        }
        val dur = if (mpvActive()) {
            mpvEngine?.snapshot?.value?.durationMs?.takeIf { it > 0 } ?: C.TIME_UNSET
        } else {
            pl.duration.takeIf { it > 0 } ?: C.TIME_UNSET
        }
        // NonCancellable: onDispose cancels ioScope's children (#9) and must
        // not kill this final save.
        ioScope.launch(NonCancellable) {
            repository.savePlayback(
                title = req.title,
                poster = req.poster,
                videoId = req.videoId,
                streamUrl = req.streamUrl,
                positionMs = pos,
                durationMs = if (dur == C.TIME_UNSET) 0L else dur,
                imdbId = req.imdbId,
                season = req.season,
                episode = req.episode,
                // Series context (owner's bug report 2026-10-27): a
                // resume must rebuild the SAME player a fresh play
                // builds — episode title, series name and meta id are
                // persisted so Continue Watching can hand them back.
                seriesName = req.seriesName,
                episodeTitle = req.episodeTitle,
                metaId = req.metaId,
                // DB v15: persist WHICH stream this position belongs
                // to, so a Continue Watching resume re-selects it
                // instead of re-running the auto-pick (owner's
                // v0.14.7-test report: resume played the 1st stream,
                // he had been watching the 7th).
                streamAddonId = req.sourceId,
                streamName = req.sourceName,
                streamTitle = req.streamTitle,
                streamQuality = req.streamLabel,
                logo = req.logo,
                // DB v16 (item 16): see the replaceStream save.
                episodeIdsJson = com.pulsestream.app.data.encodeEpisodeIds(req.episodes)
            )
            // CW widget (v0.14.13, item 10): the row just changed.
            com.pulsestream.app.ui.widget.CwWidgetUpdater.refresh(context)
        }
    }

    // Keep the second engine's subtitle style in step with the shared
    // style store: every write path (Style rail, TB popover, the
    // Settings screen) funnels through these snapshot states.
    LaunchedEffect(
        settings.subtitleTextColor, settings.subtitleBackgroundColor,
        settings.subtitleEdgeType, settings.subtitleEdgeColor,
        settings.subtitleFontSizeSp, settings.subtitleBold,
        settings.subtitleBottomOffset, activeEngine
    ) {
        if (mpvActive()) applyMpvSubtitleStyle()
    }

    // Progress-save rhythm (mobile overhaul): the poll loop ticks a
    // save every 60 s of playback; pause / seek (debounced, see
    // scheduleSeekProgressSave) / end / exit flush through the same
    // path. Before the overhaul only exit + backgrounding saved, so
    // a crash mid-play lost the whole session.
    savePositionHook = { savePosition() }
    var lastProgressSaveAtMs by remember { mutableLongStateOf(0L) }
    var endFlushSavedFor by remember { mutableStateOf<String?>(null) }

    fun maybePeriodicProgressSave() {
        val now = System.currentTimeMillis()
        if (now - lastProgressSaveAtMs >= 60_000L && activePositionMs() > 10_000L) {
            lastProgressSaveAtMs = now
            savePosition()
        }
    }

    /** End-of-playback flush: once per video, when the end is reached. */
    fun flushProgressAtEnd() {
        val key = currentRequest.videoId
        if (endFlushSavedFor == key) return
        endFlushSavedFor = key
        savePosition()
    }

    // Poll position / duration / playing / buffering / volume for the UI,
    // and track the active skip-segment window.
    /** videoId a percent-progress start seek was already applied to (item 13). */
    var progressSeekAppliedFor by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(player, activeEngine) {
        while (true) {
            // Second-engine branch (mobile overhaul): the UI state is
            // fed from the MPV snapshot; the Exo-specific machinery
            // below (seek-snap verification, audio-session boost,
            // percent-resume) does not apply to it.
            if (mpvActive()) {
                val engine = mpvEngine
                val snap = engine?.snapshot?.value
                if (engine != null && snap != null) {
                    positionMs = snap.positionMs
                    durationMs = snap.durationMs
                    isPlaying = !snap.paused && snap.fileLoaded
                    if (isPlaying) {
                        hasStartedPlayback = true
                        resumeBuffering = false
                    }
                    isBuffering = !snap.fileLoaded || snap.buffering
                    if (snap.videoWidth > 0 && snap.videoHeight > 0) {
                        MainActivity.pipVideoW = snap.videoWidth
                        MainActivity.pipVideoH = snap.videoHeight
                    }
                    feedbackTracker.onTick(
                        isPlaying = isPlaying,
                        ended = snap.eofReached,
                        nowMs = System.currentTimeMillis()
                    )
                    volumePercent = displayVolumePercent()
                    activeSegment = if (settings.showSkipButton) {
                        skipSegments.firstOrNull {
                            positionMs >= it.startMs && positionMs <= it.endMs
                        }
                    } else null
                    if (snap.eofReached &&
                        !currentRequest.isMovie &&
                        !currentRequest.isTrailer &&
                        !currentRequest.isLive &&
                        endedHandledFor != currentRequest.videoId
                    ) {
                        armNextEpisodeIfEnded()
                        flushProgressAtEnd()
                    }
                    if (!currentRequest.isTrailer) {
                        scrobbler.tick(
                            currentRequest,
                            positionMs,
                            durationMs,
                            isPlaying,
                            snap.eofReached
                        )
                    }
                    maybePeriodicProgressSave()
                }
                delay(500)
                continue
            }
            val c = player
            positionMs = c.currentPosition
            durationMs = c.duration.takeIf { it > 0 } ?: 0L
            isPlaying = c.isPlaying
            if (c.isPlaying) {
                hasStartedPlayback = true
                resumeBuffering = false
            }
            // Feedback heartbeat: real playing time only (the tracker
            // ignores paused/buffering ticks), plus the ENDED edge.
            feedbackTracker.onTick(
                isPlaying = c.isPlaying,
                ended = c.playbackState == Player.STATE_ENDED,
                nowMs = System.currentTimeMillis()
            )
            isBuffering = c.playbackState == Player.STATE_BUFFERING ||
                c.playbackState == Player.STATE_IDLE
            volumePercent = displayVolumePercent()
            // Percent-only resume (notes item 13): an imported
            // Continue Watching entry can carry a progress fraction
            // instead of an absolute position (its runtime was
            // unknown at import). Seek once, as soon as the real
            // duration is known and playback is still at the start.
            val pct = currentRequest.startAtProgressPct
            if (pct != null && durationMs > 0 &&
                progressSeekAppliedFor != currentRequest.videoId
            ) {
                progressSeekAppliedFor = currentRequest.videoId
                if (c.currentPosition < 1_000) {
                    runCatching { c.seekTo((pct * durationMs).toLong()) }
                }
            }
            // Seek-snap verification (item 5, 2026-10-28): ~1.5 s
            // after a far seek, check once where playback actually
            // landed. Conservative by construction: it only judges
            // when the SAME video/stream is playing or buffering
            // normally — an ended episode, an error panel, or a
            // switch underneath the seek all just retire the check
            // silently, and a position anywhere near the target (or
            // anywhere past the start zone) clears it as honoured.
            if (pendingSeekVerifyTargetMs >= 0L) {
                val vTarget = pendingSeekVerifyTargetMs
                val vReq = currentRequest
                when {
                    vReq.videoId != pendingSeekVerifyVideoId ||
                        vReq.streamUrl != pendingSeekVerifyStreamUrl ->
                        clearPendingSeekVerify()
                    c.playbackState == Player.STATE_ENDED || playerError != null ->
                        clearPendingSeekVerify()
                    System.currentTimeMillis() - pendingSeekVerifyAtMs >= 1_500L &&
                        (c.playbackState == Player.STATE_READY ||
                            c.playbackState == Player.STATE_BUFFERING) -> {
                        val landedMs = c.currentPosition
                        if (landedMs < 5_000L || landedMs < vTarget - 30_000L) {
                            // The host ignored the seek and restarted
                            // the file: tell the user, and guard this
                            // host's seeks for the rest of the session.
                            streamHostOf(vReq.streamUrl)?.let { host ->
                                sessionUnseekableHosts = sessionUnseekableHosts + host
                                // Persist it (v0.14.15): the guard then
                                // holds from the first seek of every
                                // future session on this host.
                                settings.unseekableHosts =
                                    settings.unseekableHosts + host
                            }
                            pokeIndicator(
                                PlayerIndicator.Message("This source doesn't support seeking")
                            )
                        }
                        clearPendingSeekVerify()
                    }
                }
            }
            // A rebuilt player (source/episode switch) has a new audio
            // session — re-attach the boost enhancer to it.
            if (volumeBoost > 0f) applyVolumeBoost()
            activeSegment = if (settings.showSkipButton) {
                skipSegments.firstOrNull { positionMs >= it.startMs && positionMs <= it.endMs }
            } else null
            // Next episode at the end (notes item 16): the
            // SUGGESTION now arms whenever an episode ends and a
            // next episode exists — the Auto-play setting gates
            // only the 10 s countdown on top of it. (Before, the
            // setting gated the whole block: with it off — or the
            // episode list missing, see below — the episode ended
            // in total silence, the owner's exact complaint.)
            if (c.playbackState == Player.STATE_ENDED &&
                !currentRequest.isMovie &&
                !currentRequest.isTrailer &&
                !currentRequest.isLive &&
                endedHandledFor != currentRequest.videoId
            ) {
                // Shared arm evaluation (item 16): the same call the
                // error listener and the stall watchdog make when an
                // episode ends as an error/stall at the tail. When the
                // episode list isn't restored yet (a resumed session
                // whose backfill is still working) this returns false
                // WITHOUT marking the end handled — when the list
                // lands, this same poll re-evaluates and arms then.
                armNextEpisodeIfEnded()
                // End flush (overhaul): reaching the end persists the
                // final position now (savePlayback's <30 s-remaining
                // rule then retires the row as finished).
                flushProgressAtEnd()
            }
            if (c.playbackState == Player.STATE_ENDED) {
                flushProgressAtEnd()
            }
            // Seeking back into the finished episode retires its
            // next-episode suggestion (item 16) — the user chose to
            // stay with this episode.
            if (c.playbackState != Player.STATE_ENDED && autoplayNext == null &&
                nextEpisodeSuggestion != null && durationMs > 0 &&
                positionMs < durationMs - 5_000
            ) {
                nextEpisodeSuggestion = null
            }
            if (!currentRequest.isTrailer) {
                scrobbler.tick(
                    currentRequest,
                    positionMs,
                    durationMs,
                    isPlaying,
                    c.playbackState == Player.STATE_ENDED
                )
            }
            maybePeriodicProgressSave()
            delay(if (isTv) 1000 else 500) // low-end TVs: half the recompositions
        }
    }

    // Autoplay-next countdown driver (finding 8): ticks 10 → 0 with the
    // countdown pill on screen, then hands over to the next episode.
    // Cancellation is by setting autoplayNext = null (any interaction does);
    // a request change underneath it (manual switch) aborts it too.
    LaunchedEffect(autoplayNext) {
        val next = autoplayNext ?: return@LaunchedEffect
        val armedFor = autoplayArmedFor
        autoplayCountdownSec = 10
        while (autoplayCountdownSec > 0) {
            delay(1_000)
            if (disposed.get() || autoplayNext !== next ||
                latestRequest.value.videoId != armedFor
            ) {
                autoplayCountdownSec = 0
                return@LaunchedEffect
            }
            autoplayCountdownSec--
        }
        autoplayNext = null
        playEpisode(next)
    }

    // Auto-hide controls and indicators (mobile overhaul gate):
    // 3.5 s, and ONLY while actually playing — never while paused,
    // buffering, scrubbing, on the error screen, or with a panel /
    // menu / dialog open over the video.
    val anyPanelOpen = tracksOpen || sourcesOpen || episodesOpen || subSearchOpen ||
        speedMenuOpen || sleepMenuOpen || resumeOfferMs != null ||
        downloadStream != null || externalWarningReq != null
    LaunchedEffect(
        showControls, controlsTick, isPlaying, isBuffering, scrubbing,
        playerError, anyPanelOpen, locked
    ) {
        if (showControls && !locked && isPlaying && !isBuffering && !scrubbing &&
            playerError == null && !anyPanelOpen
        ) {
            delay(3500)
            showControls = false
        }
    }
    // (The indicator's hide lives with its show animation below —
    // one unified effect, see "One show / one hide".)

    // One-time init: begin buffering immediately, then apply saved-position / autoplay policy.
    LaunchedEffect(Unit) {
        // Watch Now rework (owner's order 2026-10-28): a PENDING
        // request (blank streamUrl) means the user tapped Watch Now
        // while the Detail prefetch was still running. Resolve the
        // pick FIRST — continuing the same shared fetch, never
        // restarting it — then swap the never-prepared blank player
        // for one built on the picked stream (the same rebuild
        // pattern as the fresh-resume-URL path below) and let the
        // normal init proceed: the only wait is the player's own
        // startup, and playback starts automatically per settings.
        var pendingResolved = false
        if (initialRequest.streamUrl.isBlank() && !initialRequest.isLive && !initialRequest.isTrailer) {
            val picked = resolvePendingAutoPick(initialRequest)
            if (picked == null || disposed.get()) {
                if (!disposed.get()) playerError = "No stream available"
                initialPrepareDone = true
                return@LaunchedEffect
            }
            val oldPlayer = player
            playerView?.player = null
            oldPlayer.release()
            player = buildExo(picked).also { it.addListener(guardedPlayerListener()) }
            currentRequest = picked
            repository.pendingPlayback = picked
            pendingResolved = true
            if (disposed.get()) return@LaunchedEffect
        }
        // Second-engine start (mobile overhaul): when routing picks
        // MPV for the FIRST play, the throwaway ExoPlayer is never
        // prepared at all — the play starts on MPV directly. Local
        // files stay on Exo (the MPV path plays network streams).
        run {
            val engineForStart = com.pulsestream.app.player.PlaybackEngineResolver.resolve(
                settings.playbackEngine, currentRequest
            )
            val startIsLocal = currentRequest.streamUrl.startsWith("file:", true) ||
                currentRequest.streamUrl.startsWith("content:", true)
            if (engineForStart == com.pulsestream.app.player.PlaybackEngine.MPV &&
                !currentRequest.isLive && !currentRequest.isTrailer && !startIsLocal
            ) {
                val reqMp = currentRequest
                val savedMp = repository.getSavedPositionFor(
                    reqMp.imdbId, reqMp.season, reqMp.episode, reqMp.videoId, reqMp.streamUrl
                )
                var playReq = reqMp
                var offerResumeMp = savedMp > 0L
                if (savedMp > 0L && reqMp.streams.isEmpty()) {
                    // Mirror of the Exo resume path below: re-resolve
                    // fresh streams (6 s cap), prefer the saved stream,
                    // then the autoplay rule, then first playable.
                    loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.FINDING_STREAMS
                    val fresh = withTimeoutOrNull(6_000) {
                        repository.streamResultsFlow(reqMp.type, reqMp.videoId)
                            .firstOrNull {
                                it.streams.any { s ->
                                    com.pulsestream.app.data.isPlayableLiveStreamUrl(s.url)
                                }
                            }
                    }
                    val playableOnly = fresh?.streams?.filter {
                        com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
                    }.orEmpty()
                    val savedRow = repository.playbackRowFor(
                        reqMp.imdbId, reqMp.season, reqMp.episode, reqMp.videoId
                    )
                    val match = (savedRow?.let { repository.matchResumeStream(it, playableOnly) })
                        ?: (if (settings.streamAutoplay) {
                            com.pulsestream.app.ui.components.pickAutoplayStream(playableOnly, settings)
                        } else null)
                        ?: playableOnly.firstOrNull()
                    if (fresh != null && match != null) {
                        availableStreams = fresh.streams
                        playReq = reqMp.copy(
                            streamUrl = match.url,
                            headers = match.headers,
                            mimeType = match.mimeType,
                            streamLabel = streamQualityLabel(match),
                            sourceName = match.sourceName,
                            sourceId = match.sourceId,
                            streamTitle = match.title ?: match.name,
                            subtitles = fresh.subtitles,
                            streams = fresh.streams
                        )
                        currentRequest = playReq
                        repository.pendingPlayback = playReq
                        offerResumeMp = false
                    } else {
                        refreshStreamsBackground(reqMp.type, reqMp.videoId)
                    }
                }
                // v0.14.33: the resume re-resolution is over (a match
                // reset the phase via the new request; the fallback
                // path needs the word back on the buffering phase).
                loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.LOADING
                if (disposed.get()) return@LaunchedEffect
                val parked = player
                playerView?.player = null
                parked.release()
                activateMpv(
                    playReq,
                    startMs = if (offerResumeMp) 0L else savedMp,
                    autoplay = settings.autoplay && !offerResumeMp
                )
                if (offerResumeMp) resumeOfferMs = savedMp
                initialPrepareDone = true
                return@LaunchedEffect
            }
        }
        val startupPlayer = player
        val isLocalFile = initialRequest.streamUrl.startsWith("file:", true) || initialRequest.streamUrl.startsWith("content:", true)
        val prepareEarly = initialRequest.streams.isNotEmpty() || initialRequest.isLive || isLocalFile
        // Player audit 2026-10-27 (finding 1): give the subtitle resolver a
        // short bounded window BEFORE the first prepare, then fold whatever
        // landed into the initial media item — those subtitles are part of
        // the first prepare instead of forcing a re-prepare seconds into
        // playback. Requests carrying no subtitles (and Live / local files)
        // never wait.
        if (initialRequest.subtitles.isNotEmpty() && !initialRequest.isLive && !isLocalFile) {
            withTimeoutOrNull(1_500) { initialSubsSignal.await() }
        }
        // Subtitles no longer fold into the media item at all (mobile
        // overhaul): the sidecar renders them — see the activation
        // effect. Startup only waits the bounded window above so the
        // first sidecar cues are ready when playback begins.
        val saved = preparePlayerBeforeSavedPositionLookup(
            preparePlayer = {
                // Prepare with playback held so a resume prompt never leaks audio/video
                // while progress storage (or a fresh-URL lookup) is still pending.
                startupPlayer.playWhenReady = false
                startupPlayer.prepare()
            },
            loadSavedPosition = {
                if (initialRequest.isLive && !isTv) 0L
                else repository.getSavedPositionFor(
                    initialRequest.imdbId, initialRequest.season,
                    initialRequest.episode, initialRequest.videoId,
                    initialRequest.streamUrl
                )
            },
            prepareEarly = prepareEarly
        )
        var req: PlaybackRequest = initialRequest
        var rebuiltForFreshResumeUrl = false
        var offerResume = saved > 0
        // Local files (downloads): never re-resolve sources — play the file directly.
        // A resolved pending auto-pick already ran its own fetch and
        // pick — the fresh-URL re-resolution below must not override it.
        if (saved > 0 && req.streams.isEmpty() && !req.isLive && !isLocalFile && !pendingResolved && !disposed.get()) {
            // #15: Continue Watching resume — re-resolve the title's streams
            // first so signed/expiring URLs are fresh, and resume at the saved
            // position on the fresh URL. Falls back to the stored URL when
            // re-resolution fails.
            // Player audit 2026-10-27 (finding 7): the wait is capped at 6 s
            // (was 20 s) — a slow addon round must not hold the first frame
            // hostage; the stored-URL fallback below covers the miss.
            loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.FINDING_STREAMS
            val fresh = withTimeoutOrNull(6_000) {
                // v0.14.36 (defect 1): no cache seed — this pass exists
                // to re-resolve FRESH (unexpired) URLs; settling on the
                // seed emission handed it the stored set it was built
                // to replace. The 6 s cap and the stored-URL fallback
                // below are unchanged.
                repository.streamResultsFlow(req.type, req.videoId, seedFromCache = false)
                    .firstOrNull { it.streams.any { stream -> com.pulsestream.app.data.isPlayableLiveStreamUrl(stream.url) } }
            }
            val (playableFresh, hiddenFresh) = fresh?.streams?.let { ( it to 0 ) } ?: (emptyList<com.pulsestream.app.data.StreamItem>() to 0)
            // DB v15: prefer the stream the user was actually
            // watching (saved identity on the playback row) over the
            // first playable one — taking the first stream here was
            // the on-device mechanism of the v0.14.7-test defect
            // ("resume played the 1st stream, I was watching the
            // 7th"). Falls back to the first playable when the saved
            // stream is genuinely gone.
            val playableOnly = playableFresh.filter {
                com.pulsestream.app.data.isPlayableLiveStreamUrl(it.url)
            }
            val savedRow = repository.playbackRowFor(
                req.imdbId, req.season, req.episode, req.videoId
            )
            // CW resume stickiness fix (2026-11-02): when the sticky
            // ladder finds nothing, the fallback used to be the FIRST
            // playable stream — any source, any quality — bypassing
            // even the Settings autoplay rule every other entry point
            // honours. Mirror the Detail page's precedence instead:
            // ladder, then the autoplay rule (when the setting is on),
            // then first playable.
            // v0.14.33: fresh streams are in hand — the pick ladder
            // (saved identity → autoplay rule → first playable) runs now.
            loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.PICKING_QUALITY
            val stream = (savedRow?.let { repository.matchResumeStream(it, playableOnly) })
                ?: (if (settings.streamAutoplay) {
                    com.pulsestream.app.ui.components.pickAutoplayStream(playableOnly, settings)
                } else null)
                ?: playableOnly.firstOrNull()
            if (fresh != null && stream != null && !disposed.get()) {
                availableStreams = playableFresh
                hiddenIncompatibleCount = hiddenFresh
                req = req.copy(
                    streamUrl = stream.url,
                    headers = stream.headers,
                    mimeType = stream.mimeType,
                    streamLabel = streamQualityLabel(stream),
                    sourceName = stream.sourceName,
                    sourceId = stream.sourceId,
                    streamTitle = stream.title ?: stream.name,
                    subtitles = fresh.subtitles,
                    streams = fresh.streams
                )
                repository.pendingPlayback = req
                // Fresh URL: go straight in at the saved position, no prompt.
                offerResume = false
            } else {
                // Stored URL stays; quietly fill Sources for a manual re-pick.
                refreshStreamsBackground(req.type, req.videoId)
            }
        }
        // v0.14.33: whatever the resume pass decided, the wait from
        // here is the player's own buffering.
        loadingPhase = com.pulsestream.app.ui.screens.player.PlayerLoadingPhase.LOADING
        if (disposed.get()) return@LaunchedEffect
        if (req !== initialRequest) {
            // Rebuild the player around the refreshed request so the first
            // prepare already uses the fresh URL (#15; guarded by #9 above).
            val oldPlayer = player
            playerView?.player = null
            oldPlayer.release()
            // Carry the already-resolved subtitles into the rebuilt player
            // (finding 1) so its first prepare includes them too.
            val rebuilt = buildExo(req, resolvedSubs).also { it.addListener(guardedPlayerListener()) }
            subsAttached =
                if (resolvedSubs.isNotEmpty()) rebuilt to subtitleIdentity(resolvedSubs) else null
            rebuilt.setPlaybackSpeed(speed)
            player = rebuilt
            mimeHealAttempted = false
            currentRequest = req
            rebuiltForFreshResumeUrl = true
        }
        val p = player
        seekToPlaybackStart(
            isMobileLive = req.isLive && !isTv,
            startAtMs = saved,
            seekToPosition = { p.seekTo(it) },
            seekToDefaultPosition = { p.seekToDefaultPosition() }
        )
        // The original instance is already prepared above. A refreshed URL has
        // a newly-built player and still needs its first prepare after seekTo.
        if (rebuiltForFreshResumeUrl || !prepareEarly) p.prepare()
        if (offerResume) {
            p.playWhenReady = false
            resumeOfferMs = saved
            // Clean start (v0.14.21): the resume prompt is its own
            // dialog — the transport controls stay down at open.
        } else if (settings.autoplay) {
            p.playWhenReady = true
        } else {
            p.playWhenReady = false
            // Clean start (v0.14.21): no controls at open even when
            // autoplay is off — a tap brings them up to press play.
        }
        // Startup owns subtitles up to here (the fold above); from now on
        // the attach effect handles new/shifted subtitle sets (finding 1).
        initialPrepareDone = true
    }

    // An early Play action may hand off only the first addon's results. Always finish
    // the same title's complete addon flow; a source switch alone does not restart it.
    LaunchedEffect(currentRequest.type, currentRequest.videoId, currentRequest.liveChannel) {
        val req = currentRequest
        val local = req.streamUrl.startsWith("file:", true) || req.streamUrl.startsWith("content:", true)
        val playlistChannel = req.isLive && req.liveChannel == null &&
            com.pulsestream.app.data.isPlayableLiveStreamUrl(req.videoId)
        if (!local && !playlistChannel) refreshStreamsBackground(req.type, req.videoId)
    }

    // Skip segments follow the title, not the source — fetch once per episode.
    LaunchedEffect(initialRequest.imdbId, initialRequest.season, initialRequest.episode) {
        skipSegments = if (!initialRequest.imdbId.isNullOrBlank()) {
            runCatching {
                IntroDbApi().fetchSegments(
                    initialRequest.imdbId!!,
                    initialRequest.season,
                    initialRequest.episode,
                    initialRequest.isMovie
                )
            }.getOrDefault(emptyList())
        } else emptyList()
    }

    // Background audio + media session (v0.14.13, item 6): mirror
    // the ACTIVE player into PlaybackBridge; PlaybackService turns
    // it into lock-screen/notification controls and keeps audio
    // alive in the background. Re-attaches on every player rebuild
    // (source/episode switch) and title change; the service stops
    // when this screen goes away. (Placed here, after playEpisode
    // and the next-episode state exist — composable locals are
    // positional.) PlaybackRequest.title is the EPISODE title for
    // series, so the series name leads the session metadata.
    val bridgeNext = rememberUpdatedState {
        val armed = autoplayNext ?: nextEpisodeSuggestion
        if (armed != null) {
            autoplayNext = null
            nextEpisodeSuggestion = null
            playEpisode(armed)
        } else {
            val req = currentRequest
            if (!req.isMovie && req.episodes.isNotEmpty()) {
                val eps = req.episodes.sortedWith(compareBy({ it.season }, { it.episode }))
                val idx = eps.indexOfFirst { it.id == req.videoId }.takeIf { it >= 0 }
                    ?: eps.indexOfFirst { it.season == req.season && it.episode == req.episode }
                if (idx >= 0) eps.getOrNull(idx + 1)?.let { playEpisode(it) }
            }
        }
    }
    LaunchedEffect(player, currentRequest) {
        // MPV plays have no media-session bridge in this build
        // (overhaul known gap — see the build report): don't attach
        // the released/parked ExoPlayer to the session.
        if (mpvActive()) return@LaunchedEffect
        val req = currentRequest
        val bridgeTitle = when {
            !req.seriesName.isNullOrBlank() -> req.seriesName!!
            else -> req.title
        }
        val bridgeSubtitle = when {
            !req.seriesName.isNullOrBlank() -> {
                val ep = if (req.season > 0 && req.episode > 0) {
                    "S${req.season} · E${req.episode}"
                } else ""
                listOf(ep, req.episodeTitle ?: req.title)
                    .filter { it.isNotBlank() }.joinToString(" — ")
            }
            else -> ""
        }
        val eps = req.episodes.sortedWith(compareBy({ it.season }, { it.episode }))
        val idx = eps.indexOfFirst { it.id == req.videoId }.takeIf { it >= 0 }
            ?: eps.indexOfFirst { it.season == req.season && it.episode == req.episode }
        com.pulsestream.app.data.PlaybackBridge.attach(
            player = player,
            title = bridgeTitle,
            subtitle = bridgeSubtitle,
            hasNext = !req.isMovie && idx >= 0 && eps.getOrNull(idx + 1) != null,
            onNext = { bridgeNext.value() }
        )
        if (!isTv) com.pulsestream.app.data.PlaybackService.start(context)
    }
    DisposableEffect(Unit) {
        onDispose {
            com.pulsestream.app.data.PlaybackBridge.detachAll()
            if (!isTv) com.pulsestream.app.data.PlaybackService.stop(context)
        }
    }

    // Save on background so progress is never lost.
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                savePosition()
                // Second engine (overhaul): no media-session bridge
                // for MPV plays — backgrounding pauses it (PiP floats
                // keep playing, exactly like the Exo path below).
                if (mpvActive()) {
                    if (activity?.isInPictureInPictureMode == true) {
                        return@LifecycleEventObserver
                    }
                    mpvEngine?.setPaused(true)
                    return@LifecycleEventObserver
                }
                // PiP: the activity pauses when the video floats, but playback
                // must continue in the PiP window — only pause when the app is
                // truly backgrounded (not floating).
                if (activity?.isInPictureInPictureMode == true) return@LifecycleEventObserver
                // Background audio (v0.14.13, item 6): while the
                // foreground PlaybackService's media session is live,
                // backgrounding must NOT pause — the audio keeps
                // playing and the lock-screen controls own pause.
                if (com.pulsestream.app.data.PlaybackBridge.sessionActive) {
                    return@LifecycleEventObserver
                }
                // #10: pause on background — release stays in onDispose.
                latestPlayer.value.pause()
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    // Landscape + immersive; restore on exit; save + release on dispose.
    // YouTube opens portrait-first (Rotate pill switches to landscape).
    DisposableEffect(Unit) {
        // PiP dismissal rework (v0.14.4): MainActivity stops playback
        // through this hook when a PiP window is X-closed — on the
        // owner's Samsung the stopped activity never recomposes, so
        // the old counter-only path left audio playing until the app
        // was killed from recents. stop()+release() here kills the
        // audio at the source; the dispose path below stays as-is.
        MainActivity.pipEmergencyStop = {
            runCatching { savePosition() }
            runCatching { latestPlayer.value.stop() }
            runCatching { latestPlayer.value.release() }
        }
        activity?.requestedOrientation = if (initialRequest.sourceName == "YouTube")
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else
            // v0.14.33 (item 5, owner order): SENSOR_LANDSCAPE —
            // the player follows the phone's flip between BOTH
            // landscape sides; plain LANDSCAPE locked it to one
            // side. Never portrait mid-playback. The manifest's
            // configChanges (orientation|screenSize|…) already
            // handles the flip in place — no restart, no reload.
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val window = activity?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
        }
        val controller = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        controller?.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        onDispose {
            MainActivity.pipEmergencyStop = null
            // #9: from here on, no late work may build a player (ghost audio).
            disposed.set(true)
            preemptPendingLiveFallback()
            seekSaveJob?.cancel()
            savePosition()
            // P2 (v0.14.22): the final scrobble stops are AWAITED in a
            // NonCancellable job launched BEFORE the children cancel —
            // the old order launched the stops onto ioScope and then
            // cancelled its children on the next line, racing (and
            // usually killing) stops that wait out a rate-limit window.
            // The NonCancellable job is not a child of ioScope, so
            // cancelChildren below cannot touch it.
            ioScope.launch(kotlinx.coroutines.NonCancellable) {
                runCatching { scrobbler.shutdownAndAwait() }
            }
            // #9: kill late zap/episode/source-switch work. The scope itself
            // stays valid; only its children are cancelled.
            ioScope.coroutineContext.cancelChildren()
            latestPlayer.value.release()
            // Second engine teardown (overhaul): idempotent, ordered
            // (detach surface → destroy) on the engine's own thread.
            mpvEngine?.release()
            // Invalidate any in-flight sidecar parse so a late result
            // can never land on a dead screen.
            sidecarGeneration.incrementAndGet()
            runCatching { boostHolder.enhancer?.release() }
            // #18: swipe-brightness must not leak into the rest of the app.
            window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = -1f
                w.attributes = lp
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    val req = currentRequest
    val headerTitle = req.seriesName ?: req.title
    val episodeLine = if (!req.isMovie) {
        "S${req.season}E${req.episode}" + (req.episodeTitle?.let { " • $it" } ?: "")
    } else null
    val sourceLine = listOfNotNull(req.streamLabel, req.sourceName)
        .joinToString(" • ").takeIf { it.isNotBlank() }
    // Sample C revised header data (v0.14.14, item 2): the meta line
    // reads "S2 · E1 — The Fallen" and the runtime is appended in the
    // overlay by PlayerRuntimeText. (PlaybackRequest carries no
    // year, so the sample's year slot stays empty.) The subs badge
    // names the SELECTED text track's language ("EN SUBS"), or plain
    // "SUBS" when the track's language is unknown; no badge when
    // subtitles are off.
    val metaPrefix = if (!req.isMovie) {
        buildString {
            append("S${req.season} · E${req.episode}")
            req.episodeTitle?.takeIf { it.isNotBlank() }?.let { append(" — $it") }
        }
    } else ""
    val subsBadge = (sidecarSubUrl ?: (if (mpvActive()) mpvActiveSubUrl else null))
        ?.let { url ->
            val lang = panelSubs().firstOrNull { it.url == url }?.lang
            if (lang.isNullOrBlank() || lang.equals("und", ignoreCase = true)) "SUBS"
            else "${lang.take(2).uppercase()} SUBS"
        }
        ?: textOpts.firstOrNull { it.selected }?.let { opt ->
            val lang = runCatching {
                opt.group.getFormat(opt.trackIndex).language
            }.getOrNull()
            if (lang.isNullOrBlank() || lang.equals("und", ignoreCase = true)) "SUBS"
            else "${lang.take(2).uppercase()} SUBS"
        }

    // ---- Android TV D-pad: works when the touch gestures can't. ----
    val playPauseFocus = remember { FocusRequester() }
    // TV: the player container itself is focusable and holds D-pad focus
    // whenever the transport controls are hidden, so the remote never goes
    // dead (NuvioTV parity: containerFocusRequester pattern).
    val containerFocus = remember { FocusRequester() }
    // TV: land D-pad focus on the error overlay's Retry button when it shows.
    val errorRetryFocus = remember { FocusRequester() }
    // Tracks whether any transport button currently holds focus. The D-pad
    // key handler uses this: if controls are visible but nothing grabbed
    // focus (e.g. requestFocus failed), Center/Up/Down re-request focus on
    // the play/pause button instead of being swallowed with no effect.
    var transportFocused by remember { mutableStateOf(false) }
    /** True while the TV seekbar holds D-pad focus (arrows then seek). */
    var seekbarFocused by remember { mutableStateOf(false) }
    LaunchedEffect(playerError, isTv) {
        if (isTv && playerError != null) {
            delay(300)
            runCatching { errorRetryFocus.requestFocus() }
        }
    }
    LaunchedEffect(showControls, isTv, locked) {
        if (!isTv) return@LaunchedEffect
        if (showControls && !locked) {
            delay(350) // let the controls fade in first
            runCatching { playPauseFocus.requestFocus() }
        } else if (!showControls && playerError == null) {
            // Controls hidden: park focus on the container so D-pad events
            // always have a target (container's onPreviewKeyEvent toggles
            // controls back on). Without this the remote goes dead.
            runCatching { containerFocus.requestFocus() }
        }
    }
    // TV: initial focus on the container so the remote works immediately,
    // before the user ever opens the controls.
    LaunchedEffect(isTv) {
        if (isTv && playerError == null) {
            delay(300)
            runCatching { containerFocus.requestFocus() }
        }
    }
    // Focus bookkeeping: overlay flag resets when controls are hidden, and the
    // currently focused transport button registers its action so OK always
    // fires it (even if the button's own click handling misses the key).
    LaunchedEffect(showControls) { if (!showControls) transportFocused = false }
    var focusedKey by remember { mutableStateOf<String?>(null) }
    var focusedAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun act(key: String, action: () -> Unit): Modifier =
        Modifier.onFocusChanged {
            if (it.isFocused || it.hasFocus) { focusedKey = key; focusedAction = action }
            else if (focusedKey == key) { focusedKey = null; focusedAction = null }
        }
    val tvKeys = if (isTv) {
        // A settings sheet/dialog is up: the D-pad must drive the dialog's
        // own focus ( Up/Down through rows, OK to pick ), not the player.
        // Media keys and the channel rocker keep working regardless.
        val dialogOpen = tracksOpen || subSearchOpen || sourcesOpen || episodesOpen ||
            speedMenuOpen || resumeOfferMs != null || playerError != null
        Modifier.onPreviewKeyEvent { event ->
            if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
            // Any remote activity keeps the controls on screen (they used to
            // auto-hide after 3.5s MID-navigation, so focus "vanished").
            if (showControls) controlsTick++
            // Remote channel rocker zaps while watching live TV.
            when (event.nativeKeyEvent.keyCode) {
                android.view.KeyEvent.KEYCODE_CHANNEL_UP -> {
                    if (canZap()) { zapDelta(1); true } else false
                }
                android.view.KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    if (canZap()) { zapDelta(-1); true } else false
                }
                else -> when (event.key) {
                // Media keys always act directly.
                Key.MediaPlayPause -> { togglePlay(); true }
                Key.MediaPlay -> {
                    if (mpvActive()) mpvEngine?.setPaused(false) else player.play()
                    true
                }
                Key.MediaPause -> {
                    if (mpvActive()) mpvEngine?.setPaused(true) else player.pause()
                    true
                }
                Key.MediaFastForward -> { seekByWithFeedback(10_000); true }
                Key.MediaRewind -> { seekByWithFeedback(-10_000); true }
                // D-pad Left/Right: with a dialog open, hand off to the
                // dialog. With the seekbar focused, its own handler seeks.
                // With controls visible, let 2D focus search move between
                // buttons (this is what makes every control reachable).
                // With controls hidden, arrows seek directly.
                Key.DirectionLeft -> when {
                    dialogOpen || seekbarFocused || showControls -> false
                    else -> { seekByWithFeedback(-10_000); true }
                }
                Key.DirectionRight -> when {
                    dialogOpen || seekbarFocused || showControls -> false
                    else -> { seekByWithFeedback(10_000); true }
                }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter ->
                    if (dialogOpen) false
                    else if (showControls && focusedAction != null) {
                        if (event.nativeKeyEvent.repeatCount == 0) focusedAction?.invoke()
                        true
                    }
                    else if (showControls && !transportFocused) {
                        runCatching { playPauseFocus.requestFocus() }; true
                    } else if (showControls) false else { toggleControls(); true }
                // D-pad Up/Down: dialogs handle their own; visible controls
                // get 2D focus navigation between rows; hidden controls are
                // summoned (Down brings them up per the TV spec).
                Key.DirectionUp, Key.DirectionDown ->
                    if (dialogOpen) false
                    else if (showControls && !transportFocused) {
                        runCatching { playPauseFocus.requestFocus() }; true
                    } else if (showControls) false else { toggleControls(); true }
                else -> false
                }
            }
        }
    } else Modifier

    // TV: the root container is focusable and holds the containerFocus
    // requester, so D-pad key events always reach onPreviewKeyEvent even
    // when no transport button has focus (NuvioTV parity).
    val tvContainerModifier = if (isTv) {
        Modifier
            .focusRequester(containerFocus)
            .focusable()
    } else Modifier
    // TV watchdog: if D-pad focus is lost for any reason (a focused button was
    // removed, a sheet closed, an overlay faded out) park it back on the player
    // container, so the remote can never stay dead. Skipped while a sheet or
    // dialog (separate window) legitimately owns focus.
    var rootHasFocus by remember { mutableStateOf(true) }
    val sheetUp = tracksOpen || subSearchOpen || sourcesOpen || episodesOpen ||
        speedMenuOpen || resumeOfferMs != null || downloadStream != null
    LaunchedEffect(rootHasFocus, isTv, sheetUp, showControls, playerError) {
        if (isTv && !rootHasFocus && !sheetUp && playerError == null) {
            delay(400)
            runCatching { if (showControls && !locked) playPauseFocus.requestFocus() else containerFocus.requestFocus() }
                .onFailure { runCatching { containerFocus.requestFocus() } }
        }
    }
    // Second-engine surface callback (mobile overhaul).
    val mpvSurfaceCallback = remember {
        object : android.view.SurfaceHolder.Callback {
            override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                mpvEngine?.attachSurface(holder.surface)
            }

            override fun surfaceChanged(
                holder: android.view.SurfaceHolder,
                format: Int,
                width: Int,
                height: Int
            ) {
            }

            override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
                mpvEngine?.detachSurface()
            }
        }
    }

    Box(tvKeys.fillMaxSize().background(Color.Black)
        .then(if (isTv) Modifier.onFocusChanged { rootHasFocus = it.hasFocus } else Modifier)
        .then(tvContainerModifier)) {
        // Video surface with the full gesture set (gestures off while floating —
        // taps on the PiP window belong to the system's PiP controls).
        Box(Modifier.fillMaxSize().then(if (inPip) Modifier else Modifier.videoGestures())) {
            if (mpvActive()) {
                // Second engine (mobile overhaul): MPV renders into a
                // plain SurfaceView; the control shell around it is
                // shared and unchanged. The engine owns the
                // attach/detach ordering on its own thread.
                AndroidView(
                    factory = { ctx ->
                        android.view.SurfaceView(ctx).also { sv ->
                            sv.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            sv.holder.addCallback(mpvSurfaceCallback)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).also { pv ->
                        pv.player = player
                        pv.useController = false
                        pv.isFocusable = false
                        pv.isFocusableInTouchMode = false
                        pv.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                        pv.keepScreenOn = settings.keepScreenOn
                        pv.resizeMode = aspectMode
                        pv.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        applySubtitleStyle(pv)
                        playerView = pv
                    }
                },
                update = { pv ->
                    pv.player = player
                    applySubtitleStyle(pv)
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // PiP (v0.9.0+): while the video floats, skip every overlay layer —
        // the system draws its own PiP controls. Only the PlayerView surface
        // stays composed, so playback continues uninterrupted.
        if (inPip) return@Box

        // Startup presentation (v0.14.33 — owner's locked sample
        // "Poster Heartbeat + Status Line", replacing the 2026-10-24
        // "Backdrop + orbit" treatment on the initial-load path
        // only): the title's backdrop under a heartbeat pulse with
        // the status capsule — see PlayerLoadingOverlay. WHICH
        // buffering moments may wear it is the owner's scope pin
        // (v0.14.34, playerBufferVisual): the initial load before
        // this title has ever played, plus resume-after-pause
        // buffering — NOTHING else. Every other mid-playback buffer
        // (seek, slow-network rebuffer, source switch) keeps the
        // plain orbit over the video, exactly as before. Suppressed
        // on a fatal error — the error overlay takes its place (#4).
        // The stall / failover machinery behind it is unchanged.
        val bufferVisual = com.pulsestream.app.ui.screens.player.playerBufferVisual(
            isBuffering = isBuffering || switchingMedia,
            hasError = playerError != null,
            hasStartedOnce = hasStartedPlayback,
            resumeBuffering = resumeBuffering
        )
        if (bufferVisual == com.pulsestream.app.ui.screens.player.PlayerBufferVisual.PLAIN_SPINNER) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                OrbitDots(Modifier.size(48.dp))
            }
        }
        com.pulsestream.app.ui.screens.player.PlayerLoadingOverlay(
            active = bufferVisual == com.pulsestream.app.ui.screens.player.PlayerBufferVisual.STARTUP_OVERLAY,
            request = currentRequest,
            phase = loadingPhase
        )

        // Sleep timer chip (v0.14.13, item 9): while a sleep timer
        // runs, a small pill at the top-centre shows what's left —
        // tapping it cancels the timer (change it from the Sleep
        // menu in the dock). Reddit fix (owner order 2026-11-06):
        // the chip now fades WITH the controls — it used to render
        // outside the controls visibility and stayed on screen alone.
        if ((sleepDeadlineMs > 0L || sleepAtEpisodeEnd) && showControls && !locked) {
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 84.dp)
                    .clickable {
                        sleepDeadlineMs = 0L
                        sleepAtEpisodeEnd = false
                        pokeIndicator(PlayerIndicator.Message("Sleep timer off"))
                    }
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Filled.Bedtime,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        if (sleepDeadlineMs > 0L) {
                            "Sleep in $sleepTimerLabel"
                        } else {
                            "Sleep at episode end"
                        },
                        color = TextPrimary,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Next-episode pill (finding 8 + notes item 16): while the
        // autoplay countdown runs it shows the seconds; tapping the
        // label plays the episode NOW, tapping Cancel stops the
        // countdown but KEEPS the offer as a standing suggestion
        // pill (previously any tap killed it silently). With the
        // Auto-play setting off there is no countdown at all — the
        // suggestion pill alone is what the user gets, so an ended
        // episode never just sits in silence.
        (autoplayNext ?: nextEpisodeSuggestion)?.let { nextEp ->
            val countingDown = autoplayNext != null
            val playNow = {
                autoplayNext = null
                nextEpisodeSuggestion = null
                playEpisode(nextEp)
            }
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 120.dp)
            ) {
                Row(
                    Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Filled.SkipNext,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        (if (countingDown) {
                            "Next episode in ${autoplayCountdownSec}s"
                        } else {
                            "Next episode"
                        }) + (nextEp.title?.takeIf { it.isNotBlank() }
                            ?.let { " — $it" } ?: ""),
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .widthIn(max = 260.dp)
                            .clickable { playNow() }
                    )
                    if (countingDown) {
                        Text(
                            "Cancel",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { demoteAutoplayToSuggestion() }
                        )
                    } else {
                        Text(
                            "Play",
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { playNow() }
                        )
                        Text(
                            "✕",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { nextEpisodeSuggestion = null }
                        )
                    }
                }
            }
        }

        // Fatal stream error (#4): Retry re-prepares this stream, Next source
        // advances to the next available stream, and the floating Sources
        // switcher stays openable underneath via "Browse all sources".
        playerError?.let { err ->
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 32.dp)
                ) {
                    Text(
                        "Couldn't play this source",
                        color = TextPrimary,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        err,
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(20.dp))
                    if (ladderTerminal) {
                        // Error-ladder end (mobile overhaul): every
                        // recovery rung already ran for this stream —
                        // the screen offers one Back and nothing else.
                        Button(
                            onClick = { onBack() },
                            modifier = Modifier
                                .focusRequester(errorRetryFocus)
                                .tvFocusRing(RoundedCornerShape(20.dp))
                        ) {
                            Text("Back")
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { retryCurrentStream() },
                                modifier = Modifier
                                    .focusRequester(errorRetryFocus)
                                    .tvFocusRing(RoundedCornerShape(20.dp))
                            ) {
                                Text("Retry")
                            }
                            Button(
                                onClick = { nextSource() },
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(20.dp))
                            ) {
                                Text("Next source")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            // Fresh fetch when opening Sources — ensures full list
                            refreshStreamsBackground(currentRequest.type, currentRequest.videoId)
                            sourcesOpen = true
                        }) {
                            Text(
                                "Browse all sources",
                                color = LocalPalette.current.accent,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Transient gesture feedback (never consumes touches).
        // v0.14.3 (owner's order): pop-in spring + fade; volume/
        // brightness get an animated level bar; the volume indicator
        // changes colour at the extremes — soft red at mute (0),
        // amber in the boost zone (past 100).
        // One show / one hide (owner's flicker report 2026-10-26):
        // the entrance used to restart on EVERY new indicator value,
        // so a volume/brightness swipe — a fresh value per move
        // event — snapped the pill back to 82% / 0 alpha dozens of
        // times a second. Now the pop-in runs only when the pill
        // appears (alpha at rest); value changes update the content
        // in place; the hide is a single debounced fade that starts
        // 1s after the LAST poke, and a poke that lands mid-fade
        // brings the pill straight back with no pop.
        val indScale = remember { Animatable(1f) }
        val indAlpha = remember { Animatable(0f) }
        LaunchedEffect(indicatorTick) {
            if (indicator == null) return@LaunchedEffect
            if (indAlpha.value <= 0f) {
                indScale.snapTo(0.82f)
                launch { indScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 420f)) }
                indAlpha.animateTo(1f, tween(120))
            } else if (indAlpha.value < 1f) {
                launch { indScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 420f)) }
                indAlpha.animateTo(1f, tween(80))
            }
            delay(1000)
            indAlpha.animateTo(0f, tween(200))
            indicator = null
        }
        indicator?.let { ind ->
            val accentNow = LocalPalette.current.accent
            val volTint = when {
                ind is PlayerIndicator.Volume && ind.percent <= 0 -> Color(0xFFF87171)
                ind is PlayerIndicator.Volume && ind.percent > 100 -> Color(0xFFFBBF24)
                else -> accentNow
            }
            val levelFraction = when (ind) {
                is PlayerIndicator.Volume ->
                    if (ind.percent > 100) ind.percent / 200f else ind.percent / 100f
                is PlayerIndicator.Brightness -> ind.percent.coerceIn(0, 100) / 100f
                else -> null
            }
            // The level bar tracks the finger: a short tween, not a
            // spring — during a swipe the value changes continuously
            // and a spring lags and wobbles behind it (flicker fix).
            val levelAnim by animateFloatAsState(
                targetValue = levelFraction ?: 0f,
                animationSpec = tween(70),
                label = "indicatorLevel"
            )
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Surface(
                    color = Color.Black.copy(alpha = 0.62f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.graphicsLayer {
                        scaleX = indScale.value
                        scaleY = indScale.value
                        alpha = indAlpha.value
                    }
                ) {
                    Column(
                        Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            when (ind) {
                                is PlayerIndicator.Volume -> {
                                    Icon(
                                        if (ind.percent <= 0) Icons.Filled.VolumeOff
                                        else Icons.Filled.VolumeUp,
                                        null,
                                        tint = volTint
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Volume ${ind.percent}%",
                                        color = volTint,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                is PlayerIndicator.Brightness -> {
                                    Icon(Icons.Filled.SettingsBrightness, null, tint = accentNow)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Brightness ${ind.percent}%",
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                is PlayerIndicator.Seek -> {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            ind.text,
                                            color = TextPrimary,
                                            style = MaterialTheme.typography.headlineSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        // Slide-seek landing time
                                        // (v0.14.16): where the finger
                                        // will drop the playhead.
                                        ind.subtext?.let { sub ->
                                            Text(
                                                sub,
                                                color = TextPrimary.copy(alpha = 0.75f),
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                                is PlayerIndicator.Speed -> {
                                    Text(
                                        "Speed ${ind.label}",
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                is PlayerIndicator.Message -> {
                                    Text(
                                        ind.text,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                        if (levelFraction != null) {
                            Spacer(Modifier.height(8.dp))
                            Box(
                                Modifier
                                    .width(120.dp)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.25f))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(levelAnim.coerceIn(0f, 1f))
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(
                                            if (ind is PlayerIndicator.Volume) volTint else accentNow
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Hold-for-speed pill: pinned top-center only while the hold boost
        // is active, showing the current step (2x..5x); never consumes touches.
        if (holdSpeedActive) {
            Box(
                Modifier.fillMaxSize().padding(top = 24.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.62f),
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.FastForward,
                            contentDescription = null,
                            tint = LocalPalette.current.accent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "${holdSpeedStep}x",
                            color = TextPrimary,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Skip intro / recap / outro button (IntroDB).
        activeSegment?.let { seg ->
            Box(
                Modifier.fillMaxSize().padding(end = 24.dp, bottom = 170.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                TextButton(
                    onClick = {
                        // Item 16 fix: IntroDB end times are authored
                        // against a reference runtime and routinely
                        // overshoot the real file by seconds — seeking
                        // to endMs+400 landed in the void past EOF and
                        // manufactured an error end. Clamp the target
                        // to the REAL duration (duration − 1 s); when
                        // the tail left after the target is under
                        // ~1.5 s, skip the seek entirely and let the
                        // episode end naturally into the ENDED gate.
                        val dur = player.duration
                        if (dur > 0) {
                            val target = minOf(seg.endMs + 400, dur - 1_000L)
                            if (target > player.currentPosition &&
                                dur - target >= 1_500L
                            ) {
                                guardedSeekTo(target)
                            }
                        } else {
                            guardedSeekTo(seg.endMs + 400)
                        }
                        activeSegment = null
                    },
                    modifier = Modifier.background(
                        Color.Black.copy(alpha = 0.72f),
                        RoundedCornerShape(10.dp)
                    )
                ) {
                    Text(
                        seg.type.buttonLabel(),
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Unlock affordance while locked (controls stay hidden).
        if (locked) {
            IconButton(
                onClick = {
                    locked = false
                    showControls = true
                    controlsTick++
                    pokeIndicator(PlayerIndicator.Message("Controls unlocked"))
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
            ) {
                Icon(Icons.Filled.Lock, "Unlock controls", tint = LocalPalette.current.accent)
            }
        }

        // Controls overlay. Explicit fade timing (v0.14.26,
        // item 6): the default fade specs snapped in/out with the
        // frame rate on the owner's phone; a matched 220/180 ms
        // tween pair reads as one smooth motion both ways.
        AnimatedVisibility(
            visible = showControls && !locked,
            enter = fadeIn(tween(220)),
            exit = fadeOut(tween(180))
        ) {
            Box(Modifier.fillMaxSize().tapGestures()
                .then(if (isTv) Modifier.onFocusChanged { transportFocused = it.hasFocus } else Modifier)) {
                // ---- Top (Sample C revised, v0.14.14 item 2): NO
                // glass and NO scrim — a plain detail block on the
                // left (title, meta line, badges) carried by text
                // shadow alone, bare shadowed icons on the right.
                // This replaces the old full-width liquid-glass bar.
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(start = 28.dp, end = 28.dp, top = 26.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            headerTitle,
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                shadow = PLAYER_TEXT_SHADOW
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            Modifier.padding(top = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (metaPrefix.isNotEmpty()) {
                                Text(
                                    metaPrefix,
                                    color = TextPrimary.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 13.sp,
                                        shadow = PLAYER_TEXT_SHADOW
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            PlayerRuntimeText(
                                durationMsState,
                                leadingSeparator = metaPrefix.isNotEmpty()
                            )
                        }
                        Row(
                            Modifier.padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            req.streamLabel?.takeIf { it.isNotBlank() }?.let {
                                PlayerBadge(it.uppercase())
                            }
                            req.sourceName?.takeIf { it.isNotBlank() }?.let {
                                PlayerBadge(it)
                            }
                            subsBadge?.let { PlayerBadge(it) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Top-right cluster (owner's order 2026-10-25:
                        // Lock, Rotate, External player, Back — icons
                        // only, moved out of the bottom pill bar).
                        // Sample C revised (v0.14.14, item 2): the
                        // buttons stay, but the glyphs are now BARE —
                        // no glass behind them, a drop shadow only
                        // (BareShadowIcon). PiP stays in the bottom
                        // capsule, exactly as the sample also has it.
                        // Engine switch (mobile overhaul): a manual
                        // swap to the other engine at the current
                        // position. A manual switch also disarms the
                        // automatic failover for this title — the
                        // user chose, the ladder doesn't argue.
                        if (!currentRequest.isLive && !currentRequest.isTrailer) {
                            IconButton(
                                onClick = {
                                    engineFailoverArmed = false
                                    val position = activePositionMs()
                                    switchPlaybackEngine(
                                        com.pulsestream.app.player.PlaybackEngineResolver.other(activeEngine),
                                        position
                                    )
                                },
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                            ) {
                                BareShadowIcon(Icons.Filled.SwapHoriz, "Switch playback engine")
                            }
                        }
                        IconButton(
                            onClick = {
                                locked = !locked
                                if (locked) {
                                    // Hard lock (overhaul): every panel
                                    // unmounts with the shell.
                                    tracksOpen = false
                                    subSearchOpen = false
                                    sourcesOpen = false
                                    episodesOpen = false
                                    speedMenuOpen = false
                                    sleepMenuOpen = false
                                    showControls = false
                                    pokeIndicator(PlayerIndicator.Message("Controls locked"))
                                } else {
                                    showControls = true
                                    controlsTick++
                                    pokeIndicator(PlayerIndicator.Message("Controls unlocked"))
                                }
                            },
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(
                                if (locked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                if (locked) "Unlock controls" else "Lock controls"
                            )
                        }
                        IconButton(
                            onClick = {
                                isPortrait = !isPortrait
                                activity?.requestedOrientation = if (isPortrait)
                                    ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                else
                                    // v0.14.33 (item 5): back to
                                    // landscape means SENSOR_LANDSCAPE
                                    // (both sides), never the one-side
                                    // lock.
                                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            },
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(Icons.Filled.ScreenRotation, "Rotate")
                        }
                        IconButton(
                            onClick = {
                                val ctx = activity ?: return@IconButton
                                // Protected links warn once (owner's
                                // order 2026-10-26) instead of the old
                                // hard block; normal links open at once.
                                if (ExternalPlayer.needsWarning(ctx, req)) {
                                    externalWarningHide = false
                                    externalWarningReq = req
                                } else {
                                    ExternalPlayer.play(ctx, req)
                                }
                            },
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(Icons.Filled.ExitToApp, "Open in external player")
                        }
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.then(act("back") { onBack() })
                            .tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(Icons.Filled.ArrowBack, "Back")
                        }
                    }
                }

                // ---- Center transport ----
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(36.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (canZap()) {
                        IconButton(
                            onClick = { zapDelta(-1) },
                            enabled = !zapping,
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(
                                Icons.Filled.SkipPrevious, "Previous channel",
                                glyphSize = 48.dp
                            )
                        }
                    }
                    if (!currentRequest.isLive) {
                        IconButton(
                            onClick = { seekByWithFeedback(-10_000) },
                            modifier = Modifier.then(act("rew") { seekByWithFeedback(-10_000) })
                                .tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(
                                Icons.Filled.Replay10, "Back 10 seconds",
                                glyphSize = 56.dp
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .liquidGlass(RoundedCornerShape(50), frost = 0.12f, darken = 0.03f)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = { togglePlay() },
                            modifier = Modifier
                                .focusRequester(playPauseFocus)
                                .then(act("play") { togglePlay() })
                                .tvFocusRing(RoundedCornerShape(50))
                        ) {
                            Icon(
                                if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                if (isPlaying) "Pause" else "Play",
                                tint = TextPrimary, modifier = Modifier.size(76.dp)
                            )
                        }
                    }
                    if (!currentRequest.isLive) {
                        IconButton(
                            onClick = { seekByWithFeedback(10_000) },
                            modifier = Modifier.then(act("fwd") { seekByWithFeedback(10_000) })
                                .tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(
                                Icons.Filled.Forward10, "Forward 10 seconds",
                                glyphSize = 56.dp
                            )
                        }
                    }
                    if (canZap()) {
                        IconButton(
                            onClick = { zapDelta(1) },
                            enabled = !zapping,
                            modifier = Modifier.tvFocusRing(RoundedCornerShape(50))
                        ) {
                            BareShadowIcon(
                                Icons.Filled.SkipNext, "Next channel",
                                glyphSize = 48.dp
                            )
                        }
                    }
                }

                // ---- Bottom (v0.14.19 — the owner's mix of two
                // players): the seek row is Sample A's (v0.14.17) —
                // it floats BARE over the picture, no glass, no
                // backing behind it (current time, SlimSeekBar with
                // its accent light-orb, total time), and live
                // playback keeps a LIVE row in its place. The button
                // capsule below it is the LAST STABLE's (v0.14.13),
                // restored faithfully: a centered fitted pill in the
                // dock's frosted dark liquid glass (fitted dark
                // backing + liquidGlass face, RoundedCornerShape(50))
                // holding ONE natural-width row — Aspect (its label
                // carries the current mode), PiP, Speed, Sleep, Subs,
                // Audio, Sources, and Episodes on series only. Play /
                // Prev / Next stay on the center transport, exactly
                // as v0.14.13 divided the work.
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .widthIn(max = 880.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 18.dp)
                ) {
                    Box(Modifier.fillMaxWidth().padding(horizontal = 26.dp)) {
                        if (currentRequest.isLive) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = Color(0xFFE5484D),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "LIVE",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    currentRequest.title,
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    when {
                                        switchingMedia -> "Switching…"
                                        isBuffering -> "Buffering…"
                                        else -> "On air"
                                    },
                                    color = TextSecondary,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        } else {
                            PlayerSeekControls(
                                positionMsState = positionMsState,
                                durationMsState = durationMsState,
                                onSeek = { guardedSeekTo(it) },
                                isTv = isTv,
                                onSeekDelta = { seekByWithFeedback(it) },
                                onFocusChanged = { seekbarFocused = it },
                                onScrubChanged = { scrubbing = it }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box {
                            // TRUE frosted liquid glass (v0.14.6): the dock's
                            // recipe — a fitted backing behind the glass face
                            // (the bare liquidGlass call read as a plain chip).
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (LocalPalette.current.light) {
                                            Color.White.copy(alpha = 0.82f)
                                        } else {
                                            Color.Black.copy(alpha = 0.48f)
                                        },
                                        RoundedCornerShape(50)
                                    )
                            )
                            Box(
                                modifier = Modifier.liquidGlass(RoundedCornerShape(50), frost = 0.12f, darken = 0.03f)
                            ) {
                                Row(
                                    Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    PillBarButton(
                                        icon = Icons.Filled.AspectRatio,
                                        label = aspectLabel,
                                        onClick = { cycleAspect() }
                                    )
                                    PillBarButton(
                                        icon = Icons.Filled.PictureInPicture,
                                        label = "PiP",
                                        onClick = {
                                            if (!settings.pipEnabled) return@PillBarButton
                                            val act = activity as? MainActivity ?: return@PillBarButton
                                            if (mpvActive()) {
                                                // MPV size/playing state from the
                                                // snapshot (already mirrored into
                                                // the MainActivity PiP statics by
                                                // the poll loop).
                                                act.enterPictureInPictureMode(
                                                    MainActivity.buildPipParams(act, isPlaying)
                                                )
                                                return@PillBarButton
                                            }
                                            val vs = player.videoSize
                                            if (vs.width > 0 && vs.height > 0) {
                                                MainActivity.pipVideoW = vs.width
                                                MainActivity.pipVideoH = vs.height
                                            }
                                            act.enterPictureInPictureMode(
                                                MainActivity.buildPipParams(act, player.isPlaying)
                                            )
                                        }
                                    )
                                    SpeedMenuButton(
                                        speed = speed,
                                        menuOpen = speedMenuOpen,
                                        onOpenMenu = { speedMenuOpen = true },
                                        onDismissMenu = { speedMenuOpen = false },
                                        onSpeedSelected = { s ->
                                            speed = s
                                            if (mpvActive()) {
                                                mpvEngine?.setSpeed(s)
                                            } else {
                                                player.setPlaybackSpeed(s)
                                            }
                                            speedMenuOpen = false
                                            pokeIndicator(PlayerIndicator.Speed(speedLabel(s)))
                                        }
                                    )
                                    SleepTimerButton(
                                        label = sleepTimerLabel,
                                        active = sleepDeadlineMs > 0L || sleepAtEpisodeEnd,
                                        menuOpen = sleepMenuOpen,
                                        onOpenMenu = { sleepMenuOpen = true },
                                        onDismissMenu = { sleepMenuOpen = false },
                                        onSelectMinutes = { minutes ->
                                            sleepAtEpisodeEnd = false
                                            sleepDeadlineMs =
                                                System.currentTimeMillis() + minutes * 60_000L
                                            sleepMenuOpen = false
                                            pokeIndicator(
                                                PlayerIndicator.Message("Sleep timer — $minutes minutes")
                                            )
                                        },
                                        onSelectEndOfEpisode = {
                                            sleepDeadlineMs = 0L
                                            sleepAtEpisodeEnd = true
                                            sleepMenuOpen = false
                                            pokeIndicator(
                                                PlayerIndicator.Message("Sleep timer — end of episode")
                                            )
                                        },
                                        onOff = {
                                            sleepDeadlineMs = 0L
                                            sleepAtEpisodeEnd = false
                                            sleepMenuOpen = false
                                            pokeIndicator(PlayerIndicator.Message("Sleep timer off"))
                                        }
                                    )
                                    // v0.14.30 (owner's note 1): the
                                    // Subs button is the SAME
                                    // PillBarButton as every other
                                    // capsule button — plain icon +
                                    // label, no chip/background of its
                                    // own; the only ON mark is a tiny
                                    // accent-coloured dot (v0.14.29's
                                    // glass chip is removed). State is
                                    // still never carried by glyph
                                    // whiteness. The tap opens the
                                    // stepped card flow (Languages →
                                    // Files → Style).
                                    SubsPillButton(
                                        on = !subtitlesOff,
                                        onClick = {
                                            trackTick++
                                            tracksMode = "subs"
                                            subCardStep = 1
                                            tracksOpen = true
                                        }
                                    )
                                    PillBarButton(
                                        icon = Icons.Filled.Audiotrack,
                                        label = "Audio",
                                        onClick = { trackTick++; tracksMode = "audio"; tracksOpen = true }
                                    )
                                    PillBarButton(
                                        icon = Icons.Filled.CloudDownload,
                                        label = "Sources",
                                        onClick = {
                                            // Fresh fetch when opening Sources — ensures full list, not stale partial
                                            refreshStreamsBackground(currentRequest.type, currentRequest.videoId)
                                            sourcesOpen = true
                                        }
                                    )
                                    if (!currentRequest.isMovie && currentRequest.episodes.isNotEmpty()) {
                                        PillBarButton(
                                            icon = Icons.Filled.VideoLibrary,
                                            label = "Episodes",
                                            onClick = { episodesOpen = true }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Item 12 (v0.14.26): the owner's "Stream won't play" popup —
        // shown ONLY when the play's one auto source switch was spent
        // and the second stream also proved dead. Nothing auto-switches
        // past this point; the source picker is one tap away.
        if (streamWontPlayShown) {
            AlertDialog(
                onDismissRequest = { streamWontPlayShown = false },
                title = { Text("Stream won't play. Pick another one.") },
                confirmButton = {
                    TextButton(onClick = {
                        streamWontPlayShown = false
                        refreshStreamsBackground(currentRequest.type, currentRequest.videoId)
                        sourcesOpen = true
                    }) { Text("Pick a source") }
                },
                dismissButton = {
                    TextButton(onClick = { streamWontPlayShown = false }) { Text("Close") }
                }
            )
        }

        // External-player warning for protected links (owner's order
        // 2026-10-26 — replaces the old hard block): the link leaves
        // the app without its protected headers, so the outside player
        // may not be able to play it. "Don't show again" persists.
        externalWarningReq?.let { warnReq ->
            val warnCtx = activity
            AlertDialog(
                onDismissRequest = { externalWarningReq = null },
                title = { Text("Protected link") },
                text = {
                    Column {
                        Text(
                            "This source uses protected headers, which stay in Plavio — " +
                                "the other app may not be able to play this link.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { externalWarningHide = !externalWarningHide }
                        ) {
                            Checkbox(
                                checked = externalWarningHide,
                                onCheckedChange = { externalWarningHide = it }
                            )
                            Text(
                                "Don't show again",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (externalWarningHide && warnCtx != null) {
                            ExternalPlayer.setWarningSuppressed(warnCtx, true)
                        }
                        externalWarningReq = null
                        if (warnCtx != null) ExternalPlayer.play(warnCtx, warnReq)
                    }) {
                        Text("Open anyway", color = LocalPalette.current.accent)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { externalWarningReq = null }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // Resume prompt.
        resumeOfferMs?.let { saved ->
            ResumePromptDialog(
                savedMs = saved,
                title = headerTitle,
                onResume = {
                    // Tapping outside keeps their place and resumes.
                    resumeOfferMs = null
                    if (mpvActive()) {
                        // The MPV play started at 0 held paused; seek
                        // to the saved position, then play.
                        mpvEngine?.seekTo(saved)
                        mpvEngine?.setPaused(false)
                    } else {
                        player.playWhenReady = true
                    }
                },
                onStartOver = {
                    resumeOfferMs = null
                    ioScope.launch { repository.deleteSavedPosition(currentRequest.streamUrl) }
                    guardedSeekTo(0)
                    if (mpvActive()) {
                        mpvEngine?.setPaused(false)
                    } else {
                        player.playWhenReady = true
                    }
                }
            )
        }

        // (v0.14.29: the TB quick popover is superseded by the
        // stepped subtitle card flow in the tracksOpen subs branch
        // below — Languages → Files → Style, owner's approved
        // redesign. The popover's ON/OFF pill logic moved into
        // the card header unchanged. v0.14.30: the card's toggle
        // and Off row route through their own off/re-enable
        // actions — see offAction/onToggleSubs in the card branch:
        // v0.14.29 routed Off through the embedded-track selection
        // path, which never stopped the sidecar renderer.)

        // Track switching: the Subs button opens the subtitle overlay
        // (v0.14.5, Nuvio-style three rails over the playing video); the
        // Audio button keeps its bottom sheet. Neither is an
        // AlertDialog, so the root media/channel-key handler keeps
        // working while they're open (#28).
        if (tracksOpen) {
            val isAudio = tracksMode == "audio"
            // TV: land D-pad focus on the first row when the picker opens.
            val firstRowFocus = remember { FocusRequester() }
            LaunchedEffect(isTv, tracksMode) {
                if (tracksMode == "subs") {
                    // Seed the Style rail's visibility from the track
                    // that is already playing when the overlay opens.
                    // Under the sidecar / MPV the playing track is the
                    // sidecar (or sub-add) URL, not an Exo text track.
                    panelPickedUrl = sidecarSubUrl
                        ?: (if (mpvActive()) mpvActiveSubUrl else null)
                        ?: textOpts.firstOrNull { it.selected }
                            ?.let { panelTrackId(it) }
                }
                if (isTv) {
                    delay(300)
                    runCatching { firstRowFocus.requestFocus() }
                }
            }
            if (isAudio) {
                ModalBottomSheet(
                    onDismissRequest = { tracksOpen = false },
                    sheetState = rememberModalBottomSheetState(),
                    containerColor = Color(0xFF14141F)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp)
                    ) {
                        item {
                            Text(
                                "Audio",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                            )
                        }
                        if (mpvActive()) {
                            // MPV track list (overhaul): ids from the
                            // engine's own track-list, not Exo's.
                            item {
                                TrackRow(
                                    label = "Auto",
                                    selected = mpvTracksUi.none {
                                        it.type == "audio" && it.selected
                                    },
                                    onClick = { applyMpvAudioSelection(null) },
                                    modifier = Modifier.focusRequester(firstRowFocus)
                                )
                            }
                            items(mpvTracksUi.filter { it.type == "audio" }) { track ->
                                TrackRow(
                                    label = track.title ?: track.lang
                                        ?: "Track ${track.id}",
                                    selected = track.selected,
                                    onClick = { applyMpvAudioSelection(track) }
                                )
                            }
                        } else {
                            item {
                                TrackRow(
                                    label = "Auto",
                                    selected = audioOpts.none { it.selected },
                                    onClick = { applyAudioSelection(null) },
                                    modifier = Modifier.focusRequester(firstRowFocus)
                                )
                            }
                            items(audioOpts) { opt ->
                                TrackRow(
                                    label = opt.label,
                                    selected = opt.selected,
                                    onClick = { applyAudioSelection(opt) }
                                )
                            }
                        }
                    }
                }
            } else {
                // ===== Subtitle overlay (v0.14.5, owner's approved
                // design): a translucent full-player overlay — the video
                // keeps playing behind it and every style change lands
                // on the real captions live. Three side-by-side rails in
                // a horizontally scrollable row: Languages | Subtitles |
                // Style (the Style rail fades in only once a subtitle
                // is selected). =====
                val prefLangNames = settings.subtitleLanguages.map { panelLangName(it) }
                // "Show only my languages" (Settings > Subtitles): the
                // Languages rail lists just the preferred languages —
                // plus the language of the track actually playing, so
                // what's on screen is never hidden. Falls back to all
                // languages when none match, so the rail is never empty.
                val selectedLangName = (sidecarSubUrl
                    ?: (if (mpvActive()) mpvActiveSubUrl else null))?.let { url ->
                    panelSubs().firstOrNull { it.url == url }
                        ?.let { panelLangName(it.lang) }
                } ?: textOpts.firstOrNull { it.selected }?.let {
                    panelLangName(
                        runCatching { it.group.getFormat(it.trackIndex).language }
                            .getOrNull()
                    )
                }
                val allLangs = panelLanguages()
                val visibleLangs =
                    if (settings.subtitleOnlyMyLanguages && prefLangNames.isNotEmpty()) {
                        allLangs.filter { (name, _) ->
                            name in prefLangNames || name == selectedLangName
                        }.ifEmpty { allLangs }
                    } else {
                        allLangs
                    }
                // Preferred languages first (Settings > Subtitles),
                // stable for the rest.
                val sortedLangs = visibleLangs.sortedBy { (name, _) ->
                    prefLangNames.indexOf(name).let { if (it < 0) Int.MAX_VALUE else it }
                }
                val activeLang = panelLang?.takeIf { ln -> sortedLangs.any { it.first == ln } }
                    ?: textOpts.firstOrNull { it.selected }?.let {
                        panelLangName(
                            runCatching { it.group.getFormat(it.trackIndex).language }
                                .getOrNull()
                        )
                    }
                    ?: sortedLangs.firstOrNull()?.first
                val langSubs = panelSubs().filter { panelLangName(it.lang) == activeLang }
                val langEmbedded = panelEmbeddedOpts().filter {
                    panelLangName(
                        runCatching { it.group.getFormat(it.trackIndex).language }
                            .getOrNull()
                    ) == activeLang
                }
                // The playing subtitle under the overhaul is the
                // sidecar's (Exo) or the sub-add's (MPV) — an Exo text
                // track only when a legacy path selected one.
                val selectedSubUrl = sidecarSubUrl
                    ?: (if (mpvActive()) mpvActiveSubUrl else null)
                    ?: textOpts.firstOrNull { it.selected }
                        ?.let { panelTrackId(it) }
                val selectedIsAddon = selectedSubUrl != null &&
                    panelSubs().any { it.url == selectedSubUrl }
                val styleVisible = !subtitlesOff || panelPickedUrl != null
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    // ===== Subtitle card flow (v0.14.29, owner's
                    // approved redesign): ONE frosted dark-glass card
                    // at the left, vertically centred, three steps —
                    // 1 Languages → 2 Files → 3 Style — one card
                    // visible at a time; the back chevron steps back,
                    // × closes. This re-lays-out the exact plumbing
                    // the old three rails used (panelSubs /
                    // panelLanguages / activatePanelSubtitle / the
                    // same SettingsStore writes): sources, order and
                    // auto-apply behaviour are unchanged. The video
                    // keeps playing behind the scrim and every style
                    // change lands on the real captions live. State
                    // marks use the Onyx accent (dots, check discs —
                    // v0.14.30, owner's note 2), never the brand
                    // gradient and never glyph whiteness. =====
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { tracksOpen = false }
                    )
                    val subsOn = !subtitlesOff
                    // v0.14.30 (owner's note 3b): Off and the header
                    // toggle route through the dedicated actions —
                    // v0.14.29 sent Off down the embedded-track path
                    // (the sidecar kept rendering) and the toggle's
                    // ON half hit the manual-choice latch in
                    // maybeActivateDefaultSidecar, so neither half
                    // visibly did anything.
                    val offAction: () -> Unit = { applySubtitlesOff() }
                    val onToggleSubs: () -> Unit = {
                        if (subsOn) offAction() else reactivateSubtitles()
                    }
                    val compactCard = maxHeight < 500.dp
                    Column(
                        Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 18.dp, end = 18.dp)
                            .width(if (compactCard) 470.dp else 302.dp)
                            // v0.14.31 (item 5): in landscape the card
                            // gives up extra height at the bottom —
                            // the player's bottom capsule (Sources /
                            // Episodes) floats over that band and the
                            // Style step's last rows (the sync helper
                            // text) were sliding under it, cut off.
                            .heightIn(
                                max = maxHeight -
                                    if (compactCard) 88.dp else 28.dp
                            )
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF101018).copy(alpha = 0.93f))
                            .border(
                                1.dp, Color.White.copy(alpha = 0.10f),
                                RoundedCornerShape(22.dp)
                            )
                            .padding(
                                horizontal = 16.dp,
                                vertical = if (compactCard) 10.dp else 14.dp
                            )
                    ) {
                        when (subCardStep) {
                            2 -> {
                                // ---------- Step 2: Files ----------
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SubCardCircleButton(
                                        Icons.Filled.ChevronLeft, "Back"
                                    ) { subCardStep = 1 }
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        activeLang ?: "Subtitles",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    SubOnOffPill(on = subsOn, onClick = onToggleSubs)
                                }
                                Spacer(Modifier.height(10.dp))
                                SubStepDots(step = 2)
                                Spacer(Modifier.height(12.dp))
                                val embeddedCount = if (mpvActive()) {
                                    mpvTracksUi.count {
                                        it.type == "sub" && !it.external &&
                                            panelLangName(it.lang) == activeLang
                                    }
                                } else {
                                    langEmbedded.size
                                }
                                Text(
                                    "${langSubs.size + embeddedCount} subtitles available",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Spacer(Modifier.height(8.dp))
                                // PlavioSubs files carry no names —
                                // they show as "Subtitle 1/2/3",
                                // numbered among this language's
                                // PlavioSubs entries in source order.
                                // Addon/local files keep real labels.
                                val plavioOrdinals = remember(langSubs) {
                                    var n = 0
                                    langSubs.associate { sub ->
                                        sub.url to if (
                                            panelHostLabel(sub.url) == "PlavioSubs"
                                        ) ++n else 0
                                    }
                                }
                                LazyColumn(
                                    Modifier.weight(1f, fill = false),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(langSubs) { sub ->
                                        val resolvedSub =
                                            rawResolvedSubs.firstOrNull { it.sub.url == sub.url }
                                        val host = panelHostLabel(sub.url)
                                        val isPlavio = host == "PlavioSubs"
                                        SubFileRow(
compact = compactCard,
                                            formatTag = panelFormatLabel(
                                                resolvedSub?.mimeType ?: ""
                                            ) ?: if (isPlavio) "SRT" else null,
                                            title = if (isPlavio) {
                                                "Subtitle ${plavioOrdinals[sub.url]}"
                                            } else {
                                                panelFileLabel(sub)
                                            },
                                            sourceChip = host,
                                            detail = listOfNotNull(
                                                panelLangName(sub.lang),
                                                if (sub.url.contains(
                                                        "forced", ignoreCase = true
                                                    )
                                                ) "Forced" else null
                                            ).joinToString(" · "),
                                            selected = selectedSubUrl == sub.url,
                                            onClick = {
                                                panelPickedUrl = sub.url
                                                activatePanelSubtitle(sub)
                                                subCardStep = 3
                                            }
                                        )
                                    }
                                    if (mpvActive()) {
                                        items(
                                            mpvTracksUi.filter {
                                                it.type == "sub" && !it.external &&
                                                    panelLangName(it.lang) == activeLang
                                            }
                                        ) { track ->
                                            SubFileRow(
compact = compactCard,
                                                formatTag = null,
                                                title = track.title
                                                    ?: panelLangName(track.lang),
                                                sourceChip = "Built-in",
                                                detail = activeLang ?: "",
                                                selected = track.selected,
                                                onClick = {
                                                    panelPickedUrl = "built-in"
                                                    applyMpvSubtitleSelection(track)
                                                    subCardStep = 3
                                                }
                                            )
                                        }
                                    } else {
                                        items(langEmbedded) { opt ->
                                            SubFileRow(
compact = compactCard,
                                                formatTag = null,
                                                title = opt.label,
                                                sourceChip = "Built-in",
                                                detail = listOfNotNull(
                                                    activeLang,
                                                    if (opt.label.contains(
                                                            "forced", ignoreCase = true
                                                        )
                                                    ) "Forced" else null
                                                ).joinToString(" · "),
                                                selected = opt.selected,
                                                onClick = {
                                                    panelPickedUrl = "built-in"
                                                    applySubtitleSelection(opt)
                                                    subCardStep = 3
                                                }
                                            )
                                        }
                                    }
                                    // Subtitle switch fix (2026-11-09):
                                    // a pick that is still downloading
                                    // says so, and a pick whose download
                                    // failed says so — the switch is
                                    // never silent.
                                    if (subPickDownloadingLabel != null) {
                                        item {
                                            Text(
                                                "Downloading subtitle…",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 6.dp)
                                            )
                                        }
                                    }
                                    if (subPickFailedLabel != null) {
                                        item {
                                            Text(
                                                "Couldn't load that subtitle — try another file.",
                                                color = Color(0xFFEF4444),
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 6.dp)
                                            )
                                        }
                                    }
                                    if (subSearchLoading) {
                                        item {
                                            Text(
                                                "Searching online…",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 6.dp)
                                            )
                                        }
                                    }
                                    if (langSubs.isEmpty() && langEmbedded.isEmpty() &&
                                        !subSearchLoading
                                    ) {
                                        item { SubFetchRow { openSubtitleSearch() } }
                                    }
                                    if (subLoadError && panelSubs().isEmpty()) {
                                        item {
                                            Text(
                                                "Couldn't load subtitles — check your connection and try again.",
                                                color = Color(0xFFEF4444),
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                    subSearchError?.let { err ->
                                        item {
                                            Text(
                                                err,
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(start = 4.dp)
                                            )
                                        }
                                    }
                                    if (langSubs.isNotEmpty() || langEmbedded.isNotEmpty()) {
                                        item {
                                            TextButton(onClick = { openSubtitleSearch() }) {
                                                Text(
                                                    "Fetch subtitles online",
                                                    color = LocalPalette.current.accent,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                        }
                                    }
                                }
                                val footerHost = when {
                                    langSubs.any {
                                        panelHostLabel(it.url) == "PlavioSubs"
                                    } -> PlavioSubsClient.HOST
                                    langSubs.isNotEmpty() ->
                                        panelHostLabel(langSubs.first().url)
                                    else -> null
                                }
                                if (footerHost != null) {
                                    Spacer(Modifier.height(10.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SubAccentDot()
                                        Spacer(Modifier.width(7.dp))
                                        Text(
                                            "Source · $footerHost",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                            3 -> {
                                // ---------- Step 3: Style ----------
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SubCardCircleButton(
                                        Icons.Filled.ChevronLeft, "Back"
                                    ) { subCardStep = 2 }
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        "Style",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    SubOnOffPill(on = subsOn, onClick = onToggleSubs)
                                }
                                val appliedSub = panelSubs()
                                    .firstOrNull { it.url == selectedSubUrl }
                                val appliedLabel = appliedSub?.let { sub ->
                                    val fileLabel =
                                        if (panelHostLabel(sub.url) == "PlavioSubs") {
                                            val n = panelSubs().filter {
                                                panelLangName(it.lang) ==
                                                    panelLangName(sub.lang) &&
                                                    panelHostLabel(it.url) == "PlavioSubs"
                                            }.indexOfFirst { it.url == sub.url } + 1
                                            "Subtitle $n"
                                        } else {
                                            panelFileLabel(sub)
                                        }
                                    "${panelLangName(sub.lang)} · $fileLabel applied"
                                } ?: if (panelPickedUrl == "built-in") {
                                    "Built-in subtitle applied"
                                } else {
                                    "No subtitle applied"
                                }
                                Spacer(Modifier.height(8.dp))
                                if (compactCard) {
                                    // Landscape: the step dots and the
                                    // applied line share one slim row
                                    // so the style zones keep the
                                    // landscape height.
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SubStepDots(step = 3)
                                        Spacer(Modifier.width(12.dp))
                                        SubAccentDot()
                                        Spacer(Modifier.width(7.dp))
                                        Text(
                                            appliedLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                } else {
                                    SubStepDots(step = 3)
                                    Spacer(Modifier.height(10.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SubAccentDot()
                                        Spacer(Modifier.width(7.dp))
                                        Text(
                                            appliedLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Spacer(Modifier.height(if (compactCard) 8.dp else 12.dp))
                                // The style controls split into the
                                // sample's two zones. In a SHORT frame
                                // (landscape playback — the player's
                                // home) the zones sit SIDE BY SIDE so
                                // the whole step fits the landscape
                                // height at once; in a tall frame they
                                // stack exactly as the sample draws.
                                // Content and order are identical in
                                // both arrangements; the scroll
                                // containers remain only as a safety
                                // net for very short screens.
                                val applyStyleNow: () -> Unit = {
                                    playerView?.let { applySubtitleStyle(it) }
                                }
                                if (compactCard) {
                                    Row(
                                        Modifier.weight(1f, fill = false),
                                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Column(
                                            Modifier
                                                .weight(1f)
                                                .verticalScroll(rememberScrollState())
                                        ) {
                                            SubStyleProminentZone(
                                                settings = settings,
                                                colorState = subColorUiState,
                                                bgState = subBgUiState,
                                                shadeModeState = subShadeModeUiState,
                                                fontSpState = subFontSpUiState,
                                                bottomState = subBottomUiState,
                                                compact = true,
                                                applyStyle = applyStyleNow
                                            )
                                            // v0.14.31 (item 5): breathing
                                            // room at the scroll's end —
                                            // the last row must be fully
                                            // readable, never flush with
                                            // the card's bottom edge.
                                            Spacer(Modifier.height(26.dp))
                                        }
                                        Column(
                                            Modifier
                                                .weight(1f)
                                                .verticalScroll(rememberScrollState())
                                        ) {
                                            SubStyleQuietZone(
                                                settings = settings,
                                                fontFamilyState = subFontFamilyUiState,
                                                edgeState = subEdgeUiState,
                                                edgeColorState = subEdgeColorUiState,
                                                boldState = subBoldUiState,
                                                fontSpState = subFontSpUiState,
                                                colorState = subColorUiState,
                                                bgState = subBgUiState,
                                                shadeModeState = subShadeModeUiState,
                                                bottomState = subBottomUiState,
                                                selectedIsAddon = selectedIsAddon,
                                                offsetOverrideMs = subOffsetOverrideMs,
                                                effectiveOffsetMs = { effectiveSubOffsetMs() },
                                                onSetDelay = { setSubtitleDelay(it) },
                                                onReloadSubtitles = { reloadPanelSubtitles() },
                                                onStartCaptureSync = { startCaptureSync() },
                                                captureCuesState = captureCuesState,
                                                captureLoading = captureLoading,
                                                capturePositionMs = capturePositionMs,
                                                applyStyle = applyStyleNow,
                                                onSynced = {
                                                    pokeIndicator(
                                                        PlayerIndicator.Message(
                                                            "Subtitles synced"
                                                        )
                                                    )
                                                }
                                            )
                                            Spacer(Modifier.height(26.dp))
                                        }
                                    }
                                } else {
                                    Column(
                                        Modifier
                                            .weight(1f, fill = false)
                                            .verticalScroll(rememberScrollState())
                                    ) {
                                        SubStyleProminentZone(
                                            settings = settings,
                                            colorState = subColorUiState,
                                            bgState = subBgUiState,
                                            shadeModeState = subShadeModeUiState,
                                            fontSpState = subFontSpUiState,
                                            bottomState = subBottomUiState,
                                            compact = false,
                                            applyStyle = applyStyleNow
                                        )
                                        Spacer(Modifier.height(16.dp))
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .height(1.dp)
                                                .background(Color.White.copy(alpha = 0.08f))
                                        )
                                        Spacer(Modifier.height(14.dp))
                                        SubStyleQuietZone(
                                            settings = settings,
                                            fontFamilyState = subFontFamilyUiState,
                                            edgeState = subEdgeUiState,
                                            edgeColorState = subEdgeColorUiState,
                                            boldState = subBoldUiState,
                                            fontSpState = subFontSpUiState,
                                            colorState = subColorUiState,
                                            bgState = subBgUiState,
                                            shadeModeState = subShadeModeUiState,
                                            bottomState = subBottomUiState,
                                            selectedIsAddon = selectedIsAddon,
                                            offsetOverrideMs = subOffsetOverrideMs,
                                            effectiveOffsetMs = { effectiveSubOffsetMs() },
                                            onSetDelay = { setSubtitleDelay(it) },
                                            onReloadSubtitles = { reloadPanelSubtitles() },
                                            onStartCaptureSync = { startCaptureSync() },
                                            captureCuesState = captureCuesState,
                                            captureLoading = captureLoading,
                                            capturePositionMs = capturePositionMs,
                                            applyStyle = applyStyleNow,
                                            onSynced = {
                                                pokeIndicator(
                                                    PlayerIndicator.Message(
                                                        "Subtitles synced"
                                                    )
                                                )
                                            }
                                        )
                                        // v0.14.31 (item 5): same
                                        // end-of-scroll breathing room
                                        // as the landscape split.
                                        Spacer(Modifier.height(26.dp))
                                    }
                                }
                            }
                            else -> {
                                // ---------- Step 1: Languages ----------
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Subtitles",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    SubOnOffPill(on = subsOn, onClick = onToggleSubs)
                                    Spacer(Modifier.width(8.dp))
                                    SubCardCircleButton(
                                        Icons.Filled.Close, "Close"
                                    ) { tracksOpen = false }
                                }
                                Spacer(Modifier.height(10.dp))
                                SubStepDots(step = 1)
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    "Choose a language",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Spacer(Modifier.height(8.dp))
                                // Off stays pinned above the list.
                                SubOffRow(
compact = compactCard,
                                    selected = subtitlesOff && panelPickedUrl == null,
                                    modifier = if (isTv) {
                                        Modifier.focusRequester(firstRowFocus)
                                    } else {
                                        Modifier
                                    },
                                    onClick = offAction
                                )
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                        .height(1.dp)
                                        .background(Color.White.copy(alpha = 0.08f))
                                )
                                LazyColumn(
                                    Modifier.weight(1f, fill = false),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    if (sortedLangs.isEmpty() && !subSearchLoading) {
                                        item {
                                            Text(
                                                "No subtitles for this title.",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                        item { SubFetchRow { openSubtitleSearch() } }
                                    }
                                    items(sortedLangs) { (name, count) ->
                                        SubLangRow(
compact = compactCard,
                                            name = name,
                                            count = count,
                                            selected = name == selectedLangName,
                                            onClick = {
                                                panelLang = name
                                                // Subtitle switch fix
                                                // (2026-11-09): tapping a
                                                // language APPLIES it —
                                                // the rendered subtitle
                                                // switches (or starts
                                                // downloading with the
                                                // visible state) — then
                                                // the Files step opens on
                                                // that language as before.
                                                applyLanguagePick(name)
                                                subCardStep = 2
                                            }
                                        )
                                    }
                                    if (subPickDownloadingLabel != null) {
                                        item {
                                            Text(
                                                "Downloading subtitle…",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                    if (subPickFailedLabel != null) {
                                        item {
                                            Text(
                                                "Couldn't load that subtitle — try another file.",
                                                color = Color(0xFFEF4444),
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                    if (subSearchLoading) {
                                        item {
                                            Text(
                                                "Searching online…",
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                    if (subLoadError && panelSubs().isEmpty()) {
                                        item {
                                            Text(
                                                "Couldn't load subtitles — check your connection and try again.",
                                                color = Color(0xFFEF4444),
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                    subSearchError?.let { err ->
                                        item {
                                            Text(
                                                err,
                                                color = TextSecondary,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                                if (plavioSubs.isNotEmpty()) {
                                    Spacer(Modifier.height(10.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SubAccentDot()
                                        Spacer(Modifier.width(7.dp))
                                        Text(
                                            "Subtitles by PlavioSubs",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // In-player subtitle search results.
        // Bottom sheet (not AlertDialog) so the root media/channel-key handler
        // keeps working while it's open (#28).
        if (subSearchOpen) {
            // TV: land D-pad focus on the first result row when results land.
            val firstResultFocus = remember { FocusRequester() }
            LaunchedEffect(isTv, subSearchResults) {
                if (isTv && subSearchResults.isNotEmpty()) {
                    delay(300)
                    runCatching { firstResultFocus.requestFocus() }
                }
            }
            ModalBottomSheet(
                onDismissRequest = { subSearchOpen = false },
                sheetState = rememberModalBottomSheetState(),
                containerColor = Color(0xFF14141F)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp)
                ) {
                    item {
                        Text(
                            "Find subtitles",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }
                    when {
                        subSearchLoading -> item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OrbitDots(modifier = Modifier.size(30.dp))
                                Spacer(Modifier.width(12.dp))
                                Text("Searching subtitle addons…", color = TextSecondary)
                            }
                        }
                        subSearchError != null -> item {
                            Text(
                                subSearchError!!,
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        else -> itemsIndexed(subSearchResults) { index, sub ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .tvFocusRing(RoundedCornerShape(10.dp))
                                    .then(
                                        if (index == 0) Modifier.focusRequester(firstResultFocus)
                                        else Modifier
                                    )
                                    .clickable { addExternalSubtitle(sub) }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        displayLanguage(sub.lang) ?: sub.lang.uppercase(),
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        sub.url.substringAfter("://").take(52),
                                        color = TextSecondary,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // In-player Sources (Design I): full-width banner + tabs + cards.
        if (sourcesOpen) {
            ModalBottomSheet(
                onDismissRequest = { sourcesOpen = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                dragHandle = null,
                containerColor = Color(0xFF14141F)
            ) {
                com.pulsestream.app.ui.screens.player.PlayerSourcesContent(
                    title = currentRequest.title,
                    streams = availableStreams,
                    selectedUrl = currentRequest.streamUrl,
                    loading = streamsLoading,
                    onPick = { switchSource(it) },
                    onDownload = { downloadStream = it },
                    onRetry = { refreshStreamsBackground(currentRequest.type, currentRequest.videoId) },
                    onClose = { sourcesOpen = false },
                    modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f),
                    settings = repository.settings,
                    poster = currentRequest.poster,
                    addonLogos = playerAddonLogos
                )
            }
        }

        // Download confirmation dialog
        downloadStream?.let { stream ->
            com.pulsestream.app.ui.components.DownloadConfirmDialog(
                stream = stream,
                title = currentRequest.title,
                posterUrl = currentRequest.poster,
                onDismiss = { downloadStream = null },
                type = currentRequest.type,
                imdbId = currentRequest.imdbId,
                bundledSubtitles = currentRequest.subtitles,
                repository = repository
            )
        }

        // TEST: YouTube quality picker dialog.
        // Episodes picker for series.
        if (episodesOpen) {
            val episodes = currentRequest.episodes
            val seasons = remember(episodes) { episodes.map { it.season }.distinct().sorted() }
            var selSeason by remember(episodes) { mutableStateOf(currentRequest.season) }
            ModalBottomSheet(
                onDismissRequest = { episodesOpen = false },
                sheetState = rememberModalBottomSheetState(),
                containerColor = Color(0xFF14141F)
            ) {
                Column(Modifier.tvSheetFocus()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                    Text(
                        "Episodes",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        items(seasons, key = { it }) { season ->
                            FilterChip(
                                modifier = Modifier.tvFocusRing(RoundedCornerShape(50)),
                                selected = selSeason == season,
                                onClick = { selSeason = season },
                                label = { Text(if (season == 0) "Specials" else "S$season") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LocalPalette.current.accent.copy(alpha = 0.25f),
                                    selectedLabelColor = TextPrimary,
                                    containerColor = Color.White.copy(alpha = 0.06f),
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }
                }
                val eps = remember(episodes, selSeason) {
                    episodes.filter { it.season == selSeason }
                        .sortedWith(compareBy({ it.episode }, { it.title }))
                }
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 20.dp, end = 20.dp, bottom = 32.dp
                    )
                ) {
                    // Key carries the index like the detail page's
                    // episode rail: an addon serving the same episode
                    // entry twice must not crash the picker with a
                    // duplicate key (PLAVIO-D class).
                    itemsIndexed(eps, key = { index, video -> "${video.id}_$index" }) { _, video ->
                        val selected = video.id == currentRequest.videoId
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (selected) LocalPalette.current.accent.copy(alpha = 0.14f)
                                    else Color.White.copy(alpha = 0.04f)
                                )
                                .clickable { playEpisode(video) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(64.dp, 44.dp).clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.06f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (video.thumbnail != null) {
                                    SafePosterImage(
                                        video.thumbnail, null,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text(
                                        "E${video.episode}",
                                        color = TextSecondary,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${video.episode}. ${video.title}",
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (!video.overview.isNullOrBlank()) {
                                    Text(
                                        video.overview!!,
                                        color = TextSecondary,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            if (selected) {
                                Icon(Icons.Filled.PlayArrow, null, tint = LocalPalette.current.accent)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                            }
            }
        }
    }
}


/**
 * One row of the subtitle overlay's Languages rail (v0.14.5): the
 * selected language is a full WHITE pill with dark text and the track
 * count sits in a circle (the v0.14.3 reference look).
 */
@Composable
private fun RailLanguageRow(
    name: String,
    count: Int?,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color.White else Color.Transparent)
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color.Black else TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (count != null) {
            Box(
                Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (selected) Color.Black else Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "$count",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color.White else Color.Black
                )
            }
        }
    }
}

/** Small white section label above a Style-rail control (v0.14.5). */
@Composable
private fun StyleSectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = TextPrimary
    )
}

/** One 40dp rounded square stepper button (white 8% background). */
@Composable
private fun StyleStepperButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = TextPrimary,
            modifier = Modifier.size(18.dp)
        )
    }
}

/**
 * The Style rail's only numeric control (v0.14.5): [−] value [+] —
 * 40dp rounded buttons flanking a value box (white 6% background,
 * min-width 84dp). No sliders anywhere in the rail.
 */
@Composable
private fun StyleStepper(
    value: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        StyleStepperButton(Icons.Filled.Remove, "Decrease", onMinus)
        Box(
            Modifier
                .widthIn(min = 84.dp)
                .height(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.06f))
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
        }
        StyleStepperButton(Icons.Filled.Add, "Increase", onPlus)
    }
}

/** On/Off chip for the Style rail: accent background when On. */
@Composable
private fun StyleChip(
    label: String,
    on: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalPalette.current
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (on) palette.accent else Color.White.copy(alpha = 0.08f))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (on) palette.accentText else TextPrimary,
            // v0.14.31 (item 5): a chip label NEVER wraps — the
            // Style card's FONT row squeezed "Serif" into a tall
            // circle with the word broken in two ("Ser"/"if").
            // The label stays on one line and the chip sizes to
            // it; the row scrolls sideways instead of squeezing.
            maxLines = 1,
            softWrap = false
        )
    }
}

/** 32dp circular color swatch; the selected one gets a 2dp white border. */
@Composable
private fun StyleSwatch(
    color: Color,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) Color.White else Color.White.copy(alpha = 0.25f),
                CircleShape
            )
            .clickable { onClick() }
            .tvFocusRing(CircleShape)
    )
}

/**
 * One subtitle track card in the player's subtitle panel (v0.14.2):
 * source chip, track name, language/format line, accent check when
 * selected — flat Onyx card like the rest of the app.
 */
@Composable
private fun PanelSubCard(
    chip: String,
    title: String,
    detail: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Color.White else Color(0xFF1B1B1D))
            .border(
                1.dp,
                if (selected) Color.White else Color.White.copy(alpha = 0.09f),
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (selected) Color.Black.copy(alpha = 0.08f)
                        else palette.accent.copy(alpha = 0.18f)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    chip,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color(0xFF111111) else palette.accent,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(5.dp))
            Text(
                title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = if (selected) Color(0xFF111111) else TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (detail.isNotBlank()) {
                Text(
                    detail,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (selected) Color(0xFF555555) else TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Icon(
                Icons.Filled.Check,
                contentDescription = "Selected",
                tint = if (selected) Color.Black else palette.accent,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ---- Subtitle card flow helpers (v0.14.29, owner's approved
// redesign; recoloured v0.14.30, owner's note 2): the stepped
// Languages → Files → Style card's shared pieces. The flow follows
// ONYX like the rest of the app: frosted dark-glass surfaces and
// the picked accent colour (LocalPalette — White by default) for
// every state mark: dots, check discs, step indicator, switches.
// NO brand gradient anywhere in the subtitle UI, and state is
// never carried by glyph whiteness. ----

/** Small accent dot — the flow's "active/on" mark. */
@Composable
private fun SubAccentDot() {
    Box(
        Modifier
            .size(8.dp)
            .background(LocalPalette.current.accent, CircleShape)
    )
}

/** Accent disc with a check — the selected-row mark (the check
 *  takes the palette's accentText, so it stays readable on the
 *  accent: black on the default white accent, white on colours). */
@Composable
private fun SubCheckDisc() {
    val palette = LocalPalette.current
    Box(
        Modifier
            .size(26.dp)
            .background(palette.accent, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Filled.Check,
            contentDescription = "Selected",
            tint = palette.accentText,
            modifier = Modifier.size(15.dp)
        )
    }
}

/** Step indicator: the current step is an accent pill, the rest
 *  are dim dots. */
@Composable
private fun SubStepDots(step: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..3) {
            if (i == step) {
                Box(
                    Modifier
                        .width(22.dp)
                        .height(7.dp)
                        .background(
                            LocalPalette.current.accent,
                            RoundedCornerShape(50)
                        )
                )
            } else {
                Box(
                    Modifier
                        .size(7.dp)
                        .background(Color.White.copy(alpha = 0.22f), CircleShape)
                )
            }
        }
    }
}

/**
 * The card header's On/Off pill: a glass pill whose dot is the
 * Onyx accent while subtitles are on and dim grey while off —
 * the state reads from the dot, never from text/glyph whiteness.
 * Tapping toggles subtitles (same actions as the old popover pill).
 */
@Composable
private fun SubOnOffPill(on: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(50))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(50))
            .padding(horizontal = 11.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (on) {
            Box(
                Modifier
                    .size(8.dp)
                    .background(LocalPalette.current.accent, CircleShape)
            )
        } else {
            Box(
                Modifier
                    .size(8.dp)
                    .background(Color.White.copy(alpha = 0.35f), CircleShape)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            if (on) "On" else "Off",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
    }
}

/** 32dp glass circle button (the card's back chevron and ×). */
@Composable
private fun SubCardCircleButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.07f))
            .clickable { onClick() }
            .tvFocusRing(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = TextPrimary,
            modifier = Modifier.size(18.dp)
        )
    }
}

/** The pinned "Off" row at the top of the Languages step. */
@Composable
private fun SubOffRow(
    selected: Boolean,
    compact: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent
            )
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = if (compact) 6.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // v0.14.30 (item 4): the Block glyph sits in the same
        // 16dp mark slot the language rows use (centred, glyph
        // overflows the slot harmlessly), the label takes the one
        // row-label style (bodyMedium), and the check takes the
        // same fixed 26dp end slot — so Off reads as the first row
        // of the list, aligned with every language under it.
        Box(
            Modifier.width(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Block,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(19.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "Off",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        Box(
            Modifier.width(26.dp),
            contentAlignment = Alignment.Center
        ) {
            if (selected) SubCheckDisc()
        }
    }
}

/** One language row of step 1: name, file-count chip, and — for
 *  the playing language — accent dot + check disc; a chevron
 *  otherwise. */
@Composable
private fun SubLangRow(
    name: String,
    count: Int,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent
            )
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = if (compact) 6.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Fixed-width mark slot (v0.14.30, item 4): the accent dot
        // occupies the same 16dp whether the row is selected or
        // not, so the name column never shifts between rows.
        Box(
            Modifier.width(16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (selected) SubAccentDot()
        }
        Text(
            name,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        // Count chip: a pill that fits its number (a fixed 22dp
        // circle clipped 2–3 digit counts), labelSmall secondary.
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.10f))
                .padding(horizontal = 7.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "$count",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
        }
        Spacer(Modifier.width(8.dp))
        // Fixed-width end slot: check disc or chevron, same 26dp,
        // so the right edge lines up on every row.
        Box(
            Modifier.width(26.dp),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                SubCheckDisc()
            } else {
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/** One file row of step 2: format tag, title + source chip,
 *  detail line, and the accent check disc when applied. */
@Composable
private fun SubFileRow(
    formatTag: String?,
    title: String,
    sourceChip: String,
    detail: String,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (selected) {
                    Color.White.copy(alpha = 0.10f)
                } else {
                    Color.White.copy(alpha = 0.04f)
                }
            )
            .border(
                1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = if (compact) 7.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (formatTag != null) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(7.dp))
                    .background(Color(0xFFF2F2F5))
                    .padding(horizontal = 7.dp, vertical = 5.dp)
            ) {
                Text(
                    formatTag,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF14141C)
                )
            }
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // v0.14.30 (item 4): one row-label size (bodyMedium)
                // and the title takes the row's flexible space, so
                // the source chip can never push it off-layout or be
                // pushed off itself — long file names ellipsise
                // inside their own column.
                Text(
                    title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(7.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .border(
                            1.dp, Color.White.copy(alpha = 0.25f),
                            RoundedCornerShape(50)
                        )
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        sourceChip,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }
            if (detail.isNotBlank()) {
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        // Fixed-width end slot (v0.14.30, item 4): same 26dp
        // column as the language rows.
        Box(
            Modifier.width(26.dp),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                SubCheckDisc()
            } else {
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/** The "fetch online" row shown when a language has no files yet. */
@Composable
private fun SubFetchRow(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.CloudDownload,
            contentDescription = null,
            tint = LocalPalette.current.accent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            "Tap to fetch subtitles",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
    }
}

/** Small caps section label of the Style step. */
@Composable
private fun SubStyleLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = Color.White.copy(alpha = 0.85f)
    )
}

/**
 * None / Shade / Solid selector for the background shade.
 * v0.14.31 (item 3, owner order): a proper CAPSULE — the track
 * is a full pill and the selected segment is a full pill inside
 * it, filled with the picked Onyx accent (its label in
 * accentText), the same selected-state language as the rest of
 * the app. Unselected segments stay transparent on the track.
 */
@Composable
private fun SubShadeSegmented(
    selected: Int,
    compact: Boolean = false,
    onSelect: (Int) -> Unit
) {
    val palette = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(50))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        listOf("None", "Shade", "Solid").forEachIndexed { index, label ->
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (selected == index) {
                            palette.accent
                        } else {
                            Color.Transparent
                        }
                    )
                    .clickable { onSelect(index) }
                    .tvFocusRing(RoundedCornerShape(50))
                    .padding(vertical = if (compact) 6.dp else 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (selected == index) {
                        FontWeight.SemiBold
                    } else {
                        FontWeight.Medium
                    },
                    color = if (selected == index) {
                        palette.accentText
                    } else {
                        TextPrimary
                    },
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

/**
 * The Style step's stepper bar: two end buttons flanking a centred
 * title/subtitle pair, in one glass container (the sample's Size
 * and Position controls). Buttons carry text (A− / A+) or icons
 * (chevrons).
 */
@Composable
private fun SubStepperBar(
    title: String,
    subtitle: String,
    leftText: String? = null,
    rightText: String? = null,
    leftIcon: ImageVector? = null,
    rightIcon: ImageVector? = null,
    compact: Boolean = false,
    onLeft: () -> Unit,
    onRight: () -> Unit
) {
    @Composable
    fun endButton(text: String?, icon: ImageVector?, onClick: () -> Unit) {
        Box(
            Modifier
                .size(width = 46.dp, height = if (compact) 34.dp else 38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.09f))
                .clickable { onClick() }
                .tvFocusRing(RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Text(
                    text ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(14.dp))
            .padding(if (compact) 4.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        endButton(leftText, leftIcon, onLeft)
        Column(
            Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // v0.14.30 (item 4): the stepper's centre value takes
            // the flow's one row-label size (bodyMedium); its unit
            // line stays bodySmall secondary.
            Text(
                title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        endButton(rightText, rightIcon, onRight)
    }
}

/** The EDGE chip of the quiet zone: shows the current edge type;
 *  a tap cycles to the next one. */
@Composable
private fun SubEdgeChip(
    edgeName: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "EDGE",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            maxLines = 1,
            softWrap = false
        )
        Spacer(Modifier.width(8.dp))
        Text(
            edgeName,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            // v0.14.33 (item 4): the value NEVER truncates — the
            // old Ellipsis showed "Outl…" in the narrow landscape
            // column. One line, no wrap; SubEdgeBoldRow guarantees
            // the chip its room (stacked full-width when narrow).
            maxLines = 1,
            softWrap = false
        )
    }
}

/** The BOLD chip of the quiet zone, with the accent switch —
 *  on/off reads from the switch, never from text whiteness. */
@Composable
private fun SubBoldChip(
    checked: Boolean,
    modifier: Modifier = Modifier,
    onToggle: () -> Unit
) {
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.09f), RoundedCornerShape(12.dp))
            .clickable { onToggle() }
            .tvFocusRing(RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "BOLD",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            // v0.14.33 (item 4): the label NEVER wraps — in the
            // narrow landscape column the old weighted label was
            // crushed to a few dp and wrapped letter-by-letter
            // (B/O/L stacked). One line, no wrap, ever.
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.weight(1f)
        )
        // v0.14.31 (item 4): the state word rides beside the
        // switch — with the DEFAULT white accent the old switch
        // was a white track with a white thumb, a plain white
        // pill with no readable on/off face at all.
        Text(
            if (checked) "On" else "Off",
            maxLines = 1,
            softWrap = false,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (checked) {
                LocalPalette.current.accent
            } else {
                TextSecondary
            }
        )
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .width(42.dp)
                .height(24.dp)
                .clip(RoundedCornerShape(50))
                .then(
                    if (checked) {
                        Modifier.background(LocalPalette.current.accent)
                    } else {
                        Modifier.background(Color.White.copy(alpha = 0.15f))
                    }
                )
                .border(
                    1.dp,
                    if (checked) {
                        LocalPalette.current.accent
                    } else {
                        Color.White.copy(alpha = 0.22f)
                    },
                    RoundedCornerShape(50)
                )
        ) {
            Box(
                Modifier
                    .align(
                        if (checked) Alignment.CenterEnd else Alignment.CenterStart
                    )
                    .padding(3.dp)
                    .size(18.dp)
                    .background(
                        // ON: the thumb takes accentText (black on
                        // the white default accent) so the switch
                        // face reads at a glance in every accent;
                        // OFF: the plain white thumb on the grey
                        // track, as before.
                        if (checked) {
                            LocalPalette.current.accentText
                        } else {
                            Color.White
                        },
                        CircleShape
                    )
            )
        }
    }
}

/**
 * The EDGE + BOLD row of the quiet zone (v0.14.33, item 4).
 * Side by side (even split) when the column is wide enough for
 * both chips at full label width; stacked full-width in the
 * narrow landscape split column (~200dp), where the even split
 * gave each chip ~96dp — the BOLD label wrapped letter-by-letter
 * (B/O/L) and the edge value truncated ("Outl…"). Each chip
 * needs ~125–135dp, so 280dp is the side-by-side floor; below
 * it each chip gets the full column width and nothing squeezes.
 * Internal (not private) so the layout is Compose-testable.
 */
@Composable
internal fun SubEdgeBoldRow(
    edgeName: String,
    boldChecked: Boolean,
    onCycleEdge: () -> Unit,
    onToggleBold: () -> Unit
) {
    BoxWithConstraints {
        if (maxWidth >= 280.dp) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubEdgeChip(
                    edgeName = edgeName,
                    modifier = Modifier.weight(1f),
                    onClick = onCycleEdge
                )
                SubBoldChip(
                    checked = boldChecked,
                    modifier = Modifier.weight(1f),
                    onToggle = onToggleBold
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SubEdgeChip(
                    edgeName = edgeName,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onCycleEdge
                )
                SubBoldChip(
                    checked = boldChecked,
                    modifier = Modifier.fillMaxWidth(),
                    onToggle = onToggleBold
                )
            }
        }
    }
}

/** One sync step button of the Style step ("−0.5s" / "+0.5s"). */
@Composable
private fun SubSyncButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .clickable { onClick() }
            .tvFocusRing(RoundedCornerShape(9.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
    }
}


/**
 * The Style step's PROMINENT zone (v0.14.29): Colour, Background
 * shade, Size, Position. Extracted as a top-level composable —
 * the zones originally lived as local lambdas inside the player
 * composable, whose methods they bloated past the point the
 * release compiler could optimise in reasonable time; as separate
 * functions they compile as their own classes. Every control
 * writes the same SettingsStore values the old Style rail wrote
 * and re-applies the style to the live renderer via [applyStyle].
 */
@Composable
private fun SubStyleProminentZone(
    settings: com.pulsestream.app.data.SettingsStore,
    colorState: MutableState<Int>,
    bgState: MutableState<Int>,
    shadeModeState: MutableState<Int>,
    fontSpState: MutableState<Int>,
    bottomState: MutableState<Int>,
    compact: Boolean,
    applyStyle: () -> Unit
) {
    // COLOUR (prominent zone)
    SubStyleLabel("COLOUR")
    Spacer(Modifier.height(7.dp))
    Row(
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        listOf(
            0xFFFFFFFF, 0xFFFFD93B, 0xFF00E5FF,
            0xFF77D98A, 0xFFFF7BAC, 0xFFFFB35C
        ).forEach { c ->
            val rgb = c.toInt()
            StyleSwatch(
                color = Color(rgb),
                selected = (colorState.value and 0x00FFFFFF) ==
                    (rgb and 0x00FFFFFF),
                onClick = {
                    val merged =
                        (colorState.value and
                            0xFF000000.toInt()) or
                            (rgb and 0x00FFFFFF)
                    colorState.value = merged
                    settings.subtitleTextColor = merged
                    applyStyle()
                }
            )
        }
    }
    Spacer(Modifier.height(if (compact) 10.dp else 15.dp))
    // BACKGROUND SHADE: None / Shade /
    // Solid are views of the one
    // stored background ARGB (alpha is
    // the shade), same as Settings.
    SubStyleLabel("BACKGROUND SHADE")
    Spacer(Modifier.height(7.dp))
    val bgAlpha =
        android.graphics.Color.alpha(bgState.value)
    // v0.14.31 (item 2): the mode is the remembered SELECTION
    // (shadeModeState), not a value re-derived from the alpha —
    // the Opacity slider below stays on screen for as long as
    // Shade or Solid is selected, even dragged to 0.
    val shadeMode = shadeModeState.value
    SubShadeSegmented(
        selected = shadeMode,
        compact = compact
    ) { mode ->
        shadeModeState.value = mode
        val rgb = bgState.value and 0x00FFFFFF
        val merged = when (mode) {
            0 -> 0
            2 -> (0xFF shl 24) or rgb
            else -> ((if (bgAlpha in 1..249) {
                bgAlpha
            } else {
                0x99
            }) shl 24) or rgb
        }
        bgState.value = merged
        settings.subtitleBackgroundColor = merged
        applyStyle()
    }
    if (shadeMode != 0) {
        Spacer(Modifier.height(9.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Opacity",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.width(10.dp))
            Slider(
                value = bgAlpha * 100f / 255f,
                onValueChange = { pct ->
                    val a = (pct * 255f / 100f)
                        .roundToInt().coerceIn(0, 255)
                    val merged = (a shl 24) or
                        (bgState.value and 0x00FFFFFF)
                    bgState.value = merged
                    settings.subtitleBackgroundColor =
                        merged
                    applyStyle()
                },
                valueRange = 0f..100f,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "${(bgAlpha * 100 + 127) / 255}%",
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )
        }
    }
    Spacer(Modifier.height(if (compact) 10.dp else 15.dp))
    // SIZE (stepper, stored 12–40 sp)
    SubStyleLabel("SIZE")
    Spacer(Modifier.height(7.dp))
    SubStepperBar(
        // v0.14.31 (item 1): both lines come from the pure
        // formatters in PlayerHelpers — the old subtitle template
        // ("$fontSpState.value sp") interpolated the state OBJECT
        // and printed "MutableIntState(value=19)@…" on screen.
        title = subtitleSizeName(fontSpState.value),
        subtitle = subtitleSizeText(fontSpState.value),
        leftText = "A−",
        rightText = "A+",
        compact = compact,
        onLeft = {
            val v = (fontSpState.value - 2).coerceIn(12, 40)
            fontSpState.value = v
            settings.subtitleFontSizeSp = v
            applyStyle()
        },
        onRight = {
            val v = (fontSpState.value + 2).coerceIn(12, 40)
            fontSpState.value = v
            settings.subtitleFontSizeSp = v
            applyStyle()
        }
    )
    Spacer(Modifier.height(if (compact) 10.dp else 15.dp))
    // POSITION (bottom offset stepper)
    SubStyleLabel("POSITION")
    Spacer(Modifier.height(7.dp))
    val posSteps = bottomState.value / 5
    SubStepperBar(
        title = if (posSteps == 0) "Bottom" else "Raise",
        subtitle = if (posSteps == 0) {
            "lowest position"
        } else {
            "$posSteps steps up"
        },
        leftIcon = Icons.Filled.KeyboardArrowUp,
        rightIcon = Icons.Filled.KeyboardArrowDown,
        compact = compact,
        onLeft = {
            val v = (bottomState.value + 5).coerceIn(0, 200)
            bottomState.value = v
            settings.subtitleBottomOffset = v
            applyStyle()
        },
        onRight = {
            val v = (bottomState.value - 5).coerceIn(0, 200)
            bottomState.value = v
            settings.subtitleBottomOffset = v
            applyStyle()
        }
    )
}

/**
 * The Style step's QUIET zone (v0.14.29): Font, Edge, Bold, Sync,
 * plus the addon-subtitle Reload / Auto-sync tools and Reset —
 * same extraction and same store as [SubStyleProminentZone].
 */
@Composable
private fun SubStyleQuietZone(
    settings: com.pulsestream.app.data.SettingsStore,
    fontFamilyState: MutableState<Int>,
    edgeState: MutableState<Int>,
    edgeColorState: MutableState<Int>,
    boldState: MutableState<Boolean>,
    fontSpState: MutableState<Int>,
    colorState: MutableState<Int>,
    bgState: MutableState<Int>,
    shadeModeState: MutableState<Int>,
    bottomState: MutableState<Int>,
    selectedIsAddon: Boolean,
    offsetOverrideMs: Long,
    effectiveOffsetMs: () -> Long,
    onSetDelay: (Long) -> Unit,
    onReloadSubtitles: () -> Unit,
    onStartCaptureSync: () -> Unit,
    captureCuesState: MutableState<List<Pair<Long, String>>?>,
    captureLoading: Boolean,
    capturePositionMs: Long,
    applyStyle: () -> Unit,
    onSynced: () -> Unit
) {
    // FONT (quiet zone)
    SubStyleLabel("FONT")
    Spacer(Modifier.height(7.dp))
    Row(
        // v0.14.31 (item 5): sideways scroll — in the landscape
        // split the quiet column is ~200dp wide and the four
        // chips need ~310dp; the row used to crush the last
        // chips into tall circles with broken labels.
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        listOf(
            0 to "System", 1 to "Sans",
            2 to "Serif", 3 to "Mono"
        ).forEach { (index, label) ->
            StyleChip(
                label = label,
                on = fontFamilyState.value == index,
                onClick = {
                    fontFamilyState.value = index
                    settings.subtitleFontFamily = index
                    applyStyle()
                }
            )
        }
    }
    Spacer(Modifier.height(12.dp))
    // EDGE (tap cycles the stored edge type) + BOLD (accent
    // switch — state never by whiteness). The row itself lives
    // in SubEdgeBoldRow: side by side when the column is wide,
    // stacked full-width in the narrow landscape column so the
    // labels never squeeze (v0.14.33, item 4).
    SubEdgeBoldRow(
        edgeName = listOf(
            "None", "Outline", "Shadow",
            "Raised", "Depressed"
        )[edgeState.value],
        boldChecked = boldState.value,
        onCycleEdge = {
            val next = (edgeState.value + 1) % 5
            edgeState.value = next
            settings.subtitleEdgeType = next
            applyStyle()
        },
        onToggleBold = {
            val on = !boldState.value
            boldState.value = on
            settings.subtitleBold = on
            applyStyle()
        }
    )
    Spacer(Modifier.height(12.dp))
    // SYNC (per-title delay, ±0.5 s)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(
                1.dp, Color.White.copy(alpha = 0.09f),
                RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "SYNC",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )
        Spacer(Modifier.weight(1f))
        SubSyncButton("−0.5s") {
            onSetDelay(offsetOverrideMs - 500L)
        }
        Text(
            String.format(
                java.util.Locale.US, "%+.1fs",
                effectiveOffsetMs() / 1000.0
            ),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        SubSyncButton("+0.5s") {
            onSetDelay(offsetOverrideMs + 500L)
        }
    }
    Text(
        "Steps of 0.5s. Applies to downloaded subtitles — embedded tracks inside the video file can't be shifted.",
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary,
        modifier = Modifier.padding(top = 6.dp)
    )
    if (selectedIsAddon) {
        Spacer(Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextButton(
                onClick = { onReloadSubtitles() },
                contentPadding = PaddingValues(
                    horizontal = 4.dp, vertical = 2.dp
                )
            ) {
                Text(
                    "Reload",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            TextButton(
                onClick = { onStartCaptureSync() },
                contentPadding = PaddingValues(
                    horizontal = 4.dp, vertical = 2.dp
                )
            ) {
                Text(
                    if (captureLoading) {
                        "Loading…"
                    } else {
                        "Auto sync"
                    },
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        captureCuesState.value?.let { cues ->
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Tap the line you hear now",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = { captureCuesState.value = null }
                ) {
                    Text(
                        "Cancel",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            cues.forEach { (startMs, cueText) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Color.White.copy(alpha = 0.06f)
                        )
                        .clickable {
                            onSetDelay(
                                capturePositionMs - startMs -
                                    300L -
                                    settings.subtitleOffsetMs
                            )
                            onSynced()
                        }
                        .padding(
                            horizontal = 10.dp,
                            vertical = 8.dp
                        ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        String.format(
                            java.util.Locale.US,
                            "%d:%02d",
                            startMs / 60000,
                            (startMs / 1000) % 60
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = LocalPalette.current.accent
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        cueText,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    TextButton(
        onClick = {
            onSetDelay(0L)
            fontSpState.value = 18
            settings.subtitleFontSizeSp = 18
            boldState.value = false
            settings.subtitleBold = false
            colorState.value = 0xFFFFFFFF.toInt()
            settings.subtitleTextColor = 0xFFFFFFFF.toInt()
            settings.subtitleBackgroundColor =
                android.graphics.Color.TRANSPARENT
            bgState.value = android.graphics.Color.TRANSPARENT
            // v0.14.31 (item 2): Reset also returns the shade
            // MODE selection to None, so the Opacity row hides
            // here — by the user's own tap, never automatically.
            shadeModeState.value = 0
            fontFamilyState.value = 0
            settings.subtitleFontFamily = 0
            edgeState.value = 1
            settings.subtitleEdgeType = 1
            edgeColorState.value = 0xFF000000.toInt()
            settings.subtitleEdgeColor = 0xFF000000.toInt()
            bottomState.value = 20
            settings.subtitleBottomOffset = 20
            applyStyle()
        },
        contentPadding = PaddingValues(
            horizontal = 4.dp, vertical = 2.dp
        )
    ) {
        Text(
            "Reset defaults",
            color = TextSecondary,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
