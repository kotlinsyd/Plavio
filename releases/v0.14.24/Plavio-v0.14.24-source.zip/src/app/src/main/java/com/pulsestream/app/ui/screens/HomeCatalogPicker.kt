package com.pulsestream.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.pulsestream.app.data.CatalogRef
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Picker → Home reload signal (v0.14.14): bumped when the catalog
 * picker closes after a change; HomeScreen collects it and reloads
 * its rows from the (filtered) cache. Same counter pattern as
 * [HomeScrollSignal].
 */
object HomeCatalogSignal {
    val requests = MutableStateFlow(0)
    fun requestReload() {
        requests.value += 1
    }
}

/**
 * Press-and-hold Home → "Home catalogs" picker. v0.14.15 (owner
 * correction): the sheet is PROVIDER-FIRST. The top section,
 * "Meta provider", picks WHICH metadata addon fills Home
 * (single-select, persisted in SettingsStore; the default meta
 * addon — PlavioMeta by rank — is pre-selected so existing users
 * see no change). Below it, the same per-catalog list as v0.14.14,
 * but only for the selected provider: per-catalog checkboxes keyed
 * addonId|catalogId in SettingsStore, with the addon's `showOnHome`
 * flag as the fallback default.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeCatalogPickerSheet(
    repository: StreamRepository,
    onDismiss: () -> Unit
) {
    val settings = repository.settings
    var choices by remember {
        mutableStateOf<List<StreamRepository.HomeCatalogChoice>>(emptyList())
    }
    var loaded by remember { mutableStateOf(false) }
    // The provider whose catalogs the list below shows.
    var providerId by remember { mutableStateOf<String?>(null) }
    // Local mirror of the tick state so rows update instantly; every
    // change is written straight to SettingsStore as well.
    var ticks by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var changed by remember { mutableStateOf(false) }
    val pickerListState = rememberLazyListState()
    // The selected provider's catalogs in EFFECTIVE order (v0.14.15):
    // the owner's saved arrangement first, unsaved catalogs in their
    // natural (manifest) order after — the same merge Home renders
    // with (StreamRepository.applyHomeCatalogOrder). Reordering this
    // list IS arranging Home: the first row here is Home's top row.
    var orderedCatalogs by remember { mutableStateOf<List<CatalogRef>>(emptyList()) }
    // Press-and-hold drag state (v0.14.15): the catalog key being
    // dragged and its finger offset from its current slot.
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragDeltaY by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val loadedChoices = runCatching { repository.homeCatalogChoices() }
            .getOrDefault(emptyList())
        choices = loadedChoices
        providerId = runCatching { repository.homeMetaProviderId() }.getOrNull()
            ?: loadedChoices.firstOrNull()?.addonId
        ticks = loadedChoices.flatMap { choice ->
            choice.catalogs.map { catalog ->
                "${choice.addonId}|${catalog.type}|${catalog.id}" to settings.isCatalogOnHome(
                    choice.addonId, catalog.id, choice.addonShowOnHome, catalog.type
                )
            }
        }.toMap()
        loaded = true
    }

    val selected = choices.firstOrNull { it.addonId == providerId }

    // (Re)derive the display order whenever the provider (or the
    // loaded choices) changes: saved arrangement first, then the
    // rest in natural order. A completed drag writes straight back
    // to SettingsStore, so re-deriving never loses an arrangement.
    LaunchedEffect(providerId, choices) {
        val choice = choices.firstOrNull { it.addonId == providerId }
            ?: return@LaunchedEffect
        val saved = settings.homeCatalogOrder
        val rank = saved.withIndex().associate { (index, key) -> key to index }
        val (arranged, natural) = choice.catalogs.partition {
            "${choice.addonId}|${it.type}|${it.id}" in rank
        }
        orderedCatalogs = arranged.sortedBy {
            rank.getValue("${choice.addonId}|${it.type}|${it.id}")
        } + natural
    }

    /**
     * Drag maths for the catalog rows (v0.14.15): the dragged row
     * follows the finger via [dragDeltaY]; when its centre crosses
     * into a neighbouring catalog row's slot, the two swap in
     * [orderedCatalogs] and the slot jump is absorbed into
     * [dragDeltaY] so the row stays glued to the finger. Only
     * catalog rows of the selected provider are valid targets —
     * provider rows and headers never move.
     */
    fun onCatalogDrag(amountY: Float) {
        val key = draggingKey ?: return
        val choice = selected ?: return
        dragDeltaY += amountY
        val visible = pickerListState.layoutInfo.visibleItemsInfo
        val dragged = visible.firstOrNull { it.key == key } ?: return
        val center = dragged.offset + dragDeltaY + dragged.size / 2f
        val catalogKeys = orderedCatalogs.mapTo(HashSet()) {
            "${choice.addonId}|${it.type}|${it.id}"
        }
        val target = visible.firstOrNull { info ->
            info.key != key && info.key in catalogKeys &&
                center >= info.offset && center < info.offset + info.size
        } ?: return
        val fromIndex = orderedCatalogs.indexOfFirst {
            "${choice.addonId}|${it.type}|${it.id}" == key
        }
        val toIndex = orderedCatalogs.indexOfFirst {
            "${choice.addonId}|${it.type}|${it.id}" == target.key
        }
        if (fromIndex < 0 || toIndex < 0 || fromIndex == toIndex) return
        val mutable = orderedCatalogs.toMutableList()
        mutable.add(toIndex, mutable.removeAt(fromIndex))
        orderedCatalogs = mutable
        dragDeltaY += (dragged.offset - target.offset).toFloat()
    }

    /**
     * Saves the arrangement on drop: this provider's catalogs in
     * their new picker order, ahead of any saved keys belonging to
     * other addons (kept in their previous relative order, so
     * switching providers never loses the other provider's order).
     */
    fun persistCatalogOrder() {
        val choice = selected ?: return
        val mine = orderedCatalogs.map { "${choice.addonId}|${it.type}|${it.id}" }
        val others = settings.homeCatalogOrder.filter { it !in mine }
        settings.homeCatalogOrder = mine + others
        changed = true
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = {
            if (changed) HomeCatalogSignal.requestReload()
            onDismiss()
        },
        sheetState = sheetState
    ) {
        Column(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(
                    "Home catalogs",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "Pick the addon that fills your Home screen, then tick its catalogs. " +
                        "Press and hold a catalog and slide it up or down to set its place on Home.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(
                state = pickerListState,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                if (!loaded) {
                    item(key = "loading") {
                        Text(
                            "Loading catalogs…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
                        )
                    }
                } else if (choices.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            "No catalog addons installed yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
                        )
                    }
                }
                if (loaded && choices.isNotEmpty()) {
                    item(key = "provider_header") {
                        Text(
                            "Meta provider",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            modifier = Modifier.padding(
                                start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp
                            )
                        )
                    }
                    items(choices, key = { "provider_${it.addonId}" }) { choice ->
                        val isProvider = choice.addonId == providerId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (!isProvider) {
                                        settings.homeMetaProviderAddonId = choice.addonId
                                        providerId = choice.addonId
                                        changed = true
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isProvider,
                                onClick = {
                                    if (!isProvider) {
                                        settings.homeMetaProviderAddonId = choice.addonId
                                        providerId = choice.addonId
                                        changed = true
                                    }
                                },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = Color.White,
                                    unselectedColor = TextSecondary
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                choice.addonName,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (isProvider) TextPrimary else TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "${choice.catalogs.size} catalogs",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                    }
                }
                if (selected != null) {
                    val total = selected.catalogs.size
                    val onCount = selected.catalogs.count {
                        ticks["${selected.addonId}|${it.id}"] == true
                    }
                    item(key = "group_${selected.addonId}") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 20.dp, end = 8.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    selected.addonName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Text(
                                    "$onCount of $total catalogs on Home",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            TextButton(onClick = {
                                settings.setAllCatalogsOnHomeTyped(
                                    selected.addonId,
                                    selected.catalogs.map { it.type to it.id }, true
                                )
                                ticks = ticks + selected.catalogs.associate {
                                    "${selected.addonId}|${it.type}|${it.id}" to true
                                }
                                changed = true
                            }) { Text("All") }
                            TextButton(onClick = {
                                settings.setAllCatalogsOnHomeTyped(
                                    selected.addonId,
                                    selected.catalogs.map { it.type to it.id }, false
                                )
                                ticks = ticks + selected.catalogs.associate {
                                    "${selected.addonId}|${it.type}|${it.id}" to false
                                }
                                changed = true
                            }) { Text("None") }
                        }
                    }
                    // v0.14.19 (PLAVIO-H): the lazy key MUST carry
                    // the type — Cinemeta declares catalog id "top"
                    // for BOTH movie and series, so the old 2-part
                    // key rendered two rows with the identical key
                    // "…|top" and crashed the screen the moment the
                    // provider radio switched to Cinemeta (100%
                    // repro: hold Home → switch PMeta → Cinemeta).
                    // P15 (v0.14.22): the ticks/visibility map below is
                    // keyed by the same type-carrying identity —
                    // catalog visibility is per (addonId, type,
                    // catalogId), so Cinemeta's Movies-"Top" and
                    // Series-"Top" are independent switches.
                    items(
                        orderedCatalogs,
                        key = { "${selected.addonId}|${it.type}|${it.id}" }
                    ) { catalog ->
                        val key = "${selected.addonId}|${catalog.type}|${catalog.id}"
                        val on = ticks[key] == true
                        val isDragged = draggingKey == key
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                // Lift (v0.14.15): the held row rides
                                // the finger with a shadow; the other
                                // rows animate aside to show the gap it
                                // will land in.
                                .then(
                                    if (isDragged) Modifier
                                        .zIndex(1f)
                                        .graphicsLayer {
                                            translationY = dragDeltaY
                                            shadowElevation = 16.dp.toPx()
                                            alpha = 0.95f
                                        }
                                    else Modifier.animateItem()
                                )
                                .catalogReorderDrag(
                                    key = key,
                                    onDragStart = {
                                        draggingKey = key
                                        dragDeltaY = 0f
                                    },
                                    onDrag = { amount -> onCatalogDrag(amount) },
                                    onDragEnd = {
                                        if (draggingKey == key) persistCatalogOrder()
                                        draggingKey = null
                                        dragDeltaY = 0f
                                    }
                                )
                                .clickable {
                                    val next = !on
                                    settings.setCatalogOnHome(selected.addonId, catalog.id, next, catalog.type)
                                    ticks = ticks + (key to next)
                                    changed = true
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = on,
                                onCheckedChange = { next ->
                                    settings.setCatalogOnHome(selected.addonId, catalog.id, next, catalog.type)
                                    ticks = ticks + (key to next)
                                    changed = true
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color.White,
                                    checkmarkColor = Color.Black,
                                    uncheckedColor = TextSecondary
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                catalog.name,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (on) TextPrimary else TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                catalog.type.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * DRAG TRIGGER (v0.14.15, owner's final call): press-and-hold the
 * picker ROW ITSELF, then slide it up or down — there is deliberately
 * NO drag handle. [detectDragGesturesAfterLongPress] in this one
 * modifier is the single trigger point for catalog arrangement; the
 * reorder maths lives in HomeCatalogPickerSheet (onCatalogDrag /
 * persistCatalogOrder). If the trigger ever changes, it changes HERE
 * only. A plain touch never starts a drag, so the sheet's list still
 * scrolls normally and taps still toggle the tick.
 */
private fun Modifier.catalogReorderDrag(
    key: Any,
    onDragStart: () -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit
): Modifier = pointerInput(key) {
    detectDragGesturesAfterLongPress(
        onDragStart = { onDragStart() },
        onDrag = { change, dragAmount ->
            change.consume()
            onDrag(dragAmount.y)
        },
        onDragEnd = onDragEnd,
        onDragCancel = onDragEnd
    )
}
