package com.pulsestream.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pulsestream.app.data.SettingsStore
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.data.trakt.TraktManager
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Folded-entry contents for Trakt and Simkl (v0.14.6): each service is
 * ONE entry in Settings → Integrations that unfolds inline — link
 * state, what syncs, and the unlink action all live inside the fold.
 * Auth flows: both services use authorization code + PKCE with a
 * pasted code (Simkl moved off the PIN flow in v0.14.11 — Simkl
 * hard-blocks /oauth/pin for OAuth2-type apps like ours).
 */
@Composable
fun TraktFoldContent(settings: SettingsStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val palette = LocalPalette.current
    val trakt = remember { TraktManager(settings) }
    var traktTick by remember { mutableIntStateOf(0) }
    var showTraktDialog by remember { mutableStateOf(false) }
    var traktPkce by remember { mutableStateOf<TraktApi.Pkce?>(null) }
    var traktCode by remember { mutableStateOf("") }
    var traktError by remember { mutableStateOf<String?>(null) }
    var traktBusy by remember { mutableStateOf(false) }
    var showTraktLogoutDialog by remember { mutableStateOf(false) }

    fun startTraktLogin() {
        traktError = null
        traktCode = ""
        traktBusy = false
        val pkce = trakt.newPkce()
        traktPkce = pkce
        showTraktDialog = true
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(trakt.authorizeUrl(pkce)))
        )
    }

    fun submitTraktCode() {
        val pkce = traktPkce ?: return
        val code = traktCode.trim()
        if (code.isEmpty()) {
            traktError = "Paste the code shown on the Trakt page."
            return
        }
        traktBusy = true
        traktError = null
        scope.launch {
            val ok = withContext(Dispatchers.IO) { trakt.loginWithCode(code, pkce.verifier) }
            traktBusy = false
            if (ok) {
                traktTick++
                showTraktDialog = false
                traktPkce = null
                traktCode = ""
            } else {
                traktError = "That code didn't work. Try linking again."
            }
        }
    }

    val linked = remember(traktTick) { trakt.isLoggedIn }
    val linkedName = remember(traktTick) { trakt.username }

    Text(
        text = if (linked) {
            "Linked as ${linkedName ?: "Trakt user"}. Your watchlist, personal lists " +
                "and watched marks sync between Plavio and Trakt."
        } else {
            "Sync your watchlist, personal lists and watched marks with Trakt."
        },
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
    )
    Spacer(Modifier.height(12.dp))
    if (linked) {
        OutlinedButton(
            onClick = { showTraktLogoutDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Unlink Trakt", color = Color(0xFFF87171)) }
    } else {
        Button(
            onClick = { startTraktLogin() },
            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Link Trakt", color = palette.accentText) }
    }

    if (showTraktDialog) {
        TraktCodeDialog(
            code = traktCode,
            onCodeChange = { traktCode = it },
            error = traktError,
            busy = traktBusy,
            onReopen = {
                traktPkce?.let {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(trakt.authorizeUrl(it))))
                }
            },
            onSubmit = { submitTraktCode() },
            onDismiss = {
                showTraktDialog = false
                traktPkce = null
                traktCode = ""
                traktError = null
            }
        )
    }

    if (showTraktLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showTraktLogoutDialog = false },
            title = { Text("Unlink Trakt?", color = TextPrimary) },
            text = {
                Text(
                    "Plavio will stop syncing your watchlist, lists and watched marks to Trakt.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    trakt.logout()
                    traktTick++
                    showTraktLogoutDialog = false
                }) { Text("Unlink", color = palette.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showTraktLogoutDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = Color(0xFF14141F)
        )
    }
}

@Composable
fun SimklFoldContent(settings: SettingsStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val palette = LocalPalette.current
    val simkl = remember { SimklManager(settings) }
    var simklTick by remember { mutableIntStateOf(0) }
    var showSimklDialog by remember { mutableStateOf(false) }
    var simklPkce by remember { mutableStateOf<SimklApi.Pkce?>(null) }
    var simklCode by remember { mutableStateOf("") }
    var simklError by remember { mutableStateOf<String?>(null) }
    var simklBusy by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    fun startSimklLogin() {
        simklError = null
        simklCode = ""
        simklBusy = false
        val pkce = simkl.newPkce()
        simklPkce = pkce
        showSimklDialog = true
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(simkl.authorizeUrl(pkce)))
        )
    }

    fun submitSimklCode() {
        val pkce = simklPkce ?: return
        val code = when (val pasted = simkl.codeFromPaste(simklCode, pkce.state)) {
            is SimklManager.PastedCode.Code -> pasted.value
            SimklManager.PastedCode.StateMismatch -> {
                simklError = "That code belongs to a different linking attempt. Please start again."
                return
            }
            SimklManager.PastedCode.Empty -> {
                simklError = "Paste the code shown on the Simkl page."
                return
            }
        }
        simklBusy = true
        simklError = null
        scope.launch {
            val outcome = withContext(Dispatchers.IO) { simkl.loginWithCode(code, pkce.verifier) }
            simklBusy = false
            when (outcome) {
                SimklManager.LoginOutcome.Ok -> {
                    simklTick++
                    showSimklDialog = false
                    simklPkce = null
                    simklCode = ""
                }
                is SimklManager.LoginOutcome.SimklError -> {
                    // Simkl's own words (its `message` field), verbatim.
                    simklError = outcome.message
                }
                SimklManager.LoginOutcome.NetworkError -> {
                    simklError = "Couldn't reach Simkl. Check your connection and try again."
                }
            }
        }
    }

    val linked = remember(simklTick) { simkl.isLoggedIn }
    val linkedName = remember(simklTick) { simkl.username }

    Text(
        text = if (linked) {
            "Linked as ${linkedName ?: "Simkl user"}. Your library — Watching, Plan to Watch, " +
                "On Hold, Completed, Dropped — and watched marks sync with Simkl."
        } else {
            "Keep your library in five statuses — Watching, Plan to Watch, On Hold, " +
                "Completed, Dropped — synced with Simkl."
        },
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary
    )
    Spacer(Modifier.height(12.dp))
    if (linked) {
        OutlinedButton(
            onClick = { showLogoutDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Unlink Simkl", color = Color(0xFFF87171)) }
    } else {
        Button(
            onClick = { startSimklLogin() },
            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Link Simkl", color = palette.accentText) }
    }

    if (showSimklDialog) {
        SimklCodeDialog(
            code = simklCode,
            onCodeChange = { simklCode = it },
            error = simklError,
            busy = simklBusy,
            onReopen = {
                simklPkce?.let {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(simkl.authorizeUrl(it))))
                }
            },
            onSubmit = { submitSimklCode() },
            onDismiss = {
                showSimklDialog = false
                simklPkce = null
                simklCode = ""
                simklError = null
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Unlink Simkl?", color = TextPrimary) },
            text = {
                Text(
                    "Plavio will stop syncing your library and watched marks to Simkl.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    simkl.logout()
                    simklTick++
                    showLogoutDialog = false
                }) { Text("Unlink", color = palette.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = Color(0xFF14141F)
        )
    }
}

/** Dialog for pasting the Trakt authorization code shown on the callback page. */
@Composable
fun TraktCodeDialog(
    code: String,
    onCodeChange: (String) -> Unit,
    error: String?,
    busy: Boolean,
    onReopen: () -> Unit,
    onSubmit: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Link Trakt", color = TextPrimary) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Approve Plavio in the browser, then paste the code shown on the page below.",
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = onCodeChange,
                    label = { Text("Trakt code") },
                    singleLine = true,
                    enabled = !busy,
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedLabelColor = LocalPalette.current.accent,
                        unfocusedLabelColor = TextSecondary,
                        focusedIndicatorColor = LocalPalette.current.accent,
                        unfocusedIndicatorColor = TextSecondary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = Color(0xFFF87171), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                if (busy) {
                    Spacer(Modifier.height(12.dp))
                    Text("Linking…", color = TextSecondary)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onSubmit, enabled = !busy) {
                Text("Link", color = LocalPalette.current.accent)
            }
        },
        dismissButton = {
            androidx.compose.foundation.layout.Row {
                TextButton(onClick = onReopen) {
                    Text("Reopen page", color = TextSecondary)
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        },
        containerColor = Color(0xFF14141F)
    )
}

/** Dialog for pasting the Simkl authorization code shown on the callback page. */
@Composable
fun SimklCodeDialog(
    code: String,
    onCodeChange: (String) -> Unit,
    error: String?,
    busy: Boolean,
    onReopen: () -> Unit,
    onSubmit: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Link Simkl", color = TextPrimary) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Approve Plavio in the browser, then paste the code shown on the page below.",
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = onCodeChange,
                    label = { Text("Simkl code") },
                    singleLine = true,
                    enabled = !busy,
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedLabelColor = LocalPalette.current.accent,
                        unfocusedLabelColor = TextSecondary,
                        focusedIndicatorColor = LocalPalette.current.accent,
                        unfocusedIndicatorColor = TextSecondary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = Color(0xFFF87171), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                if (busy) {
                    Spacer(Modifier.height(12.dp))
                    Text("Linking…", color = TextSecondary)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onSubmit, enabled = !busy) {
                Text("Link", color = LocalPalette.current.accent)
            }
        },
        dismissButton = {
            androidx.compose.foundation.layout.Row {
                TextButton(onClick = onReopen) {
                    Text("Reopen page", color = TextSecondary)
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        },
        containerColor = Color(0xFF14141F)
    )
}
