package com.pulsestream.app.data

import com.pulsestream.app.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import com.pulsestream.app.data.db.AppDatabase
import com.pulsestream.app.data.db.CatalogCache
import com.pulsestream.app.data.db.CustomList
import com.pulsestream.app.data.db.WatchedRecord
import com.pulsestream.app.data.db.CustomListItem
import com.pulsestream.app.data.db.InstalledAddon
import com.pulsestream.app.data.db.MetaCacheEntry
import com.pulsestream.app.data.db.PlaybackState
import com.pulsestream.app.data.db.FavoriteItem
import com.pulsestream.app.data.db.SubtitleCache
import com.pulsestream.app.data.db.TitleStatusItem
import com.pulsestream.app.data.db.WatchlistItem
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.simkl.SimklManager
import com.pulsestream.app.data.trakt.TraktApi
import com.pulsestream.app.data.trakt.TraktManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import androidx.room.withTransaction
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.flow.last
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.TimeoutCancellationException
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/**
 * Single source of truth: Room for persistence, StremioApi for network,
 * in-memory caches for catalogs (search) and the pending playback request (navigation).
 */

/**
 * Outcome of an add-by-URL install (v0.14.36, defect 2):
 * [alreadyInstalled] is true when the addon's identity
 * ([AddonIdentity]) matched an installed row and the install
 * UPDATED that row in place — callers must be able to tell the
 * user plainly instead of letting it look like a fresh install
 * (or, worse, a second copy).
 */
data class AddonInstallOutcome(
    val addon: InstalledAddon,
    val alreadyInstalled: Boolean
)

/** Outcome of a manual per-addon manifest refresh. */
sealed interface AddonRefreshOutcome {
    data class Updated(val oldVersion: String, val newVersion: String) : AddonRefreshOutcome
    data class UpToDate(val version: String) : AddonRefreshOutcome
}

data class BackupPreview(val version: Int, val addonCount: Int, val watchlistCount: Int,
                         val playbackCount: Int, val customListCount: Int, val customListItemCount: Int)

class StreamRepository(
    private val db: AppDatabase,
    val api: StremioApi,
    val settings: SettingsStore
) {
    // v0.14.36 (defect 2): read-time dedupe by addon identity as a
    // safety net — rows that share one identity (manifest id +
    // normalised origin) collapse to the first, whatever wrote them.
    val addons: Flow<List<InstalledAddon>> =
        db.addonDao().observeAll().map { AddonIdentity.dedupeInstalled(it) }

    /**
     * Session cache of merged addon stream results, keyed by title. A
     * reopen shows the cached list instantly while streamResultsFlow
     * re-fetches and replaces it as fresh results land — entries live a
     * few minutes, in memory only, and die with the app (his dead-link
     * concern, 2026-10-24: the cache never blocks the refresh).
     * v0.14.36 (defect 1): the cached payloads carry formatter-composed
     * text, so this cache is also cleared by [invalidateAddonCaches] —
     * any addon add/refresh/remove/enable/disable busts it, and the
     * Addons page's quiet auto-refresh therefore syncs stream text the
     * same way it already syncs logos and versions. The seed rules
     * themselves live in [StreamCacheSupport].
     */
    private val streamResultCache =
        java.util.concurrent.ConcurrentHashMap<String, Pair<Long, StreamResult>>()

    /**
     * Session-scope ranked-search cache (v0.14.27): the final union of
     * a settled query seeds the instant display of the same query and
     * of prefix-related queries while their fresh lanes run. In memory
     * only, short TTL, bounded — see [SearchSupport.cacheSeed].
     */
    private val searchQueryCache =
        java.util.concurrent.ConcurrentHashMap<String, SearchSupport.QueryCacheEntry>()

    /**
     * Cold-title patience (v0.14.24): addon legs that ended by TIMEOUT,
     * per title key ("type|videoId") from the most recent collect. A
     * timeout is not an empty answer — a first-party cold fill can
     * legitimately outlast the standard budget — so the next collect
     * for the same title (the Detail confirmation pass) re-asks those
     * legs with the extended budget instead of re-running the same
     * too-short clock and settling on a false "No stream available".
     * v0.14.25: legs whose last answer was still-filling (marked) when
     * their budget expired ride this same map — a marked answer is
     * provisional, never an empty answer.
     */
    private val timedOutLegs =
        java.util.concurrent.ConcurrentHashMap<String, Set<String>>()

    private fun timedOutLegsFor(titleKey: String): Set<String> =
        timedOutLegs[titleKey].orEmpty()

    private fun noteTimedOutLegs(titleKey: String, addonIds: Set<String>) {
        if (addonIds.isEmpty()) timedOutLegs.remove(titleKey)
        else timedOutLegs[titleKey] = addonIds
        // Bounded like the result cache: only recent titles matter.
        while (timedOutLegs.size > 64) {
            timedOutLegs.remove(timedOutLegs.keys.firstOrNull() ?: break)
        }
    }

    /** Per-leg network budget for one stream fetch (v0.14.24). */
    private fun streamBudgetMs(addon: InstalledAddon, timedOut: Set<String>): Long = when {
        addon.baseUrl.toHttpUrlOrNull()?.host == StremioApi.FIRST_PARTY_HOST ->
            FIRST_PARTY_STREAM_TIMEOUT_MS
        addon.id in timedOut -> FIRST_PARTY_STREAM_TIMEOUT_MS
        else -> STREAM_FETCH_TIMEOUT_MS
    }

    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        // Keep the process-wide watched set current for poster/episode pills.
        repoScope.launch {
            try {
                db.watchedDao().observeKeys().collect { keys ->
                    WatchedMarks.keys.value = keys.toSet()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalStateException) {
                // v0.14.19 (PLAVIO-K): a worker-owned repository's DB
                // can be closed under this collector (see shutdown())
                // — a closed pool ends the collection quietly instead
                // of surfacing as a crash in WatchedDao.
            }
        }
    }

    /**
     * v0.14.19 (PLAVIO-K): cancels this repository's long-lived
     * coroutines. The background workers (EpisodeCheckWorker,
     * MovieReleaseWorker) each build their OWN AppDatabase +
     * repository and close the DB when done; the init collector above
     * kept querying the closed pool ("connection pool has been
     * closed"). Workers call this BEFORE db.close(). The app
     * singleton never calls it — its DB lives for the process.
     */
    /**
     * Account-deletion wipe (v0.14.27, batch N5): every Room table
     * — library, progress, addons, custom lists, download metadata,
     * across ALL profiles — plus the whole settings store and this
     * repository's in-memory caches. Downloaded FILES are deleted
     * by the caller (they live outside the database and need a
     * Context path).
     */
    suspend fun wipeLocalData() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        settings.wipeAll()
        streamResultCache.clear()
        searchQueryCache.clear()
        timedOutLegs.clear()
    }

    fun shutdown() {
        repoScope.cancel()
        catalogRefreshScope.cancel()
    }
    val continueWatching: Flow<List<PlaybackState>> =
        db.playbackDao().observeRecent().map { dedupePlaybackRows(it) }
    val watchlist: Flow<List<WatchlistItem>> = db.watchlistDao().observeAll()
    val favorites: Flow<List<FavoriteItem>> = db.favoriteDao().observeAll()
    val titleStatuses: Flow<List<TitleStatusItem>> = db.titleStatusDao().observeAll()

    /** In-memory cache of every catalog item loaded on Home — used for search. */
    @Volatile
    var catalogCache: List<CachedMeta> = emptyList()
        private set

    /** In-memory handoff for the player screen (avoids stuffing long URLs into nav args). */
    @Volatile
    var pendingPlayback: PlaybackRequest? = null

    /**
     * Deep-link handoff: a plavio-addons:// VIEW intent carries a share-bundle
     * link. MainActivity stashes the raw link here; AddonsScreen opens its
     * import dialog pre-filled with it, then clears it.
     */
    private val _pendingAddonBundle = MutableStateFlow<String?>(null)
    val pendingAddonBundle: StateFlow<String?> = _pendingAddonBundle.asStateFlow()

    fun setPendingAddonBundle(link: String) { _pendingAddonBundle.value = link }
    fun clearPendingAddonBundle() { _pendingAddonBundle.value = null }

    /**
     * Pending manifest URL from a stremio:// deep link. MainActivity stashes
     * the https:// manifest URL here; AddonsScreen picks it up and offers
     * to add it as an addon, then clears it.
     */
    private val _pendingManifestUrl = MutableStateFlow<String?>(null)
    val pendingManifestUrl: StateFlow<String?> = _pendingManifestUrl.asStateFlow()

    fun setPendingManifestUrl(url: String) { _pendingManifestUrl.value = url }
    fun clearPendingManifestUrl() { _pendingManifestUrl.value = null }

    /**
     * In-memory handoff for the catalog "view all" screen.
     * R5(i) (v0.14.23): the row's identity is also persisted (via
     * [SettingsStore.pendingCatalogJson]) whenever a row is handed over,
     * so after process death CatalogScreen can re-derive the row with
     * [rederivePendingCatalog] instead of showing an empty screen.
     */
    /**
     * In-memory handoff for a live-channel detail open (v0.14.26,
     * batch item 4): the catalog row's own entry for the channel,
     * stashed by the opener so DetailScreen can build the channel
     * page from the row in hand even when no addon answers a meta
     * request. Consumed (and cleared) by the matching detail load.
     */
    @Volatile
    var pendingChannelHint: MetaPreview? = null

    @Volatile
    var pendingCatalog: CatalogRow? = null
        set(value) {
            field = value
            if (value != null) {
                runCatching {
                    settings.pendingCatalogJson = JSONObject()
                        .put("addonId", value.addonId)
                        .put("addonName", value.addonName)
                        .put("baseUrl", value.baseUrl)
                        .put("catalogName", value.catalogName)
                        .put("type", value.type)
                        .put("catalogId", value.catalogId)
                        .toString()
                }
            }
        }

    /** The persisted "view all" row identity, or null when none was saved. */
    fun persistedPendingCatalogIdentity(): CatalogRow? {
        val raw = settings.pendingCatalogJson ?: return null
        return runCatching {
            val json = JSONObject(raw)
            CatalogRow(
                addonId = json.getString("addonId"),
                addonName = json.optString("addonName"),
                baseUrl = json.optString("baseUrl"),
                catalogName = json.optString("catalogName"),
                type = json.getString("type"),
                catalogId = json.getString("catalogId"),
                items = emptyList()
            )
        }.getOrNull()
    }

    /**
     * R5(i) (v0.14.23): re-derive the "view all" row for
     * (addonId, type, catalogId) — the in-memory handoff when it still
     * matches, else the cached Home rows, else a fresh catalog refresh.
     * A found row is latched back into [pendingCatalog].
     */
    suspend fun rederivePendingCatalog(
        addonId: String,
        type: String,
        catalogId: String
    ): CatalogRow? {
        pendingCatalog?.takeIf {
            it.addonId == addonId && it.type == type && it.catalogId == catalogId
        }?.let { return it }
        val fromCache = runCatching { loadCatalogRowsCached() }.getOrDefault(emptyList())
            .firstOrNull { it.addonId == addonId && it.type == type && it.catalogId == catalogId }
        val row = fromCache ?: runCatching { refreshCatalogRows() }.getOrDefault(emptyList())
            .firstOrNull { it.addonId == addonId && it.type == type && it.catalogId == catalogId }
        if (row != null) pendingCatalog = row
        return row
    }

    /**
     * Item 10 (v0.14.24): the next page of a catalog row for the
     * "view all" screen's endless list. Only catalogs whose manifest
     * declares the `skip` extra are paged — others answer 404 (or
     * repeat page 0) to skip= and must not be re-asked. The page is
     * returned raw; the caller dedupes against what it already
     * shows and stops when a page adds nothing new.
     */
    suspend fun fetchCatalogNextPage(row: CatalogRow, skip: Int): List<MetaPreview> =
        withContext(Dispatchers.IO) {
            val addon = enabledAddons().firstOrNull { it.id == row.addonId }
                ?: return@withContext emptyList()
            val manifest = cachedManifest(addon.baseUrl) ?: return@withContext emptyList()
            val ref = manifest.catalogs.firstOrNull {
                it.type == row.type && it.id == row.catalogId
            } ?: return@withContext emptyList()
            if ("skip" !in ref.extra.map { it.lowercase() }) {
                return@withContext emptyList()
            }
            runCatching {
                addonRequest { api.fetchCatalogPage(addon.baseUrl, row.type, row.catalogId, skip) }
            }.getOrDefault(emptyList())
        }

    /**
     * Item 6 (v0.14.24): the Discover catalog choices for the Search
     * tab — every catalog of every enabled catalog addon, grouped by
     * type ("movie" / "series" / "tv" plus any live/channel custom
     * type, which the TV picker folds into "tv"). Genre options come
     * from each catalog's declared `genre` extra values when present.
     */
    suspend fun discoverCatalogChoices(): List<CatalogRow> = withContext(Dispatchers.IO) {
        val installed = enabledAddons().filter { it.hasCatalog }
        installed.flatMap { addon ->
            val manifest = cachedManifest(addon.baseUrl) ?: return@flatMap emptyList()
            manifest.catalogs.map { ref ->
                CatalogRow(
                    addonId = addon.id,
                    addonName = addon.name,
                    baseUrl = addon.baseUrl,
                    catalogName = ref.name,
                    type = ref.type,
                    catalogId = ref.id,
                    items = emptyList()
                )
            }
        }.distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
    }

    /**
     * PrePlay (item 13, v0.14.24): background-prefetch a title's
     * streams into the session stream cache. [streamResultsFlow]
     * writes its final merged result into [streamResultCache] with
     * the plain key and emits a fresh cache entry instantly on the
     * next collect — so collecting to completion here IS the pocket:
     * the play press then starts from the cache emission with zero
     * fan-out wait while the background refresh keeps filling.
     * Skips the network entirely when the pocket is still fresh;
     * failures are silent by construction (the flow fails soft).
     */
    suspend fun prePlayPrefetch(type: String, videoId: String) {
        val key = "$type|$videoId||false"
        streamResultCache[key]?.let { (cachedAt, cached) ->
            if (cached.streams.isNotEmpty() &&
                System.currentTimeMillis() - cachedAt < PREPLAY_FRESH_MS
            ) return
        }
        try {
            streamResultsFlow(type, videoId).collect { /* pocket fill */ }
        } catch (_: Exception) {
            // Silent: a prefetch is never an error surface.
        }
    }

    /** One Discover page (first page = the plain catalog fetch). */
    suspend fun fetchDiscoverPage(row: CatalogRow, skip: Int): List<MetaPreview> =
        withContext(Dispatchers.IO) {
            if (skip <= 0) {
                runCatching {
                    addonRequest { api.fetchCatalog(row.baseUrl, row.type, row.catalogId) }
                }.getOrDefault(emptyList())
            } else {
                fetchCatalogNextPage(row, skip)
            }
        }

    /** Genre-filtered first page for Discover, when the catalog declares `genre`. */
    suspend fun fetchDiscoverGenrePage(row: CatalogRow, genre: String): List<MetaPreview> =
        withContext(Dispatchers.IO) {
            val addon = enabledAddons().firstOrNull { it.id == row.addonId }
                ?: return@withContext emptyList()
            val manifest = cachedManifest(addon.baseUrl) ?: return@withContext emptyList()
            val ref = manifest.catalogs.firstOrNull {
                it.type == row.type && it.id == row.catalogId
            } ?: return@withContext emptyList()
            if ("genre" !in ref.extra.map { it.lowercase() }) {
                return@withContext emptyList()
            }
            runCatching {
                addonRequest { api.fetchCatalogGenre(addon.baseUrl, row.type, row.catalogId, genre) }
            }.getOrDefault(emptyList())
        }

    /**
     * Genre options a catalog declares for its `genre` extra — some
     * manifests carry the option list in extraSupported (name ->
     * options); when they don't, Discover derives the chips from the
     * loaded items' own genres instead.
     */
    suspend fun discoverGenreOptions(row: CatalogRow): List<String> =
        withContext(Dispatchers.IO) {
            val addon = enabledAddons().firstOrNull { it.id == row.addonId }
                ?: return@withContext emptyList()
            val manifest = cachedManifest(addon.baseUrl) ?: return@withContext emptyList()
            val ref = manifest.catalogs.firstOrNull {
                it.type == row.type && it.id == row.catalogId
            } ?: return@withContext emptyList()
            ref.genreOptions
        }

    suspend fun addAddonFromUrl(input: String): Result<AddonInstallOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = StremioApi.normalizeBaseUrl(input)
            val manifest = addonRequest { api.fetchManifest(baseUrl) }
            // Real Stremio behavior: an addon is useful if it provides ANY of
            // catalog / meta / stream / subtitles — they no longer have to come bundled together.
            val hasAny = manifest.hasCatalog || manifest.hasMeta || manifest.hasStream || manifest.hasSubtitles
            if (!hasAny) {
                throw IllegalStateException(
                    "This addon doesn't provide catalogs, metadata, streams, or subtitles — " +
                        "there's nothing Pulse can use."
                )
            }
            val dao = db.addonDao()
            val allAddons = dao.getAll()
            // R3 (v0.14.23): AddonDao.upsert is REPLACE — building a fresh
            // row for an already-installed addon wiped the user-owned
            // fields (re-enabled it, un-hid it on Home, un-starred it,
            // moved it to the end of the order, reset its install date).
            // Carry those over from the existing row; only server-owned
            // fields (name, version, types, resources, …) refresh.
            // v0.14.36 (defect 2): the match is by IDENTITY (manifest
            // id + normalised origin, see AddonIdentity), not the raw
            // URL string and not the id alone — the same addon under
            // a /u/, /c/, or respelled URL updates its one row in
            // place, and the outcome says so, so the caller can tell
            // the user it was already installed instead of stacking
            // or silently clobbering.
            val existing = AddonIdentity.findMatch(allAddons, manifest.id, baseUrl)
            val sortOrder = existing?.sortOrder
                ?: ((allAddons.maxOfOrNull { it.sortOrder } ?: -1) + 1)
            val addon = InstalledAddon(
                // A matched row keeps its stored id (the primary key):
                // a case-only wobble in the fetched manifest must not
                // fork the addon into a second identity.
                id = existing?.id ?: manifest.id,
                name = manifest.name,
                version = manifest.version,
                description = manifest.description,
                baseUrl = baseUrl,
                types = manifest.types.joinToString(","),
                resources = manifest.resources.joinToString(","),
                enabled = existing?.enabled ?: true,
                configurable = manifest.configurable,
                showOnHome = existing?.showOnHome ?: true,
                logoUrl = resolveAddonLogoUrl(baseUrl, manifest.logo),
                sortOrder = sortOrder,
                starred = existing?.starred ?: false,
                addedAt = existing?.addedAt ?: System.currentTimeMillis()
            )
            dao.upsert(addon)
            // Upsert may replace an existing manifest URL or capabilities;
            // discard every result derived from its previous configuration.
            evictManifest(baseUrl)
            invalidateAddonCaches(addon.id)
            AddonInstallOutcome(addon, alreadyInstalled = existing != null)
        }
    }

    /**
     * Re-fetch an installed addon's manifest.json from its stored base URL
     * and update the local record (name, version, description, types,
     * resources, configure flag, logo). User-owned fields — enabled,
     * manual order, starred, pre-installed flag, show-on-home, install
     * date — are preserved. On any fetch/parse failure the stored record
     * is left untouched and the error is returned.
     */
    suspend fun refreshAddon(id: String): Result<AddonRefreshOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val dao = db.addonDao()
            val current = dao.getAll().firstOrNull { it.id == id }
                ?: throw IllegalStateException("Addon not found")
            // Gated by the shared addonRequest semaphore like every other
            // manifest fetch (2026-10-28) — this was the one ungated call.
            val manifest = addonRequest { api.fetchManifest(current.baseUrl) }
            val updated = current.copy(
                name = manifest.name,
                version = manifest.version,
                description = manifest.description,
                types = manifest.types.joinToString(","),
                resources = manifest.resources.joinToString(","),
                configurable = manifest.configurable,
                logoUrl = resolveAddonLogoUrl(current.baseUrl, manifest.logo)
                    .ifBlank { current.logoUrl }
            )
            dao.upsert(updated)
            // Publish the just-fetched manifest to both manifest
            // caches so catalogs/streams use the fresh one with no
            // refetch (v0.14.35: the persisted store included).
            storeManifest(current.baseUrl, System.currentTimeMillis(), manifest)
            invalidateAddonCaches(id)
            if (current.version.isNotBlank() && manifest.version != current.version) {
                AddonRefreshOutcome.Updated(current.version, manifest.version)
            } else {
                AddonRefreshOutcome.UpToDate(manifest.version)
            }
        }
    }

    suspend fun removeAddon(id: String) = withContext(Dispatchers.IO) {
        val baseUrl = db.addonDao().getAll().firstOrNull { it.id == id }?.baseUrl
        db.addonDao().deleteById(id)
        if (baseUrl != null) evictManifest(baseUrl)
        invalidateAddonCaches(id)
        db.catalogCacheDao().deleteByAddonId(id)
    }

    /** User on/off switch for an addon. Disabled addons are excluded everywhere. */
    suspend fun setAddonEnabled(id: String, enabled: Boolean) = withContext(Dispatchers.IO) {
        db.addonDao().getAll().firstOrNull { it.id == id }?.let { addon ->
            db.addonDao().upsert(addon.copy(enabled = enabled))
            // All provider-derived caches must move together on enable/disable.
            evictManifest(addon.baseUrl)
            invalidateAddonCaches(id)
            if (!enabled) db.catalogCacheDao().deleteByAddonId(id)
        }
    }

    private suspend fun invalidateAddonCaches(addonId: String) {
        catalogCache = catalogCache.filter { it.addonId != addonId }
        tvRowsMemoryCache = null
        trailersCache = null
        // v0.14.36 (defect 1): merged STREAM payloads are derived from
        // the addon's configuration too — a formatter/style change on
        // the server side changes the text of every row it serves.
        // This cache was the one store no lifecycle event ever
        // invalidated (only the account wipe cleared it), so styled
        // text stayed frozen behind the old payloads until a reinstall
        // happened to reset neighbouring state. Entries are keyed by
        // title, not by addon, so the whole session cache goes: it
        // rebuilds from the next collects, PrePlay pockets included.
        streamResultCache.clear()
        // Persisted catalog rows are provider-derived too; otherwise cached
        // Live/Home results can reappear after disable or manifest reconfigure.
        db.catalogCacheDao().deleteByAddonId(addonId)
        // Subtitle keys aggregate all providers; without source ownership, clear all.
        db.subtitleCacheDao().clearAll()
    }

    /**
     * Export raw addon URLs only for the caller's encrypted private snapshot.
     * Locked placeholders are excluded from ordinary sync exports so a prior
     * redacted import cannot overwrite a good private URL on another device.
     * Rollback callers may opt in because that snapshot is trusted local state.
     */
    suspend fun exportPortableAddonUrls(
        includeLockedPlaceholdersForRollback: Boolean = false
    ): Map<String, PortableAddonUrlConfig> = withContext(Dispatchers.IO) {
        db.addonDao().getAll().asSequence()
            .filterNot { isLockedAddonUrlPlaceholder(it.baseUrl) && !includeLockedPlaceholdersForRollback }
            .associate { it.id to PortableAddonUrlConfig(it.baseUrl, it.enabled) }
    }

    /**
     * Restore only URLs for addons already installed locally. Validation,
     * missing-ID checks and conflict checks all finish before the first write;
     * writes are then atomic and never fetch manifests or contact providers.
     * [allowOverwriteForRollback] is reserved for a trusted pre-import snapshot.
     */
    suspend fun restorePortableAddonUrls(
        configs: Map<String, PortableAddonUrlConfig>,
        allowOverwriteForRollback: Boolean = false
    ): Result<Int> = try {
        withContext(Dispatchers.IO) {
            require(configs.size <= MAX_PORTABLE_ADDON_URLS) { "Too many addon URLs in the private snapshot." }
            configs.forEach { (id, config) ->
                require(id.isNotBlank() && id.length <= 300 && id == id.trim() && id.none { Character.isISOControl(it) }) {
                    "Invalid addon id in the private snapshot."
                }
                require(config.baseUrl.isNotBlank() && config.baseUrl.length <= MAX_ADDON_URL_LENGTH &&
                    isHttpUrl(config.baseUrl)) { "Invalid addon URL in the private snapshot." }
                require(!isLockedAddonUrlPlaceholder(config.baseUrl) ||
                    allowOverwriteForRollback && !config.enabled) {
                    "Locked addon placeholders can only be restored from a trusted rollback snapshot."
                }
            }

            val changed = mutableListOf<Pair<InstalledAddon, InstalledAddon>>()
            db.withTransaction {
                val dao = db.addonDao()
                val installed = dao.getAll().associateBy(InstalledAddon::id)
                val unknownIds = configs.keys - installed.keys
                require(unknownIds.isEmpty()) {
                    "Restore the profile first; addon URL config references addons that are not installed."
                }
                configs.forEach { (id, incoming) ->
                    val current = installed.getValue(id)
                    val currentIsPlaceholder = isLockedAddonUrlPlaceholder(current.baseUrl)
                    require(allowOverwriteForRollback || currentIsPlaceholder ||
                        current.baseUrl == incoming.baseUrl || !isConfiguredAddonUrl(current.baseUrl)) {
                        "Addon '$id' already has a different local URL; refusing to overwrite it."
                    }
                }
                configs.forEach { (id, incoming) ->
                    val current = installed.getValue(id)
                    if (current.baseUrl != incoming.baseUrl || current.enabled != incoming.enabled) {
                        val updated = current.copy(baseUrl = incoming.baseUrl, enabled = incoming.enabled)
                        dao.upsert(updated)
                        changed += current to updated
                    }
                }
            }

            // Invalidate only after the Room transaction commits. A full clear
            // avoids retaining responses keyed by either the old or new URL.
            if (changed.isNotEmpty()) {
                clearAllManifestCaches()
                catalogCache = emptyList()
                trailersCache = null
                tvRowsMemoryCache = null
                db.catalogCacheDao().clearAll()
                db.subtitleCacheDao().clearAll()
            }
            Result.success(changed.size)
        }
    } catch (cancel: CancellationException) { throw cancel }
      catch (e: Exception) { Result.failure(e) }

    /** Star an addon: its catalogs, streams and subtitles get priority. */
    suspend fun setAddonStarred(id: String, starred: Boolean) = withContext(Dispatchers.IO) {
        db.addonDao().getAll().firstOrNull { it.id == id }?.let { addon ->
            db.addonDao().upsert(addon.copy(starred = starred))
        }
    }

    /** Swap the manual order positions of two addons (rearrange up/down). */
    suspend fun swapAddonOrder(id1: String, id2: String) = withContext(Dispatchers.IO) {
        val dao = db.addonDao()
        val all = dao.getAll()
        val a = all.firstOrNull { it.id == id1 }
        val b = all.firstOrNull { it.id == id2 }
        if (a != null && b != null) {
            dao.upsert(a.copy(sortOrder = b.sortOrder))
            dao.upsert(b.copy(sortOrder = a.sortOrder))
        }
    }

    /**
     * One-time normalization: addons installed before manual ordering
     * existed all share sortOrder 0, which makes swaps no-ops. Assign
     * distinct sequential values preserving the current relative order.
     * Later runs are no-ops.
     */
    suspend fun normalizeAddonSortOrder() = withContext(Dispatchers.IO) {
        val dao = db.addonDao()
        dao.getAll().forEachIndexed { idx, addon ->
            if (addon.sortOrder != idx) dao.upsert(addon.copy(sortOrder = idx))
        }
    }

    /** Addons the user left switched on. */
    private suspend fun enabledAddons(): List<InstalledAddon> =
        AddonIdentity.dedupeInstalled(db.addonDao().getAll()).filter { it.enabled }

    /** Enabled addons that provide catalogs — the Home Catalogs settings list. */
    suspend fun catalogAddons(): List<InstalledAddon> = withContext(Dispatchers.IO) {
        enabledAddons().filter { it.hasCatalog }
    }

    /**
     * Trending movies + series for the Trailers tab. PlavioMeta first (its
     * metas carry trailerStreams), then any other enabled catalog addon.
     * Returns catalog items only — trailer YouTube ids resolve lazily per
     * tap via [getMetaFromAny], so the tab loads fast.
     */
    suspend fun trendingForTrailers(): List<TrailerItem> = withContext(Dispatchers.IO) {
        val addons = catalogAddons()
        if (addons.isEmpty()) return@withContext emptyList()
        val ordered = addons.sortedBy { metaRank(it) }
        val out = linkedMapOf<String, TrailerItem>()
        for (addon in ordered) {
            val manifest = runCatching { cachedManifest(addon.baseUrl) }.getOrNull() ?: continue
            for (type in listOf("movie", "series")) {
                val catalog = manifest.catalogs.firstOrNull { it.type == type && "trend" in it.id.lowercase() }
                    ?: manifest.catalogs.firstOrNull { it.type == type }
                    ?: continue
                val items = runCatching { api.fetchCatalog(addon.baseUrl, type, catalog.id) }.getOrNull()
                    ?: continue
                items.forEach { meta ->
                    out.putIfAbsent(
                        "${addon.id}|${meta.id}",
                        TrailerItem(addon.id, addon.baseUrl, type, meta)
                    )
                }
            }
            // One addon's trending rows cover movies+series — no need to merge more.
            if (out.isNotEmpty()) break
        }
        out.values.toList()
    }

    /**
     * TTL-cached trending trailers, split into (movies, series). Revisiting
     * the Trailers tab within the TTL reuses memory — no spinner, no network.
     * Pass [forceRefresh] for pull-to-refresh.
     */
    suspend fun trendingTrailersCached(
        forceRefresh: Boolean = false
    ): Pair<List<TrailerItem>, List<TrailerItem>> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        trailersCache?.let { (ts, data) ->
            if (!forceRefresh && now - ts < TRAILERS_CACHE_TTL_MS) return@withContext data
        }
        val all = trendingForTrailers()
        val data = all.filter { it.type == "movie" } to all.filter { it.type == "series" }
        trailersCache = now to data
        data
    }

    /** In-memory Trailers tab data: (fetchedAt, movies to series). */
    @Volatile
    private var trailersCache: Pair<Long, Pair<List<TrailerItem>, List<TrailerItem>>>? = null

    /** Whether an addon's catalogs appear on the Home screen. */
    suspend fun setAddonShowOnHome(id: String, show: Boolean) = withContext(Dispatchers.IO) {
        db.addonDao().setShowOnHome(id, show)
        _catalogVisibility.value += 1
    }

    /** Bumped whenever Home catalog visibility changes — Home reloads on it. */
    private val _catalogVisibility = MutableStateFlow(0)
    val catalogVisibility: StateFlow<Int> = _catalogVisibility.asStateFlow()

    /**
     * Loads catalogs from every installed addon that declares the catalog
     * resource. Manifests are re-fetched so renamed/dead addons refresh
     * cleanly and capability changes are picked up; failures are skipped.
     * Fresh results are written to the catalog cache (Room).
     */
    // In-flight catalog refresh sharing: concurrent callers (splash warm-up,
    // Home load, pull-to-refresh) join the same network job instead of
    // stacking duplicate requests.
    private val catalogRefreshLock = Any()
    private var catalogRefreshJob: Deferred<List<CatalogRow>>? = null
    private val catalogRefreshScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    // v0.14.35 (cold-start fix, step 6): 4 -> 8 permits. The gate is
    // shared by manifest/catalog/meta/search fetches; at 4, a cold
    // start's ~50 catalog requests needed ~13 waves and the tail
    // wave alone could hold Home's first paint for tens of seconds.
    // 8 halves the waves while staying well under BoundedHttp's own
    // 12-permit transport bound. The 25 s call ceiling deliberately
    // stays: cold fills on first-party-class servers legitimately
    // run long (v0.14.24), and cutting the ceiling would turn slow
    // successes into failures — the minute was wave count and
    // all-or-nothing emission, not the ceiling.
    private val addonRequestGate = Semaphore(8)

    private suspend fun <T> addonRequest(block: suspend () -> T): T {
        addonRequestGate.acquire()
        try { return block() } finally { addonRequestGate.release() }
    }

    /**
     * Refreshes catalog rows from the network. If a refresh is already in
     * flight, joins it instead of starting duplicate work.
     *
     * v0.14.35 (cold-start fix, step 1): this now drains the
     * PROGRESSIVE flow instead of launching a separate plain job.
     * There is exactly one refresh implementation and one
     * single-flight job, and it always carries the progress callback —
     * previously the splash warm-up started this plain variant, and
     * Home's progressive collect joining it received exactly one
     * emission (the final list) after the whole refresh, which is
     * what turned a gated-cache miss into a ~60 s skeleton.
     */
    suspend fun refreshCatalogRows(): List<CatalogRow> =
        refreshCatalogRowsProgressive().last()

    /**
     * Progressive refresh (mobile overhaul): emits the merged Home
     * row set as catalogs land, then the authoritative final list —
     * Home never waits for the slowest addon to show what has
     * already arrived. Shares the single-flight refresh job; since
     * v0.14.35 every refresh (including the splash warm-up's, via
     * [refreshCatalogRows]) runs through this flow, so a joiner
     * always receives the incremental emissions too.
     */
    fun refreshCatalogRowsProgressive(): kotlinx.coroutines.flow.Flow<List<CatalogRow>> =
        kotlinx.coroutines.flow.channelFlow {
            val job = synchronized(catalogRefreshLock) {
                val active = catalogRefreshJob?.takeIf { it.isActive }
                active ?: catalogRefreshScope.async {
                    doRefreshCatalogRows(onProgress = { rows -> trySend(rows) })
                }.also { catalogRefreshJob = it }
            }
            val finalRows = job.await()
            trySend(finalRows)
            close()
        }

    /**
     * True when Home's catalog cache was refreshed within [maxAgeMs].
     * Freshness is tracked per-section via [SettingsStore.homeCatalogsRefreshedAt]:
     * the Live tab writes its own rows into the same catalog_cache table, so
     * judging freshness from the table's max fetchedAt let a Live visit
     * suppress Home's background refresh for 15 minutes.
     */
    suspend fun isCatalogCacheFresh(maxAgeMs: Long = 15 * 60 * 1000): Boolean =
        withContext(Dispatchers.IO) {
            val refreshedAt = settings.homeCatalogsRefreshedAt
            if (refreshedAt <= 0L) return@withContext false
            if (System.currentTimeMillis() - refreshedAt >= maxAgeMs) return@withContext false
            try {
                // The timestamp says Home refreshed — make sure there are
                // actually Home rows (Live/M3U rows don't count).
                db.catalogCacheDao().getAll().any { it.addonId != "m3u" }
            } catch (_: Exception) {
                false
            }
        }

    /**
     * True when the catalog cache already holds rows Home can paint.
     * The splash gate uses this: a cached feed is a ready feed — Home
     * shows it instantly and refreshes in the background.
     *
     * v0.14.35 (cold-start fix, step 4): this now tests EXACTLY what
     * [loadCatalogRowsCached] can serve, via [homeServableCachedRows].
     * The old check counted ANY row (Live TV rows included) as
     * "ready" while Home's gated read could still find nothing —
     * the two definitions disagreeing is what let the splash exit
     * "warm" into a minute-long skeleton.
     */
    suspend fun hasCachedHomeRows(): Boolean = withContext(Dispatchers.IO) {
        try {
            homeServableCachedRows().first.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    /**
     * THE shared "Home rows servable" read: the cached rows Home can
     * actually paint — provider gate, per-catalog visibility,
     * non-TV, non-empty — resolved by [ColdStartSupport] so the
     * splash gate and Home's cached read share one definition.
     * Returns the rows and the enabled addons by id (for ordering).
     */
    private suspend fun homeServableCachedRows(): Pair<List<CatalogRow>, Map<String, InstalledAddon>> {
        val visible = enabledAddons()
        val visibleById = visible.associateBy { it.id }
        val decoded = db.catalogCacheDao().getAll().map { cached ->
            val items = CatalogCodec.decodeMetas(cached.itemsJson)
            CatalogRow(cached.addonId, cached.addonName, cached.baseUrl,
                cached.catalogName, cached.type, cached.catalogId, items) to
                ColdStartSupport.CachedRowInfo(
                    cached.addonId, cached.type, cached.catalogId, items.size
                )
        }
        val preferenceOrder = visible
            .sortedWith(compareBy<InstalledAddon> { metaRank(it) }.thenBy { it.sortOrder })
            .map { it.id }
        val providerId = ColdStartSupport.resolveCachedProviderId(
            rows = decoded.map { it.second },
            enabledAddonIds = visibleById.keys,
            storedProviderId = settings.homeMetaProviderAddonId,
            providerOrder = { id ->
                preferenceOrder.indexOf(id).let { if (it < 0) Int.MAX_VALUE else it }
            }
        )
        val rows = decoded
            .filter { (row, info) ->
                ColdStartSupport.isHomeServable(info, visibleById.keys, providerId) { addonId, catalogId, type ->
                    visibleById[addonId]?.let {
                        settings.isCatalogOnHome(addonId, catalogId, it.showOnHome, type)
                    } ?: false
                } && row.items.isNotEmpty()
            }
            .map { it.first }
            .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
        return rows to visibleById
    }

    /**
     * Fallback read for Home's skeleton safety net (v0.14.35,
     * cold-start fix step 8): cached rows of ANY provider, still
     * visibility-gated, non-TV and non-empty — what Home paints when
     * the strict read is empty and the refresh hasn't landed within
     * the owner's 5 s skeleton budget. "Never zero" beats "strictly
     * the picked provider" once the budget is spent.
     */
    suspend fun loadAnyCachedHomeRows(): List<CatalogRow> = withContext(Dispatchers.IO) {
        try {
            val visibleById = enabledAddons().associateBy { it.id }
            val rows = db.catalogCacheDao().getAll()
                .filter { cached ->
                    cached.type != "tv" &&
                        (visibleById[cached.addonId]?.let {
                            settings.isCatalogOnHome(
                                cached.addonId, cached.catalogId, it.showOnHome, cached.type
                            )
                        } ?: false)
                }
                .map { cached ->
                    CatalogRow(cached.addonId, cached.addonName, cached.baseUrl,
                        cached.catalogName, cached.type, cached.catalogId,
                        CatalogCodec.decodeMetas(cached.itemsJson))
                }
                .filter { it.items.isNotEmpty() }
                .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
            applyHomeCatalogOrder(sortRowsByPreference(rows, visibleById))
        } catch (_: Exception) {
            emptyList()
        }
    }

    private suspend fun doRefreshCatalogRows(
        onProgress: (suspend (List<CatalogRow>) -> Unit)? = null
    ): List<CatalogRow> = withContext(Dispatchers.IO) {
        // v0.14.14: per-catalog Home visibility (press-and-hold Home
        // picker) — all enabled addons participate; each catalog is
        // filtered by SettingsStore.isCatalogOnHome with the addon's
        // showOnHome flag as the fallback default.
        val installed = enabledAddons()
        // Step 5 housekeeping: the persisted manifest store keeps
        // only installed addons' manifests.
        prunePersistedManifests(installed.map { it.baseUrl }.toSet())
        val successfulManifests = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
        // Addons whose manifest offers non-TV catalogs — the candidate
        // set for Home's meta provider gate (v0.14.15).
        val catalogProviderIds = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
        val authoritativeKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
        val listedManifestKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
        // P2 (v0.14.22): keys whose fetch FAILED this pass — a partial
        // refresh must not advance the 3 h freshness clock for them.
        val failedKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
        val manifestFailed = java.util.concurrent.atomic.AtomicBoolean(false)
        // Progressive publishing (mobile overhaul): while the refresh
        // runs, each completed addon merges its fresh rows over the
        // pre-refresh cache snapshot and the merged set is emitted —
        // shaped with the same provider gate, per-catalog visibility
        // and ordering as the final list (ratings enrichment and the
        // prune/retention bookkeeping stay final-only). The provider
        // estimate peeks at locally held manifests only (memory +
        // persisted store), never the network.
        val previewFetched = java.util.Collections.synchronizedList(mutableListOf<CatalogRow>())
        val previewCacheRows: List<CatalogRow> = if (onProgress != null) {
            try {
                db.catalogCacheDao().getAll().map { cached ->
                    CatalogRow(cached.addonId, cached.addonName, cached.baseUrl,
                        cached.catalogName, cached.type, cached.catalogId,
                        CatalogCodec.decodeMetas(cached.itemsJson))
                }
            } catch (_: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }
        val previewProviderId = if (onProgress != null) {
            resolveHomeProviderId(installed.filter { addon ->
                peekManifest(addon.baseUrl)?.catalogs?.any { it.type != "tv" } == true
            })
        } else {
            null
        }
        val previewById = installed.associateBy { it.id }
        suspend fun emitProgressPreview() {
            val callback = onProgress ?: return
            val fetched = synchronized(previewFetched) { previewFetched.toList() }
            if (fetched.isEmpty()) return
            val fetchedKeys = fetched
                .map { "${it.addonId}|${it.type}|${it.catalogId}" }.toSet()
            val merged = (fetched + previewCacheRows.filter {
                "${it.addonId}|${it.type}|${it.catalogId}" !in fetchedKeys
            })
                .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
                .filter { row ->
                    (previewProviderId == null || row.addonId == previewProviderId) &&
                        (previewById[row.addonId]?.let {
                            settings.isCatalogOnHome(
                                row.addonId, row.catalogId, it.showOnHome, row.type
                            )
                        } ?: false)
                }
            callback(applyHomeCatalogOrder(sortRowsByPreference(merged, previewById)))
        }
        // v0.14.35 (cold-start fix, steps 2+3): the fetch phase is a
        // FLAT plan, not per-addon awaitAll. Manifests resolve
        // concurrently first (the provider estimate's addon launches
        // first, so its manifest wins the request gate's first wave);
        // then every catalog fetch launches in plan order — the
        // selected provider's catalogs first, TV catalogs excluded
        // entirely (ColdStartSupport.homeFetchPlan) — and progress is
        // emitted per catalog batch instead of per whole addon. The
        // request gate admits in launch order, so plan order IS
        // fetch priority: Home's first paint is the provider's first
        // catalogs, not the slowest addon's last one.
        val providerFirst = installed.sortedBy {
            if (it.id == previewProviderId) 0 else 1
        }
        val manifests: Map<String, AddonManifest?> = coroutineScope {
            providerFirst.map { addon ->
                async { addon.id to cachedManifest(addon.baseUrl) }
            }.awaitAll().toMap()
        }
        for (addon in installed) {
            val manifest = manifests[addon.id]
            if (manifest == null) {
                manifestFailed.set(true)
            } else {
                successfulManifests.add(addon.id)
                try {
                    db.addonDao().upsert(addon.copy(
                        resources = manifest.resources.joinToString(","),
                        types = manifest.types.joinToString(","),
                        configurable = manifest.configurable
                    ))
                } catch (cancel: CancellationException) { throw cancel }
                catch (_: Exception) { /* metadata refresh must not lose existing rows */ }
                if ("catalog" in manifest.resources && manifest.catalogs.any { it.type != "tv" }) {
                    catalogProviderIds.add(addon.id)
                }
                if (manifest.catalogs.isEmpty()) authoritativeKeys.add("${addon.id}|*")
                // Every catalog key the manifest lists — TV included —
                // is "listed": the fetch plan below skips TV (step 3),
                // but the prune further down must not read that as
                // "obsolete" and delete the Live tab's cached TV rows.
                // This is exactly the key set the old per-addon loop
                // recorded while iterating the manifest.
                if ("catalog" in manifest.resources) {
                    for (catalog in manifest.catalogs) {
                        listedManifestKeys.add("${addon.id}|${catalog.type}|${catalog.id}")
                    }
                }
            }
        }
        // The authoritative provider (fresh manifests now known) —
        // the plan puts its catalogs at the head of the gate queue.
        val fetchProviderId = resolveHomeProviderId(
            installed.filter { it.id in catalogProviderIds }
        )
        val fetchPlan = ColdStartSupport.homeFetchPlan(
            installed.mapNotNull { addon ->
                manifests[addon.id]?.let { addon.id to it }
            },
            fetchProviderId
        )
        val rowsSinceEmission = java.util.concurrent.atomic.AtomicInteger(0)
        val rows = coroutineScope {
            fetchPlan.map { entry ->
                async {
                    val addon = previewById.getValue(entry.addonId)
                    val catalog = manifests[entry.addonId]!!.catalogs
                        .first { it.type == entry.type && it.id == entry.catalogId }
                    val key = "${entry.addonId}|${entry.type}|${entry.catalogId}"
                    // Hidden in the hold-Home picker: skip the fetch
                    // entirely (still listed in the manifest keys so
                    // the cache isn't pruned as obsolete while it
                    // stays hidden).
                    listedManifestKeys.add(key)
                    if (!settings.isCatalogOnHome(addon.id, catalog.id, addon.showOnHome, catalog.type)) {
                        return@async null
                    }
                    val items = try {
                        addonRequest { api.fetchCatalog(addon.baseUrl, catalog.type, catalog.id) }
                    } catch (cancel: CancellationException) { throw cancel }
                    catch (_: Exception) { failedKeys.add(key); null }
                    // Only a NON-EMPTY success is authoritative. A
                    // successful-but-empty response can be a transient
                    // upstream hiccup (cold start, rate limit answered
                    // as 200-empty); treating it as truth permanently
                    // evicted this catalog's titles from storage and
                    // from search (owner bug, 2026-10-23). An empty
                    // fetch keeps the last good row until real items
                    // replace it.
                    if (!items.isNullOrEmpty()) authoritativeKeys.add(key)
                    val row = items?.takeIf { it.isNotEmpty() }?.let {
                        CatalogRow(addon.id, addon.name, addon.baseUrl, catalog.name,
                            catalog.type, catalog.id, it)
                    }
                    if (row != null && onProgress != null) {
                        synchronized(previewFetched) { previewFetched.add(row) }
                        val total = rowsSinceEmission.incrementAndGet()
                        if (ColdStartSupport.progressEmissionDue(
                                newProviderRows = if (row.addonId == fetchProviderId) 1 else 0,
                                rowsSinceEmission = total
                            )
                        ) {
                            rowsSinceEmission.set(0)
                            emitProgressPreview()
                        }
                    }
                    row
                }
            }.awaitAll().filterNotNull()
        }.distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }

        val now = System.currentTimeMillis()
        val newRows = rows.associateBy { "${it.addonId}|${it.type}|${it.catalogId}" }
        // Same protection as loadCatalogRowsCached (2026-10-28): a poisoned /
        // oversized row (CursorWindow) must not fail the refresh — prune it,
        // treat the cache as empty, and still return the freshly fetched rows.
        val existingCache = try {
            db.catalogCacheDao().getAll()
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) {
            pruneOversizedCache()
            emptyList<CatalogCache>()
        }
        // Preserve failures/offline cached values. Delete only keys proven
        // obsolete by a successful manifest, or keys a non-empty fetch just
        // replaced. An empty fetch never deletes (see above).
        for (old in existingCache) {
            if (old.addonId !in successfulManifests) continue
            val key = old.key
            val manifestAuthoritative = "${old.addonId}|*" in authoritativeKeys
            val obsolete = !manifestAuthoritative && key !in listedManifestKeys
            if (manifestAuthoritative || obsolete || key in authoritativeKeys) {
                if (key !in newRows) db.catalogCacheDao().deleteByKey(key)
            }
        }
        if (rows.isNotEmpty()) db.catalogCacheDao().upsertAll(rows.map { row ->
            CatalogCache("${row.addonId}|${row.type}|${row.catalogId}", row.addonId,
                row.addonName, row.baseUrl, row.type, row.catalogId, row.catalogName,
                cappedItemsJson(row.items), now)
        })
        // Cache is authoritative only if at least one provider succeeded, including
        // a valid empty manifest; a total outage must remain stale/retryable.
        // P2 (v0.14.22): a PARTIAL refresh (any catalog fetch or manifest
        // failed) no longer advances the clock either — the failed
        // providers stay due and are retried on the next Home load
        // instead of being silently parked for 3 h.
        if (authoritativeKeys.isNotEmpty() && failedKeys.isEmpty() && !manifestFailed.get()) {
            settings.homeCatalogsRefreshedAt = now
        }
        val retained = existingCache.filter { cached ->
            cached.key !in newRows && cached.key !in authoritativeKeys &&
                (cached.addonId !in successfulManifests || cached.key in listedManifestKeys) &&
                installed.any { it.id == cached.addonId }
        }.map { cached -> CatalogRow(cached.addonId, cached.addonName, cached.baseUrl,
            cached.catalogName, cached.type, cached.catalogId, CatalogCodec.decodeMetas(cached.itemsJson)) }
        val byId = installed.associateBy { it.id }
        // v0.14.15: only the selected meta provider's catalogs render
        // on Home (stored pick, else the default meta addon by rank).
        val providerId = resolveHomeProviderId(
            installed.filter { it.id in catalogProviderIds }
        )
        val displayedRows = (rows + retained).distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
            // Final per-catalog visibility gate: retained cache rows
            // for picker-hidden catalogs must not leak back onto Home.
            .filter { row ->
                (providerId == null || row.addonId == providerId) &&
                    (byId[row.addonId]?.let {
                        settings.isCatalogOnHome(row.addonId, row.catalogId, it.showOnHome, row.type)
                    } ?: false)
            }
        updateSearchCache(displayedRows)
        applyHomeCatalogOrder(sortRowsByPreference(enrichRowsWithMdb(displayedRows), byId))
    }

    /**
     * Removes catalog rows too big for SQLite's CursorWindow. Call at
     * startup: heals installs poisoned by an oversized row without
     * wiping watchlist/addons/settings.
     */
    suspend fun pruneOversizedCache() = withContext(Dispatchers.IO) {
        try {
            db.catalogCacheDao().pruneOversized(MAX_CACHED_ROW_BYTES)
        } catch (_: Exception) {
        }
    }

    /** One addon's Home-picker catalog choices (v0.14.14). */
    data class HomeCatalogChoice(
        val addonId: String,
        val addonName: String,
        val addonShowOnHome: Boolean,
        val catalogs: List<CatalogRef>
    )

    /**
     * The addons + catalogs the press-and-hold Home picker offers:
     * every enabled catalog addon with its manifest catalogs (TV
     * catalogs excluded — Live TV has its own tab, Home never shows
     * them). Manifests come from the local cache first, network
     * refresh as fallback.
     */
    suspend fun homeCatalogChoices(): List<HomeCatalogChoice> = withContext(Dispatchers.IO) {
        // Preference order (v0.14.15): PlavioMeta first, then Cinemeta,
        // then install order — the first choice is Home's default meta
        // provider when the user has never picked one in the picker.
        enabledAddons()
            .sortedWith(compareBy<InstalledAddon> { metaRank(it) }.thenBy { it.sortOrder })
            .mapNotNull { addon ->
            val manifest = cachedManifest(addon.baseUrl) ?: refreshManifest(addon.baseUrl)
                ?: return@mapNotNull null
            if ("catalog" !in manifest.resources) return@mapNotNull null
            // Dedupe by type|id (v0.14.19): a manifest repeating the
            // same catalog must not hand the picker duplicate rows.
            // Same id under DIFFERENT types (Cinemeta's movie "top"
            // and series "top") are distinct catalogs and both stay.
            val catalogs = manifest.catalogs.filter { it.type != "tv" }
                .distinctBy { "${it.type}|${it.id}" }
            if (catalogs.isEmpty()) null
            else HomeCatalogChoice(addon.id, addon.name, addon.showOnHome, catalogs)
        }
    }

    /**
     * Home's meta provider among [candidates] (v0.14.15): the picker's
     * stored choice when that addon is still a candidate; otherwise
     * the default meta addon by rank (PlavioMeta first), so installs
     * that never opened the picker — or whose pick was uninstalled —
     * fall back gracefully with no visible change. Null only when
     * there are no candidates at all (callers then skip the gate).
     */
    private fun resolveHomeProviderId(candidates: List<InstalledAddon>): String? {
        if (candidates.isEmpty()) return null
        val stored = settings.homeMetaProviderAddonId
        if (stored != null && candidates.any { it.id == stored }) return stored
        return candidates.minWithOrNull(
            compareBy<InstalledAddon> { metaRank(it) }.thenBy { it.sortOrder }
        )?.id
    }

    /**
     * The provider the hold-Home picker should show as selected: the
     * stored pick when still installed, else the default (the first
     * of the preference-sorted [homeCatalogChoices]).
     */
    suspend fun homeMetaProviderId(): String? = withContext(Dispatchers.IO) {
        val choices = homeCatalogChoices()
        val stored = settings.homeMetaProviderAddonId
        if (stored != null && choices.any { it.addonId == stored }) stored
        else choices.firstOrNull()?.addonId
    }

    /**
     * Reads the last cached catalog rows from Room. Returns instantly —
     * Home shows these immediately while [refreshCatalogRows] runs quietly
     * in the background. Never throws: a poisoned cache must not crash Home.
     */
    suspend fun loadCatalogRowsCached(): List<CatalogRow> = withContext(Dispatchers.IO) {
        try {
            // v0.14.35 (cold-start fix, step 4): the gates that used
            // to live here inline (v0.14.14 per-catalog visibility,
            // v0.14.15 provider gate) now live in the ONE shared
            // servable read — see homeServableCachedRows.
            val (rows, visibleById) = homeServableCachedRows()
            updateSearchCache(rows)
            applyHomeCatalogOrder(sortRowsByPreference(rows, visibleById))
        } catch (_: Exception) {
            // Oversized/corrupt row slipped through — drop it and carry on.
            pruneOversizedCache()
            emptyList()
        }
    }

    /** In-memory Live-tab TV rows: (fetchedAt, rows) — repeat visits within the TTL skip the network. */
    @Volatile
    private var tvRowsMemoryCache: Pair<Long, List<CatalogRow>>? = null

    /**
     * Live TV rows for the Live tab: standard "tv" catalogs and explicitly
     * named live/channel catalogs with custom resource types. Served from
     * the in-memory cache when fresh (15 min TTL) so
     * every ON_RESUME doesn't re-download every catalog.
     */
    suspend fun loadTvRows(): List<CatalogRow> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        tvRowsMemoryCache?.let { (ts, rows) ->
            if (now - ts < TV_ROWS_TTL_MS) return@withContext rows
        }
        val installed = enabledAddons().filter { it.hasCatalog }
        val rows = coroutineScope {
            // OOM hotfix (v0.8.28-tv): cap concurrent TV catalog fetches.
            // Unbounded nested async + HTTP/2 segment buffers exhausted the
            // 48MB heap on low-RAM TVs (OutOfMemoryError in Http2Connection).
            val fetchGate = Semaphore(2)
            installed.map { addon ->
                async {
                    val manifest = cachedManifest(addon.baseUrl)
                    val liveCatalogs = (manifest?.catalogs ?: emptyList()).filter {
                        isLiveCatalog(it.type, it.id, it.name)
                    }
                    liveCatalogs.map { catalog ->
                        async {
                            fetchGate.acquire()
                            try {
                                val items = try { addonRequest { api.fetchCatalog(addon.baseUrl, catalog.type, catalog.id) } }
                                catch (cancel: CancellationException) { throw cancel }
                                catch (_: Exception) { emptyList() }
                                CatalogRow(
                                    addonId = addon.id,
                                    addonName = addon.name,
                                    baseUrl = addon.baseUrl,
                                    catalogName = catalog.name,
                                    type = catalog.type,
                                    catalogId = catalog.id,
                                    items = items
                                )
                            } finally {
                                fetchGate.release()
                            }
                        }
                    }.awaitAll().filter { it.items.isNotEmpty() }
                }
            }.awaitAll().flatten()
                .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
        }
        // Persist so the next visit is instant (see loadTvRowsCached).
        if (rows.isNotEmpty()) {
            val fetchedAt = System.currentTimeMillis()
            runCatching {
                db.catalogCacheDao().upsertAll(
                    rows.map { row ->
                        CatalogCache(
                            key = "${row.addonId}|${row.type}|${row.catalogId}",
                            addonId = row.addonId,
                            addonName = row.addonName,
                            baseUrl = row.baseUrl,
                            type = row.type,
                            catalogId = row.catalogId,
                            catalogName = row.catalogName,
                            itemsJson = cappedItemsJson(row.items),
                            fetchedAt = fetchedAt
                        )
                    }
                )
            }
            // Only cache successful non-empty loads — a failed visit must
            // retry on the next resume instead of serving emptiness for 15 min.
            tvRowsMemoryCache = fetchedAt to rows
        }
        rows
    }

    /**
     * Cached TV rows for the Live tab — returns instantly so the tab never
     * stares at a spinner on repeat visits. Refreshed by [loadTvRows].
     */
    suspend fun loadTvRowsCached(): List<CatalogRow> = withContext(Dispatchers.IO) {
        try {
            val visibleIds = enabledAddons().map { it.id }.toSet()
            db.catalogCacheDao().getAll()
                .filter {
                    it.addonId in visibleIds && isLiveCatalog(it.type, it.catalogId, it.catalogName)
                }
                .map { cached ->
                    CatalogRow(
                        addonId = cached.addonId,
                        addonName = cached.addonName,
                        baseUrl = cached.baseUrl,
                        catalogName = cached.catalogName,
                        type = cached.type,
                        catalogId = cached.catalogId,
                        items = CatalogCodec.decodeMetas(cached.itemsJson)
                    )
                }.filter { it.items.isNotEmpty() }
                .distinctBy { "${it.addonId}|${it.type}|${it.catalogId}" }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun updateSearchCache(rows: List<CatalogRow>) {
        catalogCache = rows.flatMap { row ->
            row.items.map { meta ->
                CachedMeta(
                    addonId = row.addonId,
                    addonName = row.addonName,
                    baseUrl = row.baseUrl,
                    meta = meta
                )
            }
        }
    }

    /** [type] filters by content type ("movie", "series", "tv"); null searches everything. */
    fun search(query: String, type: String? = null): List<CachedMeta> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return catalogCache
            .filter { (type == null || it.meta.type == type) && it.meta.name.lowercase().contains(q) }
            .distinctBy { it.meta.id + it.addonId }
            .take(100)
    }

    /**
     * Live search against installed addons (the catalog `search=` extra).
     * This is what finds titles that were never browsed into the local cache.
     *
     * Protocol-correct: `search=` is only fired at catalogs that declare the
     * "search" extra — addons without it answer 404, so querying them is
     * pure waste. A hard overall timeout keeps "Searching…" from hanging.
     */
    /** Emits a cumulative result snapshot whenever a provider finishes. A slow
     * addon is bounded independently and cannot erase faster providers' results. */
    fun searchRemoteProgressive(query: String, type: String? = null) = channelFlow {
        val q = query.trim()
        if (q.isEmpty()) { send(emptyList()); return@channelFlow }
        val types = if (type != null) listOf(type) else listOf("movie", "series")
        val resultMap = java.util.concurrent.ConcurrentHashMap<String, CachedMeta>()
        val providers = enabledAddons().filter { it.hasCatalog }
        providers.map { addon ->
            launch {
                val found = withTimeoutOrNull(REMOTE_SEARCH_PROVIDER_TIMEOUT_MS) {
                    val manifest = cachedManifest(addon.baseUrl) ?: return@withTimeoutOrNull emptyList()
                    buildList {
                        for (t in types) {
                            for (catalog in manifest.catalogs.filter { it.type == t && it.supportsSearch }.take(3)) {
                                try {
                                    addonRequest { api.searchCatalog(addon.baseUrl, t, catalog.id, q) }.forEach { meta ->
                                        add(CachedMeta(addon.id, addon.name, addon.baseUrl, meta.copy(type = t)))
                                    }
                                } catch (cancel: CancellationException) { throw cancel }
                                catch (_: Exception) { /* another catalog/provider can still succeed */ }
                            }
                        }
                    }
                } ?: emptyList()
                found.forEach { resultMap.putIfAbsent(it.addonId + it.meta.id, it) }
                send(resultMap.values.toList())
            }
        }.joinAll()
    }

    suspend fun searchRemote(query: String, type: String? = null): List<CachedMeta> =
        searchRemoteProgressive(query, type).last()

    /**
     * P10 (v0.14.22): local-cache hits ONLY — no network. Search renders
     * these instantly (the progressive-loading principle) while the
     * remote legs settle behind them.
     */
    suspend fun searchLocalOnly(query: String, type: String? = null): List<CachedMeta> =
        withContext(Dispatchers.IO) {
            if (catalogCache.isEmpty()) {
                runCatching { loadCatalogRowsCached() }
            }
            rankSearchResults(search(query, type), query)
        }

    /**
     * App-owned PRIMARY search stage (v0.14.27, Option A): the result
     * set no longer depends on which metadata addon is installed.
     * With a saved TMDB key the app queries TMDB directly (the
     * existing [TmdbClient.search] previews plus the
     * [TmdbClient.searchWithPopularity] ranking signals, fetched in
     * parallel); keyless installs call PMeta's first-party
     * `/search.json`, which performs the same TMDB search server-side
     * (12-minute server cache; Cinemeta fallback inside the endpoint).
     * Either lane returns popularity-bearing previews — tt-preferred
     * ids from PMeta, `tmdb:` ids from the direct lane (the existing
     * detail-target resolution handles both). Any failure yields an
     * empty list: the addon floor in [searchProgressiveUnion] still
     * runs, and an empty primary can never suppress it.
     */
    suspend fun searchPrimary(query: String, type: String? = null): List<CachedMeta> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        return try {
            withTimeoutOrNull(PRIMARY_SEARCH_TIMEOUT_MS) {
                val key = settings.tmdbApiKey?.takeIf { it.isNotBlank() }
                if (key != null) {
                    coroutineScope {
                        val previews = async { TmdbClient.search(key, q) }
                        val signals = async { TmdbClient.searchWithPopularity(key, q) }
                        TmdbClient.attachPopularity(previews.await(), signals.await())
                            .filter { type == null || it.type == type || (type == "tv" && it.type == "series") }
                            .map {
                                CachedMeta(
                                    addonId = SearchSupport.TMDB_ADDON_ID,
                                    // Display name is "Plavio Search" like
                                    // every own-machinery lane (owner's rule
                                    // 2026-10-31); the synthetic id is unchanged.
                                    addonName = SearchSupport.PRIMARY_SEARCH_NAME,
                                    baseUrl = "",
                                    meta = it
                                )
                            }
                    }
                } else {
                    // First-party constant URL (SearchSupport.keylessSearchUrl):
                    // never read from an installed addon's record, and this
                    // branch runs on key-absence alone — PMeta removed or
                    // disabled cannot stop it.
                    parsePrimarySearchPayload(BoundedHttp.get(SearchSupport.keylessSearchUrl(q)), type)
                }
            } ?: emptyList()
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { emptyList() }
    }

    /** PMeta /search.json payload → primary-lane previews (popularity kept). */
    private fun parsePrimarySearchPayload(text: String, type: String?): List<CachedMeta> {
        val results = JSONObject(text).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<CachedMeta>(results.length())
        for (i in 0 until results.length()) {
            val obj = results.optJSONObject(i) ?: continue
            fun str(key: String): String? =
                if (obj.isNull(key)) null else obj.optString(key).takeIf { it.isNotBlank() }
            val id = str("id") ?: continue
            val itemType = when (str("type")) {
                "tv" -> "series"
                else -> str("type") ?: "movie"
            }
            if (type != null && itemType != type && !(type == "tv" && itemType == "series")) continue
            val genresJson = obj.optJSONArray("genres")
            val genres = if (genresJson == null) emptyList() else buildList {
                for (j in 0 until genresJson.length()) {
                    genresJson.optString(j).takeIf { it.isNotBlank() }?.let { add(it) }
                }
            }
            out += CachedMeta(
                addonId = SearchSupport.PRIMARY_ADDON_ID,
                // Lane name is "Plavio Search" (owner's final label
                // spec 2026-10-31); the synthetic id is unchanged too.
                addonName = SearchSupport.PRIMARY_SEARCH_NAME,
                // Provenance base: the effective PMeta door (remote
                // config → compiled default, AppConfig) — the lane's
                // answers come from PMeta's current home, wherever
                // the config has pointed it.
                baseUrl = AppConfig.pmetaDoor(),
                meta = MetaPreview(
                    id = id,
                    type = itemType,
                    name = str("name") ?: id,
                    poster = str("poster"),
                    background = str("background"),
                    logo = str("logo"),
                    description = str("description"),
                    releaseInfo = str("releaseInfo") ?: str("year"),
                    imdbRating = str("imdbRating"),
                    genres = genres,
                    popularity = obj.optDouble("popularity", 0.0),
                    originalLanguage = str("originalLanguage") ?: str("original_language")
                        ?: str("language")
                )
            )
        }
        return out
    }

    // NOTE on Search captions (owner's final label spec v3,
    // 2026-10-31): the Search screen renders the constant caption
    // "Plavio Search" under EVERY result card at the render seam
    // (SearchScreen's GridPoster), whichever lane or addon produced
    // the row. Rows here therefore keep their TRUE addonId/addonName
    // provenance — Detail opening, stream routing and the merge all
    // depend on it — and nothing in this file rewrites display names.

    /**
     * Progressive union search (v0.14.27): emits the ranked union every
     * time a lane lands — query-cache seed + local catalogue first,
     * then the app-owned primary stage and each addon-floor snapshot
     * as they arrive. Lanes only ever ADD rows: the merge is a union
     * by canonical identity (primary fields win a collision), so no
     * lane's answer — empty or not — can discard another lane's
     * results. The final emission is the settled union (with the one
     * bounded typo-correction attempt applied when the primary stage
     * found nothing), and it is what [searchAll] returns.
     */
    fun searchProgressiveUnion(query: String, type: String? = null): Flow<List<CachedMeta>> =
        channelFlow {
            val q = query.trim()
            if (q.isEmpty()) {
                send(emptyList())
                return@channelFlow
            }
            // Warm the in-memory search cache from the DB when Home hasn't
            // loaded it yet this session — otherwise local search silently
            // returns nothing.
            if (catalogCache.isEmpty()) {
                runCatching { loadCatalogRowsCached() }
            }
            val addons = try { enabledAddons() } catch (_: Exception) { emptyList() }
            val rankByAddonId = addons.associate { it.id to metaRank(it) }
            fun addonRank(cm: CachedMeta): Int =
                if (SearchSupport.isPrimary(cm)) 0 else rankByAddonId[cm.addonId] ?: 2
            fun rankedUnion(primary: List<CachedMeta>, floor: List<CachedMeta>): List<CachedMeta> =
                SearchSupport.rank(SearchSupport.mergeByIdentity(primary, floor), q) { addonRank(it) }

            val typeKey = type ?: "all"
            val scope = addons.map { it.id }.sorted().joinToString(",") +
                "|keyed=" + (!settings.tmdbApiKey.isNullOrBlank())
            val seed = SearchSupport.cacheSeed(
                searchQueryCache.values, scope, typeKey, SearchSupport.normalize(q),
                System.currentTimeMillis(), SEARCH_QUERY_CACHE_TTL_MS
            )
            val local = search(q, type)

            val stateLock = Any()
            var primary: List<CachedMeta> = emptyList()
            var floor: List<CachedMeta> = local
            suspend fun emitDisplay() {
                val snapshot = synchronized(stateLock) { rankedUnion(primary, floor + seed) }
                if (snapshot.isNotEmpty()) send(snapshot)
            }
            emitDisplay()

            val primaryJob = launch {
                val found = try {
                    searchPrimary(q, type)
                } catch (cancel: CancellationException) { throw cancel }
                catch (_: Exception) { emptyList() }
                synchronized(stateLock) { primary = found }
                emitDisplay()
            }
            val floorJob = launch {
                try {
                    searchRemoteProgressive(q, type).collect { snapshot ->
                        synchronized(stateLock) { floor = local + snapshot }
                        emitDisplay()
                    }
                } catch (cancel: CancellationException) { throw cancel }
                catch (_: Exception) { /* the primary lane + local hits still stand */ }
            }
            primaryJob.join()
            floorJob.join()

            // One bounded typo-correction attempt, only when the primary
            // stage found nothing (see SearchSupport.correctionCandidate
            // for exactly what it covers). Corrected rows join as
            // primary results; the floor is never re-asked or dropped.
            if (primary.isEmpty() && q.length >= 4) {
                val dictionary = buildList {
                    addAll(catalogCache.map { it.meta.name })
                    addAll(floor.map { it.meta.name })
                    addAll(seed.map { it.meta.name })
                    searchQueryCache.values.forEach { entry ->
                        addAll(entry.results.map { it.meta.name })
                    }
                }
                val candidate = SearchSupport.correctionCandidate(q, dictionary)
                if (candidate != null) {
                    val corrected = try {
                        searchPrimary(candidate, type)
                    } catch (cancel: CancellationException) { throw cancel }
                    catch (_: Exception) { emptyList() }
                    if (corrected.isNotEmpty()) {
                        synchronized(stateLock) { primary = corrected }
                    }
                }
            }

            var final = synchronized(stateLock) { rankedUnion(primary, floor) }
            if (final.isEmpty() && seed.isNotEmpty()) {
                // Every fresh lane came back empty (e.g. offline): the
                // cached seed is the honest best answer left.
                final = SearchSupport.rank(seed, q) { addonRank(it) }
            } else if (final.isNotEmpty()) {
                // MDBList IMDb ratings ride along when linked (card
                // chips) — top results only, one bounded batch.
                if (settings.mdblistApiKey != null) {
                    val head = enrichPreviewsWithMdb(final.take(20).map { it.meta }, 20)
                    final = final.mapIndexed { i, cm ->
                        if (i < 20) cm.copy(meta = head[i]) else cm
                    }
                }
                val cacheKey = "$scope|$typeKey|${SearchSupport.normalize(q)}"
                searchQueryCache[cacheKey] = SearchSupport.QueryCacheEntry(
                    scope = scope, typeKey = typeKey,
                    query = SearchSupport.normalize(q),
                    storedAtMs = System.currentTimeMillis(), results = final
                )
                while (searchQueryCache.size > SEARCH_QUERY_CACHE_MAX_ENTRIES) {
                    val oldest = searchQueryCache.values.minByOrNull { it.storedAtMs } ?: break
                    searchQueryCache.remove(
                        "${oldest.scope}|${oldest.typeKey}|${oldest.query}"
                    )
                }
            }
            // Warm trigger (v0.14.28, owner's order): the union has
            // SETTLED — this is the one moment a search warms its top
            // titles, on the exact set about to be emitted (seed
            // fallback included); never on a keystroke or a progressive
            // snapshot. Fire-and-forget (in-memory selection + a
            // repoScope launch inside), so it cannot delay or fail
            // this emission. The query key reuses the query-cache
            // identity above; each query warms once per session.
            warmSearchSettled("$scope|$typeKey|${SearchSupport.normalize(q)}", final)
            send(final)
        }.flowOn(Dispatchers.IO)

    /**
     * Combined search, settled form: the final emission of
     * [searchProgressiveUnion] — local + primary + addon floor as one
     * ranked union (v0.14.27). Previously the raw cache order surfaced
     * obscure old titles first (e.g. "sultan" listed 1930s titles
     * before Salman Khan's Sultan, 2016), and a flaky server leg could
     * overwrite better addon results; both are gone by construction.
     */
    suspend fun searchAll(query: String, type: String? = null): List<CachedMeta> =
        searchProgressiveUnion(query, type).last()

    /**
     * "Popular right now" for the Search tab's landing state (v0.12.4).
     * With a TMDB key: TMDB's weekly trending chart. Without one: the
     * best in-app source — titles from cached catalog rows whose name/id
     * reads as a chart (trending / popular / top — Cinemeta's "top"
     * catalogs land in that bucket), best-scored rows first, flattened
     * in row order and de-duplicated by title id. Empty when neither
     * source can supply anything (the landing then shows recents only).
     */
    suspend fun loadPopularTitles(limit: Int = 10): List<CachedMeta> =
        withContext(Dispatchers.IO) {
            val rows = runCatching { loadCatalogRowsCached() }.getOrDefault(emptyList())
            if (rows.isEmpty()) return@withContext emptyList()
            fun chartScore(row: CatalogRow): Int {
                val text = "${row.catalogName} ${row.catalogId}".lowercase()
                var score = 0
                if ("trending" in text) score += 3
                if ("popular" in text) score += 3
                if ("top" in text) score += 2
                if ("featured" in text) score += 1
                return score
            }
            rows.filter { it.type == "movie" || it.type == "series" }
                .map { it to chartScore(it) }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .flatMap { (row, _) -> row.items.map { row to it } }
                .distinctBy { it.second.id }
                .take(limit)
                .map { (row, meta) ->
                    CachedMeta(
                        addonId = row.addonId,
                        addonName = row.addonName,
                        baseUrl = row.baseUrl,
                        meta = meta
                    )
                }
        }

    /**
     * Popular BY LANGUAGE (v0.14.32) — the Search landing's
     * "Popular" section pipe: quotas follow the user's own search
     * history (see [popularLanguagePlan]); titles come DIRECT
     * from TMDB Discover per language (see
     * [TmdbClient.discoverPopular] — never Similar). Returns bare
     * previews; the caller wraps them with a meta addon's identity
     * like the suggestions grid does. Empty without a TMDB key or
     * when Discover yields nothing — the caller then falls back
     * to [loadPopularTitles] (today's global popular behaviour).
     */
    suspend fun loadPopularByLanguages(
        languages: List<String>,
        limit: Int = 48
    ): List<MetaPreview> = withContext(Dispatchers.IO) {
        val apiKey = settings.tmdbApiKey?.takeIf { it.isNotBlank() }
            ?: return@withContext emptyList()
        val plan = popularLanguagePlan(languages, limit)
        if (plan.isEmpty()) return@withContext emptyList()
        val perLanguage = LinkedHashMap<String, List<MetaPreview>>()
        for ((language, quota) in plan) {
            perLanguage[language] = runCatching {
                TmdbClient.discoverPopular(apiKey, language, (quota + 12).coerceAtMost(52))
            }.getOrDefault(emptyList())
        }
        mixPopularByLanguage(perLanguage, plan, emptySet(), limit)
    }

    /**
     * Search ranking (v0.14.27): the pure rules live in [SearchSupport]
     * so the progressive union flow and the unit tests share them —
     * cross-lane title collapse (primary fields win, remakes stay
     * separate), then match tier, TMDB popularity, IMDb rating, year,
     * addon preference.
     */
    private suspend fun rankSearchResults(results: List<CachedMeta>, query: String): List<CachedMeta> {
        if (results.size < 2) return results
        val byAddonId = try { enabledAddons().associateBy { it.id } } catch (_: Exception) { emptyMap() }
        return SearchSupport.rank(results, query) { cm ->
            if (SearchSupport.isPrimary(cm)) 0
            else byAddonId[cm.addonId]?.let(::metaRank) ?: 2
        }
    }

    /** In-memory manifest cache so Home/Live/search don't refetch manifests per load. */
    private val manifestCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, AddonManifest>>()

    /**
     * Persisted manifest store (v0.14.35, cold-start fix step 5):
     * baseUrl -> (fetchedAt, manifest), mirrored into
     * [SettingsStore.manifestStoreJson] so it survives process death.
     * The memory cache alone died with the process, so every cold
     * start paid a serial manifest round-trip per addon before any
     * catalog could start; the disk copy answers under the same
     * [MANIFEST_TTL_MS] with no network at all. Loaded lazily,
     * written through on every successful fetch, pruned to installed
     * addons on each Home refresh so it can't accumulate dead URLs.
     */
    private val persistedManifestLock = Any()
    private var persistedManifests: MutableMap<String, Pair<Long, AddonManifest>>? = null

    private fun persistedManifestStore(): MutableMap<String, Pair<Long, AddonManifest>> {
        persistedManifests?.let { return it }
        synchronized(persistedManifestLock) {
            persistedManifests?.let { return it }
            // A corrupt store decodes to empty — it just costs one
            // cold fetch (ManifestStoreCodec).
            val loaded = ManifestStoreCodec.decodeStore(settings.manifestStoreJson)
                .toMutableMap()
            persistedManifests = loaded
            return loaded
        }
    }

    private fun writePersistedManifests(store: Map<String, Pair<Long, AddonManifest>>) {
        try {
            settings.manifestStoreJson = ManifestStoreCodec.encodeStore(store)
        } catch (_: Exception) { /* persistence is best-effort */ }
    }

    /** Records a freshly fetched manifest in memory AND on disk. */
    private fun storeManifest(baseUrl: String, fetchedAt: Long, manifest: AddonManifest) {
        manifestCache[baseUrl] = fetchedAt to manifest
        synchronized(persistedManifestLock) {
            val store = persistedManifestStore()
            store[baseUrl] = fetchedAt to manifest
            writePersistedManifests(store)
        }
    }

    /** Drops one manifest from memory AND disk (addon changed/removed/refreshed). */
    private fun evictManifest(baseUrl: String) {
        manifestCache.remove(baseUrl)
        synchronized(persistedManifestLock) {
            val store = persistedManifestStore()
            if (store.remove(baseUrl) != null) writePersistedManifests(store)
        }
    }

    /** Drops every manifest from memory AND disk (backup restore / reset paths). */
    private fun clearAllManifestCaches() {
        manifestCache.clear()
        synchronized(persistedManifestLock) {
            persistedManifests = mutableMapOf()
            settings.manifestStoreJson = null
        }
    }

    /** Removes persisted manifests whose addon is no longer installed. */
    private fun prunePersistedManifests(liveBaseUrls: Set<String>) {
        synchronized(persistedManifestLock) {
            val store = persistedManifestStore()
            if (store.keys.removeAll { it !in liveBaseUrls }) {
                writePersistedManifests(store)
            }
        }
    }

    /** Cheap manifest peek: memory first, then the persisted store. No network. */
    private fun peekManifest(baseUrl: String): AddonManifest? =
        manifestCache[baseUrl]?.second ?: persistedManifestStore()[baseUrl]?.second

    private suspend fun cachedManifest(baseUrl: String): AddonManifest? {
        val now = System.currentTimeMillis()
        manifestCache[baseUrl]?.let { (ts, manifest) ->
            if (now - ts < MANIFEST_TTL_MS) return manifest
        }
        // Disk copy next: within the TTL it answers with no network
        // round-trip at all — the cold-start win (step 5).
        val persisted = persistedManifestStore()[baseUrl]
        if (persisted != null && now - persisted.first < MANIFEST_TTL_MS) {
            manifestCache[baseUrl] = persisted
            return persisted.second
        }
        // A failed refetch falls back to the stale manifest (memory
        // first, then disk) instead of silently dropping the provider
        // everywhere (2026-10-23).
        val stale = manifestCache[baseUrl]?.second ?: persisted?.second
        val manifest = try { addonRequest { api.fetchManifest(baseUrl) } }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { return stale }
        storeManifest(baseUrl, now, manifest)
        return manifest
    }

    /**
     * Manual manifest refresh: bypasses the TTL caches (memory AND
     * disk) and re-fetches from the network. Use after an addon gains
     * capabilities (e.g. newly search-capable catalogs) instead of
     * waiting out the TTL.
     */
    suspend fun refreshManifest(baseUrl: String): AddonManifest? {
        evictManifest(baseUrl)
        return cachedManifest(baseUrl)
    }

    /** Drops the whole manifest cache, memory and disk (e.g. on pull-to-refresh). */
    fun clearManifestCache() {
        clearAllManifestCaches()
    }

    suspend fun getMeta(baseUrl: String, type: String, id: String): MetaDetail? =
        withContext(Dispatchers.IO) {
            api.fetchMeta(baseUrl, type, id)?.let { enrichFromTmdb(it) }
        }

    /**
     * TMDB Enrichment (v0.14.6): fills the meta's gaps from TMDB when the
     * user linked a TMDB key and left any of the seven toggles on. The
     * serving addon's own data always wins — see TmdbClient.enrichMeta.
     */
    private suspend fun enrichFromTmdb(meta: MetaDetail): MetaDetail {
        if (!settings.tmdbEnrichmentActive) return meta
        val key = settings.tmdbApiKey ?: return meta
        val toggles = TmdbClient.EnrichToggles(
            artwork = settings.tmdbEnrichArtwork,
            basicInfo = settings.tmdbEnrichBasicInfo,
            details = settings.tmdbEnrichDetails,
            credits = settings.tmdbEnrichCredits,
            productions = settings.tmdbEnrichProductions,
            networks = settings.tmdbEnrichNetworks,
            episodes = settings.tmdbEnrichEpisodes
        )
        return runCatching { TmdbClient.enrichMeta(key, meta, toggles) }.getOrDefault(meta)
    }

    // ---- MDBList (v0.14.6) ----

    /** Session cache of MDBList ratings by IMDb id (empty Ratings = known miss). */
    private val mdbRatingsCache = java.util.concurrent.ConcurrentHashMap<String, MdbListApi.Ratings>()

    /** Ratings for one title from the linked MDBList account. Null when unlinked / no data. */
    suspend fun mdbRatings(imdbId: String): MdbListApi.Ratings? {
        val key = settings.mdblistApiKey ?: return null
        if (!imdbId.startsWith("tt")) return null
        mdbRatingsCache[imdbId]?.let { return it.takeIf { r -> !r.isEmpty } }
        val fetched = runCatching { MdbListApi(key).ratings(imdbId) }.getOrNull()
        mdbRatingsCache[imdbId] = fetched ?: MdbListApi.Ratings()
        return fetched
    }

    // ---- Universal ratings endpoint (v0.14.20) ----
    //
    // Titles whose meta came from an addon WITHOUT MDBList fields get
    // the same ratings from the PMeta Worker's /ratings endpoint
    // (owner's key, server-side cache). Independent of the user's own
    // MDBList key above: no key, no settings — it just works. Answers
    // are cached in memory for the session and on disk for 3 days;
    // in-session misses are re-asked at most every 6 hours (the
    // server caches its own empties too).

    private val endpointRatingsMem =
        java.util.concurrent.ConcurrentHashMap<String, StremioParser.EndpointRatings>()
    private val endpointRatingsMissAt =
        java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val endpointRatingsDiskLock = Any()

    /** Ratings for one tt id from the universal endpoint. Null when it has nothing. */
    suspend fun endpointRatings(ttId: String): StremioParser.EndpointRatings? {
        if (!ttId.startsWith("tt")) return null
        endpointRatingsMem[ttId]?.let { return it }
        readEndpointRatingsDisk(ttId)?.let { parsed ->
            endpointRatingsMem[ttId] = parsed
            return parsed
        }
        val missAt = endpointRatingsMissAt[ttId]
        if (missAt != null && System.currentTimeMillis() - missAt < 6 * 60 * 60 * 1000L) {
            return null
        }
        val body = runCatching { RatingsEndpointClient.fetchBody(ttId) }.getOrNull()
        val parsed = body?.let { runCatching { StremioParser.parseRatingsEndpoint(it) }.getOrNull() }
        if (parsed == null) {
            endpointRatingsMissAt[ttId] = System.currentTimeMillis()
            return null
        }
        writeEndpointRatingsDisk(ttId, body)
        endpointRatingsMem[ttId] = parsed
        return parsed
    }

    private fun readEndpointRatingsDisk(ttId: String): StremioParser.EndpointRatings? {
        val raw = settings.ratingsEndpointCacheJson ?: return null
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        val entry = root.optJSONObject(ttId) ?: return null
        val at = entry.optLong("at", 0L)
        if (System.currentTimeMillis() - at > 3 * 24 * 60 * 60 * 1000L) return null
        val body = entry.optString("body").takeIf { it.isNotBlank() } ?: return null
        return runCatching { StremioParser.parseRatingsEndpoint(body) }.getOrNull()
    }

    private fun writeEndpointRatingsDisk(ttId: String, body: String) {
        synchronized(endpointRatingsDiskLock) {
            runCatching {
                val root = settings.ratingsEndpointCacheJson
                    ?.let { runCatching { JSONObject(it) }.getOrNull() }
                    ?: JSONObject()
                val now = System.currentTimeMillis()
                root.put(ttId, JSONObject().put("at", now).put("body", body))
                // Prune: expired entries out, and keep at most 300
                // (oldest first) so the preference stays small.
                val ttl = 3 * 24 * 60 * 60 * 1000L
                val entries = mutableListOf<Pair<String, Long>>()
                val keys = root.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    entries += k to (root.optJSONObject(k)?.optLong("at", 0L) ?: 0L)
                }
                entries.filter { now - it.second > ttl }
                    .forEach { root.remove(it.first) }
                val alive = entries.filter { now - it.second <= ttl }
                    .sortedBy { it.second }
                if (alive.size > 300) {
                    alive.take(alive.size - 300).forEach { root.remove(it.first) }
                }
                settings.ratingsEndpointCacheJson = root.toString()
            }
        }
    }

    /**
     * Fills blank imdbRating on previews from MDBList (the IMDb chip on
     * poster cards). Bounded per call so a big catalog can't stall the
     * caller; the session cache makes later calls cheap.
     */
    private suspend fun enrichPreviewsWithMdb(
        metas: List<MetaPreview>, cap: Int = 24
    ): List<MetaPreview> {
        if (settings.mdblistApiKey == null) return metas
        val targets = metas.filter { it.imdbRating.isNullOrBlank() && it.id.startsWith("tt") }
        if (targets.isEmpty()) return metas
        val ratings = kotlinx.coroutines.coroutineScope {
            targets.take(cap).chunked(6).flatMap { chunk ->
                chunk.map { meta -> async { meta.id to mdbRatings(meta.id) } }.awaitAll()
            }.toMap()
        }
        return metas.map { meta ->
            val rating = ratings[meta.id]?.imdb
            if (rating != null && meta.imdbRating.isNullOrBlank()) {
                meta.copy(imdbRating = "%.1f".format(rating))
            } else meta
        }
    }

    private suspend fun enrichRowsWithMdb(rows: List<CatalogRow>): List<CatalogRow> {
        if (settings.mdblistApiKey == null) return rows
        var budget = 24
        val out = mutableListOf<CatalogRow>()
        for (row in rows) {
            if (budget <= 0) { out += row; continue }
            val enriched = enrichPreviewsWithMdb(row.items, budget)
            budget -= row.items.count { it.imdbRating.isNullOrBlank() && it.id.startsWith("tt") }
                .coerceAtMost(24)
            out += row.copy(items = enriched)
        }
        return out
    }

    private fun addonTypes(addon: InstalledAddon): Set<String> =
        addon.types.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Addons that can serve metadata for [type] (hint addon's base URL first). */
    suspend fun metaAddonsFor(type: String, hintBaseUrl: String? = null): List<InstalledAddon> =
        withContext(Dispatchers.IO) {
            enabledAddons()
                .filter { addon ->
                    addon.hasMeta && run {
                        val types = addonTypes(addon)
                        types.isEmpty() || type in types
                    }
                }
                .sortedWith(
                    compareByDescending<InstalledAddon> { it.baseUrl == hintBaseUrl }
                        .thenBy { metaRank(it) }
                )
        }

    private fun isPlavioMeta(addon: InstalledAddon): Boolean =
        addon.id.contains("plaviometa", ignoreCase = true) ||
                // v0.14.28: PMeta's manifest id and its new home domain
                // contain neither "plaviometa" string — without these
                // two checks the domain move would silently strip
                // PMeta's rank-0 preference and its /related + /person
                // first-choice seat (plavioMetaBaseUrl).
                addon.id.contains("plavio.catalogs", ignoreCase = true) ||
                addon.baseUrl.contains("plaviometa", ignoreCase = true) ||
                addon.baseUrl.contains("meta.plavio.site", ignoreCase = true) ||
                // The remote config's PMeta door, wherever it points
                // today: a PMeta row re-pointed by a future door move
                // keeps its identity (and its rank-0 seat).
                addon.baseUrl.toHttpUrlOrNull()?.host?.equals(
                    AppConfig.pmetaDoor().toHttpUrlOrNull()?.host, ignoreCase = true
                ) == true

    private fun isCinemeta(addon: InstalledAddon): Boolean =
        addon.id.contains("cinemeta", ignoreCase = true) ||
                addon.baseUrl.contains("cinemeta", ignoreCase = true)

    /**
     * Rank for metadata/catalog priority. PlavioMeta is always the default
     * source: its posters/details come first, Cinemeta is the fallback,
     * everything else keeps its relative order after.
     */
    private fun metaRank(addon: InstalledAddon): Int {
        val plavio = isPlavioMeta(addon)
        val cine = isCinemeta(addon)
        return when {
            plavio -> 0
            cine -> 1
            else -> 2
        }
    }

    /**
     * The owner's picker arrangement (v0.14.15): rows whose typed key
     * ("addonId|type|catalogId") appears in
     * [SettingsStore.homeCatalogOrder] come first, in the saved order
     * — the first saved key is the TOP row on Home. Rows with no saved
     * position keep their natural (preference-sorted) relative order
     * after them. Saved keys whose catalog is gone (addon removed,
     * catalog dropped, provider switched) match nothing and fall away
     * on their own; brand-new catalogs land in the natural tail.
     * Applied on both Home row paths (cached + refresh); the Live tab
     * loads through loadTvRows instead and is untouched — and its
     * "tv" keys never enter the saved list, since the picker only
     * arranges Home catalogs.
     */
    private fun applyHomeCatalogOrder(rows: List<CatalogRow>): List<CatalogRow> {
        val saved = settings.homeCatalogOrder
        if (saved.isEmpty() || rows.size < 2) return rows
        val rank = HashMap<String, Int>(saved.size).apply {
            saved.forEachIndexed { index, key -> put(key, index) }
        }
        val (arranged, natural) = rows.partition {
            "${it.addonId}|${it.type}|${it.catalogId}" in rank
        }
        if (arranged.isEmpty()) return rows
        return arranged.sortedBy {
            rank.getValue("${it.addonId}|${it.type}|${it.catalogId}")
        } + natural
    }

    /** Sorts catalog rows so the preferred metadata source's rows come first. */
    private fun sortRowsByPreference(
        rows: List<CatalogRow>,
        byAddonId: Map<String, InstalledAddon>
    ): List<CatalogRow> =
        rows.sortedWith(
            compareBy<CatalogRow> { byAddonId[it.addonId]?.let(::metaRank) ?: 2 }
                .thenBy { byAddonId[it.addonId]?.sortOrder ?: Int.MAX_VALUE }
        )

    /** Addons that can serve streams. */
    suspend fun streamAddons(): List<InstalledAddon> = withContext(Dispatchers.IO) {
        enabledAddons().filter { it.hasStream }
    }

    /**
     * PlavioMeta base URL (the user's configured URL when they set a TMDB
     * key). Powers /related and /person, which need TMDB server-side.
     */
    suspend fun plavioMetaBaseUrl(): String? = withContext(Dispatchers.IO) {
        enabledAddons().firstOrNull { isPlavioMeta(it) }?.baseUrl
    }

    /**
     * Base URL of the public PlavioHD addon — the server that
     * implements /warm (v1.9.128). Door priority (AppConfig): a
     * published plaviohd door wins (host-validated to our own
     * domains). Otherwise streams reach PlavioHD through the
     * installed addon's own baseUrl, so warming resolves the same
     * way: a user who re-pointed the addon (same manifest id, another
     * host) warms the server they actually use. The manifest-id match
     * is tried first for exactly that reason; the hd.plavio.site host
     * match (the same first-party test stream budgets use) is the
     * fallback. The locked addon (addon.plavio.site) carries a
     * different manifest id on a different server and never matches.
     * Null when PlavioHD is absent or disabled — warming then skips
     * silently and search/detail behave exactly as before (the
     * search-independence rule: our search never depends on it).
     */
    suspend fun plavioHdBaseUrl(): String? = withContext(Dispatchers.IO) {
        // Door priority (AppConfig): a published plaviohd door wins —
        // it is host-validated to our own domains, so it can only
        // re-point between first-party servers. Unset, the stored
        // tier below decides exactly as before.
        AppConfig.current().plaviohdDoor?.let { return@withContext it }
        val addons = enabledAddons()
        (addons.firstOrNull { it.id == WarmSupport.PLAVIOHD_MANIFEST_ID }
            ?: addons.firstOrNull {
                it.baseUrl.toHttpUrlOrNull()?.host == StremioApi.FIRST_PARTY_HOST
            })?.baseUrl
    }

    // ---- Warm triggers (v0.14.28, owner's order 2026-10-31) ----
    //
    // "When someone searches a title, or someone clicks on a catalog
    // card title, it should start caching the title for quick
    // loading." Both entry points below are fire-and-forget: they do
    // in-memory selection only, then hand the actual ping to
    // repoScope + PlavioWarm (async enqueue, short timeout, every
    // outcome swallowed). No call site can block, delay, or fail
    // because of them.

    /**
     * Search trigger: a SETTLED union warms its top
     * [WarmSupport.SEARCH_WARM_LIMIT] tt-carrying survivors, once per
     * query per session. Progressive snapshots never reach this — the
     * only caller is the settled tail of [searchProgressiveUnion].
     */
    fun warmSearchSettled(queryKey: String, results: List<CachedMeta>) {
        // Remote switch (AppConfig): warmTriggers off silences every
        // warm hook at these two repository entry points; the switch
        // absent means on — the behaviour the feature shipped with.
        if (!AppConfig.warmTriggersEnabled()) return
        val targets = WarmSupport.selectSearchTargets(results)
        if (targets.isEmpty()) return
        repoScope.launch {
            val base = plavioHdBaseUrl() ?: return@launch
            // Claimed only once a warm can actually be sent, so a
            // query settled while PlavioHD was absent can still warm
            // if the addon appears later in the session.
            if (!PlavioWarm.claimQuery(queryKey)) return@launch
            targets.forEach { PlavioWarm.warm(base, it) }
        }
    }

    /**
     * Detail trigger: opening a title (or selecting an episode) warms
     * it. [imdbId] may be any candidate the page holds — the
     * WarmSupport validation silently drops non-tt shapes (TMDB-only
     * and opaque-addon titles simply don't warm).
     */
    fun warmDetailTitle(
        type: String,
        imdbId: String?,
        season: Int? = null,
        episode: Int? = null
    ) {
        if (!AppConfig.warmTriggersEnabled()) return
        val target = WarmSupport.target(type, imdbId, season, episode) ?: return
        repoScope.launch {
            val base = plavioHdBaseUrl() ?: return@launch
            PlavioWarm.warm(base, target)
        }
    }

    /**
     * Every meta-capable addon in preference order (PlavioMeta first —
     * it stays the default and the richest path, never the only one).
     * Metadata flexibility (owner's standing order 2026-10-26): the
     * related rows and actor pages follow whichever installed metadata
     * addon can serve them, so AIOMetadata / Cinemeta / TMDB-addon
     * users get the full experience too.
     */
    private suspend fun metaAddonsByRank(): List<InstalledAddon> =
        enabledAddons()
            .filter { it.hasMeta }
            .sortedWith(compareBy<InstalledAddon> { metaRank(it) }.thenBy { it.sortOrder })

    /**
     * "More like this" + "More from <actor>" sections for a title.
     * First, /related is tried on every meta addon in preference order
     * (the serving addon's data wins — PlavioMeta's endpoint is simply
     * the richest). When no addon serves /related, the rows are built
     * app-side from STANDARD protocol data only: the title's own full
     * meta (genres, cast) plus the meta addons' genre catalogs and
     * search endpoints. A row appears only when real data backs it.
     * Between the two, a linked TMDB key (v0.14.16) serves the row
     * from TMDB recommendations + similar for ANY provider — see the
     * TMDB stage in the body.
     */
    /** TMDB numeric id inside a TMDB-shaped meta id, or null. Shapes:
     * "tmdb:movie:872585", "tmdb:tv:1396", bare "tmdb:872585". */
    private fun parseTmdbNumericId(id: String): Int? {
        if (!id.startsWith("tmdb:")) return null
        return id.removePrefix("tmdb:").removePrefix("movie:").removePrefix("tv:")
            .toIntOrNull()
    }

    /**
     * P3 (v0.14.22): resolve a TMDB-shaped id to its canonical tt id
     * before any related/person/streams lookup — PMeta serves an empty
     * stub meta for the tmdb:movie:/tmdb:tv: shapes, so keying a lookup
     * to them starves every downstream stage. The bare "tmdb:<n>" shape
     * IS served fully (its id is rewritten to tt), which is the channel
     * this resolution rides. Non-TMDB ids pass through untouched.
     */
    private suspend fun canonicalMetaId(type: String, id: String, hintBaseUrl: String?): String {
        if (id.startsWith("tt")) return id
        val n = parseTmdbNumericId(id) ?: return id
        val meta = runCatching { getMetaFromAny(hintBaseUrl, type, "tmdb:$n") }.getOrNull()
            ?: return id
        return meta.id.takeIf { it.startsWith("tt") }
            ?: meta.imdbId?.takeIf { it.startsWith("tt") }
            ?: meta.defaultVideoId?.takeIf { it.startsWith("tt") }
            ?: id
    }

    suspend fun getRelated(
        type: String,
        id: String,
        hintBaseUrl: String? = null
    ): List<RelatedSection> = withContext(Dispatchers.IO) {
        // P3: canonical tt id first — every stage below keys to it.
        val canonId = canonicalMetaId(type, id, hintBaseUrl)
        val addons = metaAddonsFor(type, hintBaseUrl)
        // Stage order (owner's decision 2026-10-31 06:28, P3):
        // TMDB FIRST, then the addon /related, then the generic fallback.
        val tmdbKey = settings.tmdbApiKey
        if (tmdbKey != null) {
            val meta = runCatching { getMetaFromAny(hintBaseUrl, type, canonId) }.getOrNull()
            if (meta != null) {
                val picks = runCatching { TmdbClient.moreLikeThis(tmdbKey, meta) }
                    .getOrDefault(emptyList())
                    .filter { it.id != canonId && it.id != id }
                    .distinctBy { it.id }
                if (picks.isNotEmpty()) {
                    return@withContext listOf(
                        RelatedSection(
                            id = "tmdb_more_like_this",
                            title = "More like this",
                            metas = picks
                        )
                    )
                }
            }
        }
        for (addon in addons) {
            val sections = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                runCatching { api.fetchRelated(addon.baseUrl, type, canonId) }.getOrNull()
            }
            if (!sections.isNullOrEmpty()) return@withContext sections
        }
        buildRelatedFallback(type, canonId, hintBaseUrl, addons)
    }

    /**
     * Generic related rows from standard addon data (see [getRelated]):
     * "More like this" = same-genre titles from the meta addons' genre
     * catalogs, widened by a genre search; "More from <actor>" = the
     * first-billed cast member's name run through the addons' search.
     */
    private suspend fun buildRelatedFallback(
        type: String,
        id: String,
        hintBaseUrl: String?,
        metaAddons: List<InstalledAddon>
    ): List<RelatedSection> {
        val meta = getMetaFromAny(hintBaseUrl, type, id) ?: return emptyList()
        val sections = mutableListOf<RelatedSection>()
        val seen = mutableSetOf(id)

        if (meta.genres.isNotEmpty() && metaAddons.isNotEmpty()) {
            val genre = meta.genres.first()
            val similar = LinkedHashMap<String, MetaPreview>()
            // Genre catalogs of the preferred meta addons first.
            for (addon in metaAddons.take(2)) {
                val manifest = runCatching { cachedManifest(addon.baseUrl) }.getOrNull()
                    ?: continue
                val genreCatalogs = manifest.catalogs.filter {
                    it.type == type && it.extra.any { e -> e.equals("genre", true) }
                }.take(2)
                for (catalog in genreCatalogs) {
                    val metas = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                        runCatching {
                            api.fetchCatalogGenre(addon.baseUrl, type, catalog.id, genre)
                        }.getOrNull()
                    } ?: continue
                    metas.forEach { m -> if (m.id != id) similar.putIfAbsent(m.id, m) }
                }
            }
            // Widen with a genre search across the standard search path.
            runCatching { searchRemote(genre, type) }.getOrDefault(emptyList())
                .forEach { cm -> if (cm.meta.id != id) similar.putIfAbsent(cm.meta.id, cm.meta) }
            val genreSet = meta.genres.map { it.lowercase() }.toSet()
            val picks = similar.values
                .filter { m ->
                    m.genres.isEmpty() ||
                        m.genres.any { it.lowercase() in genreSet }
                }
                .take(20)
            if (picks.isNotEmpty()) {
                sections += RelatedSection(
                    id = "fallback_similar",
                    title = "More like this",
                    metas = picks
                )
                picks.forEach { seen += it.id }
            }
        }

        val leadActor = meta.cast.firstOrNull { it.name.isNotBlank() }
        if (leadActor != null) {
            val fromActor = runCatching { searchAll(leadActor.name, type) }
                .getOrDefault(emptyList())
                .map { it.meta }
                .filter { it.id != id && it.id !in seen }
                .distinctBy { it.id }
                .take(20)
            if (fromActor.isNotEmpty()) {
                sections += RelatedSection(
                    id = "fallback_actor",
                    title = "More from ${leadActor.name}",
                    metas = fromActor
                )
            }
        }
        return sections
    }

    /**
     * Actor filmography. /person is tried on every meta addon in
     * preference order (PlavioMeta first — richest). When no addon
     * serves /person for this id, [name] unlocks the generic fallback:
     * the addons' own search by actor name, split into movies/series —
     * the same standard-protocol trick as the related rows.
     */
    suspend fun getPerson(personId: Int, name: String? = null): PersonDetail? =
        withContext(Dispatchers.IO) {
            if (personId > 0) {
                // Stage order (owner's decision 2026-10-31 06:28, P3):
                // TMDB FIRST, then the addon /person, then the generic
                // name-search fallback below.
                val tmdbKey = settings.tmdbApiKey
                if (tmdbKey != null) {
                    val person = runCatching { TmdbClient.getPerson(tmdbKey, personId) }
                        .getOrNull()
                    if (person != null &&
                        (person.movies.isNotEmpty() || person.series.isNotEmpty() ||
                            person.photo != null)
                    ) {
                        return@withContext person
                    }
                }
                for (addon in metaAddonsByRank()) {
                    val person = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                        runCatching { api.fetchPerson(addon.baseUrl, personId) }.getOrNull()
                    }
                    if (person != null &&
                        (person.movies.isNotEmpty() || person.series.isNotEmpty())
                    ) {
                        return@withContext person
                    }
                }
            }
            val personName = name?.takeIf { it.isNotBlank() } ?: return@withContext null
            val found = runCatching { searchAll(personName) }.getOrDefault(emptyList())
            if (found.isEmpty()) return@withContext null
            val movies = found.filter { it.meta.type == "movie" }
                .map { it.meta }.distinctBy { it.id }.take(40)
            val series = found.filter { it.meta.type == "series" }
                .map { it.meta }.distinctBy { it.id }.take(40)
            if (movies.isEmpty() && series.isEmpty()) return@withContext null
            PersonDetail(
                id = personId,
                name = personName,
                photo = null,
                movies = movies,
                series = series
            )
        }

    /**
     * People matching a search query (owner's order 2026-10-26 — search
     * by actor). First, the /person-search route is asked on every meta
     * addon in preference order (PlavioMeta serves it since v2.5.7): a
     * real person index beats guessing from cast lists, and an answer
     * from a supporting addon — even an empty one — is final. Only when
     * NO installed meta addon serves the route does the cast-scan
     * fallback below run. Either way the result is plain [CastMember]s
     * with TMDB person ids, and tapping one opens the actor page.
     */
    suspend fun searchPeople(query: String): List<CastMember> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.length < 2) return@withContext emptyList()
            for (addon in metaAddonsByRank()) {
                val found = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                    runCatching { api.fetchPersonSearch(addon.baseUrl, q) }.getOrNull()
                }
                if (found != null) return@withContext found.take(10)
            }
            searchPeopleFromCast(q)
        }

    /**
     * Fallback people search for installs whose meta addons don't serve
     * /person-search: the top title results' full metas are read from
     * whichever addons served them, and cast members whose name matches
     * the query surface as people (name + photo when the addon
     * provides them).
     */
    private suspend fun searchPeopleFromCast(q: String): List<CastMember> =
        withContext(Dispatchers.IO) {
            val results = runCatching { searchAll(q) }.getOrDefault(emptyList()).take(6)
            if (results.isEmpty()) return@withContext emptyList()
            val people = LinkedHashMap<String, CastMember>()
            for (cm in results) {
                val meta = runCatching {
                    getMetaFromAny(cm.baseUrl, cm.meta.type, cm.meta.id)
                }.getOrNull() ?: continue
                for (member in meta.cast) {
                    if (member.name.isBlank()) continue
                    if (!member.name.contains(q, ignoreCase = true)) continue
                    val key = if (member.id > 0) {
                        "id:${member.id}"
                    } else {
                        "name:${member.name.lowercase()}"
                    }
                    val existing = people[key]
                    if (existing == null) {
                        people[key] = member
                    } else if (existing.photo.isNullOrBlank() && !member.photo.isNullOrBlank()) {
                        people[key] = member
                    }
                }
                if (people.size >= 10) break
            }
            people.values.take(10)
        }

    /**
     * Real Stremio behavior: metadata may live in a different addon than the
     * catalog the title was found in. Try every meta-capable addon in turn
     * until one returns details.
     *
     * v0.14.11: this is now a funnel over the disk meta cache
     * (DB v18 `meta_cache`) — every caller inherits the behaviour:
     *  - FRESH row (series < 24 h, movies < 7 d): returned instantly,
     *    no network at all.
     *  - STALE row: returned immediately AND refreshed in the
     *    background; the refresh replaces the row on success and
     *    leaves it untouched on failure — a failed refresh never
     *    overwrites good data.
     *  - MISS: the live addon walk below runs and a success is
     *    written through to disk.
     * A cached row that carries no episode list never satisfies a
     * [requireVideos] series caller — that caller falls through to
     * the live walk instead of being poisoned by it.
     */
    suspend fun getMetaFromAny(
        hintBaseUrl: String?, type: String, id: String, requireVideos: Boolean = false
    ): MetaDetail? =
        withContext(Dispatchers.IO) {
            val row = runCatching { db.metaCacheDao().get(type, id) }.getOrNull()
            val cached = row?.let { decodeMetaCacheRow(it) }
            if (row != null && cached != null) {
                val unusable = requireVideos && type == "series" && cached.videos.isEmpty()
                if (!unusable) {
                    val ttl = if (type == "series") {
                        META_CACHE_TTL_SERIES_MS
                    } else {
                        META_CACHE_TTL_MOVIE_MS
                    }
                    if (System.currentTimeMillis() - row.fetchedAt < ttl) {
                        // TMDB gap-fill (v0.14.16): a row cached before a
                        // TMDB key was linked — or before enrichment could
                        // resolve the title — would otherwise serve its
                        // names-only cast for the whole TTL (7 days for
                        // movies). Enrich once here and write the result
                        // through; from then on the row is a pure hit.
                        if (cached.cast.any { it.photo.isNullOrBlank() }) {
                            val enriched = enrichFromTmdb(cached)
                            if (enriched != cached) {
                                writeMetaCacheRow(type, id, enriched, row.servedByAddonId)
                                return@withContext enriched
                            }
                        }
                        return@withContext cached
                    }
                    refreshMetaCacheInBackground(hintBaseUrl, type, id, requireVideos)
                    return@withContext cached
                }
            }
            val live = fetchMetaFromAddons(hintBaseUrl, type, id, requireVideos)
            if (live != null) {
                writeMetaCacheRow(type, id, live.first, live.second)
                return@withContext live.first
            }
            // Live walk failed everywhere: the cached copy (even a
            // video-less one) is still better than nothing.
            cached
        }

    /**
     * The live addon walk (pre-v0.14.11 getMetaFromAny body):
     * every meta-capable addon in rank order, each on its own
     * [META_FETCH_TIMEOUT_MS] budget, TMDB enrichment applied to the
     * winner. Returns the meta plus the id of the addon that served
     * it (provenance for the disk cache).
     */
    private suspend fun fetchMetaFromAddons(
        hintBaseUrl: String?, type: String, id: String, requireVideos: Boolean
    ): Pair<MetaDetail, String?>? =
        withContext(Dispatchers.IO) {
            var firstMeta: MetaDetail? = null
            var firstAddonId: String? = null
            // v0.14.20: first answer that satisfies a requireVideos
            // caller — the fallback when every answer is a stub.
            var firstVideosMeta: Pair<MetaDetail, String?>? = null
            for (addon in metaAddonsFor(type, hintBaseUrl)) {
                // Per-addon budget instead of unbounded sequential waits —
                // one hanging addon must not stall the whole lookup.
                val meta = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                    runCatching { api.fetchMeta(addon.baseUrl, type, id) }.getOrNull()
                } ?: continue
                if (firstMeta == null) {
                    firstMeta = meta
                    firstAddonId = addon.id
                }
                // Series callers that need the EPISODE LIST (the
                // player's resume-context backfill, notes item 16)
                // must not stop at a meta that carries no videos —
                // a video-less answer used to poison the whole
                // session. Keep walking; the first meta stays as a
                // last-resort fallback for its name/artwork.
                if (requireVideos && type == "series" && meta.videos.isEmpty()) continue
                if (firstVideosMeta == null) firstVideosMeta = meta to addon.id
                // v0.14.20: a meta whose name is just its own id is a
                // stub echo (StremioParser falls back to name = id
                // when an addon serves an id with no title). It can
                // satisfy the fallbacks above, but the walk keeps
                // looking for an addon that actually names the title —
                // a stub name otherwise becomes the display title on
                // the detail page, the source sheet and the player,
                // and the disk meta cache then serves it for the
                // row's whole TTL.
                if (meta.name.isBlank() || meta.name == meta.id) continue
                return@withContext enrichFromTmdb(meta) to addon.id
            }
            val fallback = if (requireVideos) {
                firstVideosMeta ?: firstMeta?.let { it to firstAddonId }
            } else {
                firstMeta?.let { it to firstAddonId }
            }
            fallback?.let { (meta, addonId) -> enrichFromTmdb(meta) to addonId }
        }

    /** Keys with a background meta refresh already running (dedupe). */
    private val metaCacheRefreshInFlight =
        java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /**
     * Stale-while-revalidate refresh for the disk meta cache: runs
     * the live walk on the repository scope and writes a success
     * through. A failure changes nothing — the stale row keeps
     * serving (the same rule the PlavioHD server learned in
     * v1.9.83: never overwrite good data with a miss).
     */
    private fun refreshMetaCacheInBackground(
        hintBaseUrl: String?, type: String, id: String, requireVideos: Boolean
    ) {
        val key = "$type|$id"
        if (!metaCacheRefreshInFlight.add(key)) return
        repoScope.launch {
            try {
                fetchMetaFromAddons(hintBaseUrl, type, id, requireVideos)?.let { live ->
                    writeMetaCacheRow(type, id, live.first, live.second)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // A failed refresh must never take the cache down.
            } finally {
                metaCacheRefreshInFlight.remove(key)
            }
        }
    }

    /**
     * True when [new] is poorer than [existing] (P4, v0.14.22): a stub
     * (name missing or just the id echoed back), or a row with no genres
     * AND no cast where the cached row has them, or a series row with no
     * episodes where the cached row has some. A poorer write is rejected
     * — a stub-only refresh leaves the cached row untouched.
     */
    private fun isPoorerMeta(new: MetaDetail, existing: MetaDetail): Boolean {
        val newIsStub = new.name.isBlank() || new.name == new.id
        val oldIsReal = existing.name.isNotBlank() && existing.name != existing.id
        if (newIsStub && oldIsReal) return true
        val newThin = new.genres.isEmpty() && new.cast.isEmpty()
        val oldRich = existing.genres.isNotEmpty() || existing.cast.isNotEmpty()
        if (newThin && oldRich) return true
        if (new.videos.isEmpty() && existing.videos.isNotEmpty()) return true
        return false
    }

    /** Write-through for the disk meta cache, with the size guard. */
    private suspend fun writeMetaCacheRow(
        type: String, id: String, meta: MetaDetail, servedByAddonId: String?
    ) {
        runCatching {
            val dao = db.metaCacheDao()
            val existing = dao.get(type, id)?.let { decodeMetaCacheRow(it) }
            if (existing != null && isPoorerMeta(meta, existing)) return@runCatching
            dao.upsert(encodeMetaCacheRow(type, id, meta, servedByAddonId))
            val count = dao.count()
            if (count > META_CACHE_MAX_ROWS) {
                dao.evictOldest(count - META_CACHE_KEEP_ROWS)
            }
        }
    }

    /** MetaDetail → meta_cache row (org.json, the codebase's codec style). */
    private fun encodeMetaCacheRow(
        type: String, id: String, meta: MetaDetail, servedByAddonId: String?
    ): MetaCacheEntry {
        val videos = JSONArray()
        for (v in meta.videos) {
            videos.put(JSONObject().apply {
                put("id", v.id)
                put("title", v.title)
                put("season", v.season)
                put("episode", v.episode)
                put("overview", v.overview ?: JSONObject.NULL)
                put("thumbnail", v.thumbnail ?: JSONObject.NULL)
                put("released", v.released ?: JSONObject.NULL)
            })
        }
        val extra = JSONObject().apply {
            put("description", meta.description ?: JSONObject.NULL)
            put("releaseInfo", meta.releaseInfo ?: JSONObject.NULL)
            put("genres", JSONArray(meta.genres))
            val cast = JSONArray()
            for (c in meta.cast) {
                cast.put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("photo", c.photo ?: JSONObject.NULL)
                    put("knownFor", c.knownFor ?: JSONObject.NULL)
                    put("character", c.character ?: JSONObject.NULL)
                })
            }
            put("cast", cast)
            val trailers = JSONArray()
            for (t in meta.trailerStreams) {
                trailers.put(JSONObject().apply {
                    put("title", t.title)
                    put("ytId", t.ytId)
                })
            }
            put("trailerStreams", trailers)
            put("runtime", meta.runtime ?: JSONObject.NULL)
            put("status", meta.status ?: JSONObject.NULL)
            put("certification", meta.certification ?: JSONObject.NULL)
            put("country", meta.country ?: JSONObject.NULL)
            put("network", meta.network ?: JSONObject.NULL)
            put("production", meta.production ?: JSONObject.NULL)
            put("imdbId", meta.imdbId ?: JSONObject.NULL)
            put("defaultVideoId", meta.defaultVideoId ?: JSONObject.NULL)
        }
        return MetaCacheEntry(
            type = type,
            metaId = id,
            name = meta.name,
            poster = meta.poster,
            background = meta.background,
            logo = meta.logo,
            imdbRating = meta.imdbRating,
            videosJson = videos.toString(),
            fetchedAt = System.currentTimeMillis(),
            servedByAddonId = servedByAddonId,
            extraJson = extra.toString()
        )
    }

    /** meta_cache row → MetaDetail; null when a blob is unreadable. */
    private fun decodeMetaCacheRow(row: MetaCacheEntry): MetaDetail? = runCatching {
        val videosArr = JSONArray(row.videosJson)
        val videos = ArrayList<Video>(videosArr.length())
        for (i in 0 until videosArr.length()) {
            val o = videosArr.getJSONObject(i)
            videos += Video(
                id = o.getString("id"),
                title = o.optString("title"),
                season = o.optInt("season"),
                episode = o.optInt("episode"),
                overview = o.optString("overview").takeIf { !o.isNull("overview") },
                thumbnail = o.optString("thumbnail").takeIf { !o.isNull("thumbnail") },
                released = o.optString("released").takeIf { !o.isNull("released") }
            )
        }
        val extra = row.extraJson?.let { JSONObject(it) }
        fun extraStr(key: String): String? =
            extra?.optString(key)?.takeIf { extra != null && !extra.isNull(key) }
        val genres = ArrayList<String>()
        extra?.optJSONArray("genres")?.let { arr ->
            for (i in 0 until arr.length()) genres += arr.getString(i)
        }
        val cast = ArrayList<CastMember>()
        extra?.optJSONArray("cast")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                cast += CastMember(
                    id = o.optInt("id"),
                    name = o.optString("name"),
                    photo = o.optString("photo").takeIf { !o.isNull("photo") },
                    knownFor = o.optString("knownFor").takeIf { !o.isNull("knownFor") },
                    character = o.optString("character").takeIf { !o.isNull("character") }
                )
            }
        }
        val trailers = ArrayList<TrailerStream>()
        extra?.optJSONArray("trailerStreams")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                trailers += TrailerStream(
                    title = o.optString("title"),
                    ytId = o.optString("ytId")
                )
            }
        }
        MetaDetail(
            id = row.metaId,
            type = row.type,
            name = row.name,
            poster = row.poster,
            background = row.background,
            logo = row.logo,
            description = extraStr("description"),
            releaseInfo = extraStr("releaseInfo"),
            imdbRating = row.imdbRating,
            genres = genres,
            videos = videos,
            trailerStreams = trailers,
            cast = cast,
            runtime = extraStr("runtime"),
            status = extraStr("status"),
            certification = extraStr("certification"),
            country = extraStr("country"),
            network = extraStr("network"),
            production = extraStr("production"),
            imdbId = extraStr("imdbId"),
            defaultVideoId = extraStr("defaultVideoId")
        )
    }.getOrNull()

    /**
     * Studio logo for one title (notes items 14/15): catalog items
     * carry no logo, so poster tiles resolve it from the meta the
     * SERVING addon provides — that addon first when it is known
     * and meta-capable, any installed meta addon otherwise. Null
     * when no addon gives one; callers fall back to the plain
     * poster/title. Bounded: one serving-addon attempt + the usual
     * getMetaFromAny walk, 12 s overall.
     */
    suspend fun resolveLogoUrl(addonId: String?, type: String, metaId: String): String? =
        withContext(Dispatchers.IO) {
            withTimeoutOrNull(12_000) {
                var found: String? = null
                if (!addonId.isNullOrBlank()) {
                    val addon = runCatching { db.addonDao().getAll() }
                        .getOrDefault(emptyList())
                        .firstOrNull { it.id == addonId && it.enabled && "meta" in it.resourceSet }
                    if (addon != null) {
                        val meta = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                            runCatching { api.fetchMeta(addon.baseUrl, type, metaId) }.getOrNull()
                        }
                        found = meta?.logo?.takeIf { it.isNotBlank() }
                    }
                }
                found ?: runCatching { getMetaFromAny(null, type, metaId) }.getOrNull()
                    ?.logo?.takeIf { it.isNotBlank() }
            }
        }

    /**
     * Title poster for a Continue Watching tile in Poster artwork
     * mode (item 35): the same meta route as [resolveLogoUrl], but
     * the poster field. Serves ANY installed meta addon — never tied
     * to one provider (metadata flexibility principle).
     */
    suspend fun resolvePosterUrl(addonId: String?, type: String, metaId: String): String? =
        withContext(Dispatchers.IO) {
            withTimeoutOrNull(12_000) {
                var found: String? = null
                if (!addonId.isNullOrBlank()) {
                    val addon = runCatching { db.addonDao().getAll() }
                        .getOrDefault(emptyList())
                        .firstOrNull { it.id == addonId && it.enabled && "meta" in it.resourceSet }
                    if (addon != null) {
                        val meta = withTimeoutOrNull(META_FETCH_TIMEOUT_MS) {
                            runCatching { api.fetchMeta(addon.baseUrl, type, metaId) }.getOrNull()
                        }
                        found = meta?.poster?.takeIf { it.isNotBlank() }
                    }
                }
                found ?: runCatching { getMetaFromAny(null, type, metaId) }.getOrNull()
                    ?.poster?.takeIf { it.isNotBlank() }
            }
        }

    /**
     * Streams may live in different addons than catalogs/metadata.
     * Queries every stream-capable addon concurrently and emits the merged
     * list PROGRESSIVELY — each emission holds everything found so far,
     * de-duplicated by URL and tagged with its source addon name — so the UI
     * can show (and autoplay) the first sources without waiting for the
     * slowest addon. Each addon fails fast after [STREAM_FETCH_TIMEOUT_MS].
     * The final emission is the complete merged result.
     */
    /** Resolves a Live channel using its own resource type and catalog origin. */
    fun liveStreamResultsFlow(
        channel: TvChannelRef,
        seedFromCache: Boolean = true
    ): Flow<StreamResult> =
        streamResultsFlow(
            channel.type, channel.metaId, preferredAddonId = channel.addonId,
            preserveHeaderVariants = true, seedFromCache = seedFromCache
        )

    fun streamResultsFlow(
        type: String,
        videoId: String,
        preferredAddonId: String? = null,
        preserveHeaderVariants: Boolean = false,
        seedFromCache: Boolean = true
    ): Flow<StreamResult> = channelFlow {
        val addons = streamAddons()
        if (addons.isEmpty()) {
            send(StreamResult(emptyList(), emptyList()))
            return@channelFlow
        }
        // Session cache: reopening a title shows its last streams instantly
        // while the fresh fetch below replaces them as it lands.
        // v0.14.36 (defect 1): the seed is a PAINT only, inside the
        // short window StreamCacheSupport allows — and callers that
        // settle on an emission (the player's source pool, the
        // credential refresh, the resume fresh-URL pass) pass
        // seedFromCache = false so their answer is network data,
        // never this store. The collect still refills the cache at
        // its end either way.
        val cacheKey = "$type|$videoId|${preferredAddonId.orEmpty()}|$preserveHeaderVariants"
        streamResultCache[cacheKey]?.let { (cachedAt, cached) ->
            if (StreamCacheSupport.shouldEmitSeed(
                    cachedAt, System.currentTimeMillis(), seedFromCache
                )
            ) {
                send(cached)
            }
        }
        // Starred addons go first — in every emission, so their streams show
        // and autoplay before anyone else's.
        val starredIds = addons.filter { it.starred }.map { it.id }.toSet()
        fun prioritize(streams: List<StreamItem>): List<StreamItem> =
            streams.sortedWith(
                // Debrid-resolved rows first (owner's order 2026-10-31:
                // TorBox streams display first and play first), TorBox
                // ahead of the other providers; then the star order.
                compareBy<StreamItem> {
                    com.pulsestream.app.data.debrid.DebridSupport.debridRank(it)
                }
                    .thenByDescending { it.sourceId in starredIds }
                    .thenByDescending { it.sourceId == preferredAddonId }
                    .thenBy { it.sourceId }
            )
        val mutex = Mutex()
        val seenStreams = LinkedHashSet<String>()
        fun streamIdentity(stream: StreamItem): String = listOf(
            stream.url, stream.infoHash.orEmpty(), stream.fileIdx?.toString().orEmpty(),
            stream.filePath.orEmpty(),
            if (preserveHeaderVariants) LivePlaybackPolicy.candidateIdentity(stream) else ""
        ).joinToString("|")
        val seenSubs = LinkedHashSet<String>()
        val accStreams = mutableListOf<StreamItem>()
        val accSubs = mutableListOf<Subtitle>()
        // v0.14.24: legs that timed out on the PREVIOUS collect of this
        // title get the extended budget this time (see timedOutLegs).
        val titleKey = "$type|$videoId"
        val timedOutAtStart = timedOutLegsFor(titleKey)
        val timedOutNow = java.util.Collections.synchronizedSet(mutableSetOf<String>())
        // Debrid (native debrid layer): the service, the shared
        // apply-resolved step and the started-set live OUTSIDE the leg
        // scope so resolution can run INCREMENTALLY while the addon
        // legs are still filling (owner's report 2026-10-31: an
        // instant Watch Now tap never saw the TorBox rows because
        // resolution waited for every leg to finish). Gated by the
        // AppConfig "debrid" switch (default on): when off, pending
        // rows stay exactly as listed.
        val debridService = com.pulsestream.app.data.debrid.DebridService.create(
            torboxApiKey = settings.torboxApiKey,
            realDebridApiKey = settings.realDebridApiKey,
            premiumizeApiKey = settings.premiumizeApiKey,
            allDebridApiKey = settings.allDebridApiKey,
            debridLinkApiKey = settings.debridLinkApiKey,
            offcloudApiKey = settings.offcloudApiKey,
            enabled = AppConfig.debridEnabled()
        )
        val resolutionStarted = java.util.Collections.synchronizedSet(mutableSetOf<String>())
        fun resolutionKey(stream: StreamItem): String {
            val h = com.pulsestream.app.data.debrid.DebridSupport.hashFor(stream) ?: return ""
            return h + "|" + (stream.fileIdx?.toString() ?: "") + "|" + (stream.filePath ?: "")
        }
        val applyResolved: suspend (StreamItem, String, String, String) -> Unit =
            { stream, hash, tag, httpUrl ->
                var changed = false
                mutex.withLock {
                    val idx = accStreams.indexOfFirst {
                        com.pulsestream.app.data.debrid.DebridSupport.isSamePendingRow(it, stream)
                    }
                    if (idx >= 0 && seenStreams.add(streamIdentity(stream.copy(url = httpUrl, infoHash = null)))) {
                        val old = accStreams[idx]
                        accStreams[idx] = old.copy(
                            url = httpUrl,
                            infoHash = null,
                            resolvedInfoHash = old.infoHash ?: hash,
                            sourceName = tag + (old.sourceName?.let { " · $it" } ?: "")
                        )
                        changed = true
                    }
                }
                if (changed) {
                    mutex.withLock { send(StreamResult(prioritize(accStreams.toList()), accSubs.toList())) }
                }
            }
        coroutineScope {
            // Foreground playback must not queue behind Home/Live catalog
            // refreshes on addonRequestGate. Keep this flow bounded separately,
            // and give the selected channel's own addon the first request slot.
            val streamGate = Semaphore(4)
            val requestOrder = addons.sortedWith(
                compareByDescending<InstalledAddon> { it.id == preferredAddonId }
                    .thenByDescending { it.starred }
            )
            // PLAVIO-1E (v0.14.28): CopyOnWriteArrayList, NOT a plain
            // MutableList. The debrid resolver child below ITERATES
            // this list (legJobs.all { it.isCompleted }) on a
            // Dispatchers.IO thread while this coroutineScope body is
            // still ADDING legs to it on another IO thread — with an
            // ArrayList that is a textbook ConcurrentModification-
            // Exception (0.14.23 crash, Sentry 159598215: a list
            // changed while stream results were being read). COW
            // iteration walks a stable snapshot, so the resolver sees
            // either the legs launched so far or all of them, and the
            // completion check stays exact.
            val legJobs = java.util.concurrent.CopyOnWriteArrayList<kotlinx.coroutines.Job>()
            // Incremental debrid resolution: as soon as a leg lands
            // pending (infohash/magnet) rows, resolve them — TorBox
            // cached rows must exist within the first moments, not
            // after the slowest addon settles.
            if (debridService.isActive) {
                launch {
                    while (true) {
                        val fresh = mutex.withLock {
                            com.pulsestream.app.data.debrid.DebridSupport
                                .pendingStreams(accStreams)
                                .filter { row ->
                                    val key = resolutionKey(row)
                                    key.isNotEmpty() && resolutionStarted.add(key)
                                }
                        }
                        if (fresh.isNotEmpty()) {
                            debridService.resolveAll(
                                pending = fresh,
                                isPlayable = ::isPlayableLiveStreamUrl,
                                applyResolved = applyResolved
                            )
                        }
                        if (legJobs.isNotEmpty() && legJobs.all { it.isCompleted }) break
                        if (fresh.isEmpty()) delay(300)
                    }
                }
            }
            requestOrder.forEach { addon ->
                legJobs += launch {
                    streamGate.acquire()
                    var failure: Throwable? = null
                    val legStartedAt = System.nanoTime()
                    // v0.14.25: provisional (still-filling) bookkeeping —
                    // a marked answer keeps this leg open, see the loop.
                    var sawProvisional = false
                    var gotFinalAnswer = false
                    try {
                        // The network budget starts after a request slot is
                        // granted, not while waiting behind unrelated work.
                        // v0.14.24: the first-party host always gets the
                        // extended budget (its cold fills legitimately
                        // outlast the standard one), and so does any leg
                        // that timed out on the previous collect for this
                        // title — a timeout is "still cooking", never
                        // proof that no streams exist.
                        withTimeout(streamBudgetMs(addon, timedOutAtStart)) {
                            while (true) {
                                val res = try { api.fetchStreams(addon.baseUrl, type, videoId) }
                                    catch (cancel: CancellationException) { throw cancel }
                                    catch (e: Exception) { failure = e; null }
                                if (res == null) break
                                // Merge + emit exactly like a normal
                                // progressive landing — a provisional
                                // answer's streams display immediately.
                                var changed = false
                                mutex.withLock {
                                    res.streams.forEach { s ->
                                        if (seenStreams.add(streamIdentity(s))) {
                                            accStreams.add(s.copy(sourceName = addon.name, sourceId = addon.id))
                                            changed = true
                                        }
                                    }
                                    res.subtitles.forEach { s ->
                                        if (seenSubs.add(s.url)) {
                                            accSubs.add(s)
                                            changed = true
                                        }
                                    }
                                }
                                if (changed) {
                                    mutex.withLock { send(StreamResult(prioritize(accStreams.toList()), accSubs.toList())) }
                                }
                                if (!res.filling) {
                                    gotFinalAnswer = true
                                    break
                                }
                                // v0.14.25 PROVISIONAL: PlavioHD marks an
                                // answer whose server-side fill is still
                                // running. That answer is "not yet", not
                                // "none" — the leg stays open inside its
                                // existing budget and re-asks until an
                                // unmarked (final) answer arrives or the
                                // budget expires, when the best
                                // provisional set stands. A marked answer
                                // can never be what settles the terminal
                                // "No stream available" state: the flow
                                // cannot complete while this leg is open.
                                sawProvisional = true
                                delay(FILLING_REASK_DELAY_MS)
                            }
                        }
                    } catch (e: TimeoutCancellationException) {
                        failure = e
                    } finally {
                        streamGate.release()
                    }
                    // A leg that never received a final answer — it timed
                    // out, or its last answer was still marked when the
                    // budget expired — is "still cooking", exactly like
                    // the v0.14.24 timeout case: recorded timed_out and
                    // re-asked with the extended budget on the next
                    // collect, never treated as an empty answer.
                    if (failure is TimeoutCancellationException ||
                        failure is java.io.InterruptedIOException ||
                        failure?.cause is java.net.SocketTimeoutException ||
                        (sawProvisional && !gotFinalAnswer)
                    ) {
                        timedOutNow.add(addon.id)
                        SourceDiagnostics.record(
                            addon.baseUrl.toHttpUrlOrNull()?.host ?: "unknown",
                            "timed_out",
                            (System.nanoTime() - legStartedAt) / 1_000_000
                        )
                    }
                }
            }
        }
        // v0.14.24: publish this collect's timed-out legs so the next
        // collect for this title (the Detail confirmation pass) re-asks
        // them with the extended budget.
        noteTimedOutLegs(titleKey, synchronized(timedOutNow) { timedOutNow.toSet() })
        // Debrid final sweep: rows the incremental resolver never
        // started (arrived in its last tick) resolve here; rows it
        // already started are done or were applied as they landed.
        if (debridService.isActive) {
            val pending = mutex.withLock {
                com.pulsestream.app.data.debrid.DebridSupport.pendingStreams(accStreams)
                    .filter { row -> resolutionKey(row) !in resolutionStarted }
            }
            if (pending.isNotEmpty()) {
                debridService.resolveAll(
                    pending = pending,
                    isPlayable = ::isPlayableLiveStreamUrl,
                    applyResolved = applyResolved
                )
            }
        }
        val finalResult = mutex.withLock {
            StreamResult(prioritize(accStreams.toList()), accSubs.toList())
        }
        if (finalResult.streams.isNotEmpty()) {
            streamResultCache[cacheKey] = System.currentTimeMillis() to finalResult
        }
        send(finalResult)
    }.flowOn(Dispatchers.IO)

    suspend fun getStreams(baseUrl: String, type: String, videoId: String): StreamResult =
        withContext(Dispatchers.IO) { api.fetchStreams(baseUrl, type, videoId) }

    /**
     * Single-addon meta fetch (v0.14.26, batch item 4): asks ONE
     * addon — the one that served the catalog row — for a meta,
     * with no multi-addon walk and no disk-cache detour. Used by
     * the live-channel path, where the walk's failure/slowness
     * must not gate getting to the channel's streams.
     */
    suspend fun getStreamsMeta(baseUrl: String, type: String, id: String): MetaDetail? =
        withContext(Dispatchers.IO) { runCatching { api.fetchMeta(baseUrl, type, id) }.getOrNull() }

    /** Installed-addon id for a base URL (v0.14.26, item 4 helper). */
    suspend fun addonIdForBaseUrl(baseUrl: String?): String? =
        if (baseUrl == null) null else withContext(Dispatchers.IO) {
            db.addonDao().getAll().firstOrNull { it.baseUrl == baseUrl }?.id
        }

    suspend fun getAddonBaseUrl(addonId: String): String? = withContext(Dispatchers.IO) {
        catalogCache.firstOrNull { it.addonId == addonId }?.baseUrl
            ?: db.addonDao().getAll().firstOrNull { it.id == addonId }?.baseUrl
    }

    suspend fun getSavedPosition(key: String): Long =
        withContext(Dispatchers.IO) { db.playbackDao().getByKey(key)?.positionMs ?: 0L }

    /**
     * Saved position for a title/episode regardless of which stream
     * URL keys the row: the exact-URL lookup first (the common case),
     * then the episode identity — a resume whose stream URL was
     * refreshed during matching must not lose the position (DB v15).
     */
    suspend fun getSavedPositionFor(
        imdbId: String?, season: Int, episode: Int, videoId: String, streamUrl: String
    ): Long {
        val byUrl = getSavedPosition(streamUrl)
        if (byUrl > 0) return byUrl
        return playbackRowFor(imdbId, season, episode, videoId)?.positionMs ?: 0L
    }

    suspend fun deleteSavedPosition(key: String) =
        withContext(Dispatchers.IO) { db.playbackDao().deleteByKey(key) }

    /**
     * Continue Watching identity: rows are keyed by stream URL, so the
     * same episode reached through two addons/sources becomes two rows
     * (owner's bug report 2026-10-26 — the same episode showed twice).
     *
     * Canonical keying (CW resume stickiness fix, 2026-11-02): when the
     * row carries a real IMDb tt id, identity is built from it for BOTH
     * episodes ("ep|tt|S|E") and movies ("tt|tt") — the video id is an
     * addon-local form (a tt id from one meta addon, "tmdb:…" from
     * another), so keying a movie by video id alone made a resume
     * probe from a different addon's page miss the row even though
     * both sides knew the same tt id. A non-tt imdbId (the play path's
     * "tmdb" fallback when no tt id exists anywhere) is NOT used: the
     * old non-blank rule keyed every such episode "ep|tmdb|S|E",
     * colliding different series into one identity; those rows fall
     * back to their (series-specific) episode video id instead.
     *
     * Identity is computed from stored fields, never persisted, so
     * existing rows re-key consistently. MUST stay formula-identical
     * to LibrarySyncManager.cwIdentity — import dedupe, pruning and
     * dismissal keys share this key space.
     */
    private fun playbackIdentity(state: PlaybackState): String {
        val ttId = state.imdbId?.takeIf { it.startsWith("tt") }
        return when {
            (state.season > 0 || state.episode > 0) && ttId != null ->
                "ep|$ttId|${state.season}|${state.episode}"
            ttId != null -> "tt|$ttId"
            else -> "id|${state.videoId}"
        }
    }

    /** Collapses duplicate rows to the newest (then furthest) per identity. */
    private fun dedupePlaybackRows(rows: List<PlaybackState>): List<PlaybackState> {
        if (rows.size < 2) return rows
        val best = LinkedHashMap<String, PlaybackState>()
        for (row in rows) {
            val key = playbackIdentity(row)
            val cur = best[key]
            if (cur == null || row.updatedAt > cur.updatedAt ||
                (row.updatedAt == cur.updatedAt && row.positionMs > cur.positionMs)
            ) {
                best[key] = row
            }
        }
        val collapsed = best.values.sortedByDescending { it.updatedAt }
        // v0.14.15 (owner's rule): ONE Continue Watching card per
        // series — of the surviving per-episode rows keep only the
        // most recently played episode's row per series. Movies pass
        // through untouched (seriesKeyForPlayback is null for them).
        val seenSeries = HashSet<String>()
        return collapsed.filter { row ->
            val seriesKey = seriesKeyForPlayback(row) ?: return@filter true
            seenSeries.add(seriesKey)
        }
    }

    /** Serializes playback-state saves: a source switch saves the old
     * request while pause/dispose saves the new one, and unsynchronized
     * delete-siblings + upsert pairs could interleave so the OLD
     * stream's row won (v0.14.7-test resume defect). */
    private val playbackSaveMutex = Mutex()

    suspend fun savePlayback(
        title: String,
        poster: String?,
        videoId: String,
        streamUrl: String,
        positionMs: Long,
        durationMs: Long,
        imdbId: String? = null,
        season: Int = 0,
        episode: Int = 0,
        seriesName: String? = null,
        episodeTitle: String? = null,
        metaId: String? = null,
        streamAddonId: String? = null,
        streamName: String? = null,
        streamTitle: String? = null,
        streamQuality: String? = null,
        logo: String? = null,
        episodeIdsJson: String? = null
    ) = withContext(Dispatchers.IO) {
      playbackSaveMutex.withLock {
        // Watched pill: crossing 90% counts as watched (the same spirit as
        // the scrobblers). Recorded before the early returns below, so
        // finishing a title always lands here first.
        if (durationMs > 0 && positionMs >= durationMs * 9 / 10) {
            val watchedKey = if (season > 0 || episode > 0) {
                WatchedMarks.episodeKey(imdbId ?: videoId.substringBefore(":"), season, episode)
            } else {
                WatchedMarks.movieKey(videoId)
            }
            runCatching {
                db.watchedDao().upsert(WatchedRecord(watchedKey, System.currentTimeMillis()))
            }
        }
        // Drop sibling rows for this same episode/movie stored under
        // other stream URLs, so Continue Watching never shows a title
        // twice (see playbackIdentity). v0.14.15: for a series, drop
        // the series' OTHER episodes' rows too — playing a new
        // episode replaces the series' previous Continue Watching
        // entry, so a series only ever holds its last opened episode
        // (owner's rule). Runs before the early returns below so
        // finishing a title clears its duplicates too.
        val probe = PlaybackState(streamUrl, title, poster, videoId, streamUrl,
            positionMs, durationMs, imdbId, season, episode,
            seriesName, episodeTitle, metaId,
            streamAddonId, streamName, streamTitle, streamQuality, logo, 0L)
        val identity = playbackIdentity(probe)
        val seriesKey = seriesKeyForPlayback(probe)
        runCatching {
            db.playbackDao().getAll()
                .filter {
                    it.key != streamUrl &&
                        (playbackIdentity(it) == identity ||
                            (seriesKey != null && seriesKeyForPlayback(it) == seriesKey))
                }
                .forEach { db.playbackDao().deleteByKey(it.key) }
        }
        // Don't clutter Continue Watching with barely-started items, and drop
        // entries the user effectively finished (less than 30s left).
        if (durationMs > 0 && durationMs - positionMs < 30_000) {
            db.playbackDao().deleteByKey(streamUrl)
            return@withContext
        }
        if (positionMs < 10_000) return@withContext
        db.playbackDao().upsert(
            PlaybackState(
                key = streamUrl,
                title = title,
                poster = poster,
                videoId = videoId,
                streamUrl = streamUrl,
                positionMs = positionMs,
                durationMs = durationMs,
                imdbId = imdbId,
                season = season,
                episode = episode,
                seriesName = seriesName,
                episodeTitle = episodeTitle,
                metaId = metaId,
                streamAddonId = streamAddonId,
                streamName = streamName,
                streamTitle = streamTitle,
                streamQuality = streamQuality,
                logo = logo,
                updatedAt = System.currentTimeMillis(),
                // DB v16 (item 16): a fresh local save supersedes
                // any imported row for this title, so the import
                // provenance/pct are cleared with it.
                episodeIdsJson = episodeIdsJson,
                remoteProgressPct = null,
                importSource = null
            )
        )
        // Watching it here again also lifts any Continue Watching
        // dismissal the user set earlier (item 13 import guard).
        runCatching { settings.clearContinueWatchingDismissal(identity) }
      }
    }

    /**
     * Continue Watching removal (hold menu): deletes EVERY row for
     * the entry's title/episode identity (rows are keyed by stream
     * URL, so one entry can own several) and remembers the removal,
     * so the Trakt/Simkl progress import doesn't resurrect it with
     * older progress (notes item 13).
     */
    suspend fun removeContinueWatchingItem(item: PlaybackState) = withContext(Dispatchers.IO) {
        val identity = playbackIdentity(item)
        // v0.14.15: a series shows ONE card (its last opened episode),
        // so removing it removes the series' rows entirely — an older
        // episode must not resurface in its place. Each removed row's
        // identity is dismissed so the import can't resurrect it.
        val seriesKey = seriesKeyForPlayback(item)
        val removed = runCatching {
            db.playbackDao().getAll()
                .filter {
                    playbackIdentity(it) == identity ||
                        (seriesKey != null && seriesKeyForPlayback(it) == seriesKey)
                }
        }.getOrDefault(emptyList())
        removed.forEach { row ->
            runCatching { db.playbackDao().deleteByKey(row.key) }
            runCatching { settings.dismissContinueWatching(playbackIdentity(row)) }
        }
        runCatching { settings.dismissContinueWatching(identity) }
    }

    /**
     * The saved Continue Watching row for one title/episode, if any —
     * matched by the same identity the dedupe uses, so a resume finds
     * its row regardless of which stream URL keys it.
     */
    suspend fun playbackRowFor(
        imdbId: String?, season: Int, episode: Int, videoId: String
    ): PlaybackState? = withContext(Dispatchers.IO) {
        val probe = PlaybackState(
            key = "", title = "", poster = null, videoId = videoId, streamUrl = "",
            positionMs = 0, durationMs = 0, imdbId = imdbId,
            season = season, episode = episode, updatedAt = 0L
        )
        val identity = playbackIdentity(probe)
        db.playbackDao().getAll()
            .filter { playbackIdentity(it) == identity }
            .maxByOrNull { it.updatedAt }
    }

    /**
     * Normalized release-name fingerprint (CW resume stickiness fix,
     * 2026-11-02). The pre-fix fingerprint ran over the stream's WHOLE
     * display title, so any volatile decoration broke it exactly when
     * it was needed (the saved URL had also rotated): multi-line addon
     * titles carry extra lines (size, source tags, language notes) and
     * torrent-style titles carry seeder counts that change between
     * fetches. Normalization, in order:
     *  - only the FIRST non-blank line is used — the file/release name
     *    (the remaining lines are presentation, not identity);
     *  - size tokens are stripped ("1.5 GB", "700mb", "1,5 GiB");
     *  - seeder/peer counts are stripped ("👤 123", "seeders: 45",
     *    "leech 9" — the number right after the marker);
     *  - case/punctuation-insensitive collapse, as before.
     * Everything else (release group, codec, year, quality tokens in
     * the name) still distinguishes releases.
     */
    private fun streamFingerprint(text: String?): String {
        val firstLine = text.orEmpty().lineSequence()
            .firstOrNull { it.isNotBlank() } ?: return ""
        var t = firstLine.lowercase()
        t = t.replace(Regex("""\d+(?:[.,]\d+)?\s*(?:tib|tb|gib|gb|mib|mb)\b"""), " ")
        t = t.replace(
            Regex("""(?:👤|👥|seeders?|seeds|peers?|leechers?|leech)[:\s]*\d+"""), " "
        )
        return t.replace(Regex("[^a-z0-9]+"), " ")
            .trim().replace(Regex("\\s+"), " ")
    }

    /**
     * Numeric quality lane for a label token, so the saved lane and a
     * candidate's lane compare equal even when the two fetches spelled
     * it differently — [streamQualityLabel] returns whichever token
     * appears first in the text, so the same 2160p file could be saved
     * as "4K" and re-fetched as "2160P" (string equality then missed).
     */
    private fun qualityLaneOfLabel(label: String?): Int? {
        val t = label.orEmpty().uppercase()
        return when {
            t.contains("2160") || t.contains("4K") || t == "UHD" -> 2160
            t.contains("1440") -> 1440
            t.contains("1080") -> 1080
            t.contains("720") -> 720
            t.contains("480") -> 480
            t.contains("360") -> 360
            else -> null
        }
    }

    /**
     * Resume stream matching — the sticky ladder (DB v15, extended
     * 2026-11-02 on the owner's "same source, same quality" order).
     * Given the saved row and the freshly resolved streams for the
     * same title/episode, walk down from the stream the user was
     * actually watching to the closest relative:
     *  1. exact URL match (the saved row's own URL);
     *  2. same source + same quality lane + normalized fingerprint;
     *  3. same source + same quality lane;
     *  4. same source + normalized fingerprint (the file, re-laned);
     *  5. same source, nearest quality lane — step DOWN before up
     *     (the owner's standing rule);
     *  6. any source + normalized fingerprint (the file moved addons).
     * "Same source" is the saved addon id; when it matches no
     * candidate (the addon was reinstalled under a different manifest
     * id), the saved addon NAME defines the source set instead.
     * Null when nothing resembles the saved stream — the caller then
     * falls back (saved URL when nothing resolved at all, otherwise
     * the normal auto-pick). This runs AHEAD of every autoplay
     * ordering at the call sites, so a matched resume stream is never
     * re-ordered away by the Smart Picks / debrid tiers. Never throws.
     */
    fun matchResumeStream(row: PlaybackState, candidates: List<StreamItem>): StreamItem? {
        if (candidates.isEmpty()) return null
        candidates.firstOrNull { it.url == row.streamUrl }?.let { return it }
        var sameSource = candidates.filter {
            row.streamAddonId != null && it.sourceId == row.streamAddonId
        }
        if (sameSource.isEmpty() && !row.streamName.isNullOrBlank()) {
            sameSource = candidates.filter { it.sourceName == row.streamName }
        }
        val savedPrint = streamFingerprint(row.streamTitle)
            .ifBlank { streamFingerprint(row.streamName) }
        fun printsOf(s: StreamItem): List<String> = listOfNotNull(
            streamFingerprint(s.title ?: s.name ?: s.filename)
                .takeIf { it.isNotBlank() },
            s.filename?.let { streamFingerprint(it) }?.takeIf { it.isNotBlank() }
        )
        fun printMatches(s: StreamItem) =
            savedPrint.isNotBlank() && printsOf(s).any { it == savedPrint }
        val savedLane = qualityLaneOfLabel(row.streamQuality)
        fun laneOf(s: StreamItem) = qualityLaneOfLabel(streamQualityLabel(s))
        if (savedPrint.isNotBlank()) {
            sameSource.firstOrNull {
                printMatches(it) && (savedLane == null || laneOf(it) == savedLane)
            }?.let { return it }
        }
        if (savedLane != null) {
            sameSource.firstOrNull { laneOf(it) == savedLane }?.let { return it }
        }
        if (savedPrint.isNotBlank()) {
            sameSource.firstOrNull { printMatches(it) }?.let { return it }
        }
        if (sameSource.isNotEmpty()) {
            if (savedLane != null) {
                val withLane = sameSource.mapNotNull { s -> laneOf(s)?.let { s to it } }
                withLane.filter { it.second < savedLane }
                    .maxByOrNull { it.second }?.let { return it.first }
                withLane.filter { it.second > savedLane }
                    .minByOrNull { it.second }?.let { return it.first }
                // withLane empty (no parseable lane on this source)
                // falls through to the source's first stream below.
            }
            return sameSource.first()
        }
        if (savedPrint.isNotBlank()) {
            candidates.firstOrNull { printMatches(it) }?.let { return it }
        }
        return null
    }

    /**
     * Missing-poster fingerprint recorded after the last completed
     * backfill pass (2026-10-28): the set of "store|type|metaId" keys
     * that were missing a poster across the four library stores when
     * that pass ran. Replaces the old once-per-process boolean — rows
     * merged by a later sync change the set and retrigger the pass,
     * while an unchanged library matches and doesn't re-burn fetches.
     */
    @Volatile
    private var libraryArtworkBackfillFingerprint: Set<String>? = null

    /** Keys ("store|type|metaId") of every library row missing a poster. */
    private suspend fun missingLibraryPosterKeys(): Set<String> = withContext(Dispatchers.IO) {
        val keys = mutableSetOf<String>()
        for (item in db.watchlistDao().getAll()) {
            if (item.poster.isNullOrBlank()) keys += "watchlist|${item.type}|${item.metaId}"
        }
        for (item in db.favoriteDao().getAll()) {
            if (item.poster.isNullOrBlank()) keys += "favorites|${item.type}|${item.metaId}"
        }
        for (item in db.titleStatusDao().getAll()) {
            if (item.poster.isNullOrBlank()) keys += "title_statuses|${item.type}|${item.metaId}"
        }
        for (item in db.customListDao().getAllItems()) {
            if (item.poster.isNullOrBlank()) keys += "custom_list_items|${item.type}|${item.metaId}"
        }
        keys
    }

    /**
     * Fingerprint-gated entry for the Library (notes item 17, reworked
     * 2026-10-28): the backfill used to re-fire on EVERY Library entry
     * while any row was unfilled — and because its skip test demanded
     * poster AND logo, the poster-present/logo-missing rows (most rows,
     * since catalogues carry no logo) burned a serial meta fetch on
     * every visit, saturating the link behind the foreground load. The
     * once-per-process boolean that replaced that then starved rows
     * merged by a later sync until an app restart. Now the pass runs
     * only when the missing-poster set differs from the one recorded
     * after the last completed pass.
     * Display-side logo gaps are covered immediately by the
     * LogoResolver (items 14/15); this pass persists what it finds
     * into the rows themselves.
     */
    suspend fun backfillLibraryArtworkOnce() {
        val missing = missingLibraryPosterKeys()
        if (missing == libraryArtworkBackfillFingerprint) return
        val result = runCatching { backfillLibraryArtwork() }
        // Record the computed set after a completed pass. Rows the pass
        // filled drop out of the missing set, so the next entry runs one
        // cheap confirmation pass (its misses are served from
        // libraryArtworkCache — no network) that records the
        // unresolvable-only set; from then on an unchanged library is a
        // no-op until a sync merge changes the set again.
        if (result.isSuccess) {
            libraryArtworkBackfillFingerprint = missing
        }
    }

    /**
     * Poster/logo backfill for the local library stores (owner's
     * Library report, 2026-10-27): rows written by sync paths that
     * carry no artwork — Trakt/Simkl library pulls store poster=null
     * by design, and an account restore preserves whatever the source
     * device had — rendered as blank grey tiles forever, because the
     * Library draws local rows straight from the DB and never
     * resolved their meta. This resolves each missing poster
     * through the installed meta addons and writes it back to the
     * row, so the artwork is cached in the DB from then on.
     * Resolutions run with bounded parallelism (4 at a time) — the
     * old strictly-serial walk could hold the network for minutes
     * (notes item 17). Best-effort.
     * Reworked 2026-10-28: a row needs a job only when its POSTER is
     * missing (logo is best-effort from the same fetch — a
     * poster-present row is done), and there is no item cap: the old
     * jobs.take(40) in DAO order starved every missing row past
     * position 40 forever, with unresolvable rows hogging the same
     * slots on every run.
     */
    suspend fun backfillLibraryArtwork(): Int = withContext(Dispatchers.IO) {
        suspend fun metaFor(type: String, metaId: String): MetaDetail? {
            val cached = libraryArtworkCache["$type|$metaId"]
            if (cached != null) return cached.takeIf { it.id.isNotBlank() }
            val meta = withTimeoutOrNull(10_000) {
                runCatching { getMetaFromAny(null, type, metaId) }.getOrNull()
            }
            libraryArtworkCache["$type|$metaId"] = meta ?: MetaDetail(id = "", type = type, name = "")
            return meta
        }
        // One work item per row missing a POSTER: what to resolve +
        // how to write the result back. Poster and logo are filled
        // from the SAME single meta fetch (per-field: only the
        // missing field is written) — the logo rides along when the
        // fetch returns one, but never triggers a job on its own.
        data class ArtworkJob(
            val type: String,
            val metaId: String,
            val poster: String?,
            val logo: String?,
            val write: suspend (String?, String?) -> Unit
        )
        val jobs = mutableListOf<ArtworkJob>()
        for (item in db.watchlistDao().getAll()) {
            if (!item.poster.isNullOrBlank()) continue
            jobs += ArtworkJob(item.type, item.metaId, item.poster, item.logo) { p, l ->
                db.watchlistDao().upsert(item.copy(poster = p, logo = l))
            }
        }
        for (item in db.favoriteDao().getAll()) {
            if (!item.poster.isNullOrBlank()) continue
            jobs += ArtworkJob(item.type, item.metaId, item.poster, item.logo) { p, l ->
                db.favoriteDao().upsert(item.copy(poster = p, logo = l))
            }
        }
        for (item in db.titleStatusDao().getAll()) {
            if (!item.poster.isNullOrBlank()) continue
            jobs += ArtworkJob(item.type, item.metaId, item.poster, item.logo) { p, l ->
                db.titleStatusDao().upsert(item.copy(poster = p, logo = l))
            }
        }
        for (item in db.customListDao().getAllItems()) {
            if (!item.poster.isNullOrBlank()) continue
            jobs += ArtworkJob(item.type, item.metaId, item.poster, item.logo) { p, l ->
                db.customListDao().insertItems(listOf(item.copy(poster = p, logo = l)))
            }
        }
        // No cap (2026-10-28): every missing-poster row is processed.
        // The pass is off the UI path, per-process misses are already
        // cached in libraryArtworkCache, and the Semaphore(4) +
        // 10 s per-item timeout below keep it bounded in flight.
        if (jobs.isEmpty()) return@withContext 0
        val semaphore = kotlinx.coroutines.sync.Semaphore(4)
        val filled = java.util.concurrent.atomic.AtomicInteger(0)
        kotlinx.coroutines.coroutineScope {
            for (job in jobs) {
                launch {
                    semaphore.withPermit {
                        val meta = metaFor(job.type, job.metaId) ?: return@withPermit
                        val poster = if (job.poster.isNullOrBlank()) meta.poster else job.poster
                        val logo = if (job.logo.isNullOrBlank()) meta.logo else job.logo
                        val posterFilled = !poster.isNullOrBlank() && poster != job.poster
                        val logoFilled = !logo.isNullOrBlank() && logo != job.logo
                        if (posterFilled || logoFilled) {
                            job.write(
                                if (posterFilled) poster else job.poster,
                                if (logoFilled) logo else job.logo
                            )
                            filled.incrementAndGet()
                        }
                    }
                }
            }
        }
        filled.get()
    }

    /** Process-wide artwork-resolution cache (misses cached as blank-id sentinels). */
    private val libraryArtworkCache =
        java.util.concurrent.ConcurrentHashMap<String, MetaDetail>()

    // ---- Watchlist ----

    /**
     * Fired after any watchlist add/remove. PulseApp hooks this to the
     * Trakt/Simkl library sync (issue #3); null in tests/previews.
     */
    @Volatile
    var onWatchlistChanged: (() -> Unit)? = null

    fun observeWatchlistItem(key: String): Flow<WatchlistItem?> =
        db.watchlistDao().observeByKey(key)

    suspend fun toggleWatchlist(
        addonId: String,
        type: String,
        metaId: String,
        name: String,
        poster: String?
    ) = withContext(Dispatchers.IO) {
        // Read-modify-write: serialize concurrent toggles so a double-tap
        // can't upsert after the delete.
        writeMutex.withLock {
            val key = "$addonId|$type|$metaId"
            if (db.watchlistDao().getByKey(key) != null) {
                db.watchlistDao().deleteByKey(key)
            } else {
                db.watchlistDao().upsert(
                    WatchlistItem(
                        key = key,
                        addonId = addonId,
                        type = type,
                        metaId = metaId,
                        name = name,
                        poster = poster,
                        addedAt = System.currentTimeMillis()
                    )
                )
            }
        }
        onWatchlistChanged?.invoke()
    }

    /** Favorite toggle (v0.14.10) — same pattern as [toggleWatchlist]. */
    suspend fun toggleFavorite(
        addonId: String,
        type: String,
        metaId: String,
        name: String,
        poster: String?
    ) = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            val key = "$addonId|$type|$metaId"
            if (db.favoriteDao().getByKey(key) != null) {
                db.favoriteDao().deleteByKey(key)
            } else {
                db.favoriteDao().upsert(
                    FavoriteItem(
                        key = key,
                        addonId = addonId,
                        type = type,
                        metaId = metaId,
                        name = name,
                        poster = poster,
                        addedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    /**
     * Sets (or clears, with null) a title's Plavio status (v0.14.10).
     * One status per title: NEXT_TO_WATCH is backed by the watchlist
     * table — setting it drops any explicit row and ensures watchlist
     * membership; setting any other status writes the explicit row
     * and removes watchlist membership so the title fully moves;
     * clearing drops the explicit row, or the watchlist membership
     * when the resolved status was Next to Watch. See [PlavioStatuses].
     */
    suspend fun setPlavioStatus(
        addonId: String,
        type: String,
        metaId: String,
        name: String,
        poster: String?,
        status: String?
    ) = withContext(Dispatchers.IO) {
        var watchlistChanged = false
        writeMutex.withLock {
            val key = "$addonId|$type|$metaId"
            when (status) {
                null -> {
                    val hadExplicit = db.titleStatusDao().getByKey(key) != null
                    db.titleStatusDao().deleteByKey(key)
                    if (!hadExplicit && db.watchlistDao().getByKey(key) != null) {
                        db.watchlistDao().deleteByKey(key)
                        watchlistChanged = true
                    }
                }
                PlavioStatuses.NEXT_TO_WATCH -> {
                    db.titleStatusDao().deleteByKey(key)
                    if (db.watchlistDao().getByKey(key) == null) {
                        db.watchlistDao().upsert(
                            WatchlistItem(
                                key = key,
                                addonId = addonId,
                                type = type,
                                metaId = metaId,
                                name = name,
                                poster = poster,
                                addedAt = System.currentTimeMillis()
                            )
                        )
                        watchlistChanged = true
                    }
                }
                else -> {
                    db.titleStatusDao().upsert(
                        TitleStatusItem(
                            key = key,
                            addonId = addonId,
                            type = type,
                            metaId = metaId,
                            name = name,
                            poster = poster,
                            status = status,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    if (db.watchlistDao().getByKey(key) != null) {
                        db.watchlistDao().deleteByKey(key)
                        watchlistChanged = true
                    }
                }
            }
        }
        if (watchlistChanged) onWatchlistChanged?.invoke()
    }

    /** The Phase 1 tracking write layer (Trakt/Simkl/MDBList) for the UI. */
    fun trackingWrites(): TrackingWrites = TrackingWrites(settings)

    /**
     * One series the user follows ANYWHERE (v0.14.13): [addonId] is
     * the local watchlist's serving addon, or "" when the series is
     * followed only through Trakt/Simkl.
     */
    data class FollowedSeries(val metaId: String, val addonId: String, val name: String)

    @Volatile
    private var followedSeriesCache: Pair<Long, List<FollowedSeries>>? = null

    @Volatile
    private var followedMoviesCache: Pair<Long, List<FollowedSeries>>? = null

    /**
     * The UNION of series the user follows (v0.14.13, item 1): the
     * on-device watchlist + the Trakt watchlist + Trakt
     * watching/progress + the Simkl plan-to-watch + Simkl watching +
     * Simkl by-status sections + Simkl custom lists — deduped by
     * IMDb id, local entries first (they carry the serving addon).
     * The same union the Library's Upcoming scan reads (v0.14.11);
     * factored here so the background episode checker and the
     * detail page's notification bell read the identical set. An
     * unlinked or failing service contributes nothing. Cached for
     * five minutes per process — the detail bell and the worker
     * both read it, and Trakt's progress walk is not cheap.
     */
    suspend fun followedSeries(): List<FollowedSeries> = withContext(Dispatchers.IO) {
        followedSeriesCache?.let { (at, list) ->
            if (System.currentTimeMillis() - at < FOLLOWED_CACHE_MS) return@withContext list
        }
        val seen = LinkedHashMap<String, FollowedSeries>()
        fun add(id: String, addonId: String, name: String) {
            if (id.isBlank() || id in seen) return
            seen[id] = FollowedSeries(id, addonId, name)
        }
        runCatching { db.watchlistDao().getAll() }.getOrNull().orEmpty()
            .filter { it.type == "series" }
            .forEach { add(it.metaId, it.addonId, it.name) }
        val tw = trackingWrites()
        // Trakt: watchlist + watching/progress (the Up Next source).
        runCatching { tw.traktWatchlist() }.getOrNull().orEmpty()
            .filter { it.type == "series" }
            .forEach { add(it.imdbId, "", it.title) }
        val traktToken = runCatching { TraktManager(settings).validAccessToken() }.getOrNull()
        if (traktToken != null) {
            runCatching { TraktApi().getUpNext(traktToken, 50) }.getOrNull().orEmpty()
                .forEach { add(it.imdbId, "", it.title) }
        }
        // Simkl: plan-to-watch + watching + by-status + custom lists.
        val simklToken = runCatching { SimklManager(settings).validAccessToken() }.getOrNull()
        if (simklToken != null) {
            val simklApi = SimklApi()
            runCatching { simklApi.getPlanToWatch(simklToken) }.getOrNull().orEmpty()
                .filter { it.type == "series" }
                .forEach { add(it.imdbId, "", it.title) }
            runCatching { simklApi.getWatching(simklToken) }.getOrNull().orEmpty()
                .forEach { add(it.imdbId, "", it.title) }
        }
        runCatching { tw.simklAllWithStatus() }.getOrNull().orEmpty()
            .filter { it.type == "series" }
            .forEach { add(it.imdbId, "", it.title) }
        runCatching { tw.simklCustomLists() }.getOrNull().orEmpty().forEach { list ->
            runCatching { tw.simklCustomListItems(list.id) }.getOrNull().orEmpty()
                .filter { it.type == "series" }
                .forEach { add(it.imdbId, "", it.title) }
        }
        val out = seen.values.toList()
        followedSeriesCache = System.currentTimeMillis() to out
        out
    }

    /**
     * The movie twin of [followedSeries] (v0.14.14): the UNION of
     * movies the user keeps — local watchlist + Trakt watchlist +
     * Simkl plan-to-watch / by-status / custom lists — deduped by
     * IMDb id, local entries first. Feeds the new-movie-release
     * background checker; reuses the [FollowedSeries] triple
     * (metaId, addonId, name). Same 5-minute process cache.
     */
    suspend fun followedMovies(): List<FollowedSeries> = withContext(Dispatchers.IO) {
        followedMoviesCache?.let { (at, list) ->
            if (System.currentTimeMillis() - at < FOLLOWED_CACHE_MS) return@withContext list
        }
        val seen = LinkedHashMap<String, FollowedSeries>()
        fun add(id: String, addonId: String, name: String) {
            if (id.isBlank() || id in seen) return
            seen[id] = FollowedSeries(id, addonId, name)
        }
        runCatching { db.watchlistDao().getAll() }.getOrNull().orEmpty()
            .filter { it.type == "movie" }
            .forEach { add(it.metaId, it.addonId, it.name) }
        val tw = trackingWrites()
        runCatching { tw.traktWatchlist() }.getOrNull().orEmpty()
            .filter { it.type == "movie" }
            .forEach { add(it.imdbId, "", it.title) }
        val simklToken = runCatching { SimklManager(settings).validAccessToken() }.getOrNull()
        if (simklToken != null) {
            val simklApi = SimklApi()
            runCatching { simklApi.getPlanToWatch(simklToken) }.getOrNull().orEmpty()
                .filter { it.type == "movie" }
                .forEach { add(it.imdbId, "", it.title) }
        }
        runCatching { tw.simklAllWithStatus() }.getOrNull().orEmpty()
            .filter { it.type == "movie" }
            .forEach { add(it.imdbId, "", it.title) }
        runCatching { tw.simklCustomLists() }.getOrNull().orEmpty().forEach { list ->
            runCatching { tw.simklCustomListItems(list.id) }.getOrNull().orEmpty()
                .filter { it.type == "movie" }
                .forEach { add(it.imdbId, "", it.title) }
        }
        val out = seen.values.toList()
        followedMoviesCache = System.currentTimeMillis() to out
        out
    }

    /**
     * Local watched mark/unmark (v0.14.6): the same WatchedRecord keys
     * playback writes at the 90% mark, so the WATCHED pills follow.
     * season/episode 0 = the movie/title itself.
     */
    suspend fun setLocalWatched(
        metaId: String, season: Int, episode: Int, watched: Boolean
    ) = withContext(Dispatchers.IO) {
        val key = if (season > 0 || episode > 0) {
            WatchedMarks.episodeKey(metaId, season, episode)
        } else {
            WatchedMarks.movieKey(metaId)
        }
        if (watched) {
            db.watchedDao().upsert(WatchedRecord(key, System.currentTimeMillis()))
        } else {
            db.watchedDao().deleteByKey(key)
        }
    }

    /** Addon name → manifest logo URL (Sources tab dressing, Sample 1). */
    suspend fun addonLogosByName(): Map<String, String> = withContext(Dispatchers.IO) {
        enabledAddons()
            .filter { it.logoUrl.isNotBlank() }
            .associate { it.name to it.logoUrl }
    }

    /** True when a Trakt or Simkl account is linked (library sync, issue #3). */
    fun librarySyncLinked(): Boolean = LibrarySyncManager(db, settings).isLinked()

    /** Runs one Trakt/Simkl library sync now; returns the short result line. */
    suspend fun syncLibraryWithServices(): String =
        LibrarySyncManager(db, settings).sync().text

    // ---- Live TV: M3U playlists, favorites, recents, zap handoff ----

    /** In-memory channel list handoff so the player can zap up/down. */
    @Volatile
    var pendingTvChannels: List<TvChannelRef> = emptyList()
        private set

    /** Index into [pendingTvChannels] of the currently playing channel. */
    @Volatile
    var pendingTvIndex: Int = 0

    fun setTvZapList(channels: List<TvChannelRef>, index: Int) {
        pendingTvChannels = channels
        pendingTvIndex = if (channels.isEmpty()) 0 else index.coerceIn(channels.indices)
    }

    /** Result of loading the stored M3U playlists: channel rows + per-playlist errors. */
    data class M3uLoadResult(
        val rows: List<CatalogRow>,
        /** Human-readable failures, one per failed playlist, naming the playlist host. */
        val errors: List<String>
    )

    /** Serializes read-modify-write settings updates (playlist add/remove, watchlist toggles). */
    private val writeMutex = Mutex()

    /** In-memory M3U playlist cache: normalized URL -> (fetchedAt, channels). */
    private val m3uMemoryCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<M3uChannel>>>()

    /**
     * Adds an M3U/IPTV playlist URL. Fetches + parses it now so a bad URL
     * fails fast with a readable error; the URL is stored for reloads.
     * Returns the channel count. Never throws — validation failures come
     * back as Result.failure.
     */
    suspend fun addM3uPlaylist(url: String): Result<Int> = withContext(Dispatchers.IO) {
        // Strip control characters so the "\n"-joined settings list can never
        // be corrupted by a crafted URL.
        // Preserve the endpoint exactly for the request and durable storage;
        // comparisonKey is only for deduplication/cache identity.
        val clean = url.trim().filterNot { it == '\n' || it == '\r' }
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            return@withContext Result.failure(
                IllegalArgumentException("Paste a full http(s) playlist URL")
            )
        }
        getM3uChannels(clean).map { channels ->
            writeMutex.withLock {
                val current = settings.m3uPlaylists
                if (current.none { M3uParser.comparisonKey(it) == M3uParser.comparisonKey(clean) }) {
                    settings.m3uPlaylists = current + clean
                }
            }
            channels.size
        }
    }

    suspend fun removeM3uPlaylist(url: String) = withContext(Dispatchers.IO) {
        writeMutex.withLock {
            val norm = M3uParser.comparisonKey(url)
            // Clean up orphaned state before dropping the URL: cached
            // channels, disk rows, and any pins/recents pointing at this
            // playlist's channels ("m3u|<stream url>" keys).
            val channels = m3uMemoryCache[norm]?.second
                ?: m3uDiskRows(url).flatMap { row ->
                    CatalogCodec.decodeMetas(row.itemsJson)
                        .map { meta -> M3uChannel(meta.name, meta.id, meta.poster, null) }
                }
            val pinKeys = channels.map { "m3u|${it.url}" }.toSet()
            settings.m3uPlaylists = settings.m3uPlaylists
                .filter { M3uParser.comparisonKey(it) != norm }
            if (pinKeys.isNotEmpty()) {
                settings.liveFavorites = settings.liveFavorites - pinKeys
                settings.liveRecent = settings.liveRecent.filter { it !in pinKeys }
            }
            m3uMemoryCache.remove(norm)
            // Both spellings: playlists stored by older builds may be raw.
            db.catalogCacheDao().deleteM3uPlaylist(url)
            db.catalogCacheDao().deleteM3uPlaylist(norm)
        }
    }

    /**
     * Loads every stored playlist into grouped "tv" catalog rows.
     * Playlists are fetched CONCURRENTLY (not sequentially), served from
     * the memory/disk cache when fresh (15 min TTL), and failures are
     * reported per-playlist instead of silently dropping channels.
     */
    suspend fun loadM3uRows(): M3uLoadResult = withContext(Dispatchers.IO) {
        val urls = settings.m3uPlaylists
        if (urls.isEmpty()) return@withContext M3uLoadResult(emptyList(), emptyList())
        val outcomes = coroutineScope {
            urls.map { url -> async { loadOnePlaylist(url) } }.awaitAll()
        }
        M3uLoadResult(
            rows = outcomes.flatMap { it.first },
            errors = outcomes.mapNotNull { it.second }
        )
    }

    /** One playlist -> (rows, optional error message naming the playlist). Never throws. */
    private suspend fun loadOnePlaylist(url: String): Pair<List<CatalogRow>, String?> {
        val host = playlistHost(url)
        return getM3uChannels(url).fold(
            onSuccess = { channels -> m3uChannelsToRows(url, host, channels) to null },
            onFailure = { e ->
                // A dead playlist must not nuke the tab: keep the last
                // cached channels visible (if any) and name the failure.
                val stale = m3uDiskRows(url).map { row ->
                    CatalogRow(
                        addonId = row.addonId,
                        addonName = row.addonName,
                        baseUrl = row.baseUrl,
                        catalogName = row.catalogName,
                        type = row.type,
                        catalogId = row.catalogId,
                        items = CatalogCodec.decodeMetas(row.itemsJson)
                    )
                }.filter { it.items.isNotEmpty() }
                val msg = "$host: ${readableM3uError(e)}"
                if (stale.isNotEmpty()) stale to "$msg — showing cached channels"
                else emptyList<CatalogRow>() to msg
            }
        )
    }

    /**
     * Channels for one playlist: fresh memory cache -> fresh disk cache
     * (Room catalog_cache, addonId "m3u") -> network (cached to both on
     * success). Never throws.
     */
    private suspend fun getM3uChannels(url: String): Result<List<M3uChannel>> {
        val key = M3uParser.comparisonKey(url)
        val now = System.currentTimeMillis()
        m3uMemoryCache[key]?.let { (ts, channels) ->
            if (now - ts < M3U_CACHE_TTL_MS) return Result.success(channels)
        }
        val diskRows = m3uDiskRows(url)
        if (diskRows.isNotEmpty() && diskRows.all { now - it.fetchedAt < M3U_CACHE_TTL_MS }) {
            val channels = diskRows.flatMap { row ->
                val group = row.catalogName.takeIf { it != "All channels" }
                CatalogCodec.decodeMetas(row.itemsJson).map { meta ->
                    M3uChannel(meta.name, meta.id, meta.poster, group)
                }
            }
            m3uMemoryCache[key] = now to channels
            return Result.success(channels)
        }
        return M3uParser.fetch(url).onSuccess { channels ->
            m3uMemoryCache[key] = now to channels
            writeM3uDiskRows(url, playlistHost(url), channels, now)
        }
    }

    /** Cached M3U rows for one playlist from Room (tolerates raw and normalized baseUrls). */
    private suspend fun m3uDiskRows(url: String): List<CatalogCache> {
        val norm = M3uParser.comparisonKey(url)
        return runCatching {
            db.catalogCacheDao().getAll()
                .filter { it.addonId == "m3u" && M3uParser.comparisonKey(it.baseUrl) == norm }
        }.getOrDefault(emptyList())
    }

    private suspend fun writeM3uDiskRows(
        url: String,
        host: String,
        channels: List<M3uChannel>,
        now: Long
    ) {
        runCatching {
            // Replace (not merge): a shrunken playlist must not leave stale
            // group rows behind.
            db.catalogCacheDao().deleteM3uPlaylist(url)
            db.catalogCacheDao().upsertAll(
                m3uChannelsToRows(url, host, channels).map { row ->
                    CatalogCache(
                        key = "${row.addonId}|${row.type}|${row.catalogId}",
                        addonId = row.addonId,
                        addonName = row.addonName,
                        baseUrl = row.baseUrl,
                        type = row.type,
                        catalogId = row.catalogId,
                        catalogName = row.catalogName,
                        itemsJson = cappedItemsJson(row.items),
                        fetchedAt = now
                    )
                }
            )
        }
    }

    private fun m3uChannelsToRows(
        playlistUrl: String,
        host: String,
        channels: List<M3uChannel>
    ): List<CatalogRow> {
        if (channels.isEmpty()) return emptyList()
        return channels
            .groupBy { it.group?.takeIf { g -> g.isNotBlank() } ?: "All channels" }
            .map { (group, list) ->
                CatalogRow(
                    addonId = "m3u",
                    addonName = host,
                    baseUrl = playlistUrl,
                    catalogName = group,
                    type = "tv",
                    catalogId = "m3u:${M3uParser.comparisonKey(playlistUrl).hashCode()}:${group.hashCode()}",
                    items = list.map { ch ->
                        MetaPreview(
                            id = ch.url,
                            type = "tv",
                            name = ch.name,
                            poster = ch.logo
                        )
                    }
                )
            }
    }

    private fun playlistHost(url: String): String =
        runCatching {
            java.net.URI(url).host?.removePrefix("www.")?.takeIf { it.isNotBlank() } ?: "IPTV"
        }.getOrDefault("IPTV")

    private fun readableM3uError(e: Throwable): String = when (e) {
        is java.net.UnknownHostException ->
            "couldn't reach the server (check your connection)"
        is java.net.SocketTimeoutException ->
            "the server took too long to respond"
        else -> e.message?.takeIf { it.isNotBlank() } ?: "couldn't load the playlist"
    }

    /** Toggle a channel pin. Keys: "addonId|metaId" ("m3u|<url>" for playlists). */
    fun toggleLiveFavorite(key: String) {
        val cur = settings.liveFavorites.toMutableSet()
        if (!cur.add(key)) cur.remove(key)
        settings.liveFavorites = cur
    }

    /** Push a channel key to the front of the recents (max 20). */
    fun pushLiveRecent(key: String) {
        settings.liveRecent = (listOf(key) + settings.liveRecent.filter { it != key }).take(20)
    }

    // ---- Subtitle search (feature 9) ----

    /**
     * Queries every installed subtitle-capable addon via the Stremio addon
     * protocol ({base}/subtitles/{type}/{imdbId}.json), merged and
     * de-duplicated. Results are cached briefly (6h) in Room.
     */
    suspend fun searchSubtitles(type: String, imdbId: String): List<Subtitle> =
        withContext(Dispatchers.IO) {
            val key = "$type|$imdbId"
            val now = System.currentTimeMillis()
            val cached = db.subtitleCacheDao().getByKey(key)
            if (cached != null && now - cached.fetchedAt < SUBTITLE_CACHE_TTL_MS) {
                return@withContext CatalogCodec.decodeSubtitles(cached.itemsJson)
            }
            val addons = enabledAddons().filter { addon ->
                addon.hasSubtitles && run {
                    val types = addonTypes(addon)
                    types.isEmpty() || type in types
                }
            }
            val results = coroutineScope {
                addons.map { addon ->
                    async {
                        withTimeoutOrNull(STREAM_FETCH_TIMEOUT_MS) {
                            try { addonRequest { api.fetchSubtitles(addon.baseUrl, type, imdbId) } }
                            catch (cancel: CancellationException) { throw cancel }
                            catch (_: Exception) { emptyList() }
                        } ?: emptyList()
                    }
                }.awaitAll().flatten()
            }.distinctBy { it.url }
            if (results.isNotEmpty()) {
                db.subtitleCacheDao().upsert(
                    SubtitleCache(key, CatalogCodec.encodeSubtitles(results), now)
                )
            }
            results
        }

    // ---- Pre-installed addons (feature 4) ----

    /**
     * Resolves a manifest `logo` value into a loadable absolute URL
     * (v0.14.26, item 13): absolute values pass through untouched;
     * a root-relative value ("/logo.svg") resolves against the
     * addon origin; a plain relative value ("logo.svg") resolves
     * against the addon's (normalized) base URL — the same base the
     * manifest itself was fetched from. Before this, the raw value
     * was stored verbatim, so any relative logo could never load.
     */
    private fun resolveAddonLogoUrl(baseUrl: String, logo: String?): String {
        val raw = logo?.trim().orEmpty()
        if (raw.isEmpty()) return ""
        if (raw.startsWith("http://", ignoreCase = true) ||
            raw.startsWith("https://", ignoreCase = true)
        ) return raw
        val base = runCatching { StremioApi.normalizeBaseUrl(baseUrl) }.getOrNull()
            ?: return raw
        return if (raw.startsWith("/")) {
            val http = base.toHttpUrlOrNull() ?: return raw
            http.newBuilder().encodedPath(raw).query(null).fragment(null)
                .build().toString()
        } else {
            base.trimEnd('/') + "/" + raw
        }
    }

    /**
     * Fills in missing addon logos from their manifests (one quiet pass per
     * launch for addons installed before logos were stored).
     */
    suspend fun backfillAddonLogos() = withContext(Dispatchers.IO) {
        val dao = db.addonDao()
        for (addon in dao.getAll()) {
            if (addon.logoUrl.isNotBlank()) continue
            try {
                val logo = resolveAddonLogoUrl(
                    addon.baseUrl, api.fetchManifest(addon.baseUrl).logo
                ).takeIf { it.isNotBlank() } ?: continue
                dao.upsert(addon.copy(logoUrl = logo))
            } catch (_: Exception) {
                // Offline or dead URL — try again next launch.
            }
        }
    }
    /**
     * Auto-installs the pre-installed addons (public PlavioHD +
     * PlavioMeta) once — the only two the app ships ON (v0.14.35,
     * owner's order 2026-11-01).
     * PlavioMeta is our first-party TMDB metadata addon and the only
     * shipped meta source; anything else the user adds by hand is
     * carried by the generic any-meta-addon design. Subtitles come
     * from PlavioSubs, built into the player (v0.14.33) — the old
     * pre-installed subtitle addons (OpenSubtitles v3, SubSense) were
     * removed in v0.14.34 and Cinemeta in v0.14.35; see
     * removeRetiredPreinstalledAddons().
     * Each addon is attempted at most once (tracked per manifest id), so a
     * user who removes one is never force-fed it again; a failed attempt
     * (e.g. offline first launch) is retried on the next launch.
     */
    suspend fun ensurePreinstalledAddons() = withContext(Dispatchers.IO) {
        // NOTE: the public hd.plavio.site IS pre-installed again, listed
        // first (owner's order 2026-10-28, superseding his 2026-10-24 order
        // that removed it). The LOCKED addon.plavio.site was retired in
        // v0.14.34 (owner's order 2026-11-01) — it is no longer installed;
        // removeRetiredPreinstalledAddons() deletes its shipped row.
        // PMeta's target follows the effective PMeta door (remote
        // config → compiled default, AppConfig): a future door move
        // re-points fresh installs and the migration below without
        // an app update. With no config published this is exactly
        // the historical literal, "https://meta.plavio.site/manifest.json".
        val pmetaManifestUrl = AppConfig.pmetaManifestUrl()
        val targets = listOf(
            "https://hd.plavio.site/manifest.json",
            pmetaManifestUrl
        )
        for (url in targets) {
            try {
                val baseUrl = StremioApi.normalizeBaseUrl(url)
                val manifest = addonRequest { api.fetchManifest(baseUrl) }
                // Migrate only the exact historical bare PlavioHD host. A user
                // configured URL (including options/query/key) is never replaced.
                // Stored baseUrls are normalized (normalizeBaseUrl strips
                // "/manifest.json"), so match the bare host form too — the
                // manifest-suffixed forms above only cover rows stored by
                // builds from before that normalization (2026-10-28).
                val existing = db.addonDao().getAll().firstOrNull { it.id == manifest.id }
                val legacyPlavioHd = "https://plaviohd.edon.workers.dev/manifest.json"
                val previousPlavioHd = "https://plaviohd.vercel.app/manifest.json"
                if (url == "https://hd.plavio.site/manifest.json" &&
                    (existing?.baseUrl == legacyPlavioHd || existing?.baseUrl == previousPlavioHd ||
                        existing?.baseUrl == "https://plaviohd.edon.workers.dev" ||
                        existing?.baseUrl == "https://plaviohd.vercel.app")) {
                    db.addonDao().upsert(existing.copy(baseUrl = baseUrl))
                    invalidateAddonCaches(existing.id)
                }
                // v0.14.28 (owner's order 2026-10-31): PMeta lives on our
                // own domain now — meta.plavio.site answers with the same
                // PMeta, so its hosting can move later by DNS alone.
                // Migrate only the exact historical bare Vercel host
                // forms, on the row matched by the PMeta manifest id
                // above; a user-configured PMeta URL (config segment
                // carrying their own key/options) is never replaced.
                val legacyPmeta = "https://plaviometa.vercel.app/manifest.json"
                if (url == pmetaManifestUrl &&
                    existing != null &&
                    (existing.baseUrl == legacyPmeta ||
                        existing.baseUrl == "https://plaviometa.vercel.app")) {
                    db.addonDao().upsert(existing.copy(baseUrl = baseUrl))
                    invalidateAddonCaches(existing.id)
                }
                if (settings.isPreinstallDone(manifest.id)) continue
                val alreadyThere = existing != null
                addAddonFromUrl(url).onSuccess { outcome ->
                    if (!alreadyThere) db.addonDao().upsert(outcome.addon.copy(preinstalled = true))
                    settings.setPreinstallDone(manifest.id)
                }
            } catch (_: Exception) {
                // Offline or dead URL — try again next launch.
            }
        }
    }

    // ---- Retired pre-installed addons (owner's order 2026-11-01, v0.14.34;
    // ---- Cinemeta + Pipe added v0.14.35) ----

    /**
     * Upgrade cleanup for addons the app used to ship but no longer does
     * (owner's order 2026-11-01):
     *  - the LOCKED PlavioHD (addon.plavio.site, id
     *    community.plaviohd.private) — the public PlavioHD is the only
     *    shipped streams addon now. (The x-plavio-key gate plumbing in
     *    StremioApi stays, so a hand-added copy still works.)
     *  - OpenSubtitles v3 and SubSense — PlavioSubs, built into the
     *    player, replaced them.
     *  - Cinemeta (v0.14.35) — PlavioMeta is the only shipped meta
     *    addon now.
     * Their app-shipped rows (preinstalled flag set) are deleted via the
     * normal removal path; a row the user added by hand (flag unset) is
     * theirs and stays. The bundled rows (CNCVerse, Pengu, and Pipe
     * since v0.14.35) are deleted only when untouched (preinstalled AND
     * still disabled) — a user who switched one on keeps it.
     *
     * Rows are matched by manifest id, with a base-URL fallback
     * (v0.14.35): a retired addon that ever changes its manifest id
     * would stop matching by id and its shipped row would live forever,
     * so a row whose normalised base URL equals a retired addon's
     * shipped base URL is treated as that addon, under the SAME flag
     * rules. Every retired id — and any id a URL-matched row actually
     * carries — is marked preinstall-done so no legacy path can
     * resurrect it. Idempotent: after the first pass the rows are gone
     * and only the markers remain.
     */
    suspend fun removeRetiredPreinstalledAddons() = withContext(Dispatchers.IO) {
        // Retired pre-installed (ON) addons: manifest id -> the base URL
        // the app shipped it under (the fallback match key).
        val alwaysRetire = mapOf(
            "community.plaviohd.private" to "https://addon.plavio.site",
            "org.stremio.opensubtitlesv3" to "https://opensubtitles-v3.strem.io",
            "com.subsense.nepiraw" to "https://subsense.nepiraw.com",
            "com.linvo.cinemeta" to "https://v3-cinemeta.strem.io"
        )
        // Retired bundled (OFF) addons, same shape.
        val bundledRetire = mapOf(
            "com.cncverse.stremiobridge" to "https://cncverse.dpdns.org",
            "com.penguplay" to "https://pengu.uk",
            "org.boringways.pipe" to
                "https://pipe.boringways.workers.dev/eyJzdCI6Imh0dHAifQ"
        )
        val alwaysBases = alwaysRetire.values.map { normalizeRetiredBase(it) }.toSet()
        val bundledBases = bundledRetire.values.map { normalizeRetiredBase(it) }.toSet()
        val matchedIds = mutableSetOf<String>()
        for (addon in db.addonDao().getAll()) {
            val base = normalizeRetiredBase(addon.baseUrl)
            val retire = when {
                addon.id in alwaysRetire || base in alwaysBases -> addon.preinstalled
                addon.id in bundledRetire || base in bundledBases ->
                    addon.preinstalled && !addon.enabled
                else -> false
            }
            if (retire) {
                matchedIds += addon.id
                removeAddon(addon.id)
            }
        }
        (alwaysRetire.keys + bundledRetire.keys + matchedIds).forEach {
            settings.setPreinstallDone(it)
        }
    }

    /**
     * Normalises a stored addon base URL for the retired-addon fallback
     * match: scheme + host lowercased, path kept as-is, trailing "/"
     * and a trailing "/manifest.json" (rows stored before base-URL
     * normalisation) stripped. Unparseable values fall back to a plain
     * lowercase/trim, which simply never matches a shipped base.
     */
    private fun normalizeRetiredBase(raw: String): String {
        val trimmed = raw.trim().trimEnd('/')
        return try {
            val uri = java.net.URI(trimmed)
            val scheme = uri.scheme?.lowercase() ?: return trimmed.lowercase()
            val host = uri.host?.lowercase() ?: return trimmed.lowercase()
            var path = uri.path ?: ""
            if (path.endsWith("/manifest.json")) {
                path = path.removeSuffix("/manifest.json")
            }
            path = path.trimEnd('/')
            val port = if (uri.port >= 0) ":${uri.port}" else ""
            "$scheme://$host$port$path"
        } catch (_: Exception) {
            trimmed.lowercase()
        }
    }

    /**
     * Kept (with its call sites) as a no-op: hd.plavio.site is a
     * pre-installed default again (owner's order 2026-10-28, superseding
     * his 2026-10-24 order), so the app-preinstalled public HD row must
     * NOT be removed anymore.
     */
    suspend fun removePreinstalledPublicHd() {
        // No-op — see the doc comment above (2026-10-28).
    }

    // ---- Bundled addons (beginner-friendly, OFF by default) ----

    /**
     * Ships a small set of addons with the app for users who don't hunt
     * manifest URLs (owner's order 2026-10-23). All start OFF. (CNCVerse
     * and Pengu left the bundle in v0.14.34, Pipe in v0.14.35 — owner's
     * orders 2026-11-01; HDHub is the only bundled addon now.)
     * Once installed it behaves exactly like a hand-added addon (toggle, edit,
     * delete). Each is attempted once per manifest id — a user who deletes
     * one is never force-fed it again.
     */
    suspend fun ensureBundledAddons() = withContext(Dispatchers.IO) {
        val targets = listOf(
            "https://hdhub.thevolecitor.qzz.io/manifest.json"
        )
        for (url in targets) {
            try {
                val baseUrl = StremioApi.normalizeBaseUrl(url)
                val manifest = addonRequest { api.fetchManifest(baseUrl) }
                val existing = db.addonDao().getAll().firstOrNull { it.id == manifest.id }
                if (settings.isPreinstallDone(manifest.id)) continue
                if (existing != null) {
                    settings.setPreinstallDone(manifest.id)
                    continue
                }
                addAddonFromUrl(url).onSuccess { outcome ->
                    db.addonDao().upsert(outcome.addon.copy(preinstalled = true, enabled = false))
                    settings.setPreinstallDone(manifest.id)
                }
            } catch (_: Exception) {
                // Offline or dead URL — try again next launch.
            }
        }
    }

    companion object {
        private const val SUBTITLE_CACHE_TTL_MS = 6L * 3600L * 1000L
        /** Fail-fast budget per addon when resolving streams/subtitles. */
        private const val STREAM_FETCH_TIMEOUT_MS = 20000L
        /**
         * Extended budget (v0.14.24): the first-party host's cold fills
         * legitimately outlast the standard budget, and a leg that timed
         * out once is re-asked with this budget on the next collect —
         * a timeout means "still cooking", not "no streams exist".
         */
        private const val FIRST_PARTY_STREAM_TIMEOUT_MS = 45000L
        /**
         * Pause between re-asks of a still-filling (marked) leg
         * (v0.14.25). Each re-ask itself rides the server's ~7 s
         * short-hold while the fill runs, so the effective cadence is
         * hold + this pause, all inside the leg's existing budget.
         */
        private const val FILLING_REASK_DELAY_MS = 3000L
        /**
         * How long a cached stream list may be painted as a collect's
         * seed before only the network answer may show. The window
         * itself lives in [StreamCacheSupport.SEED_TTL_MS] so the rule
         * is unit-pinned. History: v0.14.21 raised it 5 min → 3 h for
         * instant evening reopens; v0.14.36 (defect 1) returns it to
         * 5 min — the 3 h window froze formatter-composed stream text
         * behind hours-old payloads after server-side style changes,
         * and no addon lifecycle event invalidated the cache. The
         * invalidation half of that fix is in [invalidateAddonCaches].
         */
        /** PrePlay pocket freshness (item 13): within this window a
         *  re-prefetch is skipped; play-press inside it starts from
         *  the pocket instantly (spec: "short life, ~minutes"). */
        private const val PREPLAY_FRESH_MS = 5L * 60L * 1000L
        /**
         * Max bytes per cached catalog row — well under SQLite's ~2MB
         * CursorWindow limit, so a row can never poison reads again.
         */
        private const val MAX_CACHED_ROW_BYTES = 900_000
        /** Manifests rarely change — skip the round-trip for 6h (24h delayed newly search-capable addons). */
        private const val MANIFEST_TTL_MS = 6L * 3600L * 1000L
        /** Hard ceiling for a whole remote-search pass so "Searching…" can't hang. */
        private const val REMOTE_SEARCH_PROVIDER_TIMEOUT_MS = 5_000L
        /** Budget for the app-owned primary search stage (v0.14.27). */
        private const val PRIMARY_SEARCH_TIMEOUT_MS = 8_000L
        /** Freshness of the session query cache that seeds instant display. */
        private const val SEARCH_QUERY_CACHE_TTL_MS = 10L * 60L * 1000L
        /** Bound for the session query cache (settled queries kept). */
        private const val SEARCH_QUERY_CACHE_MAX_ENTRIES = 50
        /** Per-addon budget inside the sequential getMetaFromAny walk. */
        private const val META_FETCH_TIMEOUT_MS = 15_000L

        /** How long [followedSeries] reuses one union walk per process. */
        private const val FOLLOWED_CACHE_MS = 5 * 60_000L
        /** Disk meta cache freshness (v0.14.11): series revalidate after a day — episode lists change while a show airs. */
        private const val META_CACHE_TTL_SERIES_MS = 24L * 3600L * 1000L
        /** Disk meta cache freshness: movies are static, a week is safe. */
        private const val META_CACHE_TTL_MOVIE_MS = 7L * 24L * 3600L * 1000L
        /** Disk meta cache size guard: evict oldest-fetched rows beyond the cap, down to the keep level. */
        private const val META_CACHE_MAX_ROWS = 5_000
        private const val META_CACHE_KEEP_ROWS = 4_500
        /** Freshness of cached M3U playlists (memory + disk). */
        private const val M3U_CACHE_TTL_MS = 15L * 60L * 1000L
        /** Freshness of the in-memory Live-tab TV rows. */
        private const val TV_ROWS_TTL_MS = 15L * 60L * 1000L
        /** Freshness of the in-memory Trailers-tab data. */
        private const val TRAILERS_CACHE_TTL_MS = 15L * 60L * 1000L
        private const val MAX_BACKUP_BYTES = 10 * 1024 * 1024
        private const val MAX_BACKUP_ROWS = 50_000
        private const val MAX_BACKUP_SETTINGS = 2_000
        private const val MAX_BACKUP_STRING = 32_768
        private const val MAX_PORTABLE_ADDON_URLS = 1_000
        private const val MAX_ADDON_URL_LENGTH = 8_192
        private const val LOCKED_ADDON_URL_PLACEHOLDER_PATH = "/__plavio_encrypted_config_required__"
    }

    /**
     * Encodes catalog items for the cache, shrinking the list until the
     * JSON fits safely under the CursorWindow limit.
     */
    private fun cappedItemsJson(items: List<MetaPreview>): String {
        fun bytes(value: String) = value.toByteArray(Charsets.UTF_8).size
        var kept = items
        var json = CatalogCodec.encodeMetas(kept)
        while (bytes(json) > MAX_CACHED_ROW_BYTES && kept.isNotEmpty()) {
            if (kept.size > 1) {
                kept = kept.dropLast(maxOf(1, kept.size / 2))
            } else {
                // Bound large user/provider-controlled text fields as well as list count.
                val item = kept.single()
                val shortened = item.copy(
                    name = item.name.take(256),
                    description = item.description?.take(2_000),
                    poster = item.poster?.take(2_000),
                    background = item.background?.take(2_000),
                    logo = item.logo?.take(2_000)
                )
                val candidate = CatalogCodec.encodeMetas(listOf(shortened))
                if (bytes(candidate) <= MAX_CACHED_ROW_BYTES) return candidate
                kept = emptyList()
            }
            json = CatalogCodec.encodeMetas(kept)
        }
        return if (bytes(json) <= MAX_CACHED_ROW_BYTES) json else "[]"
    }

    // ------------------------------------------------------------------
    // Versioned backup. Caches, download records/media, onboarding state
    // and the Plavio account's own auth tokens are never exported.
    // Integration credentials (API keys, Trakt/Simkl tokens) and raw
    // configured addon URLs are carried ONLY when the caller explicitly
    // opts in — the Plavio account sync does (owner's orders: signing
    // back in restores everything, keys included); the local encrypted
    // file export never does.
    // ------------------------------------------------------------------
    private data class ParsedBackup(
        val version: Int,
        val settings: Map<String, Any?>?,
        val addons: List<InstalledAddon>?,
        val watchlist: List<WatchlistItem>?,
        val playback: List<PlaybackState>?,
        val lists: List<CustomList>?,
        val listItems: List<CustomListItem>?,
        val apiKeys: Map<String, String>?,
        /** Base64 JPEG of the user's own profile photo, when the backup carries one. */
        val profilePhotoBase64: String? = null,
        /** Favorites + Plavio statuses (v0.14.10). Absent in older payloads → null → untouched on import. */
        val favorites: List<FavoriteItem>? = null,
        val plavioStatuses: List<TitleStatusItem>? = null,
        /** Raw configured addon URLs (account sync only). Absent → null → untouched on import. */
        val addonUrls: Map<String, PortableAddonUrlConfig>? = null
    )

    suspend fun exportBackupJson(
        enabledCategories: Set<String>? = null,
        includePrivateAddonUrls: Boolean = false
    ): Result<String> = try {
        withContext(Dispatchers.IO) {
            val root = JSONObject().apply {
                put("format", "plavio-backup"); put("version", 2)
                put("exportedAt", System.currentTimeMillis()); put("appVersion", BuildConfig.VERSION_NAME)
                put("coverage", "settings,addons,watchlist,favorites,plavioStatuses,playback,customLists; downloads excluded")
                // Sync category filtering (user's order): skip disabled categories
                val includeSettings = enabledCategories?.contains("settings") ?: true
                val includeAddons = enabledCategories?.contains("addons") ?: true
                val includeWatchlist = enabledCategories?.contains("watchlist") ?: true
                val includePlayback = enabledCategories?.contains("watch_history") ?: true
                val includeCustomLists = enabledCategories?.contains("custom_lists") ?: true
                val includeSearchHistory = enabledCategories?.contains("search_history") ?: true
                if (includeSettings) {
                    val prefsJson = JSONObject()
                    settings.exportAllPrefs().forEach { (k, v) ->
                        if (!isSecretPreference(k)) when (v) {
                            is Boolean, is Int, is Long, is Float, is Double -> prefsJson.put(k, v)
                            is String -> prefsJson.put(k, safeBackupSetting(k, v))
                            is Set<*> -> prefsJson.put(k, JSONArray(v.map { it.toString() }))
                            null -> prefsJson.put(k, JSONObject.NULL)
                        }
                    }
                    put("settings", prefsJson)
                    // Profile photo (owner's order 2026-10-24): the choice
                    // itself is a normal preference above; the cropped JPEG
                    // bytes ride the backup as their own field.
                    if (settings.profileAvatar == "photo") {
                        settings.readProfilePhotoBytes()?.let { bytes ->
                            put("profilePhoto", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                        }
                    }
                }
                // API keys: simple sync (user's order) — their own category,
                // independent of the settings category. Only when the caller
                // explicitly enables "api_keys": the account sync passes the
                // user's "What to sync" set (keys on by default); the local
                // file export passes no categories and never carries them.
                if (enabledCategories?.contains("api_keys") == true) {
                    val apiKeysJson = JSONObject()
                    settings.exportApiKeysForBackup().forEach { (k, v) -> apiKeysJson.put(k, v) }
                    put("api_keys", apiKeysJson)
                }
                // Raw configured addon URLs (account sync only): the addons
                // section below deliberately redacts any URL carrying a path
                // or query — which is where addon configuration lives — so
                // the real URLs ride here and restore re-attaches them.
                if (includePrivateAddonUrls && includeAddons) {
                    val urlsJson = JSONObject()
                    exportPortableAddonUrls().forEach { (id, cfg) ->
                        urlsJson.put(id, JSONObject().put("baseUrl", cfg.baseUrl).put("enabled", cfg.enabled))
                    }
                    if (urlsJson.length() > 0) put("addonUrls", urlsJson)
                }
                if (includeAddons) {
                    put("addons", JSONArray(db.addonDao().getAll().map { a -> JSONObject().apply {
                        val requiresEncryptedUrl = addonNeedsEncryptedUrl(a.baseUrl)
                        put("id", a.id); put("name", a.name); put("version", a.version)
                        put("description", a.description); put("baseUrl", safeAddonBackupUrl(a.baseUrl))
                        if (requiresEncryptedUrl) put("encryptedUrlRequired", true)
                        put("types", a.types); put("resources", a.resources); put("preinstalled", a.preinstalled)
                        put("enabled", a.enabled); put("configurable", a.configurable); put("showOnHome", a.showOnHome)
                        put("logoUrl", safeAddonAuxUrl(a.logoUrl)); put("sortOrder", a.sortOrder)
                        put("starred", a.starred); put("addedAt", a.addedAt)
                    } }))
                }
                if (includeWatchlist) {
                    put("watchlist", JSONArray(db.watchlistDao().getAll().map { w -> JSONObject().apply {
                        put("key", w.key); put("addonId", w.addonId); put("type", w.type); put("metaId", w.metaId)
                        put("name", w.name); put("poster", w.poster?.let(::safeBackupUrl) ?: JSONObject.NULL); put("addedAt", w.addedAt)
                        put("logo", w.logo?.let(::safeBackupUrl) ?: JSONObject.NULL)
                    } }))
                    // Favorites + Plavio statuses ride the watchlist
                    // category (v0.14.10) — same library surface.
                    put("favorites", JSONArray(db.favoriteDao().getAll().map { w -> JSONObject().apply {
                        put("key", w.key); put("addonId", w.addonId); put("type", w.type); put("metaId", w.metaId)
                        put("name", w.name); put("poster", w.poster?.let(::safeBackupUrl) ?: JSONObject.NULL); put("addedAt", w.addedAt)
                        put("logo", w.logo?.let(::safeBackupUrl) ?: JSONObject.NULL)
                    } }))
                    put("plavioStatuses", JSONArray(db.titleStatusDao().getAll().map { s -> JSONObject().apply {
                        put("key", s.key); put("addonId", s.addonId); put("type", s.type); put("metaId", s.metaId)
                        put("name", s.name); put("poster", s.poster?.let(::safeBackupUrl) ?: JSONObject.NULL)
                        put("status", s.status); put("updatedAt", s.updatedAt)
                        put("logo", s.logo?.let(::safeBackupUrl) ?: JSONObject.NULL)
                    } }))
                }
                if (includePlayback) {
                    put("playback", JSONArray(db.playbackDao().getAll().map { state -> JSONObject().apply {
                        put("key", state.key); put("title", state.title)
                        put("poster", state.poster?.let(::safeBackupUrl) ?: JSONObject.NULL); put("videoId", state.videoId)
                        put("streamUrl", safeBackupUrl(state.streamUrl)); put("positionMs", state.positionMs)
                        put("durationMs", state.durationMs); put("imdbId", state.imdbId ?: JSONObject.NULL)
                        put("season", state.season); put("episode", state.episode); put("updatedAt", state.updatedAt)
                        put("seriesName", state.seriesName ?: JSONObject.NULL)
                        put("episodeTitle", state.episodeTitle ?: JSONObject.NULL)
                        put("metaId", state.metaId ?: JSONObject.NULL)
                        // Stream identity (DB v15): the resume must
                        // re-select the same stream on the other
                        // device too, not just the same position.
                        put("streamAddonId", state.streamAddonId ?: JSONObject.NULL)
                        put("streamName", state.streamName ?: JSONObject.NULL)
                        put("streamTitle", state.streamTitle ?: JSONObject.NULL)
                        put("streamQuality", state.streamQuality ?: JSONObject.NULL)
                        put("logo", state.logo?.let(::safeBackupUrl) ?: JSONObject.NULL)
                        // Episode list + import provenance (DB v16).
                        put("episodeIdsJson", state.episodeIdsJson ?: JSONObject.NULL)
                        put("remoteProgressPct", state.remoteProgressPct ?: JSONObject.NULL)
                        put("importSource", state.importSource ?: JSONObject.NULL)
                    } }))
                }
                if (includeCustomLists) {
                    put("customLists", JSONArray(db.customListDao().getLists().map { l -> JSONObject().apply {
                        put("id", l.id); put("name", l.name); put("createdAt", l.createdAt)
                    } }))
                    put("customListItems", JSONArray(db.customListDao().getAllItems().map { item -> JSONObject().apply {
                        put("listId", item.listId); put("itemKey", item.itemKey); put("addonId", item.addonId)
                        put("type", item.type); put("metaId", item.metaId); put("name", item.name)
                        put("poster", item.poster?.let(::safeBackupUrl) ?: JSONObject.NULL); put("addedAt", item.addedAt)
                        put("logo", item.logo?.let(::safeBackupUrl) ?: JSONObject.NULL)
                    } }))
                }
                // Search history is stored in SharedPreferences, handled via settings if enabled
            }
            val payload = root.toString()
            require(payload.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "Backup exceeds the 10 MiB safety limit." }
            Result.success(payload)
        }
    } catch (cancel: CancellationException) { throw cancel }
      catch (e: Exception) { Result.failure(e) }

    /** Fully validates a backup without mutating app state; suitable for a replacement preview. */
    fun previewBackupJson(json: String): Result<BackupPreview> = try {
        val parsed = parseBackup(json)
        Result.success(BackupPreview(parsed.version, parsed.addons?.size ?: 0,
            parsed.watchlist?.size ?: 0, parsed.playback?.size ?: 0,
            parsed.lists?.size ?: 0, parsed.listItems?.size ?: 0))
    } catch (e: Exception) { Result.failure(e) }

    suspend fun importBackupJson(json: String): Result<Unit> = try {
        val parsed = parseBackup(json) // validation is complete before any mutation
        withContext(Dispatchers.IO) {
            val previousPrefs = settings.exportAllPrefs().toMutableMap()
            try {
                db.withTransaction {
                    parsed.addons?.let { rows -> db.addonDao().clearAll(); rows.forEach { db.addonDao().upsert(it) } }
                    parsed.watchlist?.let { rows -> db.watchlistDao().clearAll(); rows.forEach { db.watchlistDao().upsert(it) } }
                    parsed.favorites?.let { rows -> db.favoriteDao().clearAll(); rows.forEach { db.favoriteDao().upsert(it) } }
                    parsed.plavioStatuses?.let { rows -> db.titleStatusDao().clearAll(); rows.forEach { db.titleStatusDao().upsert(it) } }
                    parsed.playback?.let { rows -> db.playbackDao().clearAll(); rows.forEach { db.playbackDao().upsert(it) } }
                    parsed.lists?.let { rows ->
                        db.customListDao().clearAllItems(); db.customListDao().clearLists()
                        if (rows.isNotEmpty()) db.customListDao().insertLists(rows)
                        val items = parsed.listItems.orEmpty()
                        if (items.isNotEmpty()) db.customListDao().insertItems(items)
                    } ?: parsed.listItems?.let { rows ->
                        db.customListDao().clearAllItems()
                        if (rows.isNotEmpty()) db.customListDao().insertItems(rows)
                    }
                    db.subtitleCacheDao().clearAll(); db.catalogCacheDao().clearAll()
                    parsed.settings?.let { settings.importAllPrefs(it) }
                    // Restore API keys (simple sync, user's order)
                    parsed.apiKeys?.let { settings.importApiKeysFromBackup(it) }
                }
            } catch (cancel: CancellationException) {
                settings.importAllPrefs(previousPrefs)
                throw cancel
            } catch (e: Exception) {
                settings.importAllPrefs(previousPrefs)
                throw e
            }
            // Restore the profile photo bytes, if the backup carried them
            // (the choice itself arrived with the settings import above).
            parsed.profilePhotoBase64?.let { encoded ->
                runCatching {
                    settings.writeProfilePhoto(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT))
                }
            }
            // Re-attach the raw configured addon URLs (account backups
            // only): the addons section restored path/query-bearing
            // addons as locked placeholders; this puts the real URLs (and
            // the user's enabled choices) back. Best-effort — every other
            // section has already restored by this point, so a URL hiccup
            // must not fail the whole restore.
            parsed.addonUrls?.let { configs ->
                runCatching { restorePortableAddonUrls(configs) }
            }
            // All provider-owned cached responses are invalid after replacing settings/addons.
            clearAllManifestCaches(); catalogCache = emptyList(); trailersCache = null; tvRowsMemoryCache = null
            Result.success(Unit)
        }
    } catch (cancel: CancellationException) { throw cancel }
      catch (e: Exception) { Result.failure(e) }

    /** A clean profile target for cloud switching: reset portable preferences,
     * replaceable libraries/addons and custom lists are explicitly empty. */
    fun emptyBackupJson(): Result<String> = try {
        val payload = JSONObject().apply {
            put("format", "plavio-backup"); put("version", 2)
            put("exportedAt", System.currentTimeMillis()); put("appVersion", BuildConfig.VERSION_NAME)
            put("coverage", "settings,addons,watchlist,favorites,plavioStatuses,playback,customLists; downloads excluded")
            put("settings", JSONObject())
            put("addons", JSONArray()); put("watchlist", JSONArray()); put("favorites", JSONArray())
            put("plavioStatuses", JSONArray()); put("playback", JSONArray())
            put("customLists", JSONArray()); put("customListItems", JSONArray())
        }.toString()
        Result.success(payload)
    } catch (e: Exception) { Result.failure(e) }

    private fun parseBackup(json: String): ParsedBackup {
        require(json.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "Backup exceeds the 10 MiB safety limit." }
        val root = JSONObject(json)
        require(root.opt("format") is String && root.getString("format") == "plavio-backup") { "Not a Plavio backup file." }
        val versionValue = root.opt("version")
        require(versionValue is Number) { "Backup version is missing or invalid." }
        val version = versionValue.toInt()
        require(version in 1..2 && versionValue.toDouble() == version.toDouble()) { "This backup version is not supported." }
        val settingsJson = if (root.has("settings")) root.get("settings") as? JSONObject
            ?: throw IllegalArgumentException("Backup settings must be an object.") else null
        require((settingsJson?.length() ?: 0) <= MAX_BACKUP_SETTINGS) { "Too many settings in backup." }
        val prefs = settingsJson?.let { obj ->
            buildMap {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next().also { require(it.length <= 120) }
                    if (isSecretPreference(key)) continue
                    val v = obj.get(key)
                    put(key, when (v) {
                        JSONObject.NULL -> null
                        is JSONArray -> {
                            require(v.length() <= 1_000)
                            (0 until v.length()).map { index -> v.get(index).also { require(it is String) } as String }.toSet()
                        }
                        is String -> v.also { require(it.length <= MAX_BACKUP_STRING) }
                        is Boolean, is Int, is Long, is Double -> v
                        else -> throw IllegalArgumentException("Invalid setting value for $key.")
                    })
                }
            }
        }
        fun section(name: String, max: Int = MAX_BACKUP_ROWS): List<JSONObject>? {
            if (!root.has(name)) return null
            val arr = root.get(name) as? JSONArray ?: throw IllegalArgumentException("Backup section '$name' must be an array.")
            require(arr.length() <= max) { "Too many rows in '$name'." }
            return (0 until arr.length()).map { arr.get(it) as? JSONObject
                ?: throw IllegalArgumentException("Invalid row in '$name'.") }
        }
        fun str(o: JSONObject, k: String, required: Boolean = true, max: Int = 4_096): String? {
            if (!o.has(k) || o.isNull(k)) { require(!required) { "Missing '$k'." }; return null }
            val v = o.get(k) as? String ?: throw IllegalArgumentException("Invalid '$k'.")
            require(v.length <= max && (!required || v.isNotBlank())) { "Invalid '$k'." }
            return v
        }
        fun optionalUrl(o: JSONObject, k: String): String? {
            val value = str(o, k, required = false, max = 8_192) ?: return null
            require(value.isBlank() || isHttpUrl(value)) { "Invalid URL in '$k'." }
            return value.takeIf { it.isNotBlank() }?.let(::safeBackupUrl)
        }
        fun num(o: JSONObject, k: String, default: Long? = null): Long {
            if (!o.has(k)) return default ?: throw IllegalArgumentException("Missing '$k'.")
            val value = o.get(k) as? Number ?: throw IllegalArgumentException("Invalid '$k'.")
            val n = value.toLong(); require(value.toDouble() == n.toDouble()) { "Invalid '$k'." }; return n
        }
        fun bool(o: JSONObject, k: String, default: Boolean): Boolean = if (!o.has(k)) default else
            (o.get(k) as? Boolean ?: throw IllegalArgumentException("Invalid '$k'."))
        fun array(name: String) = section(name)?.map { it }
        val addons = array("addons")?.map { o ->
            val id = str(o,"id",max=300)!!; val url = str(o,"baseUrl",max=8_192)!!
            require(isHttpUrl(url)) { "Addon URL must be an HTTP(S) URL." }
            val encryptedUrlRequired = bool(o, "encryptedUrlRequired", false)
            val importedUrl = if (encryptedUrlRequired) lockedAddonUrlPlaceholder(url) else safeBackupUrl(url)
            InstalledAddon(id, str(o,"name",max=512)!!, str(o,"version",false,128) ?: "",
                str(o,"description",false,4_096) ?: "", importedUrl, str(o,"types",false,1_000) ?: "",
                str(o,"resources",false,1_000) ?: "catalog,meta,stream", bool(o,"preinstalled",false),
                bool(o,"enabled",true) && !encryptedUrlRequired, bool(o,"configurable",false), bool(o,"showOnHome",true),
                str(o,"logoUrl",false,8_192)?.let(::safeAddonAuxUrl) ?: "", num(o,"sortOrder",0).toInt(),
                bool(o,"starred",false), num(o,"addedAt",0))
        }?.also { require(it.map(InstalledAddon::id).distinct().size == it.size) { "Duplicate addon ids." } }
        val watch = array("watchlist")?.map { o -> WatchlistItem(str(o,"key",max=1_024)!!,
            str(o,"addonId",false,300) ?: "", str(o,"type",false,80) ?: "", str(o,"metaId",false,1_024) ?: "",
            str(o,"name",false,512) ?: "", optionalUrl(o,"poster"), num(o,"addedAt",0),
            optionalUrl(o,"logo")) }
            ?.also { require(it.map(WatchlistItem::key).distinct().size == it.size) { "Duplicate watchlist keys." } }
        // Favorites + Plavio statuses (v0.14.10): absent in older
        // payloads — array() returns null and the restore then leaves
        // those stores exactly as they are (nothing carried, nothing
        // invented), so old backups restore cleanly.
        val favs = array("favorites")?.map { o -> FavoriteItem(str(o,"key",max=1_024)!!,
            str(o,"addonId",false,300) ?: "", str(o,"type",false,80) ?: "", str(o,"metaId",false,1_024) ?: "",
            str(o,"name",false,512) ?: "", optionalUrl(o,"poster"), num(o,"addedAt",0),
            optionalUrl(o,"logo")) }
            ?.also { require(it.map(FavoriteItem::key).distinct().size == it.size) { "Duplicate favorite keys." } }
        val plavioStatuses = array("plavioStatuses")?.map { o ->
            val status = str(o,"status",max=40)!!
            require(status in PlavioStatuses.ALL) { "Invalid Plavio status '$status'." }
            TitleStatusItem(str(o,"key",max=1_024)!!,
                str(o,"addonId",false,300) ?: "", str(o,"type",false,80) ?: "", str(o,"metaId",false,1_024) ?: "",
                str(o,"name",false,512) ?: "", optionalUrl(o,"poster"), status, num(o,"updatedAt",0),
                optionalUrl(o,"logo")) }
            ?.also { require(it.map(TitleStatusItem::key).distinct().size == it.size) { "Duplicate Plavio status keys." } }
        val play = array("playback")?.map { o ->
            // A non-http stream URL (magnet:/relative rows ride in from
            // debrid plays) must never fail the WHOLE restore — the row
            // imports with its link blanked: progress, title and identity
            // survive, and resume re-resolves the stream (owner's
            // screenshot 2026-10-31: one such row killed his restore
            // with a raw "Invalid playback URL." on the Account screen).
            val rawUrl = str(o,"streamUrl",false,8_192) ?: ""
            val url = if (rawUrl.isBlank() || isHttpUrl(rawUrl)) rawUrl else ""
            PlaybackState(str(o,"key",max=1_024)!!, str(o,"title",false,512) ?: "",
                optionalUrl(o,"poster"), str(o,"videoId",false,1_024) ?: "",
                safeBackupUrl(url), num(o,"positionMs",0), num(o,"durationMs",0),
                str(o,"imdbId",false,256), num(o,"season",0).toInt(), num(o,"episode",0).toInt(),
                str(o,"seriesName",false,512), str(o,"episodeTitle",false,512), str(o,"metaId",false,1_024),
                str(o,"streamAddonId",false,300), str(o,"streamName",false,512),
                str(o,"streamTitle",false,1_024), str(o,"streamQuality",false,64),
                optionalUrl(o,"logo"),
                num(o,"updatedAt",0),
                episodeIdsJson = str(o,"episodeIdsJson",false,65_536),
                remoteProgressPct = if (o.has("remoteProgressPct") && !o.isNull("remoteProgressPct")) {
                    o.optInt("remoteProgressPct")
                } else null,
                importSource = str(o,"importSource",false,32))
        }?.also {
            require(it.map(PlaybackState::key).distinct().size == it.size) { "Duplicate playback keys." }
            require(it.all { row -> row.positionMs >= 0 && row.durationMs >= 0 }) { "Invalid playback position." }
        }
        val lists = array("customLists")?.map { o -> CustomList(str(o,"id",max=300)!!,
            str(o,"name",max=256)!!, num(o,"createdAt",0)) }
            ?.also { require(it.map(CustomList::id).distinct().size == it.size) { "Duplicate custom list ids." } }
        val listItems = array("customListItems")?.map { o -> CustomListItem(str(o,"listId",max=300)!!,
            str(o,"itemKey",max=1_024)!!, str(o,"addonId",false,300) ?: "", str(o,"type",false,80) ?: "",
            str(o,"metaId",false,1_024) ?: "", str(o,"name",false,512) ?: "",
            optionalUrl(o,"poster"), num(o,"addedAt",0), optionalUrl(o,"logo")) }
            ?.also { require(it.map { row -> row.listId to row.itemKey }.distinct().size == it.size) { "Duplicate custom-list items." } }
        if (version >= 2) require(lists != null && listItems != null) { "Version 2 backup is missing custom-list data." }
        if (listItems != null && lists != null) require(listItems.all { item -> lists.any { it.id == item.listId } }) { "A custom-list item references a missing list." }
        for (name in listOf("addons","watchlist","playback","customLists","customListItems")) if (root.has(name)) section(name)
        // Parse API keys (simple sync, user's order)
        val apiKeys: Map<String, String>? = if (root.has("api_keys")) {
            val obj = root.get("api_keys") as? JSONObject ?: throw IllegalArgumentException("Backup api_keys must be an object.")
            buildMap<String, String> {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k: String = keys.next()
                    val v = obj.optString(k, "")
                    if (v.isNotBlank()) put(k, v)
                }
            }
        } else null
        val profilePhoto = if (root.has("profilePhoto")) {
            val v = root.get("profilePhoto") as? String
                ?: throw IllegalArgumentException("Invalid 'profilePhoto'.")
            require(v.length <= 4_000_000) { "Profile photo in backup is too large." }
            v
        } else null
        // Raw configured addon URLs (account sync only): absent in local
        // file backups and older payloads → null → restore leaves the
        // redacted addons-section result exactly as it is.
        val addonUrls: Map<String, PortableAddonUrlConfig>? = if (root.has("addonUrls")) {
            val obj = root.get("addonUrls") as? JSONObject
                ?: throw IllegalArgumentException("Backup addonUrls must be an object.")
            require(obj.length() <= MAX_PORTABLE_ADDON_URLS) { "Too many addon URLs in backup." }
            buildMap {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val id = keys.next()
                    require(id.isNotBlank() && id.length <= 300) { "Invalid addon id in addonUrls." }
                    val entry = obj.get(id) as? JSONObject
                        ?: throw IllegalArgumentException("Invalid addonUrls entry.")
                    val url = entry.optString("baseUrl")
                    require(url.isNotBlank() && url.length <= MAX_ADDON_URL_LENGTH && isHttpUrl(url)) {
                        "Invalid addon URL in addonUrls."
                    }
                    put(id, PortableAddonUrlConfig(url, entry.optBoolean("enabled", true)))
                }
            }
        } else null
        return ParsedBackup(version, prefs, addons, watch, play, lists, listItems, apiKeys, profilePhoto,
            favorites = favs, plavioStatuses = plavioStatuses, addonUrls = addonUrls)
    }

    private fun isSecretPreference(key: String): Boolean {
        val k = key.lowercase()
        return k in setOf("simkl_token", "torbox_api_key", "realdebrid_api_key", "trakt_access_token", "trakt_refresh_token") ||
            listOf("token", "api_key", "apikey", "password", "secret", "auth").any { it in k } ||
            k.startsWith("plavio_privacy")
    }

    private fun isHttpUrl(value: String): Boolean = runCatching {
        val uri = java.net.URI(value)
        (uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun isLockedAddonUrlPlaceholder(value: String): Boolean = runCatching {
        val uri = java.net.URI(value)
        uri.path == LOCKED_ADDON_URL_PLACEHOLDER_PATH && uri.userInfo == null &&
            uri.rawQuery == null && uri.rawFragment == null && isHttpUrl(value)
    }.getOrDefault(false)

    private fun isConfiguredAddonUrl(value: String): Boolean = value.isNotBlank() &&
        !isLockedAddonUrlPlaceholder(value)

    /** A URL may contain secrets in any component, so only ordinary public roots are retained. */
    private fun addonNeedsEncryptedUrl(value: String): Boolean {
        if (isLockedAddonUrlPlaceholder(value)) return true
        return runCatching {
            val uri = java.net.URI(value)
            !isHttpUrl(value) || uri.userInfo != null || uri.rawQuery != null ||
                uri.rawFragment != null || uri.path.orEmpty().isNotEmpty() && uri.path != "/"
        }.getOrDefault(true)
    }

    private fun addonOrigin(value: String): String? = runCatching {
        val uri = java.net.URI(value)
        if (!isHttpUrl(value)) null
        else java.net.URI(uri.scheme, null, uri.host, uri.port, null, null, null).toASCIIString()
    }.getOrNull()

    /** Plaintext addon metadata may retain only a credential-free public root or the origin. */
    private fun safeAddonBackupUrl(value: String): String {
        if (!addonNeedsEncryptedUrl(value)) return value.take(MAX_ADDON_URL_LENGTH)
        return addonOrigin(value) ?: "https://invalid.invalid"
    }

    /** Logo URLs can be signed or derived from addon config; do not export non-root components. */
    private fun safeAddonAuxUrl(value: String): String {
        if (value.isBlank()) return ""
        return runCatching {
            val uri = java.net.URI(value)
            if (!isHttpUrl(value)) ""
            else if (uri.userInfo == null && uri.rawQuery == null && uri.rawFragment == null &&
                (uri.path.isNullOrEmpty() || uri.path == "/")) value.take(MAX_ADDON_URL_LENGTH)
            else addonOrigin(value).orEmpty()
        }.getOrDefault("")
    }

    /** Marked URLs always become a durable, non-working placeholder until private restore succeeds. */
    private fun lockedAddonUrlPlaceholder(value: String): String {
        val origin = addonOrigin(value) ?: throw IllegalArgumentException("Invalid addon URL placeholder.")
        return origin + LOCKED_ADDON_URL_PLACEHOLDER_PATH
    }

    /** Sanitize URL-bearing portable settings (notably newline-delimited M3U endpoints). */
    private fun safeBackupSetting(key: String, value: String): String {
        if (key.equals("m3u_playlists", ignoreCase = true)) {
            return value.lineSequence().joinToString("\n") { line ->
                if (isHttpUrl(line)) safeBackupUrl(line) else line.take(MAX_BACKUP_STRING)
            }
        }
        return value.take(MAX_BACKUP_STRING)
    }

    /** Remove URL credentials from local exports while keeping the configured endpoint and safe options. */
    private fun safeBackupUrl(value: String): String {
        if (!isHttpUrl(value)) return value.take(8_192)
        return try {
            val uri = java.net.URI(value)
            val safeQuery = uri.rawQuery?.split('&')?.filterNot { component ->
                val key = component.substringBefore('=').lowercase()
                listOf("token", "key", "secret", "password", "auth", "credential",
                    "signature", "sig", "jwt", "access", "refresh", "session", "code").any { it in key }
            }?.joinToString("&")
            java.net.URI(uri.scheme, null, uri.host, uri.port, uri.path, safeQuery, null).toASCIIString()
        } catch (_: Exception) { value.take(8_192) }
    }


}

/**
 * Episode-list persistence for Continue Watching rows (DB v16,
 * notes item 16): the player saves the playing series' episode
 * list with the playback row so a later resume rebuilds the full
 * player context — Episodes button, episode titles and
 * autoplay-next — with NO meta fetch. Compact JSON:
 * [{"i":videoId,"s":season,"e":episode,"t":title}].
 */
fun encodeEpisodeIds(videos: List<Video>): String? {
    if (videos.isEmpty()) return null
    val arr = org.json.JSONArray()
    for (v in videos) {
        arr.put(org.json.JSONObject().apply {
            put("i", v.id)
            put("s", v.season)
            put("e", v.episode)
            put("t", v.title)
        })
    }
    return arr.toString()
}

/** Inverse of [encodeEpisodeIds]; malformed input degrades to an empty list. */
fun decodeEpisodeIds(json: String?): List<Video> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = org.json.JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("i").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            Video(
                id = id,
                title = o.optString("t"),
                season = o.optInt("s"),
                episode = o.optInt("e")
            )
        }
    }.getOrDefault(emptyList())
}

/**
 * Series identity of a Continue Watching row (v0.14.15, owner's
 * rule: ONE CW card per movie or series). Episodic rows group by
 * the series id — the IMDb id when known, else the episode video
 * id's series prefix ("tt…:S:E"), else the series meta id. Null
 * for movies and for rows with no series signal, so those never
 * collapse into each other. Shared by the repository's CW dedupe
 * and the home-screen CW widget.
 */
internal fun seriesKeyForPlayback(state: PlaybackState): String? {
    if (state.season <= 0 && state.episode <= 0) return null
    val seriesId = state.imdbId?.takeIf { it.isNotBlank() }
        ?: state.videoId.substringBefore(":")
            .takeIf { it.isNotBlank() && it != state.videoId }
        ?: state.metaId?.takeIf { it.isNotBlank() }
        ?: return null
    return "series|$seriesId"
}
