package com.pulsestream.app.ui.screens

import androidx.compose.material3.OutlinedButton
import com.pulsestream.app.ui.components.OrbitDots
import com.pulsestream.app.ui.components.ProfileAvatarImage
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessHigh
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.material3.SwitchColors
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsestream.app.BuildConfig
import com.pulsestream.app.R
import com.pulsestream.app.data.StreamRepository
import com.pulsestream.app.data.cloud.PlavioAccountManager
import com.pulsestream.app.data.simkl.SimklApi
import com.pulsestream.app.data.update.UpdateChecker
import com.pulsestream.app.data.update.UpdateInfo
import com.pulsestream.app.ui.components.GlassCard
import com.pulsestream.app.ui.components.liquidGlass
import com.pulsestream.app.ui.components.UpdatePrompt
import com.pulsestream.app.ui.components.GlowBackground
import com.pulsestream.app.ui.theme.AppTheme
import com.pulsestream.app.ui.theme.LocalPalette
import com.pulsestream.app.ui.theme.LocalSpacingScale
import com.pulsestream.app.ui.theme.AccentTheme
import com.pulsestream.app.ui.theme.GlassBorder
import com.pulsestream.app.ui.theme.GlassWhite
import com.pulsestream.app.ui.theme.TextPrimary
import com.pulsestream.app.ui.theme.TextSecondary
import com.pulsestream.app.ui.tv.tvFocusRing
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repository: StreamRepository,
    onThemeChanged: () -> Unit = {},
    onGoToAddons: () -> Unit = {},
    onGoToPlayback: () -> Unit = {},
    onGoToSubtitles: () -> Unit = {},
    onGoToAppearance: () -> Unit = {},
    onGoToStreams: () -> Unit = {},
    onGoToAbout: () -> Unit = {},
    onGoToFeedback: () -> Unit = {},
    onGoToAccount: () -> Unit = {},
    onGoToIntegrations: () -> Unit = {},
    onGoToDownloads: () -> Unit = {},
    onGoToNotifications: () -> Unit = {},
    onGoToHomeSwitch: () -> Unit = {}
) {
    val settings = repository.settings
    val context = LocalContext.current

    var telemetryEnabled by remember { mutableStateOf(com.pulsestream.app.data.AppStats.enabled(context)) }
    var sentryEnabled by remember { mutableStateOf(repository.settings.sentryEnabled) }
    var cwArtworkPoster by remember { mutableStateOf(settings.cwArtworkPoster) }
    // Folded root cards (v0.14.14 restructure): Playback & Subs,
    // Appearance and Help & About show their rows only when opened.
    var playbackExpanded by rememberSaveable { mutableStateOf(false) }
    var appearanceExpanded by rememberSaveable { mutableStateOf(false) }
    var helpExpanded by rememberSaveable { mutableStateOf(false) }
    // Addons & Integrations (v0.14.27, batch N3+N4): the root row
    // opens the stable BOTTOM POPUP CARD again — not the v0.14.26
    // full hub page (removed). The card holds the 3 options; only
    // Manage addons / Integrations leave the card, for their pages.
    var addonsHubSheetOpen by remember { mutableStateOf(false) }

    // ---- Sample F (v0.12.4): searchable compact root screen ----
    // The account card reads the same sync manager the Account screen
    // uses; this screen is recreated on every visit, so the values are
    // fresh each time it opens.
    var settingsQuery by rememberSaveable { mutableStateOf("") }
    // Plavio account: since v0.14.6 it is the ONLY sign-in (Google +
    // Drive sync removed), so the card reads only this state.
    val plavioManager = remember { PlavioAccountManager(context, repository) }
    val plavioEmail = remember {
        if (PlavioAccountManager.isConfigured() && plavioManager.isSignedIn()) {
            plavioManager.accountEmail()
        } else {
            null
        }
    }
    val plavioLastSync = remember(plavioEmail) {
        if (plavioEmail != null) plavioManager.lastSyncTime() else null
    }
    val anySignedIn = plavioEmail != null
    // The ACCOUNT username wins over every other name (owner's report
    // 2026-10-31: he set his username and the card still showed the
    // email-derived "Najam Nns"). Then the device profile name, then
    // the email-derived name (owner's order 2026-10-22).
    val plavioUsername = remember(plavioEmail) {
        if (plavioEmail != null) plavioManager.accountUsername() else null
    }
    val profileUserName = remember { settings.profileUserName }
    val displayName = remember(profileUserName, plavioEmail, plavioUsername) {
        plavioUsername?.let { "@$it" }
            ?: profileUserName.takeIf { it.isNotBlank() }
            ?: plavioEmail?.let { deriveDisplayName(it) }
    }
    val installedAddons by repository.addons.collectAsState(initial = emptyList())
    val enabledAddons = remember(installedAddons) { installedAddons.count { it.enabled } }
    val reducedMotion by com.pulsestream.app.data.MotionPreferences.reduced.collectAsState()

    val sectionAccount = stringResource(R.string.settings_section_account)
    val sectionPlayback = stringResource(R.string.settings_section_playback)
    val sectionContent = stringResource(R.string.settings_section_content)
    val sectionAppearance = stringResource(R.string.settings_section_appearance)
    val sectionHelp = "Help & About"

    // Every root entry as data, so the search field filters the very
    // rows the sections render. Destinations and behaviour are exactly
    // the pre-restructure ones — presentation only. The old Account nav
    // row is gone: the account card above the list IS the account entry.
    // v0.14.26 (batch item 2): the ACCOUNT-section Integrations
    // entry is GONE — Integrations lives only inside Addons &
    // Integrations (the GENERAL row below), per the owner's
    // one-setting-one-home rule. It is also out of this search
    // index's entries, so Settings search cannot surface it twice.
    val entries = listOf(
        SettingsEntry(sectionPlayback, stringResource(R.string.settings_playback_title),
            "playback autoplay next episode screen skip intro audio resume buffer") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.PlayArrow,
                    title = stringResource(R.string.settings_playback_title),
                    subtitle = stringResource(R.string.settings_playback_sub),
                    onClick = onGoToPlayback,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionPlayback, stringResource(R.string.settings_streams_title),
            "streams sources source limits quality order autoplay rule providers") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.VideoLibrary,
                    title = stringResource(R.string.settings_streams_title),
                    subtitle = stringResource(R.string.settings_streams_sub),
                    onClick = onGoToStreams,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionPlayback, stringResource(R.string.settings_subtitles_title),
            "subtitles captions preferred languages appearance font size") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.ClosedCaption,
                    title = stringResource(R.string.settings_subtitles_title),
                    subtitle = stringResource(R.string.settings_subtitles_sub),
                    onClick = onGoToSubtitles,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionContent, "Downloads",
            "downloads offline files storage downloaded movies shows") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.Download,
                    title = "Downloads",
                    subtitle = "Movies and shows saved on this device",
                    onClick = onGoToDownloads,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionContent, stringResource(R.string.settings_addons_title),
            "addons manage extensions install sources manifest") {
            SettingsStaticRow(
                icon = Icons.Filled.Extension,
                title = stringResource(R.string.settings_addons_title),
                subtitle = stringResource(
                    R.string.settings_addons_sub,
                    installedAddons.size,
                    enabledAddons
                ),
                trailing = {
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = "Open addons",
                        tint = TextSecondary
                    )
                },
                onClick = onGoToAddons,
                compact = true
            )
        },
        SettingsEntry(sectionAppearance, stringResource(R.string.settings_appearance_title),
            "appearance accent color amoled black theme dark light") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.Contrast,
                    title = stringResource(R.string.settings_appearance_title),
                    subtitle = stringResource(R.string.settings_appearance_sub),
                    onClick = onGoToAppearance,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionAppearance, "Reduced motion",
            "reduced motion animations accessibility pause hero slides pulses") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsToggleRow(
                    icon = Icons.Filled.Contrast,
                    title = "Reduced motion",
                    subtitle = "Calm the app: fewer slides and pulses",
                    checked = reducedMotion,
                    onCheckedChange = { com.pulsestream.app.data.MotionPreferences.setReduced(context, it) },
                    compact = true
                )
            }
        },
        SettingsEntry(sectionAppearance, "Continue Watching posters",
            "continue watching poster scene artwork still home tile") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsToggleRow(
                    icon = Icons.Filled.VideoLibrary,
                    title = "Continue Watching posters",
                    subtitle = "Use the poster, not a scene still, on Continue Watching tiles",
                    checked = cwArtworkPoster,
                    onCheckedChange = {
                        settings.cwArtworkPoster = it
                        cwArtworkPoster = it
                    },
                    compact = true
                )
            }
        },
        SettingsEntry("Notifications", "Notifications",
            "notifications alerts new episode movies updates downloads permission bell") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.Notifications,
                    title = "Notifications",
                    subtitle = "New episodes, movies, updates and downloads",
                    onClick = onGoToNotifications,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionHelp, "Anonymous usage counting",
            "anonymous counting installs online users privacy usage data own server") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsToggleRow(
                    icon = Icons.Filled.Info,
                    title = "Usage counting",
                    subtitle = "Count installs and active users — a random ID only, no personal data",
                    checked = telemetryEnabled,
                    onCheckedChange = {
                        com.pulsestream.app.data.AppStats.setEnabled(context, it)
                        telemetryEnabled = it
                    },
                    compact = true
                )
            }
        },
        SettingsEntry(sectionHelp, "Sentry Crash Report",
            "crash reports sentry bugs errors anonymous fix") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsToggleRow(
                    icon = Icons.Filled.BugReport,
                    title = "Crash reports",
                    subtitle = "Send an anonymous report when the app crashes, so bugs get fixed",
                    checked = sentryEnabled,
                    onCheckedChange = {
                        settings.sentryEnabled = it
                        com.pulsestream.app.data.CrashReports.apply(context, it)
                        sentryEnabled = it
                    },
                    compact = true
                )
            }
        },
        SettingsEntry(sectionHelp, stringResource(R.string.settings_feedback_title),
            "feedback send bug report feature request support") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.Feedback,
                    title = stringResource(R.string.settings_feedback_title),
                    subtitle = stringResource(R.string.settings_feedback_sub),
                    onClick = onGoToFeedback,
                    compact = true
                )
            }
        },
        SettingsEntry(sectionHelp, stringResource(R.string.settings_about_title),
            "about version website updates app info check") {
            CompositionLocalProvider(LocalSettingsGrouped provides true) {
                SettingsNavRow(
                    icon = Icons.Filled.Info,
                    title = stringResource(R.string.settings_about_title),
                    subtitle = stringResource(R.string.settings_about_sub),
                    onClick = onGoToAbout,
                    compact = true
                )
            }
        }
    )
    val normalizedQuery = settingsQuery.trim().lowercase()
    val visibleEntries = if (normalizedQuery.isEmpty()) entries
        else entries.filter { entry ->
            entry.title.lowercase().contains(normalizedQuery) ||
                entry.searchText.contains(normalizedQuery)
        }
    // Folded-card row sets for the v0.14.14 root (search ignores the
    // folding and filters the same entries flat, as before).
    val playbackEntries = entries.filter { it.section == sectionPlayback }
    val appearanceEntries = entries.filter { it.section == sectionAppearance }
    val helpEntries = entries.filter { it.section == sectionHelp }

    GlowBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            // Bottom padding ensures the floating nav capsule never covers the last card,
            // including on smaller phones (capsule ~80dp + system nav ~32dp + margin)
            contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 8.dp, top = 16.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }


            // ---- Settings search — flat field, no capsule (item 11) ----
            item(key = "settings_search") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(50))
                ) {
                    OutlinedTextField(
                        value = settingsQuery,
                        onValueChange = { settingsQuery = it },
                        placeholder = { Text("Search settings", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Filled.Search, null, tint = TextSecondary) },
                        trailingIcon = if (settingsQuery.isNotEmpty()) {
                            {
                                IconButton(onClick = { settingsQuery = "" }) {
                                    Icon(Icons.Filled.Close, "Clear search", tint = TextSecondary)
                                }
                            }
                        } else null,
                        singleLine = true,
                        shape = RoundedCornerShape(50),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = LocalPalette.current.accent,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // ---- Account card (Sample F): signed-in Google account,
            // name + email only, plus sync status. This card IS the
            // account/backup entry — it opens the same Account screen
            // the old nav row did, with every backup/restore action
            // intact there. No product name for the sync feature is
            // shown anywhere in Settings (owner's order, v0.12.4).
            item(key = "account_header") {
                SettingsSectionHeader(sectionAccount)
            }
            item(key = "account_card") {
                // Flat account row (item 11): no card — the account
                // entry is a plain row under the ACCOUNT header,
                // exactly like every other Settings row.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onGoToAccount)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProfileAvatarImage(
                            avatarSetting = remember { settings.profileAvatar },
                            photoFile = remember { settings.profilePhotoFile() },
                            modifier = Modifier.size(44.dp),
                            placeholderLetter = if (anySignedIn) {
                                displayName?.firstOrNull()?.uppercase() ?: "P"
                            } else null
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (anySignedIn) (displayName ?: "Signed in") else "Not signed in",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                when {
                                    plavioEmail != null -> plavioEmail
                                    else -> "Tap to sign in and enable backup & sync"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                when {
                                    plavioEmail != null -> plavioLastSync?.let { "Synced · $it" }
                                        ?: "Plavio account · backup & sync on"
                                    else -> "Backup & sync off"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Icon(
                            Icons.Filled.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                }
            }

            // ---- Flat category layout (v0.14.24, items 2 + 11;
            // v0.14.26 item 2: ACCOUNT is the account card ONLY):
            // the root is a plain page divided only by category
            // headers — ACCOUNT (the account card above), GENERAL
            // (Addons & Integrations, Downloads), PLAYBACK
            // (playback, streams, subtitles), APPEARANCE,
            // NOTIFICATIONS, HELP & ABOUT — each row an icon tile,
            // a bold name and one plain line. No folded cards, no
            // capsules. While searching, the same entries render
            // flat below, exactly as before. ----
            if (normalizedQuery.isEmpty()) {
                item(key = "general_header") {
                    SettingsSectionHeader("General")
                }
                item(key = "flat_addons_integrations") {
                    CompositionLocalProvider(LocalSettingsGrouped provides true) {
                        SettingsNavRow(
                            icon = Icons.Filled.Extension,
                            title = "Addons & Integrations",
                            subtitle = "Addons, Home Switch and connected services",
                            onClick = { addonsHubSheetOpen = true },
                            compact = true
                        )
                    }
                }
                item(key = "flat_downloads") {
                    entries.first { it.title == "Downloads" }.content()
                }
                item(key = "playback_header") {
                    SettingsSectionHeader(sectionPlayback)
                }
                items(playbackEntries, key = { "flat_${it.title}" }) { entry ->
                    entry.content()
                }
                item(key = "appearance_header") {
                    SettingsSectionHeader(sectionAppearance)
                }
                items(appearanceEntries, key = { "flat_${it.title}" }) { entry ->
                    entry.content()
                }
                item(key = "notifications_header") {
                    SettingsSectionHeader("Notifications")
                }
                item(key = "flat_notifications") {
                    entries.first { it.title == "Notifications" }.content()
                }
                item(key = "help_header") {
                    SettingsSectionHeader(sectionHelp)
                }
                items(helpEntries, key = { "flat_${it.title}" }) { entry ->
                    entry.content()
                }
            } else {
                items(visibleEntries, key = { "entry_${it.title}" }) { entry ->
                    entry.content()
                }
                if (visibleEntries.isEmpty()) {
                    item(key = "no_settings_match") {
                        Text(
                            "No settings match \"${settingsQuery.trim()}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 32.dp, vertical = 24.dp)
                        )
                    }
                }
            }

            item(key = "credit") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 20.dp, bottom = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // The heart follows the picked accent (owner's
                    // order 2026-10-25) — a real icon, not the old
                    // fixed-green emoji, so it can be tinted.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Made with ",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = TextPrimary
                        )
                        Icon(
                            Icons.Filled.Favorite,
                            contentDescription = null,
                            tint = LocalPalette.current.accent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = " by Kotlinsyd",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = TextPrimary
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    SocialIconRow()
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    // The Addons & Integrations popup card (v0.14.27, batch N4):
    // a bottom sheet over Settings — the stable v0.14.22 shape.
    if (addonsHubSheetOpen) {
        AddonsHubSheet(
            repository = repository,
            installedCount = installedAddons.size,
            enabledCount = enabledAddons,
            onDismiss = { addonsHubSheetOpen = false },
            onGoToAddons = {
                addonsHubSheetOpen = false
                onGoToAddons()
            },
            onGoToIntegrations = {
                addonsHubSheetOpen = false
                onGoToIntegrations()
            },
            onGoToHomeSwitch = {
                addonsHubSheetOpen = false
                onGoToHomeSwitch()
            }
        )
    }
}

/**
 * Addons & Integrations BOTTOM POPUP CARD (v0.14.27, batch N3+N4 —
 * owner's orders 2026-11-07): the stable shape restored. The card
 * holds exactly the 3 options, in the owner's order — **Manage
 * addons → Home Switch → Integrations**. All three rows leave the
 * card for their pages (v0.14.29: Home Switch included — the
 * owner's fold order, restated 2026-11-09, supersedes the batch-N3
 * expand-in-place: tapping Home Switch opens its own page, and the
 * options exist only there).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddonsHubSheet(
    repository: StreamRepository,
    installedCount: Int,
    enabledCount: Int,
    onDismiss: () -> Unit,
    onGoToAddons: () -> Unit,
    onGoToIntegrations: () -> Unit,
    onGoToHomeSwitch: () -> Unit = {}
) {
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = androidx.compose.material3.rememberModalBottomSheetState(
            skipPartiallyExpanded = true
        ),
        containerColor = LocalPalette.current.background,
        dragHandle = { androidx.compose.material3.BottomSheetDefaults.DragHandle() }
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text(
                text = "Addons & Integrations",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            SettingsGroup(
                {
                    SettingsNavRow(
                        icon = Icons.Filled.Extension,
                        title = stringResource(R.string.settings_addons_title),
                        subtitle = stringResource(
                            R.string.settings_addons_sub,
                            installedCount,
                            enabledCount
                        ),
                        onClick = onGoToAddons
                    )
                }
            )
            Spacer(Modifier.height(12.dp))
            // Home Switch (v0.14.29): a folded NAV row — tapping it
            // dismisses this card and opens the dedicated Home
            // Switch page; the options live only there (owner's
            // fold order, restated 2026-11-07 and 2026-11-09 —
            // supersedes the batch-N3 expand-in-place).
            HomeSwitchSection(
                repository = repository,
                onNavigate = onGoToHomeSwitch
            )
            Spacer(Modifier.height(12.dp))
            SettingsGroup(
                {
                    SettingsNavRow(
                        icon = Icons.Filled.Link,
                        title = "Integrations",
                        subtitle = "Debrid services, tracking and API keys",
                        onClick = onGoToIntegrations
                    )
                }
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}

/**
 * A folded root Settings card (v0.14.14): header row (icon tile,
 * title, subtitle, expand chevron) in its own glass card; the
 * section's rows render inside the same card, flush with hairline
 * dividers, only while expanded.
 */
@Composable
private fun FoldedSettingsCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    rows: List<SettingsEntry>
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Spacer(Modifier.width(12.dp))
                Icon(
                    if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = TextSecondary
                )
            }
            if (expanded) {
                CompositionLocalProvider(LocalSettingsGrouped provides true) {
                    rows.forEachIndexed { index, entry ->
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(start = 74.dp, end = 16.dp)
                                .height(1.dp)
                                .background(TextSecondary.copy(alpha = 0.16f))
                        )
                        entry.content()
                    }
                }
            }
        }
    }
}

/** One root Settings entry for the Sample F searchable list (v0.12.4). */
private data class SettingsEntry(
    val section: String,
    val title: String,
    /** Extra lowercase keywords the settings search matches against. */
    val searchText: String,
    val content: @Composable () -> Unit
)

/**
 * Display name for the Settings account card, derived from the account
 * email's local part ("syed.najam" → "Syed Najam") — the sync layer
 * exposes only the email address, so the name is derived at display
 * time and never stored.
 */
private fun deriveDisplayName(email: String): String =
    email.substringBefore('@')
        .split('.', '_', '-', '+')
        .filter { it.isNotBlank() }
        .joinToString(" ") { part -> part.replaceFirstChar { c -> c.uppercase() } }
        .ifBlank { email }

/**
 * True while rendering inside a [SettingsGroup]: the shared settings
 * rows drop their own card and sit flush in the group card — the Onyx
 * settings structure (one card per section, hairline dividers between
 * rows), matching the owner's reference screenshots (2026-10-25).
 */
val LocalSettingsGrouped = compositionLocalOf { false }

/**
 * One grouped settings card: rows stacked in a single flat-ish glass
 * card with hairline dividers between them (inset to the text column).
 */
@Composable
fun SettingsGroup(vararg rows: @Composable () -> Unit) {
    // Flat category style (v0.14.24, item 11): no card, no capsule —
    // the rows sit plainly on the page with hairline dividers,
    // under their category header. Every settings sub-screen groups
    // through here, so the whole Settings area shares the style.
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        CompositionLocalProvider(LocalSettingsGrouped provides true) {
            rows.forEachIndexed { index, row ->
                if (index > 0) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 74.dp, end = 16.dp)
                            .height(1.dp)
                            .background(TextSecondary.copy(alpha = 0.16f))
                    )
                }
                row()
            }
        }
    }
}

/** Switch colours: Onyx gets the reference look (white track, black thumb). */
@Composable
fun settingsSwitchColors(): SwitchColors =
    if (LocalPalette.current.appTheme == AppTheme.ONYX) {
        // The accent drives the small things (owner's order 2026-10-25):
        // the ON switch wears the chosen accent, thumb contrasts it.
        val onyxAccent = LocalPalette.current.accent
        SwitchDefaults.colors(
            checkedThumbColor = if (onyxAccent == Color.White) Color.Black else Color.White,
            checkedTrackColor = onyxAccent,
            uncheckedThumbColor = Color(0xFF8E8E93),
            uncheckedTrackColor = Color(0xFF2E2E30),
            checkedBorderColor = Color.Transparent,
            uncheckedBorderColor = Color.Transparent
        )
    } else {
        SwitchDefaults.colors(
            checkedThumbColor = LocalPalette.current.accent,
            checkedTrackColor = LocalPalette.current.accent.copy(alpha = 0.35f)
        )
    }

/** Small-caps section header, Pulse style. */
@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        ),
        color = TextSecondary,
        modifier = Modifier.padding(start = 20.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)
    )
}

/** Leading icon in a rounded glass tile. */
@Composable
fun SettingsIconTile(icon: ImageVector, contentDescription: String?) {
    if (LocalPalette.current.appTheme == AppTheme.ONYX) {
        // Onyx: flat charcoal tile, white glyph (owner's reference).
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(Color(0xFF2E2E30), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    } else {
        Box(
            modifier = Modifier
                .size(44.dp)
                .liquidGlass(RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription, tint = LocalPalette.current.accent, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    compact: Boolean = false
) {
    if (LocalSettingsGrouped.current) {
        SettingsToggleRowGrouped(icon, title, subtitle, checked, onCheckedChange, compact)
        return
    }
    GlassCard(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp),
        onClick = { onCheckedChange(!checked) }
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = settingsSwitchColors()
            )
        }
    }
}

/** Navigation row: icon tile + title/subtitle + chevron, opens a sub-screen. */
@Composable
fun SettingsNavRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    compact: Boolean = false,
    // Optional state colour for the subtitle (v0.14.27, batch N6):
    // rows whose subtitle IS a state (e.g. a permission that is not
    // granted) can flag it red; every other caller keeps the plain
    // secondary colour by default.
    subtitleColor: Color = TextSecondary
) {
    if (LocalSettingsGrouped.current) {
        SettingsNavRowGrouped(icon, title, subtitle, onClick, compact, subtitleColor)
        return
    }
    GlassCard(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp),
        onClick = onClick
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = subtitleColor
                )
            }
            Spacer(Modifier.width(12.dp))
            Icon(
                Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}

/** Non-interactive row (used for "coming soon" placeholders). */
@Composable
fun SettingsStaticRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
    dimmed: Boolean = false,
    onClick: (() -> Unit)? = null,
    compact: Boolean = false
) {
    if (LocalSettingsGrouped.current) {
        SettingsStaticRowGrouped(icon, title, subtitle, trailing, dimmed, onClick, compact)
        return
    }
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = if (compact) 3.dp else 5.dp)
            .alpha(if (dimmed) 0.6f else 1f),
        onClick = onClick
    ) {
        Row(
            Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = (if (compact) 9.dp else 14.dp) * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(21.dp)
                )
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
private fun SettingsToggleRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    compact: Boolean
) {
    Box(Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            Switch(checked = checked, onCheckedChange = onCheckedChange, colors = settingsSwitchColors())
        }
    }
}

@Composable
private fun SettingsNavRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    compact: Boolean,
    subtitleColor: Color = TextSecondary
) {
    Box(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = subtitleColor)
            }
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

@Composable
private fun SettingsStaticRowGrouped(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit,
    dimmed: Boolean,
    onClick: (() -> Unit)?,
    compact: Boolean
) {
    Box(
        Modifier
            .fillMaxWidth()
            .alpha(if (dimmed) 0.6f else 1f)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp * LocalSpacingScale.current),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (compact) {
                Icon(icon, contentDescription = title, tint = LocalPalette.current.accent, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(12.dp))
            } else {
                SettingsIconTile(icon, title)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

/** Script font used for the "Najam Syyd" signature in About. */

@Composable
fun AboutCard() {
    val context = LocalContext.current
    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.mipmap.app_logo),
                contentDescription = "Plavio logo",
                modifier = Modifier.size(88.dp).clip(RoundedCornerShape(26.dp))
            )
            // Name + version text REMOVED (owner's order 2026-10-22):
            // the logo already says Plavio, and the updater card below
            // already shows the version — the pair only duplicated both.
            Spacer(Modifier.height(14.dp))
            Text(
                text = "A beautiful open-source streaming app with a built-in " +
                    "player. Add your favorite addons and enjoy your movies " +
                    "and shows in one glowing place.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable {
                        // Devices with no browser must not force-close.
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.plavio.site"))
                            )
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    Icons.Filled.Language,
                    contentDescription = null,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "plavio.site",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                    color = LocalPalette.current.accent,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.Link,
                    contentDescription = null,
                    tint = LocalPalette.current.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "Data: TMDB • Fanart.tv • MDBList • Cinemeta • OpenSubtitles • IntroDB",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** Settings > About > App Updater: auto-check toggle + manual update check. */
@Composable
fun AppUpdaterCard() {
    val appContext = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var updateInfo by remember { mutableStateOf<UpdateInfo?>(null) }

    GlassCard(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SettingsIconTile(Icons.Filled.SystemUpdate, "App updater")
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "App Updater",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "You're on v${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
            // The "Update available" auto-check toggle lives ONLY in
            // Settings → Notifications since v0.14.14 (owner's one-card
            // order) — this card keeps the version line and the manual
            // check button.
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    checking = true
                    status = null
                    scope.launch {
                        // Classified outcome: tell offline apart from
                        // up-to-date instead of "latest version" for all of it.
                        when (val result = UpdateChecker.checkNowDetailed(appContext)) {
                            is UpdateChecker.UpdateCheckResult.Update -> {
                                updateInfo = result.info
                            }
                            UpdateChecker.UpdateCheckResult.UpToDate -> {
                                status = "You're on the latest version."
                            }
                            UpdateChecker.UpdateCheckResult.Offline -> {
                                status = "Couldn't check — you're offline."
                            }
                            is UpdateChecker.UpdateCheckResult.Error -> {
                                status = "Couldn't check for updates: ${result.message}"
                            }
                        }
                        checking = false
                    }
                },
                enabled = !checking,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LocalPalette.current.accent.copy(alpha = 0.18f),
                    contentColor = LocalPalette.current.accent,
                    disabledContainerColor = LocalPalette.current.accent.copy(alpha = 0.08f)
                )
            ) {
                if (checking) {
                    OrbitDots(modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Checking…")
                } else {
                    Text("Check for update now")
                }
            }
            status?.let {
                Spacer(Modifier.height(8.dp))
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    UpdatePrompt(
        info = updateInfo,
        onDismiss = { updateInfo = null }
    )
}

/**
 * Icon-only social/community links, placed directly below the App Installs
 * counter. Icons only, no text labels (content descriptions for a11y).
 */
@Composable
private fun SocialIconRow() {
    val context = LocalContext.current
    val palette = LocalPalette.current
    val links = listOf(
        Triple(R.drawable.ic_discord, "Discord", "https://discord.gg/cwzHH3r9pa"),
        Triple(R.drawable.ic_github, "GitHub", "https://github.com/kotlinsyd/Plavio"),
        Triple(R.drawable.ic_gitlab, "GitLab", "https://gitlab.com/KotlinJS5/plavio"),
        Triple(R.drawable.ic_reddit, "Reddit", "https://www.reddit.com/r/Plavio/"),
    )
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        links.forEach { (iconRes, label, url) ->
            IconButton(
                onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                        )
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = palette.panel.copy(alpha = 0.7f),
                        shape = CircleShape
                    )
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = label,
                    // No tint — show icons in their native white for clean look
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
