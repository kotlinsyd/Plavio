package com.pulsestream.app.ui.screens

import com.pulsestream.app.data.MetaDetail

/**
 * The detail page's rating sources (v0.14.31, S2): each carries
 * the drawable of its brand mark — since v0.14.32 the OFFICIAL
 * brand artwork (Simple Icons paths; MDBList's own icon), bundled
 * in the APK, never hotlinked. The icon IS the name — the row
 * shows no written source names. [aspect] is the mark's natural
 * width ÷ height (from its own bounding box), used by the size
 * and fit rules below.
 */
internal enum class RatingSource(val iconRes: Int, val aspect: Float) {
    IMDB(com.pulsestream.app.R.drawable.ic_rating_imdb, 1f),
    TMDB(com.pulsestream.app.R.drawable.ic_rating_tmdb, 24f / 17.3f),
    TRAKT(com.pulsestream.app.R.drawable.ic_rating_trakt, 1f),
    RT(com.pulsestream.app.R.drawable.ic_rating_rt, 1f),
    METACRITIC(com.pulsestream.app.R.drawable.ic_rating_metacritic, 1f),
    RT_AUDIENCE(com.pulsestream.app.R.drawable.ic_rating_rt_audience, 1f),
    LETTERBOXD(com.pulsestream.app.R.drawable.ic_rating_letterboxd, 24f / 8.9f),
    MDBLIST(com.pulsestream.app.R.drawable.ic_rating_mdblist, 1f);

    /** True for the marks whose natural shape is wider than square. */
    val wide: Boolean get() = aspect > 1.01f
}

/** Icon height of the ratings row (v0.14.32: 18dp — 25% smaller
 *  than v0.14.31's 24dp; the owner locked this size). */
internal const val RATING_ICON_HEIGHT_DP = 18f

/** The widest any single rating icon may draw (the ~32dp wide
 *  slot of the locked spec); wider marks shrink to fit whole. */
internal const val RATING_ICON_MAX_WIDTH_DP = 32f

/** Smallest clear gap kept between neighbouring icons when the
 *  row decides how many slots fit (see [ratingFitCount]). */
internal const val RATING_ROW_MIN_GAP_DP = 16f

/**
 * The drawn size of one source's icon, in dp: height
 * [RATING_ICON_HEIGHT_DP] unless the mark's natural width at that
 * height would pass [RATING_ICON_MAX_WIDTH_DP] — then it shrinks
 * until the whole mark fits at its natural proportion. Nothing is
 * ever squeezed or clipped.
 */
internal fun RatingSource.iconSizeDp(): Pair<Float, Float> {
    val height = minOf(RATING_ICON_HEIGHT_DP, RATING_ICON_MAX_WIDTH_DP / aspect)
    return (height * aspect) to height
}

/**
 * The auto-fit rule (owner, v0.14.32): how many of [slots] (in
 * slot order) fit WHOLE in [availableWidthDp], each at its
 * natural width with at least [gapDp] of clear space between
 * neighbours. If five don't fit, four show; if four don't fit,
 * three — dropped from the END of the slot order. Returns 0 only
 * when not even one icon fits.
 */
internal fun ratingFitCount(
    slots: List<RatingSlot>,
    availableWidthDp: Float,
    gapDp: Float = RATING_ROW_MIN_GAP_DP
): Int {
    var used = 0f
    var count = 0
    for (slot in slots) {
        val width = slot.source.iconSizeDp().first
        val needed = if (count == 0) width else width + gapDp
        if (used + needed > availableWidthDp) break
        used += needed
        count++
    }
    return count
}

/** One filled slot of the ratings row: the source + the number as shown. */
internal data class RatingSlot(val source: RatingSource, val value: String)

/**
 * The locked slot rule (owner, v0.14.22; S2 keeps it): exactly
 * five slots, priority IMDb, TMDB, Trakt, RT, Metacritic; a
 * missing one lets the next in line slide in (RT Audience, then
 * Letterboxd, then MDBList). A rating the title doesn't have
 * simply has no slot — no placeholders. Values keep the formats
 * the row has always shown: TMDB's 0–10 vote renders on the
 * 0–100 scale, everything else as served (94, not 94%).
 */
internal fun ratingSlots(meta: MetaDetail): List<RatingSlot> = buildList {
    meta.imdbRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.IMDB, it)) }
    meta.tmdbRating?.takeIf { it.isNotBlank() }?.let { raw ->
        val scaled = raw.toDoubleOrNull()?.let { Math.round(it * 10).toString() } ?: raw
        add(RatingSlot(RatingSource.TMDB, scaled))
    }
    // MDBList per-source scores (v0.14.20): already on the
    // 0–100 scale, shown as served. Missing source, no slot.
    meta.traktRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.TRAKT, it)) }
    meta.rtRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.RT, it)) }
    meta.metacriticRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.METACRITIC, it)) }
    meta.rtAudienceRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.RT_AUDIENCE, it)) }
    meta.letterboxdRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.LETTERBOXD, it)) }
    meta.mdblistRating?.takeIf { it.isNotBlank() }
        ?.let { add(RatingSlot(RatingSource.MDBLIST, it)) }
}.take(5)
