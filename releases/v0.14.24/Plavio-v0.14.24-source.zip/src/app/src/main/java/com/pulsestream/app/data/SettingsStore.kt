@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.pulsestream.app.data

import android.content.Context
import org.json.JSONArray
import kotlin.math.roundToInt
import java.io.File
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import androidx.media3.ui.AspectRatioFrameLayout
import com.pulsestream.app.ui.theme.AccentTheme

/** Aspect-ratio modes offered by the in-player screen-size button. */
val ASPECT_MODES: List<Pair<Int, String>> = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
    AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill",
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
)

/**
 * Curated subtitle language options offered in the picker
 * (ISO 639-1 code to display name), sorted alphabetically.
 */
val SUBTITLE_LANGUAGE_OPTIONS: List<Pair<String, String>> = listOf(
    "en" to "English",
    "ar" to "Arabic",
    "bn" to "Bengali",
    "bs" to "Bosnian",
    "bg" to "Bulgarian",
    "zh" to "Chinese",
    "hr" to "Croatian",
    "cs" to "Czech",
    "da" to "Danish",
    "nl" to "Dutch",
    "fi" to "Finnish",
    "fr" to "French",
    "de" to "German",
    "el" to "Greek",
    "gu" to "Gujarati",
    "he" to "Hebrew",
    "hi" to "Hindi",
    "hu" to "Hungarian",
    "id" to "Indonesian",
    "it" to "Italian",
    "ja" to "Japanese",
    "ko" to "Korean",
    "ms" to "Malay",
    "mr" to "Marathi",
    "no" to "Norwegian",
    "fa" to "Persian",
    "pl" to "Polish",
    "pt" to "Portuguese",
    "pa" to "Punjabi",
    "ro" to "Romanian",
    "ru" to "Russian",
    "sr" to "Serbian",
    "sk" to "Slovak",
    "sl" to "Slovenian",
    "es" to "Spanish",
    "sv" to "Swedish",
    "ta" to "Tamil",
    "te" to "Telugu",
    "th" to "Thai",
    "tr" to "Turkish",
    "uk" to "Ukrainian",
    "ur" to "Urdu",
    "vi" to "Vietnamese"
).sortedBy { it.second }

/** Display name for a preferred-language code, or the code itself. */
fun subtitleLanguageName(code: String): String =
    SUBTITLE_LANGUAGE_OPTIONS.find { it.first == code }?.second ?: code.uppercase()

/**
 * Audio language options: the same curated ISO 639-1 set as subtitles
 * (an audio track's language tag usually matches these codes).
 */
val AUDIO_LANGUAGE_OPTIONS: List<Pair<String, String>> = SUBTITLE_LANGUAGE_OPTIONS

/** Display name for a preferred audio-language code, or the code itself. */
fun audioLanguageName(code: String): String =
    AUDIO_LANGUAGE_OPTIONS.find { it.first == code }?.second ?: code.uppercase()

/**
 * Subtitle text-color choices (ARGB) offered in Settings > Subtitles.
 * Widened (v0.14.14) to the player's Style-rail set of 10 so Settings
 * and the rail offer the exact same colours over the same stored value.
 */
val SUBTITLE_COLOR_OPTIONS: List<Pair<Int, String>> = listOf(
    0xFFFFFFFF.toInt() to "White",
    0xFFFFD700.toInt() to "Gold",
    0xFF00E5FF.toInt() to "Cyan",
    0xFFFF5C5C.toInt() to "Red",
    0xFF00FF88.toInt() to "Mint",
    0xFF9B59B6.toInt() to "Purple",
    0xFFF97316.toInt() to "Orange",
    0xFF22C55E.toInt() to "Green",
    0xFF3B82F6.toInt() to "Blue",
    0xFF000000.toInt() to "Black"
)

/** Names for colours from the pre-v0.14.14 7-colour set, so a stored
 *  colour from an older build still gets a friendly summary name. */
private val SUBTITLE_COLOR_LEGACY_NAMES: Map<Int, String> = mapOf(
    0xFFFFFF00.toInt() to "Yellow",
    0xFF00FFFF.toInt() to "Cyan",
    0xFF00FF00.toInt() to "Green",
    0xFFFF69B4.toInt() to "Pink",
    0xFFFFA500.toInt() to "Orange",
    0xFFFF0000.toInt() to "Red"
)

/** Subtitle outline/edge colour choices (the player's rail set of 4). */
val SUBTITLE_EDGE_COLOR_OPTIONS: List<Pair<Int, String>> = listOf(
    0xFF000000.toInt() to "Black",
    0xFFFFFFFF.toInt() to "White",
    0xFF00E5FF.toInt() to "Cyan",
    0xFFFF5C5C.toInt() to "Red"
)

/** "Subtitles by default" modes (stored by SettingsStore.subtitleDefaultMode). */
const val SUB_DEFAULT_ON_IN_MY_LANGUAGES = 0
const val SUB_DEFAULT_ALWAYS_ON = 1
const val SUB_DEFAULT_OFF = 2

fun subtitleDefaultModeName(mode: Int): String = when (mode) {
    SUB_DEFAULT_ALWAYS_ON -> "Always on"
    SUB_DEFAULT_OFF -> "Off"
    else -> "On in my languages"
}

/** Subtitle font-family choices (label to stored index). System families
 *  only — CaptionStyleCompat takes a Typeface, and these always exist. */
val SUBTITLE_FONT_OPTIONS: List<Pair<Int, String>> = listOf(
    0 to "System",
    1 to "Sans",
    2 to "Serif",
    3 to "Mono"
)

fun subtitleFontName(index: Int): String =
    SUBTITLE_FONT_OPTIONS.find { it.first == index }?.second ?: "System"

/** Subtitle background/shade choices (ARGB; includes semi-transparent). */
val SUBTITLE_BG_OPTIONS: List<Pair<Int, String>> = listOf(
    0x00000000 to "None",
    0xCC000000.toInt() to "Black",
    0xAA222222.toInt() to "Dark gray",
    0xAAFFFFFF.toInt() to "White",
    0xAA0000FF.toInt() to "Blue"
)

/** Subtitle text-size choices (label to scale factor). */
val SUBTITLE_SIZE_OPTIONS: List<Pair<Float, String>> = listOf(
    0.75f to "Small",
    1.0f to "Normal",
    1.3f to "Large",
    1.6f to "Extra large"
)

/** Subtitle edge/outline style choices (label to stored index). */
val SUBTITLE_EDGE_OPTIONS: List<Pair<Int, String>> = listOf(
    0 to "None",
    1 to "Outline",
    2 to "Drop shadow",
    3 to "Raised",
    4 to "Depressed"
)

fun subtitleColorName(color: Int): String =
    SUBTITLE_COLOR_OPTIONS.find { it.first == color }?.second
        ?: SUBTITLE_COLOR_LEGACY_NAMES[color]
        ?: "Custom"

fun subtitleEdgeColorName(color: Int): String =
    SUBTITLE_EDGE_COLOR_OPTIONS.find { it.first == color }?.second ?: "Custom"

fun subtitleBgName(color: Int): String =
    SUBTITLE_BG_OPTIONS.find { it.first == color }?.second ?: "Custom"

fun subtitleSizeName(scale: Float): String =
    SUBTITLE_SIZE_OPTIONS.find { it.first == scale }?.second ?: "${(scale * 100).toInt()}%"

fun subtitleEdgeName(index: Int): String =
    SUBTITLE_EDGE_OPTIONS.find { it.first == index }?.second ?: "Drop shadow"

/**
 * True if a subtitle/track language tag matches a preferred language code.
 * Handles ISO 639-1 vs 639-2/B differences ("en" vs "eng", "bs" vs "bos")
 * and OpenSubtitles quirks ("pob" = Brazilian Portuguese) via canonical
 * mapping — plus BCP-47 subtag matching ("en" matches "en-US"/"en_US").
 *
 * Matching is exact or at a subtag boundary only: "hi" must NOT match "hil".
 */
fun subtitleLangMatches(tag: String?, preferredCode: String): Boolean {
    val t = tag?.lowercase()?.trim().orEmpty()
    if (t.isEmpty()) return false
    val p = preferredCode.lowercase().trim()
    // ISO 639-2/B (and OpenSubtitles quirks) → canonical 639-1 primary subtag.
    fun canon(code: String): String {
        val parts = code.split('-', '_')
        val head = when (parts[0]) {
            "eng" -> "en"
            "spa" -> "es"
            "fre", "fra" -> "fr"
            "deu", "ger" -> "de"
            "ita" -> "it"
            "por", "pob" -> "pt"
            "rus" -> "ru"
            "ara" -> "ar"
            "hin" -> "hi"
            "urd" -> "ur"
            "tur" -> "tr"
            "zho", "chi" -> "zh"
            "jpn" -> "ja"
            "kor" -> "ko"
            "nld", "dut" -> "nl"
            "swe" -> "sv"
            "nor", "nob" -> "no"
            "dan" -> "da"
            "fin" -> "fi"
            "pol" -> "pl"
            "ces", "cze" -> "cs"
            "slk", "slo" -> "sk"
            "ron", "rum" -> "ro"
            "ell", "gre" -> "el"
            "heb" -> "he"
            "tha" -> "th"
            "vie" -> "vi"
            "ind" -> "id"
            "msa", "may" -> "ms"
            "tam" -> "ta"
            "tel" -> "te"
            "ben" -> "bn"
            "mar" -> "mr"
            "pan" -> "pa"
            "guj" -> "gu"
            "ukr" -> "uk"
            "hun" -> "hu"
            "srp", "scc" -> "sr"
            "hrv" -> "hr"
            "bos" -> "bs"
            "slv" -> "sl"
            "bul" -> "bg"
            "cat" -> "ca"
            else -> parts[0]
        }
        return (listOf(head) + parts.drop(1)).joinToString("-")
    }
    val normT = canon(t)
    val normP = canon(p)
    if (normT == normP) return true
    // Subtag-boundary prefix only — never a bare string prefix.
    fun startsSubtag(longer: String, shorter: String): Boolean =
        longer.length > shorter.length &&
            longer.startsWith(shorter) &&
            longer[shorter.length] == '-'
    return startsSubtag(normT, normP) || startsSubtag(normP, normT)
}

/** Quality buckets offered in Settings > Streams (canonical sort keys). */
val QUALITY_ORDER_OPTIONS: List<String> = listOf("2160p", "1080p", "720p", "480p")

/** Autoplay quality choices: "Auto" follows the quality order above. */
val AUTOPLAY_QUALITY_OPTIONS: List<String> = listOf("Auto") + QUALITY_ORDER_OPTIONS

/** Appearance option lists (v0.14.39, owner's A–H list). */
val POSTER_SIZE_OPTIONS: List<String> = listOf("Small", "Medium", "Large")
val TEXT_SIZE_OPTIONS: List<String> = listOf("Small", "Default", "Large")
val LAYOUT_SPACING_OPTIONS: List<String> = listOf("Compact", "Comfortable")
val CARD_CORNER_OPTIONS: List<String> = listOf("Rounded", "Sharp")
val ANIMATION_OPTIONS: List<String> = listOf("Full", "Reduced")

/** Autoplay max-size choices (GB; 0 = no limit). */
val AUTOPLAY_SIZE_OPTIONS: List<Pair<Int, String>> = listOf(
    0 to "No limit",
    2 to "Under 2 GB",
    5 to "Under 5 GB",
    10 to "Under 10 GB",
    20 to "Under 20 GB"
)

fun autoplaySizeName(gb: Int): String =
    AUTOPLAY_SIZE_OPTIONS.find { it.first == gb }?.second ?: if (gb <= 0) "No limit" else "Under $gb GB"

/**
 * Buffer presets offered in Settings > Playback > Buffer & Cache.
 * Each preset maps to (minBufferMs, maxBufferMs, bufferForPlaybackMs).
 */
val BUFFER_PRESETS: List<Pair<String, Triple<Int, Int, Int>>> = listOf(
    "Low" to Triple(10_000, 30_000, 1_500),
    "Balanced" to Triple(15_000, 50_000, 2_500),
    "Aggressive" to Triple(30_000, 100_000, 5_000)
)

fun bufferPresetName(minMs: Int, maxMs: Int, forPlaybackMs: Int): String =
    BUFFER_PRESETS.find { it.second == Triple(minMs, maxMs, forPlaybackMs) }?.first
        ?: "Custom (${minMs / 1000}s / ${maxMs / 1000}s)"

/** Disk cache size options in MB (0 = off). */
val DISK_CACHE_OPTIONS: List<Pair<Int, String>> = listOf(
    0 to "Off",
    100 to "100 MB",
    500 to "500 MB",
    1024 to "1 GB"
)

fun diskCacheName(mb: Int): String =
    DISK_CACHE_OPTIONS.find { it.first == mb }?.second
        ?: if (mb <= 0) "Off" else "$mb MB"

/** Which app plays video streams. */
enum class PlayerChoice(val label: String, val blurb: String) {
    BUILT_IN(
        "Built-in player",
        "Plavio's own player — gestures, subtitles, PiP, skip intro"
    ),
    EXTERNAL(
        "External player",
        "Open streams in VLC, MX Player or another app you choose"
    ),
    ASK(
        "Ask every time",
        "Choose the player each time you press play"
    );

    companion object {
        fun fromName(name: String?): PlayerChoice =
            values().find { it.name == name } ?: BUILT_IN
    }
}

/** Tiny SharedPreferences-backed store for user settings (no extra dependency). */
class SettingsStore(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("pulse_settings", Context.MODE_PRIVATE)

    /**
     * Adaptive quality ceiling (user's order 2026-10-20, Netflix/YouTube style):
     * the highest quality this device + network can actually handle.
     * - Device cap: based on the screen's smaller dimension in pixels.
     *   A 720p phone gains nothing from a 4K stream - it just buffers more.
     * - Network cap: based on the system's downstream bandwidth estimate.
     * Returns one of QUALITY_ORDER_OPTIONS ("480p".."2160p").
     */
    fun adaptiveQualityCap(): String {
        // Device cap from screen resolution.
        val metrics = appContext.resources.displayMetrics
        val shortSide = minOf(metrics.widthPixels, metrics.heightPixels)
        val deviceCap = when {
            shortSide >= 1440 -> "2160p" // QHD+ screen: 4K downscale still beats 1080p
            shortSide >= 1080 -> "1080p"
            shortSide >= 720 -> "720p"
            else -> "480p"
        }
        // Network cap from the system's link bandwidth estimate.
        val networkCap = try {
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            val downKbps = caps?.linkDownstreamBandwidthKbps ?: 0
            when {
                downKbps <= 0 -> deviceCap // unknown - trust the device
                downKbps >= 25_000 -> "2160p" // 25+ Mbps for 4K
                downKbps >= 10_000 -> "1080p" // 10+ Mbps for 1080p (headroom)
                downKbps >= 5_000 -> "720p"   // 5+ Mbps for 720p
                else -> "480p"
            }
        } catch (e: Exception) {
            deviceCap
        }
        // The lower of the two wins.
        val ladder = listOf("480p", "720p", "1080p", "2160p")
        return if (ladder.indexOf(networkCap) < ladder.indexOf(deviceCap)) networkCap else deviceCap
    }
    /**
     * Onboarding flag lives in its OWN prefs file: Android auto-backup must
     * never restore onboarding_done=true on a fresh install / new device,
     * or the first-run guide is silently skipped (see backup_rules.xml).
     */
    private val onboardingPrefs: SharedPreferences =
        appContext.getSharedPreferences("pulse_onboarding", Context.MODE_PRIVATE)
    private val secretPrefs: SharedPreferences =
        appContext.getSharedPreferences("pulse_secret_settings", Context.MODE_PRIVATE)

    // Type-tolerant numeric reads. A backup restore (org.json turns 1.0 into
    // an Int) or an older version can store a number under a key in the wrong
    // numeric type, and the strict SharedPreferences getters then throw
    // ClassCastException (Sentry PLAVIO-1). These coerce any stored Number;
    // a missing or non-numeric value falls back to the default, exactly like
    // the typed getters did for absent keys.
    private fun prefFloat(key: String, default: Float): Float =
        (prefs.all[key] as? Number)?.toFloat() ?: default

    private fun prefInt(key: String, default: Int): Int =
        (prefs.all[key] as? Number)?.toInt() ?: default

    private fun prefLong(key: String, default: Long): Long =
        (prefs.all[key] as? Number)?.toLong() ?: default

    init { migrateLegacySecrets() }

    /** Play the first source automatically (v0.2.0 behavior) vs. manual play. */
    var autoplay: Boolean
        get() = prefs.getBoolean(KEY_AUTOPLAY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTOPLAY, value).apply()

    /** Sentry crash reports (owner's order 2026-10-23): ON by default. */
    var sentryEnabled: Boolean
        get() = prefs.getBoolean(KEY_SENTRY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SENTRY_ENABLED, value).apply()

    /** Automatically start the next episode when one finishes (series only). */
    var autoPlayNext: Boolean
        get() = prefs.getBoolean(KEY_AUTOPLAY_NEXT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTOPLAY_NEXT, value).apply()

    /** Play series episodes in random order instead of sequential (v0.9.0+). */
    var shuffleEpisodes: Boolean
        get() = prefs.getBoolean(KEY_SHUFFLE_EPISODES, false)
        set(value) = prefs.edit().putBoolean(KEY_SHUFFLE_EPISODES, value).apply()

    /** Picture-in-Picture: allow the player to shrink into a floating window (v0.9.0+). */
    var pipEnabled: Boolean
        get() = prefs.getBoolean(KEY_PIP_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_PIP_ENABLED, value).apply()

    /**
     * Continue Watching artwork (item 35, Discord request the owner
     * approved 2026-10-28): true = the title's poster, crop-filled
     * into the same landscape tile (DEFAULT since the owner's order
     * 2026-10-29); false = the saved scene still. Only the no-value-yet
     * default changed — an explicit user OFF stays OFF.
     */
    var cwArtworkPoster: Boolean
        get() = prefs.getBoolean(KEY_CW_ARTWORK_POSTER, true)
        set(value) = prefs.edit().putBoolean(KEY_CW_ARTWORK_POSTER, value).apply()

    /**
     * New-episode alerts: a daily background check notifies when shows in
     * the watchlist release new episodes. Default ON; the Settings toggle
     * also requests the POST_NOTIFICATIONS runtime permission on Android 13+.
     */
    var episodeNotifications: Boolean
        get() = prefs.getBoolean(KEY_EPISODE_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_EPISODE_NOTIFICATIONS, value).apply()

    /**
     * New-movie-release alerts (v0.14.14): a background check modelled
     * on the episode checker notifies when a movie in the user's
     * library/watchlist passes its release date. Lives ONLY in
     * Settings → Notifications (owner's one-card order 2026-10-29).
     * Default ON.
     */
    var movieNotifications: Boolean
        get() = prefs.getBoolean(KEY_MOVIE_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_MOVIE_NOTIFICATIONS, value).apply()

    /**
     * "Download finished" alerts (v0.14.14): post a notification when
     * a download completes. The live progress notification is separate
     * and always runs while downloads are active. Default ON.
     */
    var downloadFinishedNotifications: Boolean
        get() = prefs.getBoolean(KEY_DOWNLOAD_FINISHED_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_DOWNLOAD_FINISHED_NOTIFICATIONS, value).apply()

    // ------------------------------------------------------------------
    // Home catalog visibility (v0.14.14): the press-and-hold Home
    // picker stores PER-CATALOG choices on top of the per-addon
    // `showOnHome` flag. Two explicit key sets ("addonId|catalogId"):
    // a catalog in the ON set shows even when its addon defaults off;
    // a catalog in the OFF set hides even when its addon defaults on.
    // Neither set containing the key = fall back to the addon's flag,
    // which is exactly how pre-picker installs migrate: an addon that
    // was off starts with all its catalogs unticked, and vice versa.
    // ------------------------------------------------------------------

    private var homeCatalogOnKeys: Set<String>
        get() = prefs.getStringSet(KEY_HOME_CATALOG_ON, emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_HOME_CATALOG_ON, value).apply()

    private var homeCatalogOffKeys: Set<String>
        get() = prefs.getStringSet(KEY_HOME_CATALOG_OFF, emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_HOME_CATALOG_OFF, value).apply()

    /**
     * Whether [catalogId] of [addonId] shows on Home (P15, v0.14.22).
     * The stored key carries the catalog TYPE ("addonId|type|catalogId") —
     * the same type-carrying identity the PLAVIO-H fix established for row
     * keys: Cinemeta declares catalog id "top" for BOTH movie and series,
     * so keying without type made the two picker rows one shared switch.
     * Legacy two-part keys ("addonId|catalogId") are still honoured as a
     * fallback, so prefs stored before this change keep their meaning;
     * every new write uses (and cleans up) the typed key.
     */
    fun isCatalogOnHome(addonId: String, catalogId: String, addonDefault: Boolean, type: String = ""): Boolean {
        val typed = "$addonId|$type|$catalogId"
        val legacy = "$addonId|$catalogId"
        if (typed in homeCatalogOnKeys || legacy in homeCatalogOnKeys) return true
        if (typed in homeCatalogOffKeys || legacy in homeCatalogOffKeys) return false
        return addonDefault
    }

    fun setCatalogOnHome(addonId: String, catalogId: String, on: Boolean, type: String = "") {
        val typed = "$addonId|$type|$catalogId"
        val legacy = "$addonId|$catalogId"
        if (on) {
            homeCatalogOnKeys = homeCatalogOnKeys + typed - legacy
            homeCatalogOffKeys = homeCatalogOffKeys - typed - legacy
        } else {
            homeCatalogOffKeys = homeCatalogOffKeys + typed - legacy
            homeCatalogOnKeys = homeCatalogOnKeys - typed - legacy
        }
    }

    /**
     * Home's meta provider (v0.14.15, owner correction): the addon the
     * hold-Home picker selected to fill Home. Null = never picked —
     * Home then falls back to the default meta addon (PlavioMeta by
     * rank), so installs that never open the picker see no change.
     * The provider decides WHICH addon's catalogs are eligible for
     * Home; the per-catalog ticks above decide which of its rows show.
     */
    var homeMetaProviderAddonId: String?
        get() = prefs.getString(KEY_HOME_META_PROVIDER, null)
        set(value) {
            val edit = prefs.edit()
            if (value == null) edit.remove(KEY_HOME_META_PROVIDER)
            else edit.putString(KEY_HOME_META_PROVIDER, value)
            edit.apply()
        }

    /**
     * The owner's own Home catalog order (v0.14.15): typed catalog
     * keys ("addonId|type|catalogId" — the row identity used
     * everywhere) in the order set by press-and-hold dragging inside
     * the hold-Home picker; the first key renders as the TOP row on
     * Home. Stored as one newline-joined string (keys never contain
     * newlines). Empty = never arranged, Home keeps its natural
     * order. The merge with the live catalog set lives in
     * StreamRepository.applyHomeCatalogOrder: saved keys first in
     * saved order, unsaved catalogs after them in natural order,
     * keys whose catalog vanished simply stop matching.
     */
    var homeCatalogOrder: List<String>
        get() = prefs.getString(KEY_HOME_CATALOG_ORDER, null)
            ?.split('\n')?.filter { it.isNotBlank() } ?: emptyList()
        set(value) {
            val edit = prefs.edit()
            if (value.isEmpty()) edit.remove(KEY_HOME_CATALOG_ORDER)
            else edit.putString(KEY_HOME_CATALOG_ORDER, value.joinToString("\n"))
            edit.apply()
        }

    /** All · None in the picker: set every catalog of one addon at once. */
    fun setAllCatalogsOnHome(addonId: String, catalogIds: List<String>, on: Boolean) {
        setAllCatalogsOnHomeTyped(addonId, catalogIds.map { "" to it }, on)
    }

    /** Typed All · None (P15): [typeAndIds] are (type, catalogId) pairs. */
    fun setAllCatalogsOnHomeTyped(addonId: String, typeAndIds: List<Pair<String, String>>, on: Boolean) {
        val keys = typeAndIds.map { (type, id) -> "$addonId|$type|$id" }.toSet()
        val legacy = typeAndIds.map { (_, id) -> "$addonId|$id" }.toSet()
        if (on) {
            homeCatalogOnKeys = homeCatalogOnKeys + keys - legacy
            homeCatalogOffKeys = homeCatalogOffKeys - keys - legacy
        } else {
            homeCatalogOffKeys = homeCatalogOffKeys + keys - legacy
            homeCatalogOnKeys = homeCatalogOnKeys - keys - legacy
        }
    }

    /**
     * Local profiles (v0.14.13, item 8): the profile the app is
     * currently showing, and the DEFAULT profile a cold start opens
     * into. Both hold ProfileRow ids; the first profile is
     * [com.pulsestream.app.data.db.Profiles.DEFAULT_ID].
     */
    var activeProfileId: String
        get() = prefs.getString(KEY_ACTIVE_PROFILE, com.pulsestream.app.data.db.Profiles.DEFAULT_ID)
            ?: com.pulsestream.app.data.db.Profiles.DEFAULT_ID
        set(value) = prefs.edit().putString(KEY_ACTIVE_PROFILE, value).apply()

    var defaultProfileId: String
        get() = prefs.getString(KEY_DEFAULT_PROFILE, com.pulsestream.app.data.db.Profiles.DEFAULT_ID)
            ?: com.pulsestream.app.data.db.Profiles.DEFAULT_ID
        set(value) = prefs.edit().putString(KEY_DEFAULT_PROFILE, value).apply()

    /**
     * One-shot profile switch (item 8): set by a manual switch right
     * before the app restarts itself; the cold start consumes it so
     * the switch lands, while every later cold start opens into the
     * DEFAULT profile, per the owner's spec.
     */
    var pendingSwitchProfileId: String
        get() = prefs.getString(KEY_PENDING_SWITCH_PROFILE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PENDING_SWITCH_PROFILE, value).apply()

    /**
     * Which player opens streams: the built-in Plavio player, an external
     * app chosen by the system chooser, or ask every time.
     * Stored as [PlayerChoice.name]; defaults to built-in.
     */
    var preferredPlayer: String
        get() = prefs.getString(KEY_PREFERRED_PLAYER, PlayerChoice.BUILT_IN.name)
            ?: PlayerChoice.BUILT_IN.name
        set(value) = prefs.edit().putString(KEY_PREFERRED_PLAYER, value).apply()

    // ------------------------------------------------------------------
    // Buffer & cache (v0.9.0+): player buffering + on-disk playback cache.
    // ------------------------------------------------------------------

    /** Minimum media buffered before playback can proceed (ms). */
    var bufferMinMs: Int
        get() = prefInt(KEY_BUFFER_MIN_MS, 15_000).coerceIn(5_000, 120_000)
        set(value) = prefs.edit().putInt(KEY_BUFFER_MIN_MS, value.coerceIn(5_000, 120_000)).apply()

    /** Maximum media buffered ahead during playback (ms). */
    var bufferMaxMs: Int
        get() = prefInt(KEY_BUFFER_MAX_MS, 50_000).coerceIn(10_000, 300_000)
        set(value) = prefs.edit().putInt(KEY_BUFFER_MAX_MS, value.coerceIn(10_000, 300_000)).apply()

    /** How much must be buffered before playback starts/resumes (ms). */
    var bufferForPlaybackMs: Int
        get() = prefInt(KEY_BUFFER_FOR_PLAYBACK_MS, 2_500).coerceIn(1_000, 30_000)
        set(value) = prefs.edit().putInt(KEY_BUFFER_FOR_PLAYBACK_MS, value.coerceIn(1_000, 30_000)).apply()

    /**
     * On-disk playback cache size in MB (0 = off). Caches progressive
     * media so re-watches don't re-download. HLS/DASH segments are cached
     * too; live streams are unaffected (they're never re-watched).
     */
    var diskCacheMb: Int
        get() = prefInt(KEY_DISK_CACHE_MB, 0).coerceAtLeast(0)
        set(value) = prefs.edit().putInt(KEY_DISK_CACHE_MB, value.coerceAtLeast(0)).apply()

    /** Keep the screen awake while the player is open. */
    var keepScreenOn: Boolean
        get() = prefs.getBoolean(KEY_KEEP_SCREEN_ON, true)
        set(value) = prefs.edit().putBoolean(KEY_KEEP_SCREEN_ON, value).apply()

    /**
     * VLC-style forced seek (owner order 2026-10-30): on hosts that ignore
     * byte ranges, the playback HTTP layer reads-and-discards its way to
     * the seek point instead of the seek being refused. Default ON — the
     * owner chose "build it always", not Wi-Fi-only. Far jumps on such
     * hosts cost extra data and a moment; range-honouring hosts are
     * completely unaffected.
     */
    var forceSeekAnyStream: Boolean
        get() = prefs.getBoolean(KEY_FORCE_SEEK_ANY_STREAM, true)
        set(value) = prefs.edit().putBoolean(KEY_FORCE_SEEK_ANY_STREAM, value).apply()

    /** Show the "Skip intro / recap / outro" button when segments are known. */
    var showSkipButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SKIP, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SKIP, value).apply()

    /** Per-addon flag so pre-installed addons are only auto-installed once. */
    fun isPreinstallDone(manifestId: String): Boolean =
        prefs.getBoolean(KEY_PREINSTALL_PREFIX + manifestId, false)

    fun setPreinstallDone(manifestId: String) =
        prefs.edit().putBoolean(KEY_PREINSTALL_PREFIX + manifestId, true).apply()

    /**
     * Clears every preinstall_done_* marker. Called when the database had
     * to be recreated from corruption: the DB is empty but the flags
     * survived, which would silently skip reinstalling the bundled addons
     * (PlavioHD/PlavioMeta). Clearing them lets
     * ensurePreinstalledAddons() run again.
     */
    fun clearPreinstallFlags() {
        val stale = prefs.all.keys.filter { it.startsWith(KEY_PREINSTALL_PREFIX) }
        if (stale.isNotEmpty()) {
            prefs.edit().apply { stale.forEach(::remove) }.apply()
        }
    }

    /**
     * "System default" subtitle appearance: when true the player skips its
     * own styling (no setStyle()) so Android's Settings > Accessibility >
     * Captions preferences apply instead.
     */
    var useSystemCaptions: Boolean
        get() = prefs.getBoolean(KEY_SYSTEM_CAPTIONS, false)
        set(value) = prefs.edit().putBoolean(KEY_SYSTEM_CAPTIONS, value).apply()

    /** Simkl access token (null = not linked). */
    var simklToken: String?
        get() = getSecret(KEY_SIMKL_TOKEN)
        set(value) = putSecret(KEY_SIMKL_TOKEN, value)

    /** Simkl refresh token (AUTH V2 grants one; null when the grant carried none). */
    var simklRefreshToken: String?
        get() = getSecret(KEY_SIMKL_REFRESH)
        set(value) = putSecret(KEY_SIMKL_REFRESH, value)

    /** Epoch millis when the current Simkl access token was issued (0 = unknown). */
    var simklTokenIssuedAt: Long
        get() = prefLong(KEY_SIMKL_ISSUED_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_SIMKL_ISSUED_AT, value).apply()

    /** Simkl display name for the linked account. */
    var simklUsername: String?
        get() = prefs.getString(KEY_SIMKL_USERNAME, null)
        set(value) {
            if (value == null) prefs.edit().remove(KEY_SIMKL_USERNAME).apply()
            else prefs.edit().putString(KEY_SIMKL_USERNAME, value).apply()
        }

    /** TorBox API key (null = not configured). Debrid-only: resolves cached torrent infoHashes to direct HTTP links. */
    var torboxApiKey: String?
        get() = getSecret(KEY_TORBOX_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_TORBOX_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    /** Real-Debrid API key (null = not configured). Debrid-only. */
    var realDebridApiKey: String?
        get() = getSecret(KEY_REALDEBRID_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_REALDEBRID_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    /** Premiumize API key (null = not configured). Debrid-only, under testing. */
    var premiumizeApiKey: String?
        get() = getSecret(KEY_PREMIUMIZE_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_PREMIUMIZE_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    /** AllDebrid API key (null = not configured). Debrid-only, under testing. */
    var allDebridApiKey: String?
        get() = getSecret(KEY_ALLDEBRID_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_ALLDEBRID_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    /** Debrid-Link API token (null = not configured). Debrid-only, under testing. */
    var debridLinkApiKey: String?
        get() = getSecret(KEY_DEBRIDLINK_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_DEBRIDLINK_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    /** Offcloud API key (null = not configured). Debrid-only, under testing. */
    var offcloudApiKey: String?
        get() = getSecret(KEY_OFFCLOUD_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_OFFCLOUD_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })


    /** Trakt access token (null = not linked). */
    var traktAccessToken: String?
        get() = getSecret(KEY_TRAKT_TOKEN)
        set(value) = putSecret(KEY_TRAKT_TOKEN, value)

    /** Trakt refresh token. */
    var traktRefreshToken: String?
        get() = getSecret(KEY_TRAKT_REFRESH)
        set(value) = putSecret(KEY_TRAKT_REFRESH, value)

    /** Epoch millis when the Trakt access token should be refreshed. */
    var traktTokenExpiry: Long
        get() = prefLong(KEY_TRAKT_EXPIRY, 0L)
        set(value) = prefs.edit().putLong(KEY_TRAKT_EXPIRY, value).apply()

    /** Trakt display name for the linked account. */
    var traktUsername: String?
        get() = prefs.getString(KEY_TRAKT_USERNAME, null)
        set(value) {
            if (value == null) prefs.edit().remove(KEY_TRAKT_USERNAME).apply()
            else prefs.edit().putString(KEY_TRAKT_USERNAME, value).apply()
        }

    /** MDBList API key (null = not linked). Powers the detail ratings strip, card ratings and MDBList lists. */
    var mdblistApiKey: String?
        get() = getSecret(KEY_MDBLIST_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_MDBLIST_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    // ---- MDBList Home-card ratings (item 29, owner's order 2026-10-28) ----

    /**
     * MDBList rating sources the user switched OFF for the Home poster
     * strip. Empty (the default) = every source on: adding a key turns
     * all sources on until the user disables some in Integrations.
     * Stored as a JSON array string (org.json — no separator hacks).
     */
    var mdblistDisabledSources: Set<String>
        get() = decodeJsonStringSet(prefs.getString(KEY_MDBLIST_DISABLED_SOURCES, null))
        set(value) = prefs.edit()
            .putString(KEY_MDBLIST_DISABLED_SOURCES, JSONArray(value).toString()).apply()

    /**
     * Source keys MDBList has been seen to return for this user —
     * drives the per-source toggle list in Integrations. Sources are
     * only added (union), never auto-removed.
     */
    var mdblistKnownSources: Set<String>
        get() = decodeJsonStringSet(prefs.getString(KEY_MDBLIST_KNOWN_SOURCES, null))
        set(value) = prefs.edit()
            .putString(KEY_MDBLIST_KNOWN_SOURCES, JSONArray(value).toString()).apply()

    /** Raw JSON backing the disk ratings cache used by MdbRatingsResolver. */
    var mdblistRatingsCacheJson: String?
        get() = prefs.getString(KEY_MDBLIST_RATINGS_CACHE, null)
        set(value) {
            if (value == null) prefs.edit().remove(KEY_MDBLIST_RATINGS_CACHE).apply()
            else prefs.edit().putString(KEY_MDBLIST_RATINGS_CACHE, value).apply()
        }

    /**
     * Raw JSON backing the /ratings endpoint disk cache (v0.14.20):
     * tt id → {at, body}. Separate from the resolver cache above —
     * that one belongs to the user's own MDBList key features.
     */
    var ratingsEndpointCacheJson: String?
        get() = prefs.getString(KEY_RATINGS_ENDPOINT_CACHE, null)
        set(value) {
            if (value == null) prefs.edit().remove(KEY_RATINGS_ENDPOINT_CACHE).apply()
            else prefs.edit().putString(KEY_RATINGS_ENDPOINT_CACHE, value).apply()
        }

    /** Parses a JSON array string into a string set; anything malformed reads as empty. */
    private fun decodeJsonStringSet(json: String?): Set<String> {
        if (json.isNullOrBlank()) return emptySet()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet()
        }.getOrDefault(emptySet())
    }

    /** TMDB API key for TMDB Enrichment (null = enrichment off). Collected inside the TMDB Enrichment entry in Integrations. */
    var tmdbApiKey: String?
        get() = getSecret(KEY_TMDB_API_KEY)?.takeIf { it.isNotBlank() }
        set(value) = putSecret(KEY_TMDB_API_KEY, value?.trim()?.takeIf { it.isNotBlank() })

    // ---- TMDB Enrichment toggles (owner-approved set of seven) ----

    var tmdbEnrichArtwork: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_ARTWORK, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_ARTWORK, value).apply()

    var tmdbEnrichBasicInfo: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_BASIC, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_BASIC, value).apply()

    var tmdbEnrichDetails: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_DETAILS, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_DETAILS, value).apply()

    var tmdbEnrichCredits: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_CREDITS, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_CREDITS, value).apply()

    var tmdbEnrichProductions: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_PRODUCTIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_PRODUCTIONS, value).apply()

    var tmdbEnrichNetworks: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_NETWORKS, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_NETWORKS, value).apply()

    var tmdbEnrichEpisodes: Boolean
        get() = prefs.getBoolean(KEY_TMDB_ENRICH_EPISODES, true)
        set(value) = prefs.edit().putBoolean(KEY_TMDB_ENRICH_EPISODES, value).apply()

    /** True when any enrichment toggle is on and a key is saved. */
    val tmdbEnrichmentActive: Boolean
        get() = tmdbApiKey != null && (tmdbEnrichArtwork || tmdbEnrichBasicInfo ||
            tmdbEnrichDetails || tmdbEnrichCredits || tmdbEnrichProductions ||
            tmdbEnrichNetworks || tmdbEnrichEpisodes)

    // ---- Sources dressing (Sample 1, owner-locked 2026-10-26) ----

    /** Size badge on stream cards (only when the stream carries a size). */
    var streamSizeBadges: Boolean
        get() = prefs.getBoolean(KEY_STREAM_SIZE_BADGES, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_SIZE_BADGES, value).apply()

    /** Badge position: false = bottom corner (Sample 1), true = top corner. */
    var streamBadgeTop: Boolean
        get() = prefs.getBoolean(KEY_STREAM_BADGE_TOP, false)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_BADGE_TOP, value).apply()

    /** Addon logo (or letter tile) on the Sources addon tabs. */
    var streamAddonLogos: Boolean
        get() = prefs.getBoolean(KEY_STREAM_ADDON_LOGOS, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_ADDON_LOGOS, value).apply()

    // ---- Stream badge styles (v0.14.12; final lineup v0.14.14) ----

    /**
     * How stream-card facts render (v0.14.28, Elite-only rule):
     * ELITE (the only built-in pack, and the default) / IMPORTED
     * (a user-imported badge pack). Stored as the enum name from
     * StreamBadges.kt's BadgeStyle. Every removed value (GROUPED /
     * GOLD / MINIMALIST / NARD / ONYX, and the v0.14.12 SEPARATE /
     * LABELLED / AIO_BADGES) falls back to ELITE when read through
     * BadgeStyle.fromName, so old installs migrate silently.
     * v0.14.36: NO LONGER READ for rendering — there is no badge-style
     * picker anymore. The active dressing is derived: the user's
     * Fusion sources (below) when any exist, else built-in Elite.
     * The value is kept so older data stays readable.
     */
    var streamCapsuleStyle: String
        get() = prefs.getString(KEY_STREAM_CAPSULE_STYLE, "ELITE") ?: "ELITE"
        set(value) = prefs.edit().putString(KEY_STREAM_CAPSULE_STYLE, value).apply()

    /**
     * Name of the user-imported badge pack (v0.14.21, Settings →
     * Streams → Badge style → Import pack). Blank = no pack imported;
     * the pack's artwork lives under filesDir/badges/imported.
     * v0.14.36: this is the LEGACY single-pack record. On the first
     * Fusion read it migrates into [fusionBadgeSourcesJson] as
     * source #1 (kind LEGACY, artwork dir unchanged) and this name
     * is cleared; until that read it still marks a user pack active.
     */
    var importedBadgePackName: String
        get() = prefs.getString(KEY_IMPORTED_BADGE_PACK_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_IMPORTED_BADGE_PACK_NAME, value).apply()

    /**
     * The user's Fusion badge sources (v0.14.36, Settings → Streams →
     * Fusion style badges): up to three sources (link imports and
     * pasted JSON), stored as one JSON list owned by FusionBadgeSources
     * in the UI layer. Null = no sources; built-in Elite dresses the
     * streams. This is the ONE home for user formatters — the old
     * single-pack import above is its migrated predecessor.
     */
    var fusionBadgeSourcesJson: String?
        get() = prefs.getString(KEY_FUSION_BADGE_SOURCES, null)
        set(value) = prefs.edit().putString(KEY_FUSION_BADGE_SOURCES, value).apply()

    /** Badge group visibility — one switch per fact family, all default ON. */
    var streamCapsuleGroupResolution: Boolean
        get() = prefs.getBoolean(KEY_STREAM_CAPSULE_GROUP_RESOLUTION, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_CAPSULE_GROUP_RESOLUTION, value).apply()

    var streamCapsuleGroupHdr: Boolean
        get() = prefs.getBoolean(KEY_STREAM_CAPSULE_GROUP_HDR, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_CAPSULE_GROUP_HDR, value).apply()

    var streamCapsuleGroupAudio: Boolean
        get() = prefs.getBoolean(KEY_STREAM_CAPSULE_GROUP_AUDIO, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_CAPSULE_GROUP_AUDIO, value).apply()

    var streamCapsuleGroupLanguages: Boolean
        get() = prefs.getBoolean(KEY_STREAM_CAPSULE_GROUP_LANGUAGES, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_CAPSULE_GROUP_LANGUAGES, value).apply()

    var streamCapsuleGroupSourceCodec: Boolean
        get() = prefs.getBoolean(KEY_STREAM_CAPSULE_GROUP_SOURCE_CODEC, true)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_CAPSULE_GROUP_SOURCE_CODEC, value).apply()
    // The Size group rides the existing streamSizeBadges toggle above
    // (Settings → Streams "Size badges" IS the size-group switch).

    // ---- Google removal migration (v0.14.6) ----

    /** The one-time "create a Plavio account" prompt has been shown. */
    var googleMigrationPromptShown: Boolean
        get() = prefs.getBoolean(KEY_GOOGLE_MIGRATION_SHOWN, false)
        set(value) = prefs.edit().putBoolean(KEY_GOOGLE_MIGRATION_SHOWN, value).apply()

    /**
     * Email of the Google account the removed Drive sync was signed in
     * with, read from that feature's own prefs file (left untouched on
     * disk). Non-null = this install was a Google user.
     */
    fun legacyGoogleAccountName(): String? = runCatching {
        appContext.getSharedPreferences("plavio_google_sync", Context.MODE_PRIVATE)
            .getString("account_name", null)?.takeIf { it.isNotBlank() }
    }.getOrNull()

    // ---- Continue Watching dismissals (notes item 13) ----

    /**
     * Continue Watching entries the user removed by hand, as
     * "identity|epochMs" strings (identity = the same episode/movie
     * identity the playback store dedupes on). The Trakt/Simkl
     * progress import checks this before resurrecting an entry:
     * progress paused BEFORE the dismissal is ignored; genuinely
     * newer progress (he watched more of it elsewhere afterwards)
     * may bring it back. A local play clears the dismissal.
     */
    var cwDismissedIdentities: Map<String, Long>
        get() = (prefs.getStringSet(KEY_CW_DISMISSED, emptySet()) ?: emptySet())
            .mapNotNull { entry ->
                val idx = entry.lastIndexOf('|')
                if (idx <= 0) null
                else entry.substring(0, idx) to
                    (entry.substring(idx + 1).toLongOrNull() ?: return@mapNotNull null)
            }.toMap()
        set(value) {
            prefs.edit().putStringSet(
                KEY_CW_DISMISSED,
                value.entries.map { "${it.key}|${it.value}" }.toSet()
            ).apply()
        }

    fun dismissContinueWatching(identity: String, atMs: Long = System.currentTimeMillis()) {
        cwDismissedIdentities = cwDismissedIdentities + (identity to atMs)
    }

    fun clearContinueWatchingDismissal(identity: String) {
        if (identity in cwDismissedIdentities) {
            cwDismissedIdentities = cwDismissedIdentities - identity
        }
    }

    // ---- Trakt/Simkl library sync ----

    /**
     * Keys ("type|imdbId") known to be in sync after the last successful
     * library sync — the merge base that lets the next sync tell a local
     * removal from a remote addition.
     */
    var librarySyncedKeys: Set<String>
        get() = prefs.getStringSet(KEY_LIBRARY_SYNCED, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_LIBRARY_SYNCED, value).apply()

    /** Epoch millis of the last library sync attempt (0 = never). */
    var librarySyncLastAt: Long
        get() = prefLong(KEY_LIBRARY_SYNC_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_LIBRARY_SYNC_AT, value).apply()

    /** Short human result of the last library sync ("" = never ran). */
    var librarySyncLastResult: String
        get() = prefs.getString(KEY_LIBRARY_SYNC_RESULT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LIBRARY_SYNC_RESULT, value).apply()

    /**
     * User-chosen display name for the Account area (owner's order
     * 2026-10-22): when set, the app shows this name instead of
     * presenting the Gmail address as the account name.
     */
    var profileUserName: String
        get() = prefs.getString(KEY_PROFILE_USER_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PROFILE_USER_NAME, value.trim()).apply()

    /**
     * Account picture choice (owner's order 2026-10-24): "" = none,
     * "photo" = the user's own photo (see [profilePhotoFile]),
     * "preset:<id>" = a built-in avatar. A plain preference, so it
     * rides the Drive backup with the other settings; the photo bytes
     * ride the backup as their own field (StreamRepository).
     */
    var profileAvatar: String
        get() = prefs.getString(KEY_PROFILE_AVATAR, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PROFILE_AVATAR, value).apply()

    /** The user's own cropped profile photo (JPEG, app-private storage). */
    fun profilePhotoFile(): File = File(appContext.filesDir, "profile_photo.jpg")

    fun readProfilePhotoBytes(): ByteArray? = runCatching {
        profilePhotoFile().takeIf { it.exists() }?.readBytes()
    }.getOrNull()

    fun writeProfilePhoto(bytes: ByteArray) {
        profilePhotoFile().writeBytes(bytes)
    }

    fun deleteProfilePhoto() {
        runCatching { profilePhotoFile().delete() }
    }

    /**
     * Full wipe of every store this class owns (v0.14.27, batch
     * N5 — account deletion): settings, secrets (API keys, service
     * tokens) and onboarding state all return to factory, and the
     * profile photo goes too. Called only from the account-delete
     * flow, after the server side has already been deleted.
     */
    fun wipeAll() {
        prefs.edit().clear().apply()
        secretPrefs.edit().clear().apply()
        onboardingPrefs.edit().clear().apply()
        deleteProfilePhoto()
    }

    /** Accent color theme name (see AccentTheme). */
    var accentName: String
        get() = prefs.getString(KEY_ACCENT, AccentTheme.WHITE.name) ?: AccentTheme.WHITE.name
        set(value) = prefs.edit().putString(KEY_ACCENT, value).apply()

    // ------------------------------------------------------------------
    // Appearance extras (v0.14.39, owner's A–H list 2026-11-02; all
    // inside the ONYX lock — no new themes). Every default reproduces
    // the pre-.39 shipped behaviour exactly, so the app looks
    // identical until the user changes something.
    // ------------------------------------------------------------------

    /** Poster size on Home + browse: "Small" / "Medium" / "Large". */
    var posterSize: String
        get() = (prefs.getString(KEY_POSTER_SIZE, "Medium") ?: "Medium")
            .takeIf { it in POSTER_SIZE_OPTIONS } ?: "Medium"
        set(value) = prefs.edit()
            .putString(KEY_POSTER_SIZE, if (value in POSTER_SIZE_OPTIONS) value else "Medium").apply()

    /** Poster scale factor for [posterSize]. */
    fun posterScale(): Float = when (posterSize) {
        "Small" -> 0.85f
        "Large" -> 1.18f
        else -> 1f
    }

    /** App text size: "Small" / "Default" / "Large". */
    var textSize: String
        get() = (prefs.getString(KEY_TEXT_SIZE, "Default") ?: "Default")
            .takeIf { it in TEXT_SIZE_OPTIONS } ?: "Default"
        set(value) = prefs.edit()
            .putString(KEY_TEXT_SIZE, if (value in TEXT_SIZE_OPTIONS) value else "Default").apply()

    /** Font-scale multiplier for [textSize] (rides the system font scale). */
    fun textScaleFactor(): Float = when (textSize) {
        "Small" -> 0.9f
        "Large" -> 1.15f
        else -> 1f
    }

    /** Layout spacing: "Compact" / "Comfortable" (row/list padding scale). */
    var layoutSpacing: String
        get() = (prefs.getString(KEY_LAYOUT_SPACING, "Comfortable") ?: "Comfortable")
            .takeIf { it in LAYOUT_SPACING_OPTIONS } ?: "Comfortable"
        set(value) = prefs.edit()
            .putString(KEY_LAYOUT_SPACING, if (value in LAYOUT_SPACING_OPTIONS) value else "Comfortable").apply()

    /** Padding-scale multiplier for [layoutSpacing]. */
    fun spacingScale(): Float = if (layoutSpacing == "Compact") 0.78f else 1f

    /** Card corners: "Rounded" (shipped look) / "Sharp". */
    var cardCorners: String
        get() = (prefs.getString(KEY_CARD_CORNERS, "Rounded") ?: "Rounded")
            .takeIf { it in CARD_CORNER_OPTIONS } ?: "Rounded"
        set(value) = prefs.edit()
            .putString(KEY_CARD_CORNERS, if (value in CARD_CORNER_OPTIONS) value else "Rounded").apply()

    /** Startup animation: ON plays the locked startup clip; OFF skips straight to the app. */
    var startupAnimation: Boolean
        get() = prefs.getBoolean(KEY_STARTUP_ANIMATION, true)
        set(value) = prefs.edit().putBoolean(KEY_STARTUP_ANIMATION, value).apply()

    /** App animations: "Full" (shipped behaviour) / "Reduced" (damped motion). */
    var animations: String
        get() = (prefs.getString(KEY_ANIMATIONS, "Full") ?: "Full")
            .takeIf { it in ANIMATION_OPTIONS } ?: "Full"
        set(value) = prefs.edit()
            .putString(KEY_ANIMATIONS, if (value in ANIMATION_OPTIONS) value else "Full").apply()

    /** True when the user picked Reduced animations. */
    val reduceAnimations: Boolean get() = animations == "Reduced"

    /** Bottom dock glass blur: ON = blurred glass dock; OFF = solid dark dock. */
    var dockGlassBlur: Boolean
        get() = prefs.getBoolean(KEY_DOCK_GLASS_BLUR, true)
        set(value) = prefs.edit().putBoolean(KEY_DOCK_GLASS_BLUR, value).apply()

    /** Pure-black backgrounds (AMOLED-friendly). */
    var amoledBlack: Boolean
        get() = prefs.getBoolean(KEY_AMOLED, false)
        set(value) = prefs.edit().putBoolean(KEY_AMOLED, value).apply()

    /** Theme mode: "dark" (default) or "light". */
    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, "dark") ?: "dark"
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value).apply()

    /**
     * The six-theme appearance choice (AppTheme name). When never set,
     * it migrates from the old settings so existing users keep their
     * current look: Normal -> Warm Ivory, AMOLED -> True Black, else
     * Onyx (the default). Writing it also keeps the legacy
     * themeMode/amoledBlack fields in sync for older readers.
     */
    var appTheme: String
        get() = prefs.getString(KEY_APP_THEME, null) ?: when {
            themeMode == "light" -> "WARM_IVORY"
            amoledBlack -> "TRUE_BLACK"
            else -> "ONYX"
        }
        set(value) {
            prefs.edit().putString(KEY_APP_THEME, value).apply()
            themeMode = if (value == "WARM_IVORY" || value == "PEARL") "light" else "dark"
            amoledBlack = value == "TRUE_BLACK"
        }

    /**
     * Preferred subtitle languages (ISO 639-1 codes) in the user's
     * priority order — index 0 is the first choice. No count cap
     * (v0.14.14; the old hard cap of 2 is gone and the stored order is
     * the priority). Empty = no preference (first available subtitle
     * is used).
     */
    var subtitleLanguages: List<String>
        get() = prefs.getString(KEY_SUBTITLE_LANGS, "")
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.distinct()
            ?: emptyList()
        set(value) = prefs.edit()
            .putString(KEY_SUBTITLE_LANGS, value.distinct().joinToString(","))
            .apply()

    /**
     * "Subtitles by default" behaviour (v0.14.14): one of
     * [SUB_DEFAULT_ON_IN_MY_LANGUAGES], [SUB_DEFAULT_ALWAYS_ON] or
     * [SUB_DEFAULT_OFF]. Drives the player's automatic track choice.
     * Default is [SUB_DEFAULT_OFF] since v0.14.22 (owner's order:
     * subtitles stay off until the user turns them on).
     */
    var subtitleDefaultMode: Int
        get() = prefInt(KEY_SUB_DEFAULT_MODE, SUB_DEFAULT_OFF)
            .coerceIn(SUB_DEFAULT_ON_IN_MY_LANGUAGES, SUB_DEFAULT_OFF)
        set(value) = prefs.edit()
            .putInt(KEY_SUB_DEFAULT_MODE, value.coerceIn(SUB_DEFAULT_ON_IN_MY_LANGUAGES, SUB_DEFAULT_OFF))
            .apply()

    /**
     * Show only my languages in the player's subtitle list (v0.14.14).
     * Default ON — the picker's language filtering already behaved this
     * way when preferences were set; the toggle just exposes it.
     */
    var subtitleOnlyMyLanguages: Boolean
        get() = prefs.getBoolean(KEY_SUB_ONLY_MY_LANGS, true)
        set(value) = prefs.edit().putBoolean(KEY_SUB_ONLY_MY_LANGS, value).apply()

    /**
     * Prefer hearing-impaired (SDH) subtitles in automatic selection
     * (v0.14.14). Best-effort only: addon data carries no SDH flag, so
     * this keys off SDH/CC tokens in the subtitle's name/URL. Default
     * OFF (no preference, as before).
     */
    var subtitlePreferSdh: Boolean
        get() = prefs.getBoolean(KEY_SUB_PREFER_SDH, false)
        set(value) = prefs.edit().putBoolean(KEY_SUB_PREFER_SDH, value).apply()

    /**
     * Forced subtitles in my languages (v0.14.14): when true (default),
     * a forced track in a preferred language is eligible for automatic
     * selection ("Auto-show"); when false ("Never"), forced tracks are
     * never auto-selected (they stay in the picker, badged). Default ON
     * preserves the previous behaviour, where forced tracks were
     * treated like any other by the auto-picker.
     */
    var subtitleForcedAutoShow: Boolean
        get() = prefs.getBoolean(KEY_SUB_FORCED_AUTO, true)
        set(value) = prefs.edit().putBoolean(KEY_SUB_FORCED_AUTO, value).apply()

    /**
     * Subtitle font family (v0.14.14): index into [SUBTITLE_FONT_OPTIONS]
     * (0 = System, 1 = Sans, 2 = Serif, 3 = Mono). Applied through
     * CaptionStyleCompat's typeface alongside the bold flag.
     */
    var subtitleFontFamily: Int
        get() = prefInt(KEY_SUB_FONT, 0).coerceIn(0, 3)
        set(value) = prefs.edit().putInt(KEY_SUB_FONT, value.coerceIn(0, 3)).apply()

    /**
     * Save subtitles with downloads (v0.14.14): when a download is
     * created, the best subtitle(s) in the preferred languages are
     * fetched and stored beside the media so the download plays with
     * them offline. Default OFF (nothing was saved before).
     */
    var subtitleSaveWithDownloads: Boolean
        get() = prefs.getBoolean(KEY_SUB_SAVE_DOWNLOADS, false)
        set(value) = prefs.edit().putBoolean(KEY_SUB_SAVE_DOWNLOADS, value).apply()

    /**
     * Auto-fetch subtitles online when a title has none (v0.14.14): on
     * playback start, if no subtitle came with the title, an online
     * search runs automatically and the best match (by the language
     * rules) is selected. The search is served by PlavioSubs (the
     * built-in subtitle source) plus any subtitle addon the user added
     * by hand (v0.14.35). Default OFF (the search used to be
     * manual-only, from the player's "Fetch subtitles online").
     */
    var subtitleAutoFetchOnline: Boolean
        get() = prefs.getBoolean(KEY_SUB_AUTO_FETCH, false)
        set(value) = prefs.edit().putBoolean(KEY_SUB_AUTO_FETCH, value).apply()

    /** First-run onboarding completed (v0.8.21+). False = show the 3-step guide. */
    var onboardingDone: Boolean
        get() {
            if (onboardingPrefs.contains(KEY_ONBOARDING_DONE)) {
                return onboardingPrefs.getBoolean(KEY_ONBOARDING_DONE, false)
            }
            // One-time migration from the old shared file (pre-backup-rules builds).
            val legacy = prefs.getBoolean(KEY_ONBOARDING_DONE, false)
            onboardingPrefs.edit().putBoolean(KEY_ONBOARDING_DONE, legacy).apply()
            return legacy
        }
        set(value) = onboardingPrefs.edit().putBoolean(KEY_ONBOARDING_DONE, value).apply()

    /**
     * Preferred audio language (ISO 639-1 code, single). Null = no preference
     * (ExoPlayer's default track selection). When set and a title's audio
     * tracks include it, the player auto-selects it at playback start.
     */
    var preferredAudioLanguage: String?
        get() = prefs.getString(KEY_AUDIO_LANG, null)?.takeIf { it.isNotBlank() }
        set(value) {
            if (value == null) prefs.edit().remove(KEY_AUDIO_LANG).apply()
            else prefs.edit().putString(KEY_AUDIO_LANG, value).apply()
        }

    /** Subtitle text color (ARGB int). Default: white. */
    var subtitleTextColor: Int
        get() = prefInt(KEY_SUB_COLOR, 0xFFFFFFFF.toInt())
        set(value) = prefs.edit().putInt(KEY_SUB_COLOR, value).apply()

    /** Subtitle text size scale (1.0 = default). Range 0.6 – 2.0.
     *  Mirrored with [subtitleFontSizeSp] (18sp == 1.0) so the Settings
     *  dialog (scale-based) and the player Style rail (sp-based) always
     *  agree on one persisted size. */
    var subtitleTextSizeScale: Float
        get() = prefFloat(KEY_SUB_SIZE, 1.0f)
        set(value) {
            val scale = value.coerceIn(0.6f, 2.0f)
            prefs.edit()
                .putFloat(KEY_SUB_SIZE, scale)
                .putInt(KEY_SUB_FONT_SP, (scale * 18f).roundToInt().coerceIn(12, 40))
                .apply()
        }

    /**
     * Subtitle font size in sp (player Style rail, v0.14.5): 12–40,
     * default 18. Kept in sync with [subtitleTextSizeScale] — writing
     * either one updates the other (18sp == scale 1.0).
     */
    var subtitleFontSizeSp: Int
        get() = if (prefs.contains(KEY_SUB_FONT_SP)) {
            prefInt(KEY_SUB_FONT_SP, 18).coerceIn(12, 40)
        } else {
            (prefFloat(KEY_SUB_SIZE, 1.0f) * 18f).roundToInt().coerceIn(12, 40)
        }
        set(value) {
            val sp = value.coerceIn(12, 40)
            prefs.edit()
                .putInt(KEY_SUB_FONT_SP, sp)
                .putFloat(KEY_SUB_SIZE, sp / 18f)
                .apply()
        }

    /**
     * Subtitle background color (ARGB int). Default: fully transparent
     * (mobile overhaul, owner order 2026-11-06): captions sit on the
     * picture with an outline, never on a solid black box, unless the
     * user picks a background themselves.
     */
    var subtitleBackgroundColor: Int
        get() = prefInt(KEY_SUB_BG, 0x00000000)
        set(value) = prefs.edit().putInt(KEY_SUB_BG, value).apply()

    /**
     * Subtitle edge style: 0 = none, 1 = outline, 2 = drop shadow,
     * 3 = raised, 4 = depressed. Default: 1 (outline) — the clean look
     * paired with the transparent background above.
     */
    var subtitleEdgeType: Int
        get() = prefInt(KEY_SUB_EDGE, 1)
        set(value) = prefs.edit().putInt(KEY_SUB_EDGE, value.coerceIn(0, 4)).apply()

    /** Bold subtitle text (player Style panel). Default: off. */
    var subtitleBold: Boolean
        get() = prefs.getBoolean(KEY_SUB_BOLD, false)
        set(value) = prefs.edit().putBoolean(KEY_SUB_BOLD, value).apply()

    /** Subtitle outline/edge color (ARGB int). Default: black. */
    var subtitleEdgeColor: Int
        get() = prefInt(KEY_SUB_EDGE_COLOR, 0xFF000000.toInt())
        set(value) = prefs.edit().putInt(KEY_SUB_EDGE_COLOR, value).apply()

    /**
     * Subtitle bottom offset, 0–200 in player Style-rail steps of 5;
     * the player maps it to a SubtitleView bottom-padding fraction so
     * captions can be lifted off the bottom edge. Default: 20.
     */
    var subtitleBottomOffset: Int
        get() = prefInt(KEY_SUB_BOTTOM, 20)
        set(value) = prefs.edit().putInt(KEY_SUB_BOTTOM, value.coerceIn(0, 200)).apply()

    /**
     * Per-video subtitle delay (ms, ±60s) set from the player's Style
     * rail — persisted per video id so a title remembers its sync.
     * Stored as newline-joined "urlEncoded(videoId)=ms" entries,
     * most recent last, capped at 100 titles.
     */
    fun subtitleDelayMsFor(videoId: String): Long {
        val raw = prefs.getString(KEY_SUB_DELAY_MAP, null) ?: return 0L
        val key = java.net.URLEncoder.encode(videoId, "UTF-8")
        for (entry in raw.split("\n")) {
            val eq = entry.lastIndexOf('=')
            if (eq > 0 && entry.substring(0, eq) == key) {
                return entry.substring(eq + 1).toLongOrNull()?.coerceIn(-60_000L, 60_000L) ?: 0L
            }
        }
        return 0L
    }

    fun setSubtitleDelayMsFor(videoId: String, delayMs: Long) {
        val key = java.net.URLEncoder.encode(videoId, "UTF-8")
        val raw = prefs.getString(KEY_SUB_DELAY_MAP, null).orEmpty()
        val entries = raw.split("\n")
            .filter { it.isNotBlank() && !it.startsWith("$key=") }
            .toMutableList()
        entries.add("$key=${delayMs.coerceIn(-60_000L, 60_000L)}")
        prefs.edit()
            .putString(KEY_SUB_DELAY_MAP, entries.takeLast(100).joinToString("\n"))
            .apply()
    }

    /**
     * Per-title remembered subtitle choice (v0.14.15, owner's order):
     * recorded when the user hand-picks a subtitle track — or "None" —
     * in the player, keyed by the player's title key (series-level for
     * episodes, so the whole series inherits the pick). Values:
     * "off", "url:<subtitle url>" (addon/online subs), "lang:<code>"
     * (embedded tracks, which have no URL). The player re-applies the
     * remembered choice on the next playback, ahead of the global
     * auto-pick. Same newline-map storage as the per-video delay,
     * most recent last, capped at 100 titles.
     */
    fun subtitleChoiceFor(memoryKey: String): String? {
        val raw = prefs.getString(KEY_SUB_CHOICE_MAP, null) ?: return null
        val key = java.net.URLEncoder.encode(memoryKey, "UTF-8")
        for (entry in raw.split("\n")) {
            val eq = entry.indexOf('=')
            if (eq > 0 && entry.substring(0, eq) == key) {
                return entry.substring(eq + 1).takeIf { it.isNotBlank() }
            }
        }
        return null
    }

    fun setSubtitleChoiceFor(memoryKey: String, choice: String) {
        val key = java.net.URLEncoder.encode(memoryKey, "UTF-8")
        val raw = prefs.getString(KEY_SUB_CHOICE_MAP, null).orEmpty()
        val entries = raw.split("\n")
            .filter { it.isNotBlank() && !it.startsWith("$key=") }
            .toMutableList()
        entries.add("$key=$choice")
        prefs.edit()
            .putString(KEY_SUB_CHOICE_MAP, entries.takeLast(100).joinToString("\n"))
            .apply()
    }

    /**
     * Hosts proven to ignore byte-range requests (v0.14.15): the
     * player's seek-snap detection adds a host here the first time it
     * catches it restarting a seek at ~0, and the guarded seek then
     * protects that host from the FIRST seek of every later session
     * too, not just the session that caught it.
     */
    var unseekableHosts: Set<String>
        get() = prefs.getStringSet(KEY_UNSEEKABLE_HOSTS, emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_UNSEEKABLE_HOSTS, value).apply()

    /**
     * Global subtitle timing offset in milliseconds (v0.9.0+). Positive =
     * subtitles appear later, negative = earlier. Range ±10 seconds.
     * Applied by rewriting subtitle files with shifted timestamps before
     * they are attached to the player (ExoPlayer has no delay API for
     * side-loaded subtitles).
     */
    var subtitleOffsetMs: Long
        get() = prefLong(KEY_SUBTITLE_OFFSET_MS, 0L).coerceIn(-10_000L, 10_000L)
        set(value) = prefs.edit().putLong(KEY_SUBTITLE_OFFSET_MS, value.coerceIn(-10_000L, 10_000L)).apply()

    /**
     * Playback engine choice (dual-engine overhaul): 0 = Auto,
     * 1 = ExoPlayer, 2 = MPV. Default Auto: HDR / Dolby Vision titles
     * route to ExoPlayer, anime routes to MPV, everything else plays
     * on ExoPlayer; a fatal error fails over to the other engine once.
     */
    var playbackEngine: Int
        get() = prefInt(KEY_PLAYBACK_ENGINE, 0).coerceIn(0, 2)
        set(value) = prefs.edit().putInt(KEY_PLAYBACK_ENGINE, value.coerceIn(0, 2)).apply()

    /**
     * Automatic one-time engine failover on a fatal playback error.
     * Default ON: it is a recovery behaviour, not an opt-in feature —
     * a manual in-player engine switch disarms it for that play.
     */
    var autoEngineFailover: Boolean
        get() = prefs.getBoolean(KEY_AUTO_ENGINE_FAILOVER, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_ENGINE_FAILOVER, value).apply()

    /** MPV hardware decoding. Default ON (matches the fast profile). */
    var mpvHardwareDecoding: Boolean
        get() = prefs.getBoolean(KEY_MPV_HWDEC, true)
        set(value) = prefs.edit().putBoolean(KEY_MPV_HWDEC, value).apply()

    /** MPV yuv420p format filter (older-device colour fix). Default OFF. */
    var mpvYuv420pFilter: Boolean
        get() = prefs.getBoolean(KEY_MPV_YUV420P, false)
        set(value) = prefs.edit().putBoolean(KEY_MPV_YUV420P, value).apply()

    /** Pinned Live TV channels, keys "addonId|metaId" ("m3u|url" for M3U). */
    var liveFavorites: Set<String>
        get() = prefs.getStringSet(KEY_LIVE_FAVS, emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_LIVE_FAVS, value).apply()

    /** Recently watched Live TV channel keys, most-recent first (max 20). */
    var liveRecent: List<String>
        get() = prefs.getString(KEY_LIVE_RECENT, "")
            ?.split("\n")?.map { it.trim() }?.filter { it.isNotEmpty() }?.take(20)
            ?: emptyList()
        set(value) = prefs.edit()
            .putString(KEY_LIVE_RECENT, value.take(20).joinToString("\n")).apply()

    /** User-added M3U/IPTV playlist URLs. */
    var m3uPlaylists: List<String>
        get() = prefs.getString(KEY_M3U_LISTS, "")
            ?.split("\n")?.map { it.trim() }?.filter { it.isNotEmpty() }
            ?: emptyList()
        set(value) = prefs.edit()
            .putString(KEY_M3U_LISTS, value.joinToString("\n")).apply()

    /**
     * Epoch millis of the last successful Home catalog refresh.
     * Per-section freshness: the Live tab writes its own rows into the same
     * catalog_cache table, so Home freshness must be tracked separately —
     * otherwise a Live visit would suppress Home's background refresh.
     */
    var homeCatalogsRefreshedAt: Long
        get() = prefLong(KEY_HOME_REFRESHED_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_HOME_REFRESHED_AT, value).apply()

    /**
     * Persisted addon manifests (v0.14.35 cold-start fix): one JSON
     * object mapping baseUrl -> {"ts": fetchedAt, "manifest": "..."},
     * owned by StreamRepository. The in-memory manifest cache dies
     * with the process, so every cold start used to pay a serial
     * manifest round-trip per addon before any catalog could load;
     * this store lets a cold start read manifests from disk under
     * the same 6 h TTL the memory cache always had.
     */
    var manifestStoreJson: String?
        get() = prefs.getString(KEY_MANIFEST_STORE, null)
        set(value) {
            val edit = prefs.edit()
            if (value == null) edit.remove(KEY_MANIFEST_STORE)
            else edit.putString(KEY_MANIFEST_STORE, value)
            edit.apply()
        }

    /**
     * R5(i) (v0.14.23): identity of the catalog row handed to the
     * "View all" screen, persisted as a small JSON object
     * (addonId/type/catalogId + display names + baseUrl). The in-memory
     * handoff dies with the process; this lets CatalogScreen re-derive
     * the row from the repository after process death instead of
     * landing on an empty screen.
     */
    var pendingCatalogJson: String?
        get() = prefs.getString(KEY_PENDING_CATALOG, null)
        set(value) = prefs.edit().putString(KEY_PENDING_CATALOG, value).apply()

    // ------------------------------------------------------------------
    // Streams section (v0.8.31+): quality order, autoplay.
    // (The old "streams per source" cap was removed by the owner's
    // order 2026-10-27: no limit anywhere — more streams is better.
    // Its leftover pref-key constant was deleted in v0.14.35; a value
    // still sitting in an old prefs file is simply never read.)
    // ------------------------------------------------------------------

    /**
     * Quality sort priority for the stream picker, top = highest priority.
     * Canonical buckets: "2160p", "1080p", "720p", "480p".
     */
    var qualityOrder: List<String>
        get() {
            val saved = prefs.getString(KEY_QUALITY_ORDER, null)
                ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
                ?: emptyList()
            val valid = saved.filter { it in QUALITY_ORDER_OPTIONS }
            return if (valid.isEmpty()) QUALITY_ORDER_OPTIONS else valid
        }
        set(value) = prefs.edit()
            .putString(KEY_QUALITY_ORDER, value.filter { it in QUALITY_ORDER_OPTIONS }.joinToString(","))
            .apply()

    /**
     * Stream autoplay: when ON, pressing Play auto-picks the first stream
     * matching the quality priority + size rule instead of the probed best.
     */
    var streamAutoplay: Boolean
        get() = prefs.getBoolean(KEY_STREAM_AUTOPLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_STREAM_AUTOPLAY, value).apply()

    /** Preferred autoplay quality ("Auto" = follow qualityOrder, else a bucket). */
    var autoplayQuality: String
        get() = (prefs.getString(KEY_AUTOPLAY_QUALITY, "Auto") ?: "Auto")
            .takeIf { it == "Auto" || it in QUALITY_ORDER_OPTIONS } ?: "Auto"
        set(value) = prefs.edit()
            .putString(KEY_AUTOPLAY_QUALITY, if (value == "Auto" || value in QUALITY_ORDER_OPTIONS) value else "Auto")
            .apply()

    /** Autoplay max file size in GB (0 = no limit). */
    var autoplayMaxSizeGb: Int
        get() = prefInt(KEY_AUTOPLAY_MAX_SIZE, 0).coerceAtLeast(0)
        set(value) = prefs.edit().putInt(KEY_AUTOPLAY_MAX_SIZE, value.coerceAtLeast(0)).apply()

    private fun migrateLegacySecrets() {
        for (key in SECRET_KEYS) {
            val legacy = prefs.getString(key, null) ?: continue
            if (secretPrefs.getString(key, null) == null) runCatching { putSecret(key, legacy) }
            // Remove plaintext only after the encrypted copy was persisted.
            if (secretPrefs.getString(key, null) != null) prefs.edit().remove(key).apply()
        }
    }

    private fun getSecret(key: String): String? {
        val encoded = secretPrefs.getString(key, null)
        if (encoded != null) return runCatching { decryptSecret(encoded) }.getOrNull()
        val legacy = prefs.getString(key, null) ?: return null
        runCatching { putSecret(key, legacy) }
        if (secretPrefs.getString(key, null) != null) prefs.edit().remove(key).apply()
        return legacy
    }

    private fun putSecret(key: String, value: String?) {
        if (value == null) {
            secretPrefs.edit().remove(key).apply()
            prefs.edit().remove(key).apply()
        } else {
            check(secretPrefs.edit().putString(key, encryptSecret(value)).commit()) { "Could not persist encrypted secret." }
            prefs.edit().remove(key).commit()
        }
    }

    private fun encryptSecret(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decryptSecret(value: String): String {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        require(bytes.size > 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
    }

    /**
     * Reads a cloud-backup payload. The write side of the old P18
     * client-side cloud sealing was deleted in v0.14.35 —
     * it had been uncalled since v0.14.29, when uploads went back to
     * plain payloads on the owner's order: a payload sealed with this
     * device's AndroidKeyStore key could only ever be decrypted on
     * this device, which broke restore-after-reinstall. Payloads
     * written by the v0.14.22–v0.14.28 builds carry the self-describing
     * [CLOUD_ENC_PREFIX] envelope and are decrypted here, on the device
     * that sealed them; anything else is plaintext and passes through
     * unchanged. Null when a sealed payload cannot be decrypted here.
     */
    fun decryptFromCloud(payload: String): String? {
        if (!payload.startsWith(CLOUD_ENC_PREFIX)) return payload
        return runCatching { decryptSecret(payload.removePrefix(CLOUD_ENC_PREFIX)) }.getOrNull()
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(SECRET_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(SECRET_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    // ------------------------------------------------------------------
    // Backup & restore (v0.9.0+): raw prefs access for JSON export/import.
    // The onboarding prefs file is deliberately excluded — restoring
    // onboarding_done=true on a new device would skip the first-run guide.
    // ------------------------------------------------------------------

    /** Snapshot of every stored preference (excludes the onboarding file). */
    fun exportAllPrefs(): Map<String, *> = prefs.all.filterKeys { it !in SECRET_KEYS }.toMap()

    /**
     * Exports API keys (decrypted) for cloud backup (user's order: simple sync like Nuvio,
     * no separate passphrase). Only includes non-blank keys.
     */
    fun exportApiKeysForBackup(): Map<String, String> {
        val keys = mutableMapOf<String, String>()
        torboxApiKey?.takeIf { it.isNotBlank() }?.let { keys["torbox_api_key"] = it }
        realDebridApiKey?.takeIf { it.isNotBlank() }?.let { keys["realdebrid_api_key"] = it }
        premiumizeApiKey?.takeIf { it.isNotBlank() }?.let { keys["premiumize_api_key"] = it }
        allDebridApiKey?.takeIf { it.isNotBlank() }?.let { keys["alldebrid_api_key"] = it }
        debridLinkApiKey?.takeIf { it.isNotBlank() }?.let { keys["debridlink_api_key"] = it }
        offcloudApiKey?.takeIf { it.isNotBlank() }?.let { keys["offcloud_api_key"] = it }
        traktAccessToken?.takeIf { it.isNotBlank() }?.let { keys["trakt_access_token"] = it }
        traktRefreshToken?.takeIf { it.isNotBlank() }?.let { keys["trakt_refresh_token"] = it }
        simklToken?.takeIf { it.isNotBlank() }?.let { keys["simkl_token"] = it }
        simklRefreshToken?.takeIf { it.isNotBlank() }?.let { keys["simkl_refresh_token"] = it }
        tmdbApiKey?.takeIf { it.isNotBlank() }?.let { keys["tmdb_api_key"] = it }
        mdblistApiKey?.takeIf { it.isNotBlank() }?.let { keys["mdblist_api_key"] = it }
        return keys
    }

    /**
     * Restores API keys from cloud backup (user's order: simple sync).
     * Only fills in blank local keys to avoid clobbering newer local values.
     */
    fun importApiKeysFromBackup(keys: Map<String, String>) {
        keys["torbox_api_key"]?.takeIf { it.isNotBlank() && torboxApiKey.isNullOrBlank() }?.let { torboxApiKey = it }
        keys["realdebrid_api_key"]?.takeIf { it.isNotBlank() && realDebridApiKey.isNullOrBlank() }?.let { realDebridApiKey = it }
        keys["premiumize_api_key"]?.takeIf { it.isNotBlank() && premiumizeApiKey.isNullOrBlank() }?.let { premiumizeApiKey = it }
        keys["alldebrid_api_key"]?.takeIf { it.isNotBlank() && allDebridApiKey.isNullOrBlank() }?.let { allDebridApiKey = it }
        keys["debridlink_api_key"]?.takeIf { it.isNotBlank() && debridLinkApiKey.isNullOrBlank() }?.let { debridLinkApiKey = it }
        keys["offcloud_api_key"]?.takeIf { it.isNotBlank() && offcloudApiKey.isNullOrBlank() }?.let { offcloudApiKey = it }
        keys["trakt_access_token"]?.takeIf { it.isNotBlank() && traktAccessToken.isNullOrBlank() }?.let { traktAccessToken = it }
        keys["trakt_refresh_token"]?.takeIf { it.isNotBlank() && traktRefreshToken.isNullOrBlank() }?.let { traktRefreshToken = it }
        keys["simkl_token"]?.takeIf { it.isNotBlank() && simklToken.isNullOrBlank() }?.let { simklToken = it }
        keys["simkl_refresh_token"]?.takeIf { it.isNotBlank() && simklRefreshToken.isNullOrBlank() }?.let { simklRefreshToken = it }
        keys["tmdb_api_key"]?.takeIf { it.isNotBlank() && tmdbApiKey.isNullOrBlank() }?.let { tmdbApiKey = it }
        keys["mdblist_api_key"]?.takeIf { it.isNotBlank() && mdblistApiKey.isNullOrBlank() }?.let { mdblistApiKey = it }
    }

    /**
     * Restores preferences from an export map. Unknown keys and wrong-typed
     * values are skipped; StringSet values are restored as string sets.
     */
    fun importAllPrefs(values: Map<String, Any?>) {
        val e = prefs.edit()
        // Backup restore replaces portable settings instead of merging; keep
        // Keystore secrets and local first-run/privacy consent state untouched.
        prefs.all.keys.filterNot { key -> key in SECRET_KEYS || key == KEY_ONBOARDING_DONE ||
            key.contains("privacy", ignoreCase = true) || key.contains("consent", ignoreCase = true) }
            .forEach(e::remove)
        for ((k, v) in values) {
            if (k in SECRET_KEYS || k == KEY_ONBOARDING_DONE || k.contains("privacy", true) || k.contains("consent", true)) continue
            when (v) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Float -> e.putFloat(k, v)
                is Double -> e.putFloat(k, v.toFloat())
                is String -> e.putString(k, v)
                is Set<*> -> {
                    @Suppress("UNCHECKED_CAST")
                    e.putStringSet(k, (v as Set<*>).map { it.toString() }.toSet())
                }
                is List<*> -> {
                    // org.json turns JSON arrays into Lists; prefs string-sets
                    // are the only collection type we store.
                    e.putStringSet(k, v.map { it.toString() }.toSet())
                }
                null -> e.remove(k)
            }
        }
        check(e.commit()) { "Could not apply backup settings." }
    }

    // ------------------------------------------------------------------
    // Plavio account sync controls (owner's orders 2026-10-29): silent
    // auto-backup on app open + per-category "What to sync" choices.
    // Plain preferences (not secrets), so they ride the settings section
    // of the backup itself and follow the user across devices.
    // ------------------------------------------------------------------

    /** Silent account backup shortly after app open. Default ON. */
    var autoBackupEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_BACKUP, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_BACKUP, value).apply()

    // ---- Validate-on-save verdicts (P5, v0.14.22) ----
    // "working" = the service accepted the key at save time;
    // "rejected" = the service answered but refused it; null = never
    // probed (or key cleared). Persisted so the Integrations rows can
    // show an HONEST status instead of deriving "On"/"Connected" from
    // non-blankness.
    private fun keyStatus(key: String): String? = prefs.getString(key, null)
    private fun putKeyStatus(key: String, value: String?) {
        val e = prefs.edit()
        if (value == null) e.remove(key) else e.putString(key, value)
        e.apply()
    }
    var tmdbKeyStatus: String?
        get() = keyStatus(KEY_TMDB_KEY_STATUS)
        set(value) = putKeyStatus(KEY_TMDB_KEY_STATUS, value)
    var mdblistKeyStatus: String?
        get() = keyStatus(KEY_MDBLIST_KEY_STATUS)
        set(value) = putKeyStatus(KEY_MDBLIST_KEY_STATUS, value)
    var torboxKeyStatus: String?
        get() = keyStatus(KEY_TORBOX_KEY_STATUS)
        set(value) = putKeyStatus(KEY_TORBOX_KEY_STATUS, value)
    /**
     * The TorBox account label captured at connect time (v0.14.24,
     * item 4): the account email — plus plan when the service sends
     * one — from the same /user/me call that verifies the key, so a
     * connected Integrations row can show WHICH account is connected.
     * Null when the key was never verified or on disconnect.
     */
    /**
     * PrePlay (item 13, v0.14.24): streams resolve in the background
     * when a title's Details page opens (and the next episode while
     * one plays) so the play press is instant. OFF by default at
     * first ship (owner's staged word 2026-11-06).
     */
    var prePlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_PREPLAY_ENABLED, false)
        set(value) { prefs.edit().putBoolean(KEY_PREPLAY_ENABLED, value).apply() }

    var torboxAccountLabel: String?
        get() = prefs.getString(KEY_TORBOX_ACCOUNT_LABEL, null)
        set(value) {
            val e = prefs.edit()
            if (value == null) e.remove(KEY_TORBOX_ACCOUNT_LABEL) else e.putString(KEY_TORBOX_ACCOUNT_LABEL, value)
            e.apply()
        }
    var realDebridKeyStatus: String?
        get() = keyStatus(KEY_RD_KEY_STATUS)
        set(value) = putKeyStatus(KEY_RD_KEY_STATUS, value)
    var premiumizeKeyStatus: String?
        get() = keyStatus(KEY_PREMIUMIZE_KEY_STATUS)
        set(value) = putKeyStatus(KEY_PREMIUMIZE_KEY_STATUS, value)
    var allDebridKeyStatus: String?
        get() = keyStatus(KEY_ALLDEBRID_KEY_STATUS)
        set(value) = putKeyStatus(KEY_ALLDEBRID_KEY_STATUS, value)
    var debridLinkKeyStatus: String?
        get() = keyStatus(KEY_DEBRIDLINK_KEY_STATUS)
        set(value) = putKeyStatus(KEY_DEBRIDLINK_KEY_STATUS, value)
    var offcloudKeyStatus: String?
        get() = keyStatus(KEY_OFFCLOUD_KEY_STATUS)
        set(value) = putKeyStatus(KEY_OFFCLOUD_KEY_STATUS, value)

    // ---- Auto-backup visibility (P2, v0.14.22) ----
    /** True while a due auto-backup still owes an upload (persisted, so a
     * process death before the +90 s timer cannot silently drop it). */
    var autoBackupPending: Boolean
        get() = prefs.getBoolean(KEY_AUTO_BACKUP_PENDING, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_BACKUP_PENDING, value).apply()
    /** Last auto-backup outcome, user/log-visible: "backed-up" /
     * "held-by-guard" / "not-due" / "failed: <reason>". */
    var autoBackupLastState: String
        get() = prefs.getString(KEY_AUTO_BACKUP_STATE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTO_BACKUP_STATE, value).apply()

    var syncCatSettings: Boolean
        get() = prefs.getBoolean(KEY_SYNC_CAT_SETTINGS, true)
        set(value) = prefs.edit().putBoolean(KEY_SYNC_CAT_SETTINGS, value).apply()

    var syncCatAddons: Boolean
        get() = prefs.getBoolean(KEY_SYNC_CAT_ADDONS, true)
        set(value) = prefs.edit().putBoolean(KEY_SYNC_CAT_ADDONS, value).apply()

    var syncCatLibrary: Boolean
        get() = prefs.getBoolean(KEY_SYNC_CAT_LIBRARY, true)
        set(value) = prefs.edit().putBoolean(KEY_SYNC_CAT_LIBRARY, value).apply()

    var syncCatProgress: Boolean
        get() = prefs.getBoolean(KEY_SYNC_CAT_PROGRESS, true)
        set(value) = prefs.edit().putBoolean(KEY_SYNC_CAT_PROGRESS, value).apply()

    var syncCatKeys: Boolean
        get() = prefs.getBoolean(KEY_SYNC_CAT_KEYS, true)
        set(value) = prefs.edit().putBoolean(KEY_SYNC_CAT_KEYS, value).apply()

    /**
     * The payload categories the account backup includes, built from the
     * "What to sync" toggles — the backup builder (via
     * PlavioAccountManager) reads exactly this set. All default ON, so a
     * silent auto-backup covers everything unless the user opts out.
     */
    fun syncEnabledCategories(): Set<String> = buildSet {
        if (syncCatSettings) add("settings")
        if (syncCatAddons) add("addons")
        if (syncCatLibrary) {
            add("watchlist")
            add("custom_lists")
            add("search_history")
        }
        if (syncCatProgress) add("watch_history")
        if (syncCatKeys) add("api_keys")
    }

    companion object {
        private const val SECRET_KEY_ALIAS = "plavio.settings.secrets.v1"
        private val SECRET_KEYS = setOf(
            "simkl_token", "simkl_refresh_token", "torbox_api_key", "realdebrid_api_key",
            "trakt_access_token", "trakt_refresh_token",
            "mdblist_api_key", "tmdb_api_key"
        )
        private const val KEY_AUTO_BACKUP = "account_auto_backup"
        private const val KEY_SYNC_CAT_SETTINGS = "sync_cat_settings"
        private const val KEY_SYNC_CAT_ADDONS = "sync_cat_addons"
        private const val KEY_SYNC_CAT_LIBRARY = "sync_cat_library"
        private const val KEY_SYNC_CAT_PROGRESS = "sync_cat_progress"
        private const val KEY_SYNC_CAT_KEYS = "sync_cat_keys"
        private const val KEY_AUTOPLAY = "autoplay"
        private const val KEY_SENTRY_ENABLED = "sentry_enabled"
        private const val KEY_AUTOPLAY_NEXT = "autoplay_next_episode"
        private const val KEY_SHUFFLE_EPISODES = "shuffle_episodes"
        private const val KEY_PIP_ENABLED = "pip_enabled"
        private const val KEY_CW_ARTWORK_POSTER = "cw_artwork_poster"
        private const val KEY_EPISODE_NOTIFICATIONS = "episode_notifications"
        private const val KEY_MOVIE_NOTIFICATIONS = "movie_notifications"
        private const val KEY_DOWNLOAD_FINISHED_NOTIFICATIONS = "download_finished_notifications"
        private const val KEY_HOME_META_PROVIDER = "home_meta_provider_addon_id"
        private const val KEY_HOME_CATALOG_ON = "home_catalog_on_keys"
        private const val KEY_HOME_CATALOG_OFF = "home_catalog_off_keys"
        private const val KEY_HOME_CATALOG_ORDER = "home_catalog_order_keys"
        private const val KEY_PREFERRED_PLAYER = "preferred_player"
        private const val KEY_BUFFER_MIN_MS = "buffer_min_ms"
        private const val KEY_BUFFER_MAX_MS = "buffer_max_ms"
        private const val KEY_BUFFER_FOR_PLAYBACK_MS = "buffer_for_playback_ms"
        private const val KEY_DISK_CACHE_MB = "disk_cache_mb"
        private const val KEY_ONBOARDING_DONE = "onboarding_done"
        
        private const val KEY_AUDIO_LANG = "preferred_audio_language"
        private const val KEY_SUB_COLOR = "subtitle_text_color"
        private const val KEY_SUB_SIZE = "subtitle_text_size_scale"
        private const val KEY_SUB_BG = "subtitle_background_color"
        private const val KEY_SUB_EDGE = "subtitle_edge_type"
        private const val KEY_SUB_BOLD = "subtitle_bold"
        private const val KEY_SUB_EDGE_COLOR = "subtitle_edge_color"
        private const val KEY_SUB_BOTTOM = "subtitle_bottom_offset"
        private const val KEY_SUB_FONT_SP = "subtitle_font_size_sp"
        private const val KEY_SUB_DELAY_MAP = "subtitle_delay_by_video"
        private const val KEY_SUB_CHOICE_MAP = "subtitle_choice_by_title"
        private const val KEY_UNSEEKABLE_HOSTS = "unseekable_hosts"
        private const val KEY_SUBTITLE_OFFSET_MS = "subtitle_offset_ms"
        private const val KEY_SYSTEM_CAPTIONS = "use_system_captions"
        private const val KEY_LIVE_FAVS = "live_favorites"
        private const val KEY_LIVE_RECENT = "live_recent"
        private const val KEY_M3U_LISTS = "m3u_playlists"
        private const val KEY_HOME_REFRESHED_AT = "home_catalogs_refreshed_at"
        private const val KEY_MANIFEST_STORE = "manifest_store_json"
        private const val KEY_PENDING_CATALOG = "pending_catalog_identity"
        private const val KEY_KEEP_SCREEN_ON = "keep_screen_on"
        private const val KEY_FORCE_SEEK_ANY_STREAM = "force_seek_any_stream"
        private const val KEY_SHOW_SKIP = "show_skip_button"
        private const val KEY_SUBTITLE_LANGS = "subtitle_languages"
        private const val KEY_SUB_DEFAULT_MODE = "subtitle_default_mode"
        private const val KEY_SUB_ONLY_MY_LANGS = "subtitle_only_my_languages"
        private const val KEY_SUB_PREFER_SDH = "subtitle_prefer_sdh"
        private const val KEY_SUB_FORCED_AUTO = "subtitle_forced_auto_show"
        private const val KEY_SUB_FONT = "subtitle_font_family"
        private const val KEY_SUB_SAVE_DOWNLOADS = "subtitle_save_with_downloads"
        private const val KEY_SUB_AUTO_FETCH = "subtitle_auto_fetch_online"
        private const val KEY_PLAYBACK_ENGINE = "playback_engine"
        private const val KEY_AUTO_ENGINE_FAILOVER = "auto_engine_failover"
        private const val KEY_MPV_HWDEC = "mpv_hardware_decoding"
        private const val KEY_MPV_YUV420P = "mpv_yuv420p_filter"
        private const val KEY_ACCENT = "accent_theme"
        private const val KEY_POSTER_SIZE = "appearance_poster_size"
        private const val KEY_TEXT_SIZE = "appearance_text_size"
        private const val KEY_LAYOUT_SPACING = "appearance_layout_spacing"
        private const val KEY_CARD_CORNERS = "appearance_card_corners"
        private const val KEY_STARTUP_ANIMATION = "appearance_startup_animation"
        private const val KEY_ANIMATIONS = "appearance_animations"
        private const val KEY_DOCK_GLASS_BLUR = "appearance_dock_glass_blur"
        private const val KEY_ACTIVE_PROFILE = "active_profile_id"
        private const val KEY_DEFAULT_PROFILE = "default_profile_id"
        private const val KEY_PENDING_SWITCH_PROFILE = "pending_switch_profile_id"
        private const val KEY_PROFILE_USER_NAME = "profile_user_name"
        private const val KEY_PROFILE_AVATAR = "profile_avatar"
        private const val KEY_CW_DISMISSED = "cw_dismissed_identities"
        private const val KEY_LIBRARY_SYNCED = "library_synced_keys"
        private const val KEY_LIBRARY_SYNC_AT = "library_sync_last_at"
        private const val KEY_LIBRARY_SYNC_RESULT = "library_sync_last_result"
        private const val KEY_AMOLED = "amoled_black"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_APP_THEME = "app_theme"
        private const val KEY_PREINSTALL_PREFIX = "preinstall_done_"
        private const val KEY_SIMKL_TOKEN = "simkl_token"
        private const val KEY_SIMKL_REFRESH = "simkl_refresh_token"
        private const val KEY_SIMKL_ISSUED_AT = "simkl_token_issued_at"
        private const val KEY_SIMKL_USERNAME = "simkl_username"
        private const val KEY_TRAKT_TOKEN = "trakt_access_token"
        private const val KEY_TRAKT_REFRESH = "trakt_refresh_token"
        private const val KEY_TRAKT_EXPIRY = "trakt_token_expiry"
        private const val KEY_TRAKT_USERNAME = "trakt_username"
        private const val KEY_TORBOX_API_KEY = "torbox_api_key"
        private const val KEY_REALDEBRID_API_KEY = "realdebrid_api_key"
        private const val KEY_PREMIUMIZE_API_KEY = "premiumize_api_key"
        private const val KEY_ALLDEBRID_API_KEY = "alldebrid_api_key"
        private const val KEY_DEBRIDLINK_API_KEY = "debridlink_api_key"
        private const val KEY_OFFCLOUD_API_KEY = "offcloud_api_key"
        private const val KEY_MDBLIST_API_KEY = "mdblist_api_key"
        private const val KEY_MDBLIST_DISABLED_SOURCES = "mdblist_disabled_sources"
        private const val KEY_MDBLIST_KNOWN_SOURCES = "mdblist_known_sources"
        private const val KEY_MDBLIST_RATINGS_CACHE = "mdblist_ratings_cache_json"
        private const val KEY_RATINGS_ENDPOINT_CACHE = "ratings_endpoint_cache_v1"
        private const val KEY_TMDB_API_KEY = "tmdb_api_key"
        private const val KEY_TMDB_ENRICH_ARTWORK = "tmdb_enrich_artwork"
        private const val KEY_TMDB_ENRICH_BASIC = "tmdb_enrich_basic_info"
        private const val KEY_TMDB_ENRICH_DETAILS = "tmdb_enrich_details"
        private const val KEY_TMDB_ENRICH_CREDITS = "tmdb_enrich_credits"
        private const val KEY_TMDB_ENRICH_PRODUCTIONS = "tmdb_enrich_productions"
        private const val KEY_TMDB_ENRICH_NETWORKS = "tmdb_enrich_networks"
        private const val KEY_TMDB_ENRICH_EPISODES = "tmdb_enrich_episodes"
        private const val KEY_STREAM_SIZE_BADGES = "stream_size_badges"
        private const val KEY_STREAM_BADGE_TOP = "stream_badge_top"
        private const val KEY_STREAM_ADDON_LOGOS = "stream_addon_logos"
        private const val KEY_STREAM_CAPSULE_STYLE = "stream_capsule_style"
        private const val KEY_IMPORTED_BADGE_PACK_NAME = "imported_badge_pack_name"
        private const val KEY_FUSION_BADGE_SOURCES = "fusion_badge_sources"
        private const val KEY_STREAM_CAPSULE_GROUP_RESOLUTION = "stream_capsule_group_resolution"
        private const val KEY_STREAM_CAPSULE_GROUP_HDR = "stream_capsule_group_hdr"
        private const val KEY_STREAM_CAPSULE_GROUP_AUDIO = "stream_capsule_group_audio"
        private const val KEY_STREAM_CAPSULE_GROUP_LANGUAGES = "stream_capsule_group_languages"
        private const val KEY_STREAM_CAPSULE_GROUP_SOURCE_CODEC = "stream_capsule_group_source_codec"
        private const val KEY_GOOGLE_MIGRATION_SHOWN = "google_migration_prompt_shown"
        private const val KEY_QUALITY_ORDER = "quality_order"
        private const val KEY_STREAM_AUTOPLAY = "stream_autoplay"
        private const val KEY_AUTOPLAY_QUALITY = "autoplay_quality"
        private const val KEY_AUTOPLAY_MAX_SIZE = "autoplay_max_size_gb"
        const val CLOUD_ENC_PREFIX = "PLAVIO-CLOUD-ENC:1\n"
        private const val KEY_TORBOX_ACCOUNT_LABEL = "torbox_account_label"
        private const val KEY_PREPLAY_ENABLED = "preplay_enabled"
        private const val KEY_TMDB_KEY_STATUS = "tmdb_key_status"
        private const val KEY_MDBLIST_KEY_STATUS = "mdblist_key_status"
        private const val KEY_TORBOX_KEY_STATUS = "torbox_key_status"
        private const val KEY_RD_KEY_STATUS = "realdebrid_key_status"
        private const val KEY_PREMIUMIZE_KEY_STATUS = "premiumize_key_status"
        private const val KEY_ALLDEBRID_KEY_STATUS = "alldebrid_key_status"
        private const val KEY_DEBRIDLINK_KEY_STATUS = "debridlink_key_status"
        private const val KEY_OFFCLOUD_KEY_STATUS = "offcloud_key_status"
        private const val KEY_AUTO_BACKUP_PENDING = "auto_backup_pending"
        private const val KEY_AUTO_BACKUP_STATE = "auto_backup_last_state"
    }
}
