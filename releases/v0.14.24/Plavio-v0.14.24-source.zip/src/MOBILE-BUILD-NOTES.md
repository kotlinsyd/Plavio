# Plavio 0.11.8 — mobile build notes

This project is derived from the exact supplied `Plavio-0.11.7-mobile-source.zip`. Package: `com.pulsestream.app`; version: **0.11.8**, versionCode **89**. The only production Kotlin change is the active public legacy anon key literal in `CloudManager.kt`; all 0.11.7 Live/fallback code remains unchanged. The version metadata is bumped for installation as an update. Read `REPAIR-0.11.8.md` and `docs/validation-summary.txt` for current results. Older repair/configuration notes are retained as history, not current status.

## Build mobile only

Use JDK 17, Android SDK Platform 35 and Build Tools 35.0.0. Set `ANDROID_HOME`, or create your own untracked `local.properties` with `sdk.dir`. The included Gradle wrapper uses 8.10.2; first-time builds need dependency-download access.

```sh
chmod +x gradlew
./gradlew --no-daemon \
  :app:testMobileDebugUnitTest \
  :app:assembleMobileDebug \
  :app:lintMobileDebug \
  :app:writeMobileDependencyInventory
```

APK: `app/build/outputs/apk/mobile/debug/app-mobile-debug.apk`.

The configuration unit tests run offline. To explicitly recheck public gateway acceptance without login or data queries:

```sh
python3 scripts/verify-public-auth-settings.py --write-evidence
python3 scripts/scan-source-secrets.py
```

The verifier logs neither key nor response body and accepts only the intended HTTPS public settings endpoint. No service-role key is required or permitted.

## Signing and native compatibility

This delivered APK uses the available local debug certificate; its comparison with the previous APK is recorded in the validation summary. A source rebuild on another computer normally uses a different debug certificate. No production signing key is included. Back up important app data; do not uninstall just to work around a signer conflict.

The original ARM FFmpeg JNI binaries and renderer factories are retained byte-for-byte, preserving the existing audio path. Their inherited 16 KiB native alignment limitation is not repaired by this configuration-only change; see `docs/native-build-provenance.md`. APK ZIP alignment and native ELF segment alignment are different checks.

Source distribution excludes build caches, local SDK paths, generated APKs and private signing material. No TV build/test, backend change, push, deployment, account login, user-data query, saved credential use or media-provider playback occurred in this repair.
