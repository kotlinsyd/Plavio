package com.github.damontecres.wholphin.plavio.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.BoundedHttp
import com.github.damontecres.wholphin.plavio.InstalledAddon
import com.github.damontecres.wholphin.plavio.cloud.PlavioAccountManager
import com.github.damontecres.wholphin.plavio.cloud.PlavioBackup
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.SerializationException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject

data class PlavioSetupUiState(
    val adding: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    /** Ids of addons with a manifest refresh in flight (v0.3.1). */
    val refreshingIds: Set<String> = emptySet(),
    /** Outcome of the last refresh, shown under the addon list header. */
    val refreshNote: String? = null,
    val refreshNoteIsError: Boolean = false,
    /** Account addons-sync in flight (v0.3.16 "Sync from account"). */
    val syncing: Boolean = false,
)

@HiltViewModel
class PlavioSetupViewModel
    @Inject
    constructor(
        @param:ApplicationContext context: Context,
        backup: PlavioBackup,
        private val addonStore: AddonStore,
        private val uiPrefs: com.github.damontecres.wholphin.plavio.PlavioUiPrefs,
    ) : ViewModel() {
        // PlavioAccountManager has no @Inject constructor — built by
        // hand exactly like PlavioAccountsViewModel builds it.
        private val accountManager = PlavioAccountManager(context, backup)
        val addons: StateFlow<List<InstalledAddon>> = addonStore.addons

        /** The chosen default catalog addon (v0.3.16, note 6). */
        val defaultCatalogAddonId: StateFlow<String?> = uiPrefs.defaultCatalogAddonId

        fun setDefaultCatalogAddon(id: String) {
            viewModelScope.launch { uiPrefs.setDefaultCatalogAddonId(id) }
        }

        private val _uiState = MutableStateFlow(PlavioSetupUiState())
        val uiState: StateFlow<PlavioSetupUiState> = _uiState

        init {
            viewModelScope.launch {
                addonStore.ensureHouseAddons()
            }
        }

        fun addAddon(url: String) {
            if (_uiState.value.adding) return
            _uiState.update { it.copy(adding = true, statusMessage = null, errorMessage = null) }
            viewModelScope.launch {
                addonStore
                    .addAddon(url)
                    .onSuccess { addon ->
                        _uiState.update {
                            it.copy(adding = false, statusMessage = addon.name)
                        }
                    }.onFailure { e ->
                        _uiState.update {
                            it.copy(adding = false, errorMessage = e.message)
                        }
                    }
            }
        }

        fun removeAddon(id: String) {
            viewModelScope.launch {
                addonStore.removeAddon(id)
            }
        }

        /**
         * Short, honest reason a manifest refresh failed (v0.3.24).
         * Until now EVERY failure — an HTTP status from the addon's
         * server, an unreadable reply, a timeout — was reported as
         * "Check your connection", which blamed the user's network
         * for faults that were never his (proven live 2026-11-09:
         * PlavioLive's manifest answers HTTP 402, deployment
         * disabled, while the other factory addons answer 200 — one
         * such addon failed every Refresh and the note lied about
         * why). The reason is read off the real exception; the
         * connection is only named when the addon genuinely could
         * not be reached.
         */
        private fun refreshFailureReason(error: Throwable): String {
            val chain = generateSequence(error) { it.cause }.toList()
            chain.filterIsInstance<BoundedHttp.HttpFailure>().firstOrNull()?.let {
                return "the server answered HTTP ${it.statusCode}"
            }
            if (chain.any { it is SocketTimeoutException || it is InterruptedIOException }) {
                return "it timed out"
            }
            if (chain.any { it is UnknownHostException || it is ConnectException }) {
                return "it couldn't be reached"
            }
            if (chain.any { it is SerializationException }) {
                return "it sent a reply the app couldn't read"
            }
            return "it failed"
        }

        /**
         * Refresh one addon's manifest from its server (v0.3.1, phone
         * parity). The note mirrors the phone's wording: updated to a
         * new version, already up to date, or the failure.
         */
        fun refreshAddon(addon: InstalledAddon) {
            if (addon.id in _uiState.value.refreshingIds) return
            _uiState.update {
                it.copy(
                    refreshingIds = it.refreshingIds + addon.id,
                    refreshNote = null,
                )
            }
            viewModelScope.launch {
                val oldVersion = addon.manifest.version
                val note: Pair<String, Boolean> =
                    addonStore
                        .refreshAddon(addon.id)
                        .fold(
                            onSuccess = { updated ->
                                val newVersion = updated.manifest.version
                                if (oldVersion.isNotBlank() && newVersion.isNotBlank() &&
                                    oldVersion != newVersion
                                ) {
                                    "${addon.name} updated: v$oldVersion → v$newVersion" to false
                                } else if (newVersion.isNotBlank()) {
                                    "${addon.name} is already up to date (v$newVersion)" to false
                                } else {
                                    "${addon.name} refreshed" to false
                                }
                            },
                            onFailure = { e ->
                                "Couldn't refresh ${addon.name} — ${refreshFailureReason(e)}." to true
                            },
                        )
                _uiState.update {
                    it.copy(
                        refreshingIds = it.refreshingIds - addon.id,
                        refreshNote = note.first,
                        refreshNoteIsError = note.second,
                    )
                }
            }
        }

        /** Refresh every installed addon's manifest (the header Refresh button). */
        fun refreshAllAddons() {
            val targets = addons.value.filter { it.id !in _uiState.value.refreshingIds }
            if (targets.isEmpty()) return
            _uiState.update {
                it.copy(
                    refreshingIds = it.refreshingIds + targets.map { a -> a.id },
                    refreshNote = null,
                )
            }
            viewModelScope.launch {
                // v0.3.24: a failure names its addon and its real
                // reason, and the addons that DID refresh are
                // reported as refreshed — until now one dead addon
                // made the whole refresh read as a network failure
                // (see refreshFailureReason).
                val failures = mutableListOf<String>()
                targets.forEach { addon ->
                    addonStore.refreshAddon(addon.id).onFailure { e ->
                        failures += "${addon.name} (${refreshFailureReason(e)})"
                    }
                    _uiState.update {
                        it.copy(refreshingIds = it.refreshingIds - addon.id)
                    }
                }
                _uiState.update {
                    it.copy(
                        refreshNote =
                            if (failures.isEmpty()) {
                                "Addons refreshed"
                            } else {
                                "Refreshed ${targets.size - failures.size} of ${targets.size} addons. " +
                                    "Couldn't refresh: ${failures.joinToString(", ")}."
                            },
                        refreshNoteIsError = failures.isNotEmpty(),
                    )
                }
            }
        }

        fun setAddonEnabled(
            id: String,
            enabled: Boolean,
        ) {
            viewModelScope.launch {
                addonStore.setEnabled(id, enabled)
            }
        }

        /**
         * "Sync from account" (v0.3.16, Sample B addons layout): the
         * same addons-only account sync the Account screen runs
         * (v0.3.14) — the phone's addons merge into this TV through
         * [PlavioAccountManager.syncAddonsFromAccount]; the note
         * wording matches the account screen's exactly.
         */
        fun syncAddonsFromAccount() {
            if (_uiState.value.syncing) return
            _uiState.update { it.copy(syncing = true, refreshNote = null) }
            viewModelScope.launch {
                val note: Pair<String, Boolean> =
                    accountManager
                        .syncAddonsFromAccount()
                        .fold(
                            onSuccess = { added ->
                                when {
                                    added == null ->
                                        "No backup found on this account yet." to false
                                    added == 0 ->
                                        "No new addons — this TV already has them all." to false
                                    added == 1 ->
                                        "1 addon added from your account." to false
                                    else ->
                                        "$added addons added from your account." to false
                                }
                            },
                            onFailure = { e ->
                                if (e.message?.contains("Not signed in") == true) {
                                    "Sign in from the tray's Account first, then sync." to true
                                } else {
                                    "Couldn't sync addons from your account. Check your connection and try again." to true
                                }
                            },
                        )
                _uiState.update {
                    it.copy(
                        syncing = false,
                        refreshNote = note.first,
                        refreshNoteIsError = note.second,
                    )
                }
            }
        }
    }
