package com.github.damontecres.wholphin.preferences

/**
 * The app-specific preferences for the current user
 */
data class UserPreferences(
    val appPreferences: AppPreferences,
)
