@file:OptIn(markerClass = [UnstableApi::class])

package com.github.damontecres.wholphin.services

import android.app.ActivityManager
import android.content.Context
import android.media.AudioFormat
import android.os.Build
import android.os.Handler
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters.AudioOffloadPreferences
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer
import androidx.media3.decoder.ffmpeg.FfmpegLibrary
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.exoplayer.video.VideoRendererEventListener
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.session.MediaSession
import com.github.damontecres.wholphin.plavio.CrashReports
import com.github.damontecres.wholphin.preferences.AppPreferences
import com.github.damontecres.wholphin.preferences.AssPlaybackMode
import com.github.damontecres.wholphin.preferences.MediaExtensionStatus
import com.github.damontecres.wholphin.preferences.PlayerBackend
import com.github.damontecres.wholphin.preferences.get
import com.github.damontecres.wholphin.services.hilt.AuthOkHttpClient
import com.github.damontecres.wholphin.util.BitstreamFilteringCodecAdapterFactory
import com.github.damontecres.wholphin.util.Hdr10PlusMaskingFilter
import com.github.damontecres.wholphin.util.WholphinDispatchers
import dagger.hilt.android.qualifiers.ApplicationContext
import io.github.peerless2012.ass.media.AssHandler
import io.github.peerless2012.ass.media.factory.AssRenderersFactory
import io.github.peerless2012.ass.media.kt.withAssMkvSupport
import io.github.peerless2012.ass.media.parser.AssSubtitleParserFactory
import io.github.peerless2012.ass.media.type.AssRenderType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import timber.log.Timber
import java.lang.reflect.Constructor
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Constructs a [Player] instance for video playback
 */
@Singleton
class PlayerFactory
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        @param:AuthOkHttpClient private val authOkHttpClient: OkHttpClient,
    ) {
        @Volatile
        var currentPlayer: Player? = null
            private set

        /**
         * The [AssHandler] built for [currentPlayer], when that
         * creation engaged libass (v0.3.19). The handler owns a
         * native libass instance that ONLY [AssHandler.release]
         * frees — releasing the player does not free it. Whoever
         * tears the player down releases its handler exactly once:
         * the owning ViewModel for its own players (it calls
         * [forgetPlayer] as part of its teardown, which clears this
         * pairing), or the straggler gate below for a player nobody
         * claimed. Before this pairing existed, every libass play
         * leaked its native handler for the rest of the app
         * session — a per-play accumulation on a 1–2 GB TV.
         */
        @Volatile
        private var currentAssHandler: AssHandler? = null

        /**
         * v0.3.22 (the 512 MB pass): is this TV in the low-RAM
         * class? The owner's set has 512 MB of RAM in TOTAL — its
         * per-app memory class lands at or below
         * [LOW_RAM_MEMORY_CLASS_MB], and Android Go / low-RAM sets
         * report [ActivityManager.isLowRamDevice] as well. Such a
         * box gets the low-RAM buffer profile in
         * [fastStartLoadControl]; anything stronger keeps today's
         * profile byte-for-byte. Only the player's APPETITE adapts
         * to the hardware — the stream served never does (owner's
         * locked rule, 2026-11-07: quality is the user's setting,
         * never the app's shortcut).
         */
        val lowRamDevice: Boolean by lazy {
            val activityManager =
                context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            activityManager != null &&
                (activityManager.isLowRamDevice ||
                    activityManager.memoryClass <= LOW_RAM_MEMORY_CLASS_MB)
        }

        /** The buffer-profile name for this device (logged once per play by the player ViewModel). */
        val bufferProfileName: String
            get() = if (lowRamDevice) "low-ram" else "standard"

        /**
         * v0.3.19: the owning ViewModel calls this as part of its
         * own teardown of [player], clearing the factory's pairing
         * so the straggler gate can never find (and re-tear-down)
         * a player that already died — and never releases an
         * [AssHandler] the ViewModel already released (a second
         * native release is a double-free risk).
         */
        fun forgetPlayer(player: Player) {
            if (currentPlayer === player) {
                currentPlayer = null
                currentAssHandler = null
            }
        }

        /**
         * Shared HTTP stack for video data (v0.3.2): OkHttp replaces
         * the default HttpURLConnection data source on the video path —
         * connection reuse and faster TLS on the old TV chipsets —
         * and one client is shared by every player the app creates.
         * Explicit timeouts (v0.3.9; OkHttp stock was 10 s/10 s):
         * connect 5 s so dead hosts fail fast, read 20 s — a
         * per-byte-gap limit, so slow-but-alive hosts stay safe.
         */
        private val videoHttpClient: OkHttpClient by lazy {
            OkHttpClient
                .Builder()
                .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                .build()
        }

        suspend fun createVideoPlayer(
            backend: PlayerBackend,
            appPreferences: AppPreferences,
            safeMode: Boolean = false,
            /**
             * v0.3.18: whether this playback actually carries an
             * ASS/SSA subtitle (a sidecar in the request). The libass
             * engine only engages when a format in play needs it —
             * see the useLibAss gate below.
             */
            hasAssSubtitles: Boolean = false,
        ): PlayerCreation {
            val prefs = appPreferences.playbackPreferences
            // v0.3.15 (the retry-loop fix): SEQUENCED release gate.
            // The three builds of this guard, and what each taught:
            //  - v0.3.10 (stable, played fine): the guard called
            //    release() on Main — Media3's release() blocks its
            //    caller until the teardown finishes, so the call
            //    SERIALIZED creation after teardown… at the price of
            //    parking the UI thread on the teardown.
            //  - v0.3.14 (the frozen-TV fix): fire-and-forget — the
            //    release went to a background thread and the new
            //    player was built IMMEDIATELY. The freeze died, but
            //    every failover rebuild now raced the old player's
            //    teardown for the TV's single video codec: codec
            //    init/configure against a still-held codec fails,
            //    the ladder steps, the next rebuild races again —
            //    the owner's "it open player then again start
            //    trying, retry retry, nothing play" (2026-11-05).
            //  - v0.3.15: keep 0.3.10's ORDER, lose its parking —
            //    WAIT for the teardown on a background dispatcher.
            //  - v0.3.16 (owner: "player was playing flawlessly in
            //    last stable, now no"): the 0.3.15 form is REVERTED
            //    to the stable v0.3.10 pattern. Proven against the
            //    bundled Media3 1.11.1 bytecode: ExoPlayerImpl's
            //    release() AND isReleased() both call
            //    verifyApplicationThread() — ANY player access off
            //    the application thread throws IllegalStateException
            //    ("Player is accessed on the wrong thread…"). The
            //    0.3.15 gate polled isReleased inside
            //    withContext(Default): the first poll threw, the
            //    throw propagated out of creation and surfaced
            //    verbatim as the player's error (the owner's photo),
            //    and the ViewModel's Default-thread release() calls
            //    threw silently inside runCatching, so the codec was
            //    never freed at all — every start with a straggler
            //    hit the same wall ("hit or miss"). The stable
            //    guard never touched the player off Main: it
            //    released the straggler right here, on the main
            //    thread — Media3's release() blocks its caller until
            //    the teardown finishes, which SERIALIZES creation
            //    after teardown. That is the whole gate again: every
            //    player call on Main, no background waiting, no
            //    background release. The no-overlap guarantee the
            //    0.3.15 gate wanted is kept — it is exactly what the
            //    stable guard's blocking release always provided.
            //  - v0.3.18 (owner: the player still freezes on
            //    start/switch/retry): the ORDER above is untouched —
            //    release() still runs here, on Main, serializing
            //    creation after teardown, because the thread rule
            //    leaves no other legal shape. What changes is the
            //    state the player is in when release() runs: the
            //    pipeline is EMPTIED first — pause → stop → clear
            //    media items → clear the video surface — the
            //    reference player's dispose order. A release() on a
            //    full player (codec chewing buffered media) parks
            //    Main for the whole codec teardown; on an emptied
            //    player there is almost nothing left to tear down,
            //    so the park shrinks to the floor the thread rule
            //    itself imposes.
            val straggler = currentPlayer
            if (straggler != null) {
                currentPlayer = null
                val stragglerHandler = currentAssHandler
                currentAssHandler = null
                withContext(WholphinDispatchers.Main) {
                    runCatching {
                        if (!straggler.isReleased) {
                            Timber.w("Player was not released before trying to create a new one!")
                            straggler.pause()
                            straggler.stop()
                            straggler.clearMediaItems()
                            (straggler as? ExoPlayer)?.clearVideoSurface()
                            straggler.release()
                        }
                    }.onFailure { Timber.w(it, "Failed to release straggler player") }
                    // v0.3.19: a straggler's libass handler dies
                    // with it (see currentAssHandler) — the gate is
                    // the only teardown this player will ever get.
                    stragglerHandler?.let { handler ->
                        runCatching { handler.release() }
                            .onFailure { Timber.w(it, "Failed to release straggler AssHandler") }
                    }
                }
            }
            var assHandler: AssHandler? = null
            // ExoPlayer is the only engine (v0.3.2): the MPV backend,
            // its AAR and the backend switcher are removed entirely.
            val buildExoPlayer: suspend () -> Player = {
                        val extensions = prefs.overrides.mediaExtensionsEnabled
                        // Safe mode (v0.3.12, the recovery ladder's
                        // second configuration — see
                        // PlavioPlayerViewModel.recreateInSafeMode):
                        // the fragile extras come OFF. No libass (its
                        // native init is a crash risk on 32-bit boxes),
                        // no FFmpeg-first renderer order, no tunnelled
                        // playback (a classic audio-but-black cause on
                        // cheap chipsets). MediaCodec leads, extensions
                        // stay available as format fallback.
                        // v0.3.18: libass is no longer the unconditional
                        // shape of every player. The native ASS engine
                        // (AssHandler init + AssRenderer + wrapped media
                        // source factory) now engages only when the
                        // user's mode allows it AND this playback
                        // actually carries an ASS/SSA subtitle — the
                        // one format that needs it. Every other title
                        // gets the lighter stock text path (Media3's
                        // own parsers render SRT/VTT/TTML and embedded
                        // SSA as cues), which is also the more reliable
                        // sidecar path (see the 0.3.18 subtitle fix in
                        // PlavioPlayerViewModel).
                        val useLibAss =
                            !safeMode &&
                                prefs.overrides.assPlaybackMode == AssPlaybackMode.ASS_LIBASS &&
                                hasAssSubtitles
                        val decodeAv1 = prefs.overrides.decodeAv1
                        // Audio passthrough (v0.3.10): the user's
                        // Settings switch. Safe mode ignores it — the
                        // recovery configuration never passes audio
                        // through untouched.
                        val passthroughAudio =
                            !safeMode && prefs.overrides.audioPassthrough
                        val preferDolbyVision =
                            appPreferences.experimentalPreferences
                                .get { preferDolbyVisionOverHdr10Plus } ?: false
                        Timber.v(
                            "extensions=%s, assPlaybackMode=%s, safeMode=%s",
                            extensions,
                            prefs.overrides.assPlaybackMode,
                            safeMode,
                        )
                        // v0.3.18 (owner: the player still freezes —
                        // diagnosis cause #2): platform decoding now
                        // leads for audio too. The old order PREFERred
                        // extension renderers and PREPENDED the FFmpeg
                        // software audio renderer, so every E-AC-3 /
                        // AC-3 / DTS / TrueHD track was software-
                        // decoded on the TV's weak 32-bit CPU for the
                        // whole runtime. Extension mode is now ON in
                        // both configurations: MediaCodecAudioRenderer
                        // goes first, the stock factory APPENDS the
                        // FFmpeg renderer as a fallback, and a track
                        // the platform cannot decode still falls to
                        // FFmpeg and plays — the capability survives,
                        // the permanent CPU tax does not. (This is the
                        // arrangement safe mode always used; what was
                        // the recovery configuration's audio order is
                        // now the everyday order. Passthrough is
                        // unaffected — it already skipped the prepend,
                        // and MediaCodec now also wins the order, so
                        // the encoded stream reaches the output
                        // untouched as before.)
                        val rendererMode = DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                        val dataSourceFactory =
                            DefaultDataSource.Factory(
                                context,
                                OkHttpDataSource.Factory(videoHttpClient),
                            )
                        val extractorsFactory = createExtractorsFactory()
                        var renderersFactory: RenderersFactory =
                            WholphinRenderersFactory(
                                context,
                                decodeAv1,
                                preferDolbyVision,
                                passthroughAudio = passthroughAudio,
                            )
                                .setEnableDecoderFallback(true)
                                .setExtensionRendererMode(rendererMode)

                        val mediaSourceFactory =
                            if (useLibAss) {
                                val renderType =
                                    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                                        AssRenderType.OVERLAY_CANVAS
                                    } else {
                                        AssRenderType.OVERLAY_OPEN_GL
                                    }
                                assHandler = AssHandler(renderType)
                                val assSubtitleParserFactory = AssSubtitleParserFactory(assHandler)
                                renderersFactory = AssRenderersFactory(assHandler, renderersFactory)
                                DefaultMediaSourceFactory(
                                    dataSourceFactory,
                                    extractorsFactory.withAssMkvSupport(
                                        assSubtitleParserFactory,
                                        assHandler,
                                    ),
                                ).setSubtitleParserFactory(assSubtitleParserFactory)
                            } else {
                                DefaultMediaSourceFactory(
                                    dataSourceFactory,
                                    extractorsFactory,
                                )
                            }
                        val disableAudioOffload =
                            appPreferences.experimentalPreferences.get { disableAudioOffload } ?: false
                        val tunneling =
                            if (safeMode || passthroughAudio) {
                                // Tunnelled playback routes audio+video
                                // through one hardware path that cheap
                                // chipsets frequently get wrong (sound,
                                // no picture). Safe mode forces it off —
                                // and so does passthrough: the tunnelled
                                // path on several chipsets decodes instead
                                // of passing the encoded stream through.
                                false
                            } else {
                                appPreferences.experimentalPreferences.get { videoTunnelingEnabled }
                            }
                        val trackSelector =
                            createTrackSelector(
                                tunneling = tunneling,
                                disableAudioOffload = disableAudioOffload,
                            )

                        ExoPlayer
                            .Builder(context)
                            .setMediaSourceFactory(mediaSourceFactory)
                            .setRenderersFactory(renderersFactory)
                            .setTrackSelector(trackSelector)
                            .setLoadControl(fastStartLoadControl())
                            .build()
                            .apply {
                                assHandler?.init(this)
                                withContext(WholphinDispatchers.Main) {
                                    setAudioAttributes(
                                        AudioAttributes
                                            .Builder()
                                            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                                            .build(),
                                        false,
                                    )
                                }
                            }
            }
            val newPlayer =
                when (backend) {
                    PlayerBackend.EXTERNAL_PLAYER -> {
                        throw IllegalArgumentException("Cannot create a player for external playback")
                    }

                    // Every other value — including the MPV / Auto
                    // values older installs may still carry in their
                    // saved preferences — builds ExoPlayer. The backend
                    // parameter survives only for call-site compatibility.
                    else -> buildExoPlayer()
                }
            currentPlayer = newPlayer
            currentAssHandler = assHandler
            return PlayerCreation(newPlayer, assHandler, bufferProfileName)
        }

        fun createAudioPlayer(
            disableAudioOffload: Boolean,
            extensions: MediaExtensionStatus = MediaExtensionStatus.MES_FALLBACK,
        ): ExoPlayer {
            val rendererMode =
                when (extensions) {
                    MediaExtensionStatus.MES_FALLBACK -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                    MediaExtensionStatus.MES_PREFERRED -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                    MediaExtensionStatus.MES_DISABLED -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
                    else -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                }
            val extractorsFactory = createExtractorsFactory()
            val renderersFactory: RenderersFactory =
                WholphinRenderersFactory(context, false)
                    .setEnableDecoderFallback(true)
                    .setExtensionRendererMode(rendererMode)
            val mediaSourceFactory =
                DefaultMediaSourceFactory(
                    OkHttpDataSource.Factory(authOkHttpClient),
                    extractorsFactory,
                )
            val trackSelector = createTrackSelector(disableAudioOffload = disableAudioOffload)
            return ExoPlayer
                .Builder(context)
                .setMediaSourceFactory(mediaSourceFactory)
                .setRenderersFactory(renderersFactory)
                .setTrackSelector(trackSelector)
                .build()
                .also {
                    it.setAudioAttributes(
                        AudioAttributes
                            .Builder()
                            .setUsage(C.USAGE_MEDIA)
                            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                            .build(),
                        true,
                    )
                }
        }

        private fun createExtractorsFactory() =
            DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setConstantBitrateSeekingAlwaysEnabled(true)

        /**
         * Fast-start buffering (v0.3.2, back buffer added v0.3.7):
         * ExoPlayer's defaults ask for 2.5s of media before the first
         * frame and hold 50s buffers — slow starts and heavy RAM on a
         * 1–2 GB TV. Start after ~1s of media, keep 15–30s buffered
         * (plenty for direct streams, far lighter), and judge
         * readiness by time, not bytes, so a large file's first chunk
         * doesn't gate the first frame. v0.3.7 adds a 60s back buffer:
         * the old 0ms default made every backward seek a cold network
         * re-buffer (the v0.3.6 "seek hangs" cause).
         *
         * v0.3.18 (diagnosis cause #5): the back buffer drops to
         * 15 s — at typical bitrates the 60 s retention held roughly
         * 110–190 MB of allocator segments for the whole session on
         * a 1–2 GB TV, beside the native decode memory; 15 s keeps
         * short backward seeks warm (the v0.3.6 complaint was about
         * ZERO back buffer, not about 15 vs 60) at a quarter of the
         * footprint, matching the reference player's budget. A
         * target-buffer-bytes ceiling rides along as the allocator's
         * outer bound once the time targets are met (time still
         * governs loading — the fast-start behaviour is unchanged).
         *
         * v0.3.22 (the 512 MB pass): the profile is RAM-adaptive.
         * On a low-RAM set ([lowRamDevice] — the owner's 512 MB TV
         * lands there) the allocator's ceiling drops 48 MB → 16 MB,
         * the forward window narrows to 8 s/16 s and the back buffer
         * to 5 s: the same stream, carried with a third of the
         * standing RAM. The two start-shaping numbers do NOT move —
         * 1,000 ms to first frame and 2,500 ms after a rebuffer are
         * the fast start/recovery the owner feels, and they stay.
         * Strong TVs keep the standard profile exactly as it was.
         */
        private fun fastStartLoadControl(): DefaultLoadControl =
            if (lowRamDevice) {
                DefaultLoadControl
                    .Builder()
                    .setBufferDurationsMs(
                        /* minBufferMs = */ 8_000,
                        /* maxBufferMs = */ 16_000,
                        /* bufferForPlaybackMs = */ 1_000,
                        /* bufferForPlaybackAfterRebufferMs = */ 2_500,
                    ).setBackBuffer(
                        /* backBufferDurationMs = */ 5_000,
                        /* retainBackBufferFromKeyframe = */ false,
                    ).setTargetBufferBytes(16 * 1024 * 1024)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .build()
            } else {
                DefaultLoadControl
                    .Builder()
                    .setBufferDurationsMs(
                        /* minBufferMs = */ 15_000,
                        /* maxBufferMs = */ 30_000,
                        /* bufferForPlaybackMs = */ 1_000,
                        /* bufferForPlaybackAfterRebufferMs = */ 2_500,
                    ).setBackBuffer(
                        /* backBufferDurationMs = */ 15_000,
                        /* retainBackBufferFromKeyframe = */ false,
                    ).setTargetBufferBytes(48 * 1024 * 1024)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .build()
            }

        /**
         * Track selector (v0.3.7 safety net): video is capped at
         * 1920x1080 — the panel resolution of the owner's TV and the
         * vast majority of TV panels — regardless of the Streams
         * rule. A wrong/heavy pick can no longer feed the decoder a
         * 2160p adaptive rendition; a deliberately chosen 2160p
         * progressive file still plays as picked (this cap governs
         * track selection, it is not a stream filter).
         */
        private fun createTrackSelector(
            tunneling: Boolean? = null,
            disableAudioOffload: Boolean = false,
        ) = DefaultTrackSelector(context).apply {
            val offloadMode =
                if (disableAudioOffload) {
                    AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
                } else {
                    AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED
                }
            setParameters(
                buildUponParameters()
                    .apply {
                        tunneling?.let { setTunnelingEnabled(tunneling) }
                        setMaxVideoSize(1920, 1080)
                    }.setAudioOffloadPreferences(
                        AudioOffloadPreferences
                            .Builder()
                            .setAudioOffloadMode(offloadMode)
                            .build(),
                    ),
            )
        }

        fun createMediaSession(player: Player) =
            MediaSession
                .Builder(context, player)
                .build()
    }

val Player.isReleased: Boolean
    get() {
        return when (this) {
            is ExoPlayer -> isReleased
            else -> throw IllegalStateException("Unknown Player type: ${this::class.qualifiedName}")
        }
    }

/** Per-app memory class (MB) at or below which a set counts as low-RAM (v0.3.22). */
private const val LOW_RAM_MEMORY_CLASS_MB = 128

/**
 * v0.3.22 (the 512 MB pass): the VIDEO codec selector —
 * hardware FIRST, safety net kept. It delegates to
 * [MediaCodecSelector.DEFAULT] and moves the platform SOFTWARE
 * video decoders (OMX.google.*, c2.android.*) to the END of the
 * list, so the hardware decoder is always tried first for every
 * format it can take; a software decoder remains listed ONLY as
 * the last resort behind it. Combined with the factory's kept
 * decoder fallback, a format the hardware truly cannot decode
 * still plays — through the software landing the v0.3.21 decoder
 * log now flags [SOFTWARE] — instead of not playing at all
 * (owner's order, 2026-11-07: the app is working, "don't break
 * anything"; a hard hardware-only cutoff was rejected for his
 * arbitrary addon sources on a generic MediaTek). Wired ONLY into
 * [WholphinRenderersFactory.buildVideoRenderers]; the audio
 * renderers keep the stock selector and their FFmpeg fallback
 * untouched. The dav1d extension renderer is not a MediaCodec
 * decoder and is unaffected; it stays pref-gated, default off.
 */
object HardwareFirstVideoCodecSelector : MediaCodecSelector {
    override fun getDecoderInfos(
        mimeType: String,
        requiresSecureDecoder: Boolean,
        requiresTunnelingDecoder: Boolean,
    ): List<MediaCodecInfo> {
        val (hardware, software) =
            MediaCodecSelector.DEFAULT
                .getDecoderInfos(mimeType, requiresSecureDecoder, requiresTunnelingDecoder)
                .partition { info ->
                    !info.name.startsWith("OMX.google.", ignoreCase = true) &&
                        !info.name.startsWith("c2.android.", ignoreCase = true)
                }
        return hardware + software
    }
}

data class PlayerCreation(
    val player: Player,
    val assHandler: AssHandler? = null,
    /** v0.3.22: the buffer profile this player was built with ("low-ram" / "standard"). */
    val bufferProfileName: String = "standard",
)

// Code is adapted from https://github.com/androidx/media/blob/release/libraries/exoplayer/src/main/java/androidx/media3/exoplayer/DefaultRenderersFactory.java#L436
class WholphinRenderersFactory(
    context: Context,
    private val av1Enabled: Boolean,
    private val preferDolbyVisionOverHdr10Plus: Boolean = false,
    /**
     * v0.3.18: defaults to false and no in-tree caller passes true
     * any more — platform decoding leads and the stock extension
     * order (renderer mode ON) appends FFmpeg as a fallback only.
     * The prepend survives as an explicit opt-in for a caller that
     * ever needs the old software-first order back; through
     * v0.3.17 the video factory passed !safeMode here, which put
     * software decoding ahead of the hardware for every surround
     * track (the permanent CPU tax the 0.3.18 diagnosis ranks as
     * freeze cause #2).
     */
    private val ffmpegAudioFirst: Boolean = false,
    /**
     * Audio passthrough (v0.3.10): when true the FFmpeg renderer is
     * NOT prepended either — software decoding would destroy the
     * encoded stream before it could be passed through — and the
     * audio sink is built claiming the surround encodings, so
     * MediaCodec hands AC3/E-AC-3/DTS/TrueHD tracks to the output
     * untouched (see [buildAudioSink]).
     */
    private val passthroughAudio: Boolean = false,
) : DefaultRenderersFactory(context) {
    /**
     * History (through v0.3.17): this prepend existed for the phone
     * player's OnePlus 13R fix — streams carrying E-AC-3 / AC-3 / DTS
     * / TrueHD audio play with NO SOUND on devices without a hardware
     * Dolby/DTS decoder, because MediaCodec silently drops the track,
     * so the FFmpeg renderer went FIRST and won every format it
     * supports. v0.3.18 reverses the order for TV (the freeze
     * diagnosis): the prepend is off ([ffmpegAudioFirst] defaults
     * false), MediaCodec leads, and the stock factory still appends
     * the FFmpeg renderer behind it — a track the platform cannot
     * decode falls through to FFmpeg and plays; it just no longer
     * pays the software-decode tax when the hardware can do the job.
     */
    override fun buildAudioRenderers(
        context: Context,
        extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean,
        audioSink: AudioSink,
        eventHandler: Handler,
        eventListener: AudioRendererEventListener,
        out: ArrayList<Renderer>,
    ) {
        if (ffmpegAudioFirst && !passthroughAudio && FfmpegLibrary.isAvailable()) {
            out.add(FfmpegAudioRenderer(eventHandler, eventListener, audioSink))
            Timber.i("FFmpeg audio renderer added (software eac3/ac3/dts/truehd decoding)")
        }
        if (passthroughAudio) {
            Timber.i("Audio passthrough on: FFmpeg renderer skipped, encoded audio goes to the output untouched")
        }
        super.buildAudioRenderers(
            context,
            extensionRendererMode,
            mediaCodecSelector,
            enableDecoderFallback,
            audioSink,
            eventHandler,
            eventListener,
            out,
        )
    }

    /**
     * Audio passthrough (v0.3.10): the stock sink only passes encoded
     * audio through for formats the DEVICE reports — several TVs
     * (Shield-class boxes behind AVRs especially) under-report what
     * the HDMI chain actually accepts, so with the user's switch on
     * we claim the standard surround set explicitly and let the
     * output chain take the encoded stream as-is. Mirrors the stock
     * sink otherwise (same processor chain and flags). Passthrough
     * off = the stock sink, untouched.
     */
    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean,
    ): AudioSink {
        if (!passthroughAudio) {
            // The stock factory method is Java-annotated nullable; it
            // never actually returns null, but satisfy the type system
            // with an equivalent stock sink as the unreachable fallback.
            return super.buildAudioSink(
                context,
                enableFloatOutput,
                enableAudioTrackPlaybackParams,
            ) ?: DefaultAudioSink
                .Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .build()
        }
        val capabilities =
            AudioCapabilities(
                intArrayOf(
                    AudioFormat.ENCODING_PCM_16BIT,
                    AudioFormat.ENCODING_AC3,
                    AudioFormat.ENCODING_E_AC3,
                    AudioFormat.ENCODING_E_AC3_JOC,
                    AudioFormat.ENCODING_DTS,
                    AudioFormat.ENCODING_DTS_HD,
                    AudioFormat.ENCODING_DOLBY_TRUEHD,
                ),
                // Max channel count across the claimed encodings.
                8,
            )
        return DefaultAudioSink
            .Builder(context)
            .setAudioCapabilities(capabilities)
            .setAudioProcessorChain(
                DefaultAudioSink.DefaultAudioProcessorChain(SonicAudioProcessor()),
            ).setEnableFloatOutput(enableFloatOutput)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .build()
    }

    @OptIn(ExperimentalApi::class)
    override fun buildVideoRenderers(
        context: Context,
        extensionRendererMode: Int,
        mediaCodecSelector: MediaCodecSelector,
        enableDecoderFallback: Boolean,
        eventHandler: Handler,
        eventListener: VideoRendererEventListener,
        allowedVideoJoiningTimeMs: Long,
        out: ArrayList<Renderer>,
    ) {
        val videoCodecAdapterFactory =
            if (preferDolbyVisionOverHdr10Plus) {
                BitstreamFilteringCodecAdapterFactory(
                    codecAdapterFactory,
                    listOf(Hdr10PlusMaskingFilter()),
                )
            } else {
                codecAdapterFactory
            }
        // v0.3.22 (the 512 MB pass): the VIDEO renderer gets the
        // hardware-FIRST selector — platform software decoders are
        // moved to the END of the list, so hardware wins every
        // format it can take (the software landing was the silent
        // CPU tax behind the lag). The factory's decoder FALLBACK
        // IS KEPT (the [enableDecoderFallback] parameter passes
        // through untouched), on the owner's word the same day:
        // after a full power-off the app plays fine and "don't
        // break anything" — his streams are arbitrary addon
        // sources, not uniform platform content, so a hard
        // hardware-only cutoff could turn "plays with lag" into
        // "doesn't play" on a generic MediaTek. If hardware truly
        // cannot take a format, the existing fallback still lands
        // it — and the v0.3.21 decoder log flags the landing
        // [SOFTWARE], so it is never silent again. The audio
        // renderers are untouched (buildAudioRenderers: stock
        // selector, platform-first, FFmpeg behind it), and the
        // dav1d extension renderer below is not a MediaCodec
        // decoder — it stays pref-gated, default off.
        var videoRendererBuilder =
            MediaCodecVideoRenderer
                .Builder(context)
                .setCodecAdapterFactory(videoCodecAdapterFactory)
                .setMediaCodecSelector(HardwareFirstVideoCodecSelector)
                .setAllowedJoiningTimeMs(allowedVideoJoiningTimeMs)
                .setEnableDecoderFallback(enableDecoderFallback)
                .setEventHandler(eventHandler)
                .setEventListener(eventListener)
                .setMaxDroppedFramesToNotify(MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY)
                .experimentalSetParseAv1SampleDependencies(false)
                .experimentalSetLateThresholdToDropDecoderInputUs(C.TIME_UNSET)
        if (Build.VERSION.SDK_INT >= 34) {
            videoRendererBuilder =
                videoRendererBuilder.experimentalSetEnableMediaCodecBufferDecodeOnlyFlag(
                    false,
                )
        }
        out.add(videoRendererBuilder.build())

        if (extensionRendererMode == EXTENSION_RENDERER_MODE_OFF) {
            return
        }
        var extensionRendererIndex = out.size
        if (extensionRendererMode == EXTENSION_RENDERER_MODE_PREFER) {
            extensionRendererIndex--
        }

        if (av1Enabled) {
            try {
                val clazz = Class.forName("androidx.media3.decoder.av1.Libdav1dVideoRenderer")
                val constructor: Constructor<*> =
                    clazz.getConstructor(
                        Long::class.javaPrimitiveType,
                        Handler::class.java,
                        VideoRendererEventListener::class.java,
                        Int::class.javaPrimitiveType,
                    )
                val renderer =
                    constructor.newInstance(
                        allowedVideoJoiningTimeMs,
                        eventHandler,
                        eventListener,
                        MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY,
                    ) as Renderer
                out.add(extensionRendererIndex++, renderer)
                Timber.i("Loaded Libdav1dVideoRenderer.")
            } catch (e: Exception) {
                // Fail soft (v0.2.1): a missing/broken AV1 extension must
                // not kill playback — log, report and continue with the
                // MediaCodec renderer list.
                Timber.e(e, "AV1 extension unavailable; continuing without it")
                CrashReports.captureException(e)
            }
        }
    }
}
