package com.github.damontecres.wholphin.plavio

import android.content.Context
import android.content.SharedPreferences

/**
 * Remembers the newest episode the app has already seen (or notified
 * about) for each followed show, so the episode check can detect
 * releases. Ported from the phone app; TV keys entries by meta id (the
 * TV meta lookup fans out over every meta addon, so no addon id is
 * needed). Backed by SharedPreferences, like the phone.
 */
class EpisodeTracker(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Newest known (season, episode) for a show, or null when never checked. */
    fun lastKnown(metaId: String): Pair<Int, Int>? {
        val raw = prefs.getString(key(metaId), null) ?: return null
        val parts = raw.split(":")
        val season = parts.getOrNull(0)?.toIntOrNull() ?: return null
        val episode = parts.getOrNull(1)?.toIntOrNull() ?: return null
        return season to episode
    }

    /** Record the newest episode seen for a show. */
    fun update(
        metaId: String,
        season: Int,
        episode: Int,
    ) {
        prefs
            .edit()
            .putString(key(metaId), "$season:$episode:${System.currentTimeMillis()}")
            .apply()
    }

    /** Drop tracking state for shows no longer followed. */
    fun prune(keepKeys: Set<String>) {
        val stale = prefs.all.keys.filter { it.startsWith(PREFIX) && it !in keepKeys }
        if (stale.isEmpty()) return
        prefs.edit().apply {
            stale.forEach { remove(it) }
        }.apply()
    }

    companion object {
        private const val PREFS = "plavio_episode_tracker"
        private const val PREFIX = "ep_"

        /** Stable storage key for a followed show. */
        fun key(metaId: String): String = "$PREFIX$metaId"
    }
}
