package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.CachedMeta
import com.github.damontecres.wholphin.plavio.CastMember
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioSearchUiState {
    /** Nothing searched yet. */
    data object Idle : PlavioSearchUiState

    data object Searching : PlavioSearchUiState

    data class Results(
        val items: List<CachedMeta>,
        /** People matching the query (search by actor) — empty when none matched. */
        val people: List<CastMember> = emptyList(),
    ) : PlavioSearchUiState

    data class NoResults(
        val query: String,
    ) : PlavioSearchUiState

    /** No enabled addon's catalog supports the search extra. */
    data object NoSearchAddons : PlavioSearchUiState
}

@HiltViewModel
class PlavioSearchViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioSearchUiState>(PlavioSearchUiState.Idle)
        val state: StateFlow<PlavioSearchUiState> = _state

        private var searchJob: Job? = null

        fun search(query: String) {
            val trimmed = query.trim()
            searchJob?.cancel()
            if (trimmed.isEmpty()) {
                _state.value = PlavioSearchUiState.Idle
                return
            }
            searchJob =
                viewModelScope.launch {
                    _state.value = PlavioSearchUiState.Searching
                    // People run alongside titles: the /person-search
                    // route on the meta addons (cast-scan fallback behind
                    // it) — a name can find the actor even when no title
                    // matches.
                    val people =
                        runCatching { repository.searchPeople(trimmed) }
                            .getOrDefault(emptyList())
                    if (!repository.hasSearchCatalogs()) {
                        _state.value =
                            if (people.isEmpty()) {
                                PlavioSearchUiState.NoSearchAddons
                            } else {
                                PlavioSearchUiState.Results(emptyList(), people)
                            }
                        return@launch
                    }
                    val results = repository.searchCatalogs(trimmed)
                    _state.value =
                        if (results.isEmpty() && people.isEmpty()) {
                            PlavioSearchUiState.NoResults(trimmed)
                        } else {
                            PlavioSearchUiState.Results(results, people)
                        }
                }
        }
    }
