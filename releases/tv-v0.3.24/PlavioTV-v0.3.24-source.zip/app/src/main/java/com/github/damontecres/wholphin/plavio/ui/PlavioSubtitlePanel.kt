package com.github.damontecres.wholphin.plavio.ui

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.SUBTITLE_COLOR_SWATCHES
import com.github.damontecres.wholphin.plavio.SUBTITLE_OUTLINE_SWATCHES
import com.github.damontecres.wholphin.plavio.Subtitle
import com.github.damontecres.wholphin.plavio.SubtitleStyle
import kotlinx.coroutines.launch
import java.util.Locale

/** One selectable track in the player's audio/subtitle pickers. */
data class TrackOption(
    val label: String,
    val group: Tracks.Group?,
    val trackIndex: Int,
    val selected: Boolean,
    /** True for the subtitles "Off" entry. */
    val isOff: Boolean = false,
    /** True for the audio picker's "Auto" entry (clears the manual override). */
    val isAuto: Boolean = false,
    /** ISO language code of the track ("und" when unknown). */
    val language: String? = null,
    /** media3 format id — side-loaded subtitles carry "e:<index>" (their slot in the request). */
    val formatId: String? = null,
    /** Forced track (name or the format's forced flag says so). */
    val forced: Boolean = false,
)

/** A subtitle row for the panel: the track plus its display source. */
data class SubtitleRow(
    val option: TrackOption,
    val title: String,
    /** "Embedded" or the addon host the subtitle file came from; null for the Off row. */
    val source: String?,
)

@OptIn(UnstableApi::class)
fun trackOptions(
    player: Player,
    text: Boolean,
): List<TrackOption> {
    val type = if (text) C.TRACK_TYPE_TEXT else C.TRACK_TYPE_AUDIO
    val options = mutableListOf<TrackOption>()
    if (text) {
        val disabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        options +=
            TrackOption(
                label = "Off",
                group = null,
                trackIndex = -1,
                selected = disabled,
                isOff = true,
            )
    }
    var n = 0
    for (group in player.currentTracks.groups) {
        if (group.type != type) continue
        for (i in 0 until group.length) {
            if (!group.isSupported) continue
            n++
            val format = group.getTrackFormat(i)
            val label =
                format.label
                    ?: format.language?.takeIf { it.isNotBlank() && it != "und" }
                    ?: "Track $n"
            options +=
                TrackOption(
                    label = label,
                    group = group,
                    trackIndex = i,
                    selected = group.isTrackSelected(i),
                    language = format.language,
                    formatId = format.id,
                    forced =
                        (format.selectionFlags and C.SELECTION_FLAG_FORCED) != 0 ||
                            label.contains("forced", ignoreCase = true),
                )
        }
    }
    return options
}

@OptIn(UnstableApi::class)
fun applyTrackOption(
    player: Player,
    text: Boolean,
    option: TrackOption,
) {
    val type = if (text) C.TRACK_TYPE_TEXT else C.TRACK_TYPE_AUDIO
    val builder = player.trackSelectionParameters.buildUpon()
    if (option.isAuto) {
        // Back to the player's own choice: drop any forced track of
        // this type and make sure the type is enabled.
        builder.clearOverridesOfType(type)
        builder.setTrackTypeDisabled(type, false)
    } else if (option.isOff) {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
    } else if (option.group != null) {
        builder
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(
                TrackSelectionOverride(option.group.mediaTrackGroup, option.trackIndex),
            )
    }
    player.trackSelectionParameters = builder.build()
}

/** Human language name for an ISO code ("en" → "English"). */
fun languageDisplayName(code: String?): String =
    when {
        code.isNullOrBlank() || code == "und" -> "Unknown"
        else ->
            runCatching { Locale.forLanguageTag(code).displayLanguage }
                .getOrNull()
                ?.takeIf { it.isNotBlank() }
                ?: code.uppercase()
    }

/**
 * The phone player's three-rail subtitle panel, adapted to the remote:
 * Languages | Subtitles | Style side by side, every control a plain
 * focusable row/chip/swatch so D-pad order runs rail to rail. The Style
 * rail carries the same controls as the phone (delay stepper + Auto
 * Sync, font size, bold, colour, opacity, outline, bottom offset,
 * Reset Defaults) and edits the shared style store live.
 */
@Composable
fun PlavioSubtitlePanel(
    languages: List<String>,
    selectedLanguage: String?,
    onSelectLanguage: (String?) -> Unit,
    rows: List<SubtitleRow>,
    onPickRow: (SubtitleRow) -> Unit,
    style: SubtitleStyle,
    onStyleChange: (SubtitleStyle) -> Unit,
    delayMs: Long,
    delayEnabled: Boolean,
    onDelayChange: (Long) -> Unit,
    onReloadSubtitles: () -> Unit,
    onCaptureCues: suspend () -> Pair<Long, List<Pair<Long, String>>>,
    onCuePicked: (capturedAtMs: Long, cueStartMs: Long) -> Unit,
    onResetDefaults: () -> Unit,
    preferredLanguages: List<String>,
    onPreferredLanguagesChange: (List<String>) -> Unit,
    onFetchOnlineSubtitles: suspend () -> List<Subtitle>,
    onAttachOnlineSubtitle: (Subtitle) -> Unit,
    modifier: Modifier = Modifier,
) {
    var captured by remember { mutableStateOf<Pair<Long, List<Pair<Long, String>>>?>(null) }
    var capturing by remember { mutableStateOf(false) }
    // Which preferred-language slot the Languages rail is editing (1/2), if any.
    var prefEdit by remember { mutableStateOf<Int?>(null) }
    // "Fetch subtitles online" state for the Subtitles rail.
    var onlineSubs by remember { mutableStateOf<List<Subtitle>?>(null) }
    var onlineSearching by remember { mutableStateOf(false) }
    var onlineSearched by remember { mutableStateOf(false) }
    var attachedUrls by remember { mutableStateOf<Set<String>>(emptySet()) }
    val scope = rememberCoroutineScope()
    val firstFocus = remember { FocusRequester() }
    // v0.3.22 focus trap, entry half: the one-shot request this panel
    // used to make could fire before the target row existed (tracks
    // still loading, or no track selected so NO row carried the
    // requester) — focus then stayed on the player controls BEHIND
    // the open panel and D-pad presses drove the player (the owner's
    // "focus escapes back to the player"). Now the request retries
    // until focus is verifiably inside the panel, and the target is
    // the selected row or, failing that, the first row — a row always
    // carries the requester.
    //
    // Hardened 2026-11-04 (owner: "subs just displaying, not
    // clickable" on the v0.3.24 test): three changes — the effect is
    // keyed on Unit, not on the rows list (a rebuilt list restarted
    // the retry and could strand it); the retry window is ~6s, not
    // ~1s; and the selected row is scrolled into composition before
    // the first request, so a selected track below the fold still
    // exists to receive focus. The panel root is also its own focus
    // group (below), like the gated control stack.
    val focusRowIndex =
        rows.indexOfFirst { it.option.selected }.let { if (it >= 0) it else 0 }
    val rail2State = rememberLazyListState()
    var focusEntered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (focusRowIndex > 0) {
            runCatching { rail2State.scrollToItem(focusRowIndex) }
        }
        // v0.3.15: the 40-shot retry (up to ~6s of re-requests
        // inside the player) is replaced by the shared additive
        // landing — one shot plus one next-frame confirmation,
        // standing down the moment the panel's own focus sensor
        // trips (see PlavioFocus.landFocus).
        landFocus(firstFocus, isClaimed = { focusEntered })
    }

    // v0.3.16 (note 11 — Sample B "Bottom panel", the owner's
    // pick): the panel is a wide frosted strip from the bottom of
    // the player (its host modifier in PlavioPlayerScreen places
    // it there). Inside: a header row (title + the Subtitles
    // On/Off segment), a divider, then the columns — TRACK list
    // on the left, Languages next, the Style controls on the
    // right (Size / Text colour / Background / Timing sync /
    // Position first, in the sample's order; the remaining
    // controls below). Every state, callback and feature of the
    // three-rail panel is kept — this is a layout reshape, and
    // the style edits still write the shared store live, so the
    // on-video subtitles preview every change as it happens.
    Column(
        modifier =
            modifier
                .background(PlavioOnyx.Panel, RoundedCornerShape(20.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(20.dp))
                .padding(horizontal = 22.dp, vertical = 16.dp)
                .onFocusChanged { if (it.hasFocus) focusEntered = true }
                .focusGroup(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ---- Header: title + On/Off segment (Sample B) ----
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.plavio_player_subtitles),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Spacer(modifier = Modifier.weight(1f))
            val offRow = rows.firstOrNull { it.option.isOff }
            val subsOn = rows.any { it.option.selected && !it.option.isOff }
            PanelChip(
                text = stringResource(R.string.plavio_setting_on),
                selected = subsOn,
                onClick = {
                    if (!subsOn) {
                        rows.firstOrNull { !it.option.isOff }?.let { onPickRow(it) }
                    }
                },
            )
            Spacer(modifier = Modifier.width(8.dp))
            PanelChip(
                text = stringResource(R.string.plavio_setting_off),
                selected = !subsOn,
                onClick = { offRow?.let { onPickRow(it) } },
            )
        }
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(PlavioOnyx.GlassBorder),
        )
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
        // ---- Rail 2: Subtitles ----
        Column(
            modifier = Modifier.weight(1.15f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            PanelRailTitle(stringResource(R.string.plavio_sub_track))
            if (rows.size <= 1) {
                Text(
                    text = stringResource(R.string.plavio_player_no_subtitles),
                    style = MaterialTheme.typography.bodyMedium,
                    color = PlavioOnyx.TextSecondary,
                )
            }
            // The entry-focus target: the selected row, or the first
            // row when nothing is selected — one row ALWAYS carries
            // the requester (v0.3.22; before, an unselected panel had
            // no target at all and focus never entered). focusRowIndex
            // itself is computed at the panel level (2026-11-04) so
            // the entry effect can scroll it into composition first.
            LazyColumn(
                state = rail2State,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(
                    rows,
                    key = { _, row -> row.option.formatId ?: row.title + row.option.trackIndex },
                ) { index, row ->
                    PanelRow(
                        text = row.title,
                        subText =
                            listOfNotNull(
                                row.source,
                                if (row.option.forced) {
                                    stringResource(R.string.plavio_sub_forced)
                                } else {
                                    null
                                },
                            ).joinToString(" • ").takeIf { it.isNotEmpty() },
                        selected = row.option.selected,
                        onClick = { onPickRow(row) },
                        modifier =
                            if (index == focusRowIndex) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                    )
                }
            }
            // Fetch subtitles online (phone parity): results attach to
            // the title and join the list above on the next open.
            PanelRow(
                text =
                    if (onlineSearching) {
                        stringResource(R.string.plavio_sub_searching)
                    } else {
                        stringResource(R.string.plavio_sub_fetch_online)
                    },
                selected = false,
                onClick = {
                    if (!onlineSearching) {
                        onlineSearching = true
                        scope.launch {
                            onlineSubs =
                                runCatching { onFetchOnlineSubtitles() }
                                    .getOrDefault(emptyList())
                                    // Rows key by url — two addons can
                                    // serve the same subtitle file.
                                    .distinctBy { it.url }
                            onlineSearched = true
                            onlineSearching = false
                        }
                    }
                },
            )
            val found = onlineSubs
            if (found != null) {
                if (found.isEmpty()) {
                    Text(
                        text = stringResource(R.string.plavio_sub_none_found),
                        style = MaterialTheme.typography.bodySmall,
                        color = PlavioOnyx.TextSecondary,
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(168.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(found, key = { it.url }) { sub ->
                            val attached = sub.url in attachedUrls
                            PanelRow(
                                text = languageDisplayName(sub.lang),
                                subText =
                                    listOfNotNull(
                                        subtitleSourceHost(sub.url),
                                        if (attached) {
                                            stringResource(R.string.plavio_sub_added)
                                        } else {
                                            null
                                        },
                                    ).joinToString(" • ").takeIf { it.isNotEmpty() },
                                selected = attached,
                                onClick = {
                                    if (!attached) {
                                        attachedUrls = attachedUrls + sub.url
                                        onAttachOnlineSubtitle(sub)
                                    }
                                },
                            )
                        }
                    }
                }
            } else if (onlineSearched) {
                Text(
                    text = stringResource(R.string.plavio_sub_none_found),
                    style = MaterialTheme.typography.bodySmall,
                    color = PlavioOnyx.TextSecondary,
                )
            }
        }

        // ---- Rail 1: Languages (+ Preferred slots at the bottom) ----
        Column(
            modifier = Modifier.width(190.dp).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            val editing = prefEdit
            if (editing == null) {
                PanelRailTitle(stringResource(R.string.plavio_sub_languages))
                PanelRow(
                    text = stringResource(R.string.plavio_sub_none),
                    selected = selectedLanguage == null,
                    onClick = { onSelectLanguage(null) },
                )
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(languages, key = { it }) { code ->
                        PanelRow(
                            text = languageDisplayName(code),
                            selected = code == selectedLanguage,
                            onClick = { onSelectLanguage(code) },
                        )
                    }
                }
                // Preferred languages live here now (they left Settings
                // with the rest of the subtitle settings — player only).
                PanelRailTitle(stringResource(R.string.plavio_sub_preferred))
                PanelRow(
                    text =
                        stringResource(R.string.plavio_settings_sub_lang1) + " — " +
                            (preferredLanguages.getOrNull(0)?.let { languageDisplayName(it) }
                                ?: stringResource(R.string.plavio_settings_lang_none)),
                    selected = false,
                    onClick = { prefEdit = 1 },
                )
                PanelRow(
                    text =
                        stringResource(R.string.plavio_settings_sub_lang2) + " — " +
                            (preferredLanguages.getOrNull(1)?.let { languageDisplayName(it) }
                                ?: stringResource(R.string.plavio_settings_lang_none)),
                    selected = false,
                    onClick = { prefEdit = 2 },
                )
                Text(
                    text = stringResource(R.string.plavio_sub_pref_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = PlavioOnyx.TextSecondary,
                )
            } else {
                PanelRailTitle(
                    stringResource(
                        if (editing == 1) {
                            R.string.plavio_settings_sub_lang1
                        } else {
                            R.string.plavio_settings_sub_lang2
                        },
                    ),
                )
                val current = preferredLanguages.getOrNull(editing - 1)
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    item {
                        PanelRow(
                            text = stringResource(R.string.plavio_settings_lang_none),
                            selected = current == null,
                            onClick = {
                                val updated =
                                    if (editing == 1) {
                                        listOfNotNull(preferredLanguages.getOrNull(1))
                                    } else {
                                        listOfNotNull(preferredLanguages.getOrNull(0))
                                    }
                                onPreferredLanguagesChange(updated.distinct())
                                prefEdit = null
                            },
                        )
                    }
                    items(SUBTITLE_LANGUAGE_CODES, key = { it }) { code ->
                        PanelRow(
                            text = languageDisplayName(code),
                            selected = code == current,
                            onClick = {
                                val first =
                                    if (editing == 1) code else preferredLanguages.getOrNull(0)
                                val second =
                                    if (editing == 2) code else preferredLanguages.getOrNull(1)
                                onPreferredLanguagesChange(
                                    listOfNotNull(first, second).distinct(),
                                )
                                prefEdit = null
                            },
                        )
                    }
                }
                PanelRow(
                    text = stringResource(R.string.plavio_cancel),
                    selected = false,
                    onClick = { prefEdit = null },
                )
            }
        }

        // ---- Rail 3: Style ----
        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
            PanelRailTitle(stringResource(R.string.plavio_sub_style))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    // Size (Sample B): the S/M/L/XL segment writes
                    // the same font-size the stepper used to (the
                    // shared store's presets 16/24/32/40sp); a size
                    // set elsewhere shows its nearest segment.
                    val sizePresets = listOf(16, 24, 32, 40)
                    SegmentRow(
                        label = stringResource(R.string.plavio_sub_size),
                        options = listOf("S", "M", "L", "XL"),
                        selectedIndex =
                            sizePresets.indices.minByOrNull {
                                kotlin.math.abs(sizePresets[it] - style.fontSizeSp)
                            } ?: 1,
                        onPick = { index ->
                            onStyleChange(style.copy(fontSizeSp = sizePresets[index]))
                        },
                    )
                }
                item {
                    SwatchRow(
                        label = stringResource(R.string.plavio_sub_color),
                        swatches = SUBTITLE_COLOR_SWATCHES,
                        selectedRgb = style.textColorRgb,
                        onPick = { rgb -> onStyleChange(style.copy(textColorRgb = rgb)) },
                    )
                }
                item {
                    // Background strength (Sample B): the
                    // None/Dim/Solid segment writes the background
                    // opacity the stepper used to (0/50/100%); the
                    // colour swatch above picks the box colour.
                    val bgPresets = listOf(0, 50, 100)
                    SegmentRow(
                        label = stringResource(R.string.plavio_sub_background),
                        options =
                            listOf(
                                stringResource(R.string.plavio_sub_bg_none),
                                stringResource(R.string.plavio_sub_bg_dim),
                                stringResource(R.string.plavio_sub_bg_solid),
                            ),
                        selectedIndex =
                            bgPresets.indices.minByOrNull {
                                kotlin.math.abs(bgPresets[it] - style.backgroundOpacityPercent)
                            } ?: 0,
                        onPick = { index ->
                            onStyleChange(
                                style.copy(backgroundOpacityPercent = bgPresets[index]),
                            )
                        },
                    )
                }
                item {
                    SwatchRow(
                        label = stringResource(R.string.plavio_sub_background),
                        swatches = SUBTITLE_COLOR_SWATCHES,
                        selectedRgb = style.backgroundColorRgb,
                        onPick = { rgb -> onStyleChange(style.copy(backgroundColorRgb = rgb)) },
                    )
                }

                item {
                    // Timing sync (Sample B): −/+ in 0.5s steps
                    // with the current offset shown. (Was ±100ms
                    // before v0.3.16; the sample's step is 0.5s.)
                    StepperRow(
                        label = stringResource(R.string.plavio_sub_timing),
                        value = "%+.1fs".format(delayMs / 1000.0),
                        enabled = delayEnabled,
                        onDecrease = { onDelayChange(delayMs - 500) },
                        onIncrease = { onDelayChange(delayMs + 500) },
                        onReset = { onDelayChange(0) },
                    )
                }
                if (!delayEnabled) {
                    item {
                        Text(
                            text = stringResource(R.string.plavio_sub_delay_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = PlavioOnyx.TextSecondary,
                        )
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = stringResource(R.string.plavio_sub_auto_sync),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PanelChip(
                                text = stringResource(R.string.plavio_sub_reload),
                                enabled = delayEnabled,
                                onClick = {
                                    captured = null
                                    onReloadSubtitles()
                                },
                            )
                            PanelChip(
                                text =
                                    stringResource(
                                        if (capturing) R.string.plavio_sub_capturing else R.string.plavio_sub_capture,
                                    ),
                                enabled = delayEnabled && !capturing,
                                onClick = {
                                    capturing = true
                                    scope.launch {
                                        captured = runCatching { onCaptureCues() }.getOrNull()
                                        capturing = false
                                    }
                                },
                            )
                        }
                        val cap = captured
                        if (cap != null) {
                            if (cap.second.isEmpty()) {
                                Text(
                                    text = stringResource(R.string.plavio_sub_no_cues),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PlavioOnyx.TextSecondary,
                                )
                            } else {
                                cap.second.forEach { (cueStartMs, cueText) ->
                                    PanelRow(
                                        text = cueText,
                                        subText = formatPanelTime(cueStartMs),
                                        selected = false,
                                        onClick = {
                                            onCuePicked(cap.first, cueStartMs)
                                            captured = null
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    // Position (v0.3.24, owner order 2026-11-09):
                    // the Sample-B Bottom/Lower/Raised segment only
                    // jumped between three fixed heights — the owner
                    // asked for a joystick to move the subtitles a
                    // little up or down, to where HE wants them. Now
                    // a ▼/▲ stepper on the same persisted
                    // bottomOffset (store range 0–200): each press
                    // moves the caption block 1% of the screen
                    // height, the value reads as the block's height
                    // above the bottom of the screen (the player's
                    // 0.06 base fraction + offset), and Reset
                    // returns to the shipped default. Every press
                    // writes the shared store, which the player
                    // applies live to the video behind the panel.
                    StepperRow(
                        label = stringResource(R.string.plavio_sub_position),
                        value = "${(60 + style.bottomOffset + 5) / 10}%",
                        decreaseText = "▼",
                        increaseText = "▲",
                        onDecrease = {
                            onStyleChange(
                                style.copy(
                                    bottomOffset = (style.bottomOffset - 10).coerceAtLeast(0),
                                ),
                            )
                        },
                        onIncrease = {
                            onStyleChange(
                                style.copy(
                                    bottomOffset = (style.bottomOffset + 10).coerceAtMost(200),
                                ),
                            )
                        },
                        onReset = {
                            onStyleChange(
                                style.copy(bottomOffset = SubtitleStyle().bottomOffset),
                            )
                        },
                    )
                }
                item {
                    ToggleRow(
                        label = stringResource(R.string.plavio_sub_bold),
                        on = style.bold,
                        onToggle = { onStyleChange(style.copy(bold = !style.bold)) },
                    )
                }
                item {
                    StepperRow(
                        label = stringResource(R.string.plavio_sub_opacity),
                        value = "${style.opacityPercent}%",
                        stepValue = 10,
                        onDecrease = {
                            onStyleChange(style.copy(opacityPercent = (style.opacityPercent - 10).coerceAtLeast(0)))
                        },
                        onIncrease = {
                            onStyleChange(style.copy(opacityPercent = (style.opacityPercent + 10).coerceAtMost(100)))
                        },
                    )
                }
                // Edge treatment (v0.3.22): the full caption edge
                // set as chips — the current edge carries the accent
                // fill (selection signal); the colour row below feeds
                // every edge type and greys out on None.
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = stringResource(R.string.plavio_sub_edge),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                        )
                        val edgeLabels =
                            listOf(
                                com.github.damontecres.wholphin.plavio.SubtitleEdge.NONE to
                                    stringResource(R.string.plavio_sub_edge_none),
                                com.github.damontecres.wholphin.plavio.SubtitleEdge.OUTLINE to
                                    stringResource(R.string.plavio_sub_outline),
                                com.github.damontecres.wholphin.plavio.SubtitleEdge.DROP_SHADOW to
                                    stringResource(R.string.plavio_sub_edge_shadow),
                                com.github.damontecres.wholphin.plavio.SubtitleEdge.RAISED to
                                    stringResource(R.string.plavio_sub_edge_raised),
                                com.github.damontecres.wholphin.plavio.SubtitleEdge.DEPRESSED to
                                    stringResource(R.string.plavio_sub_edge_depressed),
                            )
                        edgeLabels.chunked(3).forEach { line ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                line.forEach { (edge, label) ->
                                    PanelChip(
                                        text = label,
                                        selected = style.edgeType == edge,
                                        onClick = {
                                            onStyleChange(
                                                style.copy(
                                                    edgeType = edge,
                                                    outlineEnabled =
                                                        edge != com.github.damontecres.wholphin.plavio.SubtitleEdge.NONE,
                                                ),
                                            )
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    SwatchRow(
                        label = stringResource(R.string.plavio_sub_edge_color),
                        swatches = SUBTITLE_OUTLINE_SWATCHES,
                        selectedRgb = style.outlineColorRgb,
                        enabled =
                            style.edgeType != com.github.damontecres.wholphin.plavio.SubtitleEdge.NONE,
                        onPick = { rgb -> onStyleChange(style.copy(outlineColorRgb = rgb)) },
                    )
                }
                // Caption background (v0.3.22): colour + opacity —
                // opacity 0 keeps the historic no-box look.
                item {
                    PanelChip(
                        text = stringResource(R.string.plavio_sub_reset),
                        onClick = onResetDefaults,
                    )
                }
                item { Spacer(modifier = Modifier.height(4.dp)) }
            
            }
        }
        }
    }
}

/**
 * A Sample-B control row (v0.3.16, note 11): label on the left, a
 * segmented chip group on the right; the chosen segment carries
 * the white fill, and focus carries the white fill too (with an
 * ink edge, so a focused segment next to the chosen one still
 * reads as the cursor). Used for Size, Background and Position.
 */
@Composable
private fun SegmentRow(
    label: String,
    options: List<String>,
    selectedIndex: Int,
    onPick: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = Color.White,
            modifier = Modifier.weight(1f),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { index, option ->
                PanelChip(
                    text = option,
                    selected = index == selectedIndex,
                    enabled = enabled,
                    onClick = { onPick(index) },
                )
            }
        }
    }
}

@Composable
private fun PanelRailTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
        modifier = Modifier.padding(bottom = 4.dp),
    )
}

@Composable
private fun PanelRow(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    subText: String? = null,
) {
    // v0.3.16 (notes 2 + 11, Sample B): focus = the travelling
    // white fill (white row, ink text) — the pink ring is retired
    // in this panel family. The SELECTED row carries a ✓ at its
    // right edge (the sample's active-track mark) and bold white
    // text at rest.
    val ink = Color(0xFF131320)
    var rowFocused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier =
            modifier
                .fillMaxWidth()
                .onFocusChanged { rowFocused = it.isFocused },
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = Color.White,
                focusedContainerColor = Color.White,
                focusedContentColor = ink,
                pressedContainerColor = Color.White,
                pressedContentColor = ink,
            ),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (subText != null) {
                    Text(
                        text = subText,
                        style = MaterialTheme.typography.bodySmall,
                        color =
                            if (rowFocused) {
                                ink.copy(alpha = 0.65f)
                            } else {
                                PlavioOnyx.TextSecondary
                            },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (selected) {
                Text(
                    text = "✓",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun PanelChip(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    /** Selection signal: the white fill (v0.3.16, Sample B segments). */
    selected: Boolean = false,
) {
    // v0.3.16 (notes 2 + 11, Sample B): the chosen segment carries
    // the WHITE fill with ink text (the accent fill is retired in
    // this panel family), and focus is the same white fill plus an
    // ink edge — so a focused-but-unchosen segment beside the
    // chosen one still reads as the cursor, and nothing else in
    // the panel competes with the one white shape.
    val ink = Color(0xFF131320)
    val fill =
        if (selected) Color.White else PlavioOnyx.Background.copy(alpha = 0.7f)
    val content =
        if (selected) ink else Color.White
    Surface(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = fill,
                contentColor = content,
                focusedContainerColor = Color.White,
                focusedContentColor = ink,
                pressedContainerColor = Color.White,
                pressedContentColor = ink,
                disabledContainerColor = PlavioOnyx.Background.copy(alpha = 0.35f),
                disabledContentColor = PlavioOnyx.TextSecondary,
            ),
        border =
            ClickableSurfaceDefaults.border(
                focusedBorder =
                    androidx.tv.material3.Border(
                        border =
                            androidx.compose.foundation.BorderStroke(2.dp, ink),
                        shape = RoundedCornerShape(50),
                    ),
                pressedBorder =
                    androidx.tv.material3.Border(
                        border =
                            androidx.compose.foundation.BorderStroke(2.dp, ink),
                        shape = RoundedCornerShape(50),
                    ),
            ),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun StepperRow(
    label: String,
    value: String,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    stepValue: Int = 1,
    onReset: (() -> Unit)? = null,
    /** Chip glyphs (v0.3.24): the Position stepper passes ▼/▲ so
     * the control reads as move-down / move-up, not minus / plus. */
    decreaseText: String = "−",
    increaseText: String = "+",
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = Color.White,
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PanelChip(text = decreaseText, enabled = enabled, onClick = onDecrease)
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                color = if (enabled) Color.White else PlavioOnyx.TextSecondary,
                modifier = Modifier.width(76.dp),
            )
            PanelChip(text = increaseText, enabled = enabled, onClick = onIncrease)
            if (onReset != null) {
                PanelChip(
                    text = stringResource(R.string.plavio_sub_reset_short),
                    enabled = enabled,
                    onClick = onReset,
                )
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    on: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = Color.White,
            modifier = Modifier.weight(1f),
        )
        PanelChip(
            text =
                stringResource(
                    if (on) R.string.plavio_setting_on else R.string.plavio_setting_off,
                ),
            onClick = onToggle,
        )
    }
}

@Composable
private fun SwatchRow(
    label: String,
    swatches: List<Pair<String, Int>>,
    selectedRgb: Int,
    onPick: (Int) -> Unit,
    enabled: Boolean = true,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = Color.White,
        )
        // Two lines of circles, like the phone panel's swatch grid.
        swatches.chunked(5).forEach { line ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                line.forEach { (name, rgb) ->
                    val selected = rgb == selectedRgb
                    Surface(
                        onClick = { onPick(rgb) },
                        enabled = enabled,
                        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color(0xFF000000 or rgb.toLong()),
                                contentColor = Color.Transparent,
                                focusedContainerColor = Color(0xFF000000 or rgb.toLong()),
                                focusedContentColor = Color.Transparent,
                                disabledContainerColor = Color(0xFF000000 or rgb.toLong()).copy(alpha = 0.4f),
                                disabledContentColor = Color.Transparent,
                            ),
                        border =
                            ClickableSurfaceDefaults.border(
                                border =
                                    androidx.tv.material3.Border(
                                        border =
                                            androidx.compose.foundation.BorderStroke(
                                                if (selected) 3.dp else 1.dp,
                                                // v0.3.16 (Sample B): the
                                                // chosen colour carries a
                                                // WHITE ring, not accent.
                                                if (selected) {
                                                    Color.White
                                                } else {
                                                    PlavioOnyx.GlassBorder
                                                },
                                            ),
                                        shape = CircleShape,
                                    ),
                                focusedBorder =
                                    androidx.tv.material3.Border(
                                        border =
                                            androidx.compose.foundation.BorderStroke(
                                                // Travelling-white focus ring.
                                                2.5.dp,
                                                Color.White,
                                            ),
                                        shape = CircleShape,
                                    ),
                            ),
                        modifier = Modifier.size(30.dp),
                    ) {
                        // The circle itself is the swatch; `name` is the
                        // phone panel's label for this colour.
                        Box(modifier = Modifier.size(30.dp))
                    }
                }
            }
        }
    }
}

/** Curated language choices for the preferred-language pickers (ISO 639-1). */
internal val SUBTITLE_LANGUAGE_CODES =
    listOf(
        "en", "ur", "hi", "ar", "es", "fr", "de", "tr", "bn", "pa",
        "ta", "te", "ml", "id", "pt", "ru", "it", "ja", "ko", "zh",
    )

/** Display host for an addon subtitle URL ("Addon" when it doesn't parse). */
private fun subtitleSourceHost(url: String): String? =
    runCatching { java.net.URI(url).host }
        .getOrNull()
        ?.removePrefix("www.")
        ?.takeIf { it.isNotBlank() }

/**
 * Standalone preferred-language picker with the subtitle panel's
 * chrome — used by the player's Audio panel for the preferred audio
 * language (the pickers' home is the player now, not Settings).
 */
@Composable
fun PreferredLanguagePanel(
    title: String,
    current: String?,
    onPick: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    Column(
        modifier =
            modifier
                .width(320.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        PanelRailTitle(title)
        PanelRow(
            text = stringResource(R.string.plavio_settings_lang_none),
            selected = current == null,
            onClick = { onPick(null) },
            modifier = Modifier.focusRequester(firstFocus),
        )
        LazyColumn(
            modifier = Modifier.height(360.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(SUBTITLE_LANGUAGE_CODES, key = { it }) { code ->
                PanelRow(
                    text = languageDisplayName(code),
                    selected = code == current,
                    onClick = { onPick(code) },
                )
            }
        }
        Text(
            text = stringResource(R.string.plavio_sub_pref_note),
            style = MaterialTheme.typography.bodySmall,
            color = PlavioOnyx.TextSecondary,
        )
    }
}

private fun formatPanelTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val millis = ms % 1000
    return "%d:%02d.%03d".format(minutes, seconds, millis)
}
