package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.plavio.CastMember
import com.github.damontecres.wholphin.plavio.MetaPreview

/**
 * Shared cards for the Plavio TV flow: poster cards with the phone's
 * glass ★ rating chip, and cast/person cards. Used by Home, Search,
 * Detail (cast + related rows), the actor page and Live.
 */

/** The phone's glass ★ chip: rating over the poster's top-left corner. */
@Composable
fun RatingChip(
    rating: String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier =
            modifier
                .clip(RoundedCornerShape(50))
                .background(PlavioOnyx.GlassFillStrong)
                .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "★",
            style = MaterialTheme.typography.labelMedium,
            color = LocalPlavioAccent.current.primary,
        )
        Text(
            text = rating,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White,
        )
    }
}

@Composable
fun SharedPosterCard(
    item: MetaPreview,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showTitle: Boolean = true,
    onFocus: (() -> Unit)? = null,
    /** v0.3.14: an identity-keyed requester for armed restores —
     * the card's owner keeps one per item so a return can land on
     * this exact card. Applied to the Card (the focusable node). */
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null,
) {
    // Overhaul (v0.3.11): the approved samples show a clean poster-only
    // card (14dp radius, hairline border, Weave-pink focus ring) with
    // the title + year printed UNDER it — uniform on every shelf.
    Column(modifier = modifier.width(124.dp)) {
        Card(
            onClick = onClick,
            modifier =
                Modifier
                    .fillMaxWidth()
                    .then(
                        if (focusRequester != null) {
                            Modifier.focusRequester(focusRequester)
                        } else {
                            Modifier
                        },
                    )
                    .then(
                        if (onFocus != null) {
                            Modifier.onFocusChanged { state ->
                                if (state.isFocused) onFocus()
                            }
                        } else {
                            Modifier
                        },
                    ),
            shape = plavioCardShape(RoundedCornerShape(14.dp)),
            colors = plavioCardColors(),
            border = plavioCardBorder(RoundedCornerShape(14.dp)),
            scale = plavioCardScale(),
        ) {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (item.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(item.poster)
                                // v0.3.12 perf: decode at display size
                                // (124dp card × 2 headroom), not the
                                // original — full-size poster decodes
                                // were a main scroll-jank source on
                                // 32-bit TVs.
                                .size(248, 372)
                                .crossfade(false)
                                .build(),
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = item.name.take(1),
                        style = MaterialTheme.typography.displaySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                item.imdbRating?.takeIf { it.isNotBlank() }?.let { rating ->
                    RatingChip(
                        rating = rating,
                        modifier =
                            Modifier
                                .align(Alignment.TopStart)
                                .padding(6.dp),
                    )
                }
            }
        }
        if (showTitle) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = PlavioOnyx.TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp),
            )
            item.releaseInfo
                ?.take(4)
                ?.takeIf { it.isNotBlank() }
                ?.let { year ->
                    Text(
                        text = year,
                        style = MaterialTheme.typography.bodySmall,
                        color = PlavioOnyx.TextSecondary,
                        maxLines = 1,
                    )
                }
        }
    }
}

/** A cast member / person search result: round photo over the name. */
@Composable
fun PersonCard(
    member: CastMember,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    /** v0.3.14: identity-keyed requester for armed restores (see
     * SharedPosterCard). Applied to the Card itself. */
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null,
) {
    Card(
        onClick = onClick,
        modifier =
            modifier
                .width(110.dp)
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                ),
        shape = plavioCardShape(RoundedCornerShape(14.dp)),
        colors = CardDefaults.colors(containerColor = Color.Transparent),
        border = plavioCardBorder(RoundedCornerShape(14.dp)),
        scale = plavioCardScale(),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 8.dp),
        ) {
            Box(
                modifier =
                    Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (member.photo != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(member.photo)
                                .size(168, 168)
                                .crossfade(false)
                                .build(),
                        contentDescription = member.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = member.name.take(1),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text(
                text = member.name,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
            )
        }
    }
}
