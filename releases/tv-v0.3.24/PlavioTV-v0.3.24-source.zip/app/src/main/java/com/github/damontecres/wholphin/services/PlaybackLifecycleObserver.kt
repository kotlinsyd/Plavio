package com.github.damontecres.wholphin.services

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import dagger.hilt.android.scopes.ActivityRetainedScoped
import javax.inject.Inject

/**
 * Observes the activity lifecycle in order to pause/resume/stop playback
 */
@ActivityRetainedScoped
class PlaybackLifecycleObserver
    @Inject
    constructor(
        private val playerFactory: PlayerFactory,
    ) : DefaultLifecycleObserver {
        private var wasPlaying: Boolean? = null

        override fun onStart(owner: LifecycleOwner) {
            wasPlaying = null
        }

        override fun onResume(owner: LifecycleOwner) {
            if (wasPlaying == true) {
                playerFactory.currentPlayer?.let {
                    if (!it.isReleased) it.play()
                }
            }
        }

        override fun onPause(owner: LifecycleOwner) {
            playerFactory.currentPlayer?.let {
                wasPlaying = it.isPlaying
                it.pause()
            }
        }
    }
