package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.download.DownloadEntry
import com.github.damontecres.wholphin.plavio.download.DownloadStatus
import com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import javax.inject.Inject

@HiltViewModel
class PlavioDownloadsViewModel
    @Inject
    constructor(
        private val downloadManager: PlavioDownloadManager,
    ) : ViewModel() {
        val entries: StateFlow<List<DownloadEntry>> = downloadManager.entries

        fun pause(id: String) = downloadManager.pause(id)

        fun resume(id: String) = downloadManager.resume(id)

        fun delete(id: String) = downloadManager.delete(id)

        /** The offline playback request for a finished download, or null if the file is gone. */
        fun playRequest(entry: DownloadEntry): PlaybackRequest? {
            if (entry.status != DownloadStatus.COMPLETED) return null
            val file = File(entry.filePath)
            if (!file.exists() || file.length() == 0L) return null
            return PlaybackRequest(
                streamUrl = "file://${entry.filePath}",
                title = entry.title,
                poster = entry.poster,
                videoId = entry.videoId,
                season = entry.season,
                episode = entry.episode,
                isMovie = entry.type == "movie",
                type = entry.type,
                streamLabel = "Download",
                sourceName = entry.sourceName,
                metaId = entry.metaId,
                seriesName = entry.seriesName,
                episodeTitle = entry.episodeTitle,
            )
        }
    }
