package com.github.damontecres.wholphin.plavio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.github.damontecres.wholphin.MainActivity
import com.github.damontecres.wholphin.R
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** One detected new episode, surfaced on Home and as a notification. */
data class EpisodeAlert(
    val metaId: String,
    val showName: String,
    val poster: String?,
    val baseUrl: String,
    val season: Int,
    val episode: Int,
    val episodeTitle: String?,
    val foundAt: Long,
)

/**
 * Pending episode alerts (in-app surfacing): a small SharedPreferences
 * list the Home screen reads into its "New episodes" rail. One alert
 * per show — a newer detection replaces the older one.
 */
object EpisodeAlertStore {
    private const val PREFS = "plavio_episode_alerts"
    private const val KEY_ALERTS = "alerts"

    private val mutableAlerts = MutableStateFlow<List<EpisodeAlert>>(emptyList())
    val alerts: StateFlow<List<EpisodeAlert>> = mutableAlerts

    fun initialize(context: Context) {
        mutableAlerts.value = load(context)
    }

    fun add(
        context: Context,
        alert: EpisodeAlert,
    ) {
        val updated =
            (mutableAlerts.value.filter { it.metaId != alert.metaId } + alert)
                .sortedByDescending { it.foundAt }
        mutableAlerts.value = updated
        save(context, updated)
    }

    fun clearFor(
        context: Context,
        metaId: String,
    ) {
        val updated = mutableAlerts.value.filter { it.metaId != metaId }
        if (updated.size != mutableAlerts.value.size) {
            mutableAlerts.value = updated
            save(context, updated)
        }
    }

    private fun load(context: Context): List<EpisodeAlert> {
        val raw =
            context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_ALERTS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                EpisodeAlert(
                    metaId = obj.optString("metaId"),
                    showName = obj.optString("showName"),
                    poster = obj.optString("poster").takeIf { it.isNotBlank() },
                    baseUrl = obj.optString("baseUrl"),
                    season = obj.optInt("season"),
                    episode = obj.optInt("episode"),
                    episodeTitle = obj.optString("episodeTitle").takeIf { it.isNotBlank() },
                    foundAt = obj.optLong("foundAt"),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(
        context: Context,
        alerts: List<EpisodeAlert>,
    ) {
        val array = JSONArray()
        alerts.forEach { alert ->
            array.put(
                JSONObject()
                    .put("metaId", alert.metaId)
                    .put("showName", alert.showName)
                    .put("poster", alert.poster ?: "")
                    .put("baseUrl", alert.baseUrl)
                    .put("season", alert.season)
                    .put("episode", alert.episode)
                    .put("episodeTitle", alert.episodeTitle ?: "")
                    .put("foundAt", alert.foundAt),
            )
        }
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ALERTS, array.toString())
            .apply()
    }
}

/**
 * Episode-release alerts (phone parity): a periodic WorkManager check
 * plus an in-app check on Home load. Followed shows are the series in
 * Continue Watching. The first check per show only records a baseline —
 * no alert — so enabling the feature never spams.
 */
object EpisodeAlerts {
    const val CHANNEL_ID = "episode_releases"
    const val WORK_NAME = "plavio_episode_check"
    const val CHECK_INTERVAL_HOURS = 12L

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.plavio_notif_channel_episodes),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = context.getString(R.string.plavio_notif_channel_episodes_desc)
            },
        )
    }

    fun ensureScheduled(
        context: Context,
        enabled: Boolean,
    ) {
        val appContext = context.applicationContext
        if (!enabled) {
            runCatching { WorkManager.getInstance(appContext).cancelUniqueWork(WORK_NAME) }
            return
        }
        ensureChannel(appContext)
        val request =
            PeriodicWorkRequestBuilder<EpisodeCheckWorker>(CHECK_INTERVAL_HOURS, TimeUnit.HOURS)
                .setConstraints(
                    Constraints
                        .Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .setRequiresBatteryNotLow(true)
                        .build(),
                ).addTag(WORK_NAME)
                .build()
        runCatching {
            WorkManager
                .getInstance(appContext)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }

    fun postNewEpisode(
        context: Context,
        alert: EpisodeAlert,
    ) {
        val appContext = context.applicationContext
        if (!NotificationManagerCompat.from(appContext).areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        ensureChannel(appContext)
        val intent =
            Intent(appContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
        val pendingIntent =
            PendingIntent.getActivity(
                appContext,
                alert.metaId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        val epLabel = "S${alert.season} E${alert.episode}"
        val text =
            if (alert.episodeTitle.isNullOrBlank()) {
                appContext.getString(R.string.plavio_notif_new_episode_text, epLabel)
            } else {
                appContext.getString(
                    R.string.plavio_notif_new_episode_text_titled,
                    epLabel,
                    alert.episodeTitle,
                )
            }
        val notification =
            NotificationCompat
                .Builder(appContext, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_foreground)
                .setContentTitle(alert.showName)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        try {
            NotificationManagerCompat.from(appContext).notify(alert.metaId.hashCode(), notification)
        } catch (_: SecurityException) {
            // Permission revoked between the check and notify().
        }
    }

    /**
     * One check pass over the followed shows. Failures are contained per
     * show; an unreachable addon simply means "try again next cycle".
     */
    suspend fun runCheck(
        context: Context,
        repository: AddonCatalogRepository,
        progressStore: PlavioProgressStore,
    ) {
        val appContext = context.applicationContext
        val tracker = EpisodeTracker(appContext)
        val series =
            progressStore.entries.value
                .filter { it.type == "series" }
                .distinctBy { it.metaId }
        if (series.isEmpty()) {
            tracker.prune(emptySet())
            return
        }
        val baseUrl = repository.primaryMetaBaseUrl() ?: return
        val keepKeys = mutableSetOf<String>()
        for (entry in series) {
            keepKeys.add(EpisodeTracker.key(entry.metaId))
            runCatching {
                val meta = repository.loadMeta(baseUrl, "series", entry.metaId) ?: return@runCatching
                val newest = newestReleased(meta.videos) ?: return@runCatching
                val last = tracker.lastKnown(entry.metaId)
                if (last == null) {
                    tracker.update(entry.metaId, newest.first, newest.second)
                } else if (isNewer(newest.first, newest.second, last.first, last.second)) {
                    val epTitle =
                        meta.videos
                            .firstOrNull { it.season == newest.first && it.episode == newest.second }
                            ?.title
                            ?.takeIf { it.isNotBlank() }
                    val alert =
                        EpisodeAlert(
                            metaId = entry.metaId,
                            showName = entry.seriesName ?: meta.name,
                            poster = entry.poster ?: meta.poster,
                            baseUrl = baseUrl,
                            season = newest.first,
                            episode = newest.second,
                            episodeTitle = epTitle,
                            foundAt = System.currentTimeMillis(),
                        )
                    EpisodeAlertStore.add(appContext, alert)
                    postNewEpisode(appContext, alert)
                    tracker.update(entry.metaId, newest.first, newest.second)
                }
            }.onFailure { Timber.v(it, "Episode check failed for %s", entry.metaId) }
        }
        tracker.prune(keepKeys)
    }

    private fun isNewer(
        s: Int,
        e: Int,
        lastS: Int,
        lastE: Int,
    ): Boolean = s > lastS || (s == lastS && e > lastE)

    /** Newest episode that has actually aired (phone logic). */
    private fun newestReleased(videos: List<Video>): Pair<Int, Int>? {
        val today = runCatching { LocalDate.now() }.getOrNull()
        return videos
            .filter { v -> today == null || v.released == null || !isFutureDate(v.released, today) }
            .maxWithOrNull(compareBy({ it.season }, { it.episode }))
            ?.let { it.season to it.episode }
    }

    private fun isFutureDate(
        raw: String,
        today: LocalDate,
    ): Boolean {
        val parts = raw.take(10).split("-")
        if (parts.size != 3) return false
        val y = parts[0].toIntOrNull() ?: return false
        val m = parts[1].toIntOrNull() ?: return false
        val d = parts[2].toIntOrNull() ?: return false
        return runCatching { LocalDate.of(y, m, d).isAfter(today) }.getOrDefault(false)
    }
}

/** Periodic background episode check (12 h, phone parity). */
@HiltWorker
class EpisodeCheckWorker
    @AssistedInject
    constructor(
        @Assisted appContext: Context,
        @Assisted params: WorkerParameters,
        private val repository: AddonCatalogRepository,
        private val progressStore: PlavioProgressStore,
        private val uiPrefs: PlavioUiPrefs,
    ) : CoroutineWorker(appContext, params) {
        override suspend fun doWork(): Result {
            if (!uiPrefs.episodeAlertsEnabled.value) {
                EpisodeAlerts.ensureScheduled(applicationContext, enabled = false)
                return Result.success()
            }
            EpisodeAlerts.runCheck(applicationContext, repository, progressStore)
            return Result.success()
        }
    }
