package com.github.damontecres.wholphin.plavio.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.cloud.GoogleDriveSyncManager
import com.github.damontecres.wholphin.plavio.cloud.PlavioAccountManager
import com.github.damontecres.wholphin.plavio.cloud.PlavioBackup
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Everything the Settings → Account section renders. */
data class PlavioAccountUiState(
    val plavioConfigured: Boolean = false,
    val plavioEmail: String? = null,
    val plavioLastSync: String? = null,
    val googleAccounts: List<String> = emptyList(),
    val googleEmail: String? = null,
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    /** Set after "Forgot password" succeeded: the reset-code form shows. */
    val resetRequestedFor: String? = null,
)

/**
 * Settings → Account: the phone's two sync doors on TV — the Plavio
 * account (Supabase Auth, no email verification) and Google Drive sync
 * (system account + Drive app folder), both carrying the same backup
 * payload via [PlavioBackup].
 */
@HiltViewModel
class PlavioAccountsViewModel
    @Inject
    constructor(
        @param:ApplicationContext context: Context,
        backup: PlavioBackup,
    ) : ViewModel() {
        private val accountManager = PlavioAccountManager(context, backup)
        private val driveManager = GoogleDriveSyncManager(context, backup)

        private val _state = MutableStateFlow(PlavioAccountUiState())
        val state: StateFlow<PlavioAccountUiState> = _state

        /** A Google auth prompt the UI layer must launch (Drive token consent). */
        private val _authIntent = MutableStateFlow<Intent?>(null)
        val authIntent: StateFlow<Intent?> = _authIntent

        init {
            refresh()
        }

        fun consumeAuthIntent() {
            _authIntent.value = null
        }

        fun refresh() {
            _state.value =
                _state.value.copy(
                    plavioConfigured = PlavioAccountManager.isConfigured(),
                    plavioEmail = accountManager.accountEmail(),
                    plavioLastSync = accountManager.lastSyncTime(),
                    googleAccounts = driveManager.getGoogleAccounts().map { it.name },
                    googleEmail = driveManager.getAccountEmail(),
                )
        }

        private fun run(
            onDone: (String) -> Unit,
            block: suspend () -> Unit,
        ) {
            if (_state.value.busy) return
            _state.value = _state.value.copy(busy = true, message = null, error = null)
            viewModelScope.launch {
                runCatching { block() }
                    .onSuccess { onDone("Done") }
                    .onFailure { e ->
                        if (e is GoogleDriveSyncManager.AuthRequiredException) {
                            _authIntent.value = e.intent
                            _state.value =
                                _state.value.copy(
                                    busy = false,
                                    message = "Approve Google access in the prompt, then try again.",
                                )
                        } else {
                            _state.value =
                                _state.value.copy(
                                    busy = false,
                                    error = e.message ?: "Something went wrong.",
                                )
                        }
                        refresh()
                    }
            }
        }

        private fun finish(message: String) {
            _state.value = _state.value.copy(busy = false, message = message, error = null)
            refresh()
        }

        // --------------------------------------------------------------
        // Plavio account
        // --------------------------------------------------------------

        fun plavioSignIn(
            email: String,
            password: String,
        ) {
            run(onDone = { }) {
                accountManager.signIn(email.trim(), password).getOrThrow()
                val restored = accountManager.syncAfterSignIn().getOrDefault(false)
                finish(
                    if (restored) {
                        "Signed in — your backup was restored."
                    } else {
                        "Signed in — backup saved."
                    },
                )
            }
        }

        fun plavioSignUp(
            email: String,
            password: String,
        ) {
            run(onDone = { }) {
                val sessionNow = accountManager.signUp(email.trim(), password).getOrThrow()
                if (sessionNow) {
                    val restored = accountManager.syncAfterSignIn().getOrDefault(false)
                    finish(
                        if (restored) {
                            "Account created — your backup was restored."
                        } else {
                            "Account created — backup saved."
                        },
                    )
                } else {
                    finish("Account created — sign in to continue.")
                }
            }
        }

        /** Changes the signed-in account's password (Account page, v0.3.21). */
        fun plavioChangePassword(newPassword: String) {
            run(onDone = { }) {
                accountManager.changePassword(newPassword).getOrThrow()
                finish("Password changed.")
            }
        }

        fun plavioSignOut() {
            run(onDone = { }) {
                accountManager.signOut()
                finish("Signed out.")
            }
        }

        fun plavioForgot(email: String) {
            run(onDone = { }) {
                accountManager.requestPasswordReset(email.trim()).getOrThrow()
                _state.value = _state.value.copy(resetRequestedFor = email.trim())
                finish("Reset code sent — check your email.")
            }
        }

        fun plavioResetPassword(
            email: String,
            code: String,
            newPassword: String,
        ) {
            run(onDone = { }) {
                accountManager
                    .verifyResetAndSetPassword(email.trim(), code.trim(), newPassword)
                    .getOrThrow()
                _state.value = _state.value.copy(resetRequestedFor = null)
                finish("Password updated — sign in with the new password.")
            }
        }

        fun plavioSync() {
            run(onDone = { }) {
                accountManager.syncNow().getOrThrow()
                finish("Backup saved to your Plavio account.")
            }
        }

        fun plavioRestore() {
            run(onDone = { }) {
                val found = accountManager.restoreFromAccount().getOrThrow()
                finish(
                    if (found) {
                        "Backup restored."
                    } else {
                        "No backup found on this account yet."
                    },
                )
            }
        }

        /** Addons-only sync: pull the account backup's addon list into this TV. */
        fun plavioSyncAddons() {
            run(onDone = { }) {
                val added = accountManager.syncAddonsFromAccount().getOrThrow()
                finish(
                    when {
                        added == null -> "No backup found on this account yet."
                        added == 0 -> "No new addons — this TV already has them all."
                        added == 1 -> "1 addon added from your account."
                        else -> "$added addons added from your account."
                    },
                )
            }
        }

        // --------------------------------------------------------------
        // Google Drive
        // --------------------------------------------------------------

        fun googleSelect(email: String) {
            val account = driveManager.getGoogleAccounts().firstOrNull { it.name == email } ?: return
            driveManager.selectAccount(account)
            refresh()
            run(onDone = { }) {
                val restored = driveManager.syncAfterSignIn().getOrThrow()
                finish(
                    if (restored) {
                        "Google backup restored."
                    } else {
                        "Google account connected — backup saved."
                    },
                )
            }
        }

        fun googleSignOut() {
            driveManager.signOut()
            refresh()
            _state.value = _state.value.copy(message = "Google account disconnected.")
        }

        fun googleBackup() {
            run(onDone = { }) {
                driveManager.backupNow().getOrThrow()
                finish("Backup saved to Google Drive.")
            }
        }

        fun googleRestore() {
            run(onDone = { }) {
                val found = driveManager.restoreFromCloud().getOrThrow()
                finish(
                    if (found) {
                        "Google backup restored."
                    } else {
                        "No backup found in Google Drive yet."
                    },
                )
            }
        }
    }
