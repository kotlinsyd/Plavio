package com.github.damontecres.wholphin.services

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Small app-start helpers that used to live alongside the (removed)
 * Wholphin-era upgrade migrations.
 */
@Singleton
class AppUpgradeHandler
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        /**
         * Copies the bundled subtitle font out of assets so the ASS subtitle
         * renderer can use it from the filesystem.
         */
        fun copySubfont(overwrite: Boolean) {
            try {
                val fontFileName = "subfont.ttf"
                val outputFile = File(context.filesDir, fontFileName)
                if (!outputFile.exists() || overwrite) {
                    context.assets.open(fontFileName).use { input ->
                        outputFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    Timber.i("Wrote font %s to local", fontFileName)
                }
            } catch (ex: Exception) {
                Timber.e(ex, "Exception copying subfont.tff")
            }
        }
    }
