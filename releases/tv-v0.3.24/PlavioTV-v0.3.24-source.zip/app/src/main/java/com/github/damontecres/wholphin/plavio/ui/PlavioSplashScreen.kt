package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.github.damontecres.wholphin.R
import kotlinx.coroutines.delay

// Minimum time the splash stays up (normal motion): the exit also
// waits for the clip to end, so this is a floor, not the duration.
private const val SPLASH_MIN_MS = 2400L

// Hard safety cap: if the player neither ends nor errors (wedged
// codec), the splash finishes anyway instead of hanging on launch.
private const val SPLASH_CAP_MS = 5000L

// Reduced-motion hold: poster only, no clip, out quickly.
private const val SPLASH_REDUCED_MS = 600L

/**
 * Launch splash — the owner-locked HUG startup (the whole Weave mark
 * stays connected in every frame, squeezes in a short hug, then the
 * signature PLAVIO lettering, gradient underline and tagline; FINAL
 * pick locked 2026-10-29, replacing the Sample G orbit build). TV
 * plays the dedicated LANDSCAPE render bundled at
 * res/raw/splash_g_orbit_build.mp4 (1920x1080, 70 frames, ~2.33s —
 * the locked portrait master's own frames, scaled and centred for
 * 16:9) with
 * [AspectRatioFrameLayout.RESIZE_MODE_FIT]: the lockup sits centred
 * at its proper size, never zoom-cropped. (v0.3.0/0.3.1 wrongly played
 * the portrait phone clip with RESIZE_MODE_ZOOM — the mark blew up
 * huge and cropped on TV screens.)
 *
 * Exit rule (TV has no feed-wait): [onDone] fires when the clip has
 * ENDED and at least ~2.4s have elapsed since start, with a 5s hard
 * cap so a wedged player still finishes. On player error — or if
 * video fails entirely — the clip's last frame
 * (res/drawable-nodpi/splash_g_last_frame.png, the landscape frame) is
 * shown for the remaining wait and the splash finishes after the
 * minimum time. Reduced motion: the poster only, finished after
 * ~600ms.
 *
 * No loader overlay (v0.3.2): the extra OrbitLoader that used to spin
 * bottom-centre is not part of the locked design and is gone.
 */
@Composable
fun PlavioSplashScreen(
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    // Reduced motion: poster only, no player is even built.
    val reduced = com.github.damontecres.wholphin.plavio.rememberReducedMotion()

    var clipDone by remember { mutableStateOf(false) }
    var minTimeDone by remember { mutableStateOf(false) }
    var videoFailed by remember { mutableStateOf(false) }
    var doneFired by remember { mutableStateOf(false) }

    val player =
        remember(reduced) {
            if (reduced) {
                null
            } else {
                ExoPlayer.Builder(context.applicationContext).build().apply {
                    setMediaItem(
                        MediaItem.fromUri(
                            RawResourceDataSource.buildRawResourceUri(R.raw.splash_g_orbit_build),
                        ),
                    )
                    volume = 0f
                    repeatMode = Player.REPEAT_MODE_OFF
                    playWhenReady = true
                    prepare()
                }
            }
        }

    DisposableEffect(player) {
        val active = player
        if (active == null) {
            onDispose { }
        } else {
            val listener =
                object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) clipDone = true
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        // Show the poster; the min-time gate below
                        // still decides when the splash finishes.
                        videoFailed = true
                        clipDone = true
                    }
                }
            active.addListener(listener)
            onDispose {
                active.removeListener(listener)
                active.release()
            }
        }
    }

    // Reduced motion needs no clip end to wait for.
    LaunchedEffect(reduced) {
        if (reduced) clipDone = true
    }
    // The minimum stay: ~2.4s normally, ~600ms with reduced motion.
    LaunchedEffect(reduced) {
        delay(if (reduced) SPLASH_REDUCED_MS else SPLASH_MIN_MS)
        minTimeDone = true
    }
    // Hard safety cap (normal motion only — reduced exits at 600ms):
    // a player that neither ends nor errors must not trap the splash.
    LaunchedEffect(reduced) {
        if (!reduced) {
            delay(SPLASH_CAP_MS)
            clipDone = true
        }
    }
    LaunchedEffect(clipDone, minTimeDone) {
        if (clipDone && minTimeDone && !doneFired) {
            doneFired = true
            onDone()
        }
    }

    val showPoster = reduced || videoFailed
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(Color(0xFF04060C)),
    ) {
        if (showPoster || player == null) {
            Image(
                painter = painterResource(R.drawable.splash_g_last_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(0xFF04060C.toInt())
                        this.player = player
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}
