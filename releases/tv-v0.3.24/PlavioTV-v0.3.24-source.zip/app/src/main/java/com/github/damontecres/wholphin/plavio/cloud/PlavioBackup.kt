package com.github.damontecres.wholphin.plavio.cloud

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.github.damontecres.wholphin.BuildConfig
import com.github.damontecres.wholphin.plavio.AddonManifest
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.InstalledAddon
import com.github.damontecres.wholphin.plavio.PlavioProgressStore
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.SubtitleStyle
import com.github.damontecres.wholphin.plavio.SubtitleStyleStore
import com.github.damontecres.wholphin.plavio.ui.PlavioAccent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioBackupDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_backup_passthrough")

/**
 * Builds and applies Plavio backup payloads on TV — the SAME envelope
 * the phone app syncs through the Plavio account and Google Drive
 * (`format: "plavio-backup"`, version 2), so a backup made on either
 * device restores on the other:
 *
 * - `addons` and `playback` are the shared sections, written in the
 *   phone's exact field format (types/resources as comma-joined
 *   strings, playback keyed rows) and read back the same way.
 * - Sections TV doesn't own (the phone's settings map, watchlist,
 *   custom lists, API keys, profile photo) are never dropped: whatever
 *   the last imported backup carried is kept verbatim and re-emitted on
 *   the next export, so syncing from the TV can never erase phone-only
 *   data.
 * - TV-only state rides in `tvSettings` (accent, subtitle style,
 *   autoplay switches), which the phone's parser simply ignores.
 */
@Singleton
class PlavioBackup
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        private val addonStore: AddonStore,
        private val progressStore: PlavioProgressStore,
        private val uiPrefs: PlavioUiPrefs,
        private val subtitleStyleStore: SubtitleStyleStore,
        private val watchlistStore: com.github.damontecres.wholphin.plavio.PlavioWatchlistStore,
    ) {
        private val passthroughStore = context.plavioBackupDataStore

        suspend fun exportJson(): Result<String> =
            runCatching {
                val passthrough = readPassthrough()
                val root = JSONObject()
                root.put("format", "plavio-backup")
                root.put("version", 2)
                root.put("exportedAt", System.currentTimeMillis())
                root.put("appVersion", BuildConfig.VERSION_NAME)
                root.put(
                    "coverage",
                    "settings,addons,watchlist,playback,customLists; downloads excluded",
                )

                // Phone-owned sections ride through untouched.
                root.put("settings", passthrough?.optJSONObject("settings") ?: JSONObject())
                // Watchlist (v0.3.21): the TV now owns a local My List
                // store, so the export is the UNION — TV entries in the
                // phone's field format first, then any passthrough rows
                // the TV store doesn't have (phone-only saves ride on).
                val watchlist = JSONArray()
                val localKeys = mutableSetOf<String>()
                watchlistStore.entries.value.forEach { entry ->
                    localKeys += entry.key
                    watchlist.put(
                        JSONObject()
                            .put("key", "${entry.type}:${entry.metaId}")
                            .put("addonId", "")
                            .put("type", entry.type)
                            .put("metaId", entry.metaId)
                            .put("name", entry.name)
                            .put("poster", entry.poster ?: JSONObject.NULL)
                            .put("addedAt", entry.addedAt)
                            .put("logo", JSONObject.NULL),
                    )
                }
                passthrough?.optJSONArray("watchlist")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val key = "${o.optString("type")}|${o.optString("metaId")}"
                        if (key !in localKeys) watchlist.put(o)
                    }
                }
                root.put("watchlist", watchlist)
                root.put("customLists", passthrough?.optJSONArray("customLists") ?: JSONArray())
                root.put(
                    "customListItems",
                    passthrough?.optJSONArray("customListItems") ?: JSONArray(),
                )
                passthrough?.optJSONObject("api_keys")?.let { root.put("api_keys", it) }
                // Profile photo: the TV's own photo (Account page) wins;
                // otherwise the phone's rides through untouched.
                (uiPrefs.profilePhotoBase64.value
                    ?: passthrough?.optString("profilePhoto")?.takeIf { it.isNotBlank() })
                    ?.let { root.put("profilePhoto", it) }

                val addons = JSONArray()
                addonStore.addons.value.forEachIndexed { index, addon ->
                    val m = addon.manifest
                    addons.put(
                        JSONObject()
                            .put("id", m.id)
                            .put("name", m.name)
                            .put("version", m.version)
                            .put("description", m.description)
                            .put("baseUrl", addon.baseUrl)
                            .put("types", m.types.joinToString(","))
                            .put("resources", m.resources.joinToString(","))
                            .put("preinstalled", addon.preinstalled)
                            .put("enabled", addon.enabled)
                            .put("configurable", m.configurable)
                            .put("showOnHome", true)
                            .put("logoUrl", m.logo ?: JSONObject.NULL)
                            .put("sortOrder", index)
                            .put("starred", false)
                            .put("addedAt", 0),
                    )
                }
                root.put("addons", addons)

                val playback = JSONArray()
                progressStore.entries.value.forEach { entry ->
                    playback.put(
                        JSONObject()
                            .put("key", entry.key)
                            .put("title", entry.title)
                            .put("poster", entry.poster ?: JSONObject.NULL)
                            .put("videoId", entry.videoId)
                            .put("streamUrl", entry.streamUrl)
                            .put("positionMs", entry.positionMs)
                            .put("durationMs", entry.durationMs)
                            .put(
                                "imdbId",
                                Regex("""tt\d+""").find(entry.metaId)?.value ?: JSONObject.NULL,
                            )
                            .put("season", entry.season)
                            .put("episode", entry.episode)
                            .put("updatedAt", entry.updatedAt),
                    )
                }
                root.put("playback", playback)

                val style = subtitleStyleStore.style.value
                root.put(
                    "tvSettings",
                    JSONObject()
                        .put("accent", uiPrefs.accent.value.name)
                        .put("autoplayBestStream", uiPrefs.autoplayBestStream.value)
                        .put("autoPlayNextEpisode", uiPrefs.autoPlayNextEpisode.value)
                        .put("subtitleFontSizeSp", style.fontSizeSp)
                        .put("subtitleTextColorRgb", style.textColorRgb)
                        .put("subtitleOpacityPercent", style.opacityPercent)
                        .put("subtitleBold", style.bold)
                        .put("subtitleOutlineEnabled", style.outlineEnabled)
                        .put("subtitleOutlineColorRgb", style.outlineColorRgb)
                        .put("subtitleBottomOffset", style.bottomOffset),
                )
                root.toString()
            }

        /** Applies a backup payload. Returns true when it parsed as a Plavio backup. */
        suspend fun importJson(json: String): Result<Unit> =
            runCatching {
                require(json.toByteArray(Charsets.UTF_8).size <= 10 * 1024 * 1024) {
                    "Backup exceeds the 10 MiB safety limit."
                }
                val root = JSONObject(json)
                require(root.optString("format") == "plavio-backup") { "Not a Plavio backup file." }

                // Keep every section TV doesn't own verbatim for re-export.
                writePassthrough(root)

                // Watchlist + profile photo (v0.3.21): the payload's
                // watchlist folds into the TV's own My List store, and
                // a photo the TV doesn't have yet is adopted.
                root.optJSONArray("watchlist")?.let { arr ->
                    val imported = mutableListOf<com.github.damontecres.wholphin.plavio.WatchlistEntry>()
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val type = o.optString("type").takeIf { it.isNotBlank() } ?: continue
                        val metaId = o.optString("metaId").takeIf { it.isNotBlank() } ?: continue
                        imported +=
                            com.github.damontecres.wholphin.plavio.WatchlistEntry(
                                type = type,
                                metaId = metaId,
                                name = o.optString("name"),
                                poster = o.optString("poster").takeIf { it.isNotBlank() },
                                addedAt = o.optLong("addedAt", 0),
                            )
                    }
                    watchlistStore.mergeImported(imported)
                }
                if (uiPrefs.profilePhotoBase64.value == null) {
                    root.optString("profilePhoto").takeIf { it.isNotBlank() }?.let {
                        uiPrefs.setProfilePhotoBase64(it)
                    }
                }

                root.optJSONArray("addons")?.let {
                    addonStore.importAddons(parseAddons(root))
                }

                root.optJSONArray("playback")?.let { arr ->
                    val entries = mutableListOf<ContinueWatchingEntry>()
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val videoId = o.optString("videoId").takeIf { it.isNotBlank() } ?: continue
                        val streamUrl = o.optString("streamUrl").takeIf { it.isNotBlank() } ?: continue
                        val season = o.optInt("season", 0)
                        val episode = o.optInt("episode", 0)
                        val type = if (season > 0 || episode > 0) "series" else "movie"
                        val imdbId = o.optString("imdbId").takeIf { it.isNotBlank() }
                        entries +=
                            ContinueWatchingEntry(
                                type = type,
                                videoId = videoId,
                                metaId = imdbId ?: videoId,
                                title = o.optString("title"),
                                poster = o.optString("poster").takeIf { it.isNotBlank() },
                                season = season,
                                episode = episode,
                                streamUrl = streamUrl,
                                positionMs = o.optLong("positionMs", 0),
                                durationMs = o.optLong("durationMs", 0),
                                updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                            )
                    }
                    progressStore.replaceAll(entries)
                }

                root.optJSONObject("tvSettings")?.let { tv ->
                    tv.optString("accent").takeIf { it.isNotBlank() }?.let {
                        uiPrefs.setAccent(PlavioAccent.byName(it))
                    }
                    if (tv.has("autoplayBestStream")) {
                        uiPrefs.setAutoplayBestStream(tv.optBoolean("autoplayBestStream"))
                    }
                    if (tv.has("autoPlayNextEpisode")) {
                        uiPrefs.setAutoPlayNextEpisode(tv.optBoolean("autoPlayNextEpisode"))
                    }
                    subtitleStyleStore.setStyle(
                        SubtitleStyle(
                            fontSizeSp = tv.optInt("subtitleFontSizeSp", 24),
                            textColorRgb = tv.optInt("subtitleTextColorRgb", 0xFFFFFF),
                            opacityPercent = tv.optInt("subtitleOpacityPercent", 100),
                            bold = tv.optBoolean("subtitleBold", false),
                            outlineEnabled = tv.optBoolean("subtitleOutlineEnabled", true),
                            outlineColorRgb = tv.optInt("subtitleOutlineColorRgb", 0x000000),
                            bottomOffset = tv.optInt("subtitleBottomOffset", 20),
                        ),
                    )
                }
                Unit
            }

        /**
         * Addons-only import (v0.3.14): parses a backup payload and
         * MERGES just its addon list into the store (see
         * [AddonStore.mergeAddons]) — playback, settings and every
         * other section are left untouched. Returns how many addons
         * were newly added (0 when the payload has no addons array).
         */
        suspend fun importAddonsOnly(json: String): Result<Int> =
            runCatching {
                require(json.toByteArray(Charsets.UTF_8).size <= 10 * 1024 * 1024) {
                    "Backup exceeds the 10 MiB safety limit."
                }
                val root = JSONObject(json)
                require(root.optString("format") == "plavio-backup") { "Not a Plavio backup file." }
                if (!root.has("addons")) {
                    0
                } else {
                    addonStore.mergeAddons(parseAddons(root))
                }
            }

        /** The shared `addons` array parser (phone field format). */
        private fun parseAddons(root: JSONObject): List<InstalledAddon> {
            val arr = root.optJSONArray("addons") ?: return emptyList()
            val imported = mutableListOf<InstalledAddon>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val baseUrl = o.optString("baseUrl").takeIf { it.isNotBlank() } ?: continue
                val id = o.optString("id").takeIf { it.isNotBlank() } ?: continue
                imported +=
                    InstalledAddon(
                        baseUrl = baseUrl,
                        manifest =
                            AddonManifest(
                                id = id,
                                name = o.optString("name").ifBlank { id },
                                version = o.optString("version"),
                                description = o.optString("description"),
                                types = splitCsv(o.optString("types")),
                                catalogs = emptyList(),
                                resources =
                                    splitCsv(o.optString("resources"))
                                        .ifEmpty { listOf("catalog", "meta", "stream") },
                                configurable = o.optBoolean("configurable", false),
                                logo = o.optString("logoUrl").takeIf { it.isNotBlank() },
                            ),
                        enabled = o.optBoolean("enabled", true),
                        preinstalled = o.optBoolean("preinstalled", false),
                    )
            }
            return imported
        }

        private fun splitCsv(value: String): List<String> =
            value.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        /**
         * The last imported backup's phone-owned sections (watchlist,
         * favorites, plavioStatuses, customLists, customListItems,
         * api_keys) as parsed JSON — the Library reads its Plavio /
         * Trakt / Simkl data from here (v0.3.21). Null when no backup
         * has ever been imported on this TV.
         */
        suspend fun passthroughSnapshot(): JSONObject? = readPassthrough()

        private suspend fun readPassthrough(): JSONObject? {
            val raw = passthroughStore.data.first()[KEY_PASSTHROUGH] ?: return null
            return runCatching { JSONObject(raw) }.getOrNull()
        }

        private suspend fun writePassthrough(root: JSONObject) {
            val kept = JSONObject()
            for (key in listOf("settings", "watchlist", "favorites", "plavioStatuses", "customLists", "customListItems", "api_keys", "profilePhoto")) {
                if (root.has(key)) kept.put(key, root.get(key))
            }
            passthroughStore.edit { it[KEY_PASSTHROUGH] = kept.toString() }
        }

        private companion object {
            val KEY_PASSTHROUGH = stringPreferencesKey("last_imported_passthrough")
        }
    }
