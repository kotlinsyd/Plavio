// This file was inspired by related Button source files from
// https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-main/tv/tv-material/src/main/java/androidx/tv/material3

package com.github.damontecres.wholphin.ui.components


import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.NonRestartableComposable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceBorder
import androidx.tv.material3.ClickableSurfaceColors
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ClickableSurfaceGlow
import androidx.tv.material3.ClickableSurfaceScale
import androidx.tv.material3.ClickableSurfaceShape
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.ProvideTextStyle
import androidx.tv.material3.Surface
import androidx.tv.material3.Text

/**
 * This is a re-implementation of [androidx.tv.material3.Button] with altered sizing, padding, colors, etc
 *
 * This allows for creating smaller and fully circular Buttons.
 */
val MinButtonSize = 40.dp

@Composable
fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    // Plavio TV v0.3.13: no focus growth. The tv-material default
    // focusedScale is 1.1f (bytecode-verified in 1.1.0-alpha01) —
    // full-width buttons inside clipped panels lost glyphs off both
    // edges when focused. Focus is the Weave-pink ring below, only.
    scale: ClickableSurfaceScale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
    glow: ClickableSurfaceGlow = ClickableSurfaceDefaults.glow(),
    shape: ClickableSurfaceShape =
        ClickableSurfaceDefaults.shape(
            shape = CircleShape,
        ),
    colors: ClickableSurfaceColors =
        ClickableSurfaceDefaults.colors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
            contentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
            // v0.3.13: focus never recolours the button (owner's one
            // focus language: the pink ring in the border below).
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
            focusedContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
            pressedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
            pressedContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
        ),
    tonalElevation: Dp = 0.dp,
    border: ClickableSurfaceBorder =
        ClickableSurfaceDefaults.border(
            border = Border.None,
            // Plavio TV: one focus ring on every pill button — 2.5dp
            // in the user's accent (the tv scheme primary; v0.3.12
            // introduced the ring, v0.3.14 routed its colour to the
            // accent pick).
            focusedBorder =
                Border(
                    border =
                        BorderStroke(
                            width = 2.5.dp,
                            color = MaterialTheme.colorScheme.primary,
                        ),
                    shape = CircleShape,
                ),
            pressedBorder =
                Border(
                    border =
                        BorderStroke(
                            width = 2.5.dp,
                            color = MaterialTheme.colorScheme.primary,
                        ),
                    shape = CircleShape,
                ),
            disabledBorder = Border.None,
            focusedDisabledBorder =
                Border(
                    border =
                        BorderStroke(
                            width = 1.5.dp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f),
                        ),
                    shape = CircleShape,
                ),
        ),
    contentPadding: PaddingValues = DefaultButtonPadding,
    contentHeight: Dp = MinButtonSize,
    interactionSource: MutableInteractionSource? = null,
    content: @Composable RowScope.() -> Unit,
) {
    Surface(
        modifier = modifier.semantics { role = Role.Button },
        onClick = onClick,
        onLongClick = onLongClick,
        enabled = enabled,
        scale = scale,
        glow = glow,
        shape = shape,
        colors = colors,
        tonalElevation = tonalElevation,
        border = border,
        interactionSource = interactionSource,
    ) {
        ProvideTextStyle(value = MaterialTheme.typography.labelLarge) {
            Row(
                modifier =
                    Modifier
                        .padding(contentPadding)
                        .height(contentHeight),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                content = content,
            )
        }
    }
}

@Composable
@NonRestartableComposable
fun TextButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    contentPadding: PaddingValues =
        PaddingValues(
            start = 8.dp,
            top = 4.dp,
            end = 8.dp,
            bottom = 4.dp,
        ),
    contentHeight: Dp = 32.dp,
    interactionSource: MutableInteractionSource? = null,
    content: @Composable RowScope.() -> Unit,
) = Button(
    onClick = onClick,
    modifier = modifier,
    onLongClick = onLongClick,
    enabled = enabled,
    contentPadding = contentPadding,
    contentHeight = contentHeight,
    interactionSource = interactionSource,
    content = content,
)

@Composable
fun TextButton(
    @StringRes stringRes: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    contentPadding: PaddingValues =
        PaddingValues(
            start = 8.dp,
            top = 4.dp,
            end = 8.dp,
            bottom = 4.dp,
        ),
    contentHeight: Dp = 32.dp,
    interactionSource: MutableInteractionSource? = null,
) = Button(
    onClick = onClick,
    modifier = modifier,
    onLongClick = onLongClick,
    enabled = enabled,
    contentPadding = contentPadding,
    contentHeight = contentHeight,
    interactionSource = interactionSource,
    content = {
        Text(text = stringResource(stringRes))
    },
)

val DefaultButtonPadding =
    PaddingValues(
        start = 4.dp,
        top = 4.dp,
        end = 4.dp,
        bottom = 4.dp,
    )
