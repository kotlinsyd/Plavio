package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CatalogRow
import com.github.damontecres.wholphin.plavio.ContinueWatchingEntry
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.ui.components.Button
import kotlinx.coroutines.launch
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type

/**
 * Plavio TV home: one poster row per catalog of every enabled addon, fed
 * by [AddonCatalogRepository]. The addon setup stays one click away via
 * the "Manage addons" entry in the header.
 */
@Composable
fun PlavioHomeScreen(
    onManageAddons: () -> Unit,
    onItemClick: (CatalogRow, MetaPreview) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onPlayRequest: (com.github.damontecres.wholphin.plavio.PlaybackRequest) -> Unit,
    onEpisodeAlertClick: (com.github.damontecres.wholphin.plavio.EpisodeAlert) -> Unit,
    modifier: Modifier = Modifier,
    /** v0.3.14: root-held focus memory (see PlavioFocus.kt). */
    focusMemory: HomeFocusMemory = HomeFocusMemory(),
    viewModel: PlavioHomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val episodeAlerts by viewModel.episodeAlerts.collectAsState()
    // Stable gate (v0.3.14, owner's override — he accepts the wait):
    // a Content state whose rows have not SETTLED yet renders as the
    // loading face, exactly like the reference's home. The first
    // composed frame of Home is therefore the real, final first row —
    // no provisional shelves composing under the remote and being
    // re-sorted out from under a landed focus (the v0.3.13 startup
    // flicker class, killed structurally instead of gated only at
    // the focus claim). A 5s safety timeout releases the gate with
    // whatever has arrived, so a hung addon can never hold Home
    // hostage. Once released for a given visit the rows only ever
    // refresh in place (identity keys — see CatalogRows).
    var gateTimedOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(5_000)
        gateTimedOut = true
    }
    val contentUnsettled = (state as? PlavioHomeUiState.Content)?.settled == false
    val effectiveState =
        if (contentUnsettled && !gateTimedOut) {
            PlavioHomeUiState.Loading
        } else {
            state
        }

    Column(
        modifier =
            modifier
                .background(MaterialTheme.colorScheme.background)
                // v0.3.12: the brand lockup floats now and reserves
                // nothing, so the old 60dp brand-clearance top pad
                // is gone — only a small breathing margin remains
                // and the hero uses the full height of the screen.
                .padding(top = 8.dp),
    ) {
        // v0.3.16 (owner order): the top-centre search capsule is
        // GONE — Search is a side-tray destination now, directly
        // under Home. Every button lives in the tray.
        when (val st = effectiveState) {
            PlavioHomeUiState.Loading -> {
                // v0.3.16 (note 8, owner's explicit order): a
                // SKELETON, not a spinner. This branch renders while
                // the first load is unsettled (the settle gate
                // above) — the page's shape (hero block, then row
                // title bars with poster blocks) stands in place,
                // and the COMPLETE page replaces it at once when
                // the load settles. Nothing here is focusable; the
                // entry landing already waits for the settled rows.
                HomeSkeleton()
            }

            is PlavioHomeUiState.Content -> {
                var heroFocus by remember {
                    mutableStateOf<Pair<CatalogRow, MetaPreview>?>(null)
                }
                // v0.3.12 perf (owner: "buttery movements, scroll"):
                // the hero follows SETTLED focus only. Round 1 swapped
                // the full-screen backdrop + logo on every single
                // D-pad step, so holding Right across a row decoded a
                // new backdrop per card and stuttered the scroll. The
                // hero now updates ~350ms after focus comes to rest —
                // the Nuvio-Modern behaviour.
                var settledHeroFocus by remember {
                    mutableStateOf<Pair<CatalogRow, MetaPreview>?>(null)
                }
                LaunchedEffect(heroFocus) {
                    val target = heroFocus
                    if (target != null) {
                        kotlinx.coroutines.delay(350)
                        settledHeroFocus = target
                    }
                }
                val hero =
                    settledHeroFocus
                        ?: st.rows.firstOrNull()?.let { row ->
                            row.items.firstOrNull()?.let { row to it }
                        }
                // Hero (v0.3.14, owner's order — the reference
                // behaviour): the hero is FIXED. It no longer
                // collapses or scrolls away (the v0.3.11–0.3.13
                // shrink-to-zero: "scrolling down it move up, and
                // only first cards show at hero" — owner verdict).
                // It sits at its resting height — 45% of the
                // available viewport (v0.3.1 proportional rule) —
                // for the whole visit, the rows scroll beneath it in
                // their sheet, and it FOLLOWS the focused card on
                // any catalog row (the settled-focus feed below), so
                // whichever title the remote rests on is the title
                // the hero shows. Its buttons are ordinary focus
                // stops the whole time: Up from the first row lands
                // on them, visibly, because the hero is always fully
                // on screen — the old focus gate for the collapsing
                // sliver is gone with the collapse itself.
                // The list state lives in the root-held focus memory
                // so a return to Home restores the scroll too.
                val listState = focusMemory.listState
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val heroHeight = if (hero != null) maxHeight * 0.45f else 0.dp
                    if (hero != null) {
                        val myListKeys by viewModel.myListKeys.collectAsState()
                        HomeHero(
                            row = hero.first,
                            item = hero.second,
                            inMyList = "${hero.second.type}|${hero.second.id}" in myListKeys,
                            onWatchNow = {
                                viewModel.watchNow(hero.first, hero.second) { request ->
                                    if (request != null) onPlayRequest(request)
                                }
                            },
                            onToggleMyList = { viewModel.toggleMyList(hero.second) },
                            height = heroHeight,
                        )
                    }
                    // Rows slide up over the hero's bottom edge: the sheet
                    // starts 20.dp above the hero's bottom (overlap) and
                    // follows the animated hero height as it shrinks.
                    Box(
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .padding(
                                    top =
                                        if (hero != null) {
                                            (heroHeight - 20.dp).coerceAtLeast(0.dp)
                                        } else {
                                            0.dp
                                        },
                                )
                                .clip(
                                    RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                                )
                                .background(MaterialTheme.colorScheme.background),
                    ) {
                        CatalogRows(
                            rows = st.rows,
                            continueWatching = st.continueWatching,
                            rowsSettled = st.settled,
                            episodeAlerts = episodeAlerts,
                            onItemClick = onItemClick,
                            onItemFocus = { row, item -> heroFocus = row to item },
                            onContinueWatchingClick = onContinueWatchingClick,
                            onEpisodeAlertClick = { alert ->
                                viewModel.clearEpisodeAlert(alert.metaId)
                                onEpisodeAlertClick(alert)
                            },
                            listState = listState,
                            focusMemory = focusMemory,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }

            PlavioHomeUiState.NoAddons -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_no_addons_text),
                    actionLabel = stringResource(R.string.plavio_home_add_addon),
                    onAction = onManageAddons,
                )
            }

            PlavioHomeUiState.NoCatalogs -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_no_catalogs),
                    actionLabel = stringResource(R.string.plavio_home_manage_addons),
                    onAction = onManageAddons,
                )
            }

            PlavioHomeUiState.LoadFailed -> {
                EmptyState(
                    title = stringResource(R.string.plavio_home_no_addons_title),
                    text = stringResource(R.string.plavio_home_load_failed),
                    actionLabel = stringResource(R.string.plavio_home_retry),
                    onAction = { viewModel.refresh() },
                )
            }
        }
    }
}

@Composable
private fun CatalogRows(
    rows: List<CatalogRow>,
    continueWatching: List<ContinueWatchingEntry>,
    rowsSettled: Boolean,
    episodeAlerts: List<com.github.damontecres.wholphin.plavio.EpisodeAlert>,
    onItemClick: (CatalogRow, MetaPreview) -> Unit,
    onItemFocus: (CatalogRow, MetaPreview) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onEpisodeAlertClick: (com.github.damontecres.wholphin.plavio.EpisodeAlert) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
    focusMemory: HomeFocusMemory = HomeFocusMemory(),
) {
    val firstCardFocus = remember { FocusRequester() }
    // Identity-keyed requesters (v0.3.14): one per card the user can
    // have focused — Continue Watching by entry key, catalog cards
    // by row key + item identity — so a return can land on the EXACT
    // card again instead of always the first card. Pruned implicitly:
    // the map lives and dies with this composition, and a requester
    // whose card left the data simply never gets attached again.
    val itemRequesters = remember { mutableMapOf<String, FocusRequester>() }
    fun requesterFor(key: String): FocusRequester = itemRequesters.getOrPut(key) { FocusRequester() }
    fun rowKeyOf(row: CatalogRow): String = "${row.addonId}/${row.type}/${row.catalogId}"
    fun itemKeyOf(item: MetaPreview): String = "${item.type}|${item.id}"
    // The claim: focus verifiably inside the list (the column's
    // onFocusChanged) OR the viewer pressing a navigation key (the
    // column's preview stamp). Every landing below goes through the
    // shared landFocus primitive against this claim — it can never
    // fight the user, and a landing is one-shot by construction.
    var listFocusEntered by remember { mutableStateOf(false) }
    var lastKeyMs by remember { mutableStateOf(0L) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    // The one landing for this screen (v0.3.14): the remembered card
    // when it still exists (scroll its row into the window first —
    // the row states ride in the focus memory, so the card is back
    // inside its row's window too), else the first card. Used by the
    // entry effect, the player-return flip and the capsule's return
    // transfer alike — one mechanism, three sanctioned moments.
    suspend fun landHome() {
        val stampAtStart = lastKeyMs
        // v0.3.15 (the capsule trap, root-caused): the claim must be
        // RELATIVE to this landing's start, like every other screen's
        // (they reset their flag; Detail releases its claim). The
        // v0.3.14 form read listFocusEntered RAW — a one-way latch
        // set at first entry and never cleared when focus leaves for
        // the capsule — so a capsule-return landing polled the claim,
        // saw the STALE "entered" from the original entry landing,
        // and landFocus stood down before issuing a single
        // requestFocus. The transfer reported success, the Right key
        // was consumed, and focus was welded into the capsule. The
        // latch half now counts only a RE-ENTRY after this landing
        // began; the key-stamp half was already relative.
        val enteredAtStart = listFocusEntered
        val claimed = { (listFocusEntered && !enteredAtStart) || lastKeyMs != stampAtStart }
        val memoryRowKey = focusMemory.rowKey
        val memoryItemKey = focusMemory.itemKey
        val memoryCwKey = focusMemory.continueWatchingKey
        val target: FocusRequester? =
            when {
                memoryCwKey != null &&
                    continueWatching.any { it.key == memoryCwKey } ->
                    requesterFor("cw|$memoryCwKey")
                memoryRowKey != null && memoryItemKey != null -> {
                    val rowIndex = rows.indexOfFirst { rowKeyOf(it) == memoryRowKey }
                    val row = rows.getOrNull(rowIndex)
                    if (row != null && row.items.any { itemKeyOf(it) == memoryItemKey }) {
                        val columnIndex =
                            (if (episodeAlerts.isNotEmpty()) 1 else 0) +
                                (if (continueWatching.isNotEmpty()) 1 else 0) + rowIndex
                        runCatching { listState.scrollToItem(columnIndex) }
                        requesterFor("$memoryRowKey|$memoryItemKey")
                    } else {
                        null
                    }
                }
                else -> null
            }
        if (target != null) {
            landFocus(target, isClaimed = claimed)
        }
        if (!claimed()) {
            landFocus(firstCardFocus, isClaimed = claimed)
        }
    }
    // Settle fallback (v0.3.13, kept): the entry landing waits for
    // the rows to settle, but a refresh whose final emission somehow
    // never lands must not leave the remote dead — after 4s the
    // landing proceeds against whatever first card exists by then.
    // (The screen-level stable gate in PlavioHomeScreen now covers
    // the display side; this remains the focus-side belt.)
    var settleTimedOut by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(4000)
        settleTimedOut = true
    }
    LaunchedEffect(rowsSettled, settleTimedOut) {
        if (!rowsSettled && !settleTimedOut) return@LaunchedEffect
        landHome()
    }
    // Focus hand-back on the playing→stopped flip (v0.3.10 pattern,
    // v0.3.14 mechanism): Home stays composed under the player, but
    // focus lives in the player tree and leaves with it — on the
    // flip, land deliberately once more, on the remembered card (a
    // Continue Watching play returns to the very entry played).
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            listFocusEntered = false
            landHome()
        }
    }
    // The capsule's return transfer lands here too (v0.3.14):
    // registered while this content is composed, removed on dispose
    // (the root's holder then reports no handler and geometry rules).
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = { scope.launch { landHome() } }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    LazyColumn(
        modifier =
            modifier
                // v0.3.15: a LIVE mirror (focus is inside the list
                // RIGHT NOW), not the v0.3.14 one-way latch — the
                // latch never cleared when focus left for the
                // capsule, which is what welded focus in there.
                .onFocusChanged { listFocusEntered = it.hasFocus }
                .onPreviewKeyEvent { event ->
                    if (event.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                        (
                            event.key == androidx.compose.ui.input.key.Key.DirectionUp ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionDown ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionLeft ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionRight ||
                                event.key == androidx.compose.ui.input.key.Key.DirectionCenter ||
                                event.key == androidx.compose.ui.input.key.Key.Enter ||
                                event.key == androidx.compose.ui.input.key.Key.NumPadEnter
                        )
                    ) {
                        lastKeyMs = android.os.SystemClock.uptimeMillis()
                    }
                    false
                },
        state = listState,
        // Extra bottom room so the last row can scroll fully into
        // view, clear of the TV's overscan crop zone.
        contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        if (episodeAlerts.isNotEmpty()) {
            item(key = "episode-alerts") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_home_new_episodes),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(end = 40.dp),
                    )
                    LazyRow(
                        contentPadding = PaddingValues(end = 40.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(episodeAlerts, key = { _, alert -> alert.metaId }) { _, alert ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                SharedPosterCard(
                                    item =
                                        MetaPreview(
                                            id = alert.metaId,
                                            type = "series",
                                            name = alert.showName,
                                            poster = alert.poster,
                                        ),
                                    onClick = { onEpisodeAlertClick(alert) },
                                )
                                Text(
                                    text =
                                        stringResource(
                                            R.string.plavio_home_new_episode_label,
                                            alert.season,
                                            alert.episode,
                                        ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = LocalPlavioAccent.current.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        if (continueWatching.isNotEmpty()) {
            item(key = "continue-watching") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_home_continue_watching),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(end = 40.dp),
                    )
                    LazyRow(
                        state = focusMemory.rowState("continue-watching"),
                        contentPadding = PaddingValues(end = 40.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(continueWatching, key = { _, entry -> entry.key }) { index, entry ->
                            ContinueWatchingCard(
                                entry = entry,
                                onClick = { onContinueWatchingClick(entry) },
                                modifier =
                                    Modifier
                                        .focusRequester(requesterFor("cw|${entry.key}"))
                                        .onFocusChanged { state ->
                                            if (state.isFocused) {
                                                focusMemory.continueWatchingKey = entry.key
                                                focusMemory.rowKey = null
                                                focusMemory.itemKey = null
                                            }
                                        }
                                        .then(
                                            if (index == 0) {
                                                Modifier.focusRequester(firstCardFocus)
                                            } else {
                                                Modifier
                                            },
                                        ),
                            )
                        }
                    }
                }
            }
        }
        itemsIndexed(rows, key = { rowIndex, row -> "${row.addonId}/${row.type}/${row.catalogId}|$rowIndex" }) { rowIndex, row ->
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.padding(end = 40.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = row.catalogName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    // v0.3.16 (note 5): the addon-name label that
                    // used to sit beside the catalog name is GONE —
                    // rows carry the catalog's own name only, clean
                    // like the mobile app (no "PMeta" branding on
                    // rows). Display layer only: the row's addon
                    // identity (addonId/baseUrl on the row model)
                    // still drives fetching, ordering and hiding
                    // exactly as before.
                }
                LazyRow(
                    state = focusMemory.rowState(rowKeyOf(row)),
                    contentPadding = PaddingValues(end = 40.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    // Identity keys with an OCCURRENCE suffix
                    // (v0.3.14): the suffix counts prior occurrences
                    // of the same title in this row (PLAVIO-8/5: the
                    // same title can legitimately appear twice in
                    // one rail; type|id alone crashed on it) — NOT
                    // the item's list position. An item inserted or
                    // removed elsewhere in the row therefore keeps
                    // every other card's key (and its focus node)
                    // stable across a refresh, where the old
                    // position suffix re-keyed every card after the
                    // change and could tear down the focused node
                    // mid-browse — the reference's identity-
                    // relocation rule, applied to our keys.
                    val occurrenceKeys =
                        run {
                            val seen = mutableMapOf<String, Int>()
                            row.items.map { item ->
                                val base = itemKeyOf(item)
                                val occurrence = seen.getOrDefault(base, 0)
                                seen[base] = occurrence + 1
                                "$base|$occurrence"
                            }
                        }
                    itemsIndexed(
                        row.items,
                        key = { index, _ -> occurrenceKeys[index] },
                    ) { itemIndex, item ->
                        SharedPosterCard(
                            item = item,
                            onClick = { onItemClick(row, item) },
                            onFocus = {
                                onItemFocus(row, item)
                                focusMemory.rowKey = rowKeyOf(row)
                                focusMemory.itemKey = itemKeyOf(item)
                                focusMemory.continueWatchingKey = null
                            },
                            focusRequester = requesterFor("${rowKeyOf(row)}|${itemKeyOf(item)}"),
                            modifier =
                                if (continueWatching.isEmpty() && rowIndex == 0 && itemIndex == 0) {
                                    Modifier.focusRequester(firstCardFocus)
                                } else {
                                    Modifier
                                },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    entry: ContinueWatchingEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.width(216.dp),
        shape = plavioCardShape(),
        colors = plavioCardColors(),
        border = plavioCardBorder(),
        scale = plavioCardScale(),
    ) {
        Column {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (entry.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(entry.poster)
                                .size(432, 243)
                                .crossfade(false)
                                .build(),
                        contentDescription = entry.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = entry.title.take(1),
                        style = MaterialTheme.typography.displaySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                // Progress bar along the bottom of the artwork: what is
                // left of the bar is how much of the title remains.
                Box(
                    modifier =
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(entry.progressFraction)
                                .height(4.dp)
                                .background(MaterialTheme.colorScheme.primary),
                    )
                }
            }
            Column(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = entry.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = stringResource(R.string.plavio_home_time_left, formatTimeLeft(entry)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

/** "1h 5m" / "5m" / "<1m" for the time remaining on a continue-watching entry. */
private fun formatTimeLeft(entry: ContinueWatchingEntry): String {
    val remainingMs = (entry.durationMs - entry.positionMs).coerceAtLeast(0)
    val totalMinutes = (remainingMs / 60_000).toInt()
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return when {
        hours > 0 -> "${hours}h ${minutes}m"
        minutes > 0 -> "${minutes}m"
        else -> "<1m"
    }
}

@Composable
private fun EmptyState(
    title: String,
    text: String,
    actionLabel: String,
    onAction: () -> Unit,
) {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(8.dp))
            PlavioPrimaryButton(onClick = onAction) {
                Text(text = actionLabel)
            }
        }
    }
}


/**
 * Home hero (mobile parity, TV pattern): a full-bleed backdrop for the
 * currently FOCUSED title — logo art when the metadata provides it,
 * else the title text — a facts line (year • ★ rating • genre) and the
 * detail page's Watch Now capsule. Before anything is focused it
 * shows the first title of the first rail. Down from the capsule
 * enters the rails; the capsule never traps focus.
 */
@Composable
private fun HomeHero(
    row: CatalogRow,
    item: MetaPreview,
    inMyList: Boolean,
    onWatchNow: () -> Unit,
    onToggleMyList: () -> Unit,
    height: Dp = 300.dp,
) {
    val context = LocalContext.current
    // v0.3.21 (the approved home sample): the hero is an INSET
    // rounded card, not a full-bleed backdrop — 20dp corners,
    // hairline border. Its left edge is the shared content margin
    // (v0.3.12: the root pad already places it exactly beside the
    // capsule, so the hero no longer adds a start inset of its
    // own; the 40dp end inset stays).
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(end = 40.dp)
                .height(height)
                .clip(RoundedCornerShape(20.dp))
                .border(
                    1.dp,
                    PlavioOnyx.PanelBorder,
                    RoundedCornerShape(20.dp),
                ),
    ) {
        // Static backdrop (v0.3.2 smoothness): the old parallax
        // translation + alpha fade repainted this full-screen image on
        // every scroll frame. The sheet sliding over it carries the
        // motion now; the backdrop itself never moves.
        // v0.3.20 ROOT-CAUSE FIX (owner: "posters in hero section are
        // missing, showing details but missing posters"): the image
        // was gated behind the LIGHT-LOOK preference —
        // `if (!LocalPlavioLightLook.current)` — a Settings-only
        // cheap-drawing mode for low-end TVs (owner design
        // 2026-11-04) whose whole contract is "the same look drawn
        // cheap". Under it the hero skipped its ONLY image entirely
        // while the title, facts and buttons (plain text/draw calls)
        // still rendered — exactly the owner's photo: details
        // showing, picture area blank. A performance preference
        // must never remove CONTENT: the backdrop is the hero's
        // picture, not an effect. The gate is gone; the image now
        // loads in both looks. What light look legitimately cheapens
        // (shadows, glass translucency, scrims elsewhere) is
        // untouched.
        AsyncImage(
            model =
                ImageRequest
                    .Builder(context)
                    .data(item.background ?: item.poster)
                    // v0.3.12 perf: cap the hero decode —
                    // backdrops arrive at original size (often
                    // 2000px+). v0.3.15: 960×540, down from
                    // 1280×720 — the hero sits under two scrims
                    // and the rows sheet, and on the owner's TV
                    // the settled-hero backdrop swap lands while
                    // he is still scrolling: ~44% fewer decode
                    // pixels is ~44% less of that mid-scroll hit.
                    .size(960, 540)
                    .crossfade(false)
                    .build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        // Legibility scrims: bottom fade into the app background + a
        // soft start-side shade behind the text block.
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors =
                                listOf(
                                    androidx.compose.ui.graphics.Color.Transparent,
                                    MaterialTheme.colorScheme.background,
                                ),
                            startY = 120f,
                        ),
                    ),
        )
        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors =
                                listOf(
                                    androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f),
                                    androidx.compose.ui.graphics.Color.Transparent,
                                ),
                        ),
                    ),
        )
        Column(
            modifier =
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 24.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // The sample's kicker: FEATURED first, then the content
            // type + first genre, letterspaced, in the accent.
            val kicker =
                listOfNotNull(
                    "FEATURED",
                    item.type.takeIf { it.isNotBlank() }?.uppercase(),
                    item.genres.firstOrNull()?.uppercase(),
                ).joinToString("  ·  ")
            if (kicker.isNotBlank()) {
                Text(
                    text = kicker,
                    style = MaterialTheme.typography.labelLarge,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold,
                    color = LocalPlavioAccent.current.primary,
                )
            }
            // Title logo art, progressive (v0.3.17): the TEXT title
            // renders first and the logo replaces it only once it has
            // actually loaded — a slow or dead logo URL never leaves
            // the hero title blank, and the hero never waits on it.
            // Adaptive logo size (owner order, v0.3.4) is preserved:
            // title logos arrive in wildly different shapes, so the
            // box follows the loaded image's own aspect (ContentScale
            // .Fit inside, never Crop).
            val heroLogoPainter =
                coil3.compose.rememberAsyncImagePainter(
                    model =
                        ImageRequest
                            .Builder(context)
                            .data(item.logo)
                            .size(680, 240)
                            .crossfade(false)
                            .build(),
                )
            val heroLogoState by heroLogoPainter.state.collectAsState()
            val heroLogoSuccess =
                heroLogoState as? coil3.compose.AsyncImagePainter.State.Success
            if (item.logo != null && heroLogoSuccess != null) {
                val loadedSize = heroLogoSuccess.painter.intrinsicSize
                val logoAspect =
                    if (loadedSize != androidx.compose.ui.geometry.Size.Unspecified &&
                        loadedSize.height > 0f
                    ) {
                        loadedSize.width / loadedSize.height
                    } else {
                        null
                    }
                val logoSize =
                    when (val aspect = logoAspect) {
                        null -> androidx.compose.ui.unit.DpSize(300.dp, 84.dp)
                        else ->
                            when {
                                aspect >= 2.6f -> androidx.compose.ui.unit.DpSize(340.dp, 92.dp)
                                aspect >= 1.8f -> androidx.compose.ui.unit.DpSize(300.dp, 96.dp)
                                aspect >= 1.2f -> androidx.compose.ui.unit.DpSize(220.dp, 110.dp)
                                else -> androidx.compose.ui.unit.DpSize(160.dp, 120.dp)
                            }
                    }
                androidx.compose.foundation.Image(
                    painter = heroLogoPainter,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart,
                    modifier = Modifier.size(logoSize),
                )
            } else {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            val facts =
                listOfNotNull(
                    item.releaseInfo?.take(4)?.takeIf { it.isNotBlank() },
                    item.imdbRating?.takeIf { it.isNotBlank() }?.let { "★ $it" },
                    item.genres.firstOrNull(),
                ).joinToString(" • ")
            if (facts.isNotBlank()) {
                Text(
                    text = facts,
                    style = MaterialTheme.typography.bodyLarge,
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f),
                )
            }
            // The sample's 2-line overview under the facts.
            item.description?.takeIf { it.isNotBlank() }?.let { overview ->
                Text(
                    text = overview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.75f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth(0.55f),
                )
            }
            // The sample's two fixed capsules: Play + My List (the
            // TV has a real My List store since v0.3.21 — the button
            // toggles this title in it, and says so).
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                PlavioFixedButton(
                    text = stringResource(R.string.plavio_detail_watch),
                    onClick = onWatchNow,
                    kind = PlavioButtonKind.Primary,
                    whiteFocus = true,
                    leadingIcon = androidx.compose.material.icons.Icons.Filled.PlayArrow,
                    modifier = Modifier.width(150.dp),
                )
                PlavioFixedButton(
                    text =
                        stringResource(
                            if (inMyList) {
                                R.string.plavio_in_my_list
                            } else {
                                R.string.plavio_add_my_list
                            },
                        ),
                    onClick = onToggleMyList,
                    whiteFocus = true,
                    modifier = Modifier.width(150.dp),
                )
            }
        }
    }
}

/**
 * The Home first-load skeleton (v0.3.16, note 8): the page's own
 * shape in quiet glass blocks — the hero block at its real 45%
 * resting height with title/action shapes inside, then two catalog
 * rows (title bar + poster blocks). Pure decoration: nothing
 * focusable, no text. It stands only while the first load is
 * unsettled; the complete page replaces it at once.
 */
@Composable
private fun HomeSkeleton() {
    val block = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.06f)
    val line = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.10f)
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(end = 40.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.45f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(block),
        ) {
            Column(
                modifier =
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier =
                        Modifier
                            .width(340.dp)
                            .height(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(line),
                )
                Box(
                    modifier =
                        Modifier
                            .width(220.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(block),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier =
                            Modifier
                                .width(150.dp)
                                .height(40.dp)
                                .clip(PlavioCapsuleShape)
                                .background(line),
                    )
                    Box(
                        modifier =
                            Modifier
                                .width(150.dp)
                                .height(40.dp)
                                .clip(PlavioCapsuleShape)
                                .background(block),
                    )
                }
            }
        }
        repeat(2) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier =
                        Modifier
                            .width(180.dp)
                            .height(22.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(line),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    repeat(6) {
                        Box(
                            modifier =
                                Modifier
                                    .width(124.dp)
                                    .height(186.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(block),
                        )
                    }
                }
            }
        }
    }
}
