package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import kotlin.math.cos
import kotlin.math.sin

/**
 * The signature orbit loader, ported from the phone app: a head dot with
 * a shrinking, fading tail circling a faint dotted ring. In Onyx it is
 * drawn in the single active accent colour.
 *
 * [alwaysAnimate] (v0.3.14, the player's loading layers): the orbit
 * then ignores the reduced-motion gate. That gate — the in-app
 * reduced-motion choice OR `ValueAnimator.areAnimatorsEnabled()`
 * being false (animator scale 0, common on budget TVs) — froze the
 * player's loading circle SOLID on the owner's TV: a still spinner
 * during playback preparation is indistinguishable from a hang, so
 * the loading indicator always spins. The transition is clock-driven,
 * so after any brief main-thread stall it resumes at the correct
 * angle rather than restarting; playback preparation itself runs on
 * ExoPlayer's threads / IO, so frames keep flowing.
 */
@Composable
fun OrbitLoader(
    modifier: Modifier = Modifier,
    alwaysAnimate: Boolean = false,
) {
    val accent = LocalPlavioAccent.current.primary
    // Reduced motion (phone parity): the orbit sits still — unless
    // this instance is a loading indicator that must always spin.
    val gate = com.github.damontecres.wholphin.plavio.rememberReducedMotion()
    val reduced = gate && !alwaysAnimate
    val transition = rememberInfiniteTransition(label = "orbit")
    val animatedRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec =
            infiniteRepeatable(
                animation = tween(1350, easing = LinearEasing),
                repeatMode = RepeatMode.Restart,
            ),
        label = "orbitRotation",
    )
    val rotation = if (reduced) 0f else animatedRotation
    Canvas(modifier) {
        val unit = size.minDimension / 40f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val ringR = 13.5f * unit

        fun pos(angleDeg: Float): Offset {
            val rad = Math.toRadians(angleDeg.toDouble())
            return Offset(
                cx + ringR * cos(rad).toFloat(),
                cy + ringR * sin(rad).toFloat(),
            )
        }
        // Faint dotted ring underneath (12 dots, every 30 degrees).
        for (i in 0 until 12) {
            drawCircle(
                color = accent.copy(alpha = 0.22f),
                radius = 1.4f * unit,
                center = pos(i * 30f),
            )
        }
        // Tail behind the head: shrinking and fading.
        val tailR = listOf(2.5f, 2.05f, 1.65f, 1.3f)
        val tailA = listOf(0.75f, 0.55f, 0.38f, 0.24f)
        for (i in 4 downTo 1) {
            drawCircle(
                color = accent.copy(alpha = tailA[i - 1]),
                radius = tailR[i - 1] * unit,
                center = pos(rotation - 35f * i),
            )
        }
        // Head with its soft glow.
        val head = pos(rotation)
        drawCircle(color = accent.copy(alpha = 0.28f), radius = 6f * unit, center = head)
        drawCircle(color = accent, radius = 3.1f * unit, center = head)
    }
}
