package com.github.damontecres.wholphin

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.datastore.core.DataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewModelScope
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import com.github.damontecres.wholphin.preferences.AppPreferences
import com.github.damontecres.wholphin.services.AppUpgradeHandler
import com.github.damontecres.wholphin.services.PlaybackLifecycleObserver
import com.github.damontecres.wholphin.services.SetupDestination
import com.github.damontecres.wholphin.services.SetupNavigationManager
import com.github.damontecres.wholphin.services.UpdateChecker
import com.github.damontecres.wholphin.services.UserPreferencesService
import com.github.damontecres.wholphin.services.hilt.AuthOkHttpClient
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.ui.PlavioTvTheme
import com.github.damontecres.wholphin.ui.CoilConfig
import com.github.damontecres.wholphin.ui.components.LoadingPage
import com.github.damontecres.wholphin.ui.launchDefault
import com.github.damontecres.wholphin.ui.util.ProvideLocalClock
import com.github.damontecres.wholphin.util.DebugLogTree
import com.github.damontecres.wholphin.util.ExceptionHandler
import com.github.damontecres.wholphin.util.WholphinDispatchers
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import timber.log.Timber
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private val viewModel: MainActivityViewModel by viewModels()

    @Inject
    lateinit var userPreferencesDataStore: DataStore<AppPreferences>

    @Inject
    lateinit var userPreferencesService: UserPreferencesService

    @AuthOkHttpClient
    @Inject
    lateinit var okHttpClient: OkHttpClient

    @Inject
    lateinit var setupNavigationManager: SetupNavigationManager

    @Inject
    lateinit var updateChecker: UpdateChecker

    @Inject
    lateinit var playbackLifecycleObserver: PlaybackLifecycleObserver

    @Inject
    lateinit var plavioUiPrefs: PlavioUiPrefs

    @OptIn(ExperimentalTvMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        Timber.i("MainActivity.onCreate: savedInstanceState is null=${savedInstanceState == null}")
        lifecycle.addObserver(playbackLifecycleObserver)

        viewModel.appStart()
        // Anonymous usage counting (the owner's own stats server,
        // same as the phone app): install + session ping on launch,
        // then a heartbeat every 5 minutes while RESUMED so "online
        // now" stays true. Opt-out lives in Settings.
        lifecycleScope.launch {
            com.github.damontecres.wholphin.plavio.AppStats
                .trackLaunch(this@MainActivity)
        }
        lifecycleScope.launch {
            repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.RESUMED) {
                while (true) {
                    delay(5 * 60 * 1000L)
                    com.github.damontecres.wholphin.plavio.AppStats
                        .heartbeat(this@MainActivity)
                }
            }
        }
        setContent {
            val plavioAccent by plavioUiPrefs.accent.collectAsState()
            PlavioTvTheme(accent = plavioAccent) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    shape = RectangleShape,
                    colors =
                        SurfaceDefaults.colors(
                            containerColor = MaterialTheme.colorScheme.background,
                            contentColor = MaterialTheme.colorScheme.onBackground,
                        ),
                ) {
                    val userPreferences by userPreferencesService.flow.collectAsState(null)
                    if (userPreferences == null) {
                        // Show loading page if it is taking a while to get app preferences
                        var showLoading by remember { mutableStateOf(false) }
                        LaunchedEffect(Unit) {
                            delay(500.milliseconds)
                            Timber.i("Showing loading page")
                            showLoading = true
                        }
                        if (showLoading) {
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black),
                            ) {
                                LoadingPage()
                            }
                        }
                    } else {
                        userPreferences?.let { userPreferences ->
                            val appPreferences = userPreferences.appPreferences
                            CoilConfig(
                                prefs = appPreferences,
                                okHttpClient = okHttpClient,
                                debugLogging = false,
                                enableCache = true,
                            )
                            LaunchedEffect(appPreferences.debugLogging) {
                                DebugLogTree.INSTANCE.enabled = appPreferences.debugLogging
                            }
                            ProvideLocalClock {
                                MainContent(
                                    backStack = setupNavigationManager.backStack,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Timber.d("onResume")
    }

    override fun onRestart() {
        super.onRestart()
        Timber.d("onRestart")
        viewModel.appStart()
    }

    override fun onStop() {
        super.onStop()
        Timber.d("onStop")
        // Report the foreground session's real duration to Stats.
        com.github.damontecres.wholphin.plavio.AppStats.sessionEnded(this)
    }

    override fun onPause() {
        super.onPause()
        Timber.d("onPause")
    }

    override fun onStart() {
        super.onStart()
        Timber.d("onStart")
        // Arm the Stats session clock (onStop reports the duration).
        com.github.damontecres.wholphin.plavio.AppStats.sessionStarted()

        lifecycleScope.launchDefault {
            val appPreferences = userPreferencesDataStore.data.first()
            if (UpdateChecker.ACTIVE && appPreferences.autoCheckForUpdates) {
                try {
                    updateChecker.maybeShowUpdateToast(
                        appPreferences.updateUrl,
                    )
                } catch (ex: Exception) {
                    Timber.w(
                        ex,
                        "Exception during update check",
                    )
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Timber.d("onSaveInstanceState")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Timber.d("onRestoreInstanceState")
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("onDestroy")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Timber.d("onConfigurationChanged: newConfig=%s", newConfig)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Timber.v("onNewIntent")
        setIntent(intent)
        viewModel.appStart()
    }

    companion object {
        lateinit var instance: MainActivity
            private set
    }
}

@HiltViewModel
class MainActivityViewModel
    @Inject
    constructor(
        private val setupNavigationManager: SetupNavigationManager,
        private val appUpgradeHandler: AppUpgradeHandler,
    ) : ViewModel() {
        fun appStart() {
            viewModelScope.launchDefault {
                try {
                    // The subtitle font asset is used by the ASS subtitle renderer
                    appUpgradeHandler.copySubfont(false)
                } catch (ex: Exception) {
                    Timber.e(ex, "Error during appStart")
                }
                setupNavigationManager.navigateTo(SetupDestination.Placeholder)
            }
        }
    }
