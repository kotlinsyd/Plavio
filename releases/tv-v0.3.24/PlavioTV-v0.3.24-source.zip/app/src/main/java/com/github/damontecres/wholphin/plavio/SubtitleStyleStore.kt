package com.github.damontecres.wholphin.plavio

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioSubtitleStyleDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_subtitle_style")

/**
 * The subtitle style + timing state, mirroring the phone app's model
 * (SettingsStore subtitle fields) so the two apps behave the same:
 * font size in sp (12–40), text colour + opacity, bold, outline on/off +
 * outline colour, bottom offset (0–200; the player's Position
 * stepper moves it in steps of 10 = 1% of screen height) and a per-video
 * delay map (±60s, capped at 100 titles). The player applies these live
 * to the ExoPlayer SubtitleView; the Settings screen edits the same
 * store as defaults.
 */
/** Edge treatments, mirroring media3's CaptionStyleCompat constants
 * (kept as plain ints so this store needs no media3 dependency). */
object SubtitleEdge {
    const val NONE = 0
    const val OUTLINE = 1
    const val DROP_SHADOW = 2
    const val RAISED = 3
    const val DEPRESSED = 4
    val ALL = listOf(NONE, OUTLINE, DROP_SHADOW, RAISED, DEPRESSED)
}

data class SubtitleStyle(
    val fontSizeSp: Int = 24,
    /** RGB (no alpha) of the text colour; opacity applies on top. */
    val textColorRgb: Int = 0xFFFFFF,
    val opacityPercent: Int = 100,
    val bold: Boolean = false,
    val outlineEnabled: Boolean = true,
    val outlineColorRgb: Int = 0x000000,
    val bottomOffset: Int = 20,
    /** Caption background (v0.3.22): RGB + opacity. Opacity 0 = the
     * historic look — no background box behind the text. */
    val backgroundColorRgb: Int = 0x000000,
    val backgroundOpacityPercent: Int = 0,
    /** Edge treatment (v0.3.22): one of [SubtitleEdge]. Defaults to
     * OUTLINE, the historic look; [outlineEnabled] stays as the
     * derived on/off view (edge != NONE) for older call sites. */
    val edgeType: Int = SubtitleEdge.OUTLINE,
) {
    /** Effective ARGB text colour: swatch colour at the chosen opacity. */
    val textColorArgb: Int
        get() {
            val alpha = (opacityPercent.coerceIn(0, 100) * 255 / 100) shl 24
            return alpha or (textColorRgb and 0xFFFFFF)
        }

    val outlineColorArgb: Int get() = (0xFF shl 24) or (outlineColorRgb and 0xFFFFFF)

    /** Effective ARGB caption background: swatch colour at the chosen opacity. */
    val backgroundColorArgb: Int
        get() {
            val alpha = (backgroundOpacityPercent.coerceIn(0, 100) * 255 / 100) shl 24
            return alpha or (backgroundColorRgb and 0xFFFFFF)
        }
}

@Singleton
class SubtitleStyleStore
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioSubtitleStyleDataStore
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + CrashReports.backgroundScopeHandler)

        val style: StateFlow<SubtitleStyle> =
            dataStore.data
                .map { prefs ->
                    val outlineOn = prefs[KEY_OUTLINE] ?: true
                    SubtitleStyle(
                        fontSizeSp = (prefs[KEY_FONT_SP] ?: 24).coerceIn(12, 40),
                        textColorRgb = prefs[KEY_COLOR_RGB] ?: 0xFFFFFF,
                        opacityPercent = (prefs[KEY_OPACITY] ?: 100).coerceIn(0, 100),
                        bold = prefs[KEY_BOLD] ?: false,
                        outlineEnabled = outlineOn,
                        outlineColorRgb = prefs[KEY_OUTLINE_RGB] ?: 0x000000,
                        bottomOffset = (prefs[KEY_BOTTOM] ?: 20).coerceIn(0, 200),
                        backgroundColorRgb = prefs[KEY_BG_RGB] ?: 0x000000,
                        backgroundOpacityPercent = (prefs[KEY_BG_OPACITY] ?: 0).coerceIn(0, 100),
                        // Migration: before v0.3.22 only the outline
                        // on/off existed — it maps to OUTLINE / NONE.
                        edgeType =
                            (prefs[KEY_EDGE_TYPE]
                                ?: if (outlineOn) SubtitleEdge.OUTLINE else SubtitleEdge.NONE)
                                .let { if (it in SubtitleEdge.ALL) it else SubtitleEdge.OUTLINE },
                    )
                }.stateIn(scope, SharingStarted.Eagerly, SubtitleStyle())

        suspend fun setStyle(style: SubtitleStyle) {
            dataStore.edit { prefs ->
                prefs[KEY_FONT_SP] = style.fontSizeSp.coerceIn(12, 40)
                prefs[KEY_COLOR_RGB] = style.textColorRgb and 0xFFFFFF
                prefs[KEY_OPACITY] = style.opacityPercent.coerceIn(0, 100)
                prefs[KEY_BOLD] = style.bold
                // outlineEnabled is stored as the derived view of the
                // edge type so the two never disagree.
                prefs[KEY_OUTLINE] = style.edgeType != SubtitleEdge.NONE
                prefs[KEY_OUTLINE_RGB] = style.outlineColorRgb and 0xFFFFFF
                prefs[KEY_BOTTOM] = style.bottomOffset.coerceIn(0, 200)
                prefs[KEY_BG_RGB] = style.backgroundColorRgb and 0xFFFFFF
                prefs[KEY_BG_OPACITY] = style.backgroundOpacityPercent.coerceIn(0, 100)
                prefs[KEY_EDGE_TYPE] =
                    if (style.edgeType in SubtitleEdge.ALL) style.edgeType else SubtitleEdge.OUTLINE
            }
        }

        suspend fun update(transform: (SubtitleStyle) -> SubtitleStyle) {
            setStyle(transform(style.value))
        }

        /** Per-video subtitle delay (ms, ±60s), like the phone's map. */
        suspend fun delayMsFor(videoId: String): Long {
            val raw = dataStore.data.first()[KEY_DELAY_MAP] ?: return 0L
            val key = URLEncoder.encode(videoId, "UTF-8")
            for (entry in raw.split("\n")) {
                val eq = entry.lastIndexOf('=')
                if (eq > 0 && entry.substring(0, eq) == key) {
                    return entry.substring(eq + 1).toLongOrNull()?.coerceIn(-60_000L, 60_000L) ?: 0L
                }
            }
            return 0L
        }

        suspend fun setDelayMsFor(
            videoId: String,
            delayMs: Long,
        ) {
            val key = URLEncoder.encode(videoId, "UTF-8")
            dataStore.edit { prefs ->
                val raw = prefs[KEY_DELAY_MAP].orEmpty()
                val entries =
                    raw
                        .split("\n")
                        .filter { it.isNotBlank() && !it.startsWith("$key=") }
                        .toMutableList()
                entries.add("$key=${delayMs.coerceIn(-60_000L, 60_000L)}")
                prefs[KEY_DELAY_MAP] = entries.takeLast(100).joinToString("\n")
            }
        }

        /** Reset Defaults from the phone's Style rail. */
        suspend fun resetDefaults() {
            setStyle(SubtitleStyle())
        }

        private companion object {
            val KEY_FONT_SP = intPreferencesKey("font_size_sp")
            val KEY_COLOR_RGB = intPreferencesKey("text_color_rgb")
            val KEY_OPACITY = intPreferencesKey("opacity_percent")
            val KEY_BOLD = booleanPreferencesKey("bold")
            val KEY_OUTLINE = booleanPreferencesKey("outline_enabled")
            val KEY_OUTLINE_RGB = intPreferencesKey("outline_color_rgb")
            val KEY_BG_RGB = intPreferencesKey("background_color_rgb")
            val KEY_BG_OPACITY = intPreferencesKey("background_opacity_percent")
            val KEY_EDGE_TYPE = intPreferencesKey("edge_type")
            val KEY_BOTTOM = intPreferencesKey("bottom_offset")
            val KEY_DELAY_MAP = stringPreferencesKey("delay_map")
            @Suppress("unused")
            val KEY_UNUSED = longPreferencesKey("unused")
        }
    }

/** The phone panel's colour swatches, in order (RGB values). */
val SUBTITLE_COLOR_SWATCHES: List<Pair<String, Int>> =
    listOf(
        "White" to 0xFFFFFF,
        "Gold" to 0xFFD700,
        "Cyan" to 0x00E5FF,
        "Red" to 0xFF5C5C,
        "Green" to 0x00FF88,
        "Purple" to 0x9B59B6,
        "Orange" to 0xF97316,
        "Green" to 0x22C55E,
        "Blue" to 0x3B82F6,
        "Black" to 0x000000,
    )

/** The phone panel's outline colour swatches (RGB values). */
val SUBTITLE_OUTLINE_SWATCHES: List<Pair<String, Int>> =
    listOf(
        "Black" to 0x000000,
        "White" to 0xFFFFFF,
        "Cyan" to 0x00E5FF,
        "Red" to 0xFF5C5C,
    )
