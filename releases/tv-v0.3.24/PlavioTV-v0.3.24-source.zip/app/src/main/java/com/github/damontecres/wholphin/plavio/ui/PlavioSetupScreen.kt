package com.github.damontecres.wholphin.plavio.ui

import coil3.request.crossfade
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.InstalledAddon
import com.github.damontecres.wholphin.plavio.StremioApi
import kotlinx.coroutines.launch

/**
 * Addons (v0.3.21 redesign, the owner's approved sample): a header
 * ("Addons" + "N installed", Refresh + "+ Add addon" in the one
 * fixed capsule size) and one card per addon — letter/logo avatar,
 * name, "host · version", a status dot line, and THREE fixed-size
 * word capsules bottom-right: Configure / Disable|Enable / Remove.
 * The factory pre-installed set's Remove is disabled (the sample's
 * rule); Remove asks first (focus-trapped confirm). The add card
 * keeps the click-to-edit URL field: OK opens the keyboard, and
 * Enter (hardware key event — see PlavioClickToEditField), the IME
 * Done action, or the Add button all fetch + install the manifest.
 */
@Composable
fun PlavioSetupScreen(
    modifier: Modifier = Modifier,
    viewModel: PlavioSetupViewModel = hiltViewModel(),
) {
    val addons by viewModel.addons.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val defaultCatalogId by viewModel.defaultCatalogAddonId.collectAsState()
    var urlInput by rememberSaveable { mutableStateOf("") }
    var localNote by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(uiState.statusMessage) {
        if (uiState.statusMessage != null) {
            urlInput = ""
        }
    }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val refreshFocus = remember { FocusRequester() }
    val urlFieldFocus = remember { FocusRequester() }
    var setupClaimed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        // v0.3.14: was a single unretried shot — now the shared
        // primitive against the screen claim.
        landFocus(refreshFocus, isClaimed = { setupClaimed }, attempts = 6, delayMs = 130)
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    val entryScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            entryScope.launch {
                setupClaimed = false
                landFocus(refreshFocus, isClaimed = { setupClaimed }, attempts = 6, delayMs = 130)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    val factoryBaseUrls =
        remember {
            AddonStore.FACTORY_ADDON_URLS.map { StremioApi.normalizeBaseUrl(it) }.toSet()
        }
    val context = LocalContext.current

    Column(
        modifier =
            modifier
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) setupClaimed = true }
                .padding(end = 40.dp, top = 72.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.plavio_addons_heading),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text =
                        stringResource(R.string.plavio_addons_installed_count, addons.size),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            PlavioFixedButton(
                text =
                    if (uiState.refreshingIds.isNotEmpty()) {
                        stringResource(R.string.plavio_addons_refreshing)
                    } else {
                        stringResource(R.string.plavio_addons_refresh)
                    },
                onClick = { viewModel.refreshAllAddons() },
                enabled = addons.isNotEmpty() && uiState.refreshingIds.isEmpty(),
                focusRequester = refreshFocus,
            )
            PlavioFixedButton(
                text = "+ " + stringResource(R.string.plavio_addons_add),
                onClick = {
                    // Scroll the add card into view and land focus
                    // on its URL field — the button's whole job.
                    scope.launch {
                        runCatching {
                            listState.animateScrollToItem(addons.size + 1)
                        }
                        runCatching { urlFieldFocus.requestFocus() }
                    }
                },
                kind = PlavioButtonKind.Primary,
            )
        }

        when {
            uiState.adding -> {
                Text(
                    text = stringResource(R.string.plavio_addons_adding),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            uiState.errorMessage != null -> {
                Text(
                    text =
                        stringResource(R.string.plavio_addons_add_failed) +
                            (uiState.errorMessage?.let { " $it" } ?: ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            uiState.statusMessage != null -> {
                Text(
                    text = stringResource(R.string.plavio_addons_added, uiState.statusMessage!!),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (uiState.refreshNote != null) {
            Text(
                text = uiState.refreshNote!!,
                style = MaterialTheme.typography.bodyMedium,
                color =
                    if (uiState.refreshNoteIsError) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
            )
        }
        if (localNote != null) {
            Text(
                text = localNote!!,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // Default catalog choice (v0.3.16, note 6): shown only
        // when two or more ENABLED addons can serve catalogs. The
        // pick persists (PlavioUiPrefs) and drives the default
        // catalog source wherever the app used to hard-pick the
        // first/meta addon (AddonCatalogRepository.primaryMetaBaseUrl
        // + loadMeta's candidate order). With no explicit pick the
        // effective default shown selected is the historic one —
        // the first meta-capable catalog addon.
        val catalogAddons =
            addons.filter { it.enabled && it.manifest.hasCatalog }
        if (catalogAddons.size >= 2) {
            val effectiveDefaultId =
                defaultCatalogId?.takeIf { id -> catalogAddons.any { it.id == id } }
                    ?: catalogAddons.firstOrNull { it.manifest.hasMeta }?.id
                    ?: catalogAddons.first().id
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(PlavioOnyx.PanelFramed)
                        .border(1.dp, PlavioOnyx.PanelBorder, RoundedCornerShape(20.dp))
                        .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_addons_default_catalog),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.plavio_addons_default_catalog_sub),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        catalogAddons.forEach { addon ->
                            PlavioFilterCapsule(
                                text = addon.name,
                                selected = addon.id == effectiveDefaultId,
                                onClick = { viewModel.setDefaultCatalogAddon(addon.id) },
                            )
                        }
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 8.dp),
        ) {
            if (addons.isEmpty()) {
                item(key = "addons-empty") {
                    Text(
                        text = stringResource(R.string.plavio_addons_empty),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            itemsIndexed(
                addons,
                key = { index, addon -> "${addon.id}|${addon.baseUrl}|$index" },
            ) { _, addon ->
                AddonCard(
                    addon = addon,
                    isFactory = addon.baseUrl in factoryBaseUrls,
                    onEnabledChange = { viewModel.setAddonEnabled(addon.id, it) },
                    onRemove = { viewModel.removeAddon(addon.id) },
                    onConfigure = {
                        val url = addon.baseUrl.trimEnd('/') + "/configure"
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }.onFailure {
                            localNote =
                                context.getString(R.string.plavio_addons_configure_failed)
                        }
                    },
                )
            }
            item(key = "add-your-own") {
                // The install card: click-to-edit URL field (OK opens
                // the keyboard — v0.3.16, kept), Add + Sync buttons
                // in the one fixed capsule size under it.
                Box(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(PlavioOnyx.PanelFramed)
                            .border(1.dp, PlavioOnyx.PanelBorder, RoundedCornerShape(20.dp))
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = stringResource(R.string.plavio_addons_group_add),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        PlavioClickToEditField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions =
                                KeyboardOptions(
                                    keyboardType = KeyboardType.Uri,
                                    imeAction = ImeAction.Done,
                                ),
                            onDone = {
                                if (urlInput.isNotBlank()) {
                                    viewModel.addAddon(urlInput)
                                }
                            },
                            emptyHint = stringResource(R.string.plavio_addons_url_placeholder),
                            placeholder = {
                                androidx.compose.material3.Text(
                                    text = stringResource(R.string.plavio_addons_url_hint),
                                )
                            },
                            restingFocusRequester = urlFieldFocus,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            PlavioFixedButton(
                                text = stringResource(R.string.plavio_addons_add),
                                onClick = { viewModel.addAddon(urlInput) },
                                enabled = urlInput.isNotBlank() && !uiState.adding,
                                kind = PlavioButtonKind.Primary,
                                modifier = Modifier.width(124.dp),
                            )
                            PlavioFixedButton(
                                text =
                                    if (uiState.syncing) {
                                        stringResource(R.string.plavio_addons_syncing)
                                    } else {
                                        stringResource(R.string.plavio_account_sync_addons)
                                    },
                                onClick = { viewModel.syncAddonsFromAccount() },
                                enabled = !uiState.syncing,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddonCard(
    addon: InstalledAddon,
    isFactory: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    onRemove: () -> Unit,
    onConfigure: () -> Unit,
) {
    var confirmRemove by remember { mutableStateOf(false) }
    val removeFocus = remember { FocusRequester() }
    if (confirmRemove) {
        PlavioConfirmDialog(
            title = stringResource(R.string.plavio_addons_remove_title, addon.name),
            message = stringResource(R.string.plavio_addons_remove_text),
            confirmText = stringResource(R.string.plavio_addons_remove),
            dismissText = stringResource(R.string.plavio_cancel),
            danger = true,
            openerFocus = removeFocus,
            onConfirm = {
                confirmRemove = false
                onRemove()
            },
            onDismiss = { confirmRemove = false },
        )
    }
    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .alpha(if (addon.enabled) 1f else 0.7f)
                .clip(RoundedCornerShape(20.dp))
                .background(PlavioOnyx.PanelFramed)
                .border(1.dp, PlavioOnyx.PanelBorder, RoundedCornerShape(20.dp))
                .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                // Avatar: the addon's logo in a circle, else its
                // initial over the Weave gradient (brand artwork).
                Box(
                    modifier =
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .then(
                                if (addon.manifest.logo != null) {
                                    Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                                } else {
                                    Modifier.background(PlavioOnyx.WeaveBrush)
                                },
                            ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (addon.manifest.logo != null) {
                        coil3.compose.AsyncImage(
                            model =
                                coil3.request.ImageRequest
                                    .Builder(androidx.compose.ui.platform.LocalContext.current)
                                    .data(addon.manifest.logo)
                                    .size(104, 104)
                                    .crossfade(false)
                                    .build(),
                            contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().padding(6.dp),
                        )
                    } else {
                        Text(
                            text = addon.name.take(1).uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = addon.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text =
                            listOfNotNull(
                                addon.baseUrl
                                    .removePrefix("https://")
                                    .removePrefix("http://")
                                    .trimEnd('/'),
                                addon.manifest.version.takeIf { it.isNotBlank() }?.let { "v$it" },
                            ).joinToString(" · "),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        modifier = Modifier.padding(top = 3.dp),
                    ) {
                        Box(
                            modifier =
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (addon.enabled) {
                                            PlavioOnyx.CachedGreen
                                        } else {
                                            PlavioOnyx.TextSecondary
                                        },
                                    ),
                        )
                        Text(
                            text =
                                stringResource(
                                    if (addon.enabled) {
                                        R.string.plavio_addons_enabled_label
                                    } else {
                                        R.string.plavio_addons_disabled_label
                                    },
                                ) +
                                    if (addon.preinstalled) {
                                        " · " + stringResource(R.string.plavio_addons_builtin)
                                    } else {
                                        ""
                                    },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            // The three actions: ONE fixed size for every button on
            // every card (124×40), bottom-right as the sample draws.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlavioFixedButton(
                        text = stringResource(R.string.plavio_addons_configure),
                        onClick = onConfigure,
                        enabled = addon.manifest.configurable,
                        modifier = Modifier.width(124.dp),
                    )
                    PlavioFixedButton(
                        text =
                            stringResource(
                                if (addon.enabled) {
                                    R.string.plavio_addons_disable
                                } else {
                                    R.string.plavio_addons_enable
                                },
                            ),
                        onClick = { onEnabledChange(!addon.enabled) },
                        modifier = Modifier.width(124.dp),
                    )
                    PlavioFixedButton(
                        text = stringResource(R.string.plavio_addons_remove),
                        onClick = { confirmRemove = true },
                        enabled = !isFactory,
                        kind = PlavioButtonKind.Danger,
                        modifier = Modifier.width(124.dp),
                        focusRequester = removeFocus,
                    )
                }
            }
        }
    }
}
