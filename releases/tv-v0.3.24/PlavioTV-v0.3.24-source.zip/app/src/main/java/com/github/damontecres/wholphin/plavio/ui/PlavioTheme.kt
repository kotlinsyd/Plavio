package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.github.damontecres.wholphin.ui.theme.AppTypography

/**
 * Plavio TV's skin: the phone app's Onyx language, mirrored — pure black
 * canvas (#070707), flat charcoal panels (#1B1B1D), white primary text,
 * #9A9AA0 secondary text, and the phone's accent set driving focus,
 * highlights and loaders. White is the default accent, exactly as on
 * the phone.
 */
enum class PlavioAccent(
    val label: String,
    val primary: Color,
    val secondary: Color,
    /** Picker-circle gradient stops (Weave only); null = solid [primary] circle. */
    val pickerGradient: Array<Pair<Float, Color>>? = null,
) {
    WHITE("White", Color.White, Color(0xFFD9D9DE)),
    WEAVE(
        "Weave",
        Color(0xFF7C3AED),
        Color(0xFFDB2777),
        pickerGradient =
            arrayOf(
                0f to Color(0xFF7C3AED),
                0.55f to Color(0xFFDB2777),
                1f to Color(0xFFF9738C),
            ),
    ),
    CRIMSON("Crimson", Color(0xFFF43F5E), Color(0xFFFB923C)),
    OCEAN("Ocean", Color(0xFF38BDF8), Color(0xFF6366F1)),
    VIOLET("Violet", Color(0xFFA78BFA), Color(0xFFF0ABFC)),
    EMERALD("Emerald", Color(0xFF34D399), Color(0xFF22D3EE)),
    AMBER("Amber", Color(0xFFFBBF24), Color(0xFFF97316)),
    ROSE("Rose", Color(0xFFEC407A), Color(0xFFF48FB1)),
    ;

    companion object {
        fun byName(name: String?): PlavioAccent =
            entries.firstOrNull { it.name == name } ?: WHITE
    }
}

/** Onyx surface tokens shared by every Plavio TV screen. */
object PlavioOnyx {
    val Background = Color(0xFF070707)
    val Panel = Color(0xFF1B1B1D)
    val PanelVariant = Color(0xFF26262B)
    val TextPrimary = Color.White
    val TextSecondary = Color(0xFF9A9AA0)
    val Error = Color(0xFFF43F5E)

    // -- UI overhaul tokens (v0.3.11): the framed design system. Flat
    // panels only — no backdrop blur anywhere (weak TV boxes); depth
    // comes from the panel fill + hairline border + gradient scrims.
    /** Framed panel / card fill: a step above the #070707 canvas. */
    val PanelFramed = Color(0xFF121317)

    /** Hairline border for framed panels and cards (white 8%). */
    val PanelBorder = Color.White.copy(alpha = 0.08f)

    /** The side rail's near-black surface. */
    val RailBackground = Color(0xFF0B0B0E)

    /** Sample B frost (v0.3.16): the tray reads as dark frosted glass
     * WITHOUT a backdrop blur (weak TV GPUs) — a translucent
     * near-black blue-grey fill over the pure-black canvas plus the
     * glass hairline. Same trick as the phone dock's glass: fill +
     * border, no blur pass. */
    val RailGlass = Color(0xFF14141C).copy(alpha = 0.88f)

    /** Light look twin of [RailGlass]: the same colour, fully solid —
     * no translucency for the compositor to blend over moving rows
     * (owner's Light TV mode, 2026-11-04). */
    val RailSolid = Color(0xFF14141C)

    /** Weave brand gradient stops — BRAND ONLY since v0.3.14 (the
     * gradient brush below, logo-family artwork). Interactive colour
     * (focus rings, selections, switches) is the user's accent, never
     * these constants. */
    val WeavePink = Color(0xFFEC4899)
    val WeaveViolet = Color(0xFF7C3AED)

    /** Debrid "cached" green (the phone's Sample B tag green). */
    val CachedGreen = Color(0xFF4ADE80)
    val CachedGreenFill = Color(0xFF4ADE80).copy(alpha = 0.14f)
    val CachedGreenBorder = Color(0xFF4ADE80).copy(alpha = 0.35f)

    /** The Weave gradient as a horizontal brush (install button, marks). */
    val WeaveBrush: androidx.compose.ui.graphics.Brush
        get() =
            androidx.compose.ui.graphics.Brush.horizontalGradient(
                listOf(WeavePink, WeaveViolet),
            )

    /** The phone dock's glass: a light frost over the app background. */
    val GlassFill = Color.White.copy(alpha = 0.055f)
    val GlassBorder = Color.White.copy(alpha = 0.10f)

    /** Darker glass for chips that sit on artwork (the ★ rating chip). */
    val GlassFillStrong = Color.Black.copy(alpha = 0.55f)
}

val LocalPlavioAccent = compositionLocalOf { PlavioAccent.WHITE }

/**
 * The owner's Light look (2026-11-04): true when the user (or the
 * first-start auto-pick they confirmed) chose the cheap-drawn look
 * for a low-end TV. Provided by the root from PlavioUiPrefs.lookMode;
 * heavy-drawing sites (translucent layers, the hero backdrop) read it
 * and take their solid / skipped path. Default false = Full look.
 */
val LocalPlavioLightLook = compositionLocalOf { false }

/**
 * True while the full-screen player destination is on top (provided
 * by the root from its isPlaying state). Browse screens watch it for
 * the focus hand-back: with the keep-alive browse tree the landing
 * screen stays composed under the player, but focus itself lives in
 * the player tree and leaves with it — so on the playing→stopped
 * flip each browse screen re-requests its own first focus target
 * (v0.3.10). Default false.
 */
val LocalPlavioPlayerActive = compositionLocalOf { false }

/**
 * Readable content colour drawn ON this accent (switch thumb/icon on
 * the accent track, text on an accent-filled pill): near-black on
 * light accents (White, Amber), white on the rest. v0.3.14 — round 3
 * hard-coded a white switch thumb, so with the White accent the ON
 * switch rendered as one solid white pill.
 */
fun PlavioAccent.onAccent(): Color =
    if (primary.luminance() > 0.5f) Color(0xFF0A0A0C) else Color.White

@Composable
fun PlavioTvTheme(
    accent: PlavioAccent,
    content: @Composable () -> Unit,
) {
    val tvScheme =
        androidx.tv.material3.darkColorScheme(
            primary = accent.primary,
            onPrimary = if (accent == PlavioAccent.WHITE) Color.Black else Color.White,
            secondary = accent.secondary,
            onSecondary = Color.Black,
            background = PlavioOnyx.Background,
            onBackground = PlavioOnyx.TextPrimary,
            surface = PlavioOnyx.Panel,
            onSurface = PlavioOnyx.TextPrimary,
            surfaceVariant = PlavioOnyx.PanelVariant,
            onSurfaceVariant = PlavioOnyx.TextSecondary,
            error = PlavioOnyx.Error,
            onError = Color.White,
            // v0.3.14: the interactive colour IS the user's accent,
            // everywhere (owner order, superseding the v0.3.12/13
            // constant Weave-pink focus ring). This role drives the
            // focused border of every TV-Material control that doesn't
            // override it, plus Wholphin helpers that key off it
            // (CircularProgress / LoadingPage spin in this colour), so
            // it follows the accent pick dynamically: changing the
            // accent in Settings recolours focus, spinners and every
            // override site (which all read LocalPlavioAccent) at once.
            border = accent.primary,
            inverseSurface = Color.White,
            inverseOnSurface = Color.Black,
            scrim = Color.Black,
        )
    val materialScheme =
        androidx.compose.material3.darkColorScheme(
            primary = accent.primary,
            onPrimary = if (accent == PlavioAccent.WHITE) Color.Black else Color.White,
            secondary = accent.secondary,
            onSecondary = Color.Black,
            background = PlavioOnyx.Background,
            onBackground = PlavioOnyx.TextPrimary,
            surface = PlavioOnyx.Panel,
            onSurface = PlavioOnyx.TextPrimary,
            surfaceVariant = PlavioOnyx.PanelVariant,
            onSurfaceVariant = PlavioOnyx.TextSecondary,
            error = PlavioOnyx.Error,
            onError = Color.White,
            inverseSurface = Color.White,
            inverseOnSurface = Color.Black,
            scrim = Color.Black,
        )
    CompositionLocalProvider(LocalPlavioAccent provides accent) {
        androidx.compose.material3.MaterialTheme(
            colorScheme = materialScheme,
            typography = androidx.compose.material3.Typography(),
        ) {
            androidx.tv.material3.MaterialTheme(
                colorScheme = tvScheme,
                typography = AppTypography,
                content = content,
            )
        }
    }
}
