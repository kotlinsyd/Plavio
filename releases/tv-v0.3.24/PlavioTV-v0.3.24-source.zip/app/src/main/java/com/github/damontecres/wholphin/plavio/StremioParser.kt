package com.github.damontecres.wholphin.plavio

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Resilient hand-written parser for the Stremio addon protocol.
 * Addons in the wild vary (resources as strings or objects, missing fields),
 * so we parse JsonElement defensively with defaults instead of @Serializable.
 */
object StremioParser {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // Safe string read: a field that arrives as an object/array (addons in
    // the wild do this) defaults to null instead of jsonPrimitive throwing
    // IllegalArgumentException and aborting the entire parse.
    private fun JsonObject.str(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }

    private fun JsonObject.strList(key: String): List<String> =
        (this[key] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull } ?: emptyList()

    /**
     * Reads behaviorHints.proxyHeaders.request — extra HTTP headers an addon
     * requires on the stream URL (used by some debrid-backed addons).
     * Returns an empty map when absent.
    */
    private fun parseProxyHeaders(s: JsonObject, embeddedHeaders: Map<String, String>): Map<String, String> {
        val hints = s["behaviorHints"] as? JsonObject
        val req = (hints?.get("proxyHeaders") as? JsonObject)?.get("request") as? JsonObject
        val proxyHeaders = parseHeaderObject(req)
        // Explicit Stremio header objects retain their existing precedence over
        // proxy headers; both override URL-embedded IPTV headers.
        val merged = linkedMapOf<String, Pair<String, String>>()
        listOf(embeddedHeaders, proxyHeaders, parseHeaderObject(s["headers"] as? JsonObject)).forEach { source ->
            source.forEach { (name, value) -> merged[name.lowercase()] = name to value }
        }
        return merged.values.associate { it }
    }

    /**
     * IPTV playlists/addons often encode request headers as
     * `https://host/live.m3u8|User-Agent=...&Referer=...`. Treat the suffix as
     * headers only when every pair is well-formed; otherwise preserve the URL
     * unchanged rather than guessing at an arbitrary pipe in a URL.
     */
    private fun splitEmbeddedHeaders(rawUrl: String?): Pair<String?, Map<String, String>> {
        if (rawUrl == null) return null to emptyMap()
        val separator = rawUrl.lastIndexOf('|')
        if (separator < 0 || separator == rawUrl.lastIndex) return rawUrl to emptyMap()
        val pairs = rawUrl.substring(separator + 1).split('&')
        val headers = linkedMapOf<String, String>()
        for (pair in pairs) {
            val equals = pair.indexOf('=')
            if (equals <= 0) return rawUrl to emptyMap()
            val name = decodeHeaderComponent(pair.substring(0, equals)) ?: return rawUrl to emptyMap()
            val value = decodeHeaderComponent(pair.substring(equals + 1)) ?: return rawUrl to emptyMap()
            if (!name.matches(Regex("[!#$%&'*+.^_`|~0-9A-Za-z-]+")) ||
                value.isBlank() || value.any { it == '\r' || it == '\n' || it == '\u0000' }) {
                return rawUrl to emptyMap()
            }
            headers[name] = value
        }
        return rawUrl.substring(0, separator) to headers
    }

    private fun decodeHeaderComponent(value: String): String? =
        runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrNull()

    private fun parseHeaderObject(obj: JsonObject?): Map<String, String> =
        obj?.entries?.mapNotNull { (k, v) ->
            val value = (v as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
            if (value != null) k to value else null
        }?.toMap() ?: emptyMap()

    private fun resourceNames(el: JsonElement): List<String> = when (el) {
        is JsonPrimitive -> listOfNotNull(el.contentOrNull)
        is JsonObject -> listOfNotNull(el.str("name"))
        else -> emptyList()
    }

    fun parseManifest(text: String): AddonManifest {
        val obj = json.parseToJsonElement(text).jsonObject
        val id = obj.str("id") ?: throw IllegalArgumentException("Manifest is missing 'id'")
        val name = obj.str("name") ?: id
        val resources = (obj["resources"] as? JsonArray)
            ?.flatMap { resourceNames(it) } ?: emptyList()
        val catalogs = (obj["catalogs"] as? JsonArray)?.mapNotNull { el ->
            val c = el as? JsonObject ?: return@mapNotNull null
            val type = c.str("type") ?: return@mapNotNull null
            val cid = c.str("id") ?: return@mapNotNull null
            // "extra" declares supported query extras. Stremio shapes vary:
            // strings ("search"), {name:"search"} objects, or {name, options}.
            val extra = (c["extra"] as? JsonArray)?.mapNotNull { x ->
                when (x) {
                    is JsonPrimitive -> x.contentOrNull
                    is JsonObject -> x.str("name")
                    else -> null
                }
            } ?: emptyList()
            CatalogRef(type = type, id = cid, name = c.str("name") ?: cid, extra = extra)
        } ?: emptyList()
        return AddonManifest(
            id = id,
            name = name,
            version = obj.str("version") ?: "",
            description = obj.str("description") ?: "",
            logo = obj.str("logo"),
            types = obj.strList("types"),
            catalogs = catalogs,
            resources = resources,
            configurable = ((obj["behaviorHints"] as? JsonObject)
                ?.get("configurable") as? JsonPrimitive)?.booleanOrNull ?: false
        )
    }

    private fun parseMetaPreview(obj: JsonObject, fallbackType: String): MetaPreview? {
        val id = obj.str("id") ?: return null
        return MetaPreview(
            id = id,
            type = obj.str("type") ?: fallbackType,
            name = obj.str("name") ?: id,
            poster = obj.str("poster"),
            background = obj.str("background"),
            logo = obj.str("logo"),
            description = obj.str("description"),
            releaseInfo = obj.str("releaseInfo"),
            imdbRating = obj.str("imdbRating"),
            genres = obj.strList("genres")
        )
    }

    fun parseCatalog(text: String, fallbackType: String): List<MetaPreview> {
        val obj = json.parseToJsonElement(text).jsonObject
        return (obj["metas"] as? JsonArray)?.mapNotNull { el ->
            (el as? JsonObject)?.let { parseMetaPreview(it, fallbackType) }
        } ?: emptyList()
    }

    fun parseMeta(text: String, fallbackType: String): MetaDetail? {
        val obj = json.parseToJsonElement(text).jsonObject
        val meta = obj["meta"] as? JsonObject ?: return null
        val preview = parseMetaPreview(meta, fallbackType) ?: return null
        // distinctBy id: a sloppy addon can repeat a video id, and the
        // episode lists key rows by id — a repeat is a duplicate-key crash.
        val videos = (meta["videos"] as? JsonArray)?.mapNotNull { el ->
            val v = el as? JsonObject ?: return@mapNotNull null
            val vid = v.str("id") ?: return@mapNotNull null
            Video(
                id = vid,
                title = v.str("title") ?: v.str("name") ?: vid,
                season = (v["season"] as? JsonPrimitive)?.intOrNull ?: 0,
                episode = (v["episode"] as? JsonPrimitive)?.intOrNull ?: 0,
                overview = v.str("overview") ?: v.str("description"),
                thumbnail = v.str("thumbnail"),
                released = v.str("released")
            )
        }?.distinctBy { it.id } ?: emptyList()
        return MetaDetail(
            id = preview.id, type = preview.type, name = preview.name,
            poster = preview.poster, background = preview.background, logo = preview.logo,
            description = preview.description, releaseInfo = preview.releaseInfo,
            imdbRating = preview.imdbRating, genres = preview.genres, videos = videos,
            ratings = parseRatings(meta),
            trailerStreams = parseTrailers(meta), cast = parseCast(meta),
            runtime = meta.str("runtime"),
            status = meta.str("status"),
            certification = meta.str("certification") ?: meta.str("contentRating")
                ?: meta.str("mpaaRating"),
            country = meta.str("country") ?: meta.str("originCountry"),
            network = meta.str("network") ?: meta.strList("networks").firstOrNull()
        )
    }

    /** Score text for a ratings value: strings pass through; numbers print trimmed (8.0 -> "8", 8.35 -> "8.4"). */
    private fun ratingScoreText(el: JsonElement?): String? {
        val p = el as? JsonPrimitive ?: return null
        if (p.isString) return p.contentOrNull?.takeIf { it.isNotBlank() }
        val d = p.doubleOrNull ?: return p.contentOrNull?.takeIf { it.isNotBlank() }
        return if (d == d.toLong().toDouble()) {
            d.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.1f", d)
        }
    }

    /**
     * Multi-source ratings (v0.3.17). A meta addon may serve a
     * `ratings` array of {name|source, rating|value|score} objects, or
     * a {source: score} object. Only entries with BOTH a source label
     * and a score survive; the addon's own order is kept. PMeta and
     * Cinemeta serve no `ratings` today (their metas carry only
     * `imdbRating`) — this stays dormant for them and lights up for
     * any addon that does serve it.
     */
    private fun parseRatings(meta: JsonObject): List<MetaRating> {
        val out = mutableListOf<MetaRating>()
        fun add(
            source: String?,
            score: String?,
        ) {
            val s = source?.trim().orEmpty()
            val v = score?.trim().orEmpty()
            if (s.isNotEmpty() && v.isNotEmpty() && out.none { it.source.equals(s, ignoreCase = true) }) {
                out += MetaRating(source = s, score = v)
            }
        }
        when (val r = meta["ratings"]) {
            is JsonArray ->
                r.forEach { el ->
                    (el as? JsonObject)?.let { o ->
                        add(
                            o.str("name") ?: o.str("source") ?: o.str("title") ?: o.str("label"),
                            ratingScoreText(o["rating"] ?: o["value"] ?: o["score"]),
                        )
                    }
                }
            is JsonObject ->
                r.forEach { (key, value) -> add(key, ratingScoreText(value)) }
            else -> {}
        }
        return out.take(6)
    }

    /**
     * Cast list. PlavioMeta (TMDB mode) serves objects [{id,name,photo}];
     * keyless/Cinemeta mode serves plain name strings. Both are accepted;
     * string entries get id=0 (filmography unavailable).
     *
     * v0.3.13: PMeta's live meta serves cast as plain names, but its
     * `links` array carries an actor entry per member WITH the TMDB
     * person id (`personId`, mirrored in the themoviedb.org URL). Merge
     * those ids in by name — the Detail page then resolves each photo
     * from the addon's own /person/<id> route instead of rendering
     * initial-letter circles for the whole cast.
     */
    private fun parseCast(meta: JsonObject): List<CastMember> {
        val arr = meta["cast"] as? JsonArray ?: return emptyList()
        val actorIds = actorLinkIds(meta)
        val parsed =
            arr.mapNotNull { el ->
                when (el) {
                    is JsonObject -> {
                        val name = el.str("name") ?: return@mapNotNull null
                        CastMember(
                            id = (el["id"] as? JsonPrimitive)?.intOrNull
                                ?: actorIds[name.lowercase()]
                                ?: 0,
                            name = name,
                            photo = el.str("photo")
                        )
                    }
                    is JsonPrimitive -> el.contentOrNull?.takeIf { it.isNotBlank() }?.let {
                        CastMember(
                            id = actorIds[it.lowercase()] ?: 0,
                            name = it,
                        )
                    }
                    else -> null
                }
            }
        return dedupeCast(parsed).take(12)
    }

    /** Actor TMDB ids from the meta's links array: name (lowercased) → person id. */
    private fun actorLinkIds(meta: JsonObject): Map<String, Int> {
        val links = meta["links"] as? JsonArray ?: return emptyMap()
        val ids = HashMap<String, Int>()
        for (el in links) {
            val link = el as? JsonObject ?: continue
            if (link.str("category") != "actor") continue
            val name = link.str("name")?.takeIf { it.isNotBlank() } ?: continue
            val id =
                (link["personId"] as? JsonPrimitive)?.intOrNull
                    ?: link.str("url")
                        ?.substringAfterLast('/')
                        ?.takeWhile { it.isDigit() }
                        ?.toIntOrNull()
                    ?: continue
            if (id > 0) ids.putIfAbsent(name.lowercase(), id)
        }
        return ids
    }

    /**
     * One entry per person (TMDB id when known, else the name): an addon
     * can list the same actor twice, and the cast/people rows key chips by
     * id|name — a repeat is a duplicate-key crash (the phone's PLAVIO-D
     * class). First billing wins; a later duplicate only fills a missing
     * photo.
     */
    private fun dedupeCast(members: List<CastMember>): List<CastMember> {
        val byPerson = LinkedHashMap<String, CastMember>()
        for (member in members) {
            if (member.name.isBlank()) continue
            val key =
                if (member.id > 0) "id:${member.id}" else "name:${member.name.lowercase()}"
            val existing = byPerson[key]
            if (existing == null) {
                byPerson[key] = member
            } else if (existing.photo.isNullOrBlank() && !member.photo.isNullOrBlank()) {
                byPerson[key] = member
            }
        }
        return byPerson.values.toList()
    }

    /**
     * YouTube trailer references. PlavioMeta serves `trailerStreams`
     * ([{title, ytId}]); the Stremio-standard `trailers` array carries the
     * YouTube id in `source` ([{source, type}]). Both shapes are accepted.
     */
    private fun parseTrailers(meta: JsonObject): List<TrailerStream> {
        val out = linkedMapOf<String, TrailerStream>()
        (meta["trailerStreams"] as? JsonArray)?.forEach { el ->
            val o = el as? JsonObject ?: return@forEach
            val ytId = o.str("ytId")?.trim()?.takeIf { it.isNotEmpty() } ?: return@forEach
            out.putIfAbsent(ytId, TrailerStream(o.str("title") ?: "", ytId))
        }
        (meta["trailers"] as? JsonArray)?.forEach { el ->
            val o = el as? JsonObject ?: return@forEach
            val ytId = o.str("source")?.trim()?.takeIf { it.isNotEmpty() } ?: return@forEach
            // Skip non-YouTube sources (ids are 11-char YouTube video ids).
            if (!ytId.matches(Regex("[A-Za-z0-9_-]{11}"))) return@forEach
            out.putIfAbsent(ytId, TrailerStream(o.str("title") ?: "", ytId))
        }
        return out.values.toList()
    }

    fun parseStreams(text: String): StreamResult {
        val obj = json.parseToJsonElement(text).jsonObject
        val streams = (obj["streams"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val (url, embeddedHeaders) = splitEmbeddedHeaders(s.str("url"))
            val magnetHash = torrentHashFromMagnet(url)
            val infoHash = s.str("infoHash") ?: magnetHash
            val behaviorHints = s["behaviorHints"] as? JsonObject
            // Keep entries that have either a direct URL or an infoHash
            // (infoHash-only entries can be resolved via TorBox debrid).
            if (url == null && infoHash == null) return@mapNotNull null
            StreamItem(
                // Placeholder URL for infoHash-only entries so dedup still
                // works; StreamRepository replaces it with the real HTTP
                // link once TorBox resolves it.
                url = if (magnetHash != null) "infohash:$infoHash" else url ?: "infohash:$infoHash",
                name = s.str("name"),
                title = s.str("title") ?: s.str("description"),
                headers = parseProxyHeaders(s, embeddedHeaders),
                infoHash = infoHash,
                fileIdx = (s["fileIdx"] as? JsonPrimitive)?.intOrNull
                    ?: ((s["behaviorHints"] as? JsonObject)?.get("fileIdx") as? JsonPrimitive)?.intOrNull,
                filePath = s.str("filePath") ?: s.str("file") ?: s.str("path")
                    ?: s.str("filename") ?: behaviorHints?.str("filePath"),
                mimeType = s.str("mimeType") ?: behaviorHints?.str("mimeType"),
                videoSize = ((s["videoSize"] ?: behaviorHints?.get("videoSize")) as? JsonPrimitive)
                    ?.contentOrNull?.toLongOrNull(),
                filename = s.str("filename") ?: behaviorHints?.str("filename"),
                plavioPick = ((behaviorHints?.get("plavioPick") as? JsonPrimitive)?.booleanOrNull
                    ?: (s["plavioPick"] as? JsonPrimitive)?.booleanOrNull) == true,
            )
        } ?: emptyList()
        val subtitles = (obj["subtitles"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val url = s.str("url") ?: return@mapNotNull null
            Subtitle(url = url, lang = s.str("lang") ?: "und")
        } ?: emptyList()
        return StreamResult(streams, subtitles)
    }

    /** Parses a dedicated /subtitles/{type}/{id}.json response. */
    fun parseSubtitles(text: String): List<Subtitle> {
        val obj = json.parseToJsonElement(text).jsonObject
        return (obj["subtitles"] as? JsonArray)?.mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val url = s.str("url") ?: return@mapNotNull null
            Subtitle(url = url, lang = s.str("lang") ?: "und")
        } ?: emptyList()
    }

    /** Parses PlavioMeta /related/{type}/{id}.json: { sections: [{id,title,metas}] }. */
    fun parseRelated(text: String, fallbackType: String): List<RelatedSection> {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return emptyList()
        return ((obj["sections"] as? JsonArray) ?: return emptyList()).mapNotNull { el ->
            val s = el as? JsonObject ?: return@mapNotNull null
            val title = s.str("title") ?: return@mapNotNull null
            val metas = ((s["metas"] as? JsonArray) ?: JsonArray(emptyList())).mapNotNull { m ->
                (m as? JsonObject)?.let { parseMetaPreview(it, fallbackType) }
            }
            if (metas.isEmpty()) return@mapNotNull null
            RelatedSection(
                id = s.str("id") ?: title,
                title = title,
                metas = metas
            )
        }
    }

    /** Parses PlavioMeta /person/{id}.json: { person, movies, series }. */
    fun parsePerson(text: String): PersonDetail? {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return null
        val p = obj["person"] as? JsonObject ?: return null
        val name = p.str("name") ?: return null
        fun metas(key: String, type: String): List<MetaPreview> =
            ((obj[key] as? JsonArray) ?: JsonArray(emptyList())).mapNotNull { m ->
                (m as? JsonObject)?.let { parseMetaPreview(it, type) }
            }
        return PersonDetail(
            id = (p["id"] as? JsonPrimitive)?.intOrNull ?: 0,
            name = name,
            photo = p.str("photo"),
            movies = metas("movies", "movie"),
            series = metas("series", "series")
        )
    }

    /**
     * Parses /person-search/{query}.json: { people: [{id,name,photo,knownFor}] }.
     * Returns null when the payload has no people array — the addon does
     * not serve the route — so the caller can try the next addon. An
     * empty list is a real answer (same contract as the phone).
     */
    fun parsePersonSearch(text: String): List<CastMember>? {
        val obj = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
            ?: return null
        val arr = obj["people"] as? JsonArray ?: return null
        return dedupeCast(
            arr.mapNotNull { el ->
                val p = el as? JsonObject ?: return@mapNotNull null
                val name = p.str("name") ?: return@mapNotNull null
                CastMember(
                    id = (p["id"] as? JsonPrimitive)?.intOrNull ?: 0,
                    name = name,
                    photo = p.str("photo")
                )
            }
        )
    }
}
