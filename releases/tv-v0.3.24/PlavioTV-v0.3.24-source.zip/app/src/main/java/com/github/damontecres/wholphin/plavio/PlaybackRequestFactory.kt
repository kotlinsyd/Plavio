package com.github.damontecres.wholphin.plavio

import com.github.damontecres.wholphin.plavio.ui.StreamsRef

/**
 * Builds the [PlaybackRequest] the player consumes from a streams-screen
 * reference + bundle + chosen stream. Shared by the streams picker, the
 * detail page's Watch Now (autoplay) and the Live tab, so every entry
 * point hands the player the same shape — including the full episode
 * list the next-episode autoplay needs.
 */
/** The streams reference a [PlaybackRequest] belongs to (the
 * player-side twin of the root's helper — same fields, same order). */
fun refForPlaybackRequest(request: PlaybackRequest): StreamsRef =
    StreamsRef(
        type = request.type,
        videoId = request.videoId,
        metaId = request.metaId,
        title = request.seriesName ?: request.title,
        poster = request.poster,
        backdrop = request.backdrop,
        season = request.season,
        episode = request.episode,
        episodeTitle = request.episodeTitle,
        seriesName = request.seriesName,
    )

/**
 * The unresolved Play request of v0.3.16's Instant Play (note 9):
 * everything the player needs to find the streams itself — title,
 * art, ids, episode context — and no stream URL. The player resolves
 * it on start (autoplay pick inside the player); if nothing playable
 * answers it reports resume-failed and the sources picker opens.
 */
fun buildPendingPlaybackRequest(
    ref: StreamsRef,
    episodes: List<Video> = emptyList(),
): PlaybackRequest =
    PlaybackRequest(
        streamUrl = "",
        title =
            if (ref.seriesName != null) {
                listOfNotNull(ref.seriesName, ref.episodeTitle).joinToString(" — ")
            } else {
                ref.title
            },
        poster = ref.poster,
        backdrop = ref.backdrop,
        videoId = ref.videoId,
        imdbId = Regex("""tt\d+""").find(ref.metaId)?.value,
        season = ref.season,
        episode = ref.episode,
        isMovie = ref.type == "movie",
        type = ref.type,
        episodes = episodes,
        metaId = ref.metaId,
        seriesName = ref.seriesName,
        episodeTitle = ref.episodeTitle,
        autoplayResolve = true,
    )

fun buildPlaybackRequest(
    ref: StreamsRef,
    bundle: StreamBundle,
    stream: StreamItem,
    episodes: List<Video> = emptyList(),
): PlaybackRequest =
    PlaybackRequest(
        streamUrl = stream.url,
        title =
            if (ref.seriesName != null) {
                listOfNotNull(ref.seriesName, ref.episodeTitle).joinToString(" — ")
            } else {
                ref.title
            },
        poster = ref.poster,
        backdrop = ref.backdrop,
        videoId = ref.videoId,
        subtitles = bundle.subtitles,
        imdbId = Regex("""tt\d+""").find(ref.metaId)?.value,
        season = ref.season,
        episode = ref.episode,
        isMovie = ref.type == "movie",
        type = ref.type,
        streamLabel = streamQualityLabel(stream),
        sourceName = stream.sourceName,
        streams = bundle.streams,
        episodes = episodes,
        metaId = ref.metaId,
        seriesName = ref.seriesName,
        episodeTitle = ref.episodeTitle,
        headers = stream.headers,
        mimeType = stream.mimeType,
    )
