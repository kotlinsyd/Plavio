package com.github.damontecres.wholphin.ui

import android.content.Context
import android.content.res.Resources
import android.text.format.DateFormat
import androidx.annotation.StringRes
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.buildAnnotatedString
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.WholphinApplication
import timber.log.Timber
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.format.FormatStyle
import java.util.Date
import java.util.Locale
import kotlin.time.Duration

/**
 * Format the time-of-day of [time] honouring the device's 12/24-hour setting and the current
 * locale. [context] should be an Activity/composition context (e.g. `LocalContext.current`) so an
 * in-app language switch (`AppCompatDelegate.setApplicationLocales`) is reflected; the application
 * context may carry a stale locale.
 */
fun formatTime(
    context: Context,
    time: LocalDateTime,
): String = formatTime(context, time.toLocalTime())

fun formatTime(
    context: Context,
    time: LocalTime,
): String {
    val instant =
        time
            .atDate(LocalDate.now())
            .atZone(ZoneId.systemDefault())
            .toInstant()
    return DateFormat.getTimeFormat(context).format(Date.from(instant))
}

private var dateFormatter: DateTimeFormatter =
    DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Locale.getDefault())

fun getDateFormatter(): DateTimeFormatter {
    if (dateFormatter.locale != Locale.getDefault()) {
        dateFormatter = dateFormatter.withLocale(Locale.getDefault())
    }
    return dateFormatter
}

// TODO server returns in UTC, but sdk converts to local time
// eg 2020-02-14T00:00:00.0000000Z => 2020-02-13T17:00:00 PT => Feb 13, 2020

/**
 * Format a [LocalDateTime] as `Aug 24, 2000`
 */
fun formatDateTime(dateTime: LocalDateTime): String = getDateFormatter().format(dateTime)

fun formatDate(dateTime: LocalDate): String = getDateFormatter().format(dateTime)

fun formatDate(dateTime: LocalDateTime): String = getDateFormatter().format(dateTime)

fun toLocalDate(date: String?): LocalDate? =
    date?.let {
        try {
            LocalDate.parse(it)
        } catch (_: DateTimeParseException) {
            Timber.w("Could not parse date: %s", date)
            null
        }
    }

// Falls back to the default format if the application is not initialized (e.g. unit tests)
private fun formatStringWithFallback(
    @StringRes resId: Int,
    defaultFormat: String,
    vararg args: Any,
): String {
    val resources =
        try {
            WholphinApplication.instance.resources
        } catch (_: UninitializedPropertyAccessException) {
            null
        }
    return resources?.getString(resId, *args)
        ?: String.format(Locale.getDefault(), defaultFormat, *args)
}

/**
 * Format season & episode numbers using localized string resources.
 * Returns null if [season] or [episode] is missing.
 */
fun formatSeasonEpisode(
    season: Int?,
    episode: Int?,
    episodeEnd: Int? = null,
    padded: Boolean = false,
): String? {
    if (season == null || episode == null) return null
    return if (episodeEnd != null) {
        if (padded) {
            formatStringWithFallback(R.string.season_episode_number_padded_range, "S%1\$02dE%2\$02d-E%3\$02d", season, episode, episodeEnd)
        } else {
            formatStringWithFallback(R.string.season_episode_number_range, "S%1\$d E%2\$d-E%3\$d", season, episode, episodeEnd)
        }
    } else if (padded) {
        formatStringWithFallback(R.string.season_episode_number_padded, "S%1\$02dE%2\$02d", season, episode)
    } else {
        formatStringWithFallback(R.string.season_episode_number, "S%1\$d E%2\$d", season, episode)
    }
}

/** Compact episode-only label, e.g. `E3`. */
fun formatEpisodeNumber(episode: Int): String = formatStringWithFallback(R.string.episode_number_short, "E%1\$d", episode)

/** Fallback season title when the library has no season name, e.g. `Season 2`. */
fun formatSeasonNumber(season: Int): String = formatStringWithFallback(R.string.season_number, "Season %1\$d", season)

private val abbrevSuffixes = listOf("", "K", "M", "B")

/**
 * Format a number by abbreviation, eg 5533 => 5.5K
 */
fun abbreviateNumber(number: Int): String {
    if (number < 1000) {
        return number.toString()
    }
    var unit = 0
    var count = number.toDouble()
    while (count >= 1000 && unit + 1 < abbrevSuffixes.size) {
        count /= 1000
        unit++
    }
    return String.format(Locale.getDefault(), "%.1f%s", count, abbrevSuffixes[unit])
}

val byteSuffixes = listOf("B", "KiB", "MiB", "GiB", "TiB")
val byteRateSuffixes = listOf("bps", "kbps", "mbps", "gbps", "tbps")

fun formatBytes(
    bytes: Long,
    suffixes: List<String> = byteSuffixes,
    divisor: Int = 1024,
): String {
    var unit = 0
    var count = bytes.toDouble()
    while (count >= divisor && unit + 1 < suffixes.size) {
        count /= divisor
        unit++
    }
    return String.format(Locale.getDefault(), "%.2f %s", count, suffixes[unit])
}

fun formatBitrate(bitrate: Int) = formatBytes(bitrate.toLong(), byteRateSuffixes, 1000)

fun AnnotatedString.Builder.dot() = append("  \u2022  ")

fun listToDotString(
    strings: List<String>,
    communityRating: Float?,
    criticRating: Float?,
): AnnotatedString =
    buildAnnotatedString {
        strings.forEachIndexed { index, string ->
            append(string)
            if (index != strings.lastIndex) dot()
        }
        communityRating?.let {
            dot()
            append(String.format(Locale.getDefault(), "%.1f", it))
            appendInlineContent(id = "star")
        }
        criticRating?.let {
            dot()
            append("${it.toInt()}%")
            if (it >= 60f) {
                appendInlineContent(id = "fresh")
            } else {
                appendInlineContent(id = "rotten")
            }
        }
    }

/**
 * Format a [Duration] into a localized "Xh Ym Zs" string using string resources.
 */
fun Resources.formatDuration(duration: Duration): String =
    duration.toComponents { hours, minutes, seconds, _ ->
        when {
            hours > 0 && minutes > 0 && seconds > 0 -> getString(R.string.duration_hours_minutes_seconds, hours.toInt(), minutes, seconds)
            hours > 0 && minutes > 0 -> getString(R.string.duration_hours_minutes, hours.toInt(), minutes)
            hours > 0 && seconds > 0 -> getString(R.string.duration_hours_seconds, hours.toInt(), seconds)
            hours > 0 -> getString(R.string.duration_hours, hours.toInt())
            minutes > 0 && seconds > 0 -> getString(R.string.duration_minutes_seconds, minutes, seconds)
            minutes > 0 -> getString(R.string.duration_minutes, minutes)
            else -> getString(R.string.duration_seconds, seconds)
        }
    }
