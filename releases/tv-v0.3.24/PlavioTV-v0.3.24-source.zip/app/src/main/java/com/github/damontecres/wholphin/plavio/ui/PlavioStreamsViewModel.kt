package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.PlavioProgressStore
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.StreamBundle
import com.github.damontecres.wholphin.plavio.StreamItem
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioStreamsUiState {
    data object Loading : PlavioStreamsUiState

    data class Loaded(
        val bundle: StreamBundle,
        /** Full episode list for series — the player's next-episode autoplay needs it. */
        val episodes: List<Video> = emptyList(),
        /** True while more addons are still answering (progressive fill). */
        val filling: Boolean = false,
    ) : PlavioStreamsUiState
}

@HiltViewModel
class PlavioStreamsViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val downloadManager: PlavioDownloadManager,
        private val progressStore: PlavioProgressStore,
        uiPrefs: PlavioUiPrefs,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioStreamsUiState>(PlavioStreamsUiState.Loading)
        val state: StateFlow<PlavioStreamsUiState> = _state

        /** Stream-card badge style + group toggles (Settings → Streams; phone parity). */
        val badgeConfig: StateFlow<StreamCapsuleConfig> =
            combine(
                uiPrefs.badgeStyle,
                combine(
                    uiPrefs.badgeGroupResolution,
                    uiPrefs.badgeGroupHdr,
                    uiPrefs.badgeGroupAudio,
                    uiPrefs.badgeGroupLanguages,
                    uiPrefs.badgeGroupSourceCodec,
                    uiPrefs.badgeGroupSize,
                ) { groups -> groups },
            ) { style, groups ->
                StreamCapsuleConfig(
                    style = BadgeStyle.fromName(style),
                    showResolution = groups[0],
                    showHdr = groups[1],
                    showAudio = groups[2],
                    showLanguages = groups[3],
                    showSourceCodec = groups[4],
                    showSize = groups[5],
                )
            }.stateIn(viewModelScope, SharingStarted.Eagerly, StreamCapsuleConfig())

        /** Transient line under the heading ("Download started" / a refusal reason). */
        private val _notice = MutableStateFlow<String?>(null)
        val notice: StateFlow<String?> = _notice

        /**
         * Saved resume position for the loaded item (from the
         * continue-watching store, keyed type|videoId — the same key
         * the player progress writes), or 0 when there is nothing to
         * resume. The panel shows it as a chip and hands it to the
         * player through the existing Play resume path (v0.3.17).
         */
        private val _resumePositionMs = MutableStateFlow(0L)
        val resumePositionMs: StateFlow<Long> = _resumePositionMs

        private var loadedKey: String? = null

        fun load(
            type: String,
            videoId: String,
            metaId: String,
        ) {
            val key = "$type|$videoId"
            if (key == loadedKey) return
            loadedKey = key
            // Resume position for this item, kept live while the
            // screen is open (the entry can only change from another
            // screen, but the flow is cheap and always current).
            viewModelScope.launch {
                progressStore.entries.collect { entries ->
                    _resumePositionMs.value =
                        entries.firstOrNull { it.key == key }?.positionMs ?: 0L
                }
            }
            viewModelScope.launch {
                _state.value = PlavioStreamsUiState.Loading
                // The episode list loads alongside the streams instead
                // of after them; partial bundles below carry whatever
                // is ready at the time.
                var episodes: List<Video> = emptyList()
                val episodesJob =
                    launch {
                        episodes =
                            if (type == "series") {
                                runCatching { repository.loadMeta("", type, metaId) }
                                    .getOrNull()
                                    ?.videos
                                    ?: emptyList()
                            } else {
                                emptyList()
                            }
                    }
                // Progressive (v0.3.10): each addon's streams render as
                // soon as that addon answers; the debrid pass and the
                // slowest addon no longer hold the whole list hostage.
                // Empty partials stay on the spinner — "no streams" is
                // only declared once every addon has settled.
                val bundle =
                    repository.loadStreamsProgressive(type, videoId, metaId) { partial ->
                        if (partial.streams.isNotEmpty()) {
                            _state.value =
                                PlavioStreamsUiState.Loaded(partial, episodes, filling = true)
                        }
                    }
                episodesJob.join()
                _state.value = PlavioStreamsUiState.Loaded(bundle, episodes, filling = false)
            }
        }

        /** Enqueues a download of [stream] for the item this screen is about. */
        fun download(
            ref: StreamsRef,
            stream: StreamItem,
        ) {
            if (downloadManager.isDashUrl(stream.url)) {
                _notice.value = "DASH streams can't be downloaded."
                return
            }
            downloadManager.enqueue(
                url = stream.url,
                title =
                    if (ref.seriesName != null) {
                        listOfNotNull(ref.seriesName, ref.episodeTitle).joinToString(" — ")
                    } else {
                        ref.title
                    },
                poster = ref.poster,
                type = ref.type,
                videoId = ref.videoId,
                metaId = ref.metaId,
                season = ref.season,
                episode = ref.episode,
                seriesName = ref.seriesName,
                episodeTitle = ref.episodeTitle,
                sourceName = stream.sourceName,
                headers = stream.headers,
                mimeType = stream.mimeType,
            )
            _notice.value = "Download started — find it in Downloads."
        }
    }
