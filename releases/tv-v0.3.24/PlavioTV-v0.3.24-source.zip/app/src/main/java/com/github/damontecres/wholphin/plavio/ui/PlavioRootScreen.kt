package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.border
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.BuildConfig
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import kotlinx.coroutines.launch

/**
 * In-app destinations for the Plavio flow. v0.3.21 (the redesign):
 * ONE global stack for every browse destination — the root
 * destinations (Home, Search, Live, Library, Addons, Downloads,
 * Settings, Account) sit at the bottom and Detail / Actor / Streams
 * push on top of whichever root opened them, so Back always unwinds
 * to the opener and the capsule's selection is simply the nearest
 * root under the stack top. Play is rendered full-screen above
 * everything, as before.
 */
sealed interface PlavioDestination {
    data object Home : PlavioDestination

    data object Search : PlavioDestination

    data object Live : PlavioDestination

    data object Library : PlavioDestination

    data object Addons : PlavioDestination

    data object Downloads : PlavioDestination

    data object Settings : PlavioDestination

    data object Account : PlavioDestination

    data class Detail(
        val baseUrl: String,
        val type: String,
        val id: String,
        /** Preview art/name from the tapped card (v0.3.13): the Detail
         * loading state shows the title's own backdrop + name from the
         * first frame instead of a black "Loading…" screen. */
        val previewName: String? = null,
        val previewPoster: String? = null,
        val previewBackground: String? = null,
    ) : PlavioDestination

    data class Actor(
        val personId: Int,
        val name: String,
    ) : PlavioDestination

    data class Streams(
        val ref: StreamsRef,
    ) : PlavioDestination

    data class Play(
        val request: PlaybackRequest,
        /** Continue Watching resumes seek here; fresh plays start at 0. */
        val resumePositionMs: Long = 0,
    ) : PlavioDestination
}

/** True for the destinations the capsule's five buttons + profile own. */
private fun PlavioDestination.isRoot(): Boolean =
    when (this) {
        PlavioDestination.Home, PlavioDestination.Search, PlavioDestination.Live,
        PlavioDestination.Library, PlavioDestination.Addons, PlavioDestination.Downloads,
        PlavioDestination.Settings, PlavioDestination.Account,
        -> true
        else -> false
    }

/** The streams-screen reference for the item a [PlaybackRequest] belongs to. */
private fun streamsRefFor(request: PlaybackRequest): StreamsRef =
    StreamsRef(
        type = request.type,
        videoId = request.videoId,
        metaId = request.metaId,
        title = request.seriesName ?: request.title,
        poster = request.poster,
        backdrop = request.backdrop,
        season = request.season,
        episode = request.episode,
        episodeTitle = request.episodeTitle,
        seriesName = request.seriesName,
    )

/** Everything the streams screen (and the player after it) needs about a playable item. */
data class StreamsRef(
    val type: String,
    val videoId: String,
    val metaId: String,
    val title: String,
    val poster: String?,
    /** Wide art for the player's loading layer (v0.3.13); poster is the fallback. */
    val backdrop: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    val episodeTitle: String? = null,
    val seriesName: String? = null,
)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun PlavioRootScreen(
    modifier: Modifier = Modifier,
    rootViewModel: PlavioRootViewModel = hiltViewModel(),
    playerViewModel: PlavioPlayerViewModel = hiltViewModel(),
) {
    var showSplash by remember { mutableStateOf(true) }
    if (showSplash) {
        PlavioSplashScreen(
            onDone = { showSplash = false },
            modifier = modifier,
        )
        return
    }

    val stack =
        remember { mutableStateListOf<PlavioDestination>(PlavioDestination.Home) }
    // Settings can be opened straight onto a sub-page (Account's
    // "Connected services" row opens Integrations this way).
    var settingsStartPage by remember { mutableStateOf("main") }

    fun goRoot(dest: PlavioDestination) {
        stack.clear()
        stack.add(PlavioDestination.Home)
        if (dest != PlavioDestination.Home) stack.add(dest)
    }

    fun push(dest: PlavioDestination) {
        stack.add(dest)
    }

    val pendingUpdate by rootViewModel.pendingUpdate.collectAsState()
    val installing by rootViewModel.installing.collectAsState()
    // TV look (owner design 2026-11-04, final shape): a Settings-only
    // choice — no first-start popup, no in-app offer (owner's cut).
    val lookMode by rootViewModel.lookMode.collectAsState()
    val lightLook = lookMode == com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_LIGHT
    val updateProblem by rootViewModel.updateProblem.collectAsState()
    LaunchedEffect(Unit) {
        rootViewModel.maybeCheckOnLaunch()
    }
    // Returning from the unknown-sources detour with the permission
    // granted continues into the installer on its own (v0.3.6).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        rootViewModel.onResumed()
        // v0.3.21 (study fix #5): re-open a play the ON_STOP standby
        // teardown tore down, if one is waiting — a no-op otherwise.
        runCatching { playerViewModel.resumeFromStandby() }
    }
    // The app left the foreground mid-playback (Home button, app
    // switch, TV standby): snapshot the play and tear the player
    // FULLY down through the release funnel (v0.3.21, study fix
    // #5 — the standby case file). The sound still dies on the
    // spot (stop() pauses synchronously — the 2026-11-04 "audio
    // keep playing back" fix holds), the position is saved, and
    // ON_RESUME above re-opens the play from the snapshot.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        if (stack.lastOrNull() is PlavioDestination.Play) {
            runCatching { playerViewModel.teardownForStandby() }
        }
    }
    // The update dialog's confirm button takes focus when it appears,
    // so the remote's centre press lands on Update (v0.3.6).
    // v0.3.14: the landing goes through the shared primitive — a
    // bounded retry that stands down when the dialog goes away —
    // instead of the old single blind shot.
    val updateButtonFocus = remember { FocusRequester() }
    LaunchedEffect(pendingUpdate) {
        if (pendingUpdate != null) {
            landFocus(
                requester = updateButtonFocus,
                isClaimed = { pendingUpdate == null },
                attempts = 6,
                delayMs = 120,
            )
        }
    }

    // ---- The focus scaffold (v0.3.14, the focus rebuild) -----------
    // The root owns the three things screens used to improvise:
    // (1) a requester per capsule destination, so focus can be sent
    //     INTO the capsule deterministically (edge door, Back door);
    // (2) the content-entry transfer holder screens register their
    //     own landing with (the return door — PlavioFocus.kt);
    // (3) the cross-screen memories that must outlive the
    //     AnimatedContent disposing a screen under a pushed child:
    //     Detail's armed restore records and Home's focus memory.
    val contentEntry = remember { ContentEntryFocus() }
    val capsuleRequesters =
        remember {
            listOf(
                PlavioDestination.Home,
                PlavioDestination.Search,
                PlavioDestination.Live,
                PlavioDestination.Library,
                PlavioDestination.Settings,
                PlavioDestination.Account,
            ).associateWith { FocusRequester() }
        }
    var capsuleHasFocus by remember { mutableStateOf(false) }
    val detailRestores = remember { mutableMapOf<String, DetailRestore>() }
    val homeFocusMemory = remember { HomeFocusMemory() }
    val focusManager = LocalFocusManager.current
    val rootScope = rememberCoroutineScope()

    // ---- The capsule exit (v0.3.15 — HARD mechanism, three doors) --
    // v0.3.14's return door was a single hop of faith: the capsule
    // called the current screen's registered landing and trusted its
    // boolean. On Home that landing silently no-opped (its claim
    // read a stale latch — see CatalogRows.landHome), the transfer
    // still reported success, the Right key was consumed so geometry
    // never ran, and focus was welded into the capsule until a power
    // cycle. The exit is therefore no longer a hop of faith:
    //   step 1 — fire the screen's own scripted landing (it knows
    //     the remembered/exact target and scrolls it into view);
    //   step 2 — VERIFY, frame by frame, that focus actually LEFT
    //     the capsule. If it is still inside after a short head
    //     start, take it out GEOMETRICALLY (a Right move from the
    //     leftmost strip can only land in the content), retrying on
    //     later frames, and ask the screen once more at the end.
    // The ladder depends on nothing a screen can fail to register:
    // screens with no handler at all (Settings, Account) are rescued
    // by step 2 alone. All three doors — Right in the capsule,
    // re-selecting the current section, Back in the capsule — call
    // this one function.
    fun exitCapsuleToContent() {
        contentEntry.transfer()
        rootScope.launch {
            var nudges = 0
            repeat(20) { frame ->
                withFrameNanos { }
                if (!capsuleHasFocus) return@launch
                // Head start: frames 0–9 belong to the screen's own
                // landing. v0.3.16 (note 7): the window doubled from
                // 0–4 — Detail's restore scroll is instant now, but
                // its landing still composes a beat after the scroll,
                // and the geometric pushes that fired at frame 5 used
                // to land mid-flight, trip the page's claim sensor
                // and stand the scripted landing down (RIGHT from
                // the capsule's lower buttons "did nothing"; from
                // Home the rescue happened to land on stable hero
                // nodes, so it read as working). From frame 10, push
                // geometrically every 3 frames, at most 3 pushes —
                // the rescue still exists, it just speaks last.
                if (frame >= 10 && (frame - 10) % 3 == 0 && nudges < 3) {
                    focusManager.moveFocus(FocusDirection.Right)
                    nudges++
                }
            }
            if (capsuleHasFocus) {
                // Last resort: the screen may have registered late —
                // ask once more, then one final geometric push.
                contentEntry.transfer()
                withFrameNanos { }
                if (capsuleHasFocus) {
                    focusManager.moveFocus(FocusDirection.Right)
                }
            }
        }
    }

    BackHandler(enabled = stack.size > 1) {
        // Leaving the player: stop playback FIRST, synchronously, so
        // the picture and sound die on the press itself (owner report
        // 2026-11-04: closing the player took time and the video kept
        // playing in the background for a few seconds). The old order
        // popped first and let the player screen's onDispose stop the
        // player — but that only runs after the browse tree's heavy
        // first compose finishes, which on a weak TV is exactly those
        // few seconds, and sometimes reads as "back is stuck".
        // stop() pauses now and releases on a background thread; the
        // screen's own onDispose stop() remains as a harmless second
        // pass. Same activity-scoped instance the player screen uses
        // (this app keeps a custom back stack, not NavHost entries).
        if (stack.lastOrNull() is PlavioDestination.Play) {
            runCatching { playerViewModel.stop() }
        }
        stack.removeAt(stack.lastIndex)
    }

    // Back at a root destination opens the capsule (v0.3.14, the
    // reference behaviour the owner ordered): the landing is the
    // CURRENT section's own capsule button, via its requester —
    // deterministic, not geometric luck. When the capsule already
    // holds focus this handler stands down and Back falls through
    // to exit, exactly like the reference's open-panel Back.
    BackHandler(enabled = stack.size == 1 && !capsuleHasFocus) {
        val currentRoot = stack.lastOrNull { it.isRoot() } ?: PlavioDestination.Home
        capsuleRequesters[currentRoot]?.let { requester ->
            runCatching { requester.requestFocus() }
        }
    }

    pendingUpdate?.let { update ->
        AlertDialog(
            onDismissRequest = { rootViewModel.dismissUpdate() },
            title = {
                androidx.compose.material3.Text(
                    text = stringResource(R.string.plavio_update_available_title),
                )
            },
            text = {
                androidx.compose.material3.Text(
                    text =
                        when {
                            installing -> stringResource(R.string.plavio_update_downloading)
                            updateProblem == PlavioRootViewModel.UpdateProblem.PermissionNeeded ->
                                stringResource(R.string.plavio_update_permission_needed)
                            updateProblem == PlavioRootViewModel.UpdateProblem.Failed ->
                                stringResource(R.string.plavio_update_launch_failed)
                            else ->
                                stringResource(R.string.plavio_update_available_text, update.versionName) +
                                    (update.notes?.let { "\n\n$it" } ?: "")
                        },
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = { rootViewModel.installPendingUpdate() },
                    enabled = !installing,
                    modifier = Modifier.focusRequester(updateButtonFocus),
                ) {
                    androidx.compose.material3.Text(stringResource(R.string.plavio_update_now))
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { rootViewModel.dismissUpdate() },
                    enabled = !installing,
                ) {
                    androidx.compose.material3.Text(stringResource(R.string.plavio_update_later))
                }
            },
        )
    }

    val top = stack.lastOrNull() ?: PlavioDestination.Home
    // The destination the BROWSE tree shows: the topmost non-Play
    // entry. While the player runs, browse keeps showing (and keeps
    // alive) exactly this screen underneath (v0.3.26 hang fix).
    val browseTop =
        stack.lastOrNull { it !is PlavioDestination.Play } ?: PlavioDestination.Home
    // The capsule's selection: the nearest root destination at or
    // below the stack top (Detail/Streams opened from Library keep
    // Library lit, and so on).
    val selectedRoot =
        stack.lastOrNull { it.isRoot() } ?: PlavioDestination.Home
    // The last Play destination, kept so the player stays composed (and
    // keeps playing) through its fade-out when playback closes and the
    // stack top has already moved on to the streams screen.
    var lastPlay by remember { mutableStateOf<PlavioDestination.Play?>(null) }
    LaunchedEffect(top) {
        if (top is PlavioDestination.Play) lastPlay = top
    }
    val reducedMotion = com.github.damontecres.wholphin.plavio.rememberReducedMotion()
    val isPlaying = top is PlavioDestination.Play
    // Door three of the capsule exit (v0.3.15): Back while focus
    // sits in the capsule is a RETURN TO CONTENT, nothing else — it
    // must not pop the stack, must not fall through to the
    // Back-at-root-opens-capsule handler (disabled in this state
    // anyway), and must never exit the app out from under a user
    // who was only trying to leave the rail. Registered after the
    // two handlers above, so while enabled it is the one Back
    // consults first; while the capsule does not hold focus (or
    // the player owns the screen) it stands down completely.
    // v0.3.16 (note 12): the door now requires a page UNDER the
    // current one (stack.size > 1). At a root destination it used
    // to bounce Back into the content, the root handler then sent
    // the next Back into the capsule, and so on forever — Back at
    // the top level never exited and read as "not listened to,
    // needs many presses". At root with the capsule focused, Back
    // now falls through every handler to the system: the app exits,
    // the reference behaviour for an open panel at the top level.
    // Pushed pages (Detail, Streams…) keep the door exactly as
    // 0.3.15 built it.
    BackHandler(enabled = capsuleHasFocus && !isPlaying && stack.size > 1) {
        exitCapsuleToContent()
    }
    // Adaptive safe margins (owner's rule 2026-11-04: "should never
    // crop in small tv and in big screens — should be adaptive").
    // The edge insets are a PERCENTAGE of this TV's own screen, with
    // the hand-tuned values as the floor: a TV that crops its edges
    // (overscan) or a very large screen automatically gets more
    // room, a clean small screen keeps the designed look. Nothing
    // important ever sits in the crop zone, on any TV.
    val screenConfig = androidx.compose.ui.platform.LocalConfiguration.current
    val capsuleInset = maxOf(28.dp, screenConfig.screenWidthDp.dp * 0.03f)
    val browseBottomPad = maxOf(16.dp, screenConfig.screenHeightDp.dp * 0.03f)
    // Floating chrome, exact clearance (v0.3.12, owner's orders):
    // the side capsule and the top-left brand lockup are overlays —
    // the layout tree reserves no column for either — but NO card,
    // text or button may ever slide under the capsule's strip, and
    // the owner's verdict on both earlier builds was that the gap
    // left for it was too much. The browse start pad is therefore
    // EXACTLY the capsule's right edge + a 12dp breathing gap:
    // capsuleInset (its left offset) + 42dp (its slimmed width) +
    // 12dp. Since every card's left edge sits at or right of this
    // line and the capsule never extends past it, a card can never
    // intersect the capsule at any scroll position — and there is
    // no dead band either. The screens' own left insets were
    // normalised to zero where they merely repeated this margin
    // (their right insets stay), so the visible gap beside the
    // capsule really is ~12dp on every screen. Backdrop imagery
    // may still run full-bleed under the floating glass (the
    // Detail hero) — picture under glass is intended; cards, text
    // and buttons are what the clearance protects. The logo keeps
    // its exact spot, size and look, floating over the artwork;
    // text stays out from under it by sitting below its band (the
    // screens' top offsets) or right of it (hero text).
    // Focus hand-back (v0.3.10): no ROOT focus requester/restorer and
    // no rail focus groups (both stay removed — the focusGroup
    // experiment was the scroll-freeze suspect). But the v0.3.26
    // claim below that "focus survives the player on its own" proved
    // wrong on the owner's TV: the player's focused node leaves with
    // it and the landing screen holds nothing (his "scroll got
    // stuck" after Back). The hand-back lives in the browse screens:
    // they watch LocalPlavioPlayerActive and re-request their own
    // first focus target on the playing→stopped flip.
    // v0.3.26 (the owner's hang fix): the browse tree is NEVER thrown
    // away while the player runs — it stays composed underneath and
    // the player layers over it. The old swap disposed the whole
    // browse tree at Play and rebuilt it at Back; on a weak TV that
    // rebuild, landing in the same moment as the player's teardown,
    // was the "closing sticks / everything heavy after playing"
    // hang. Player open/close stays a HARD CUT (v0.3.5 fix) — no
    // alpha-animating layer ever wraps the player (the v0.3.3
    // crossfade put the SurfaceView under a fading layer and it
    // never composited: sound, black picture). Layering static
    // browse UNDER an opaque, non-animated player breaks neither
    // rule: the surface is born in the top layer at full alpha.
    CompositionLocalProvider(
        LocalPlavioLightLook provides lightLook,
        LocalPlavioPlayerActive provides isPlaying,
        LocalPlavioContentEntry provides contentEntry,
    ) {
    Box(modifier = modifier.fillMaxSize()) {
        if (isPlaying) {
            // Playback owns the whole screen — no capsule, no brand.
            val playDest = (top as? PlavioDestination.Play) ?: lastPlay
            if (playDest != null) {
                PlavioPlayerScreen(
                    request = playDest.request,
                    resumePositionMs = playDest.resumePositionMs,
                    onResumeFailed = {
                        stack[stack.lastIndex] =
                            PlavioDestination.Streams(streamsRefFor(playDest.request))
                    },
                    onPlayNextEpisode = { next ->
                        stack[stack.lastIndex] = PlavioDestination.Play(next)
                    },
                    onZapChannel = { channel ->
                        rootViewModel.zapToChannel(channel, playDest.request.liveChannels) { resolved ->
                            stack[stack.lastIndex] = PlavioDestination.Play(resolved)
                        }
                    },
                    modifier = Modifier.fillMaxSize().zIndex(2f),
                )
            } else {
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .zIndex(2f)
                            .background(Color.Black),
                )
            }
        }
        Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
            ) {
                // Browse content: starts exactly at the capsule's
                // right edge + 12dp (see the geometry note at
                // capsuleInset above) — no card, text or button can
                // ever slide under the capsule strip, and no dead
                // band is left either.
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .padding(start = capsuleInset + 54.dp, bottom = browseBottomPad)
                            // The edge door (v0.3.14): a Left key that
                            // reaches this box unconsumed first tries
                            // an ordinary geometric move; only when
                            // NOTHING focusable sits further left does
                            // the door fire and send focus to the
                            // capsule button of the current section —
                            // deterministically, via its requester.
                            // Keys the focused control consumed itself
                            // (sliders, seek bars) never arrive here,
                            // and no focusGroup/focusRestorer is
                            // involved (the 2026-11-04 ban stands).
                            .onKeyEvent { event ->
                                if (event.type == KeyEventType.KeyDown &&
                                    event.key == Key.DirectionLeft
                                ) {
                                    if (focusManager.moveFocus(FocusDirection.Left)) {
                                        true
                                    } else {
                                        capsuleRequesters[selectedRoot]?.let { requester ->
                                            runCatching { requester.requestFocus() }
                                        }
                                        true
                                    }
                                } else {
                                    false
                                }
                            }
                            // NO focusGroup / focusRestorer here, and
                            // none on the capsule either (removed
                            // 2026-11-04): the groups added in v0.3.25
                            // to "help" rail crossing are what stopped
                            // the remote reaching the side rail at all
                            // on the owner's TV. Plain geometry — the
                            // v0.3.24 behaviour — is what worked there.
                ) {
                    AnimatedContent(
                        targetState = browseTop,
                        transitionSpec = {
                            if (reducedMotion) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else {
                                fadeIn(
                                    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                                ) togetherWith
                                    fadeOut(
                                        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                                    )
                            }
                        },
                        label = "destination",
                        modifier = Modifier.fillMaxSize(),
                    ) { dest ->
                        when (dest) {
                            PlavioDestination.Home -> {
                                PlavioHomeScreen(
                                    onManageAddons = { goRoot(PlavioDestination.Addons) },
                                    onItemClick = { row, item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = row.baseUrl,
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    onContinueWatchingClick = { entry ->
                                        push(
                                            PlavioDestination.Play(
                                                request = entry.toPlaybackRequest(),
                                                resumePositionMs = entry.positionMs,
                                            ),
                                        )
                                    },
                                    onPlayRequest = { request ->
                                        push(PlavioDestination.Play(request))
                                    },
                                    onEpisodeAlertClick = { alert ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = alert.baseUrl,
                                                type = "series",
                                                id = alert.metaId,
                                                previewName = alert.showName,
                                                previewPoster = alert.poster,
                                            ),
                                        )
                                    },
                                    focusMemory = homeFocusMemory,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Search -> {
                                PlavioSearchScreen(
                                    onItemClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = item.baseUrl,
                                                type = item.meta.type,
                                                id = item.meta.id,
                                                previewName = item.meta.name,
                                                previewPoster = item.meta.poster,
                                                previewBackground = item.meta.background,
                                            ),
                                        )
                                    },
                                    onPersonClick = { member ->
                                        push(
                                            PlavioDestination.Actor(
                                                personId = member.id,
                                                name = member.name,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Live -> {
                                PlavioLiveScreen(
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Library -> {
                                PlavioLibraryScreen(
                                    onItemClick = { type, metaId, name, poster, background ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = "",
                                                type = type,
                                                id = metaId,
                                                previewName = name,
                                                previewPoster = poster,
                                                previewBackground = background,
                                            ),
                                        )
                                    },
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    onOpenDownloads = { goRoot(PlavioDestination.Downloads) },
                                    onConnectServices = { goRoot(PlavioDestination.Account) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Addons -> {
                                PlavioSetupScreen(modifier = Modifier.fillMaxSize())
                            }

                            PlavioDestination.Downloads -> {
                                PlavioDownloadsScreen(
                                    onPlay = { request -> push(PlavioDestination.Play(request)) },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Settings -> {
                                PlavioSettingsScreen(
                                    onOpenAddons = { goRoot(PlavioDestination.Addons) },
                                    onOpenAccount = { goRoot(PlavioDestination.Account) },
                                    startPage = settingsStartPage,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            PlavioDestination.Account -> {
                                PlavioAccountScreen(
                                    onOpenIntegrations = {
                                        settingsStartPage = "integrations"
                                        goRoot(PlavioDestination.Settings)
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Actor -> {
                                PlavioActorScreen(
                                    destination = dest,
                                    onItemClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = "",
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Detail -> {
                                val detailKey = "${dest.baseUrl}|${dest.type}|${dest.id}"
                                PlavioDetailScreen(
                                    destination = dest,
                                    restoreRecord = detailRestores[detailKey],
                                    onArmRestore = { record ->
                                        if (record == null) {
                                            detailRestores.remove(detailKey)
                                        } else {
                                            detailRestores[detailKey] = record
                                        }
                                    },
                                    onWatchNow = { request ->
                                        push(PlavioDestination.Play(request))
                                    },
                                    onWatchMovie = { meta ->
                                        push(
                                            PlavioDestination.Streams(
                                                StreamsRef(
                                                    type = meta.type,
                                                    videoId = meta.id,
                                                    metaId = meta.id,
                                                    title = meta.name,
                                                    poster = meta.poster,
                                                    backdrop = meta.background,
                                                ),
                                            ),
                                        )
                                    },
                                    onEpisodeClick = { meta, video ->
                                        push(
                                            PlavioDestination.Streams(
                                                StreamsRef(
                                                    type = meta.type,
                                                    videoId = video.id,
                                                    metaId = meta.id,
                                                    title = meta.name,
                                                    poster = video.thumbnail ?: meta.poster,
                                                    backdrop = meta.background,
                                                    season = video.season,
                                                    episode = video.episode,
                                                    episodeTitle = video.title,
                                                    seriesName = meta.name,
                                                ),
                                            ),
                                        )
                                    },
                                    onActorClick = { member ->
                                        push(
                                            PlavioDestination.Actor(
                                                personId = member.id,
                                                name = member.name,
                                            ),
                                        )
                                    },
                                    onRelatedClick = { item ->
                                        push(
                                            PlavioDestination.Detail(
                                                baseUrl = dest.baseUrl,
                                                type = item.type,
                                                id = item.id,
                                                previewName = item.name,
                                                previewPoster = item.poster,
                                                previewBackground = item.background,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Streams -> {
                                PlavioStreamsScreen(
                                    ref = dest.ref,
                                    // The panel's saved resume position
                                    // rides into the Play destination —
                                    // the player's existing resume
                                    // prompt/start path consumes it.
                                    onPlay = { request, resumeMs ->
                                        push(
                                            PlavioDestination.Play(
                                                request = request,
                                                resumePositionMs = resumeMs,
                                            ),
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }

                            is PlavioDestination.Play -> {
                                // Handled above (full-screen).
                            }
                        }
                    }
                }
                // The floating capsule, vertically centred at the
                // left, drawn OVER the content (v0.3.12 — it
                // reserves no width; content runs beneath it). Its
                // inset is the adaptive safe margin (see
                // capsuleInset above) — at the old fixed 14dp the
                // TV's edge crop glued it to the corner and it
                // stopped reading as floating (owner photo
                // 2026-11-04).
                PlavioCapsule(
                    selected = selectedRoot,
                    onSelect = { dest ->
                        settingsStartPage = "main"
                        if (dest == selectedRoot && browseTop == dest) {
                            // Same-section click while already there:
                            // NOT a navigation — the scaffold must not
                            // rebuild the screen. It is door two of
                            // the capsule exit (v0.3.15): focus goes
                            // back into the content through the hard
                            // exit (the screen's landing, verified,
                            // with the geometric rescue behind it).
                            exitCapsuleToContent()
                        } else {
                            // A different destination owns its own
                            // landing — the scaffold never competes
                            // with the new screen's entry focus.
                            goRoot(dest)
                        }
                    },
                    requesters = capsuleRequesters,
                    onFocusWithin = { capsuleHasFocus = it },
                    onReturnToContent = { exitCapsuleToContent() },
                    modifier =
                        Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = capsuleInset),
                )
                // Brand (v0.3.20, the owner's locked logo rule —
                // "C size, D rule, plain"; final sample
                // final-DC.png): the FULL lockup lives on Home
                // ONLY; every other page carries the plain Weave
                // icon alone — no name, no disc, no background —
                // at 36dp. Both forms float (no space reserved,
                // nothing focusable), sit near the left edge with
                // just a little gap (NOT the old deep adaptive
                // inset), and are centred on the capsule's centre
                // line (PlavioChrome.centreLine): ONE straight
                // vertical line, logo centre → capsule centre.
                // The top gap keeps the same adaptive floor as
                // before so the art always shows whole, never
                // clipped, on the owner's TV.
                BrandBlock(
                    full = browseTop == PlavioDestination.Home,
                    modifier =
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(
                                top = maxOf(14.dp, screenConfig.screenHeightDp.dp * 0.022f),
                            ),
                )
                // The version line (v0.3.16, note 3 — owner's
                // order, reversing the 0.3.15 in-pill placement):
                // OUT of the capsule, at the screen's BOTTOM-LEFT
                // corner, SUBTLE weight (his pick): quiet ~13sp
                // type at 60% white, on the same adaptive safe
                // margins as everything else at the edges. ONLY
                // the short form (owner's standing rule): capital
                // V + the version number, no app name, never the
                // word "Version", no build code — read from the
                // build itself, so it stays true on every future
                // build. Plain text, not focusable.
                Text(
                    text = "V${BuildConfig.VERSION_NAME}",
                    style =
                        MaterialTheme.typography.bodySmall.copy(
                            fontSize = 13.sp,
                        ),
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 1,
                    softWrap = false,
                    modifier =
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(
                                start = capsuleInset,
                                bottom = maxOf(12.dp, screenConfig.screenHeightDp.dp * 0.02f),
                            ),
                )
            }
        }
    }
}

/**
 * The brand (v0.3.20, the owner's locked logo rule): [full] = the
 * complete lockup — Weave mark + the locked signature wordmark +
 * "TV" (the letters are the master PNG, never redrawn as a font) —
 * shown on HOME only. Everywhere else the PLAIN Weave icon alone at
 * 36dp: no name, no glass disc, no background (the owner's pick over
 * sample C's disc — "C size, D rule, plain").
 *
 * Placement (both forms): near the left edge with just a little gap,
 * and the Weave mark's centre exactly on the side capsule's centre
 * line ([PlavioChrome.centreLine]) — one straight vertical line from
 * the mark's centre down through the capsule's centre. The full
 * lockup is positioned by its MARK (it starts near the edge and the
 * mark sits 18dp inside the block, so the start padding compensates
 * exactly).
 *
 * Ground (v0.3.22, the owner's pick A — sample
 * home-logo-A-transparent.png, locked 2026-11-07): the Home lockup
 * floats DIRECTLY on the picture — no black ground, no glass panel,
 * nothing behind the mark or the name. The ground it carried from
 * v0.3.17 to v0.3.21 (a black 0.88-alpha rounded block, kept so a
 * bright hero could not wash out the pale wordmark and overscan
 * would bite black padding, never letters) is REMOVED on his word.
 * The 18dp/12dp padding that used to inset the mark inside the
 * ground stays — now invisible breathing room — so the mark does
 * not move a single dp from its locked position.
 */
@Composable
private fun BrandBlock(
    full: Boolean,
    modifier: Modifier = Modifier,
) {
    if (!full) {
        Image(
            painter = painterResource(R.drawable.plavio_mark),
            contentDescription = null,
            modifier =
                modifier
                    .padding(start = PlavioChrome.startPadFor(PlavioChrome.iconSize))
                    .size(PlavioChrome.iconSize),
        )
        return
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier =
            modifier
                .padding(
                    start =
                        maxOf(
                            0.dp,
                            PlavioChrome.startPadFor(40.dp) - 18.dp,
                        ),
                )
                // v0.3.22: NO background here — the lockup floats
                // on the picture (owner's pick A; see above). The
                // padding stays so the mark keeps its position.
                .padding(horizontal = 18.dp, vertical = 12.dp),
    ) {
        Image(
            painter = painterResource(R.drawable.plavio_mark),
            contentDescription = null,
            modifier = Modifier.size(40.dp),
        )
        Image(
            painter = painterResource(R.drawable.plavio_wordmark_signature),
            contentDescription = null,
            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
            modifier =
                Modifier
                    .height(36.dp)
                    .aspectRatio(952f / 181f),
        )
        Text(
            text = "TV",
            style = MaterialTheme.typography.titleMedium,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            softWrap = false,
        )
    }
}

/**
 * The floating glass capsule (v0.3.21, the owner's approved chrome):
 * a vertical glass pill floating over the content — exactly five
 * icon-only buttons in the mobile dock's icons (Home, Search, Live
 * TV, Library, Settings), and the user's profile picture below a
 * divider (opens Account). The pill is STATIC (v0.3.15, owner's
 * order): the slim icon strip at all times — no fold/unfold, no
 * labels on focus, no size animation anywhere near the focus
 * path (the v0.3.14 unfold experiment is cancelled; the owner
 * feared the animation could stick). NO brand
 * lockup — the floating top-left block is the screen's only
 * logo — and, since v0.3.16 (note 3), NO version line either: the
 * version sits at the screen's bottom-left corner. Focus = the
 * travelling white fill (v0.3.16, note 2, Sample A "Slide"): a
 * white disc GLIDES inside the pill to the focused button; the
 * selected section carries no fill of its own — focus lives in
 * exactly one place at a time. Slimmed in v0.3.12 (owner's order): the
 * rail is 42dp wide in total — 32dp buttons + 2×5dp padding —
 * down from 64dp (48dp buttons + 2×8dp padding), ≈35% narrower;
 * it reserves no layout width either way.
 */
@Composable
private fun PlavioCapsule(
    selected: PlavioDestination,
    onSelect: (PlavioDestination) -> Unit,
    requesters: Map<PlavioDestination, FocusRequester>,
    onFocusWithin: (Boolean) -> Unit,
    onReturnToContent: () -> Unit,
    modifier: Modifier = Modifier,
    accountsViewModel: PlavioAccountsViewModel = hiltViewModel(),
    profileViewModel: PlavioProfileViewModel = hiltViewModel(),
) {
    val accountState by accountsViewModel.state.collectAsState()
    val photoBase64 by profileViewModel.profilePhotoBase64.collectAsState()
    val photoBitmap =
        remember(photoBase64) {
            photoBase64?.let { encoded ->
                runCatching {
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }.getOrNull()
            }
        }
    val email = accountState.plavioEmail ?: accountState.googleEmail
    // STATIC strip (v0.3.15, owner's order cancelling the
    // v0.3.14 unfold): the pill never changes size or content with
    // focus — no fold/unfold state, no labels appearing, no
    // animateContentSize. The container's onFocusChanged only
    // REPORTS focus entry/exit to the root (which arms the
    // capsule's Back door and the content's Left door).
    // The capsule carries NO brand lockup (v0.3.15, owner's order):
    // 0.3.14 showed the full lockup here AND the floating top-left
    // brand block at the same time — two logos on one screen.
    //
    // Travelling white (v0.3.16, note 2 — Sample A "Slide", the
    // owner's pick): a white disc GLIDES inside the pill to the
    // button that holds focus, eased; every button rests ghost and
    // the current section carries no fill of its own. Each button
    // reports its focus + its Y inside the pill through [glideTrack];
    // the disc is drawn behind the buttons and animates between the
    // reported positions. When focus leaves the rail the disc fades
    // out entirely — the white is never left standing on the last
    // button (the owner's report: "side buttons when i press it
    // stay white there, i need same like before, moving").
    var glideDest by remember { mutableStateOf<PlavioDestination?>(null) }
    val glideOffsets = remember { mutableMapOf<PlavioDestination, Float>() }
    val glideDensity = androidx.compose.ui.platform.LocalDensity.current
    val glideTargetY =
        with(glideDensity) { (glideDest?.let { glideOffsets[it] } ?: 0f).toDp() }
    val glideY by
        androidx.compose.animation.core.animateDpAsState(
            targetValue = glideTargetY,
            animationSpec =
                androidx.compose.animation.core.tween(
                    durationMillis = 240,
                    easing = FastOutSlowInEasing,
                ),
            label = "capsuleGlideY",
        )
    val glideAlpha by
        androidx.compose.animation.core.animateFloatAsState(
            targetValue = if (glideDest != null) 1f else 0f,
            animationSpec = androidx.compose.animation.core.tween(durationMillis = 160),
            label = "capsuleGlideAlpha",
        )
    fun glideTrack(dest: PlavioDestination): Modifier =
        Modifier
            .onGloballyPositioned { coords ->
                glideOffsets[dest] = coords.positionInParent().y
            }.onFocusChanged { if (it.isFocused) glideDest = dest }
    Column(
        modifier =
            modifier
                .onFocusChanged { state ->
                    onFocusWithin(state.hasFocus)
                    if (!state.hasFocus) glideDest = null
                }
                // Door one of the capsule exit (v0.3.15): Right from
                // any capsule item is the trip back into the page,
                // through the root's hard exit (the screen's own
                // landing, verified frame by frame, with a geometric
                // rescue that cannot be registered away). A PREVIEW
                // handler, so the door sees the key in the capture
                // phase — before the focused button or anything
                // under it can consume it — and the key is consumed
                // ALWAYS: Right inside the rail has no other sane
                // destination, and letting an unverified transfer
                // decide consumption was the v0.3.14 trap (the
                // transfer "succeeded", the key died, geometry
                // never ran).
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        event.key == Key.DirectionRight
                    ) {
                        onReturnToContent()
                        true
                    } else {
                        false
                    }
                },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(
            modifier =
                Modifier
                    .shadow(
                        // Light look: no shadow pass under the rail.
                        // 18dp (was 14): a clearer lift so the capsule
                        // reads as floating, not fixed to the edge.
                        elevation = if (LocalPlavioLightLook.current) 0.dp else 18.dp,
                        shape = RoundedCornerShape(50),
                        ambientColor = Color.Black,
                        spotColor = Color.Black,
                    )
                    .clip(RoundedCornerShape(50))
                    .background(
                        // Light look: the rail fill goes solid — no
                        // translucency to blend over moving rows.
                        if (LocalPlavioLightLook.current) {
                            PlavioOnyx.RailSolid
                        } else {
                            PlavioOnyx.RailGlass
                        },
                    )
                    .border(
                        1.dp,
                        PlavioOnyx.GlassBorder,
                        RoundedCornerShape(50),
                    )
                    // Width (v0.3.12, owner's order — "shrink it
                    // 35 percent"): the rail was 64dp wide in total
                    // (48dp buttons + 2×8dp padding); it is 42dp
                    // now (32dp buttons + 2×5dp padding) — the
                    // buttons shrink with it, icons and the profile
                    // photo scaled inside, focus rings unchanged
                    // (they draw inside the button bounds). That
                    // 42dp is the pill's width at ALL times
                    // (v0.3.15: the unfold is cancelled, so the pill
                    // can never reach toward the hero buttons the
                    // way the v0.3.14 unfolded pill did).
                    .padding(horizontal = 5.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box {
                // The travelling white disc (v0.3.16, note 2):
                // drawn behind the buttons, its Y animated to the
                // focused button's Y inside this box (the buttons'
                // own positions are reported in the same coordinate
                // space — the inner column below shares this box's
                // origin). Alpha 0 whenever focus is outside the
                // rail.
                Box(
                    modifier =
                        Modifier
                            .offset(y = glideY)
                            .size(32.dp)
                            .alpha(glideAlpha)
                            .background(Color.White, CircleShape),
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
            CapsuleButton(
                icon = Icons.Filled.Home,
                selected = selected == PlavioDestination.Home,
                onClick = { onSelect(PlavioDestination.Home) },
                focusRequester = requesters[PlavioDestination.Home],
                glideModifier = glideTrack(PlavioDestination.Home),
            )
            CapsuleButton(
                icon = Icons.Filled.Search,
                selected = selected == PlavioDestination.Search,
                onClick = { onSelect(PlavioDestination.Search) },
                focusRequester = requesters[PlavioDestination.Search],
                glideModifier = glideTrack(PlavioDestination.Search),
            )
            CapsuleButton(
                icon = PlavioIcons.LiveTv,
                selected = selected == PlavioDestination.Live,
                onClick = { onSelect(PlavioDestination.Live) },
                focusRequester = requesters[PlavioDestination.Live],
                glideModifier = glideTrack(PlavioDestination.Live),
            )
            CapsuleButton(
                icon = PlavioIcons.MenuBook,
                selected = selected == PlavioDestination.Library,
                onClick = { onSelect(PlavioDestination.Library) },
                focusRequester = requesters[PlavioDestination.Library],
                glideModifier = glideTrack(PlavioDestination.Library),
            )
            CapsuleButton(
                icon = Icons.Filled.Settings,
                selected = selected == PlavioDestination.Settings,
                onClick = { onSelect(PlavioDestination.Settings) },
                focusRequester = requesters[PlavioDestination.Settings],
                glideModifier = glideTrack(PlavioDestination.Settings),
            )
            // Divider above the profile picture.
            Box(
                modifier =
                    Modifier
                        .width(22.dp)
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.18f)),
            )
            CapsuleProfileButton(
                photoBitmap = photoBitmap,
                initial = email?.firstOrNull()?.uppercase(),
                selected = selected == PlavioDestination.Account,
                onClick = { onSelect(PlavioDestination.Account) },
                focusRequester = requesters[PlavioDestination.Account],
                glideModifier = glideTrack(PlavioDestination.Account),
            )
            // v0.3.16 (note 3): the version line is OUT of the
            // pill again — the capsule carries no version at all.
            // It lives at the screen's bottom-left corner now (see
            // the root overlay), in the owner's picked SUBTLE form.
                }
            }
        }
    }
}

@Composable
private fun CapsuleButton(
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    glideModifier: Modifier = Modifier,
) {
    // Icon-only at all times (v0.3.15: the unfold is cancelled —
    // no labels ever render in the rail).
    // v0.3.16 (note 2, Sample A): the button itself NEVER fills —
    // it rests ghost (muted glyph on transparency) whether it is
    // the current section or not. Focus is drawn by the capsule's
    // travelling white disc BEHIND the buttons (see PlavioCapsule);
    // the focused button only flips its glyph to ink so it reads
    // dark on the white disc. No ring, no accent fill: the white
    // lives in exactly one place at a time.
    val ghost = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = Color(0xFF131320)
    Surface(
        onClick = onClick,
        modifier =
            Modifier
                .size(32.dp)
                .then(glideModifier)
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                ),
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = ghost,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = ink,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = ink,
            ),
    ) {
        // Centering: the frame is fixed (32dp since the v0.3.12
        // slimming) — the content box fills it outright and centres
        // the glyph in the frame.
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(19.dp),
            )
        }
    }
}

/** The capsule's bottom stop: the user's profile picture (or the
 * account initial / person glyph), opening the Account screen. */
@Composable
private fun CapsuleProfileButton(
    photoBitmap: android.graphics.Bitmap?,
    initial: String?,
    selected: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    glideModifier: Modifier = Modifier,
) {
    val accent = LocalPlavioAccent.current
    // Icon-only at all times, like CapsuleButton (v0.3.15: the
    // unfold is cancelled). v0.3.16 (note 2): same travelling-white
    // treatment — the button never fills; the capsule's white disc
    // glides behind it on focus (reading as a white ring around the
    // 24dp photo/initial), and the fallback glyph flips to ink.
    val ghost = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = Color(0xFF131320)
    Surface(
        onClick = onClick,
        modifier =
            Modifier
                .size(32.dp)
                .then(glideModifier)
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                ),
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = ghost,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = ink,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = ink,
            ),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            if (photoBitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = photoBitmap.asImageBitmap(),
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier =
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape),
                )
            } else if (initial != null) {
                Box(
                    modifier =
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(accent.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = initial,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = accent.onAccent(),
                    )
                }
            } else {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    modifier = Modifier.size(19.dp),
                )
            }
        }
    }
}
