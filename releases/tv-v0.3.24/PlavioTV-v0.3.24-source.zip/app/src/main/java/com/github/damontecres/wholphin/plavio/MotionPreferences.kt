package com.github.damontecres.wholphin.plavio

import android.animation.ValueAnimator
import android.content.Context
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object MotionPreferences {
    private val mutableReduced = MutableStateFlow(false)
    val reduced: StateFlow<Boolean> = mutableReduced
    fun initialize(context: Context) {
        mutableReduced.value = context.getSharedPreferences("plavio_accessibility", Context.MODE_PRIVATE)
            .getBoolean("reduced_motion", false)
    }
    fun setReduced(context: Context, value: Boolean) {
        check(context.getSharedPreferences("plavio_accessibility", Context.MODE_PRIVATE).edit()
            .putBoolean("reduced_motion", value).commit()) { "Couldn't save accessibility choice" }
        mutableReduced.value = value
    }

    /**
     * The system's animator-scale answer, guarded for old Android
     * (Sentry PLAVIO-G): `ValueAnimator.areAnimatorsEnabled()` only
     * exists on API 26+, and the TV app's minSdk is 23 — on API 23–25
     * the direct call threw NoSuchMethodError during composition in
     * MainActivity (15 events by v0.3.10, TV 0.3.1→0.3.9).
     * Before API 26 there is no system animator-scale setting to
     * honour, so animations count as enabled there. The call itself
     * is ALSO wrapped (v0.3.10): some vendor firmware strips or
     * mis-links framework methods its SDK level claims to have, and
     * a stripped areAnimatorsEnabled on API 26+ would throw the same
     * NoSuchMethodError straight past the SDK check. runCatching
     * treats any such failure as "enabled" — the identical answer a
     * healthy device with animations on gives — while devices that
     * have the method get its real answer, unchanged.
     */
    fun systemAnimatorsEnabled(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            runCatching { ValueAnimator.areAnimatorsEnabled() }
                .getOrDefault(true)

    fun animationsEnabled(): Boolean = !reduced.value && systemAnimatorsEnabled()
}

@Composable
fun rememberReducedMotion(): Boolean {
    val reduced by MotionPreferences.reduced.collectAsState()
    return reduced || !MotionPreferences.systemAnimatorsEnabled()
}
