package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.MetaDetail
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.RelatedSection
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import com.github.damontecres.wholphin.plavio.pickBestStream
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioDetailUiState {
    data object Loading : PlavioDetailUiState

    data class Loaded(
        val meta: MetaDetail,
        val related: List<RelatedSection> = emptyList(),
    ) : PlavioDetailUiState

    data object Unavailable : PlavioDetailUiState
}

/**
 * Watch Now outcome (v0.3.16, note 9 — Instant Play): a press is
 * Ready IMMEDIATELY with an unresolved request; the player finds the
 * streams inside itself and falls back to the sources picker when
 * nothing playable answers. The old Resolving ("Finding…" button)
 * and NoStreams states are gone — the press never waits here.
 */
sealed interface WatchNowState {
    data object Idle : WatchNowState

    data class Ready(
        val request: PlaybackRequest,
    ) : WatchNowState
}

/**
 * The Detail page's in-place Sources popup (v0.3.22): closed, or
 * open over the page with the target's streams filling in
 * progressively (the same bundle the Streams screen would show).
 */
sealed interface DetailSourcesState {
    data object Closed : DetailSourcesState

    data class Open(
        val ref: StreamsRef,
        val streams: List<com.github.damontecres.wholphin.plavio.StreamItem>,
        /** True while more addons are still answering. */
        val loading: Boolean,
    ) : DetailSourcesState
}

@HiltViewModel
class PlavioDetailViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
        private val uiPrefs: PlavioUiPrefs,
        private val watchlistStore: com.github.damontecres.wholphin.plavio.PlavioWatchlistStore,
        private val progressStore: com.github.damontecres.wholphin.plavio.PlavioProgressStore,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioDetailUiState>(PlavioDetailUiState.Loading)
        val state: StateFlow<PlavioDetailUiState> = _state

        /** + My List membership keys (the store's own flow). */
        val myListKeys: StateFlow<Set<String>> = watchlistStore.keys

        /** Episode watch progress for the open title: videoId → fraction (v0.3.21). */
        private val _episodeProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
        val episodeProgress: StateFlow<Map<String, Float>> = _episodeProgress

        fun toggleMyList(meta: MetaDetail) {
            viewModelScope.launch {
                watchlistStore.toggle(
                    com.github.damontecres.wholphin.plavio.WatchlistEntry(
                        type = meta.type,
                        metaId = meta.id,
                        name = meta.name,
                        poster = meta.poster,
                    ),
                )
            }
        }

        private val _watchNow = MutableStateFlow<WatchNowState>(WatchNowState.Idle)
        val watchNow: StateFlow<WatchNowState> = _watchNow

        private val _sources = MutableStateFlow<DetailSourcesState>(DetailSourcesState.Closed)
        val sources: StateFlow<DetailSourcesState> = _sources

        /** The full bundle behind the open Sources popup (a pick
         * builds its PlaybackRequest from it, like Watch Now does). */
        private var sourcesBundle: com.github.damontecres.wholphin.plavio.StreamBundle? = null
        private var sourcesJob: kotlinx.coroutines.Job? = null

        /** True when Watch Now should auto-play the best stream (phone parity setting). */
        val autoplayBestStream: StateFlow<Boolean> = uiPrefs.autoplayBestStream

        private var loadedKey: String? = null

        fun load(
            baseUrl: String,
            type: String,
            id: String,
        ) {
            val key = "$baseUrl|$type|$id"
            if (key == loadedKey) return
            loadedKey = key
            viewModelScope.launch {
                _state.value = PlavioDetailUiState.Loading
                val meta = repository.loadMeta(baseUrl, type, id)
                if (meta == null) {
                    _state.value = PlavioDetailUiState.Unavailable
                    return@launch
                }
                // v0.3.16 (note 8, owner's explicit order): the page
                // reveals WHOLE. Related rows are fetched BEFORE the
                // first Loaded emission, so the skeleton layer stays
                // up until the page is complete and the finished page
                // appears at once — the targeted waiver of progressive
                // loading for this surface. (Cast photos still enrich
                // in place afterwards: they are images inside cards
                // that already stand, not page structure.)
                val related =
                    runCatching { repository.getRelated(meta.type, meta.id, baseUrl) }
                        .getOrDefault(emptyList())
                _state.value = PlavioDetailUiState.Loaded(meta, related)
                _episodeProgress.value =
                    progressStore.entries.value
                        .filter { it.metaId == meta.id }
                        .associate { it.videoId to it.progressFraction }
                enrichCastPhotos(meta)
            }
        }

        /** The streams reference for a title (series target = the given episode). */
        private fun streamsRefFor(
            meta: MetaDetail,
            target: Video?,
        ): StreamsRef =
            if (meta.type == "series" && target != null) {
                StreamsRef(
                    type = meta.type,
                    videoId = target.id,
                    metaId = meta.id,
                    title = meta.name,
                    poster = target.thumbnail ?: meta.poster,
                    backdrop = meta.background,
                    season = target.season,
                    episode = target.episode,
                    episodeTitle = target.title,
                    seriesName = meta.name,
                )
            } else {
                StreamsRef(
                    type = meta.type,
                    videoId = meta.id,
                    metaId = meta.id,
                    title = meta.name,
                    poster = meta.poster,
                    backdrop = meta.background,
                )
            }

        /**
         * Watch Now (v0.3.16, note 9 — Instant Play): NO resolution
         * here. The press builds the unresolved request from the
         * already-loaded meta and is Ready on the same frame, so the
         * player opens at once and finds the streams inside itself
         * (the behaviour the owner asked back: "keep loading there
         * as you before doing"). For a series the target is the
         * episode asked for. When the player finds nothing playable
         * it swaps itself for the sources picker — the old NoStreams
         * fallback, one room over.
         */
        fun watchNow(
            meta: MetaDetail,
            target: Video?,
        ) {
            val ref = streamsRefFor(meta, target)
            _watchNow.value =
                WatchNowState.Ready(
                    com.github.damontecres.wholphin.plavio.buildPendingPlaybackRequest(
                        ref,
                        meta.videos,
                    ),
                )
        }

        fun consumeWatchNow() {
            _watchNow.value = WatchNowState.Idle
        }

        /**
         * Sources popup (v0.3.22): opens over the Detail page with
         * the same target Watch Now uses (the movie itself, or the
         * first episode for a series). Streams fill progressively —
         * each addon's answer renders as it lands.
         */
        fun openSources(
            meta: MetaDetail,
            target: Video?,
        ) {
            val ref = streamsRefFor(meta, target)
            sourcesJob?.cancel()
            sourcesBundle = null
            _sources.value = DetailSourcesState.Open(ref, emptyList(), loading = true)
            sourcesJob =
                viewModelScope.launch {
                    val bundle =
                        runCatching {
                            repository.loadStreamsProgressive(ref.type, ref.videoId, ref.metaId) { partial ->
                                val open = _sources.value
                                if (open is DetailSourcesState.Open && open.ref == ref) {
                                    _sources.value =
                                        open.copy(streams = partial.streams, loading = true)
                                }
                            }
                        }.getOrNull()
                    val open = _sources.value
                    if (open is DetailSourcesState.Open && open.ref == ref) {
                        sourcesBundle = bundle
                        _sources.value =
                            open.copy(streams = bundle?.streams ?: open.streams, loading = false)
                    }
                }
        }

        /** Reload behind the popup's empty state: same target, fresh answers. */
        fun reloadSources(
            meta: MetaDetail,
            target: Video?,
        ) = openSources(meta, target)

        fun closeSources() {
            sourcesJob?.cancel()
            sourcesJob = null
            _sources.value = DetailSourcesState.Closed
        }

        /** A popup pick: build the PlaybackRequest exactly like a
         * Streams-screen pick (full bundle rides along for failover). */
        fun pickSource(
            meta: MetaDetail,
            stream: com.github.damontecres.wholphin.plavio.StreamItem,
        ): PlaybackRequest? {
            val open = _sources.value as? DetailSourcesState.Open ?: return null
            val bundle = sourcesBundle ?: return null
            return buildPlaybackRequest(open.ref, bundle, stream, meta.videos)
        }

        /**
         * Cast photos (v0.3.13): the meta's cast arrives as names +
         * TMDB ids with no photos (PMeta serves them that way — the
         * photo lives on the addon's /person/<id> route). Resolve them
         * in parallel AFTER the page is up and swap them into the cast
         * row as they land; a member whose photo never resolves keeps
         * the initial-letter chip.
         */
        private fun enrichCastPhotos(meta: MetaDetail) {
            val missing = meta.cast.filter { it.photo.isNullOrBlank() && it.id > 0 }
            if (missing.isEmpty()) return
            viewModelScope.launch {
                val photos = mutableMapOf<Int, String>()
                coroutineScope {
                    val deferreds =
                        ArrayList<Deferred<Pair<Int, String?>>>(missing.size)
                    for (member in missing) {
                        deferreds +=
                            async {
                                member.id to
                                    runCatching { repository.fetchPersonPhoto(member.id) }.getOrNull()
                            }
                    }
                    for (deferred in deferreds) {
                        val (id, photo) = deferred.await()
                        if (photo != null) photos[id] = photo
                    }
                }
                if (photos.isEmpty()) return@launch
                val current = _state.value
                if (current is PlavioDetailUiState.Loaded && current.meta.id == meta.id) {
                    _state.value =
                        current.copy(
                            meta =
                                current.meta.copy(
                                    cast =
                                        current.meta.cast.map { member ->
                                            photos[member.id]?.let { member.copy(photo = it) }
                                                ?: member
                                        },
                                ),
                        )
                }
            }
        }
    }
