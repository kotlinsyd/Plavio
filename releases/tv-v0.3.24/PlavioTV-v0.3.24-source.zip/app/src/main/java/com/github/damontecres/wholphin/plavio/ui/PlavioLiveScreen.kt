package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CatalogRow
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import kotlinx.coroutines.launch

/**
 * Live TV tab: one row per TV catalog of every enabled addon — sports
 * categories stay separate top-level rows, never merged (the house
 * rule). Tapping a channel resolves its streams and plays the best one
 * straight away, like zapping on the phone's Live tab.
 */
@Composable
fun PlavioLiveScreen(
    onPlay: (PlaybackRequest) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioLiveViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val resolving by viewModel.resolving.collectAsState()

    LaunchedEffect(resolving) {
        resolving?.let { request ->
            viewModel.consumeResolving()
            onPlay(request)
        }
    }

    // Channel search + category filter (v0.3.21, the sample): the
    // search box sits top-right and filters channels as you type;
    // the category capsules pick one catalog row (sports rows stay
    // separate top-level rows either way — the house rule).
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<String?>(null) }
    // The channel the user last zapped into — focus returns to its
    // card after playback (see LiveRows).
    var lastPlayedKey by remember { mutableStateOf<String?>(null) }

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                // v0.3.12: the brand lockup FLOATS (no width is
                // reserved for it anywhere), but text still never
                // runs under it — this top offset keeps the heading
                // below the lockup's band, like every screen's.
                .padding(top = 72.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(end = 40.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.plavio_nav_live),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            PlavioClickToEditField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.width(320.dp),
                keyboardOptions =
                    androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
                        imeAction = androidx.compose.ui.text.input.ImeAction.Search,
                    ),
                emptyHint = stringResource(R.string.plavio_live_search_hint),
            )
        }
        when (val st = state) {
            PlavioLiveUiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        OrbitLoader(modifier = Modifier.size(64.dp))
                        Text(
                            text = stringResource(R.string.plavio_live_loading),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            PlavioLiveUiState.Empty -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(R.string.plavio_live_empty),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 48.dp),
                    )
                }
            }

            is PlavioLiveUiState.Content -> {
                val categories =
                    remember(st.rows) { st.rows.map { it.catalogName }.distinct() }
                if (categories.size > 1) {
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = PaddingValues(end = 40.dp, top = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        item(key = "live-cat-all") {
                            PlavioFilterCapsule(
                                text = stringResource(R.string.plavio_filter_any),
                                selected = category == null,
                                onClick = { category = null },
                            )
                        }
                        itemsIndexed(categories, key = { _, name -> "live-cat|$name" }) { _, name ->
                            PlavioFilterCapsule(
                                text = name,
                                selected = category == name,
                                onClick = { category = name },
                            )
                        }
                    }
                }
                val filteredRows =
                    remember(st.rows, query, category) {
                        st.rows
                            .filter { category == null || it.catalogName == category }
                            .map { row ->
                                if (query.isBlank()) {
                                    row
                                } else {
                                    row.copy(
                                        items =
                                            row.items.filter {
                                                it.name.contains(query, ignoreCase = true)
                                            },
                                    )
                                }
                            }
                            .filter { it.items.isNotEmpty() }
                    }
                if (filteredRows.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = stringResource(R.string.plavio_live_no_matches),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    LiveRows(
                        rows = filteredRows,
                        lastPlayedKey = lastPlayedKey,
                        onChannelClick = { row, item ->
                            lastPlayedKey =
                                "${row.addonId}/${row.catalogId}|${item.type}|${item.id}"
                            viewModel.playChannel(row, item)
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}

@Composable
private fun LiveRows(
    rows: List<CatalogRow>,
    lastPlayedKey: String?,
    onChannelClick: (CatalogRow, MetaPreview) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Focus hand-back (v0.3.11 — the Live Back-freeze root cause).
    // The player teardown itself is light (pause on the press,
    // release off the main thread); what froze the remote on return
    // was HERE: the v0.3.10 hand-back was a single unretried
    // requestFocus() on the FIRST card, with no check that it ever
    // landed. When it lost the race against the browse tree's
    // recomposition — the same race Home's entry loop was hardened
    // against — the screen was left holding NO focused element, and
    // a D-pad with nothing focused reads exactly like a freeze.
    // When it did land, it also yanked a long channel list back to
    // row 1. Now: focus returns to the PLAYED channel's card (the
    // list never unmounts under the player, so the card is still
    // composed at the same scroll position), requested in a bounded
    // loop that stops the moment the card verifiably holds focus;
    // the first card is only the fallback when nothing was played
    // yet or the played channel has left the list.
    val handBackFocus = remember { FocusRequester() }
    var handBackLanded by remember { mutableStateOf(false) }
    val handBackKey =
        remember(rows, lastPlayedKey) {
            val present =
                rows.any { row ->
                    row.items.any { item ->
                        "${row.addonId}/${row.catalogId}|${item.type}|${item.id}" == lastPlayedKey
                    }
                }
            if (present) lastPlayedKey else null
        }
    // v0.3.14: both landings now run through the shared primitive
    // against a screen claim (any focus inside the channel list) —
    // the loops they replace watched only their own target's landed
    // flag, so a shot could still drag focus off a card the user had
    // reached himself inside the landing window.
    var liveClaimed by remember { mutableStateOf(false) }
    val liveScope = androidx.compose.runtime.rememberCoroutineScope()
    suspend fun landLive() {
        liveClaimed = false
        landFocus(handBackFocus, isClaimed = { liveClaimed }, attempts = 10, delayMs = 130)
    }
    LaunchedEffect(Unit) { landLive() }
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            landLive()
        }
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = { liveScope.launch { landLive() } }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    LazyColumn(
        modifier =
            modifier.onFocusChanged { if (it.hasFocus) liveClaimed = true },
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        itemsIndexed(rows, key = { rowIndex, row -> "${row.addonId}/${row.catalogId}|$rowIndex" }) { rowIndex, row ->
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.padding(end = 40.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = row.catalogName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    // v0.3.16 (note 5): no addon-name label beside
                    // the catalog name — same clean rows as Home.
                }
                LazyRow(
                    contentPadding = PaddingValues(end = 40.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    itemsIndexed(
                        row.items,
                        key = { index, item -> "${item.type}|${item.id}|$index" },
                    ) { itemIndex, item ->
                        val itemKey =
                            "${row.addonId}/${row.catalogId}|${item.type}|${item.id}"
                        val isHandBack =
                            if (handBackKey != null) {
                                itemKey == handBackKey
                            } else {
                                rowIndex == 0 && itemIndex == 0
                            }
                        ChannelCard(
                            item = item,
                            onClick = { onChannelClick(row, item) },
                            modifier =
                                if (isHandBack) {
                                    Modifier
                                        .focusRequester(handBackFocus)
                                        .onFocusChanged {
                                            if (it.isFocused) handBackLanded = true
                                        }
                                } else {
                                    Modifier
                                },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChannelCard(
    item: MetaPreview,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.width(216.dp),
        shape = plavioCardShape(),
        colors = plavioCardColors(),
        border = plavioCardBorder(),
        scale = plavioCardScale(),
    ) {
        // v0.3.13→.21: the channel name lives ON the card over a
        // bottom scrim from the first frame, the LIVE marker is the
        // sample's RED dot + LIVE pill top-left inside the tile,
        // and the name + current programme sit BELOW the tile (the
        // sample's caption): the programme is whatever text the
        // addon serves in the meta description, prefixed "Now:".
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            val art = item.background ?: item.poster
            if (art != null) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalContext.current)
                            .data(art)
                            .size(480, 270)
                            .crossfade(false)
                            .build(),
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(10.dp),
                )
            }
            // Bottom scrim + name (always composed — text never waits
            // for the image).
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors =
                                    listOf(
                                        androidx.compose.ui.graphics.Color.Transparent,
                                        androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.78f),
                                    ),
                            ),
                        ),
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                )
            }
            // LIVE pill, top-left inside the tile: RED dot + the
            // word LIVE (the approved sample; red is a fixed
            // exception to the accent rule).
            Row(
                modifier =
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(androidx.compose.ui.graphics.Color(0xB3000000))
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Box(
                    modifier =
                        Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(androidx.compose.ui.graphics.Color(0xFFEF4444)),
                )
                Text(
                    text = stringResource(R.string.plavio_live_badge),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color.White,
                )
            }
        }
        // Caption below the tile: name + current programme.
        Column(modifier = Modifier.padding(start = 2.dp, top = 8.dp, bottom = 2.dp)) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val programme = item.description?.takeIf { it.isNotBlank() }
            if (programme != null) {
                Text(
                    text = stringResource(R.string.plavio_live_now, programme),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
