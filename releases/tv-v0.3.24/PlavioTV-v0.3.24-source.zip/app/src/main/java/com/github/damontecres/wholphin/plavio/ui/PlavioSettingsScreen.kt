package com.github.damontecres.wholphin.plavio.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.graphics.luminance
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.AppStats
import com.github.damontecres.wholphin.plavio.CrashReports
import com.github.damontecres.wholphin.ui.components.LicenseInfo

/**
 * Plavio TV settings (v0.3.21 redesign, the owner's approved sample):
 * the landing is six full-width rows — the ROW is the click target,
 * no "Open" words anywhere; a row that carries a page shows "»" at
 * its right end, an action row carries no mark. Appearance /
 * Playback / Streams / About open panels holding every control the
 * old sectioned page had (nothing dropped); Addons and Account rows
 * leave for their own screens. Panels keep the focus discipline:
 * opening moves focus to the panel's first control, Back returns
 * focus to the row that opened it.
 *
 * Subtitle settings are NOT here — they live in the video player's
 * Subtitles panel (owner's order).
 */
@Composable
fun PlavioSettingsScreen(
    onOpenAddons: () -> Unit,
    onOpenAccount: () -> Unit,
    startPage: String = "main",
    modifier: Modifier = Modifier,
    viewModel: PlavioSettingsViewModel = hiltViewModel(),
    accountsViewModel: PlavioAccountsViewModel = hiltViewModel(),
) {
    var page by remember { mutableStateOf(startPage) }
    LaunchedEffect(startPage) {
        if (startPage != "main") page = startPage
    }
    // Page graph: quality/badges/integrations/homeCatalogs live
    // under the Streams panel; licenses under About; the rest under
    // the landing.
    fun backTarget(current: String): String =
        when (current) {
            "quality", "badges", "integrations", "homeCatalogs" -> "streams"
            "licenses" -> "about"
            else -> "main"
        }
    BackHandler(enabled = page != "main") { page = backTarget(page) }

    val context = LocalContext.current
    val accent by viewModel.accent.collectAsState()
    val lookMode by viewModel.lookMode.collectAsState()
    val addons by viewModel.addons.collectAsState()
    val accountState by accountsViewModel.state.collectAsState()

    val autoplayBest by viewModel.autoplayBestStream.collectAsState()
    val autoplayNext by viewModel.autoPlayNextEpisode.collectAsState()
    val showSkipIntro by viewModel.showSkipIntro.collectAsState()
    val audioPassthrough by viewModel.audioPassthrough.collectAsState()
    val autoUpdate by viewModel.autoUpdateCheck.collectAsState()
    val qualityOrder by viewModel.qualityOrder.collectAsState()
    val streamAutoplay by viewModel.streamAutoplay.collectAsState()
    val autoplayQuality by viewModel.autoplayQuality.collectAsState()
    val badgeStyle by viewModel.badgeStyle.collectAsState()
    val badgeGroupResolution by viewModel.badgeGroupResolution.collectAsState()
    val badgeGroupHdr by viewModel.badgeGroupHdr.collectAsState()
    val badgeGroupAudio by viewModel.badgeGroupAudio.collectAsState()
    val badgeGroupLanguages by viewModel.badgeGroupLanguages.collectAsState()
    val badgeGroupSourceCodec by viewModel.badgeGroupSourceCodec.collectAsState()
    val badgeGroupSize by viewModel.badgeGroupSize.collectAsState()
    val episodeAlerts by viewModel.episodeAlertsEnabled.collectAsState()
    var reducedMotion by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        reducedMotion =
            com.github.damontecres.wholphin.plavio.MotionPreferences.reduced.value
    }
    val updateState by viewModel.updateState.collectAsState()
    var statsEnabled by remember { mutableStateOf(AppStats.enabled(context)) }
    var crashReportsEnabled by remember { mutableStateOf(CrashReports.isEnabled(context)) }

    // Focus travel: landing rows and panel first-controls. Opening a
    // panel focuses its first control; returning focuses the opener.
    val appearanceRowFocus = remember { FocusRequester() }
    val playbackRowFocus = remember { FocusRequester() }
    val streamsRowFocus = remember { FocusRequester() }
    val aboutRowFocus = remember { FocusRequester() }
    val qualityRowFocus = remember { FocusRequester() }
    val badgesRowFocus = remember { FocusRequester() }
    val integrationsRowFocus = remember { FocusRequester() }
    val homeCatalogsRowFocus = remember { FocusRequester() }
    val licensesRowFocus = remember { FocusRequester() }
    val appearanceFirstFocus = remember { FocusRequester() }
    val playbackFirstFocus = remember { FocusRequester() }
    val streamsFirstFocus = remember { FocusRequester() }
    val aboutFirstFocus = remember { FocusRequester() }
    val qualityFirstFocus = remember { FocusRequester() }
    val badgesFirstFocus = remember { FocusRequester() }
    var lastPage by remember { mutableStateOf("main") }
    LaunchedEffect(page) {
        val target =
            when (page) {
                "main" ->
                    when (lastPage) {
                        "appearance" -> appearanceRowFocus
                        "playback" -> playbackRowFocus
                        "streams" -> streamsRowFocus
                        "about" -> aboutRowFocus
                        else -> appearanceRowFocus
                    }
                "streams" ->
                    when (lastPage) {
                        "quality" -> qualityRowFocus
                        "badges" -> badgesRowFocus
                        "integrations" -> integrationsRowFocus
                        "homeCatalogs" -> homeCatalogsRowFocus
                        else -> qualityRowFocus
                    }
                "about" ->
                    if (lastPage == "licenses") licensesRowFocus else aboutFirstFocus
                "appearance" -> appearanceFirstFocus
                "playback" -> playbackFirstFocus
                else -> null
            }
        if (target != null) {
            // v0.3.15: the v0.3.11–0.3.14 hand-rolled retry loop is
            // gone — it was the same fight-window class the owner's
            // no-swallow rule bans (up to ~0.7s of re-requests after
            // a page flip, any of which could pull focus back from
            // a control the user had just moved to). The shared
            // primitive covers the panel-composes-a-beat-late race
            // with its single next-frame confirmation shot and is
            // then done.
            landFocus(target)
        }
        lastPage = page
    }

    val badgeStyleLabel =
        stringResource(
            when (BadgeStyle.fromName(badgeStyle)) {
                BadgeStyle.GROUPED -> R.string.plavio_settings_badge_grouped
                BadgeStyle.ELITE -> R.string.plavio_settings_badge_elite
                BadgeStyle.NARD -> R.string.plavio_settings_badge_nard
                BadgeStyle.GOLD -> R.string.plavio_settings_badge_gold
                BadgeStyle.MINIMALIST -> R.string.plavio_settings_badge_minimalist
            },
        )
    AnimatedContent(
        targetState = page,
        transitionSpec = {
            if (reducedMotion) {
                EnterTransition.None togetherWith ExitTransition.None
            } else {
                (fadeIn(animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing)) +
                    slideInVertically(
                        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
                    ) { it / 12 }) togetherWith
                    fadeOut(animationSpec = tween(durationMillis = 150, easing = FastOutSlowInEasing))
            }
        },
        label = "settingsPage",
        modifier = modifier.fillMaxSize(),
    ) { currentPage ->
        when (currentPage) {
            "integrations" -> PlavioIntegrationsScreen(modifier = Modifier.fillMaxSize())
            "homeCatalogs" -> PlavioHomeCatalogsScreen(modifier = Modifier.fillMaxSize())
            "licenses" -> LicenseInfo(modifier = Modifier.fillMaxSize())
            "quality" -> {
                LaunchedEffect(Unit) {
                    // v0.3.15: additive landing (see PlavioFocus.landFocus).
                    landFocus(qualityFirstFocus)
                }
                SettingsPanel(title = stringResource(R.string.plavio_settings_quality_order)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        qualityOrder.forEachIndexed { index, bucket ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Text(
                                    text = bucket,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.weight(1f),
                                )
                                StepperButton(
                                    label = "↑",
                                    enabled = index > 0,
                                    onClick = {
                                        val list = qualityOrder.toMutableList()
                                        list.removeAt(index)
                                        list.add(index - 1, bucket)
                                        viewModel.setQualityOrder(list)
                                    },
                                )
                                StepperButton(
                                    label = "↓",
                                    enabled = index < qualityOrder.size - 1,
                                    onClick = {
                                        val list = qualityOrder.toMutableList()
                                        list.removeAt(index)
                                        list.add(index + 1, bucket)
                                        viewModel.setQualityOrder(list)
                                    },
                                    modifier =
                                        if (index == 0) {
                                            Modifier.focusRequester(qualityFirstFocus)
                                        } else {
                                            Modifier
                                        },
                                )
                            }
                        }
                    }
                }
            }

            "badges" -> {
                LaunchedEffect(Unit) {
                    // v0.3.15: additive landing (see PlavioFocus.landFocus).
                    landFocus(badgesFirstFocus)
                }
                SettingsPanel(title = stringResource(R.string.plavio_settings_badge_style)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        RadioRow(
                            label = stringResource(R.string.plavio_settings_badge_grouped),
                            selected = BadgeStyle.fromName(badgeStyle) == BadgeStyle.GROUPED,
                            onClick = { viewModel.setBadgeStyle(BadgeStyle.GROUPED) },
                            modifier = Modifier.focusRequester(badgesFirstFocus),
                        )
                        RadioRow(
                            label = stringResource(R.string.plavio_settings_badge_elite),
                            selected = BadgeStyle.fromName(badgeStyle) == BadgeStyle.ELITE,
                            onClick = { viewModel.setBadgeStyle(BadgeStyle.ELITE) },
                        )
                        RadioRow(
                            label = stringResource(R.string.plavio_settings_badge_nard),
                            selected = BadgeStyle.fromName(badgeStyle) == BadgeStyle.NARD,
                            onClick = { viewModel.setBadgeStyle(BadgeStyle.NARD) },
                        )
                        RadioRow(
                            label = stringResource(R.string.plavio_settings_badge_gold),
                            selected = BadgeStyle.fromName(badgeStyle) == BadgeStyle.GOLD,
                            onClick = { viewModel.setBadgeStyle(BadgeStyle.GOLD) },
                        )
                        RadioRow(
                            label = stringResource(R.string.plavio_settings_badge_minimalist),
                            selected = BadgeStyle.fromName(badgeStyle) == BadgeStyle.MINIMALIST,
                            onClick = { viewModel.setBadgeStyle(BadgeStyle.MINIMALIST) },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_badge_details),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_resolution),
                            checked = badgeGroupResolution,
                            onStateChange = { viewModel.setBadgeGroupResolution(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_hdr),
                            checked = badgeGroupHdr,
                            onStateChange = { viewModel.setBadgeGroupHdr(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_audio),
                            checked = badgeGroupAudio,
                            onStateChange = { viewModel.setBadgeGroupAudio(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_languages),
                            checked = badgeGroupLanguages,
                            onStateChange = { viewModel.setBadgeGroupLanguages(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_source_codec),
                            checked = badgeGroupSourceCodec,
                            onStateChange = { viewModel.setBadgeGroupSourceCodec(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_badge_group_size),
                            checked = badgeGroupSize,
                            onStateChange = { viewModel.setBadgeGroupSize(it) },
                        )
                    }
                }
            }

            "appearance" -> {
                SettingsPanel(title = stringResource(R.string.plavio_settings_appearance)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text =
                                stringResource(R.string.plavio_settings_accent) +
                                    " — " + accent.label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            PlavioAccent.entries.forEachIndexed { index, entry ->
                                AccentCircle(
                                    accent = entry,
                                    selected = entry == accent,
                                    onClick = { viewModel.setAccent(entry) },
                                    modifier =
                                        if (index == 0) {
                                            Modifier.focusRequester(appearanceFirstFocus)
                                        } else {
                                            Modifier
                                        },
                                )
                            }
                        }
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_reduced_motion),
                            checked = reducedMotion,
                            onStateChange = { on ->
                                reducedMotion = on
                                com.github.damontecres.wholphin.plavio.MotionPreferences
                                    .setReduced(context, on)
                            },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_reduced_motion_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_look),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 10.dp),
                        )
                        LookChoiceRow(
                            label = stringResource(R.string.plavio_settings_look_full),
                            selected = lookMode != com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_LIGHT,
                            onClick = {
                                viewModel.setLookMode(
                                    com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_FULL,
                                )
                            },
                        )
                        LookChoiceRow(
                            label = stringResource(R.string.plavio_settings_look_light),
                            selected = lookMode == com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_LIGHT,
                            onClick = {
                                viewModel.setLookMode(
                                    com.github.damontecres.wholphin.plavio.PLAVIO_LOOK_LIGHT,
                                )
                            },
                        )
                    }
                }
            }

            "playback" -> {
                SettingsPanel(title = stringResource(R.string.plavio_settings_playback)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_autoplay_best),
                            checked = autoplayBest,
                            onStateChange = { viewModel.setAutoplayBestStream(it) },
                            modifier = Modifier.focusRequester(playbackFirstFocus),
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_autoplay_best_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_autoplay_next),
                            checked = autoplayNext,
                            onStateChange = { viewModel.setAutoPlayNextEpisode(it) },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_autoplay_next_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_skip_intro),
                            checked = showSkipIntro,
                            onStateChange = { viewModel.setShowSkipIntro(it) },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_skip_intro_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_episode_alerts),
                            checked = episodeAlerts,
                            onStateChange = { on ->
                                viewModel.setEpisodeAlertsEnabled(on)
                                com.github.damontecres.wholphin.plavio.EpisodeAlerts
                                    .ensureScheduled(context, on)
                            },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_episode_alerts_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.audio_passthrough),
                            checked = audioPassthrough,
                            onStateChange = { viewModel.setAudioPassthrough(it) },
                        )
                        Text(
                            text = stringResource(R.string.audio_passthrough_summary),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            "streams" -> {
                SettingsPanel(title = stringResource(R.string.plavio_settings_streams)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingsNavRow(
                            title = stringResource(R.string.plavio_settings_quality_order),
                            summary = qualityOrder.joinToString(" › "),
                            onClick = { page = "quality" },
                            modifier = Modifier.focusRequester(qualityRowFocus),
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_autoplay_rule),
                            checked = streamAutoplay,
                            onStateChange = { viewModel.setStreamAutoplay(it) },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_autoplay_rule_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (streamAutoplay) {
                            CycleRow(
                                label = stringResource(R.string.plavio_settings_autoplay_quality),
                                value = autoplayQuality,
                                onClick = {
                                    val options = listOf("Auto") + com.github.damontecres.wholphin.plavio.QUALITY_ORDER_OPTIONS
                                    val next = options[(options.indexOf(autoplayQuality) + 1) % options.size]
                                    viewModel.setAutoplayQuality(next)
                                },
                            )
                        }
                        SettingsNavRow(
                            title = stringResource(R.string.plavio_settings_badge_style),
                            summary = badgeStyleLabel,
                            onClick = { page = "badges" },
                            modifier = Modifier.focusRequester(badgesRowFocus),
                        )
                        SettingsNavRow(
                            title = stringResource(R.string.plavio_integrations_title),
                            summary = null,
                            onClick = { page = "integrations" },
                            modifier = Modifier.focusRequester(integrationsRowFocus),
                        )
                        SettingsNavRow(
                            title = stringResource(R.string.plavio_home_catalogs_title),
                            summary = null,
                            onClick = { page = "homeCatalogs" },
                            modifier = Modifier.focusRequester(homeCatalogsRowFocus),
                        )
                    }
                }
            }

            "about" -> {
                SettingsPanel(title = stringResource(R.string.plavio_settings_about)) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        // v0.3.16 (note 4): Check for updates LEADS
                        // the panel and takes its first focus — the
                        // owner's TV had no findable manual path
                        // when the button sat fourth, below three
                        // switches. It runs the real updater check
                        // (PlavioSettingsViewModel.checkForUpdate →
                        // PlavioUpdater) and the status line beside
                        // it reports the result in plain words; the
                        // install button appears under it when an
                        // update is found.
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            PlavioFixedButton(
                                text = stringResource(R.string.plavio_settings_check_updates),
                                onClick = { viewModel.checkForUpdate() },
                                enabled =
                                    updateState !is PlavioUpdateUiState.Checking &&
                                        updateState !is PlavioUpdateUiState.Downloading,
                                focusRequester = aboutFirstFocus,
                            )
                            UpdateStatusText(updateState)
                        }
                        val installableUpdate =
                            when (val s = updateState) {
                                is PlavioUpdateUiState.Available -> s.update
                                is PlavioUpdateUiState.InstallFailed -> s.update
                                is PlavioUpdateUiState.NeedsPermission -> s.update
                                else -> null
                            }
                        if (installableUpdate != null) {
                            PlavioFixedButton(
                                text =
                                    stringResource(R.string.plavio_update_now) +
                                        " — V${installableUpdate.versionName}",
                                onClick = { viewModel.installUpdate(installableUpdate) },
                                kind = PlavioButtonKind.Primary,
                            )
                        }
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_auto_update),
                            checked = autoUpdate,
                            onStateChange = { viewModel.setAutoUpdateCheck(it) },
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_anonymous_stats),
                            checked = statsEnabled,
                            onStateChange = { on ->
                                statsEnabled = on
                                AppStats.setEnabled(context, on)
                            },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_anonymous_stats_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioSwitchRow(
                            label = stringResource(R.string.plavio_settings_crash_reports),
                            checked = crashReportsEnabled,
                            onStateChange = { on ->
                                crashReportsEnabled = on
                                CrashReports.setEnabled(context, on)
                            },
                        )
                        Text(
                            text = stringResource(R.string.plavio_settings_crash_reports_sub),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        SettingsNavRow(
                            title = stringResource(R.string.plavio_settings_licenses),
                            summary = null,
                            onClick = { page = "licenses" },
                            modifier = Modifier.focusRequester(licensesRowFocus),
                        )
                    }
                }
            }

            else -> {
                // The landing: the sample's six rows. (v0.3.12: the
                // brand lockup floats and reserves nothing, so the
                // top padding is a normal margin, not a clearance.)
                LazyColumn(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background),
                    contentPadding = PaddingValues(end = 40.dp, top = 72.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Text(
                            text = stringResource(R.string.plavio_settings_title),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(bottom = 12.dp),
                        )
                    }
                    item {
                        SettingsLandingRow(
                            letter = "A",
                            title = stringResource(R.string.plavio_settings_appearance),
                            subtitle = "Theme Onyx · Accent ${accent.label}",
                            onClick = { page = "appearance" },
                            modifier = Modifier.focusRequester(appearanceRowFocus),
                        )
                    }
                    item {
                        SettingsLandingRow(
                            letter = "P",
                            title = stringResource(R.string.plavio_settings_playback),
                            subtitle = stringResource(R.string.plavio_settings_landing_playback_sub),
                            onClick = { page = "playback" },
                            modifier = Modifier.focusRequester(playbackRowFocus),
                        )
                    }
                    item {
                        SettingsLandingRow(
                            letter = "S",
                            title = stringResource(R.string.plavio_settings_streams),
                            subtitle = stringResource(R.string.plavio_settings_landing_streams_sub),
                            onClick = { page = "streams" },
                            modifier = Modifier.focusRequester(streamsRowFocus),
                        )
                    }
                    item {
                        SettingsLandingRow(
                            letter = "A",
                            title = stringResource(R.string.plavio_settings_addons),
                            subtitle =
                                stringResource(
                                    R.string.plavio_settings_landing_addons_sub,
                                    addons.size,
                                    addons.joinToString(", ") { it.name },
                                ),
                            onClick = onOpenAddons,
                        )
                    }
                    item {
                        SettingsLandingRow(
                            letter = "A",
                            title = stringResource(R.string.plavio_settings_account),
                            subtitle =
                                if (accountState.plavioEmail != null) {
                                    stringResource(R.string.plavio_settings_landing_account_in)
                                } else {
                                    stringResource(R.string.plavio_settings_account_sub)
                                },
                            onClick = onOpenAccount,
                        )
                    }
                    item {
                        // About carries NO mark (the sample's rule:
                        // page rows get "»", this one doesn't — it
                        // still opens the About panel, where Check
                        // for updates lives).
                        SettingsLandingRow(
                            letter = "A",
                            title = stringResource(R.string.plavio_settings_about),
                            subtitle =
                                "Plavio TV v${viewModel.installedVersionName()} · " +
                                    stringResource(R.string.plavio_settings_check_updates),
                            showMark = false,
                            onClick = { page = "about" },
                            modifier = Modifier.focusRequester(aboutRowFocus),
                        )
                    }
                }
            }
        }
    }
}

/**
 * One landing row of the redesign: letter chip, title + subtitle,
 * and "»" at the right end when the row carries a page. The whole
 * row is the click target; focus is the accent ring only.
 */
@Composable
private fun SettingsLandingRow(
    letter: String,
    title: String,
    subtitle: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    showMark: Boolean = true,
) {
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(14.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelFramed,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = PlavioOnyx.PanelFramed,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = PlavioOnyx.PanelFramed,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(14.dp)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(
                modifier =
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(LocalPlavioAccent.current.primary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = letter,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LocalPlavioAccent.current.primary,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (showMark) {
                Text(
                    text = "»",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** One TV-look choice row (Settings → Appearance): the picked look
 * carries the accent dot, focus is the accent ring only. */
@Composable
private fun LookChoiceRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(14.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelVariant,
                contentColor = PlavioOnyx.TextPrimary,
                focusedContainerColor = PlavioOnyx.PanelVariant,
                focusedContentColor = PlavioOnyx.TextPrimary,
                pressedContainerColor = PlavioOnyx.PanelVariant,
                pressedContentColor = PlavioOnyx.TextPrimary,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(14.dp)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = if (selected) "●  " else "○  ",
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) LocalPlavioAccent.current.primary else PlavioOnyx.TextSecondary,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = PlavioOnyx.TextPrimary,
            )
        }
    }
}

/** A folded settings sub-panel: panel title over its controls, same
 * page padding as the settings root. Top padding clears the brand
 * block at the corner.
 *
 * v0.3.11 — this is a plain VERTICALLY SCROLLING column now, not a
 * LazyColumn. The old form wrapped the title and the ENTIRE panel in
 * two lazy items, so every control lived inside one oversized item —
 * and a focusable buried below the fold of a single giant lazy item
 * cannot be scrolled into focus reliably. That is exactly why the
 * remote could never reach About's "Check for updates" button (and
 * why the Badges panel's lower switches were at risk): the button
 * existed, but the list had no item boundary to scroll to. In a
 * scrolling column every control is a direct scroll child and the
 * focus system's bring-into-view walks it into sight. */
@Composable
private fun SettingsPanel(
    title: String,
    content: @Composable () -> Unit,
) {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(end = 40.dp, top = 72.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Column(
            modifier =
                Modifier
                    .weight(1f)
                    .verticalScroll(scrollState),
        ) {
            PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                content()
            }
        }
    }
}

/**
 * One folded entry inside a panel: title (+ current-value summary)
 * and "»"; opens its sub-panel on click. The whole row is the click
 * target — no "Open" words. Focus is the accent ring only, scale
 * pinned (the tv-material 1.1 growth clipped row text in panels).
 */
@Composable
private fun SettingsNavRow(
    title: String,
    summary: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = MaterialTheme.colorScheme.surface,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                )
                if (summary != null) {
                    Text(
                        text = summary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Text(
                text = "»",
                style = MaterialTheme.typography.titleLarge,
            )
        }
    }
}

@Composable
private fun UpdateStatusText(state: PlavioUpdateUiState) {
    val text =
        when (state) {
            PlavioUpdateUiState.Idle -> null
            PlavioUpdateUiState.Checking -> stringResource(R.string.plavio_update_checking)
            PlavioUpdateUiState.UpToDate -> stringResource(R.string.plavio_update_up_to_date)
            PlavioUpdateUiState.Failed -> stringResource(R.string.plavio_update_failed)
            is PlavioUpdateUiState.Available ->
                stringResource(R.string.plavio_update_available_text, state.update.versionName)
            is PlavioUpdateUiState.Downloading -> stringResource(R.string.plavio_update_downloading)
            is PlavioUpdateUiState.InstallFailed ->
                stringResource(R.string.plavio_update_install_failed)
            is PlavioUpdateUiState.NeedsPermission ->
                stringResource(R.string.plavio_update_permission_needed)
        }
    if (text != null) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color =
                if (state is PlavioUpdateUiState.Failed ||
                    state is PlavioUpdateUiState.InstallFailed
                ) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
        )
    }
}

@Composable
private fun AccentCircle(
    accent: PlavioAccent,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            Modifier
                .size(52.dp)
                .then(
                    if (selected) {
                        Modifier.border(
                            2.5.dp,
                            accent.primary,
                            CircleShape,
                        )
                    } else {
                        Modifier
                    },
                ),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            onClick = onClick,
            // v0.3.17 (owner note 4): the caller's modifier — for
            // the first circle, the Appearance panel's opening
            // focus requester — belongs on THIS focusable Surface.
            // It used to ride the outer (non-focusable) Box: the
            // one first-focus attachment in Settings not sitting on
            // its focusable node (every sibling panel's requester
            // is on its row/button Surface directly), so the
            // Appearance panel's scripted landing had no guaranteed
            // target and the remote stayed live on whatever held
            // focus before — the capsule, whose profile button
            // opens Account/Login: the owner's "clicked Light in
            // Appearance and it opened login" report.
            modifier = modifier.size(42.dp),
            shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
            colors =
                ClickableSurfaceDefaults.colors(
                    containerColor = accent.primary,
                    contentColor = accent.primary,
                    focusedContainerColor = accent.primary,
                    focusedContentColor = accent.primary,
                ),
            border =
                ClickableSurfaceDefaults.border(
                    focusedBorder =
                        androidx.tv.material3.Border(
                            border =
                                androidx.compose.foundation.BorderStroke(
                                    2.5.dp,
                                    LocalPlavioAccent.current.primary,
                                ),
                            shape = CircleShape,
                        ),
                    pressedBorder =
                        androidx.tv.material3.Border(
                            border =
                                androidx.compose.foundation.BorderStroke(
                                    2.5.dp,
                                    LocalPlavioAccent.current.primary,
                                ),
                            shape = CircleShape,
                        ),
                ),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        ) {
            val gradient = accent.pickerGradient
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .then(
                            if (gradient != null) {
                                Modifier.background(
                                    androidx.compose.ui.graphics.Brush.linearGradient(
                                        colorStops = gradient,
                                    ),
                                    CircleShape,
                                )
                            } else {
                                Modifier
                            },
                        ),
            )
        }
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint =
                    if (accent.primary.luminance() > 0.5f) {
                        PlavioOnyx.Background
                    } else {
                        PlavioOnyx.TextPrimary
                    },
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun RadioRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val accent = LocalPlavioAccent.current
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = MaterialTheme.colorScheme.surface,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier =
                    Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .border(
                            2.dp,
                            if (selected) accent.primary else PlavioOnyx.TextSecondary,
                            CircleShape,
                        ),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) {
                    Box(
                        modifier =
                            Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(accent.primary),
                    )
                }
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

@Composable
private fun StepperButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.GlassFill,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = PlavioOnyx.GlassFill,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = PlavioOnyx.GlassFill,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
                disabledContainerColor = PlavioOnyx.GlassFill,
                disabledContentColor = PlavioOnyx.TextSecondary,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
        )
    }
}

/** A settings row whose value cycles through its options on click. */
@Composable
private fun CycleRow(
    label: String,
    value: String,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = MaterialTheme.colorScheme.surface,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
