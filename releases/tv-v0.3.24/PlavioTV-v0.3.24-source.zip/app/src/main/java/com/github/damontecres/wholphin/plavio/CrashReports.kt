package com.github.damontecres.wholphin.plavio

import android.content.Context
import com.github.damontecres.wholphin.BuildConfig
import io.sentry.Sentry
import io.sentry.android.core.SentryAndroid
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import timber.log.Timber

/**
 * Sentry crash reporting for the TV app — same project and pattern as
 * the phone (`plavio` in the `plavio-media` org), events distinguished
 * with environment="tv" and app/flavor tags. Errors only: no tracing,
 * no profiling, no session replay.
 *
 * ON by default; the Settings "Crash reports" toggle turns it off,
 * which closes the SDK for the rest of the process and prevents any
 * init at the next launch. The flag lives in its own SharedPreferences
 * file so [initIfEnabled] can read it synchronously in
 * Application.onCreate, before anything else starts. Every call is
 * failure-proof: a Sentry problem must never break app startup.
 *
 * This replaces ACRA (removed in v0.2.1): its dialog promised a SEND
 * that had no configured destination and could never deliver.
 */
object CrashReports {
    private const val PREFS_FILE = "plavio_crash_reports"
    private const val KEY_ENABLED = "sentry_enabled"

    fun isEnabled(context: Context): Boolean =
        runCatching {
            context
                .getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true)
        }.getOrDefault(true)

    fun setEnabled(
        context: Context,
        enabled: Boolean,
    ) {
        runCatching {
            context
                .getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply()
        }
        apply(context, enabled)
    }

    fun initIfEnabled(context: Context) {
        if (isEnabled(context)) init(context)
    }

    /** Applies a toggle change immediately (init now, or close until relaunch). */
    fun apply(
        context: Context,
        enabled: Boolean,
    ) {
        runCatching {
            if (enabled) init(context) else Sentry.close()
        }
    }

    /** Reports a caught failure (e.g. the MPV fail-soft path) without crashing. */
    fun captureException(throwable: Throwable) {
        runCatching { Sentry.captureException(throwable) }
    }

    /**
     * v0.3.23 (PLAVIO-1A / PLAVIO-1B): the exception handler for the
     * app's long-lived background scopes (the singleton stores, the
     * download engine, AppStats, the Application's startup scope).
     *
     * Both Sentry issues were a bare JobCancellationException —
     * "<job> was cancelled" — recorded as a FATAL crash: a
     * cancellation that escaped structured concurrency (thrown
     * across a withContext/await boundary, so its job was not the
     * receiving coroutine's own) landed in a scope with no
     * [CoroutineExceptionHandler] and fell through to the thread's
     * uncaught handler. A coroutine cancellation is lifecycle
     * machinery, never an application failure — the same policy the
     * Wholphin-era util.ExceptionHandler already states ("Don't
     * log/toast cancellations") — so it is dropped here. Every
     * other exception is still reported to Sentry, as a handled
     * error instead of a fatal crash: background cache/store work
     * must not take the whole TV app down, but it must stay
     * visible.
     */
    val backgroundScopeHandler: CoroutineExceptionHandler =
        CoroutineExceptionHandler { _, exception ->
            if (exception is CancellationException) {
                Timber.v(exception, "Background coroutine cancelled")
            } else {
                Timber.e(exception, "Exception in background coroutine")
                captureException(exception)
            }
        }

    /** Attaches a breadcrumb to future events (v0.3.21: decoder names, study fix #2). */
    fun addBreadcrumb(message: String) {
        runCatching {
            Sentry.addBreadcrumb(
                io.sentry.Breadcrumb().apply {
                    this.message = message
                    category = "playback"
                },
            )
        }
    }

    /** Former ACRA custom-data call sites: attach context to future events. */
    fun putCustomData(
        key: String,
        value: String,
    ) {
        runCatching { Sentry.setTag(key, value) }
    }

    private fun init(context: Context) {
        val dsn = BuildConfig.SENTRY_DSN
        if (dsn.isBlank()) return
        runCatching {
            SentryAndroid.init(context) { options ->
                options.dsn = dsn
                options.isEnableUncaughtExceptionHandler = true
                // The native (NDK) crash handler stays OFF — Java-side
                // reporting only (phone lesson from v0.12.23: a native
                // init failure can kill the app before any report is
                // written).
                options.isEnableNdk = false
                // Crashes only — keep the free plan's quota for errors.
                options.tracesSampleRate = 0.0
                options.isEnableAutoSessionTracking = false
                options.isAttachScreenshot = false
                options.isAttachViewHierarchy = false
                options.environment = "tv"
                options.setTag("app", "plavio-tv")
                options.setTag("flavor", "tv")
            }
        }
    }
}
