package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.ui.components.Button

/**
 * Settings → Account block (one item in the settings list): the Plavio
 * account form + Google Drive door, phone behaviour in TV form. Text is
 * entered with the TV keyboard through [PlavioClickToEditField] —
 * the keyboard opens only on an explicit OK press (v0.3.16).
 */
@Composable
fun PlavioAccountsBlock(
    modifier: Modifier = Modifier,
    viewModel: PlavioAccountsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val authIntent by viewModel.authIntent.collectAsState()
    val context = LocalContext.current
    LaunchedEffect(authIntent) {
        val intent = authIntent ?: return@LaunchedEffect
        runCatching { context.startActivity(intent) }
        viewModel.consumeAuthIntent()
    }

    val emailState = rememberTextFieldState()
    val passwordState = rememberTextFieldState()
    val codeState = rememberTextFieldState()
    val newPasswordState = rememberTextFieldState()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ---- Plavio account ----
        Text(
            text = stringResource(R.string.plavio_account_plavio_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (!state.plavioConfigured) {
            Text(
                text = stringResource(R.string.plavio_account_not_configured),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else if (state.plavioEmail == null) {
            Text(
                text = stringResource(R.string.plavio_account_email_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PlavioClickToEditField(
                state = emailState,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next,
                    ),
                emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
            )
            Text(
                text = stringResource(R.string.plavio_account_password_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PlavioClickToEditField(
                state = passwordState,
                modifier = Modifier.fillMaxWidth(),
                isPassword = true,
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioPrimaryButton(
                    onClick = {
                        viewModel.plavioSignIn(
                            emailState.text.toString(),
                            passwordState.text.toString(),
                        )
                    },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_sign_in))
                }
                PlavioOutlineButton(
                    onClick = {
                        viewModel.plavioSignUp(
                            emailState.text.toString(),
                            passwordState.text.toString(),
                        )
                    },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_create))
                }
                PlavioOutlineButton(
                    onClick = { viewModel.plavioForgot(emailState.text.toString()) },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_forgot))
                }
            }
            if (state.resetRequestedFor != null) {
                Text(
                    text = stringResource(R.string.plavio_account_code_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                PlavioClickToEditField(
                    state = codeState,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions =
                        KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next,
                        ),
                    emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                )
                Text(
                    text = stringResource(R.string.plavio_account_new_password_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                PlavioClickToEditField(
                    state = newPasswordState,
                    modifier = Modifier.fillMaxWidth(),
                    isPassword = true,
                    keyboardOptions =
                        KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done,
                        ),
                    emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                )
                PlavioPrimaryButton(
                    onClick = {
                        viewModel.plavioResetPassword(
                            state.resetRequestedFor ?: emailState.text.toString(),
                            codeState.text.toString(),
                            newPasswordState.text.toString(),
                        )
                    },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_set_password))
                }
            }
        } else {
            Text(
                text =
                    stringResource(R.string.plavio_account_signed_in_as, state.plavioEmail ?: ""),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.plavioLastSync?.let { last ->
                Text(
                    text = stringResource(R.string.plavio_account_last_sync, last),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioPrimaryButton(
                    onClick = { viewModel.plavioSync() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_sync_now))
                }
                PlavioOutlineButton(
                    onClick = { viewModel.plavioRestore() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_restore))
                }
                PlavioOutlineButton(
                    onClick = { viewModel.plavioSignOut() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_sign_out))
                }
            }
            // Addons-only sync (v0.3.14): addons added on the phone
            // appear here without a full restore and without typing
            // URLs with the remote.
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioOutlineButton(
                    onClick = { viewModel.plavioSyncAddons() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_sync_addons))
                }
            }
        }

        // ---- Google Drive ----
        Text(
            text = stringResource(R.string.plavio_account_google_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (state.googleAccounts.isEmpty()) {
            Text(
                text = stringResource(R.string.plavio_account_google_none),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else if (state.googleEmail == null) {
            Text(
                text = stringResource(R.string.plavio_account_google_pick),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.googleAccounts.forEach { email ->
                PlavioOutlineButton(
                    onClick = { viewModel.googleSelect(email) },
                    enabled = !state.busy,
                ) {
                    Text(text = email)
                }
            }
        } else {
            Text(
                text =
                    stringResource(R.string.plavio_account_signed_in_as, state.googleEmail ?: ""),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PlavioPrimaryButton(
                    onClick = { viewModel.googleBackup() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_sync_now))
                }
                PlavioOutlineButton(
                    onClick = { viewModel.googleRestore() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_restore))
                }
                PlavioOutlineButton(
                    onClick = { viewModel.googleSignOut() },
                    enabled = !state.busy,
                ) {
                    Text(text = stringResource(R.string.plavio_account_sign_out))
                }
            }
        }

        state.message?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = LocalPlavioAccent.current.primary,
            )
        }
        state.error?.let { error ->
            Text(
                text = error,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.error,
            )
        }
        if (state.busy) {
            Text(
                text = stringResource(R.string.plavio_account_working),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * The Account screen (v0.3.21 redesign, the owner's approved
 * sample): a photo card on the left (photo, name, @username, the
 * green Synced pill, Change photo) and the account rows on the
 * right — Username / Email / Password / Sync & backup / Connected
 * services, each carrying "»" into its panel, and Sign out in red
 * with no mark. The panels reuse [PlavioAccountsBlock] (the one
 * auth/sync engine) plus small dedicated forms (username, change
 * password, photo picker) — every control wired, focus landing on
 * each panel's first control and returning to the row on Back.
 *
 * Signed OUT (owner's fix 2026-11-04): the rows are only Sign in /
 * Create account, both opening the shared form — the detail rows
 * and Sign out exist only once a door is signed in, same as the
 * phone app. A guest page must never show account details, a
 * password row, or a Sign out row.
 */
@Composable
fun PlavioAccountScreen(
    onOpenIntegrations: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioAccountsViewModel = hiltViewModel(),
    profileViewModel: PlavioProfileViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val profileName by profileViewModel.profileName.collectAsState()
    val profileUsername by profileViewModel.profileUsername.collectAsState()
    val photoBase64 by profileViewModel.profilePhotoBase64.collectAsState()
    val context = LocalContext.current

    var page by remember { mutableStateOf("main") }
    androidx.activity.compose.BackHandler(enabled = page != "main") { page = "main" }

    val email = state.plavioEmail ?: state.googleEmail
    val displayName =
        profileName ?: email?.substringBefore("@")?.replaceFirstChar { it.uppercase() }
            ?: stringResource(R.string.plavio_account_guest)
    val username = profileUsername ?: email?.substringBefore("@") ?: ""
    val photoBitmap =
        remember(photoBase64) {
            photoBase64?.let { encoded ->
                runCatching {
                    val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }.getOrNull()
            }
        }
    var photoNote by remember { mutableStateOf<String?>(null) }
    val photoPicker =
        androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        ) { uri ->
            if (uri != null) {
                runCatching {
                    val bytes = context.contentResolver.openInputStream(uri)?.readBytes()
                        ?: error("empty")
                    val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        ?: error("not an image")
                    val scaled =
                        android.graphics.Bitmap.createScaledBitmap(bitmap, 256, 256, true)
                    val out = java.io.ByteArrayOutputStream()
                    scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                    profileViewModel.setProfilePhotoBase64(
                        android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP),
                    )
                    photoNote = null
                }.onFailure {
                    photoNote = context.getString(R.string.plavio_account_photo_failed)
                }
            }
        }

    // Focus: the first row on entry; panels take their first control.
    val usernameRowFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    val panelFirstFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(page) {
        // v0.3.15: the v0.3.11 bounded-retry loop is replaced by the
        // shared additive landing (one shot + one next-frame
        // confirmation) — see PlavioFocus.landFocus for why the
        // retry windows are banned.
        landFocus(if (page == "main") usernameRowFocus else panelFirstFocus)
    }

    var confirmSignOut by remember { mutableStateOf(false) }
    val signOutFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    if (confirmSignOut) {
        PlavioConfirmDialog(
            title = stringResource(R.string.plavio_account_sign_out_title),
            message = stringResource(R.string.plavio_account_sign_out_text),
            confirmText = stringResource(R.string.plavio_account_sign_out),
            dismissText = stringResource(R.string.plavio_cancel),
            danger = true,
            openerFocus = signOutFocus,
            onConfirm = {
                confirmSignOut = false
                viewModel.plavioSignOut()
            },
            onDismiss = { confirmSignOut = false },
        )
    }

    // v0.3.11: a scrolling column, not a LazyColumn — the email
    // panel's shared account block is far taller than the viewport,
    // and as ONE lazy item its lower controls sat in the same
    // unreachable-below-the-fold trap as the Settings panels. Every
    // control is a direct scroll child now; the layout (paddings,
    // spacing, header) is unchanged.
    val accountScrollState = androidx.compose.foundation.rememberScrollState()
    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(end = 40.dp, top = 72.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_tray_account),
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Column(
            modifier = Modifier.weight(1f).verticalScroll(accountScrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
        when (page) {
            "main" -> {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        // Photo card.
                        PlavioPanel(modifier = Modifier.width(300.dp)) {
                            Column(
                                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Box(
                                    modifier =
                                        Modifier
                                            .size(120.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(
                                                if (photoBitmap == null) {
                                                    LocalPlavioAccent.current.primary
                                                } else {
                                                    MaterialTheme.colorScheme.surfaceVariant
                                                },
                                            ),
                                    contentAlignment = androidx.compose.ui.Alignment.Center,
                                ) {
                                    if (photoBitmap != null) {
                                        androidx.compose.foundation.Image(
                                            bitmap = photoBitmap.asImageBitmap(),
                                            contentDescription = null,
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize(),
                                        )
                                    } else {
                                        Text(
                                            text = displayName.take(1).uppercase(),
                                            style = MaterialTheme.typography.displayMedium,
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                            color = LocalPlavioAccent.current.onAccent(),
                                        )
                                    }
                                }
                                Text(
                                    text = displayName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                )
                                if (username.isNotBlank()) {
                                    Text(
                                        text = "@$username",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                PlavioStatusChip(
                                    text =
                                        stringResource(
                                            if (state.plavioEmail != null) {
                                                R.string.plavio_account_synced
                                            } else {
                                                R.string.plavio_tray_not_signed_in
                                            },
                                        ),
                                    positive = state.plavioEmail != null,
                                )
                                PlavioFixedButton(
                                    text = stringResource(R.string.plavio_account_change_photo),
                                    onClick = {
                                        runCatching { photoPicker.launch("image/*") }
                                            .onFailure {
                                                photoNote =
                                                    context.getString(R.string.plavio_account_photo_failed)
                                            }
                                    },
                                )
                                if (photoNote != null) {
                                    Text(
                                        text = photoNote!!,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                        }
                        // Rows.
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            if (state.plavioEmail == null && state.googleEmail == null) {
                                // Signed out: only the doors in. Both
                                // rows open the shared account form
                                // (the "email" panel), which carries
                                // the email/password form and the
                                // Google Drive door.
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sign_in),
                                    value = null,
                                    onClick = { page = "email" },
                                    modifier = Modifier.focusRequester(usernameRowFocus),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_create),
                                    value = null,
                                    onClick = { page = "email" },
                                )
                            } else {
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_username),
                                    value = if (username.isNotBlank()) "@$username" else null,
                                    onClick = { page = "username" },
                                    modifier = Modifier.focusRequester(usernameRowFocus),
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_email_hint),
                                    value = email,
                                    onClick = { page = "email" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_password_row),
                                    value = "••••••••",
                                    onClick = { page = "password" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sync_row),
                                    value = state.plavioLastSync,
                                    onClick = { page = "sync" },
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_connected_row),
                                    value = null,
                                    onClick = onOpenIntegrations,
                                )
                                AccountRow(
                                    title = stringResource(R.string.plavio_account_sign_out),
                                    value = null,
                                    danger = true,
                                    showMark = false,
                                    onClick = { confirmSignOut = true },
                                    modifier = Modifier.focusRequester(signOutFocus),
                                )
                            }
                        }
                    }
            }

            "username" -> {
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        val nameState = rememberTextFieldState(profileName ?: "")
                        val usernameState = rememberTextFieldState(profileUsername ?: "")
                        Text(
                            text = stringResource(R.string.plavio_account_username),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text = stringResource(R.string.plavio_account_display_name),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioClickToEditField(
                            state = nameState,
                            modifier =
                                Modifier.fillMaxWidth().focusRequester(panelFirstFocus),
                            keyboardOptions =
                                KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Next,
                                ),
                            emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                        )
                        Text(
                            text = stringResource(R.string.plavio_account_username),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PlavioClickToEditField(
                            state = usernameState,
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions =
                                KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done,
                                ),
                            emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                        )
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_integrations_save),
                            onClick = {
                                profileViewModel.setProfileName(nameState.text.toString())
                                profileViewModel.setProfileUsername(usernameState.text.toString())
                                page = "main"
                            },
                            kind = PlavioButtonKind.Primary,
                        )
                    }
            }

            "password" -> {
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        if (state.plavioEmail != null) {
                            val newPasswordState = rememberTextFieldState()
                            Text(
                                text = stringResource(R.string.plavio_account_password_row),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            PlavioClickToEditField(
                                state = newPasswordState,
                                modifier =
                                    Modifier.fillMaxWidth().focusRequester(panelFirstFocus),
                                isPassword = true,
                                keyboardOptions =
                                    KeyboardOptions(
                                        keyboardType = KeyboardType.Password,
                                        imeAction = ImeAction.Done,
                                    ),
                                emptyHint = stringResource(R.string.plavio_field_tap_to_edit),
                            )
                            PlavioFixedButton(
                                text = stringResource(R.string.plavio_account_change_password),
                                onClick = {
                                    viewModel.plavioChangePassword(newPasswordState.text.toString())
                                },
                                kind = PlavioButtonKind.Primary,
                                enabled = !state.busy,
                            )
                        }
                        // The reset path + account messages live in
                        // the shared block.
                        PlavioAccountsBlock()
                    }
            }

            else -> {
                // "email" and "sync": the shared account block is
                // the engine for both (sign-in/out, sync, restore,
                // Drive door).
                    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                        PlavioAccountsBlock()
                    }
            }
        }
        }
    }
}

/** One Account row: title + current value + "»" (the Settings row language). */
@Composable
private fun AccountRow(
    title: String,
    value: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    showMark: Boolean = true,
) {
    androidx.tv.material3.Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape =
            androidx.tv.material3.ClickableSurfaceDefaults.shape(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            ),
        scale =
            androidx.tv.material3.ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            androidx.tv.material3.ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelFramed,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = PlavioOnyx.PanelFramed,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = PlavioOnyx.PanelFramed,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border = plavioRowFocusBorder(androidx.compose.foundation.shape.RoundedCornerShape(14.dp)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                color =
                    if (danger) {
                        androidx.compose.ui.graphics.Color(0xFFF87171)
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                modifier = Modifier.weight(1f),
            )
            if (value != null) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
            if (showMark) {
                Text(
                    text = "»",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
