package com.github.damontecres.wholphin.plavio.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.StreamItem

/**
 * TV port of the phone app's stream-card facts + badge styles (mobile
 * StreamBrowser.kt's parser and StreamBadges.kt's rendering, v0.14.14
 * lineup). The raw scene/P2P release title is parsed into a cleaned
 * name line (title + year ONLY — every other token becomes a fact) plus
 * capsule facts; the badge row renders in one of five styles:
 * GROUPED (Plavio's own tinted-glass capsules, the default) or the
 * bundled community badge packs ELITE / NARD / GOLD / MINIMALIST
 * (genuine artwork under `assets/badges/<pack>/`, see each pack's
 * credits.json). A fact a pack has no artwork for simply doesn't
 * render in that style — except the size, which every style shows
 * once as a text chip dressed to match the pack.
 *
 * TV adaptations: the phone's `liquidGlass` modifier becomes the TV
 * glass treatment ([PlavioOnyx.GlassFill] / [PlavioOnyx.GlassBorder],
 * the same fill/border the Sources addon tabs use), and the download
 * capsule is a focusable tv-material3 [Surface] instead of a plain
 * clickable Box, since TV navigation is D-pad driven. Badge artwork
 * keeps the phone's compact sizes (14dp Nard / 16dp others).
 */

// ---------------------------------------------------------------------------
// Badge styles
// ---------------------------------------------------------------------------

enum class BadgeStyle(
    val displayName: String,
    val assetDir: String?,
) {
    GROUPED("Grouped", null),
    ELITE("Elite", "elite"),
    NARD("Nard", "nard"),
    GOLD("Gold", "gold"),
    MINIMALIST("Minimalist", "minimalist"),
    ;

    companion object {
        fun fromName(name: String?): BadgeStyle = entries.firstOrNull { it.name == name } ?: GROUPED
    }
}

/** Fact families on a stream card; Settings → Streams toggles each one. */
enum class StreamFactGroup {
    RESOLUTION,
    HDR,
    AUDIO,
    LANGUAGES,
    SOURCE_CODEC,
    SIZE,
}

/** Style + per-group visibility for the stream-card badge row. */
data class StreamCapsuleConfig(
    val style: BadgeStyle = BadgeStyle.GROUPED,
    val showResolution: Boolean = true,
    val showHdr: Boolean = true,
    val showAudio: Boolean = true,
    val showLanguages: Boolean = true,
    val showSourceCodec: Boolean = true,
    val showSize: Boolean = true,
) {
    fun shows(group: StreamFactGroup): Boolean =
        when (group) {
            StreamFactGroup.RESOLUTION -> showResolution
            StreamFactGroup.HDR -> showHdr
            StreamFactGroup.AUDIO -> showAudio
            StreamFactGroup.LANGUAGES -> showLanguages
            StreamFactGroup.SOURCE_CODEC -> showSourceCodec
            StreamFactGroup.SIZE -> showSize
        }
}

// ---------------------------------------------------------------------------
// Stream metadata parsing (ported from mobile StreamBrowser.kt)
// ---------------------------------------------------------------------------

/** Human-readable bits extracted from a stream's title/name. */
data class ParsedStreamInfo(
    val quality: String? = null,
    val source: String? = null,
    val codec: String? = null,
    val audio: String? = null,
    val size: String? = null,
)

private val QUALITY_RE = Regex("""\b(2160p|1440p|1080p|720p|480p|360p)\b""", RegexOption.IGNORE_CASE)
private val FOUR_K_RE = Regex("""\b(4K|UHD)\b""", RegexOption.IGNORE_CASE)
// Named quality labels (AIOStreams-style formatters print these instead of
// numeric tags): FHD = 1080p, HD = 720p, SD = 480p. Word boundaries keep
// HDRip / HDCAM / HDTV from matching the bare HD rule.
private val FHD_RE = Regex("""\bFHD\b""", RegexOption.IGNORE_CASE)
private val HD_RE = Regex("""\bHD\b""", RegexOption.IGNORE_CASE)
private val SD_RE = Regex("""\bSD\b""", RegexOption.IGNORE_CASE)
private val SOURCE_RE =
    Regex("""\b(Blu[-\s]?Ray|BDRip|BRRip|WEB[-\s]?DL|WEBRip|HDRip|HDTC|HDCAM|HDTS|DVDRip|HDTV|\bTS\b|CAM)\b""", RegexOption.IGNORE_CASE)
private val CODEC_RE = Regex("""\b(x265|HEVC|x264|AVC|AV1|VP9)\b""", RegexOption.IGNORE_CASE)
private val AUDIO_RE =
    Regex(
        """\b(Atmos|DTS[-\s]?HD(?:\s?MA)?|TrueHD|DTS|DD\+?(?:\s?[57]\.1)?|Dolby(?:\s?Digital)?|AAC(?:\s?5\.1)?)\b""",
        RegexOption.IGNORE_CASE,
    )
private val SIZE_RE = Regex("""(\d+(?:\.\d+)?\s?(?:GB|MB))""", RegexOption.IGNORE_CASE)

/** Scans a stream's title/name for quality, source, codec, audio and size tags. */
fun parseStreamInfo(stream: StreamItem): ParsedStreamInfo {
    val haystack = listOfNotNull(stream.title, stream.name).joinToString("\n")
    if (haystack.isBlank()) return ParsedStreamInfo()
    val quality =
        FOUR_K_RE.find(haystack)?.value?.uppercase()
            ?: QUALITY_RE.find(haystack)?.value?.lowercase()
            ?: if (FHD_RE.containsMatchIn(haystack)) {
                "1080p"
            } else if (HD_RE.containsMatchIn(haystack)) {
                "720p"
            } else if (SD_RE.containsMatchIn(haystack)) {
                "480p"
            } else {
                null
            }
    val source =
        SOURCE_RE.find(haystack)?.value
            ?.replace(Regex("""[-\s]+"""), "-")?.uppercase()
            ?.replace("BLU-RAY", "BluRay")?.replace("WEB-DL", "WEB-DL")
    val codec = CODEC_RE.find(haystack)?.value?.uppercase()
    val audio =
        AUDIO_RE.find(haystack)?.value
            ?.replace(Regex("""\s+"""), " ")?.trim()
            ?.let { a ->
                when {
                    a.equals("Atmos", ignoreCase = true) -> "Atmos"
                    a.startsWith("DTS", ignoreCase = true) -> a.uppercase().replace(" ", "")
                    a.startsWith("DD", ignoreCase = true) -> a.uppercase().replace(" ", "")
                    a.startsWith("Dolby", ignoreCase = true) -> "Dolby"
                    else -> a.uppercase()
                }
            }
    val size =
        SIZE_RE.find(haystack)?.value?.uppercase()?.replace(" ", "")
            ?.let { s -> s.dropLast(2) + " " + s.takeLast(2) }
    return ParsedStreamInfo(quality, source, codec, audio, size)
}

/** Canonical filter bucket for a parsed quality label; unknown labels have no filter bucket. */
fun normalizeStreamQuality(quality: String?): String? {
    val value = quality?.trim()?.lowercase()?.replace(" ", "") ?: return null
    return when (value) {
        "4k", "uhd", "2160p" -> "4K"
        "fhd" -> "1080p"
        "hd" -> "720p"
        "sd" -> "480p"
        "1440p", "1080p", "720p", "480p", "360p" -> value
        else -> null
    }
}

/** Compare display labels after case/spacing/punctuation normalization, retaining original text. */
private fun comparableStreamLabel(value: String): String = value.lowercase().filter { it.isLetterOrDigit() }

private fun streamLinesEquivalent(
    first: String,
    second: String,
): Boolean {
    val firstLabel = comparableStreamLabel(first)
    val secondLabel = comparableStreamLabel(second)
    if (firstLabel == secondLabel) return true
    val firstQuality = normalizeStreamQuality(first)
    val secondQuality = normalizeStreamQuality(second)
    return firstQuality != null && firstQuality == secondQuality
}

/** Combine addon title/name while removing repeated and less-informative overlapping lines. */
fun streamDisplayName(
    title: String?,
    name: String?,
    fallbackUrl: String = "",
): String {
    val t = title?.trim().orEmpty()
    val n = name?.trim().orEmpty()
    if (t.isBlank() && n.isBlank()) {
        return fallbackUrl.substringAfter("://").substringBefore("/").take(48)
    }

    val lines = mutableListOf<String>()
    (listOf(t, n).filter { it.isNotBlank() }.flatMap { field ->
        field.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
    }).forEach { candidate ->
        val candidateLabel = comparableStreamLabel(candidate)
        if (candidateLabel.isEmpty()) return@forEach
        val overlaps =
            lines.indices.filter { index ->
                val existingLabel = comparableStreamLabel(lines[index])
                streamLinesEquivalent(lines[index], candidate) ||
                    (existingLabel.isNotEmpty() &&
                        (existingLabel.contains(candidateLabel) || candidateLabel.contains(existingLabel)))
            }
        if (overlaps.isEmpty()) {
            lines += candidate
        } else {
            val richer =
                overlaps.filter { index ->
                    comparableStreamLabel(lines[index]).length < candidateLabel.length
                }
            if (richer.isNotEmpty()) {
                val insertionIndex = richer.minOrNull()!!
                richer.asReversed().forEach { index -> lines.removeAt(index) }
                lines.add(insertionIndex.coerceAtMost(lines.size), candidate)
            }
        }
    }
    return lines.joinToString("\n").ifBlank {
        fallbackUrl.substringAfter("://").substringBefore("/").take(48)
    }
}

/** Addon grouping key for tabs. */
fun StreamItem.addonKey(): String =
    sourceName?.takeIf { it.isNotBlank() }
        ?: name?.takeIf { it.isNotBlank() } ?: "Unknown"

// ---------------------------------------------------------------------------
// Stream-card facts (mobile v0.14.10–v0.14.12): parse the raw release
// title into a clean title line + glass capsule facts. The name line
// shows ONLY title + year (episode codes stay — they are part of a
// title's identity); every parsed fact token lives in the capsules.
// ---------------------------------------------------------------------------

/** Everything a cleaned-up stream card shows, parsed from the raw title. */
data class StreamFacts(
    val displayName: String,
    val quality: String? = null,
    /** "4K UHD" tag — the name carries UHD, or 2160p from a BluRay-class source. */
    val qualityTag: String? = null,
    val sourceType: String? = null,
    val remux: Boolean = false,
    /** HDR formats, short forms: HDR / HDR10 / HDR10+ / DV. */
    val hdrFormats: List<String> = emptyList(),
    /** HDR formats, display forms: DV spells out to "Dolby Vision". */
    val hdrFormatsFull: List<String> = emptyList(),
    val audioCodec: String? = null,
    val atmos: Boolean = false,
    val channels: String? = null,
    val languages: List<String> = emptyList(),
    val languageCodes: List<String> = emptyList(),
    val codec: String? = null,
    /** "10bit" when the release is 10-bit. */
    val bitDepth: String? = null,
    val version: String? = null,
    val size: String? = null,
    val providerLine: String? = null,
) {
    /** True when the title yielded at least one capsule-worthy fact. */
    val hasFacts: Boolean
        get() =
            quality != null || qualityTag != null || sourceType != null || remux ||
                hdrFormats.isNotEmpty() || audioCodec != null || atmos || channels != null ||
                languages.isNotEmpty() || codec != null || bitDepth != null ||
                version != null || size != null

    /**
     * Short-form parts of one group, in display order, for the Grouped
     * style: codec and bit depth glue together ("HEVC 10bit") and
     * languages ride as CODES.
     */
    fun groupParts(group: StreamFactGroup): List<String> =
        when (group) {
            StreamFactGroup.RESOLUTION -> listOfNotNull(quality, qualityTag)
            StreamFactGroup.HDR -> hdrFormats
            StreamFactGroup.AUDIO ->
                listOfNotNull(audioCodec, if (atmos) "Atmos" else null, channels)
            StreamFactGroup.LANGUAGES -> languageCodes
            StreamFactGroup.SOURCE_CODEC -> {
                val codecGlued =
                    codec?.let { c ->
                        if (bitDepth != null) "$c $bitDepth" else c
                    }
                listOfNotNull(sourceType, if (remux) "REMUX" else null, codecGlued, version)
            }
            StreamFactGroup.SIZE -> listOfNotNull(size)
        }

    /** Grouped style: one "a · b · c" string per visible non-empty group. */
    fun groupedCapsules(config: StreamCapsuleConfig): List<Pair<StreamFactGroup, String>> =
        StreamFactGroup.entries.mapNotNull { group ->
            if (!config.shows(group)) return@mapNotNull null
            val parts = groupParts(group)
            if (parts.isEmpty()) null else group to parts.joinToString(" · ")
        }
}

/** Soft category tints for the Grouped glass style (mobile's colour map). */
fun StreamFactGroup.capsuleTint(): Color =
    when (this) {
        StreamFactGroup.RESOLUTION -> Color(0xFF8B5CF6) // violet
        StreamFactGroup.HDR -> Color(0xFFFFC400) // gold
        StreamFactGroup.AUDIO -> Color(0xFF4ADE80) // green
        StreamFactGroup.LANGUAGES -> Color(0xFFFB7185) // rose
        StreamFactGroup.SOURCE_CODEC -> Color(0xFF60A5FA) // blue
        StreamFactGroup.SIZE -> Color(0xFFFB923C) // orange
    }

private val YEAR_TOKEN_RE = Regex("""^(19|20)\d{2}$""")
private val EPISODE_TOKEN_RE = Regex("""^S\d{1,2}E\d{1,3}$""", RegexOption.IGNORE_CASE)
private val VERSION_TAG_RE = Regex("""\b(V\d{1,2}|PROPER|REPACK)\b""", RegexOption.IGNORE_CASE)

/** Whole words that are release facts/junk, never title words worth keeping. */
private val STREAM_FACT_WORDS =
    setOf(
        "2160P", "1440P", "1080P", "720P", "480P", "360P", "4K", "UHD", "FHD",
        "HD", "SD", "HQ", "ORG", "CLEAN", "PROPER", "REPACK",
        // Capsule facts: HDR family, audio family, misc release tags.
        "HDR", "HDR10", "DV", "DOVI", "REMUX", "FLAC", "OPUS", "EAC3", "AC3",
        "ATMOS", "TRUEHD", "DTS", "10BIT",
    )

/** Language name → code, for the Grouped capsule style. */
private val STREAM_LANGUAGE_CODES =
    mapOf(
        "Hindi" to "HI", "Telugu" to "TE", "Tamil" to "TA", "Malayalam" to "ML",
        "Kannada" to "KN", "Bengali" to "BN", "Punjabi" to "PA", "Marathi" to "MR",
        "Gujarati" to "GU", "Odia" to "OR", "Assamese" to "AS", "Urdu" to "UR",
        "English" to "EN", "Arabic" to "AR", "Spanish" to "ES", "French" to "FR",
        "German" to "DE", "Italian" to "IT", "Portuguese" to "PT", "Russian" to "RU",
        "Ukrainian" to "UK", "Polish" to "PL", "Turkish" to "TR", "Persian" to "FA",
        "Korean" to "KO", "Japanese" to "JA", "Chinese" to "ZH", "Thai" to "TH",
        "Vietnamese" to "VI", "Indonesian" to "ID", "Dutch" to "NL", "Swedish" to "SV",
    )

// HDR / extended-audio probes over the raw title. Word boundaries keep
// HDRip / DVDRip from tripping the HDR / DV rules.
private val HDR10_PLUS_RE = Regex("""HDR10\+|HDR10PLUS""", RegexOption.IGNORE_CASE)
private val HDR10_RE = Regex("""\bHDR10\b""", RegexOption.IGNORE_CASE)
private val HDR_GENERIC_RE = Regex("""\bHDR\b""", RegexOption.IGNORE_CASE)
private val DOLBY_VISION_RE =
    Regex("""\bDV\b|\bDoVi\b|Dolby[\s._-]?Vision""", RegexOption.IGNORE_CASE)
private val DTS_HD_RE = Regex("""DTS[-\s.]?HD""", RegexOption.IGNORE_CASE)
private val TRUEHD_RE = Regex("""TrueHD|True[.\s]HD""", RegexOption.IGNORE_CASE)
private val EAC3_RE =
    Regex("""EAC3|E-AC-3|DDP|DD\+|Dolby[\s.]?Digital[\s.]?Plus""", RegexOption.IGNORE_CASE)
private val AC3_RE = Regex("""\bAC3\b""", RegexOption.IGNORE_CASE)
private val DTS_RE = Regex("""\bDTS\b""", RegexOption.IGNORE_CASE)
private val DD_RE = Regex("""\bDD\b""", RegexOption.IGNORE_CASE)
private val AAC_TOKEN_RE = Regex("""\bAAC\b""", RegexOption.IGNORE_CASE)
private val FLAC_RE = Regex("""\bFLAC\b""", RegexOption.IGNORE_CASE)
private val OPUS_RE = Regex("""\bOpus\b""", RegexOption.IGNORE_CASE)
private val ATMOS_RE = Regex("""\bAtmos\b""", RegexOption.IGNORE_CASE)
// Channel layout, standalone ("...DDP.5.1...") or glued ("DDP5.1");
// the lookahead keeps bare file sizes ("5.1 GB") from matching.
private val CHANNELS_RE =
    Regex("""(?:^|[^0-9.])(2\.0|5\.1|6\.1|7\.1)(?![0-9]|\s?(GB|MB|TB))""", RegexOption.IGNORE_CASE)
private val BIT_DEPTH_RE = Regex("""\b10[-\s]?bit\b""", RegexOption.IGNORE_CASE)
private val REMUX_RE = Regex("""\bREMUX\b|\bBDREMUX\b""", RegexOption.IGNORE_CASE)

/**
 * True when [token] (one dot/underscore-separated piece of a release
 * name) carries a fact the capsules already show — quality, source,
 * codec, audio, a language, a version tag — or is release junk.
 * Hyphen-glued tokens ("Hindi-Telugu", "x264-HDHub4u", "V2-HDTC")
 * count when any part or the whole matches.
 */
private fun isStreamFactToken(token: String): Boolean {
    val parts = token.split('-')
    val partIsFact =
        parts.any { part ->
            val p = part.uppercase()
            p in STREAM_FACT_WORDS ||
                Regex("""V\d{1,2}""").matches(p) ||
                STREAM_LANGUAGES.any { it.equals(part, ignoreCase = true) }
        }
    return partIsFact || SOURCE_RE.containsMatchIn(token) ||
        CODEC_RE.containsMatchIn(token) || AUDIO_RE.containsMatchIn(token)
}

/**
 * The fully-clean name line: "Title (Year)", or "Title S01E05" for
 * episodes — every fact token stripped, no extension. Returns null
 * when the stem yields no parseable title anchored by a year, an
 * episode code, or at least one fact token; the caller then keeps the
 * previous cleaned-filename rendering.
 */
private fun cleanStreamTitle(stem: String): String? {
    val tokens = stem.split(Regex("""[._\s]+""")).filter { it.isNotBlank() }
    if (tokens.isEmpty()) return null
    val title = mutableListOf<String>()
    var year: String? = null
    var episode: String? = null
    var stoppedAtFact = false
    var i = 0
    while (i < tokens.size) {
        val tok = tokens[i]
        when {
            YEAR_TOKEN_RE.matches(tok) -> {
                year = tok
                // An episode code right after the year stays in the name too.
                tokens.getOrNull(i + 1)?.takeIf { EPISODE_TOKEN_RE.matches(it) }
                    ?.let { episode = it.uppercase() }
                break
            }
            EPISODE_TOKEN_RE.matches(tok) -> {
                episode = tok.uppercase()
                break
            }
            isStreamFactToken(tok) -> {
                stoppedAtFact = true
                break
            }
            else -> {
                title += tok
                i++
            }
        }
    }
    if (title.isEmpty()) return null
    if (year == null && episode == null && !stoppedAtFact) return null
    return buildString {
        append(title.joinToString(" "))
        year?.let { append(" (").append(it).append(")") }
        episode?.let { append(" ").append(it) }
    }
}

private val STREAM_EXT_RE =
    Regex("""\.(mkv|mp4|avi|mov|webm|m4v|wmv|ts|m2ts)$""", RegexOption.IGNORE_CASE)
private val LEADING_BRACKETS_RE = Regex("""^(\[[^\]]*\]\s*)+""")
private val BRACKET_CONTENT_RE = Regex("""\[([^\]]+)\]""")

/** Audio languages commonly named in release titles, longest names first. */
private val STREAM_LANGUAGES =
    listOf(
        "Hindi", "Telugu", "Tamil", "Malayalam", "Kannada", "Bengali", "Punjabi",
        "Marathi", "Gujarati", "Odia", "Assamese", "Urdu", "English", "Arabic",
        "Spanish", "French", "German", "Italian", "Portuguese", "Russian",
        "Ukrainian", "Polish", "Turkish", "Persian", "Korean", "Japanese",
        "Chinese", "Thai", "Vietnamese", "Indonesian", "Dutch", "Swedish",
    )

/** Languages named in [raw], in the order the title names them. */
fun parseStreamLanguages(raw: String): List<String> =
    STREAM_LANGUAGES.mapNotNull { lang ->
        Regex("""(?<![A-Za-z])${Regex.escape(lang)}(?![A-Za-z])""", RegexOption.IGNORE_CASE)
            .find(raw)?.let { lang to it.range.first }
    }.sortedBy { it.second }.map { it.first }.distinct()

/** Display form for a parsed source tag: HDTC / WEB-DL / WEBRip / BluRay / HDRip… */
private fun streamSourceDisplay(raw: String): String {
    val u = raw.uppercase().replace(Regex("""[-\s]+"""), "-")
    return when {
        u.contains("BLU") || u == "BDRIP" -> "BluRay"
        u.startsWith("WEB") && u.contains("DL") -> "WEB-DL"
        u == "WEBRIP" -> "WEBRip"
        u == "BRRIP" -> "BRRip"
        u == "HDRIP" -> "HDRip"
        u == "DVDRIP" -> "DVDRip"
        else -> u
    }
}

/** Bytes (behaviorHints videoSize) formatted the way titles print size. */
private fun formatStreamBytes(bytes: Long): String =
    if (bytes >= 1_073_741_824L) {
        String.format(java.util.Locale.US, "%.2f GB", bytes / 1_073_741_824.0)
    } else {
        String.format(java.util.Locale.US, "%.1f MB", bytes / 1_048_576.0)
    }

/**
 * Parses [stream]'s raw release title into card facts.
 *
 * The filename line is the title/name line that ends in a video
 * extension once its leading bracket groups ("[FSLv2] [💾 15.69 GB]")
 * are stripped. Its display form is [cleanStreamTitle] — title + year
 * only, facts removed — and only stems that don't parse keep the older
 * dots-to-spaces form with the extension kept. [showSize] is the
 * Settings → Streams size-group toggle: it governs the size fact (the
 * size appears exactly once, in the card's sub-line / size chip).
 * When nothing parseable is found, [StreamFacts.hasFacts] is false
 * and the card renders the raw title exactly as before.
 */
fun streamFacts(
    stream: StreamItem,
    showSize: Boolean,
): StreamFacts {
    val info = parseStreamInfo(stream)
    val rawLines =
        listOfNotNull(stream.filename, stream.title, stream.name)
            .flatMap { field ->
                field.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
            }
    val stripped = rawLines.map { it.replace(LEADING_BRACKETS_RE, "").trim() }
    val filenameLine =
        stripped.firstOrNull { STREAM_EXT_RE.containsMatchIn(it) }
            ?: stripped.filter { line -> line.count { c -> c == '.' } >= 3 }
                .maxByOrNull { it.length }
    val displayName =
        filenameLine?.let { line ->
            val ext = STREAM_EXT_RE.find(line)?.value?.lowercase()
            val stem = if (ext != null) line.dropLast(ext.length) else line
            // The name line is title + year only ("Street Fighter
            // (2026)") whenever the stem parses that far; the facts it
            // drops live in the capsules. Unparseable stems keep the
            // cleaned-filename rendering.
            cleanStreamTitle(stem) ?: run {
                val spaced =
                    stem.replace('.', ' ').replace('_', ' ')
                        .replace(Regex("""\s+"""), " ").trim()
                if (ext != null && spaced.isNotBlank()) spaced + ext else spaced
            }
        }?.takeIf { it.isNotBlank() }
            ?: streamDisplayName(stream.title, stream.name, stream.url)

    // Provider line: the title's leading bracket tag ("[FSLv2]") plus the
    // addon label, "FSLv2 · HdHub" style.
    val rawAll = listOfNotNull(stream.filename, stream.title, stream.name).joinToString("\n")
    val bracketTag =
        BRACKET_CONTENT_RE.findAll(rawAll)
            .map { it.groupValues[1].trim() }
            .firstOrNull { tag ->
                tag.isNotBlank() && tag.length <= 24 &&
                    !SIZE_RE.containsMatchIn(tag) && !tag.contains("💾")
            }
    val addonLabel =
        stream.sourceName?.takeIf { it.isNotBlank() }
            ?: stream.name?.takeIf { n ->
                n.isNotBlank() && n.length <= 40 && !STREAM_EXT_RE.containsMatchIn(n) &&
                    !n.contains('.')
            }?.let { n ->
                // Drop a trailing quality tag ("HdHub 1080p" -> "HdHub").
                n.replace(
                    Regex("""\s+\b(2160p|1440p|1080p|720p|480p|360p|4K|UHD)\b.*$""", RegexOption.IGNORE_CASE),
                    "",
                ).trim().ifBlank { null }
            }
    val providerLine =
        listOfNotNull(bracketTag, addonLabel)
            .distinctBy { it.lowercase() }
            .joinToString(" · ").ifBlank { null }

    val qualityNorm =
        when (val q = info.quality) {
            null -> null
            else -> if (q.equals("4K", true) || q.equals("UHD", true)) "2160p" else q.lowercase()
        }
    val sourceDisp = info.source?.let { streamSourceDisplay(it) }
    val remuxFound = REMUX_RE.containsMatchIn(rawAll)
    val bluRayClass = sourceDisp in setOf("BluRay", "BDRip", "BRRip") || remuxFound
    // "4K UHD" tag: the name says UHD (or 4K), or it's a 2160p rip from
    // a UHD/BluRay-class source. A plain 1080p never earns the tag.
    val qualityTag =
        when {
            FOUR_K_RE.containsMatchIn(rawAll) -> "4K UHD"
            qualityNorm == "2160p" && bluRayClass -> "4K UHD"
            else -> null
        }
    // HDR formats, strongest form first; DV rides last ("HDR10+ · DV").
    val hdrShort = mutableListOf<String>()
    val hdrFull = mutableListOf<String>()
    when {
        HDR10_PLUS_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR10+"
            hdrFull += "HDR10+"
        }
        HDR10_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR10"
            hdrFull += "HDR10"
        }
        HDR_GENERIC_RE.containsMatchIn(rawAll) -> {
            hdrShort += "HDR"
            hdrFull += "HDR"
        }
    }
    if (DOLBY_VISION_RE.containsMatchIn(rawAll)) {
        hdrShort += "DV"
        hdrFull += "Dolby Vision"
    }
    // Audio: codec by precedence (DTS-HD before DTS, DDP family before
    // DD), plus the Atmos flag and the channel layout.
    val audioCodec =
        when {
            DTS_HD_RE.containsMatchIn(rawAll) -> "DTS-HD"
            TRUEHD_RE.containsMatchIn(rawAll) -> "TrueHD"
            EAC3_RE.containsMatchIn(rawAll) -> "DDP"
            AC3_RE.containsMatchIn(rawAll) -> "AC3"
            DTS_RE.containsMatchIn(rawAll) -> "DTS"
            DD_RE.containsMatchIn(rawAll) -> "DD"
            AAC_TOKEN_RE.containsMatchIn(rawAll) -> "AAC"
            FLAC_RE.containsMatchIn(rawAll) -> "FLAC"
            OPUS_RE.containsMatchIn(rawAll) -> "Opus"
            else -> null
        }
    val languageNames = parseStreamLanguages(rawAll)
    return StreamFacts(
        displayName = displayName,
        quality = qualityNorm,
        qualityTag = qualityTag,
        sourceType = sourceDisp,
        remux = remuxFound,
        hdrFormats = hdrShort,
        hdrFormatsFull = hdrFull,
        audioCodec = audioCodec,
        atmos = ATMOS_RE.containsMatchIn(rawAll),
        channels = CHANNELS_RE.find(rawAll)?.groupValues?.get(1),
        languages = languageNames,
        languageCodes = languageNames.mapNotNull { STREAM_LANGUAGE_CODES[it] },
        codec =
            when (val c = info.codec) {
                null -> null
                else -> if (c.startsWith("X", true)) c.lowercase() else c.uppercase()
            },
        bitDepth = if (BIT_DEPTH_RE.containsMatchIn(rawAll)) "10bit" else null,
        version = VERSION_TAG_RE.find(rawAll)?.value?.uppercase(),
        size =
            if (showSize) {
                info.size ?: stream.videoSize?.takeIf { it > 0 }?.let { formatStreamBytes(it) }
            } else {
                null
            },
        providerLine = providerLine,
    )
}

// ---------------------------------------------------------------------------
// Badge keys + pack artwork rendering (ported from mobile StreamBadges.kt)
// ---------------------------------------------------------------------------

/**
 * Canonical badge keys for [facts], in card order (resolution, source,
 * codec, HDR, audio, languages), honouring the per-group toggles. The
 * asset prep decides per pack which keys actually have a file; a
 * missing file renders nothing.
 */
fun streamBadgeKeys(
    facts: StreamFacts,
    config: StreamCapsuleConfig,
): List<String> =
    buildList {
        if (config.shows(StreamFactGroup.RESOLUTION)) {
            when (facts.quality) {
                "2160p" -> add("res-2160p")
                "1440p" -> add("res-1440p")
                "1080p" -> add("res-1080p")
                "720p" -> add("res-720p")
                "480p" -> add("res-480p")
                "360p" -> add("res-360p")
            }
        }
        if (config.shows(StreamFactGroup.SOURCE_CODEC)) {
            when (facts.sourceType) {
                "BluRay", "BDRip", "BRRip" -> add("src-bluray")
                "WEB-DL" -> add("src-webdl")
                "WEBRip" -> add("src-webrip")
                "HDRip" -> add("src-hdrip")
                "DVDRip" -> add("src-dvdrip")
                "HDTV" -> add("src-hdtv")
                "CAM", "HDCAM", "HDTC", "HDTS", "TS" -> add("src-cam")
            }
            if (facts.remux) add("remux")
            when (facts.codec?.uppercase()) {
                "HEVC", "X265" -> add("codec-hevc")
                "AVC", "X264" -> add("codec-avc")
                "AV1" -> add("codec-av1")
            }
            if (facts.bitDepth != null) add("bit-10")
        }
        if (config.shows(StreamFactGroup.HDR)) {
            facts.hdrFormats.forEach { format ->
                when (format) {
                    "DV" -> add("hdr-dv")
                    "HDR10+" -> add("hdr-hdr10plus")
                    "HDR10" -> add("hdr-hdr10")
                    "HDR" -> add("hdr-hdr")
                }
            }
        }
        if (config.shows(StreamFactGroup.AUDIO)) {
            when (facts.audioCodec) {
                "TrueHD" -> add("audio-truehd")
                "DTS-HD" -> add("audio-dtshd")
                "DTS" -> add("audio-dts")
                "DDP" -> add("audio-ddp")
                "AC3", "DD" -> add("audio-dd")
                "AAC" -> add("audio-aac")
                "FLAC" -> add("audio-flac")
                "Opus" -> add("audio-opus")
            }
            if (facts.atmos) add("atmos")
            when (facts.channels) {
                "2.0" -> add("ch-20")
                "5.1" -> add("ch-51")
                "6.1" -> add("ch-61")
                "7.1" -> add("ch-71")
            }
        }
        if (config.shows(StreamFactGroup.LANGUAGES)) {
            facts.languageCodes.forEach { code -> add("lang-" + code.lowercase()) }
        }
    }

/** NardBadges group colours (from the pack's own group definitions). */
private fun nardChipColor(key: String): Color =
    when {
        key.startsWith("res-") || key.startsWith("ch-") -> Color(0xFF858283)
        key.startsWith("src-") || key == "remux" -> Color(0xFF1976D2)
        key.startsWith("hdr-") -> Color(0xFFFF9800)
        key.startsWith("codec-") || key == "bit-10" -> Color(0xFF4CAF50)
        key.startsWith("audio-") || key == "atmos" -> Color(0xFF00BCD4)
        key.startsWith("lang-") -> Color(0xFF4ECDC4)
        else -> Color(0xFF858283)
    }

@Composable
private fun rememberBadgeBitmap(path: String): ImageBitmap? {
    val context = LocalContext.current
    return remember(path) {
        runCatching {
            context.assets.open(path).use { BitmapFactory.decodeStream(it) }
                ?.asImageBitmap()
        }.getOrNull()
    }
}

/** One pack badge: the pack's real artwork, chipped where the pack chips it. */
@Composable
private fun BadgeArtwork(
    style: BadgeStyle,
    dir: String,
    key: String,
) {
    val bitmap = rememberBadgeBitmap("badges/$dir/$key.png") ?: return
    if (style == BadgeStyle.NARD) {
        Box(
            Modifier
                .background(nardChipColor(key), RoundedCornerShape(6.dp))
                .padding(horizontal = 5.dp, vertical = 2.dp),
        ) {
            Image(bitmap, contentDescription = null, modifier = Modifier.height(14.dp))
        }
    } else {
        Image(bitmap, contentDescription = null, modifier = Modifier.height(16.dp))
    }
}

/** The size, as a text chip dressed to match the chosen pack. */
@Composable
private fun BadgeSizeChip(
    style: BadgeStyle,
    text: String,
) {
    when (style) {
        BadgeStyle.GOLD ->
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFBE01),
                maxLines = 1,
                modifier = Modifier.padding(horizontal = 2.dp, vertical = 3.dp),
            )
        BadgeStyle.MINIMALIST ->
            Box(
                Modifier
                    .border(1.dp, Color.White.copy(alpha = 0.75f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 7.dp, vertical = 3.dp),
            ) {
                Text(
                    text,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                )
            }
        BadgeStyle.NARD ->
            Box(
                Modifier
                    .background(Color(0xFF858283), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp),
            ) {
                Text(
                    text,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                )
            }
        else ->
            Box(
                Modifier
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp),
            ) {
                Text(
                    text,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                )
            }
    }
}

/**
 * One fact capsule in the Grouped style: the TV glass treatment
 * ([PlavioOnyx.GlassFill] fill + [PlavioOnyx.GlassBorder] rim — the
 * phone's liquidGlass recipe in TV form) with the SOFT category tint
 * laid over it: a gentle wash of the colour inside, the rim in the
 * colour, white text on top.
 */
@Composable
fun StreamFactCapsule(
    text: String,
    modifier: Modifier = Modifier,
    tint: Color? = null,
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .background(PlavioOnyx.GlassFill, shape)
            .then(
                if (tint != null) {
                    Modifier
                        .background(tint.copy(alpha = 0.13f), shape)
                        .border(1.dp, tint.copy(alpha = 0.55f), shape)
                } else {
                    Modifier.border(1.dp, PlavioOnyx.GlassBorder, shape)
                },
            )
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            fontWeight = FontWeight.Bold,
            color = PlavioOnyx.TextPrimary,
            maxLines = 1,
        )
    }
}

/**
 * The wrapping badge row under a cleaned stream filename, in the
 * user's chosen style (Settings → Streams → Badge style). GROUPED
 * renders the glass capsules; the pack styles render the packs'
 * bundled artwork. All styles read the same parsed facts and obey
 * the same group toggles (Settings → Streams → Badge details).
 * [trailing] renders LAST in the row (the download capsule rides
 * there); with no facts and no trailing content the row doesn't
 * render at all. Badges are informational — never focusable.
 *
 * Note: the SIZE group renders as a chip in EVERY style — in the
 * Grouped style as an accent-tinted capsule (v0.3.17), in the pack
 * styles as the pack-dressed text chip — and the card's sub-line
 * carries only the provider, so the size appears exactly once.
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun BadgeStrip(
    facts: StreamFacts,
    config: StreamCapsuleConfig = StreamCapsuleConfig(),
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
) {
    if (!facts.hasFacts && trailing == null) return
    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        if (config.style == BadgeStyle.GROUPED) {
            val accent = LocalPlavioAccent.current
            facts.groupedCapsules(config).forEach { (group, text) ->
                StreamFactCapsule(
                    text,
                    // v0.3.17: the SIZE group rides as its own capsule
                    // in the user's accent (the Nuvio-style size chip),
                    // not in the card's sub-line — it still appears
                    // exactly once. Other groups keep their soft
                    // category tints.
                    tint =
                        if (group == StreamFactGroup.SIZE) {
                            accent.primary
                        } else {
                            group.capsuleTint()
                        },
                )
            }
            trailing?.invoke()
            return@FlowRow
        }
        val dir = config.style.assetDir
        if (dir != null) {
            streamBadgeKeys(facts, config).forEach { key ->
                BadgeArtwork(config.style, dir, key)
            }
            if (config.shows(StreamFactGroup.SIZE)) {
                facts.size?.let { BadgeSizeChip(config.style, it) }
            }
        }
        trailing?.invoke()
    }
}

/**
 * The stream card's download action: no separate button column — a
 * capsule that rides LAST in the badge row, dressed by the SAME style
 * as the facts beside it (mobile StreamDownloadCapsule semantics).
 * Grouped = the TV-glass capsule; Elite = a self-contained dark chip;
 * Nard = a filled chip in the pack's blue; Gold = bare gold wordmark
 * style; Minimalist = white outline chip. On TV it is a focusable
 * tv-material3 [Surface] with a focused state, like the Sources
 * addon tabs.
 */
@Composable
fun StreamDownloadCapsule(
    style: BadgeStyle,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    @Composable
    fun Content() {
        // The Surface's stateful content colour (gold for the Gold
        // style, white otherwise, inverted while focused).
        val tint = androidx.tv.material3.LocalContentColor.current
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Icon(
                PlavioIcons.Download,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(12.dp),
            )
            Text(
                stringResource(R.string.plavio_download_action),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = tint,
                maxLines = 1,
            )
        }
    }
    val dim = if (enabled) 1f else 0.4f
    val shape =
        when (style) {
            BadgeStyle.GROUPED -> RoundedCornerShape(50)
            BadgeStyle.MINIMALIST -> RoundedCornerShape(10.dp)
            else -> RoundedCornerShape(8.dp)
        }
    val containerColor =
        when (style) {
            BadgeStyle.GROUPED -> PlavioOnyx.GlassFill
            BadgeStyle.ELITE -> Color.Black.copy(alpha = 0.55f)
            BadgeStyle.NARD -> Color(0xFF1976D2)
            BadgeStyle.GOLD -> Color.Transparent
            BadgeStyle.MINIMALIST -> Color.Transparent
        }
    val contentColor =
        when (style) {
            BadgeStyle.GOLD -> Color(0xFFFFBE01)
            BadgeStyle.GROUPED -> PlavioOnyx.TextPrimary
            else -> Color.White
        }
    val borderColor =
        when (style) {
            BadgeStyle.GROUPED -> PlavioOnyx.GlassBorder
            BadgeStyle.ELITE -> Color.White.copy(alpha = 0.25f)
            BadgeStyle.MINIMALIST -> Color.White.copy(alpha = 0.75f)
            else -> Color.Transparent
        }
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.alpha(dim),
        shape = ClickableSurfaceDefaults.shape(shape = shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = containerColor,
                contentColor = contentColor,
                // Focus = the accent ring in the border below
                // only; the badge keeps its own colours when focused.
                focusedContainerColor = containerColor,
                focusedContentColor = contentColor,
                pressedContainerColor = containerColor,
                pressedContentColor = contentColor,
                disabledContainerColor = containerColor,
                disabledContentColor = contentColor,
            ),
        border =
            ClickableSurfaceDefaults.border(
                border = Border(border = androidx.compose.foundation.BorderStroke(1.dp, borderColor), shape = shape),
                focusedBorder =
                    Border(
                        border =
                            androidx.compose.foundation.BorderStroke(
                                // Standard accent focus ring.
                                2.5.dp,
                                LocalPlavioAccent.current.primary,
                            ),
                        shape = shape,
                    ),
            ),
    ) {
        Box(Modifier.padding(horizontal = 7.dp, vertical = 3.dp)) {
            Content()
        }
    }
}
