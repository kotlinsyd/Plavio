package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.download.DownloadEntry
import com.github.damontecres.wholphin.plavio.download.DownloadStatus
import kotlinx.coroutines.launch

/**
 * Downloads tab: everything the download manager holds — in-progress
 * downloads with live progress and pause/resume, finished titles ready
 * to play offline, and delete for both. Mirrors the phone's Downloads
 * screen in TV form.
 *
 * Focus (v0.3.19): a row used to be ONE clickable tv Card with the
 * pause/resume and delete buttons nested inside it — a focusable
 * nested inside the element that already holds focus is a stop the
 * D-pad can never reach (directional focus search never descends
 * into the bounds of the focused element; the same defect the
 * Streams rows had until v0.3.15), so the buttons existed but the
 * remote could not land on them, and the row's own click (play /
 * resume) was the only action — for a DOWNLOADING row a no-op. The
 * row is now a NON-clickable frame with the Card's exact rest
 * visuals holding sibling focus stops: the play area (poster +
 * title block; clicking plays a finished title / resumes a paused
 * one, as the Card did) and the action buttons beside it. While the
 * play area holds focus the frame draws the same 2.5dp accent ring
 * the focused Card used to draw. Opening the tab also lands focus
 * on the first row (the Live/Home screens do the same).
 */
@Composable
fun PlavioDownloadsScreen(
    onPlay: (PlaybackRequest) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioDownloadsViewModel = hiltViewModel(),
) {
    val entries by viewModel.entries.collectAsState()
    // First-row focus grab, keyed on the list becoming non-empty —
    // NOT on the list itself: the manager republishes the entries
    // on every progress tick, and re-firing on each one would yank
    // focus back to row 1 while the user walks the list.
    val firstFocus = remember { FocusRequester() }
    // v0.3.14: the shared landing primitive against a screen claim —
    // the blind burst it replaces could fire its later shots after
    // the user had already taken the remote elsewhere in the list.
    var downloadsClaimed by remember { mutableStateOf(false) }
    LaunchedEffect(entries.isNotEmpty()) {
        if (entries.isNotEmpty()) {
            landFocus(firstFocus, isClaimed = { downloadsClaimed }, attempts = 6, delayMs = 120)
        } else {
            downloadsClaimed = false
        }
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    val entryScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            entryScope.launch {
                downloadsClaimed = false
                landFocus(firstFocus, isClaimed = { downloadsClaimed }, attempts = 6, delayMs = 130)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) downloadsClaimed = true }
                // v0.3.12: the brand lockup FLOATS (no width is
                // reserved for it anywhere), but text still never
                // runs under it — this top offset keeps the heading
                // below the lockup's band, like every screen's.
                .padding(top = 72.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_nav_downloads),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(end = 48.dp),
        )
        // The sample's summary line: count · space used · space free.
        val context = LocalContext.current
        val summary =
            remember(entries) {
                val usedBytes = entries.sumOf { maxOf(it.downloadedBytes, 0L) }
                val stat = android.os.StatFs(context.filesDir.absolutePath)
                val freeBytes = stat.availableBytes
                "${entries.size} downloads · ${formatBytes(usedBytes)} · ${formatBytes(freeBytes)} free"
            }
        Text(
            text = summary,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(end = 48.dp, top = 4.dp, bottom = 4.dp),
        )
        if (entries.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(R.string.plavio_downloads_empty),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 48.dp),
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(end = 40.dp, top = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(entries, key = { _, entry -> entry.id }) { index, entry ->
                    DownloadRow(
                        entry = entry,
                        onPlay = { viewModel.playRequest(entry)?.let(onPlay) },
                        onPause = { viewModel.pause(entry.id) },
                        onResume = { viewModel.resume(entry.id) },
                        onDelete = { viewModel.delete(entry.id) },
                        firstFocus = if (index == 0) firstFocus else null,
                    )
                }
            }
        }
    }
}

@Composable
private fun DownloadRow(
    entry: DownloadEntry,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onDelete: () -> Unit,
    firstFocus: FocusRequester? = null,
) {
    // The frame's ring follows the play area's focus (accent ring
    // while it holds focus, the rest hairline otherwise — including
    // while an action button holds focus, when the button's own
    // ring is the signal). Same treatment as the Streams rows.
    var playFocused by remember { mutableStateOf(false) }
    val accent = LocalPlavioAccent.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = PlavioPanelShape,
        colors =
            SurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelFramed,
                contentColor = PlavioOnyx.TextPrimary,
            ),
        border =
            if (playFocused) {
                Border(
                    border = BorderStroke(2.5.dp, accent.primary),
                    shape = PlavioPanelShape,
                )
            } else {
                Border(
                    border = BorderStroke(1.dp, PlavioOnyx.PanelBorder),
                    shape = PlavioPanelShape,
                )
            },
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DownloadPlayArea(
                // The old Card's click mapping, unchanged: a finished
                // title plays; anything else resumes (a no-op from
                // the manager for a DOWNLOADING row — Pause is the
                // button beside it now, and reachable).
                onClick = if (entry.status == DownloadStatus.COMPLETED) onPlay else onResume,
                onFocusChanged = { playFocused = it },
                modifier = Modifier.weight(1f),
                focusRequester = firstFocus,
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (entry.poster != null) {
                        AsyncImage(
                            model =
                                ImageRequest
                                    .Builder(LocalContext.current)
                                    .data(entry.poster)
                                    .size(160, 240)
                                    .crossfade(false)
                                    .build(),
                            contentDescription = entry.title,
                            contentScale = ContentScale.Crop,
                            modifier =
                                Modifier
                                    .width(52.dp)
                                    .height(78.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                        )
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = entry.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = statusText(entry),
                            style = MaterialTheme.typography.bodyMedium,
                            // State colours (v0.3.21, the sample):
                            // amber while downloading, green when
                            // complete, grey when paused, red on failure.
                            color =
                                when (entry.status) {
                                    DownloadStatus.FAILED -> MaterialTheme.colorScheme.error
                                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED ->
                                        Color(0xFFF5B84C)
                                    DownloadStatus.COMPLETED -> PlavioOnyx.CachedGreen
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (entry.status == DownloadStatus.DOWNLOADING ||
                            entry.status == DownloadStatus.PAUSED ||
                            entry.status == DownloadStatus.QUEUED ||
                            entry.status == DownloadStatus.COMPLETED
                        ) {
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                            ) {
                                Box(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth(
                                                if (entry.status == DownloadStatus.COMPLETED) {
                                                    1f
                                                } else {
                                                    entry.progressFraction.coerceIn(0.02f, 1f)
                                                },
                                            )
                                            .height(5.dp)
                                            .background(
                                                when (entry.status) {
                                                    DownloadStatus.COMPLETED -> PlavioOnyx.CachedGreen
                                                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED ->
                                                        Color(0xFFF5B84C)
                                                    else -> PlavioOnyx.TextSecondary
                                                },
                                                RoundedCornerShape(50),
                                            ),
                                )
                            }
                        }
                    }
                }
            }
            // Fixed word capsules per state (v0.3.21, the sample):
            // ONE size (110×40) for every action on every row.
            when (entry.status) {
                DownloadStatus.COMPLETED -> {
                    PlavioFixedButton(
                        text = stringResource(R.string.plavio_play),
                        onClick = onPlay,
                        kind = PlavioButtonKind.Primary,
                        modifier = Modifier.width(110.dp),
                    )
                }
                DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED -> {
                    PlavioFixedButton(
                        text = stringResource(R.string.plavio_downloads_pause),
                        onClick = onPause,
                        modifier = Modifier.width(110.dp),
                    )
                }
                DownloadStatus.PAUSED, DownloadStatus.FAILED -> {
                    PlavioFixedButton(
                        text = stringResource(R.string.plavio_downloads_resume),
                        onClick = onResume,
                        modifier = Modifier.width(110.dp),
                    )
                }
            }
            // Remove doubles as Cancel for an in-progress download:
            // the manager's delete IS its cancel (stop the job, drop
            // the entry, delete the partial file) — the phone's
            // semantics exactly (its cancel and delete do the same).
            PlavioFixedButton(
                text = stringResource(R.string.plavio_addons_remove),
                onClick = onDelete,
                kind = PlavioButtonKind.Danger,
                modifier = Modifier.width(110.dp),
            )
        }
    }
}

/**
 * The row's play stop: a clickable Surface over the poster + title
 * block only, fully transparent in every state (it draws nothing —
 * its focus is signalled by the frame's ring), so it and the action
 * buttons are SIBLING focus stops the D-pad can walk between. A
 * local copy of the Streams rows' StreamPlayArea pattern.
 */
@Composable
private fun DownloadPlayArea(
    onClick: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier =
            modifier
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                )
                .onFocusChanged { state -> onFocusChanged(state.isFocused) },
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(8.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border =
            ClickableSurfaceDefaults.border(
                border = Border.None,
                focusedBorder = Border.None,
                pressedBorder = Border.None,
            ),
    ) {
        // The tv Surface's content slot is BoxScope.() -> Unit;
        // invoke the plain content lambda inside it (the same shape
        // as the Streams rows' StreamPlayArea).
        content()
    }
}

private fun statusText(entry: DownloadEntry): String =
    when (entry.status) {
        DownloadStatus.COMPLETED -> "Downloaded · ${formatBytes(entry.totalBytes)}"
        DownloadStatus.DOWNLOADING ->
            if (entry.isHls && entry.totalBytes in 1..100_000) {
                // HLS progress is counted in playlist parts, not bytes.
                "Downloading · ${percentText(entry)} · ${entry.downloadedBytes} of ${entry.totalBytes} parts"
            } else {
                "Downloading · ${percentText(entry)} · ${formatBytes(entry.downloadedBytes)} of ${formatBytes(entry.totalBytes)}"
            }
        DownloadStatus.PAUSED ->
            "Paused · ${percentText(entry)} · ${formatBytes(entry.downloadedBytes)}"
        DownloadStatus.QUEUED -> "Waiting…"
        DownloadStatus.FAILED -> entry.error ?: "Download failed"
    }

/** "42%" for an entry with a known total; "" (and no dangling separator) without one. */
private fun percentText(entry: DownloadEntry): String =
    if (entry.totalBytes > 0) {
        "${(entry.progressFraction * 100).toInt()}%"
    } else {
        "…"
    }

private fun formatBytes(bytes: Long): String =
    when {
        bytes < 0 -> "?"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
        else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
    }
