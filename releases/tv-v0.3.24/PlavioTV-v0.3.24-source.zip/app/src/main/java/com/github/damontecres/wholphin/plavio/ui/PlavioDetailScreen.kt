package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import kotlinx.coroutines.launch
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CastMember
import com.github.damontecres.wholphin.plavio.MetaDetail
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.RelatedSection
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.ui.components.Button

/**
 * Detail page for a catalog item — phone parity in TV form: backdrop
 * header, poster card + fact pills (year, ★ rating, runtime,
 * certification, status, network), Watch Now (autoplays the best
 * stream, like the phone) + Sources, the synopsis, the cast (→ actor
 * pages), episodes for series, and the More Like This / More From rows
 * that follow whichever addon serves the title.
 */
@Composable
fun PlavioDetailScreen(
    destination: PlavioDestination.Detail,
    onWatchNow: (PlaybackRequest) -> Unit,
    onWatchMovie: (MetaDetail) -> Unit,
    onEpisodeClick: (MetaDetail, Video) -> Unit,
    onActorClick: (CastMember) -> Unit,
    onRelatedClick: (MetaPreview) -> Unit,
    modifier: Modifier = Modifier,
    /** v0.3.14 (focus rebuild): the armed restore record for this
     * page, held by the root so it survives this screen being
     * disposed under a pushed child; [onArmRestore] writes/clears
     * it. See PlavioFocus.kt — arm-at-click, fire-once-on-return,
     * cancelled by any focus the user takes himself. */
    restoreRecord: DetailRestore? = null,
    onArmRestore: (DetailRestore?) -> Unit = {},
    viewModel: PlavioDetailViewModel =
        hiltViewModel(key = "detail|${destination.baseUrl}|${destination.type}|${destination.id}"),
) {
    LaunchedEffect(destination) {
        viewModel.load(destination.baseUrl, destination.type, destination.id)
    }
    val state by viewModel.state.collectAsState()
    val watchNow by viewModel.watchNow.collectAsState()
    val autoplay by viewModel.autoplayBestStream.collectAsState()
    val myListKeys by viewModel.myListKeys.collectAsState()
    val episodeProgress by viewModel.episodeProgress.collectAsState()
    val sourcesState by viewModel.sources.collectAsState()

    // The Sources popup owns Back while it is open (v0.3.22).
    androidx.activity.compose.BackHandler(enabled = sourcesState is DetailSourcesState.Open) {
        viewModel.closeSources()
    }

    // The full-summary overlay (v0.3.11): owns Back while open, and
    // closing it returns focus to the Read more button that opened
    // it — the same trap/restore discipline as the Sources popup.
    var summaryOpen by remember { mutableStateOf(false) }
    val readMoreFocus = remember { FocusRequester() }
    androidx.activity.compose.BackHandler(enabled = summaryOpen) {
        summaryOpen = false
    }
    // Focus anchors for the page's armed-restore discipline
    // (v0.3.14 — see the machine in DetailContent). The Watch button
    // is the page's home position and the universal fallback: it is
    // ALWAYS composed on a loaded page, so a restore that ends there
    // can never strand the remote. The Read more button exists only
    // while a long synopsis is actually composed, so its presence
    // and landed state are tracked explicitly — a restore may aim
    // at it only while it is verifiably on screen.
    val watchFocus = remember { FocusRequester() }
    // State OBJECTS, not plain values: the retry loops read them
    // live from inside coroutines, where a captured value snapshot
    // would go stale the moment it matters most.
    val watchLandedState = remember { mutableStateOf(false) }
    val readMoreAttachedState = remember { mutableStateOf(false) }
    val readMoreLandedState = remember { mutableStateOf(false) }
    // The claim (v0.3.13's gate, v0.3.14's form — a FocusClaim from
    // the shared focus system, PlavioFocus.kt): it trips the moment
    // focus verifiably sits ANYWHERE inside this page (the root's
    // onFocusChanged below) or the viewer presses a navigation key
    // (the root's preview key handler — a Left press heading for the
    // rail is delivered to the in-page focused control first, so the
    // claim trips BEFORE focus leaves). Every landing on this page
    // runs through landFocus against this claim, so a landing stands
    // down the instant the viewer takes the remote — and an armed
    // restore (below) is cancelled by the same signal. There is no
    // standing restore/watchdog code on this page anymore: the
    // v0.3.12 helper that fought live navigation and the v0.3.13
    // loops that could strand focus on an off-screen Play button
    // are both deleted; returns are armed records, fired once.
    val detailClaim = remember { FocusClaim() }
    // The local mirror of the armed record: click handlers write it
    // (and the root's copy, via onArmRestore) at arm time; the
    // firing effects in DetailContent read and consume it.
    val armState = remember { mutableStateOf<DetailRestore?>(null) }
    fun arm(record: DetailRestore) {
        armState.value = record
        onArmRestore(record)
    }

    // Watch Now (v0.3.16, note 9 — Instant Play): the press is
    // Ready on the same frame with an unresolved request — the
    // player opens immediately and finds the streams inside itself.
    // (The picker fallback for "nothing playable" now lives in the
    // player: it swaps its Play entry for the Streams destination.)
    LaunchedEffect(watchNow) {
        val wn = watchNow
        if (wn is WatchNowState.Ready) {
            viewModel.consumeWatchNow()
            onWatchNow(wn.request)
        }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                // The claim gate's sensors (v0.3.13, see the states
                // above): focus anywhere inside the page claims it,
                // and any navigation key pressed while a page control
                // holds focus claims it too — the preview handler
                // sees the key on its way to the focused control,
                // before focus moves, so a landing loop can never
                // fire one more shot after the viewer has taken over.
                // Neither handler ever consumes an event.
                .onFocusChanged { if (it.hasFocus) detailClaim.claim() }
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        (
                            event.key == Key.DirectionUp ||
                                event.key == Key.DirectionDown ||
                                event.key == Key.DirectionLeft ||
                                event.key == Key.DirectionRight ||
                                event.key == Key.DirectionCenter ||
                                event.key == Key.Enter ||
                                event.key == Key.NumPadEnter
                        )
                    ) {
                        detailClaim.stampKey()
                    }
                    false
                },
    ) {
        when (val st = state) {
            PlavioDetailUiState.Loading -> {
                // v0.3.13: no more full-black "Loading…" screen. The
                // tapped card's own backdrop + name are already known
                // (they ride the destination), so the page opens on
                // the title's art with a skeleton where the facts and
                // actions will land — the loaded content then replaces
                // it in place.
                DetailLoadingLayer(destination = destination)
            }

            PlavioDetailUiState.Unavailable -> {
                Text(
                    text = stringResource(R.string.plavio_detail_unavailable),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            is PlavioDetailUiState.Loaded -> {
                DetailContent(
                    meta = st.meta,
                    related = st.related,
                    inMyList = "${st.meta.type}|${st.meta.id}" in myListKeys,
                    onToggleMyList = { viewModel.toggleMyList(st.meta) },
                    episodeProgress = episodeProgress,
                    onWatchNowClick = {
                        if (autoplay) {
                            viewModel.watchNow(st.meta, firstEpisode(st.meta))
                        } else {
                            val target = firstEpisode(st.meta)
                            if (st.meta.type == "series" && target != null) {
                                onEpisodeClick(st.meta, target)
                            } else {
                                onWatchMovie(st.meta)
                            }
                        }
                    },
                    onSourcesClick = {
                        val target = firstEpisode(st.meta)
                        if (st.meta.type == "series" && target != null) {
                            onEpisodeClick(st.meta, target)
                        } else {
                            onWatchMovie(st.meta)
                        }
                    },
                    sourcesOpen = sourcesState is DetailSourcesState.Open,
                    summaryOpen = summaryOpen,
                    onReadMoreClick = { summaryOpen = true },
                    readMoreFocus = readMoreFocus,
                    watchFocus = watchFocus,
                    watchLandedState = watchLandedState,
                    readMoreLandedState = readMoreLandedState,
                    readMoreAttachedState = readMoreAttachedState,
                    claim = detailClaim,
                    armState = armState,
                    initialRecord = restoreRecord,
                    onConsumeRecord = { onArmRestore(null) },
                    arm = ::arm,
                    onReadMorePresenceChange = { attached ->
                        readMoreAttachedState.value = attached
                        if (!attached) readMoreLandedState.value = false
                    },
                    onReadMoreLanded = { readMoreLandedState.value = true },
                    onSourcesButtonClick = {
                        viewModel.openSources(st.meta, firstEpisode(st.meta))
                    },
                    autoplay = autoplay,
                    onEpisodePlay = { m, v -> viewModel.watchNow(m, v) },
                    onEpisodeClick = onEpisodeClick,
                    onActorClick = onActorClick,
                    onRelatedClick = onRelatedClick,
                )
            }
        }

        // The Sources popup (v0.3.22): the player's OWN SourcesPanel
        // component, overlaid on the page exactly as it overlays the
        // player — the owner's word was same way, same style, not a
        // separate screen. A pick plays through the Watch Now path.
        val openSources = sourcesState as? DetailSourcesState.Open
        val loadedMeta = (state as? PlavioDetailUiState.Loaded)?.meta
        if (openSources != null && loadedMeta != null) {
            if (openSources.streams.isEmpty() && openSources.loading) {
                Row(
                    modifier =
                        Modifier
                            .align(Alignment.CenterEnd)
                            .width(440.dp)
                            .padding(end = 48.dp)
                            .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                            .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                            .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    OrbitLoader(modifier = Modifier.size(28.dp), alwaysAnimate = true)
                    Text(
                        text = stringResource(R.string.plavio_detail_finding_stream),
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                    )
                }
            } else {
                SourcesPanel(
                    streams = openSources.streams,
                    currentUrl = "",
                    onPick = { stream ->
                        // Arm BEFORE leaving (v0.3.14): this pick
                        // goes straight to the player; the return
                        // lands on the page's home position.
                        arm(DetailRestore.Watch)
                        val request = viewModel.pickSource(loadedMeta, stream)
                        viewModel.closeSources()
                        if (request != null) onWatchNow(request)
                    },
                    onReload = {
                        viewModel.reloadSources(loadedMeta, firstEpisode(loadedMeta))
                    },
                    modifier = Modifier.align(Alignment.CenterEnd),
                )
            }
        }

        // The full-summary overlay (v0.3.11): the whole synopsis in a
        // scrollable panel over a scrim — see SummaryOverlay.
        val summaryText = loadedMeta?.description?.takeIf { it.isNotBlank() }
        if (summaryOpen && summaryText != null) {
            SummaryOverlay(
                title = stringResource(R.string.plavio_detail_summary),
                text = summaryText,
                onClose = { summaryOpen = false },
            )
        }
    }
}

/**
 * The full synopsis, readable by remote (v0.3.11). The page's summary
 * block used to expand IN PLACE as one giant focusable surface: the
 * expanded item grew taller than the viewport, focus landed on the
 * text box itself, and Up/Left from the Play row had nowhere sane to
 * go — users backed out of the page to escape (the owner's report).
 * Now the page's text is never a focus stop; this overlay carries the
 * full text in a focusable scroll area (D-pad Up/Down scrolls while
 * there is more to scroll, then falls through to the Close button),
 * Back closes it, and focus returns to the Read more button.
 */
@Composable
private fun SummaryOverlay(
    title: String,
    text: String,
    onClose: () -> Unit,
) {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val textFocus = remember { FocusRequester() }
    // Landed-checked entry (v0.3.12): stop the moment the text
    // verifiably holds focus — the v0.3.11 loop fired all 8 shots
    // blind, and a shot landing AFTER the user had already moved to
    // the Close button dragged focus back onto the text.
    var textLanded by remember { mutableStateOf(false) }
    // v0.3.13: the loop also stands down the moment the viewer
    // presses a navigation key (the overlay root's preview handler
    // stamps it) — pressing Down toward Close inside the landing
    // window must never be answered by another shot at the text.
    var lastKeyMs by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        // v0.3.14: the shared landing primitive — same semantics as
        // the hand-rolled loop it replaces (stop on the text's own
        // landed flag or on any navigation keypress).
        val keyAtStart = lastKeyMs
        landFocus(
            requester = textFocus,
            isClaimed = { textLanded || lastKeyMs != keyAtStart },
            attempts = 10,
            delayMs = 120,
        )
    }
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown &&
                        (
                            event.key == Key.DirectionUp ||
                                event.key == Key.DirectionDown ||
                                event.key == Key.DirectionLeft ||
                                event.key == Key.DirectionRight ||
                                event.key == Key.DirectionCenter ||
                                event.key == Key.Enter ||
                                event.key == Key.NumPadEnter
                        )
                    ) {
                        lastKeyMs = android.os.SystemClock.uptimeMillis()
                    }
                    false
                },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier =
                Modifier
                    .width(760.dp)
                    .fillMaxHeight(0.84f)
                    .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                    .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                    .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier =
                    Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .focusRequester(textFocus)
                        .onFocusChanged { if (it.isFocused) textLanded = true }
                        .focusable()
                        .onPreviewKeyEvent { event ->
                            if (event.type != KeyEventType.KeyDown) {
                                false
                            } else {
                                when (event.key) {
                                    Key.DirectionDown ->
                                        if (scrollState.canScrollForward) {
                                            scope.launch {
                                                scrollState.scrollBy(160f)
                                            }
                                            true
                                        } else {
                                            false
                                        }
                                    Key.DirectionUp ->
                                        if (scrollState.canScrollBackward) {
                                            scope.launch {
                                                scrollState.scrollBy(-160f)
                                            }
                                            true
                                        } else {
                                            false
                                        }
                                    else -> false
                                }
                            }
                        },
            )
            PlavioFixedButton(
                text = stringResource(R.string.plavio_close),
                onClick = onClose,
                modifier = Modifier.width(150.dp),
            )
        }
    }
}

/**
 * Detail's loading face (v0.3.13): the preview backdrop/poster from
 * the tapped card under the same scrims the loaded header uses, the
 * title's name, and static skeleton bars where the fact pills and
 * action buttons will appear. Static on purpose — no shimmer tax on
 * a weak TV box.
 */
@Composable
private fun DetailLoadingLayer(destination: PlavioDestination.Detail) {
    val background = MaterialTheme.colorScheme.background
    Box(modifier = Modifier.fillMaxSize()) {
        val art = destination.previewBackground ?: destination.previewPoster
        if (art != null) {
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalContext.current)
                        .data(art)
                        .size(1280, 720)
                        .crossfade(false)
                        .build(),
                contentDescription = destination.previewName,
                contentScale = ContentScale.Crop,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .align(Alignment.TopStart),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                        .align(Alignment.TopStart)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, background),
                                startY = 120f,
                            ),
                        ),
            )
        }
        Column(
            modifier =
                Modifier
                    .align(Alignment.TopStart)
                    .padding(end = 48.dp, top = 24.dp, bottom = 24.dp)
                    // v0.3.12: the old extra 190dp top pad existed
                    // only to clear the brand lockup; the lockup
                    // floats now (reserves nothing), so the loading
                    // face starts at the normal top margin like the
                    // loaded hero.
                    .padding(top = 46.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (!destination.previewName.isNullOrBlank()) {
                Text(
                    text = destination.previewName ?: "",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            // Skeleton: fact-pill row + synopsis lines.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(4) {
                    Box(
                        modifier =
                            Modifier
                                .size(width = 64.dp, height = 26.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.10f)),
                    )
                }
            }
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth(0.62f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth(0.45f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.padding(top = 6.dp),
            ) {
                OrbitLoader(modifier = Modifier.size(32.dp))
                Text(
                    text = stringResource(R.string.plavio_detail_loading),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * v0.3.14: the old restoreDetailFocus helper that lived here is
 * DELETED. It was the v0.3.12 mechanism (primary/fallback request
 * bursts with landed flags) that fought live navigation on the
 * owner's TV, and its v0.3.13 claim-gated descendants could still
 * strand focus on an off-screen target. All Detail landings now go
 * through the armed-restore machine in DetailContent (arm-at-click
 * records fired once via the shared landFocus primitive — see
 * PlavioFocus.kt).
 */

/** The episode Watch Now targets: the first regular episode (season 1+ when present). */
private fun firstEpisode(meta: MetaDetail): Video? {
    if (meta.type != "series") return null
    val sorted = meta.videos.sortedWith(compareBy({ it.season }, { it.episode }))
    return sorted.firstOrNull { it.season >= 1 } ?: sorted.firstOrNull()
}

@Composable
private fun DetailContent(
    meta: MetaDetail,
    related: List<RelatedSection>,
    inMyList: Boolean,
    onToggleMyList: () -> Unit,
    episodeProgress: Map<String, Float>,
    onWatchNowClick: () -> Unit,
    onSourcesClick: () -> Unit,
    sourcesOpen: Boolean,
    summaryOpen: Boolean,
    onReadMoreClick: () -> Unit,
    readMoreFocus: FocusRequester,
    watchFocus: FocusRequester,
    watchLandedState: androidx.compose.runtime.MutableState<Boolean>,
    readMoreLandedState: androidx.compose.runtime.MutableState<Boolean>,
    readMoreAttachedState: androidx.compose.runtime.MutableState<Boolean>,
    claim: FocusClaim,
    armState: androidx.compose.runtime.MutableState<DetailRestore?>,
    initialRecord: DetailRestore?,
    onConsumeRecord: () -> Unit,
    arm: (DetailRestore) -> Unit,
    onReadMorePresenceChange: (Boolean) -> Unit,
    onReadMoreLanded: () -> Unit,
    onSourcesButtonClick: () -> Unit,
    autoplay: Boolean,
    onEpisodePlay: (MetaDetail, Video) -> Unit,
    onEpisodeClick: (MetaDetail, Video) -> Unit,
    onActorClick: (CastMember) -> Unit,
    onRelatedClick: (MetaPreview) -> Unit,
) {
    val background = MaterialTheme.colorScheme.background
    // Hero text margin (v0.3.12): v0.3.11 pushed this column to a
    // 190dp absolute start so it would clear the top-left brand
    // lockup. The lockup floats now and reserves nothing; the page
    // content starts at the shared margin (the root pad — exactly
    // beside the capsule), and the hero text keeps only its own
    // 24dp inset inside the hero, like the Home hero's. It sits at
    // the hero's bottom — far below the lockup's band — so no text
    // ever runs under the floating logo or the capsule.
    val seasons = meta.videos.groupBy { it.season }.toSortedMap()
    // Season capsule state lives HERE, in the composable body —
    // LazyListScope is not a composable context, so remember()
    // cannot be called from inside the list block.
    val seasonNumbers = seasons.keys.toList()
    var selectedSeason by remember(meta.id) {
        mutableStateOf(seasonNumbers.firstOrNull { it >= 1 } ?: seasonNumbers.firstOrNull() ?: 1)
    }
    // ---- The armed-restore machine (v0.3.14, the focus rebuild) --
    // Everything the v0.3.12 helper and the v0.3.13 loops did is
    // replaced by this: click handlers ARM a typed record (see the
    // arm() calls on the buttons/rows below) naming the exact target
    // to return to; the four sanctioned moments — page entry, the
    // playing→stopped flip, an overlay's close, the capsule's return
    // transfer — FIRE the record exactly once through landFocus.
    // Firing scrolls the target into the window BEFORE requesting
    // it, so a landing is never on an off-screen/invisible node (the
    // v0.3.13 failure: focus sat on a Play button nobody could see).
    // The claim cancels everything the moment the viewer takes the
    // remote himself. No other code on this page requests focus.
    val detailListState = androidx.compose.foundation.lazy.rememberLazyListState()
    val detailScope = rememberCoroutineScope()
    val sourcesBtnFocus = remember { FocusRequester() }
    var sourcesBtnLanded by remember { mutableStateOf(false) }
    val episodeRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val castRequesters = remember { mutableMapOf<Int, FocusRequester>() }
    val relatedRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val castRowState = androidx.compose.foundation.lazy.rememberLazyListState()
    val relatedRowStates =
        remember { mutableMapOf<String, androidx.compose.foundation.lazy.LazyListState>() }
    fun episodeRequester(id: String): FocusRequester =
        episodeRequesters.getOrPut(id) { FocusRequester() }

    // LazyColumn item indexes, mirroring the item order emitted
    // below: hero (0), info+actions (1), summary?, cast?,
    // season header?, episode rows…, related sections…
    fun episodeItemIndex(position: Int): Int {
        var idx = 2
        if (!meta.description.isNullOrBlank()) idx++
        if (meta.cast.isNotEmpty()) idx++
        idx++ // season capsules header
        return idx + position
    }

    fun castItemIndex(): Int {
        var idx = 2
        if (!meta.description.isNullOrBlank()) idx++
        return idx
    }

    fun relatedItemIndex(sectionPos: Int): Int {
        var idx = 2
        if (!meta.description.isNullOrBlank()) idx++
        if (meta.cast.isNotEmpty()) idx++
        if (meta.type == "series") {
            idx +=
                if (meta.videos.isEmpty()) {
                    1
                } else {
                    1 + (seasons[selectedSeason]?.size ?: 0)
                }
        }
        return idx + sectionPos
    }

    suspend fun fireRestore(record: DetailRestore) {
        claim.release()
        val stampAtStart = claim.lastKeyMs.value
        watchLandedState.value = false
        sourcesBtnLanded = false
        readMoreLandedState.value = false
        val done = { claim.claimed.value || claim.lastKeyMs.value != stampAtStart }
        suspend fun landWatch() {
            // v0.3.16 (note 7): INSTANT scroll, not animated. The
            // animated scroll took tens of frames on a scrolled-deep
            // page; the capsule exit's geometric rescue pushes began
            // mid-animation, landed on transient rows the scroll then
            // disposed, tripped this page's claim, and stood the
            // landing down — RIGHT from the capsule's lower buttons
            // "did nothing" (from Home it worked: its rescue landed
            // on the hero row the scroll never disposes). An instant
            // scroll puts the target in composition on the spot, the
            // landing fires while the list is still, and the rescue
            // is never needed. All restore branches scroll instantly
            // now; the landing TARGETS are unchanged (episode-exact
            // returns keep their exact rows).
            runCatching { detailListState.scrollToItem(1) }
            landFocus(watchFocus, isClaimed = { done() || watchLandedState.value })
        }
        when (record) {
            DetailRestore.Watch -> landWatch()

            is DetailRestore.Episode -> {
                var settled = false
                if (seasons.containsKey(record.season)) {
                    if (selectedSeason != record.season) {
                        selectedSeason = record.season
                        // Let the episode list recompose for the
                        // newly selected season before addressing it.
                        kotlinx.coroutines.delay(180)
                    }
                    val eps = (seasons[record.season] ?: emptyList()).sortedBy { it.episode }
                    val pos = eps.indexOfFirst { it.id == record.videoId }
                    if (pos >= 0) {
                        runCatching { detailListState.scrollToItem(episodeItemIndex(pos)) }
                        settled =
                            landFocus(episodeRequester(record.videoId), isClaimed = done)
                    }
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.CastMember -> {
                var settled = false
                val pos = meta.cast.indexOfFirst { it.id == record.memberId }
                if (pos >= 0) {
                    runCatching { detailListState.scrollToItem(castItemIndex()) }
                    runCatching { castRowState.scrollToItem(pos) }
                    settled =
                        landFocus(
                            castRequesters.getOrPut(record.memberId) { FocusRequester() },
                            isClaimed = done,
                        )
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.Related -> {
                var settled = false
                for ((sectionPos, section) in related.withIndex()) {
                    val pos =
                        section.metas.indexOfFirst {
                            it.type == record.type && it.id == record.id
                        }
                    if (pos < 0) continue
                    runCatching {
                        detailListState.scrollToItem(relatedItemIndex(sectionPos))
                    }
                    runCatching {
                        relatedRowStates
                            .getOrPut(section.id) {
                                androidx.compose.foundation.lazy.LazyListState()
                            }
                            .scrollToItem(pos)
                    }
                    settled =
                        landFocus(
                            relatedRequesters.getOrPut("${record.type}|${record.id}") {
                                FocusRequester()
                            },
                            isClaimed = done,
                        )
                    break
                }
                if (!settled && !done()) landWatch()
            }

            is DetailRestore.Opener -> {
                val settled =
                    when (record.which) {
                        "sources" ->
                            landFocus(
                                sourcesBtnFocus,
                                isClaimed = { done() || sourcesBtnLanded },
                            )
                        else ->
                            if (readMoreAttachedState.value) {
                                landFocus(
                                    readMoreFocus,
                                    isClaimed = { done() || readMoreLandedState.value },
                                )
                            } else {
                                false
                            }
                    }
                if (!settled && !done()) landWatch()
            }
        }
    }

    fun consume(record: DetailRestore?) {
        if (record != null) {
            armState.value = null
            onConsumeRecord()
        }
    }

    // Sanctioned moment 1 — page entry: fire the record a pushed
    // child left armed (return from Streams/Actor/related Detail),
    // else the default home-position landing.
    LaunchedEffect(meta.id) {
        val record = armState.value ?: initialRecord
        fireRestore(record ?: DetailRestore.Watch)
        consume(record)
    }
    // Sanctioned moment 2 — the playing→stopped flip: the player
    // tree took focus away with it; fire what the play click armed
    // (the played episode's own row for episodes, Watch otherwise).
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            val record = armState.value
            fireRestore(record ?: DetailRestore.Watch)
            consume(record)
        }
    }
    // Sanctioned moment 3 — an overlay closes: fire ONLY its opener
    // record. (A Sources pick arms Watch instead and closes into the
    // player; moment 2 owns that return, so this effect deliberately
    // leaves a Watch arm untouched.)
    var sourcesWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(sourcesOpen) {
        if (sourcesOpen) {
            sourcesWasOpen = true
        } else if (sourcesWasOpen) {
            sourcesWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "sources") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    var summaryWasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(summaryOpen) {
        if (summaryOpen) {
            summaryWasOpen = true
        } else if (summaryWasOpen) {
            summaryWasOpen = false
            val record = armState.value
            if (record is DetailRestore.Opener && record.which == "summary") {
                fireRestore(record)
                consume(record)
            }
        }
    }
    // Sanctioned moment 4 — the capsule's return transfer: the
    // scripted trip back from the side capsule lands HERE, on the
    // armed target or the visible home position (fireRestore
    // scrolls first) — never on geometric luck, never invisible.
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            detailScope.launch {
                val record = armState.value
                fireRestore(record ?: DetailRestore.Watch)
                consume(record)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    LazyColumn(
        state = detailListState,
        modifier =
            Modifier
                .fillMaxSize()
                .focusProperties { canFocus = !sourcesOpen && !summaryOpen },
        contentPadding = PaddingValues(bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            // v0.3.20 (the D clear-space rule, owner's locked logo
            // pick): the hero's title art (backdrop, title/logo)
            // starts BELOW the clear top strip (PlavioChrome
            // .clearTop), so no title art can ever reach the
            // floating brand icon's band at the top-left. The page
            // background fills the strip itself.
            Spacer(Modifier.height(PlavioChrome.clearTop))
        }
        item {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(340.dp),
            ) {
                val backdrop = meta.background ?: meta.poster
                if (backdrop != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(backdrop)
                                .size(1280, 720)
                                .crossfade(false)
                                .build(),
                        contentDescription = meta.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, background),
                                    startY = 120f,
                                ),
                            ),
                )
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors =
                                        listOf(
                                            Color.Black.copy(alpha = 0.5f),
                                            Color.Transparent,
                                        ),
                                ),
                            ),
                )
                Column(
                    modifier =
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 24.dp, end = 48.dp, top = 24.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    // Overhaul (v0.3.11): the samples' pink kicker line.
                    val kicker =
                        listOfNotNull(
                            meta.type.takeIf { it.isNotBlank() }?.uppercase(),
                            meta.genres.firstOrNull()?.uppercase(),
                        ).joinToString("  ·  ")
                    if (kicker.isNotBlank()) {
                        Text(
                            text = kicker,
                            style = MaterialTheme.typography.labelLarge,
                            letterSpacing = 2.sp,
                            fontWeight = FontWeight.Bold,
                            color = LocalPlavioAccent.current.primary,
                        )
                    }
                    // Title logo art, progressive (v0.3.17): the TEXT
                    // title renders first and the logo replaces it
                    // only once it has actually loaded — a slow or
                    // dead logo URL can never leave the title area
                    // blank, and the screen never waits on the image.
                    val logoPainter =
                        coil3.compose.rememberAsyncImagePainter(
                            model =
                                ImageRequest
                                    .Builder(LocalContext.current)
                                    .data(meta.logo)
                                    .size(600, 144)
                                    .crossfade(false)
                                    .build(),
                        )
                    val logoState by logoPainter.state.collectAsState()
                    if (meta.logo != null &&
                        logoState is coil3.compose.AsyncImagePainter.State.Success
                    ) {
                        androidx.compose.foundation.Image(
                            painter = logoPainter,
                            contentDescription = meta.name,
                            contentScale = ContentScale.Fit,
                            modifier =
                                Modifier
                                    .height(72.dp)
                                    .width(300.dp),
                        )
                    } else {
                        Text(
                            text = meta.name,
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    // v0.3.19 organisation: the hero carries ONLY
                    // the kicker + title/logo. The facts line that
                    // used to repeat down here (year • rating •
                    // runtime • genres) duplicated the pills block
                    // below — every fact now lives in exactly one
                    // place: the info block under the hero.
                }
            }
        }

        // Poster card + fact pills + actions
        item {
            Row(
                modifier = Modifier.padding(end = 48.dp, top = 8.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
            ) {
                if (meta.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(meta.poster)
                                .size(220, 330)
                                .crossfade(false)
                                .build(),
                        contentDescription = meta.name,
                        contentScale = ContentScale.Crop,
                        modifier =
                            Modifier
                                .width(110.dp)
                                .aspectRatio(2f / 3f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(1.dp, PlavioOnyx.PanelBorder, RoundedCornerShape(14.dp)),
                    )
                }
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    // Multi-source ratings row (v0.3.17): renders ONLY
                    // when the serving meta provides 2+ ratings — the
                    // badges then take the single IMDb pill's place.
                    // Single-rating titles keep today's display as-is.
                    val showRatings = meta.ratings.size >= 2
                    if (showRatings) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            meta.ratings.take(5).forEach { rating -> RatingBadge(rating) }
                        }
                    }
                    // Facts + genres in ONE flow row (v0.3.21, the
                    // sample's rule): every fact pill and every genre
                    // pill wraps in a single block — nothing dropped,
                    // nothing in a second row.
                    val pills =
                        listOfNotNull(
                            meta.releaseInfo,
                            meta.imdbRating?.takeIf { !showRatings }?.let { "★ $it IMDb" },
                            meta.runtime,
                            meta.certification,
                            meta.status,
                            meta.network,
                            meta.country,
                        ) + meta.genres
                    if (pills.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            pills.forEach { pill -> FactPill(text = pill) }
                        }
                    }
                    // The sample's three fixed capsules: Play /
                    // + My List / Download. Download opens the
                    // streams screen, where every row carries its
                    // own Download capsule (the real download flow).
                    // v0.3.17 (owner note 3): the four actions share
                    // the column width by weight with a 150dp cap —
                    // as four FIXED 150dp capsules they needed 636dp,
                    // and on narrower screens (720p-class panels at
                    // TV densities) the column beside the poster
                    // offers less, which pushed the LAST capsule
                    // (Sources) off the right edge entirely: present
                    // in the build, invisible on the TV. Weighted
                    // with a cap, the row looks identical wherever
                    // 636dp fits and simply tightens where it doesn't
                    // — all four buttons always on screen.
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        // v0.3.16 (notes 2 + 9): the Play capsule
                        // rests ghost-style and takes the travelling
                        // white fill on focus (Sample A), and a press
                        // opens the player IMMEDIATELY — the button
                        // never shows a "Finding…" state and is never
                        // disabled by resolution; the finding happens
                        // inside the player.
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_play),
                            onClick = {
                                arm(DetailRestore.Watch)
                                onWatchNowClick()
                            },
                            kind = PlavioButtonKind.Primary,
                            whiteFocus = true,
                            leadingIcon = Icons.Filled.PlayArrow,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .widthIn(max = 150.dp)
                                    .onFocusChanged { if (it.isFocused) watchLandedState.value = true },
                            focusRequester = watchFocus,
                        )
                        PlavioFixedButton(
                            text =
                                stringResource(
                                    if (inMyList) {
                                        R.string.plavio_in_my_list
                                    } else {
                                        R.string.plavio_add_my_list
                                    },
                                ),
                            onClick = onToggleMyList,
                            whiteFocus = true,
                            modifier = Modifier.weight(1f).widthIn(max = 150.dp),
                        )
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_download),
                            whiteFocus = true,
                            onClick = {
                                // Download leaves for the streams page
                                // of the first episode — arm its row.
                                val first = firstEpisode(meta)
                                arm(
                                    if (first != null) {
                                        DetailRestore.Episode(first.id, first.season)
                                    } else {
                                        DetailRestore.Watch
                                    },
                                )
                                onSourcesClick()
                            },
                            leadingIcon = PlavioIcons.Download,
                            modifier = Modifier.weight(1f).widthIn(max = 150.dp),
                        )
                        // Source (v0.3.22): opens the player's own
                        // sources popup over this page (see the
                        // overlay in PlavioDetailScreen) — a manual
                        // source pick without leaving the page.
                        // v0.3.20 (owner photo verdict): whiteFocus —
                        // this was the ONLY button of the row without
                        // it, so on focus it showed just the white
                        // outline ring over a dark inside while Play /
                        // My List / Download swept to the full white
                        // fill. Same shared mechanism, same fill now.
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_player_sources),
                            onClick = {
                                arm(DetailRestore.Opener("sources"))
                                onSourcesButtonClick()
                            },
                            whiteFocus = true,
                            leadingIcon = Icons.AutoMirrored.Filled.List,
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .widthIn(max = 150.dp)
                                    .onFocusChanged { if (it.isFocused) sourcesBtnLanded = true },
                            focusRequester = sourcesBtnFocus,
                        )
                    }
                }
            }
        }

        meta.description?.takeIf { it.isNotBlank() }?.let { description ->
            item {
                // Summary (v0.3.19 shape, v0.3.11 focus fix): a
                // headed section, collapsed to 4 lines with the
                // accent "more" suffix as a visual hint. The text
                // itself is NEVER a focus stop: the v0.3.19 form made
                // the whole block one focusable surface that expanded
                // in place — the expanded item grew taller than the
                // viewport, focus sat on the text box, and Up/Left
                // from the Play row had nowhere sane to go (the
                // owner's stuck-remote report). The full text now
                // lives in the SummaryOverlay, opened by a real Read
                // more button under the text (shown only when the
                // text actually overflows, measured on the collapsed
                // state exactly like the phone).
                Column {
                    Text(
                        text = stringResource(R.string.plavio_detail_summary),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier =
                            Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                    )
                    var synopsisOverflows by remember(meta.id) { mutableStateOf(false) }
                    val accent = LocalPlavioAccent.current.primary
                    val moreText = stringResource(R.string.plavio_more)
                    val shown =
                        remember(description, synopsisOverflows, accent, moreText) {
                            buildAnnotatedString {
                                append(description.trim())
                                if (synopsisOverflows) {
                                    append("  ")
                                    withStyle(
                                        SpanStyle(color = accent, fontWeight = FontWeight.SemiBold),
                                    ) {
                                        append(moreText)
                                    }
                                }
                            }
                        }
                    Text(
                        text = shown,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                        onTextLayout = { layout ->
                            synopsisOverflows = layout.hasVisualOverflow
                        },
                        modifier =
                            Modifier.padding(end = 48.dp, top = 4.dp, bottom = 4.dp),
                    )
                    if (synopsisOverflows) {
                        // Presence + landed tracking (v0.3.12): the
                        // summary overlay's close-restore may aim at
                        // this button only while it is verifiably
                        // composed — with a SHORT synopsis the button
                        // never exists, and when this lazy item
                        // scrolls off it stops existing too. The
                        // v0.3.11 restore aimed at it unconditionally,
                        // and an unattached requester fails silently:
                        // the page could be left with nothing focused.
                        androidx.compose.runtime.DisposableEffect(meta.id) {
                            onReadMorePresenceChange(true)
                            onDispose { onReadMorePresenceChange(false) }
                        }
                        PlavioFixedButton(
                            text = stringResource(R.string.plavio_read_more),
                            onClick = {
                                arm(DetailRestore.Opener("summary"))
                                onReadMoreClick()
                            },
                            modifier =
                                Modifier
                                    .padding(top = 8.dp)
                                    .width(170.dp)
                                    .onFocusChanged { if (it.isFocused) onReadMoreLanded() },
                            focusRequester = readMoreFocus,
                        )
                    }
                }
            }
        }

        if (meta.cast.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.plavio_detail_cast),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier =
                            Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                    )
                    LazyRow(
                        state = castRowState,
                        contentPadding = PaddingValues(end = 40.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(
                            meta.cast,
                            key = { index, member -> "${member.id}|${member.name}|$index" },
                        ) { _, member ->
                            PersonCard(
                                member = member,
                                onClick = {
                                    arm(
                                        DetailRestore.CastMember(member.id, member.name),
                                    )
                                    onActorClick(member)
                                },
                                focusRequester =
                                    castRequesters.getOrPut(member.id) { FocusRequester() },
                            )
                        }
                    }
                }
            }
        }

        if (meta.type == "series") {
            if (meta.videos.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.plavio_detail_no_episodes),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 48.dp, top = 16.dp, bottom = 16.dp),
                    )
                }
            } else {
                // Season capsules (v0.3.21, the sample): one capsule
                // per season; the episode list shows the picked
                // season only. Default = the first regular season
                // (state hoisted to the composable body above).
                item(key = "season-capsules") {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = stringResource(R.string.plavio_detail_episodes),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier =
                                Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                        )
                        LazyRow(
                            contentPadding = PaddingValues(end = 48.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            items(seasonNumbers, key = { "season|$it" }) { season ->
                                PlavioFilterCapsule(
                                    text =
                                        if (season == 0) {
                                            stringResource(R.string.plavio_detail_specials)
                                        } else {
                                            "S$season"
                                        },
                                    selected = season == selectedSeason,
                                    onClick = { selectedSeason = season },
                                )
                            }
                        }
                    }
                }
                val episodes = (seasons[selectedSeason] ?: emptyList()).sortedBy { it.episode }
                itemsIndexed(
                    episodes,
                    key = { index, video -> "${video.id}|$index" },
                ) { _, video ->
                    EpisodeRow(
                        video = video,
                        progress = episodeProgress[video.id],
                        // Episode direct play (v0.3.10, user feedback):
                        // with autoplay on, tapping an episode PLAYS it
                        // (same rule as the Watch Now button) instead of
                        // opening the picker first. Autoplay off keeps
                        // today's behaviour — the picker for that episode.
                        onClick = {
                            // Arm BEFORE leaving (v0.3.14): whichever
                            // way this episode opens — direct play or
                            // the streams page — the return lands on
                            // THIS episode's row, not the page top.
                            arm(DetailRestore.Episode(video.id, video.season))
                            if (autoplay) {
                                onEpisodePlay(meta, video)
                            } else {
                                onEpisodeClick(meta, video)
                            }
                        },
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(end = 48.dp, top = 6.dp, bottom = 6.dp)
                                .focusRequester(episodeRequester(video.id)),
                    )
                }
            }
        }

        related.forEach { section ->
            item(key = "related|${section.id}") {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = section.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier =
                            Modifier.padding(end = 48.dp, top = 20.dp, bottom = 8.dp),
                    )
                    LazyRow(
                        state =
                            relatedRowStates.getOrPut(section.id) {
                                androidx.compose.foundation.lazy.LazyListState()
                            },
                        contentPadding = PaddingValues(end = 40.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(
                            section.metas,
                            key = { index, item -> "${item.type}|${item.id}|$index" },
                        ) { _, item ->
                            SharedPosterCard(
                                item = item,
                                onClick = {
                                    arm(DetailRestore.Related(item.type, item.id))
                                    onRelatedClick(item)
                                },
                                focusRequester =
                                    relatedRequesters.getOrPut("${item.type}|${item.id}") {
                                        FocusRequester()
                                    },
                            )
                        }
                    }
                }
            }
        }
    }
}

/** One source + score rating badge (v0.3.17): the FactPill chrome, source muted, score bold. */
@Composable
private fun RatingBadge(rating: com.github.damontecres.wholphin.plavio.MetaRating) {
    Row(
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(PlavioOnyx.GlassFill)
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = rating.source,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
        Text(
            text = rating.score,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@Composable
private fun FactPill(text: String) {
    Box(
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(PlavioOnyx.GlassFill)
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 5.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@Composable
private fun EpisodeRow(
    video: Video,
    progress: Float?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = plavioCardShape(),
        colors = plavioCardColors(),
        border = plavioCardBorder(),
        scale = plavioCardScale(),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (video.thumbnail != null) {
                AsyncImage(
                    model =
                        ImageRequest
                            .Builder(LocalContext.current)
                            .data(video.thumbnail)
                            .size(320, 180)
                            .crossfade(false)
                            .build(),
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .width(160.dp)
                            .height(90.dp)
                            .clip(RoundedCornerShape(8.dp)),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text =
                        stringResource(R.string.plavio_detail_episode, video.episode) +
                            " · " + video.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                video.overview?.takeIf { it.isNotBlank() }?.let { overview ->
                    // v0.3.19 "view full": the episode overview is
                    // shown in FULL — the old 2-line ellipsis cut it
                    // with no way to read the rest (the row's click
                    // plays the episode, so there is no expand tap to
                    // give it; episode overviews are a few sentences,
                    // so the row simply grows).
                    Text(
                        text = overview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                // Watched state (v0.3.21, the sample): a progress
                // bar + word — "Watching · 62%" while part-seen,
                // "Watched" when finished, "Unwatched" when never
                // started.
                val watched = progress != null && progress >= 0.95f
                Text(
                    text =
                        when {
                            progress == null -> stringResource(R.string.plavio_detail_unwatched)
                            watched -> stringResource(R.string.plavio_detail_watched)
                            else ->
                                stringResource(
                                    R.string.plavio_detail_watching,
                                    (progress * 100).toInt(),
                                )
                        },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (watched) FontWeight.SemiBold else FontWeight.Normal,
                    color =
                        if (watched) {
                            PlavioOnyx.CachedGreen
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                )
                if (progress != null && !watched) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(0.4f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                                    .height(4.dp)
                                    .background(LocalPlavioAccent.current.primary, RoundedCornerShape(50)),
                        )
                    }
                }
            }
        }
    }
}
