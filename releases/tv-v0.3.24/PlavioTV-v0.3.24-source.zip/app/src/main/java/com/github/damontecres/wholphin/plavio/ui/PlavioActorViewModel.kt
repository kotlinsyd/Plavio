package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.PersonDetail
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlavioActorUiState {
    data object Loading : PlavioActorUiState

    data class Loaded(
        val person: PersonDetail,
    ) : PlavioActorUiState

    data object Unavailable : PlavioActorUiState
}

@HiltViewModel
class PlavioActorViewModel
    @Inject
    constructor(
        private val repository: AddonCatalogRepository,
    ) : ViewModel() {
        private val _state = MutableStateFlow<PlavioActorUiState>(PlavioActorUiState.Loading)
        val state: StateFlow<PlavioActorUiState> = _state

        private var loadedKey: String? = null

        fun load(
            personId: Int,
            name: String,
        ) {
            val key = "$personId|$name"
            if (key == loadedKey) return
            loadedKey = key
            viewModelScope.launch {
                _state.value = PlavioActorUiState.Loading
                val person =
                    runCatching { repository.getPerson(personId, name) }.getOrNull()
                _state.value =
                    if (person != null) {
                        PlavioActorUiState.Loaded(person)
                    } else {
                        PlavioActorUiState.Unavailable
                    }
            }
        }
    }
