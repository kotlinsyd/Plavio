package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.text.input.setTextAndPlaceCursorAtEnd
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.debrid.TorBoxDeviceAuth
import com.github.damontecres.wholphin.ui.components.Button
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/** TorBox "Connect with code" UI state (device-code flow). */
data class TorboxDeviceUiState(
    /** A session is live and polling for approval. */
    val active: Boolean = false,
    val userCode: String? = null,
    val displayUrl: String? = null,
    /** Waiting note or the failure message when the flow has ended badly. */
    val status: String? = null,
    /** Set the moment the key landed — the block then shows Connected. */
    val connected: Boolean = false,
)

@HiltViewModel
class PlavioIntegrationsViewModel
    @Inject
    constructor(
        private val uiPrefs: PlavioUiPrefs,
    ) : ViewModel() {
        val torboxApiKey: StateFlow<String?> = uiPrefs.torboxApiKey
        val realDebridApiKey: StateFlow<String?> = uiPrefs.realDebridApiKey

        private val deviceAuth = TorBoxDeviceAuth()
        private val _torboxDevice = MutableStateFlow(TorboxDeviceUiState())
        val torboxDevice: StateFlow<TorboxDeviceUiState> = _torboxDevice
        private var deviceJob: Job? = null

        fun setTorboxApiKey(key: String?) {
            viewModelScope.launch { uiPrefs.setTorboxApiKey(key) }
        }

        /**
         * TorBox device-code flow (v0.3.14, TV only): start a session,
         * show the code, poll until the user approves on another
         * device, then store the returned key through the SAME path
         * as a typed key ([setTorboxApiKey] → uiPrefs).
         */
        fun startTorboxDevice() {
            deviceJob?.cancel()
            _torboxDevice.value = TorboxDeviceUiState(active = true)
            deviceJob =
                viewModelScope.launch {
                    val session =
                        deviceAuth.start().getOrElse { e ->
                            _torboxDevice.value =
                                TorboxDeviceUiState(
                                    status = e.message ?: "Could not reach TorBox.",
                                )
                            return@launch
                        }
                    _torboxDevice.value =
                        TorboxDeviceUiState(
                            active = true,
                            userCode = session.userCode,
                            displayUrl = session.displayUrl,
                        )
                    val deadline =
                        System.currentTimeMillis() + session.expiresInSeconds * 1000
                    while (true) {
                        delay(session.intervalSeconds * 1000)
                        if (System.currentTimeMillis() > deadline) {
                            _torboxDevice.value =
                                TorboxDeviceUiState(
                                    status = "That code expired. Start again to get a new code.",
                                )
                            return@launch
                        }
                        when (val poll = deviceAuth.pollOnce(session.deviceCode)) {
                            is TorBoxDeviceAuth.Poll.Ready -> {
                                uiPrefs.setTorboxApiKey(poll.apiToken)
                                _torboxDevice.value = TorboxDeviceUiState(connected = true)
                                return@launch
                            }
                            is TorBoxDeviceAuth.Poll.Failed -> {
                                _torboxDevice.value = TorboxDeviceUiState(status = poll.message)
                                return@launch
                            }
                            TorBoxDeviceAuth.Poll.Waiting -> Unit
                        }
                    }
                }
        }

        fun cancelTorboxDevice() {
            deviceJob?.cancel()
            _torboxDevice.value = TorboxDeviceUiState()
        }

        override fun onCleared() {
            deviceJob?.cancel()
        }

        fun setRealDebridApiKey(key: String?) {
            viewModelScope.launch { uiPrefs.setRealDebridApiKey(key) }
        }
    }

/**
 * Integrations — the debrid half (phone parity): TorBox and Real-Debrid
 * API keys. With a key saved, torrent (infoHash) streams from addons
 * resolve to direct links through the service, TorBox first.
 */
@Composable
fun PlavioIntegrationsScreen(
    modifier: Modifier = Modifier,
    viewModel: PlavioIntegrationsViewModel = hiltViewModel(),
) {
    val torboxKey by viewModel.torboxApiKey.collectAsState()
    val realDebridKey by viewModel.realDebridApiKey.collectAsState()
    val torboxDevice by viewModel.torboxDevice.collectAsState()

    // Entry focus (v0.3.11): this screen owned no requester and the
    // Settings page effect has no branch for it, so it opened with
    // nothing focused. The first field's resting capsule is the home.
    val entryFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) {
        // v0.3.15: additive landing (see PlavioFocus.landFocus).
        landFocus(entryFocus)
    }

    LazyColumn(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(end = 40.dp, top = 32.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.plavio_integrations_title),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = stringResource(R.string.plavio_integrations_sub),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            DebridKeyBlock(
                title = stringResource(R.string.plavio_integrations_torbox),
                savedKey = torboxKey,
                onSave = { viewModel.setTorboxApiKey(it) },
                deviceState = torboxDevice,
                onConnectWithCode = { viewModel.startTorboxDevice() },
                onCancelDevice = { viewModel.cancelTorboxDevice() },
                fieldFocusRequester = entryFocus,
            )
        }
        item {
            DebridKeyBlock(
                title = stringResource(R.string.plavio_integrations_realdebrid),
                savedKey = realDebridKey,
                onSave = { viewModel.setRealDebridApiKey(it) },
            )
        }
    }
}

@Composable
private fun DebridKeyBlock(
    title: String,
    savedKey: String?,
    onSave: (String?) -> Unit,
    deviceState: TorboxDeviceUiState? = null,
    onConnectWithCode: (() -> Unit)? = null,
    onCancelDevice: (() -> Unit)? = null,
    fieldFocusRequester: androidx.compose.ui.focus.FocusRequester? = null,
) {
    val state = rememberTextFieldState()
    var saved by remember { mutableStateOf(false) }
    // Device-code approval stores the key through the same path as
    // Save; when that lands, show the same "Saved" feedback.
    LaunchedEffect(deviceState?.connected) {
        if (deviceState?.connected == true) saved = true
    }
    LaunchedEffect(savedKey) {
        if (savedKey != null && state.text.isEmpty()) {
            state.setTextAndPlaceCursorAtEnd(savedKey)
        }
    }
    // Overhaul (v0.3.11): each debrid service is a framed card with a
    // status chip and proper buttons (Save = filled white primary,
    // Remove = glass outline).
    PlavioPanel(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        PlavioStatusChip(
            text =
                stringResource(
                    if (savedKey != null) {
                        R.string.plavio_integrations_connected
                    } else {
                        R.string.plavio_integrations_not_connected
                    },
                ),
            positive = savedKey != null,
        )
        // Click-to-edit (v0.3.16): the keyboard opens only on an
        // explicit OK press on the field — D-pad focus passing over
        // it no longer pops the keyboard (owner's Settings note).
        PlavioClickToEditField(
            state = state,
            modifier = Modifier.fillMaxWidth(),
            restingFocusRequester = fieldFocusRequester,
            isPassword = true,
            keyboardOptions =
                KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                ),
            emptyHint = stringResource(R.string.plavio_integrations_key_hint),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PlavioPrimaryButton(
                onClick = {
                    onSave(state.text.toString())
                    saved = true
                },
            ) {
                Text(text = stringResource(R.string.plavio_integrations_save))
            }
            if (savedKey != null) {
                PlavioOutlineButton(
                    onClick = {
                        onSave(null)
                        state.setTextAndPlaceCursorAtEnd("")
                        saved = false
                    },
                ) {
                    Text(text = stringResource(R.string.plavio_integrations_remove))
                }
            }
            if (saved) {
                Text(
                    text = stringResource(R.string.plavio_integrations_saved),
                    style = MaterialTheme.typography.bodyMedium,
                    color = LocalPlavioAccent.current.primary,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
        }
        // "Connect with code" (TorBox only; the params are null for
        // every other service): the second sign-in method next to
        // the API-key field above.
        if (deviceState != null && onConnectWithCode != null && onCancelDevice != null) {
            if (deviceState.active && deviceState.userCode != null) {
                Text(
                    text =
                        stringResource(
                            R.string.plavio_torbox_device_instructions,
                            deviceState.displayUrl ?: "",
                        ),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = deviceState.userCode,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 6.sp,
                    color = LocalPlavioAccent.current.primary,
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Text(
                        text =
                            deviceState.status
                                ?: stringResource(R.string.plavio_torbox_waiting),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    PlavioOutlineButton(onClick = onCancelDevice) {
                        Text(text = stringResource(R.string.plavio_cancel))
                    }
                }
            } else if (savedKey == null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PlavioOutlineButton(onClick = onConnectWithCode) {
                        Text(text = stringResource(R.string.plavio_torbox_connect_code))
                    }
                }
                deviceState.status?.let { message ->
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}
