package com.github.damontecres.wholphin.plavio.ui

import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.util.TypedValue
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.SubtitleStyle
import com.github.damontecres.wholphin.plavio.TvChannelRef
import com.github.damontecres.wholphin.plavio.Video
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import com.github.damontecres.wholphin.plavio.StreamItem
import com.github.damontecres.wholphin.plavio.buttonLabel
import com.github.damontecres.wholphin.plavio.streamQualityLabel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import timber.log.Timber
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private enum class PlayerPicker { NONE, SUBTITLES, AUDIO, EPISODES, SPEED, AUDIO_PREF, SOURCES }

// Sources auto-popup budget (v0.3.10, owner's rule; v0.3.18:
// 35s → 30s on the owner's word): a play start that has produced
// no picture within this long gets the Sources panel opened over
// the still-running load, so the user can take over by hand. The
// popup switches nothing itself — it hands the user the wheel.
private const val SOURCES_AUTO_POPUP_MS = 30_000L

/**
 * v0.3.15 (the retry-loop fix): the STALL bound on one load session —
 * how long a start may make NO PROGRESS WHATSOEVER before it is
 * declared dead. v0.3.14 ran this as a plain wall clock from first
 * composition: 45s, whether or not the start was actually feeding.
 * On the owner's slow routes a healthy start spends its first tens
 * of seconds in connect + read waits (the HTTP stack allows 5s
 * connect / 20s read per attempt, and a ladder hop starts a fresh
 * attempt inside the SAME clock), so the deadline fired mid-load on
 * starts that were progressing fine — stop(), error surface, retry,
 * same wall — "retry retry, nothing play". The stall form only
 * accrues time while the player exists, has not reached READY, and
 * its buffered position has not advanced at all; any forward feed,
 * any player swap (a ladder hop is activity), and any moment the
 * user owns the screen (picker, error surface, resume prompt)
 * resets the clock to zero. A start that is genuinely wedged —
 * error-free but frozen, no bytes moving — still dies at the bound
 * and hands the remote back, which is all the deadline was for.
 */
private const val LOAD_STALL_LIMIT_MS = 45_000L

/** Stall-detector poll interval (v0.3.15, see LOAD_STALL_LIMIT_MS). */
private const val LOAD_STALL_POLL_MS = 5_000L

/**
 * v0.3.17 (owner note 1 — the source-switch crash): the automatic
 * recovery budget, mirroring the reference player's method the
 * owner ordered ("same to same"): the player NEVER advances to
 * another source on its own — a failure retries THE SAME source,
 * bounded, with a real pause between attempts, and then hands the
 * remote back. MAX_AUTO_RETRIES = 2 and RETRY_DELAY_MS = 1,500 are
 * the reference's own constants; the budget refills only after
 * STABLE_PROGRESS_RESET_MS of healthy READY + playing progress
 * (the reference's stable-progress reset rule), never the instant
 * a state flag flickers to READY.
 */
private const val MAX_AUTO_RETRIES = 2
private const val RETRY_DELAY_MS = 1_500L
private const val STABLE_PROGRESS_RESET_MS = 5_000L

/**
 * HTTP statuses a retry of the same request gets again, so retrying
 * only delays the error (v0.3.17: the reference player's rule,
 * adopted with its recovery method).
 */
private fun isPermanentHttpStatus(code: Int): Boolean =
    code == 400 || code == 401 || code == 403 || code == 404 || code == 410

/** The HTTP status behind a playback error, when it carries one. */
private fun httpStatusOf(error: PlaybackException): Int? {
    var cause: Throwable? = error
    while (cause != null) {
        if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
            return cause.responseCode
        }
        cause = cause.cause
    }
    return null
}

/**
 * Whether a playback error is worth retrying THE SAME source for
 * (v0.3.17: the reference player's classification, adopted with its
 * recovery method — transient IO, parsing glitches and decoder
 * failures retry; a permanent HTTP status and everything else is
 * fatal and surfaces at once). Replaces the v0.3.9–0.3.13 helpers
 * that sorted errors into source-hopping lanes.
 */
private fun isRetryablePlaybackError(error: PlaybackException): Boolean =
    when (error.errorCode) {
        PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION,
        PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED,
        PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE,
        -> true
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> {
            val status = httpStatusOf(error)
            status == null || !isPermanentHttpStatus(status)
        }
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        -> true
        PlaybackException.ERROR_CODE_UNSPECIFIED ->
            error.cause is IllegalStateException || error.cause is NullPointerException
        else -> false
    }

/**
 * Full-screen playback for an addon stream with a remote-first control
 * layer, mirroring the phone player's control set: play/pause, seek bar
 * (D-pad left/right seek by the configured skip amounts), current/total
 * time, the three-rail subtitle panel (Languages | Subtitles | Style),
 * an audio picker, next-episode autoplay with a countdown, an episodes
 * picker and a Sources shortcut back to the stream list. Controls
 * auto-hide while playing; any key wakes them, and focus is always on a
 * visible control while they're up.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlavioPlayerScreen(
    request: PlaybackRequest,
    modifier: Modifier = Modifier,
    resumePositionMs: Long = 0,
    onResumeFailed: (() -> Unit)? = null,
    onPlayNextEpisode: ((PlaybackRequest) -> Unit)? = null,
    onZapChannel: ((TvChannelRef) -> Unit)? = null,
    viewModel: PlavioPlayerViewModel = hiltViewModel(),
) {
    val player by viewModel.player.collectAsState()
    val resumeFailed by viewModel.resumeFailed.collectAsState()
    val subtitleStyle by viewModel.subtitleStyle.collectAsState()
    val autoPlayNext by viewModel.autoPlayNextEpisode.collectAsState()
    val subtitleLanguages by viewModel.subtitleLanguages.collectAsState()
    val preferredAudioLanguage by viewModel.preferredAudioLanguage.collectAsState()
    val localSubtitles by viewModel.localSubtitles.collectAsState()
    val subtitleDelayMs by viewModel.subtitleDelayMs.collectAsState()
    val skipForwardMs by viewModel.skipForwardMs.collectAsState()
    val skipBackMs by viewModel.skipBackMs.collectAsState()
    val skipSegments by viewModel.skipSegments.collectAsState()
    val showSkipIntro by viewModel.showSkipIntro.collectAsState()
    val creationError by viewModel.creationError.collectAsState()
    val playerClock by viewModel.playerClock.collectAsState()
    val sidecarSubtitle by viewModel.sidecarSubtitle.collectAsState()
    val liveRequest by viewModel.currentRequestFlow.collectAsState()
    val displayRequest = liveRequest ?: request
    var errorMessage by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // Parity state (v0.2.1): speed + aspect are per-title session state,
    // reset whenever a new title starts.
    var speed by remember(request.streamUrl) { mutableFloatStateOf(1f) }
    var resizeMode by remember(request.streamUrl) { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    // v0.3.21 (study fix #3): the playing video's display aspect,
    // fed by the player listener below — it drives the SURFACE
    // frame sizing in the AndroidView block (the SmartTube way:
    // the frame the surface lives in is sized by aspect + mode,
    // not a content frame inside a full-screen PlayerView).
    var videoAspect by remember(request.streamUrl) { mutableFloatStateOf(0f) }
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }
    // Same-source recovery state (v0.3.17, the reference method —
    // see MAX_AUTO_RETRIES): how many automatic retries THE CURRENT
    // SOURCE has spent, the pending retry job (a second failure
    // arriving while one is scheduled must not spend budget twice —
    // the v0.3.16 crash shape), and the safe-mode rebuild latch
    // (attempt two's configuration change, at most once per title).
    // The note tells the user a recovery is running instead of
    // leaving a silent spinner.
    var autoRetryCount by remember(request.streamUrl) { mutableIntStateOf(0) }
    var recoveryJob by remember(request.streamUrl) { mutableStateOf<Job?>(null) }
    var backendSwitched by remember(request.streamUrl) { mutableStateOf(false) }
    var failoverNote by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // [loadGen] keys the load-stall detector below: each fresh start
    // (and each manual retry from the error surface) earns one full
    // stall budget, never an endless spinner.
    var loadGen by remember(request.streamUrl) { mutableIntStateOf(0) }
    // Resume prompt: playback waits until the user picks Resume / Start over.
    var resumeDecided by remember(request.streamUrl) { mutableStateOf(resumePositionMs <= 0) }
    var startOver by remember(request.streamUrl) { mutableStateOf(false) }
    val showResumePrompt =
        resumePositionMs > 0 && !resumeDecided && !request.isLive && !request.isTrailer
    val shownError = errorMessage ?: creationError
    // Live zapping context: siblings + this channel's place among them.
    val liveSiblings = displayRequest.liveChannels
    val liveIndex =
        liveSiblings.indexOfFirst { it.metaId == displayRequest.liveChannel?.metaId }
    val canZap = request.isLive && liveSiblings.size > 1 && onZapChannel != null
    fun zap(delta: Int) {
        if (!canZap || liveIndex < 0) return
        val target = liveSiblings.getOrNull(liveIndex + delta) ?: return
        onZapChannel?.invoke(target)
    }
    var buffering by remember(request.streamUrl) { mutableStateOf(true) }
    var reachedReady by remember(request.streamUrl) { mutableStateOf(false) }
    var resumeFallbackDone by remember(request.streamUrl) { mutableStateOf(false) }
    var playbackEnded by remember(request.streamUrl) { mutableStateOf(false) }
    // Sources auto-popup bookkeeping (v0.3.10): sourcesStartGen
    // counts play STARTS within this screen — a pick from the Sources
    // panel is a new start and bumps it, earning a fresh 30s clock;
    // auto-failovers in between do NOT touch it, so the clock runs
    // across them, as the owner's rule states. sourcesAutoOpened is
    // the once-per-start latch: set when the popup fires (or when the
    // panel is already up by hand at fire time), never reset except
    // by a pick starting a new clock — a manual close after an
    // auto-open therefore stays closed for that start.
    var sourcesStartGen by remember(request.streamUrl) { mutableIntStateOf(0) }
    var sourcesAutoOpened by remember(request.streamUrl) { mutableStateOf(false) }

    var controlsVisible by remember(request.streamUrl) { mutableStateOf(true) }
    var picker by remember(request.streamUrl) { mutableStateOf(PlayerPicker.NONE) }
    var isPlaying by remember(request.streamUrl) { mutableStateOf(false) }
    var positionMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var durationMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var bufferedMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var tracksVersion by remember(request.streamUrl) { mutableIntStateOf(0) }
    // The IntroDB segment under the playhead, if the toggle is on.
    // v0.3.23: derivedStateOf — reading positionMs directly here
    // subscribed this whole screen body to every ticker write (500ms
    // with the controls up), recomposing the video container, scrims
    // and control stack on a box that can ill afford it. Now the body
    // only recomposes when the segment actually changes; the ticker
    // still writes positionMs at the same rate, but only the seek
    // bar (below, lambda-fed) and this derived value observe it.
    val skipIntroEnabled by rememberUpdatedState(showSkipIntro)
    val skipSegmentsNow by rememberUpdatedState(skipSegments)
    val activeSegment by
        remember(request.streamUrl) {
            derivedStateOf {
                if (skipIntroEnabled) {
                    skipSegmentsNow.firstOrNull {
                        positionMs >= it.startMs && positionMs <= it.endMs
                    }
                } else {
                    null
                }
            }
        }
    val seekFocus = remember { FocusRequester() }
    // v0.3.19 focus trap: every picker-opening control carries its
    // own FocusRequester so that closing a picker can return focus
    // to the exact control that opened it (see the restore effect
    // below). AUDIO_PREF is reached from inside the Audio panel, so
    // it returns to the Audio control — the chain's root opener.
    val episodesBtnFocus = remember { FocusRequester() }
    val subtitlesBtnFocus = remember { FocusRequester() }
    val audioBtnFocus = remember { FocusRequester() }
    val sourcesBtnFocus = remember { FocusRequester() }
    val speedBtnFocus = remember { FocusRequester() }
    // The picker that was open most recently — its opener regains
    // focus when the picker closes. NONE = nothing to restore to.
    var pickerOpener by remember(request.streamUrl) { mutableStateOf(PlayerPicker.NONE) }
    // v0.3.8: focus holder of last resort for the root Box — armed
    // whenever the control layer is un-composed (see the effect below).
    val keyCatcherFocus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    // Next-episode state (autoplay countdown + manual picks).
    var nextUpRequest by remember(request.streamUrl) { mutableStateOf<PlaybackRequest?>(null) }
    var nextUpVideo by remember(request.streamUrl) { mutableStateOf<Video?>(null) }
    var nextUpSeconds by remember(request.streamUrl) { mutableIntStateOf(10) }
    var resolvingNext by remember(request.streamUrl) { mutableStateOf(false) }
    var episodeError by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    // In-player Download outcome (v0.3.16), shown as the same
    // transient centre message as episodeError.
    var downloadNotice by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    val hasEpisodes = request.episodes.isNotEmpty() && !request.isMovie && !request.isLive
    val nextVideo = remember(request) { viewModel.nextEpisode(request) }

    fun playEpisode(video: Video) {
        if (resolvingNext || onPlayNextEpisode == null) return
        resolvingNext = true
        scope.launch {
            val resolved = viewModel.resolveEpisode(request, video)
            resolvingNext = false
            if (resolved != null) {
                onPlayNextEpisode(resolved)
            } else {
                episodeError = "No streams for that episode."
            }
        }
    }

    // Autoplay: when playback ends and the switch is on, resolve the
    // next episode and start the countdown card.
    LaunchedEffect(playbackEnded, autoPlayNext, nextVideo) {
        if (playbackEnded && autoPlayNext && nextVideo != null &&
            nextUpRequest == null && !resolvingNext && onPlayNextEpisode != null
        ) {
            resolvingNext = true
            val resolved = viewModel.resolveEpisode(request, nextVideo)
            resolvingNext = false
            if (resolved != null) {
                nextUpVideo = nextVideo
                nextUpRequest = resolved
                nextUpSeconds = 10
            }
        }
    }
    // The countdown itself: ticks to zero, then jumps.
    LaunchedEffect(nextUpRequest) {
        val target = nextUpRequest ?: return@LaunchedEffect
        while (nextUpSeconds > 0) {
            delay(1_000)
            nextUpSeconds--
        }
        onPlayNextEpisode?.invoke(target)
    }
    // The same-source recovery coordinator (v0.3.17 — replaces the
    // v0.3.12–0.3.16 source-hopping ladder; see MAX_AUTO_RETRIES).
    // One entry point for every automatic failure: the player-error
    // listener and both ViewModel watchdogs (through the
    // watchdogRecovery hook) come through here, so a hard error, a
    // silent hang and an audio-but-black stream all recover the
    // reference player's way:
    //   · classify first — a non-retryable failure (a permanent
    //     HTTP status above all) returns false at once and the
    //     caller shows the error surface; the source NEVER changes
    //     on its own, so there is nothing to "skip fast" through;
    //   · retryable → at most MAX_AUTO_RETRIES retries of THE SAME
    //     source, each after RETRY_DELAY_MS of patience: attempt
    //     one re-prepares the live player, attempt two fully
    //     rebuilds it — in the safe configuration when that hasn't
    //     been tried yet (our one-engine analogue of the reference's
    //     second-chance configuration), a plain rebuild otherwise;
    //   · single-flight: while a retry is scheduled or running,
    //     further failure calls return true WITHOUT spending budget
    //     again — the v0.3.16 crash came from two callers (error
    //     listener + watchdog) stepping the old ladder in the same
    //     instant and racing two starts against each other.
    // Manual choices are untouched: the error surface keeps Retry /
    // Next source / Sources, and the Sources panel pick still
    // switches — those are the USER's switches, not the player's.
    val safeRetryNote = stringResource(R.string.plavio_player_safe_retry)
    val retryingNote = stringResource(R.string.plavio_player_retrying)
    fun attemptRecovery(retryable: Boolean): Boolean {
        if (!retryable) return false
        if (recoveryJob?.isActive == true) return true
        if (autoRetryCount >= MAX_AUTO_RETRIES) return false
        val attempt = autoRetryCount
        autoRetryCount++
        errorMessage = null
        buffering = true
        recoveryJob =
            scope.launch {
                delay(RETRY_DELAY_MS)
                if (attempt == 0) {
                    failoverNote = retryingNote
                    // Light recovery first (the reference's attempt
                    // one): re-prepare the same player. A watchdog
                    // failure on a start that never produced a
                    // player falls through to a full same-source
                    // restart instead.
                    if (!viewModel.reprepareCurrentStream(positionMs)) {
                        viewModel.retry(positionMs)
                    }
                } else {
                    // Full rebuild (the reference's attempt two),
                    // in the safe configuration when untried.
                    if (!backendSwitched && viewModel.recreateInSafeMode(positionMs)) {
                        backendSwitched = true
                        failoverNote = safeRetryNote
                    } else {
                        failoverNote = retryingNote
                        viewModel.retry(positionMs)
                    }
                }
            }
        return true
    }

    LaunchedEffect(episodeError) {
        if (episodeError != null) {
            delay(3_000)
            episodeError = null
        }
    }
    LaunchedEffect(downloadNotice) {
        if (downloadNotice != null) {
            delay(3_000)
            downloadNotice = null
        }
    }

    // The stored stream is gone (or never got going): hand the user the
    // item's streams screen instead of leaving them on an error.
    LaunchedEffect(resumeFailed) {
        if (resumeFailed && !resumeFallbackDone) {
            resumeFallbackDone = true
            onResumeFailed?.invoke()
        }
    }

    LaunchedEffect(request.streamUrl, resumePositionMs, resumeDecided) {
        if (resumeDecided) {
            viewModel.start(request, if (startOver) 0 else resumePositionMs)
        }
    }
    // Sources auto-popup timer (v0.3.10): armed once the start is
    // real (resume decided — before that the clock hasn't begun) and
    // cancelled the moment this start first reaches READY
    // (reachedReady flips true on the first STATE_READY, the
    // "playing picture" proxy the rest of this screen uses) or when
    // the screen leaves composition. Failovers don't re-key it —
    // switchStream keeps the same request.streamUrl and generation —
    // so the 30s runs across them. At fire time it re-checks the UI:
    // an error surface or another open picker owns the screen by
    // then, and the popup stays out of their way.
    LaunchedEffect(request.streamUrl, sourcesStartGen, resumeDecided, reachedReady) {
        if (!resumeDecided || reachedReady || sourcesAutoOpened) return@LaunchedEffect
        delay(SOURCES_AUTO_POPUP_MS)
        if (picker == PlayerPicker.SOURCES) {
            // Opened by hand during the wait: that counts as this
            // start's one fire — no re-open after a manual close.
            sourcesAutoOpened = true
        } else if (shownError == null && !showResumePrompt && picker == PlayerPicker.NONE) {
            sourcesAutoOpened = true
            picker = PlayerPicker.SOURCES
        }
    }
    // Load stall detector (v0.3.15 — replaces the v0.3.14 wall-clock
    // deadline; see LOAD_STALL_LIMIT_MS for why the wall clock killed
    // healthy starts): poll the feeding player; time only accrues
    // while NOTHING is progressing. Progress = the buffered position
    // advancing, or the player instance changing (a ladder hop or a
    // fresh start is activity, not stall). The clock also rests
    // while anything else owns the screen (the sources picker counts
    // as control returned; an error surface and the resume prompt
    // own it outright) and while no player exists yet (creation is
    // quick and its failures surface as creation errors). A manual
    // Retry / Next source bumps [loadGen] and restarts the detector.
    // When the bound is hit the session is stopped and the error
    // surface takes the screen with focus — the user always gets
    // the remote back, and Back never needed help from here: no
    // step in the load path blocks the UI thread (factory gate).
    val loadTimeoutMessage = stringResource(R.string.plavio_player_load_timeout)
    LaunchedEffect(request.streamUrl, loadGen) {
        if (reachedReady) return@LaunchedEffect
        var stalledMs = 0L
        var lastPlayer: Player? = null
        var lastBufferedMs = -1L
        while (isActive && !reachedReady) {
            delay(LOAD_STALL_POLL_MS)
            if (reachedReady) break
            val current = player
            val userOwnsScreen =
                picker != PlayerPicker.NONE || shownError != null || showResumePrompt
            val progressed =
                when {
                    userOwnsScreen -> true
                    current == null -> true
                    current !== lastPlayer -> true
                    current.bufferedPosition > lastBufferedMs -> true
                    else -> false
                }
            lastPlayer = current
            if (current != null) lastBufferedMs = current.bufferedPosition
            if (progressed) {
                stalledMs = 0L
                continue
            }
            stalledMs += LOAD_STALL_POLL_MS
            if (stalledMs >= LOAD_STALL_LIMIT_MS) {
                // v0.3.17: a wedged load gets the same bounded
                // same-source recovery as a hard error before the
                // session is declared dead — the recovery's own
                // restart counts as progress on the next polls.
                // Only when the budget is spent (or a recovery is
                // somehow refused) does the old stop + error
                // surface path run: the user always gets the
                // remote back.
                if (attemptRecovery(retryable = true)) {
                    stalledMs = 0L
                    continue
                }
                Timber.w(
                    "Load stalled: no buffering progress for %dms; returning control",
                    stalledMs,
                )
                viewModel.stop()
                buffering = false
                errorMessage = loadTimeoutMessage
                break
            }
        }
    }
    // Re-apply the session speed whenever the player instance changes
    // (fresh start, failover, episode switch all build a new player).
    LaunchedEffect(player, speed) {
        val active = player ?: return@LaunchedEffect
        runCatching { active.playbackParameters = PlaybackParameters(speed) }
    }
    DisposableEffect(Unit) {
        onDispose { viewModel.stop() }
    }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // The recovery coordinator itself (attemptRecovery) is defined
    // with the session state above — it must precede the load-stall
    // detector, which also routes through it. What remains here is
    // its wiring: the note's auto-clear, and the ViewModel watchdog
    // hook (a silent hang or an audio-but-black stream is a
    // retryable failure of THE SAME source — never a source hop).
    LaunchedEffect(failoverNote) {
        if (failoverNote != null) {
            delay(3_500)
            failoverNote = null
        }
    }

    DisposableEffect(viewModel) {
        viewModel.watchdogRecovery = { attemptRecovery(retryable = true) }
        onDispose { viewModel.watchdogRecovery = null }
    }

    DisposableEffect(player) {
        val active = player
        if (active == null) {
            onDispose { }
        } else {
            val listener =
                object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        if (resumePositionMs > 0 && !reachedReady &&
                            onResumeFailed != null && !resumeFallbackDone
                        ) {
                            resumeFallbackDone = true
                            onResumeFailed()
                            return
                        }
                        // v0.3.17, the reference method: classify,
                        // then retry THE SAME source (bounded, with
                        // patience) — the player never advances to
                        // another source on its own. A non-retryable
                        // failure (permanent HTTP status, DRM, …)
                        // or a spent budget shows the error surface,
                        // where Retry / Next source / Sources stay
                        // manual, as they were.
                        if (!attemptRecovery(isRetryablePlaybackError(error))) {
                            errorMessage = error.message
                            buffering = false
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        // v0.3.18: buffering/isPlaying are written by
                        // the ViewModel clock alone now (see the
                        // mirror effect below) — this listener keeps
                        // only the edge events: ready, ended, error.
                        if (playbackState == Player.STATE_READY) {
                            reachedReady = true
                            errorMessage = null
                            // v0.3.17: NO instant budget reset here —
                            // the retry budget refills only after
                            // STABLE_PROGRESS_RESET_MS of sustained
                            // healthy playing (see the effect below),
                            // the reference's stable-progress rule. A
                            // stream that flickers READY between
                            // failures must not regain a full budget
                            // on every flicker.
                        }
                        if (playbackState == Player.STATE_ENDED) {
                            playbackEnded = true
                        }
                    }

                    override fun onTracksChanged(tracks: Tracks) {
                        tracksVersion++
                    }

                    override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                        // v0.3.21 (study fix #3): feed the surface
                        // frame sizing in the AndroidView block.
                        videoAspect =
                            if (videoSize.height > 0) {
                                videoSize.width * videoSize.pixelWidthHeightRatio /
                                    videoSize.height
                            } else {
                                0f
                            }
                    }
                }
            active.addListener(listener)
            onDispose { active.removeListener(listener) }
        }
    }

    // Stable-progress budget refill (v0.3.17, the reference's rule):
    // the automatic-retry budget resets only after
    // STABLE_PROGRESS_RESET_MS of sustained READY + playing. The
    // effect re-keys on every playing/ready flip, so any stumble
    // restarts the 5s proof — a stream oscillating between READY
    // and error keeps the budget it has left.
    LaunchedEffect(player, isPlaying, reachedReady) {
        if (player != null && isPlaying && reachedReady) {
            delay(STABLE_PROGRESS_RESET_MS)
            if (isPlaying) {
                autoRetryCount = 0
            }
        }
    }

    // Preferred-language auto-pick, once per title: first audio
    // track matching the preferred audio language. v0.3.18: the
    // subtitle half of this effect is REMOVED on the owner's order
    // — subtitles are OFF by default, no auto-selected subtitle on
    // play, whatever the preferred languages say. (The preferred
    // languages still order the panel's Languages rail; they just
    // never turn a subtitle on by themselves.)
    var preferredApplied by remember(request.streamUrl) { mutableStateOf(false) }
    LaunchedEffect(tracksVersion, player) {
        val active = player ?: return@LaunchedEffect
        if (preferredApplied) return@LaunchedEffect
        val audioOptions = trackOptions(active, text = false)
        if (audioOptions.isEmpty()) return@LaunchedEffect
        preferredApplied = true
        preferredAudioLanguage?.let { lang ->
            audioOptions
                .firstOrNull { it.language == lang }
                ?.let { applyTrackOption(active, text = false, it) }
        }
    }

    // Player clock mirror (v0.3.18, diagnosis cause #3): the 500 ms
    // position ticker that used to run in THIS composition is gone.
    // The ViewModel polls the player on its own clock and publishes
    // PlayerClock snapshots; this effect only mirrors them into the
    // state the seek bar, time labels and spinner read — same
    // values at the same rate, but a tick no longer recomposes the
    // video container and control stack out of the composition
    // itself, and the AndroidView below no longer re-updates at
    // 2 Hz behind the controls. The buffering rule (an advancing
    // position counts as playing even when the state flag sticks at
    // BUFFERING) moved with the polling, into the ViewModel.
    LaunchedEffect(playerClock) {
        positionMs = playerClock.positionMs
        durationMs = playerClock.durationMs
        bufferedMs = playerClock.bufferedMs
        isPlaying = playerClock.isPlaying
        buffering = playerClock.buffering
    }

    // v0.3.21 (study fix #4): tell the ViewModel whether the
    // control layer is presented, so its clock can drop the
    // 500 ms publish rate while nothing is on screen to read it.
    // An open picker counts as presented (its panels read the
    // mirrored position).
    LaunchedEffect(controlsVisible, picker) {
        viewModel.setControlsPresented(controlsVisible || picker != PlayerPicker.NONE)
    }

    // Focus the seek bar whenever the controls come up.
    LaunchedEffect(controlsVisible, player) {
        if (controlsVisible && player != null && picker == PlayerPicker.NONE && nextUpRequest == null) {
            runCatching { seekFocus.requestFocus() }
        }
    }
    // v0.3.8 REGRESSION FIX (controls never woke after the first
    // auto-hide): the wake-up keys are handled by the root Box's
    // onPreviewKeyEvent, and a preview handler only receives events
    // dispatched to a FOCUSED descendant. While the controls are up
    // that descendant is the seek bar — but the seek bar lives inside
    // the control layer, which v0.3.7 un-composes when hidden, and a
    // focused node leaving composition takes focus with it. The
    // PlayerView is isFocusable=false, so after the first hide no
    // node in this screen could hold focus and no key ever reached
    // the wake-up handler again. Fix: whenever the controls go down
    // (and no picker / next-up card / error / resume prompt owns the
    // UI — those request their own focus), hand focus to the root Box
    // itself, which is always composed and carries the wake handler.
    // Re-armed on every hide, so hide -> wake works repeatedly; the
    // layer stays un-composed while hidden (the v0.3.7 perf win is
    // untouched).
    LaunchedEffect(controlsVisible, player, picker, nextUpRequest, shownError, showResumePrompt) {
        if (!controlsVisible && player != null && picker == PlayerPicker.NONE &&
            nextUpRequest == null && shownError == null && !showResumePrompt
        ) {
            runCatching { keyCatcherFocus.requestFocus() }
        }
    }
    // v0.3.19: closing a picker (a pick, or Back) returns focus to
    // the control that opened it. Before this, the panel row holding
    // focus left composition together with the panel and focus fell
    // to wherever the next focus search happened to land — the
    // seek bar or another control, seemingly at random ("it also
    // goes back to the video player controls"). Skipped when another
    // overlay (error, next-up card, resume prompt) owns the UI, and
    // on the very first composition (picker starts at NONE).
    LaunchedEffect(picker) {
        if (picker != PlayerPicker.NONE) {
            pickerOpener = picker
            return@LaunchedEffect
        }
        if (pickerOpener == PlayerPicker.NONE) return@LaunchedEffect
        val opener = pickerOpener
        pickerOpener = PlayerPicker.NONE
        if (!controlsVisible || shownError != null || nextUpRequest != null || showResumePrompt) {
            return@LaunchedEffect
        }
        runCatching {
            when (opener) {
                PlayerPicker.SUBTITLES -> subtitlesBtnFocus.requestFocus()
                PlayerPicker.AUDIO, PlayerPicker.AUDIO_PREF -> audioBtnFocus.requestFocus()
                PlayerPicker.EPISODES -> episodesBtnFocus.requestFocus()
                PlayerPicker.SOURCES -> sourcesBtnFocus.requestFocus()
                PlayerPicker.SPEED -> speedBtnFocus.requestFocus()
                PlayerPicker.NONE -> seekFocus.requestFocus()
            }
        }
    }
    // Auto-hide while playing.
    LaunchedEffect(controlsVisible, isPlaying, picker, nextUpRequest) {
        if (controlsVisible && isPlaying && picker == PlayerPicker.NONE &&
            shownError == null && nextUpRequest == null
        ) {
            delay(6_000)
            controlsVisible = false
        }
    }
    // Back hides the controls / closes a picker before leaving playback.
    BackHandler(enabled = picker != PlayerPicker.NONE) { picker = PlayerPicker.NONE }
    BackHandler(enabled = nextUpRequest != null) { nextUpRequest = null }
    BackHandler(
        enabled = picker == PlayerPicker.NONE && nextUpRequest == null && controlsVisible && shownError == null,
    ) {
        controlsVisible = false
    }

    fun togglePlay() {
        val active = player ?: return
        if (active.isPlaying) active.pause() else active.play()
        controlsVisible = true
    }

    // Seek coalescing (v0.3.7): D-pad taps used to fire one full
    // re-buffer per key-down, so holding/repeating left/right stacked
    // several cold seeks. Now presses accumulate for ~300ms of quiet
    // and fire as ONE seekTo to the summed target; the seek bar shows
    // the pending target immediately. The skip-intro button below
    // still seeks directly — it is a single deliberate jump.
    var pendingSeekDeltaMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
    var pendingSeekJob by remember(request.streamUrl) { mutableStateOf<Job?>(null) }

    fun seekBy(deltaMs: Long) {
        val active = player ?: return
        pendingSeekDeltaMs += deltaMs
        val optimistic =
            (active.currentPosition + pendingSeekDeltaMs).coerceAtLeast(0)
        val dur = active.duration
        positionMs =
            if (dur != C.TIME_UNSET && dur > 0) optimistic.coerceAtMost(dur) else optimistic
        controlsVisible = true
        pendingSeekJob?.cancel()
        pendingSeekJob =
            scope.launch {
                delay(300)
                val delta = pendingSeekDeltaMs
                pendingSeekDeltaMs = 0L
                val base = runCatching { active.currentPosition }.getOrDefault(0L)
                val target = (base + delta).coerceAtLeast(0)
                val d = active.duration
                active.seekTo(
                    if (d != C.TIME_UNSET && d > 0) target.coerceAtMost(d) else target,
                )
            }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(Color.Black)
                // v0.3.8: the root Box itself is focusable so it can
                // hold focus while the control layer is un-composed
                // (armed by the effect above). focusable() draws
                // nothing, and a full-screen containing rect is never
                // a directional focus-search target from its own
                // children, so navigation while the controls are up
                // is unchanged.
                // v0.3.22: while a picker popup is open the catcher
                // is OUT of the focus graph entirely — a full-screen
                // focusable behind the popup was a landing spot for
                // focus leaving the popup, and from it the wake
                // handler + focus search could walk back into the
                // player (the owner's subs-popup escape).
                .focusRequester(keyCatcherFocus)
                .focusable(enabled = picker == PlayerPicker.NONE)
                .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (event.key) {
                        Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> {
                            togglePlay()
                            true
                        }
                        Key.MediaFastForward -> {
                            seekBy(skipForwardMs)
                            true
                        }
                        Key.MediaRewind -> {
                            seekBy(-skipBackMs)
                            true
                        }
                        Key.MediaStop -> {
                            player?.pause()
                            controlsVisible = true
                            true
                        }
                        Key.ChannelUp -> {
                            zap(1)
                            true
                        }
                        Key.ChannelDown -> {
                            zap(-1)
                            true
                        }
                        Key.DirectionCenter, Key.DirectionLeft, Key.DirectionRight,
                        Key.DirectionUp, Key.DirectionDown,
                        -> {
                            if (!controlsVisible && shownError == null && nextUpRequest == null) {
                                controlsVisible = true
                                true
                            } else {
                                false
                            }
                        }
                        else -> false
                    }
                },
    ) {
        val activePlayer = player
        // v0.3.7: the 500ms ticker recomposes this screen, so the
        // AndroidView update lambda re-runs at 2 Hz. The subtitle
        // style is only re-applied when it actually changed — the old
        // code re-touched the SubtitleView's style, size and padding
        // on every tick.
        var lastAppliedSubtitleStyle by remember(request.streamUrl) { mutableStateOf<SubtitleStyle?>(null) }
        // v0.3.21 (study fix #3): the last (resizeMode, videoAspect)
        // spec the surface's fixed size was driven for — the holder
        // is only re-sized when the spec actually changes.
        var lastSurfaceSpec by remember(request.streamUrl) { mutableStateOf<Pair<Int, Float>?>(null) }
        if (activePlayer != null) {
            // v0.3.21 (study fix #3 — the SurfaceView retry, shaped
            // the SmartTube way): the PlayerView's FRAME is sized by
            // the video aspect + the Aspect mode and centred on the
            // screen — Fit = the aspect rect inside the screen,
            // Fill = the full screen, Zoom = the aspect rect
            // COVERING the screen (the display crops the overflow).
            // The v0.3.7 attempt resized a content frame INSIDE a
            // full-screen PlayerView, which this class of MediaTek
            // firmware ignores; sizing the frame the surface lives
            // in — plus the holder's fixed size, driven in update
            // below — is the level the firmware honours. Until the
            // video size is known the view fills the screen, as
            // before. The subtitle view and the control layer are
            // separate layers and are untouched by the frame size.
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val frameModifier =
                    if (videoAspect > 0f) {
                        val screenAspect = maxWidth / maxHeight
                        val frameSize =
                            when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FILL ->
                                    DpSize(maxWidth, maxHeight)
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM ->
                                    if (screenAspect > videoAspect) {
                                        DpSize(maxWidth, maxWidth / videoAspect)
                                    } else {
                                        DpSize(maxHeight * videoAspect, maxHeight)
                                    }
                                else ->
                                    if (screenAspect > videoAspect) {
                                        DpSize(maxHeight * videoAspect, maxHeight)
                                    } else {
                                        DpSize(maxWidth, maxWidth / videoAspect)
                                    }
                            }
                        Modifier
                            .align(Alignment.Center)
                            .requiredSize(frameSize)
                    } else {
                        Modifier.fillMaxSize()
                    }
                AndroidView(
                    factory = { context ->
                        // v0.3.21: the surface is a SurfaceView
                        // again — see res/layout/plavio_player_view.xml
                        // for the one-line revert if this build shows
                        // a BLACK PICTURE on the owner's TV.
                        val inflated =
                            android.view.LayoutInflater
                                .from(context)
                                .inflate(R.layout.plavio_player_view, null) as PlayerView
                        inflated.apply {
                            useController = false
                            isFocusable = false
                            this.player = activePlayer
                            this.resizeMode = resizeMode
                            playerViewRef = this
                            applySubtitleStyle(this, subtitleStyle)
                            lastAppliedSubtitleStyle = subtitleStyle
                            // v0.3.18: the sidecar renders into this
                            // view's own SubtitleView (the reference's
                            // binding shape) — bind it so a pick made
                            // before the view existed still lands.
                            subtitleView?.let { viewModel.bindSubtitleView(it) }
                        }
                    },
                    update = { playerView ->
                        playerView.player = activePlayer
                        playerView.resizeMode = resizeMode
                        if (lastAppliedSubtitleStyle != subtitleStyle) {
                            runCatching { applySubtitleStyle(playerView, subtitleStyle) }
                            lastAppliedSubtitleStyle = subtitleStyle
                        }
                        // v0.3.21 (study fix #3): drive the
                        // surface's own fixed size from the frame's
                        // laid-out size — the second half of sizing
                        // at the surface level. Posted so it reads
                        // the post-layout size; runs only when the
                        // (mode, aspect) spec changed.
                        val spec = resizeMode to videoAspect
                        if (lastSurfaceSpec != spec) {
                            lastSurfaceSpec = spec
                            playerView.post {
                                runCatching {
                                    (playerView.videoSurfaceView as? android.view.SurfaceView)
                                        ?.holder
                                        ?.setFixedSize(
                                            playerView.width.coerceAtLeast(1),
                                            playerView.height.coerceAtLeast(1),
                                        )
                                }
                            }
                        }
                    },
                    // v0.3.12 guard: never leave a dangling PlayerView
                    // reference behind when the surface detaches — the
                    // aspect button writes through it.
                    onRelease = {
                        it.player = null
                        playerViewRef = null
                        viewModel.bindSubtitleView(null)
                    },
                    modifier = frameModifier,
                )
            }
        }

        if (shownError != null) {
            val retryFocus = remember { FocusRequester() }
            LaunchedEffect(shownError) { runCatching { retryFocus.requestFocus() } }
            // v0.3.19: if the Sources panel below closes without a
            // pick (Back), hand focus back to the error actions — the
            // screen-level opener-restore deliberately skips the
            // error state, and the panel row that held focus leaves
            // composition with the panel.
            LaunchedEffect(picker) {
                if (picker == PlayerPicker.NONE) {
                    runCatching { retryFocus.requestFocus() }
                }
            }
            Column(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        // Same focus gate as the control stack: while
                        // a picker is open, nothing behind it is a
                        // focus-search candidate.
                        .focusProperties { canFocus = picker == PlayerPicker.NONE },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_error),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error,
                )
                shownError?.takeIf { it.isNotBlank() }?.let { detail ->
                    Text(
                        text = detail,
                        style = MaterialTheme.typography.bodyMedium,
                        color = PlavioOnyx.TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 64.dp),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ControlButton(
                        icon = PlavioIcons.Restart,
                        label = stringResource(R.string.plavio_player_retry),
                        onClick = {
                            errorMessage = null
                            // A manual retry is a fresh load session:
                            // full retry budget, full stall deadline,
                            // and any pending automatic retry is
                            // cancelled so it can't fire into the
                            // user's own restart.
                            recoveryJob?.cancel()
                            autoRetryCount = 0
                            loadGen++
                            viewModel.retry(positionMs)
                        },
                        modifier = Modifier.focusRequester(retryFocus),
                    )
                    if (viewModel.nextStream() != null) {
                        ControlButton(
                            icon = PlavioIcons.SkipNext,
                            label = stringResource(R.string.plavio_player_next_source),
                            onClick = {
                                val next = viewModel.nextStream()
                                errorMessage = null
                                recoveryJob?.cancel()
                                autoRetryCount = 0
                                loadGen++
                                if (next != null) viewModel.switchStream(next, positionMs)
                            },
                        )
                    }
                    ControlButton(
                        icon = Icons.AutoMirrored.Filled.List,
                        label = stringResource(R.string.plavio_player_sources),
                        onClick = { picker = PlayerPicker.SOURCES },
                    )
                }
            }
            // v0.3.19: the Sources button above used to be dead — it
            // set the picker, but the only Sources panel lived in the
            // control layer, which is un-composed while an error
            // shows. Compose the same panel here, above the error
            // actions; a pick clears the error and switches through
            // the same switchStream path as the panel in the control
            // layer (and as this layer's own Next-source button).
            if (picker == PlayerPicker.SOURCES) {
                SourcesPanel(
                    streams = displayRequest.streams,
                    currentUrl = displayRequest.streamUrl,
                    onPick = { stream ->
                        errorMessage = null
                        // A manual pick supersedes any pending
                        // automatic retry (v0.3.17).
                        recoveryJob?.cancel()
                        autoRetryCount = 0
                        viewModel.switchStream(stream, positionMs)
                        picker = PlayerPicker.NONE
                        // A pick is a new start: fresh 30s clock.
                        sourcesAutoOpened = false
                        sourcesStartGen++
                    },
                    onReload = { viewModel.refreshStreams() },
                    modifier = Modifier.align(Alignment.CenterEnd),
                )
            }
        } else if ((activePlayer == null || (buffering && !reachedReady)) && !showResumePrompt) {
            // v0.3.13: the loading face of the player. v0.3.12 showed a
            // bare spinner on pure black for the whole start (6s+ on
            // the owner's TV read as a hang) — now the title's own art
            // + name + source are up from the first frame, and the
            // layer also covers the initial buffering stretch (and a
            // failover's, since reachedReady is keyed by stream URL)
            // until the first READY.
            PlayerLoadingLayer(
                request = displayRequest,
                modifier = Modifier.fillMaxSize(),
            )
            // v0.3.10: the control layer that normally hosts the
            // Sources panel is un-composed in this state (its gate
            // needs a first READY), so a hung start could never show
            // the panel the 30s auto-popup opens. The loading face
            // composes the same panel itself — exactly the error
            // layer's precedent above — with loading still running
            // behind it; a pick switches through the same path.
            if (picker == PlayerPicker.SOURCES) {
                SourcesPanel(
                    streams = displayRequest.streams,
                    currentUrl = displayRequest.streamUrl,
                    onPick = { stream ->
                        errorMessage = null
                        // A manual pick supersedes any pending
                        // automatic retry (v0.3.17).
                        recoveryJob?.cancel()
                        autoRetryCount = 0
                        viewModel.switchStream(stream, positionMs)
                        picker = PlayerPicker.NONE
                        // A pick is a new start: fresh 30s clock.
                        sourcesAutoOpened = false
                        sourcesStartGen++
                    },
                    onReload = { viewModel.refreshStreams() },
                    modifier = Modifier.align(Alignment.CenterEnd),
                )
            }
        }

        // Recovery note (v0.3.12 shape, v0.3.17 method): while an
        // automatic same-source recovery runs, say so — the old behaviour was a silent spinner
        // that read as a hang. Non-focusable, auto-clears.
        if (failoverNote != null && shownError == null) {
            Box(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .padding(top = 120.dp)
                        .background(
                            PlavioOnyx.Panel.copy(alpha = 0.92f),
                            RoundedCornerShape(12.dp),
                        ),
            ) {
                Text(
                    text = failoverNote ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                )
            }
        }

        // Resume prompt (phone parity): ask before starting when a
        // saved position exists; playback only begins on a choice.
        if (showResumePrompt) {
            val resumeFocus = remember { FocusRequester() }
            LaunchedEffect(Unit) { runCatching { resumeFocus.requestFocus() } }
            Column(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .width(440.dp)
                        .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                        .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                        .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text =
                        stringResource(
                            R.string.plavio_player_resume_from,
                            formatTime(resumePositionMs),
                        ),
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                )
                Text(
                    text = displayRequest.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PlavioOnyx.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ControlButton(
                        icon = Icons.Filled.PlayArrow,
                        label = stringResource(R.string.plavio_player_resume),
                        onClick = { resumeDecided = true },
                        modifier = Modifier.focusRequester(resumeFocus),
                    )
                    ControlButton(
                        icon = PlavioIcons.Restart,
                        label = stringResource(R.string.plavio_player_start_over),
                        onClick = {
                            viewModel.clearProgress()
                            startOver = true
                            resumeDecided = true
                        },
                    )
                }
            }
        }

        // v0.3.21 (study fix #4): the buffering spinner lives
        // OUTSIDE the control layer now — buffering alone no longer
        // composes the full control stack. While buffering with the
        // controls hidden, this spinner is the only thing composed
        // over the video; its visibility matches the old in-layer
        // spinner exactly (ready + buffering + no next-up card).
        if (activePlayer != null && shownError == null && reachedReady && buffering &&
            nextUpRequest == null
        ) {
            OrbitLoader(
                modifier =
                    Modifier
                        .align(Alignment.Center)
                        .size(64.dp),
                alwaysAnimate = true,
            )
        }

        // Control layer (v0.3.7): fully UN-COMPOSED when hidden —
        // the old alpha(0f) kept the full-screen scrims, seek bar and
        // buttons laid out and drawn over every video frame, plus a
        // 2 Hz recomposition tax. v0.3.21: the old `|| buffering`
        // exception is gone (see the spinner above) — buffering no
        // longer keeps this whole layer composed.
        if (activePlayer != null && shownError == null &&
            (reachedReady || !buffering) &&
            (controlsVisible || picker != PlayerPicker.NONE || nextUpRequest != null)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
            ) {
                // Title block (v0.3.10): the top gradient scrim is
                // GONE — user feedback called the overlays vintage and
                // said they hinder the picture. The title now sits
                // directly on the video, Sample C style: plain text,
                // no background band behind it.
                Column(
                    modifier =
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(horizontal = 48.dp, vertical = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = displayRequest.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (displayRequest.isLive) {
                            Box(
                                modifier =
                                    Modifier
                                        .background(Color(0xFFE53935), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                            ) {
                                Text(
                                    text = stringResource(R.string.plavio_player_live_badge),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                )
                            }
                        }
                    }
                    // Episode line (series): S<n> E<n> — <episode title>.
                    if (!displayRequest.isMovie && displayRequest.episode > 0) {
                        Text(
                            text =
                                "S${displayRequest.season} E${displayRequest.episode}" +
                                    (displayRequest.episodeTitle?.let { " — $it" } ?: ""),
                            style = MaterialTheme.typography.bodyLarge,
                            color = PlavioOnyx.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    // Current source line: addon/provider + quality.
                    val sourceLine =
                        listOfNotNull(displayRequest.sourceName, displayRequest.streamLabel)
                            .joinToString(" • ")
                    if (sourceLine.isNotBlank()) {
                        Text(
                            text = sourceLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = PlavioOnyx.TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                (episodeError ?: downloadNotice)?.let { message ->
                    Box(
                        modifier =
                            Modifier
                                .align(Alignment.Center)
                                .background(
                                    PlavioOnyx.Panel.copy(alpha = 0.92f),
                                    RoundedCornerShape(12.dp),
                                ),
                    ) {
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        )
                    }
                }

                // Bottom controls — v0.3.19 (owner order, supersedes
                // the v0.3.16 Sample B arrangement of a transport
                // capsule over two action rows): ONE wide frosted
                // capsule holds everything. Line 1 is the seek line
                // on its own (the SeekBar with its time labels). Line
                // 2 is ONE single row with every button: the transport
                // group first (rewind · big accent play/pause ·
                // forward), a divider, then the action buttons.
                // v0.3.22 (owner's word on v0.3.21, superseding the
                // 2026-11-02 icon-only rule): every action button
                // carries its title under the glyph — Subs, Audio,
                // Sources, Download, Speed, Aspect say what they
                // are. Still no live value or mode text in the row.
                // Episodes uses the PlaylistPlay glyph so it never
                // shares Sources' List icon. The skip-intro capsule
                // still floats separately above (below). Focus lands
                // on the seek bar when the layer appears, as before;
                // DOWN from it reaches the row.
                if (nextUpRequest == null) {
                    Column(
                        modifier =
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 48.dp, vertical = 24.dp)
                                // v0.3.19 FOCUS TRAP: while any picker
                                // popup is open, this whole control
                                // stack leaves the focus graph — D-pad
                                // navigation inside the popup can then
                                // never land on the controls sitting
                                // behind it (the owner's "it also goes
                                // back to the video player controls").
                                // The stack stays fully VISIBLE; only
                                // its focusability is gated. The popup's
                                // own subtree is a sibling of this
                                // Column, never a child, so the popup
                                // itself is unaffected.
                                .focusProperties { canFocus = picker == PlayerPicker.NONE }
                                .focusGroup(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Column(
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .widthIn(max = 1000.dp)
                                    .clip(RoundedCornerShape(36.dp))
                                    .background(PlavioOnyx.Panel.copy(alpha = 0.88f))
                                    .border(
                                        1.dp,
                                        PlavioOnyx.GlassBorder,
                                        RoundedCornerShape(36.dp),
                                    )
                                    .padding(horizontal = 28.dp, vertical = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            SeekBar(
                                // v0.3.23: lambda-fed so the ticker's
                                // writes recompose only the seek bar,
                                // not this whole screen body.
                                positionMs = { positionMs },
                                durationMs = { durationMs },
                                bufferedMs = { bufferedMs },
                                isLive = displayRequest.isLive,
                                onSeekKey = { delta -> seekBy(delta) },
                                onTogglePlay = { togglePlay() },
                                skipForwardMs = skipForwardMs,
                                skipBackMs = skipBackMs,
                                focusRequester = seekFocus,
                            )
                            Row(
                                modifier = Modifier.align(Alignment.CenterHorizontally),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                // Transport group (unchanged buttons):
                                // rewind · play/pause · forward, seeking
                                // by the configured skip amounts; D-pad
                                // left/right on the seek bar above still
                                // works via SeekBar.onSeekKey.
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    TransportButton(
                                        icon = PlavioIcons.Rewind,
                                        onClick = { seekBy(-skipBackMs) },
                                    )
                                    PlayerPlayButton(
                                        isPlaying = isPlaying,
                                        onClick = { togglePlay() },
                                    )
                                    TransportButton(
                                        icon = PlavioIcons.FastForward,
                                        onClick = { seekBy(skipForwardMs) },
                                    )
                                }
                                Box(
                                    modifier =
                                        Modifier
                                            .width(1.dp)
                                            .height(30.dp)
                                            .background(PlavioOnyx.GlassBorder),
                                )
                                if (canZap) {
                                    PlayerRowButton(
                                        icon = PlavioIcons.SkipPrevious,
                                        label = stringResource(R.string.plavio_player_previous),
                                        onClick = { zap(-1) },
                                    )
                                    PlayerRowButton(
                                        icon = PlavioIcons.SkipNext,
                                        label = stringResource(R.string.plavio_player_next),
                                        onClick = { zap(1) },
                                    )
                                }
                                if (hasEpisodes && nextVideo != null && onPlayNextEpisode != null) {
                                    PlayerRowButton(
                                        icon = PlavioIcons.SkipNext,
                                        label = stringResource(R.string.plavio_player_next),
                                        onClick = { playEpisode(nextVideo) },
                                    )
                                }
                                if (hasEpisodes && onPlayNextEpisode != null) {
                                    PlayerRowButton(
                                        icon = PlavioIcons.PlaylistPlay,
                                        label = stringResource(R.string.plavio_player_episodes),
                                        onClick = { picker = PlayerPicker.EPISODES },
                                        modifier = Modifier.focusRequester(episodesBtnFocus),
                                    )
                                }
                                PlayerRowButton(
                                    icon = PlavioIcons.Subtitles,
                                    label = stringResource(R.string.plavio_player_subs),
                                    onClick = { picker = PlayerPicker.SUBTITLES },
                                    modifier = Modifier.focusRequester(subtitlesBtnFocus),
                                )
                                PlayerRowButton(
                                    icon = PlavioIcons.Audiotrack,
                                    label = stringResource(R.string.plavio_player_audio),
                                    onClick = { picker = PlayerPicker.AUDIO },
                                    modifier = Modifier.focusRequester(audioBtnFocus),
                                )
                                PlayerRowButton(
                                    icon = Icons.AutoMirrored.Filled.List,
                                    label = stringResource(R.string.plavio_player_sources),
                                    onClick = { picker = PlayerPicker.SOURCES },
                                    modifier = Modifier.focusRequester(sourcesBtnFocus),
                                )
                                // Download (v0.3.16 behaviour, unchanged):
                                // same engine the Streams screen feeds,
                                // fed from the playing request. VOD only —
                                // a live channel has nothing to save.
                                if (!displayRequest.isLive) {
                                    val downloadStartedText =
                                        stringResource(R.string.plavio_player_download_started)
                                    val downloadDashText =
                                        stringResource(R.string.plavio_player_download_dash)
                                    PlayerRowButton(
                                        icon = PlavioIcons.Download,
                                        label = stringResource(R.string.plavio_download),
                                        onClick = {
                                            downloadNotice =
                                                when (
                                                    viewModel.downloadCurrent(displayRequest)
                                                ) {
                                                    PlavioPlayerViewModel.PlayerDownloadResult.STARTED ->
                                                        downloadStartedText
                                                    PlavioPlayerViewModel.PlayerDownloadResult.DASH ->
                                                        downloadDashText
                                                }
                                        },
                                    )
                                }
                                PlayerRowButton(
                                    icon = PlavioIcons.Speed,
                                    label = stringResource(R.string.plavio_player_speed),
                                    onClick = { picker = PlayerPicker.SPEED },
                                    modifier = Modifier.focusRequester(speedBtnFocus),
                                )
                                PlayerRowButton(
                                    icon = PlavioIcons.Aspect,
                                    label = stringResource(R.string.plavio_player_aspect),
                                    onClick = {
                                        resizeMode =
                                            when (resizeMode) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                        playerViewRef?.resizeMode = resizeMode
                                    },
                                )
                            }
                        }
                    }
                }

                // Skip intro / recap / outro capsule (IntroDB, phone
                // placement: bottom-right above the controls). Takes
                // focus when it appears so it is one press away.
                val segment = activeSegment
                if (segment != null && picker == PlayerPicker.NONE && nextUpRequest == null) {
                    val skipFocus = remember { FocusRequester() }
                    LaunchedEffect(segment) {
                        if (controlsVisible) runCatching { skipFocus.requestFocus() }
                    }
                    ControlButton(
                        icon = PlavioIcons.FastForward,
                        label = segment.type.buttonLabel(),
                        onClick = {
                            val target = segment.endMs + 400
                            player?.seekTo(target)
                            positionMs = target
                        },
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                // v0.3.19: re-seated for the single
                                // capsule stack — the v0.3.16 lift
                                // to 312dp matched the old three-row
                                // stack and would leave this floating.
                                // v0.3.22: +14dp for the button row's
                                // new under-glyph labels.
                                .padding(end = 48.dp, bottom = 210.dp)
                                .focusRequester(skipFocus),
                    )
                }

                // Audio track picker (single rail, like before) — now
                // with the phone's "Auto" row on top and the preferred
                // audio language at the bottom (its home is the player).
                if (picker == PlayerPicker.AUDIO) {
                    val autoLabel = stringResource(R.string.plavio_player_auto)
                    val options =
                        remember(activePlayer, tracksVersion, picker) {
                            val tracks = trackOptions(activePlayer, text = false)
                            val hasOverride =
                                runCatching {
                                    activePlayer.trackSelectionParameters.overrides.keys
                                        .any { it.type == C.TRACK_TYPE_AUDIO }
                                }.getOrDefault(false)
                            listOf(
                                TrackOption(
                                    label = autoLabel,
                                    group = null,
                                    trackIndex = -1,
                                    selected = !hasOverride,
                                    isAuto = true,
                                ),
                            ) + tracks
                        }
                    TrackPickerPanel(
                        title = stringResource(R.string.plavio_player_audio),
                        emptyText = stringResource(R.string.plavio_player_no_audio),
                        options = options,
                        onPick = { option ->
                            applyTrackOption(activePlayer, text = false, option)
                            tracksVersion++
                            picker = PlayerPicker.NONE
                        },
                        footer = {
                            PanelFooterRow(
                                label =
                                    stringResource(R.string.plavio_settings_audio_lang) + " — " +
                                        (preferredAudioLanguage?.let { languageDisplayName(it) }
                                            ?: stringResource(R.string.plavio_settings_lang_none)),
                                onClick = { picker = PlayerPicker.AUDIO_PREF },
                            )
                        },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }

                // Preferred audio language picker (from the Audio panel).
                if (picker == PlayerPicker.AUDIO_PREF) {
                    PreferredLanguagePanel(
                        title = stringResource(R.string.plavio_settings_audio_lang),
                        current = preferredAudioLanguage,
                        onPick = { code ->
                            viewModel.setPreferredAudioLanguage(code)
                            picker = PlayerPicker.NONE
                        },
                        modifier =
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 48.dp),
                    )
                }

                // Playback speed panel (phone's 0.5×–2× set).
                if (picker == PlayerPicker.SPEED) {
                    SpeedPanel(
                        current = speed,
                        onPick = { picked ->
                            speed = picked
                            runCatching {
                                activePlayer.playbackParameters = PlaybackParameters(picked)
                            }
                            picker = PlayerPicker.NONE
                        },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }

                // Episodes picker
                if (picker == PlayerPicker.EPISODES) {
                    EpisodesPanel(
                        episodes = request.episodes,
                        currentVideoId = request.videoId,
                        onPick = { video ->
                            picker = PlayerPicker.NONE
                            playEpisode(video)
                        },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }

                // Sources panel (v0.3.18): an overlay INSIDE the player —
                // picking a row switches the playing source through the
                // ViewModel's position-keeping switchStream path; the
                // player screen never leaves composition and playback is
                // not torn down. (The old capsule navigated away to the
                // Streams destination, replacing the Play entry.)
                if (picker == PlayerPicker.SOURCES) {
                    SourcesPanel(
                        streams = displayRequest.streams,
                        currentUrl = displayRequest.streamUrl,
                        onPick = { stream ->
                            errorMessage = null
                            // A manual pick supersedes any pending
                            // automatic retry (v0.3.17).
                            recoveryJob?.cancel()
                            autoRetryCount = 0
                            viewModel.switchStream(stream, positionMs)
                            picker = PlayerPicker.NONE
                            // A pick is a new start: fresh 30s clock.
                            sourcesAutoOpened = false
                            sourcesStartGen++
                        },
                        onReload = { viewModel.refreshStreams() },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }

                // Subtitle panel (v0.3.16: Sample B bottom strip —
                // see PlavioSubtitlePanel)
                if (picker == PlayerPicker.SUBTITLES) {
                    val textOptions =
                        remember(activePlayer, tracksVersion, localSubtitles) {
                            trackOptions(activePlayer, text = true)
                        }
                    // v0.3.18 rows: Off + one row per ADDON subtitle
                    // (from the live request — addon subtitles no
                    // longer ride the media item, so most have no
                    // player track at all; the old rows were built
                    // from the track list alone, which is why a
                    // broken track meant a broken panel) + the
                    // player's EMBEDDED text tracks. An addon row's
                    // option carries its "e:<index>" id and, when a
                    // libass media track exists for it, that track's
                    // group/index; pickSubtitleRow below routes the
                    // pick: sidecar for everything except libass ASS
                    // on its media track.
                    val addonSubs = displayRequest.subtitles
                    val embeddedOptions =
                        textOptions.filter { option ->
                            !option.isOff && option.formatId?.startsWith("e:") != true
                        }
                    val mediaOptionByIndex =
                        textOptions
                            .filter { !it.isOff }
                            .mapNotNull { option ->
                                option.formatId
                                    ?.takeIf { it.startsWith("e:") }
                                    ?.removePrefix("e:")
                                    ?.toIntOrNull()
                                    ?.let { it to option }
                            }.toMap()
                    // v0.3.21 (study fix #1): a libass pick that
                    // rebuilt the player applies its media track as
                    // soon as the rebuilt player's tracks land.
                    val pendingLibass by viewModel.pendingLibassSubtitle.collectAsState()
                    LaunchedEffect(activePlayer, textOptions, pendingLibass) {
                        val pending = pendingLibass ?: return@LaunchedEffect
                        val index = addonSubs.indexOfFirst { it.url == pending.url }
                        if (index < 0) {
                            viewModel.clearPendingLibassSubtitle()
                            return@LaunchedEffect
                        }
                        val option = mediaOptionByIndex[index]
                        if (option?.group != null) {
                            viewModel.stopSidecar()
                            applyTrackOption(activePlayer, text = true, option)
                            tracksVersion++
                            viewModel.clearPendingLibassSubtitle()
                        }
                    }
                    val offOption =
                        textOptions.firstOrNull { it.isOff }
                            ?: TrackOption(
                                label = "Off",
                                group = null,
                                trackIndex = -1,
                                selected = false,
                                isOff = true,
                            )
                    val languages =
                        remember(addonSubs, textOptions, subtitleLanguages) {
                            val present =
                                (
                                    addonSubs.map { it.lang } +
                                        embeddedOptions.mapNotNull { it.language }
                                    )
                                    .filter { it.isNotBlank() && it != "und" }
                                    .distinct()
                            val preferred = subtitleLanguages.filter { it in present }
                            preferred + present.filter { it !in preferred }
                        }
                    val rows =
                        buildList {
                            add(
                                SubtitleRow(
                                    option =
                                        offOption.copy(
                                            // The sidecar disables the
                                            // media text type too, so
                                            // "disabled" alone does not
                                            // mean Off any more.
                                            selected =
                                                offOption.selected && sidecarSubtitle == null,
                                        ),
                                    title = offOption.label,
                                    source = null,
                                ),
                            )
                            addonSubs.forEachIndexed { index, sub ->
                                val mediaOption = mediaOptionByIndex[index]
                                val selected =
                                    if (viewModel.sidecarEligible(sub)) {
                                        sidecarSubtitle?.url == sub.url
                                    } else {
                                        mediaOption?.selected == true
                                    }
                                add(
                                    SubtitleRow(
                                        option =
                                            TrackOption(
                                                label = languageDisplayName(sub.lang),
                                                group = mediaOption?.group,
                                                trackIndex = mediaOption?.trackIndex ?: -1,
                                                selected = selected,
                                                language = sub.lang,
                                                formatId = "e:$index",
                                                forced = mediaOption?.forced ?: false,
                                            ),
                                        title = languageDisplayName(sub.lang),
                                        source = subtitleHost(sub.url),
                                    ),
                                )
                            }
                            embeddedOptions.forEach { option ->
                                add(
                                    SubtitleRow(
                                        option = option,
                                        title = option.label,
                                        source = stringResource(R.string.plavio_sub_embedded),
                                    ),
                                )
                            }
                        }
                    fun pickSubtitleRow(row: SubtitleRow) {
                        val option = row.option
                        val addonIndex =
                            option.formatId
                                ?.takeIf { it.startsWith("e:") }
                                ?.removePrefix("e:")
                                ?.toIntOrNull()
                        val sub = addonIndex?.let { addonSubs.getOrNull(it) }
                        // v0.3.21: any pick that is not itself a
                        // libass rebuild abandons a pending one.
                        if (sub == null || !viewModel.needsLibassForPick(sub)) {
                            viewModel.clearPendingLibassSubtitle()
                        }
                        when {
                            option.isOff -> {
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                            sub != null && viewModel.needsLibassForPick(sub) -> {
                                // v0.3.21 (study fix #1): an ASS/SSA
                                // pick on a player built without
                                // libass (start() builds it on pick
                                // only now) — rebuild with libass at
                                // the current position; the pending
                                // pick applies itself when the new
                                // player's tracks land (effect above).
                                viewModel.rebuildWithLibassFor(sub, positionMs)
                            }
                            sub != null && viewModel.sidecarEligible(sub) -> {
                                viewModel.selectSidecarSubtitle(sub)
                            }
                            sub != null && option.group != null -> {
                                // libass ASS on its media track.
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                            sub != null -> {
                                // No media track and not
                                // sidecar-eligible (defensive — the
                                // eligibility sweep covers every
                                // non-libass format): the sidecar
                                // attempt is the best route left.
                                viewModel.selectSidecarSubtitle(sub)
                            }
                            else -> {
                                // Embedded track.
                                viewModel.stopSidecar()
                                applyTrackOption(activePlayer, text = true, option)
                            }
                        }
                        tracksVersion++
                    }
                    val selectedOption = rows.firstOrNull { it.option.selected }?.option
                    val selectedSub =
                        when {
                            sidecarSubtitle != null -> sidecarSubtitle
                            else ->
                                selectedOption?.formatId
                                    ?.takeIf { it.startsWith("e:") }
                                    ?.removePrefix("e:")
                                    ?.toIntOrNull()
                                    ?.let { addonSubs.getOrNull(it) }
                        }
                    val selectedLocal =
                        selectedSub?.let { sub ->
                            localSubtitles.firstOrNull { it.sub.url == sub.url }
                        }
                    PlavioSubtitlePanel(
                        languages = languages,
                        selectedLanguage = selectedOption?.language,
                        onSelectLanguage = { code ->
                            // The Languages rail routes through the
                            // same pick as the track rows (v0.3.18):
                            // first row of that language, sidecar
                            // included.
                            if (code == null) {
                                rows.firstOrNull { it.option.isOff }?.let { pickSubtitleRow(it) }
                            } else {
                                rows
                                    .firstOrNull { !it.option.isOff && it.option.language == code }
                                    ?.let { pickSubtitleRow(it) }
                            }
                        },
                        rows = rows,
                        onPickRow = { row -> pickSubtitleRow(row) },
                        style = subtitleStyle,
                        onStyleChange = { style -> viewModel.updateSubtitleStyle { style } },
                        delayMs = subtitleDelayMs,
                        delayEnabled = selectedLocal != null,
                        onDelayChange = { viewModel.setSubtitleDelay(it) },
                        onReloadSubtitles = { viewModel.reloadSubtitles() },
                        onCaptureCues = {
                            val at = viewModel.currentPositionMs()
                            val cues =
                                selectedLocal?.let { viewModel.captureCues(it) }
                                    ?: emptyList()
                            at to cues
                        },
                        onCuePicked = { capturedAtMs, cueStartMs ->
                            // The phone's rule: the heard line should
                            // have started 300ms before the tap.
                            viewModel.setSubtitleDelay(capturedAtMs - cueStartMs - 300)
                        },
                        onResetDefaults = { viewModel.resetSubtitleStyle() },
                        preferredLanguages = subtitleLanguages,
                        onPreferredLanguagesChange = { viewModel.setSubtitleLanguages(it) },
                        onFetchOnlineSubtitles = { viewModel.fetchOnlineSubtitles() },
                        onAttachOnlineSubtitle = { viewModel.attachOnlineSubtitle(it) },
                        modifier =
                            Modifier
                                // v0.3.16 (note 11, Sample B): the
                                // subtitle panel is a wide frosted
                                // strip from the BOTTOM of the
                                // screen (fractions of the screen,
                                // per the adaptive rule — never a
                                // fixed size tuned to one TV), so
                                // the playing subtitles stay visible
                                // above it and preview every change
                                // live.
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 24.dp)
                                .fillMaxWidth(0.88f)
                                .fillMaxHeight(0.54f),
                    )
                }

                // Next-episode countdown card
                val upNext = nextUpRequest
                if (upNext != null && nextUpVideo != null) {
                    NextEpisodeCard(
                        video = nextUpVideo!!,
                        seriesName = request.seriesName ?: request.title,
                        secondsLeft = nextUpSeconds,
                        onPlayNow = { onPlayNextEpisode?.invoke(upNext) },
                        onCancel = { nextUpRequest = null },
                        grabFocus = picker == PlayerPicker.NONE,
                        modifier =
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 48.dp, bottom = 40.dp)
                                // v0.3.19: same trap as the control
                                // stack — while a picker popup is open
                                // the next-up card is not a focus
                                // target either (and its focus grab
                                // below is ignored while gated), so a
                                // countdown ending mid-popup cannot
                                // pull focus out of the popup.
                                .focusProperties { canFocus = picker == PlayerPicker.NONE }
                                .focusGroup(),
                    )
                }
            }
        }
    }
}

/** Applies the shared subtitle style to the ExoPlayer subtitle view, live. */
@OptIn(UnstableApi::class)
private fun applySubtitleStyle(
    playerView: PlayerView,
    style: SubtitleStyle,
) {
    val subtitleView = playerView.subtitleView ?: return
    subtitleView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, style.fontSizeSp.toFloat())
    subtitleView.setStyle(
        CaptionStyleCompat(
            style.textColorArgb,
            // v0.3.22: the caption background is the user's style
            // choice now (colour + opacity; opacity 0 keeps the
            // historic no-box look). The window colour stays clear.
            style.backgroundColorArgb,
            AndroidColor.TRANSPARENT,
            // v0.3.22: the full edge set (none / outline / drop
            // shadow / raised / depressed), not just outline on/off.
            // SubtitleEdge mirrors these CaptionStyleCompat values.
            when (style.edgeType) {
                com.github.damontecres.wholphin.plavio.SubtitleEdge.NONE ->
                    CaptionStyleCompat.EDGE_TYPE_NONE
                com.github.damontecres.wholphin.plavio.SubtitleEdge.DROP_SHADOW ->
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                com.github.damontecres.wholphin.plavio.SubtitleEdge.RAISED ->
                    CaptionStyleCompat.EDGE_TYPE_RAISED
                com.github.damontecres.wholphin.plavio.SubtitleEdge.DEPRESSED ->
                    CaptionStyleCompat.EDGE_TYPE_DEPRESSED
                else -> CaptionStyleCompat.EDGE_TYPE_OUTLINE
            },
            style.outlineColorArgb,
            if (style.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT,
        ),
    )
    subtitleView.setApplyEmbeddedStyles(false)
    // v0.3.18: the base bottom fraction is the reference player's
    // 0.06 (ours was two thirds of SubtitleView's 0.0533 default
    // ≈ 0.0355, which sat the captions lower than the reference's);
    // the user's Position offset still adds on top.
    val fraction =
        (0.06f + style.bottomOffset / 1000f).coerceIn(0f, 0.35f)
    subtitleView.setBottomPaddingFraction(fraction)
}

/** Display host for an addon subtitle URL ("Addon" when it doesn't parse). */
private fun subtitleHost(url: String): String? =
    runCatching { java.net.URI(url).host }
        .getOrNull()
        ?.removePrefix("www.")
        ?.takeIf { it.isNotBlank() }

@Composable
private fun NextEpisodeCard(
    video: Video,
    seriesName: String,
    secondsLeft: Int,
    onPlayNow: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    // v0.3.19: false while a picker popup is open (the card is
    // focus-gated then — see the call site). Keyed into the grab
    // effect so the card takes focus when the popup closes over it,
    // not just when it first composes.
    grabFocus: Boolean = true,
) {
    val playFocus = remember { FocusRequester() }
    LaunchedEffect(grabFocus) {
        if (grabFocus) runCatching { playFocus.requestFocus() }
    }
    Column(
        modifier =
            modifier
                .width(420.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_up_next),
            style = MaterialTheme.typography.labelLarge,
            color = LocalPlavioAccent.current.primary,
        )
        Text(
            text =
                "S${video.season} E${video.episode}" +
                    (video.title?.let { " — $it" } ?: ""),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = seriesName,
            style = MaterialTheme.typography.bodyMedium,
            color = PlavioOnyx.TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ControlButton(
                icon = Icons.Filled.PlayArrow,
                label =
                    "${stringResource(R.string.plavio_play_now)} · " +
                        stringResource(R.string.plavio_playing_in, secondsLeft),
                onClick = onPlayNow,
                modifier = Modifier.focusRequester(playFocus),
            )
            ControlButton(
                icon = Icons.Filled.Close,
                label = stringResource(R.string.plavio_cancel),
                onClick = onCancel,
            )
        }
    }
}

@Composable
private fun EpisodesPanel(
    episodes: List<Video>,
    currentVideoId: String,
    onPick: (Video) -> Unit,
    modifier: Modifier = Modifier,
) {
    val sorted = remember(episodes) { episodes.sortedWith(compareBy({ it.season }, { it.episode })) }
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    Column(
        modifier =
            modifier
                .width(440.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_episodes),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        LazyColumn(
            modifier = Modifier.fillMaxWidth().height(420.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // Grouped by season with headers (phone parity); episodes
            // carry their overview line when the addon provided one.
            val seasons = sorted.map { it.season }.distinct()
            seasons.forEach { season ->
                item(key = "season-$season") {
                    Text(
                        text = stringResource(R.string.plavio_player_season, season),
                        style = MaterialTheme.typography.titleSmall,
                        color = LocalPlavioAccent.current.primary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    )
                }
                itemsIndexed(
                    sorted.filter { it.season == season },
                    key = { index, video -> "${video.id}|$index" },
                ) { _, video ->
                    val isCurrent = video.id == currentVideoId
                    Surface(
                        onClick = { onPick(video) },
                        modifier =
                            if (isCurrent) Modifier.focusRequester(firstFocus) else Modifier,
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor =
                                    if (isCurrent) {
                                        LocalPlavioAccent.current.primary
                                    } else {
                                        Color.White
                                    },
                                // v0.3.13: focus = pink ring only.
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor =
                                    if (isCurrent) {
                                        LocalPlavioAccent.current.primary
                                    } else {
                                        Color.White
                                    },
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor =
                                    if (isCurrent) {
                                        LocalPlavioAccent.current.primary
                                    } else {
                                        Color.White
                                    },
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(
                                text =
                                    "S${video.season} E${video.episode}" +
                                        (video.title?.let { " — $it" } ?: ""),
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            video.overview?.takeIf { it.isNotBlank() }?.let { overview ->
                                Text(
                                    text = overview,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PlavioOnyx.TextSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The player's loading face (v0.3.13): the title's backdrop (poster
 * as fallback) under a scrim, with the source line, the title and
 * the spinner — composed from the first frame of a start, so a slow
 * stream never presents as a pure-black void. The recovery-ladder
 * note composes on top of this layer while a failover runs.
 */
@Composable
private fun PlayerLoadingLayer(
    request: PlaybackRequest,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.background(Color.Black)) {
        val art = request.backdrop ?: request.poster
        if (art != null) {
            AsyncImage(
                model =
                    ImageRequest
                        .Builder(LocalContext.current)
                        .data(art)
                        .size(1280, 720)
                        .crossfade(false)
                        .build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f)),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors =
                                    listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.88f),
                                    ),
                                startY = 260f,
                            ),
                        ),
            )
        }
        Column(
            modifier =
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 48.dp, vertical = 40.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val sourceLine =
                listOfNotNull(request.sourceName, request.streamLabel)
                    .joinToString(" • ")
            if (sourceLine.isNotBlank()) {
                Text(
                    text = sourceLine,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PlavioOnyx.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = request.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // v0.3.14: alwaysAnimate — the reduced-motion /
                // system-animator gate froze this circle solid on
                // the owner's TV; a loading spinner must spin.
                OrbitLoader(modifier = Modifier.size(36.dp), alwaysAnimate = true)
                Text(
                    text = stringResource(R.string.plavio_detail_loading),
                    style = MaterialTheme.typography.bodyLarge,
                    color = PlavioOnyx.TextSecondary,
                )
            }
        }
    }
}

@Composable
private fun SeekBar(
    positionMs: () -> Long,
    durationMs: () -> Long,
    bufferedMs: () -> Long,
    isLive: Boolean,
    onSeekKey: (Long) -> Unit,
    onTogglePlay: () -> Unit,
    skipForwardMs: Long,
    skipBackMs: Long,
    focusRequester: FocusRequester,
) {
    val accent = LocalPlavioAccent.current
    // v0.3.23: snapshot the lambda-fed progress values once per pass.
    val pos = positionMs()
    val dur = durationMs()
    val buf = bufferedMs()
    var focused by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester)
                    .onFocusChanged { focused = it.isFocused }
                    .focusable()
                    .onKeyEvent { event ->
                        if (event.type != KeyEventType.KeyDown) return@onKeyEvent false
                        when (event.key) {
                            Key.DirectionLeft -> {
                                onSeekKey(-skipBackMs)
                                true
                            }
                            Key.DirectionRight -> {
                                onSeekKey(skipForwardMs)
                                true
                            }
                            Key.DirectionCenter, Key.Enter -> {
                                onTogglePlay()
                                true
                            }
                            else -> false
                        }
                    }
                    .border(
                        // The focus ring in the user's accent
                        // (v0.3.14 — the v0.3.12/13 constant Weave
                        // pink is superseded; the progress fill below
                        // uses the accent too).
                        width = if (focused) 2.5.dp else 0.dp,
                        color = if (focused) accent.primary else Color.Transparent,
                        shape = RoundedCornerShape(50),
                    )
                    .padding(horizontal = 4.dp, vertical = 8.dp),
        ) {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(50)),
            ) {
                // v0.3.13: three honest states. LIVE (an actual live
                // stream) gets NO progress fill at all. VOD with a
                // known duration gets the normal buffered + played
                // bars. VOD whose duration the container hasn't
                // reported yet gets an indeterminate sliding segment
                // — v0.3.12 fell through to an empty track plus a
                // "LIVE" label here, so a movie's seek bar read as a
                // hollow full-length capsule labelled LIVE.
                when {
                    isLive -> Unit
                    dur > 0 -> {
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth((buf.toFloat() / dur).coerceIn(0f, 1f))
                                    .height(6.dp)
                                    .background(Color.White.copy(alpha = 0.35f), RoundedCornerShape(50)),
                        )
                        Box(
                            modifier =
                                Modifier
                                    .fillMaxWidth((pos.toFloat() / dur).coerceIn(0f, 1f))
                                    .height(6.dp)
                                    .background(accent.primary, RoundedCornerShape(50)),
                        )
                    }
                    else -> {
                        val slideTransition =
                            rememberInfiniteTransition(label = "seekIndeterminate")
                        val slide by slideTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 1f,
                            animationSpec =
                                infiniteRepeatable(
                                    animation = tween(durationMillis = 1400, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart,
                                ),
                            label = "seekIndeterminateSlide",
                        )
                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val segmentWidth = maxWidth * 0.3f
                            Box(
                                modifier =
                                    Modifier
                                        .offset(x = (maxWidth - segmentWidth) * slide)
                                        .width(segmentWidth)
                                        .height(6.dp)
                                        .background(accent.primary, RoundedCornerShape(50)),
                            )
                        }
                    }
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (isLive) "" else formatTime(pos),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text =
                    when {
                        isLive -> "LIVE"
                        dur > 0 -> formatTime(dur)
                        else -> "--:--"
                    },
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
        }
    }
}

/**
 * One round glass transport button (rewind / forward) inside the
 * player's centred capsule (Sample B, v0.3.16). Accent ring on
 * focus, scale pinned like every other surface since v0.3.13.
 */
@Composable
private fun TransportButton(
    icon: ImageVector,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                contentColor = Color.White,
                focusedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                focusedContentColor = Color.White,
                pressedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(CircleShape),
    ) {
        Box(
            modifier = Modifier.size(48.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(24.dp))
        }
    }
}

/**
 * The capsule's big play/pause: accent-filled circle, glyph in the
 * luminance-matched on-accent colour, on-accent ring on focus (the
 * PlavioPrimaryButton treatment). Sample B player, v0.3.16.
 */
@Composable
private fun PlayerPlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
) {
    val accent = LocalPlavioAccent.current
    val onAccent = accent.onAccent()
    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = accent.primary,
                contentColor = onAccent,
                focusedContainerColor = accent.primary,
                focusedContentColor = onAccent,
                pressedContainerColor = accent.primary,
                pressedContentColor = onAccent,
            ),
        border =
            ClickableSurfaceDefaults.border(
                border =
                    Border(
                        border = BorderStroke(2.5.dp, onAccent),
                        shape = CircleShape,
                    ),
                focusedBorder =
                    Border(
                        border = BorderStroke(2.5.dp, onAccent),
                        shape = CircleShape,
                    ),
                pressedBorder =
                    Border(
                        border = BorderStroke(2.5.dp, onAccent),
                        shape = CircleShape,
                    ),
            ),
    ) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (isPlaying) PlavioIcons.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(30.dp),
            )
        }
    }
}

@Composable
private fun ControlButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                contentColor = Color.White,
                // v0.3.13: focus = pink ring only, no white fill.
                focusedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                focusedContentColor = Color.White,
                pressedContainerColor = PlavioOnyx.Panel.copy(alpha = 0.85f),
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(50)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            // One line, never wrapped: in v0.3.3 the controls row could
            // overrun the screen width and Compose crushed the LAST
            // button ("Sources") into the leftover sliver, soft-wrapping
            // its label one letter per line into a fake vertical "tab".
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.plavioCentred(),
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/**
 * One action capsule in the player's single button row: the same
 * glass pill language as [ControlButton] — PanelVariant step over
 * the capsule's Panel fill, accent ring on focus, scale pinned.
 * v0.3.22 (owner's word on v0.3.21, superseding the 2026-11-02
 * icon-only rule): every button carries its title under the glyph —
 * Subs, Audio, Sources, Aspect and the rest say what they are.
 * Icon + label are centred as one column inside the capsule.
 */
@Composable
private fun PlayerRowButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(50)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelVariant.copy(alpha = 0.9f),
                contentColor = Color.White,
                // Focus = the accent ring only, like every Plavio surface.
                focusedContainerColor = PlavioOnyx.PanelVariant.copy(alpha = 0.9f),
                focusedContentColor = Color.White,
                pressedContainerColor = PlavioOnyx.PanelVariant.copy(alpha = 0.9f),
                pressedContentColor = Color.White,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(50)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Text(
                text = label,
                style =
                    MaterialTheme.typography.labelSmall.copy(
                        platformStyle =
                            androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                    ),
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/** The phone player's speed set. */
private val PLAYER_SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

private fun formatSpeed(speed: Float): String {
    val text =
        if (speed % 1f == 0f) {
            speed.toInt().toString()
        } else {
            speed.toString().trimEnd('0').trimEnd('.')
        }
    return "$text×"
}

@Composable
private fun SpeedPanel(
    current: Float,
    onPick: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    Column(
        modifier =
            modifier
                .width(400.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_speed),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(PLAYER_SPEEDS) { index, value ->
                val selected = value == current
                Surface(
                    onClick = { onPick(value) },
                    modifier =
                        if (selected) {
                            Modifier.focusRequester(firstFocus)
                        } else {
                            Modifier
                        },
                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                    colors =
                        ClickableSurfaceDefaults.colors(
                            containerColor = Color.Transparent,
                            contentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                            // v0.3.13: focus = pink ring only.
                            focusedContainerColor = Color.Transparent,
                            focusedContentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                            pressedContainerColor = Color.Transparent,
                            pressedContentColor =
                                if (selected) {
                                    LocalPlavioAccent.current.primary
                                } else {
                                    Color.White
                                },
                        ),
                    border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                ) {
                    Text(
                        text = formatSpeed(value),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
            }
        }
    }
}

/** A footer row inside a picker panel (e.g. the Audio panel's preferred-language entry). */
@Composable
private fun PanelFooterRow(
    label: String,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = PlavioOnyx.TextSecondary,
                // v0.3.13: focus = pink ring only.
                focusedContainerColor = Color.Transparent,
                focusedContentColor = PlavioOnyx.TextSecondary,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = PlavioOnyx.TextSecondary,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun TrackPickerPanel(
    title: String,
    emptyText: String,
    options: List<TrackOption>,
    onPick: (TrackOption) -> Unit,
    modifier: Modifier = Modifier,
    footer: (@Composable () -> Unit)? = null,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(options) {
        runCatching { firstFocus.requestFocus() }
    }
    Column(
        modifier =
            modifier
                .width(400.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        if (options.isEmpty()) {
            Text(
                text = emptyText,
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(options) { index, option ->
                    Surface(
                        onClick = { onPick(option) },
                        modifier =
                            if (index == 0) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                                // v0.3.13: focus = pink ring only.
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = if (option.selected) LocalPlavioAccent.current.primary else Color.White,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Text(
                            text = option.label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
            }
        }
        if (footer != null) {
            Spacer(modifier = Modifier.height(4.dp))
            footer()
        }
    }
}

/** Streams-screen labelling for one source row: "Source · 1080p". */
internal fun sourcePanelLine(stream: StreamItem): String {
    val source = stream.sourceName ?: stream.name ?: "Source"
    val quality = streamQualityLabel(stream)
    return if (quality != null) "$source · $quality" else source
}

/**
 * In-player Sources panel (v0.3.18): the title's fetched streams as a
 * right-side overlay in the player's own panel language (same chrome
 * as [TrackPickerPanel]). The currently playing stream is marked in
 * the accent colour; OK on a row switches through the ViewModel's
 * position-keeping switch path without leaving the player. When the
 * request carries no streams (resumed items), the panel says so and
 * offers a reload through the ViewModel instead of navigating away.
 * Rows carry the Streams screen's labelling (source · quality over
 * the stream's own title line); no Download capsule in here.
 *
 * v0.3.22: shared with the Detail page — its Source button opens
 * THIS panel (same component, same chrome), per the owner's word
 * that Detail sources open exactly like the player's.
 */
@Composable
internal fun SourcesPanel(
    streams: List<StreamItem>,
    currentUrl: String,
    onPick: (StreamItem) -> Unit,
    onReload: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(streams.isNotEmpty()) {
        runCatching { firstFocus.requestFocus() }
    }
    Column(
        modifier =
            modifier
                .width(440.dp)
                .padding(end = 48.dp)
                .background(PlavioOnyx.Panel, RoundedCornerShape(16.dp))
                .border(1.dp, PlavioOnyx.GlassBorder, RoundedCornerShape(16.dp))
                .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_player_sources),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
        )
        if (streams.isEmpty()) {
            Text(
                text = stringResource(R.string.plavio_player_no_sources),
                style = MaterialTheme.typography.bodyMedium,
                color = PlavioOnyx.TextSecondary,
            )
            Surface(
                onClick = onReload,
                modifier = Modifier.focusRequester(firstFocus),
                shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                colors =
                    ClickableSurfaceDefaults.colors(
                        containerColor = Color.Transparent,
                        contentColor = Color.White,
                        focusedContainerColor = Color.Transparent,
                        focusedContentColor = Color.White,
                        pressedContainerColor = Color.Transparent,
                        pressedContentColor = Color.White,
                    ),
                border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
            ) {
                Text(
                    text = stringResource(R.string.plavio_player_reload_sources),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(streams) { index, stream ->
                    val isCurrent = stream.url == currentUrl
                    val accent = LocalPlavioAccent.current.primary
                    Surface(
                        onClick = { onPick(stream) },
                        modifier =
                            if (index == 0) {
                                Modifier.focusRequester(firstFocus)
                            } else {
                                Modifier
                            },
                        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
                        colors =
                            ClickableSurfaceDefaults.colors(
                                containerColor = Color.Transparent,
                                contentColor = if (isCurrent) accent else Color.White,
                                focusedContainerColor = Color.Transparent,
                                focusedContentColor = if (isCurrent) accent else Color.White,
                                pressedContainerColor = Color.Transparent,
                                pressedContentColor = if (isCurrent) accent else Color.White,
                            ),
                        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = sourcePanelLine(stream),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isCurrent) accent else Color.White,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f),
                                )
                                if (isCurrent) {
                                    Text(
                                        text = stringResource(R.string.plavio_player_now_playing),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = accent,
                                    )
                                }
                            }
                            val detail = stream.title ?: stream.filename
                            if (!detail.isNullOrBlank()) {
                                Text(
                                    text = detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PlavioOnyx.TextSecondary,
                                    maxLines = 2,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}
