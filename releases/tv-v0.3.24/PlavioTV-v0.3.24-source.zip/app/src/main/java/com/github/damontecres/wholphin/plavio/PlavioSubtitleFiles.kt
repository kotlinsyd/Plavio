package com.github.damontecres.wholphin.plavio

import androidx.media3.common.MimeTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** A subtitle downloaded to the local cache and identified by content. */
data class LocalSubtitle(
    val sub: Subtitle,
    val file: File,
    val mimeType: String,
)

/**
 * Side-loaded subtitle handling for the TV player, ported from the phone
 * app (SubtitleResolver + SubtitleShifter): addon subtitles are
 * downloaded to the app cache and sniffed for their real format, because
 * ExoPlayer has no delay API for side-loaded subtitles — timing
 * adjustments (the Style rail's delay + Auto Sync) are applied by
 * rewriting the downloaded file with shifted timestamps.
 */
object PlavioSubtitleFiles {
    private const val SUB_CACHE_DIR = "plavio_subs"
    private const val SHIFT_CACHE_DIR = "plavio_subs_shifted"
    private const val CACHE_VERSION = "v3"
    private const val MAX_SUB_BYTES = 4 * 1024 * 1024

    private val client =
        OkHttpClient
            .Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()

    /** Downloads every subtitle to the cache; failures drop that subtitle only. */
    suspend fun resolve(
        subs: List<Subtitle>,
        cacheDir: File,
        headers: Map<String, String> = emptyMap(),
    ): List<LocalSubtitle> =
        withContext(Dispatchers.IO) {
            val dir = File(cacheDir, SUB_CACHE_DIR).apply { mkdirs() }
            subs
                .map { sub ->
                    async {
                        runCatching {
                            val identity =
                                sub.url + "\n" +
                                    headers.toSortedMap().entries
                                        .joinToString("\n") { "${it.key}:${it.value}" }
                            val digest =
                                MessageDigest
                                    .getInstance("SHA-256")
                                    .digest(identity.toByteArray(Charsets.UTF_8))
                                    .take(12)
                                    .joinToString("") { "%02x".format(it.toInt() and 0xff) }
                            val file = File(dir, "${CACHE_VERSION}_sub_$digest")
                            if (!file.exists() || file.length() == 0L) {
                                downloadTo(sub.url, file, headers)
                            }
                            if (!file.exists() || file.length() == 0L) return@async null
                            val head =
                                file.inputStream().use { input ->
                                    val buf = ByteArray(4096)
                                    val n = input.read(buf)
                                    if (n <= 0) return@async null
                                    String(buf, 0, n, Charsets.UTF_8).removePrefix("\uFEFF")
                                }
                            val mime = detectMimeType(head) ?: run {
                                file.delete()
                                return@async null
                            }
                            LocalSubtitle(sub, file, mime)
                        }.getOrNull()
                    }
                }.awaitAll()
                .filterNotNull()
        }

    /** Deletes the cached download + shifted copies of [local] (Auto Sync > Reload). */
    fun invalidate(
        local: LocalSubtitle,
        cacheDir: File,
    ) {
        runCatching { local.file.delete() }
        val key = local.file.absolutePath.hashCode().toUInt().toString(16)
        File(cacheDir, SHIFT_CACHE_DIR).listFiles()?.forEach { f ->
            if (f.name.startsWith("shift_") && f.name.contains(key)) {
                runCatching { f.delete() }
            }
        }
    }

    private fun downloadTo(
        url: String,
        dest: File,
        headers: Map<String, String>,
    ) {
        val request =
            Request
                .Builder()
                .url(url)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .get()
                .build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Subtitle HTTP ${response.code}")
                val body = response.body ?: throw IOException("Empty subtitle response")
                if (body.contentLength() > MAX_SUB_BYTES) throw IOException("Subtitle too large")
                body.byteStream().use { input ->
                    dest.outputStream().use { output ->
                        val buf = ByteArray(8192)
                        var total = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_SUB_BYTES) throw IOException("Subtitle too large")
                            output.write(buf, 0, n)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
    }

    /** Recognize actual subtitle syntax (same sniff rules as the phone). */
    fun detectMimeType(content: String): String? {
        val text = content.removePrefix("\uFEFF").trimStart()
        if (text.startsWith("WEBVTT", ignoreCase = true) &&
            (text.length == 6 || text[6].isWhitespace())
        ) {
            return MimeTypes.TEXT_VTT
        }
        // v0.3.18: ASS/SSA and TTML join the recognized set. Before
        // this, an addon serving either format had its download
        // DELETED here (null = unrecognized) and the subtitle
        // silently vanished from the local set — one of the ways a
        // listed subtitle could never display. Media3's own parsers
        // render both as cues on the stock (non-libass) path.
        if (text.contains("[Script Info]", ignoreCase = true) ||
            text.contains("[Events]", ignoreCase = true)
        ) {
            return MimeTypes.TEXT_SSA
        }
        if (text.startsWith("<?xml") && text.contains("<tt", ignoreCase = true)) {
            return MimeTypes.APPLICATION_TTML
        }
        val srtTimestamp =
            Regex("""(?m)^\s*\d{2}:\d{2}:\d{2}[,.]\d{3}\s+-->\s+\d{2}:\d{2}:\d{2}[,.]\d{3}""")
        val numberedSrt =
            Regex("""(?m)^\s*\d+\s*\r?\n\s*\d{2}:\d{2}:\d{2}[,.]\d{3}\s+-->""")
        return if (srtTimestamp.containsMatchIn(text) || numberedSrt.containsMatchIn(text)) {
            MimeTypes.APPLICATION_SUBRIP
        } else {
            null
        }
    }

    // ------------------------------------------------------------------
    // Timing shift (ported from the phone's SubtitleShifter)
    // ------------------------------------------------------------------

    private val SRT_TS = Regex("""(\d{2}):(\d{2}):(\d{2}),(\d{3})""")
    private val VTT_TS = Regex("""(?:(\d{2,}):)?(\d{2}):(\d{2})\.(\d{3})""")

    /**
     * Returns a copy of [source] with [offsetMs] applied to every cue
     * timestamp (clamped at 0). Shifted files are cached by offset, so
     * re-applying the same offset is instant. A shift failure returns
     * the original file — it must never break subtitles.
     */
    fun shiftedFile(
        source: File,
        offsetMs: Long,
        cacheDir: File,
    ): File {
        if (offsetMs == 0L) return source
        return runCatching {
            val dir = File(cacheDir, SHIFT_CACHE_DIR).apply { mkdirs() }
            val sourceKey = source.absolutePath.hashCode().toUInt().toString(16)
            val out = File(dir, "shift_${offsetMs}_${sourceKey}_${source.name}")
            if (out.exists() && out.length() > 0) return out
            val text = source.readText(Charsets.UTF_8)
            val isVtt = text.trimStart().startsWith("WEBVTT", ignoreCase = true)
            val shifted =
                if (isVtt) {
                    VTT_TS.replace(text) { m -> formatVtt(shiftMs(parseVtt(m), offsetMs)) }
                } else {
                    SRT_TS.replace(text) { m -> formatSrt(shiftMs(parseSrt(m), offsetMs)) }
                }
            out.writeText(shifted, Charsets.UTF_8)
            out
        }.getOrDefault(source)
    }

    private fun parseSrt(m: MatchResult): Long {
        val (h, min, s, ms) = m.destructured
        return h.toLong() * 3_600_000L + min.toLong() * 60_000L + s.toLong() * 1_000L + ms.toLong()
    }

    private fun parseVtt(m: MatchResult): Long {
        val h = m.groups[1]?.value?.toLongOrNull() ?: 0L
        return h * 3_600_000L + m.groupValues[2].toLong() * 60_000L +
            m.groupValues[3].toLong() * 1_000L + m.groupValues[4].toLong()
    }

    private fun shiftMs(
        tsMs: Long,
        offsetMs: Long,
    ): Long = (tsMs + offsetMs).coerceAtLeast(0L)

    private fun formatSrt(tsMs: Long): String =
        "%02d:%02d:%02d,%03d".format(
            tsMs / 3_600_000L,
            (tsMs % 3_600_000L) / 60_000L,
            (tsMs % 60_000L) / 1_000L,
            tsMs % 1_000L,
        )

    private fun formatVtt(tsMs: Long): String =
        "%02d:%02d:%02d.%03d".format(
            tsMs / 3_600_000L,
            (tsMs % 3_600_000L) / 60_000L,
            (tsMs % 60_000L) / 1_000L,
            tsMs % 1_000L,
        )

    /** Parses (startMs, text) cues out of a downloaded SRT/VTT file (Auto Sync). */
    fun parseCues(file: File): List<Pair<Long, String>> {
        val out = mutableListOf<Pair<Long, String>>()
        val timing = Regex("""(\d{1,2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->""")
        val lines = runCatching { file.readLines(Charsets.UTF_8) }.getOrDefault(emptyList())
        var i = 0
        while (i < lines.size && out.size < 4000) {
            val m = timing.find(lines[i])
            if (m == null) {
                i++
                continue
            }
            val (h, min, sec, ms) = m.destructured
            val start = ((h.toLong() * 60 + min.toLong()) * 60 + sec.toLong()) * 1000 + ms.toLong()
            val text = StringBuilder()
            i++
            while (i < lines.size && lines[i].isNotBlank() && !timing.containsMatchIn(lines[i])) {
                val t = lines[i].replace(Regex("<[^>]+>"), "").trim()
                if (t.isNotEmpty() && !t.all { ch -> ch.isDigit() }) {
                    if (text.isNotEmpty()) text.append(' ')
                    text.append(t)
                }
                i++
            }
            if (text.isNotEmpty()) out.add(start to text.toString())
        }
        return out
    }
}
