package com.github.damontecres.wholphin.plavio

import timber.log.Timber

/**
 * Minimal per-source request diagnostics, kept signature-compatible with the
 * phone app's version so the ported addon API layer records outcomes the
 * same way. The TV app has no diagnostics UI yet, so outcomes are only
 * logged (verbose) for now.
 */
object SourceDiagnostics {
    fun record(
        provider: String,
        outcome: String,
        durationMs: Long,
    ) {
        Timber.v("Addon source $provider: $outcome in $durationMs ms")
    }
}
