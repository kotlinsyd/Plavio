package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.AddonStore
import com.github.damontecres.wholphin.plavio.InstalledAddon
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.ui.components.SwitchWithLabel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlavioHomeCatalogsViewModel
    @Inject
    constructor(
        private val addonStore: AddonStore,
        private val uiPrefs: PlavioUiPrefs,
    ) : ViewModel() {
        /** Catalog addons in the user's Home order (natural order for unlisted ones). */
        val addons: StateFlow<List<InstalledAddon>> =
            combine(addonStore.addons, uiPrefs.homeAddonOrder) { addons, order ->
                val catalog = addons.filter { it.enabled && it.manifest.hasCatalog }
                catalog
                    .withIndex()
                    .sortedWith(
                        compareBy<IndexedValue<InstalledAddon>> { indexed ->
                            val pos = order.indexOf(indexed.value.id)
                            if (pos >= 0) pos else Int.MAX_VALUE
                        }.thenBy { it.index },
                    ).map { it.value }
            }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

        val hiddenAddons: StateFlow<Set<String>> = uiPrefs.homeHiddenAddons

        fun move(
            addon: InstalledAddon,
            delta: Int,
        ) {
            val list = addons.value.map { it.id }.toMutableList()
            val idx = list.indexOf(addon.id)
            val target = idx + delta
            if (idx < 0 || target < 0 || target >= list.size) return
            list.removeAt(idx)
            list.add(target, addon.id)
            viewModelScope.launch { uiPrefs.setHomeAddonOrder(list) }
        }

        fun setHidden(
            addon: InstalledAddon,
            hidden: Boolean,
        ) {
            val updated = uiPrefs.homeHiddenAddons.value.toMutableSet()
            if (hidden) updated.add(addon.id) else updated.remove(addon.id)
            viewModelScope.launch { uiPrefs.setHomeHiddenAddons(updated) }
        }
    }

/**
 * Home catalogs (phone parity): choose which addons show their catalog
 * rows on Home and arrange their order — up/down buttons + a show
 * switch per addon, all D-pad friendly.
 */
@Composable
fun PlavioHomeCatalogsScreen(
    modifier: Modifier = Modifier,
    viewModel: PlavioHomeCatalogsViewModel = hiltViewModel(),
) {
    val addons by viewModel.addons.collectAsState()
    val hidden by viewModel.hiddenAddons.collectAsState()

    // Entry focus (v0.3.11): like Integrations, this screen opened
    // with nothing focused — the first addon's Show switch is home.
    val entryFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(addons.isNotEmpty()) {
        if (addons.isNotEmpty()) {
            // v0.3.15: additive landing (see PlavioFocus.landFocus).
            landFocus(entryFocus)
        }
    }

    LazyColumn(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(end = 40.dp, top = 32.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.plavio_home_catalogs_title),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = stringResource(R.string.plavio_home_catalogs_sub),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (addons.isEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.plavio_home_catalogs_empty),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        itemsIndexed(addons, key = { index, addon -> "${addon.id}|${addon.baseUrl}|$index" }) { index, addon ->
            // Overhaul (v0.3.11): each addon group is a framed card.
            PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = addon.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text =
                                if (addon.id in hidden) {
                                    stringResource(R.string.plavio_home_catalogs_hidden)
                                } else {
                                    stringResource(R.string.plavio_home_catalogs_shown)
                                },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    ArrangeButton(
                        label = "↑",
                        enabled = index > 0,
                        onClick = { viewModel.move(addon, -1) },
                    )
                    ArrangeButton(
                        label = "↓",
                        enabled = index < addons.size - 1,
                        onClick = { viewModel.move(addon, 1) },
                    )
                }
                PlavioSwitchRow(
                    label = stringResource(R.string.plavio_home_catalogs_show),
                    checked = addon.id !in hidden,
                    onStateChange = { show -> viewModel.setHidden(addon, hidden = !show) },
                    modifier =
                        if (index == 0) {
                            Modifier.focusRequester(entryFocus)
                        } else {
                            Modifier
                        },
                )
            }
        }
    }
}

@Composable
private fun ArrangeButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(10.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = PlavioOnyx.GlassFill,
                contentColor = MaterialTheme.colorScheme.onSurface,
                // v0.3.13: focus = pink ring only, no white fill.
                focusedContainerColor = PlavioOnyx.GlassFill,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = PlavioOnyx.GlassFill,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
                disabledContainerColor = PlavioOnyx.GlassFill,
                disabledContentColor = PlavioOnyx.TextSecondary,
            ),
        border = plavioRowFocusBorder(RoundedCornerShape(10.dp)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
}
