package com.github.damontecres.wholphin.plavio

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.github.damontecres.wholphin.services.DownloadCallback
import com.github.damontecres.wholphin.services.copyTo
import com.github.damontecres.wholphin.services.hilt.StandardOkHttpClient
import com.github.damontecres.wholphin.util.Version
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/** A newer Plavio TV build published on the TV update feed. */
data class TvUpdate(
    val versionName: String,
    val versionCode: Int,
    val apkUrl: String,
    val notes: String?,
    val major: Boolean,
)

/** Outcome of an update install attempt — always reported, never silent. */
sealed interface UpdateInstallResult {
    /** The system installer was launched for the downloaded APK. */
    data object Launched : UpdateInstallResult

    /**
     * The APK is downloaded and verified, but Android needs the user to
     * allow installs from this app first. The unknown-sources settings
     * page was opened; the downloaded file is kept, so a retry goes
     * straight to the installer.
     */
    data object NeedsInstallPermission : UpdateInstallResult

    /** The attempt failed; [message] says why, for the logs and UI. */
    data class Failed(
        val message: String?,
    ) : UpdateInstallResult
}

/**
 * Plavio TV's auto-updater, mirroring the phone app's mechanism: a small
 * JSON feed (tv-stable.json on the Plavio repo) names the latest version
 * and its APK. A missing/unreachable feed simply means "no update" and
 * stays silent.
 *
 * Downloads/installs are Plavio's own (v0.3.0): the old route reused
 * Wholphin's MediaStore/public-Downloads plumbing, which failed on the
 * owner's Android 9 TV (the public Downloads write needs a storage
 * permission the app doesn't hold, and MediaStore inserts are flaky on
 * TV firmware). The APK now downloads into the app's private cache —
 * no permission involved — is verified against the feed (must parse as
 * this package, at the feed's version code), and is handed to the
 * system installer through the app's FileProvider.
 *
 * v0.3.6: the install-permission gate is no longer a wall. The old flow
 * hard-gated on canRequestPackageInstalls() and detoured to the
 * unknown-sources Settings page on EVERY attempt — on the owner's TV
 * that page cannot grant the permission for this app, so the update
 * downloaded, every Update tap reopened Settings, and the installer
 * was never reached. Now the detour happens once per version; after
 * it (or when no Settings page exists at all) the installer intent is
 * fired anyway and the system installer presents its own allow/block
 * step in-line. Intents are only fired after a resolve check, so a
 * "Launched" result always means a real handler took the file.
 */
@Singleton
class PlavioUpdater
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        @param:StandardOkHttpClient private val okHttpClient: OkHttpClient,
    ) {
        fun installedVersionName(): String =
            runCatching {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
            }.getOrDefault("0.0.0")

        fun installedVersionCode(): Long =
            runCatching {
                val info = context.packageManager.getPackageInfo(context.packageName, 0)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    info.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    info.versionCode.toLong()
                }
            }.getOrDefault(0L)

        /** True when Android currently allows this app to install packages. */
        fun canInstallPackages(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
                context.packageManager.canRequestPackageInstalls()

        /** The newest published update, or null when up to date / no feed. */
        suspend fun checkForUpdate(): TvUpdate? =
            withContext(Dispatchers.IO) {
                runCatching {
                    val request = Request.Builder().url(FEED_URL).get().build()
                    okHttpClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            Timber.v("Update feed answered ${response.code} — treating as no update")
                            return@use null
                        }
                        val root =
                            Json
                                .parseToJsonElement(response.body.string())
                                .jsonObject
                        val versionName =
                            root["version"]?.jsonPrimitive?.contentOrNull
                                ?: return@use null
                        val apkUrl =
                            root["apkUrl"]?.jsonPrimitive?.contentOrNull
                                ?: return@use null
                        // Per-ABI downloads (v0.2.2+ feeds): when the
                        // feed carries an "abis" map, download the build
                        // for the first ABI this device supports; feeds
                        // without the map keep using apkUrl untouched.
                        val abis =
                            runCatching { root["abis"]?.jsonObject }.getOrNull()
                        val downloadUrl =
                            if (abis == null) {
                                apkUrl
                            } else {
                                Build.SUPPORTED_ABIS
                                    .firstNotNullOfOrNull { abi ->
                                        abis[abi]?.jsonPrimitive?.contentOrNull
                                            ?.takeIf { it.isNotBlank() }
                                    } ?: apkUrl
                            }
                        val feedCode =
                            root["code"]?.jsonPrimitive?.intOrNull
                        val installedCode = installedVersionCode()
                        val isNewer =
                            if (feedCode != null) {
                                feedCode.toLong() > installedCode
                            } else {
                                val feed = Version.tryFromString(versionName)
                                val installed = Version.tryFromString(installedVersionName())
                                feed != null && installed != null && feed.isGreaterThan(installed)
                            }
                        if (!isNewer) return@use null
                        TvUpdate(
                            versionName = versionName,
                            versionCode = feedCode ?: 0,
                            apkUrl = downloadUrl,
                            notes = root["notes"]?.jsonPrimitive?.contentOrNull,
                            major = root["major"]?.jsonPrimitive?.booleanOrNull ?: false,
                        )
                    }
                }.onFailure { Timber.v(it, "Update check failed — treating as no update") }
                    .getOrNull()
            }

        /**
         * Downloads the update APK into the app's private cache,
         * verifies it against the feed, and launches the system
         * installer. The outcome is ALWAYS returned to the caller —
         * the v0.3.x version swallowed every failure into a log line,
         * which (with the 12-hour launch-check throttle) is why
         * v0.3.1 silently never arrived on the owner's TV.
         *
         * The verified download is kept under the feed version's name:
         * if the install stops at the unknown-sources permission, the
         * retry reuses the file instead of downloading it again.
         */
        suspend fun install(
            update: TvUpdate,
            callback: DownloadCallback,
        ): UpdateInstallResult =
            withContext(Dispatchers.IO) {
                runCatching {
                    val dir =
                        java.io.File(context.cacheDir, "plavio-updates").apply { mkdirs() }
                    val target = java.io.File(dir, "PlavioTV-update-${update.versionName}.apk")
                    // Drop downloads for any other version; keep this
                    // version's file when it still verifies (the
                    // permission-retry fast path).
                    dir.listFiles()?.forEach { old ->
                        if (old.name != target.name) {
                            runCatching { old.delete() }
                        }
                    }
                    if (!verifies(target, update)) {
                        runCatching { target.delete() }
                        val request = Request.Builder().url(update.apkUrl).get().build()
                        okHttpClient.newCall(request).execute().use { response ->
                            check(response.isSuccessful) { "Update download HTTP ${response.code}" }
                            val body = response.body
                            callback.contentLength(body.contentLength())
                            body.byteStream().use { input ->
                                target.outputStream().use { output ->
                                    copyTo(input, output, callback = callback)
                                }
                            }
                        }
                        check(verifies(target, update)) {
                            "Downloaded file failed verification"
                        }
                    }
                    // Hand the verified file to the system installer.
                    // Without the install permission, the user is sent
                    // to the unknown-sources page ONCE per version
                    // (v0.3.6): if they come back still ungranted — the
                    // page on some TV firmwares cannot grant it at
                    // all — or no Settings page exists, the installer
                    // intent is fired anyway and the installer itself
                    // presents the allow/block step in-line. The flow
                    // can no longer loop on a Settings page forever
                    // while the installer is never reached.
                    val uri =
                        FileProvider.getUriForFile(
                            context,
                            context.packageName + ".provider",
                            target,
                        )
                    if (!canInstallPackages() &&
                        !settingsDetourTried(update.versionName)
                    ) {
                        if (openUnknownAppSourcesSettings()) {
                            markSettingsDetourTried(update.versionName)
                            Timber.i(
                                "Install permission not granted — opened unknown-sources settings",
                            )
                            return@withContext UpdateInstallResult.NeedsInstallPermission
                        }
                        Timber.w(
                            "No unknown-sources settings page resolved — trying the installer directly",
                        )
                    }
                    launchInstaller(uri)
                }.getOrElse {
                    Timber.w(it, "Update install failed")
                    UpdateInstallResult.Failed(it.message)
                }
            }

        /**
         * Fires the system installer for [uri]. [UpdateInstallResult.Launched]
         * is returned ONLY when a handler for the intent exists and the
         * start did not throw — v0.3.5 and earlier reported success for
         * intents that went nowhere. ACTION_VIEW is tried first, then
         * the legacy ACTION_INSTALL_PACKAGE some TV firmwares still
         * route to their installer.
         */
        @Suppress("DEPRECATION")
        private fun launchInstaller(uri: Uri): UpdateInstallResult {
            val pm = context.packageManager
            val viewIntent =
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, APK_MIME_TYPE)
                    addCategory(Intent.CATEGORY_DEFAULT)
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_ACTIVITY_NEW_TASK,
                    )
                }
            val legacyIntent =
                Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
                    setDataAndType(uri, APK_MIME_TYPE)
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_ACTIVITY_NEW_TASK,
                    )
                }
            for (intent in listOf(viewIntent, legacyIntent)) {
                if (!resolves(pm, intent)) continue
                val started =
                    runCatching { context.startActivity(intent) }
                        .onFailure { Timber.w(it, "Installer intent failed to start") }
                        .isSuccess
                if (started) return UpdateInstallResult.Launched
            }
            return UpdateInstallResult.Failed(
                "No installer on this device would open the update file",
            )
        }

        /**
         * Opens a settings page where the user can allow installs from
         * this app. TV firmwares expose this in different places (and
         * some not at all), so candidates are tried in order and the
         * first that actually resolves is fired. False when no settings
         * page on this device will open.
         */
        private fun openUnknownAppSourcesSettings(): Boolean {
            val pm = context.packageManager
            val pkgUri = Uri.parse("package:" + context.packageName)
            val candidates =
                listOf(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkgUri),
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES),
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri),
                    Intent(Settings.ACTION_SETTINGS),
                )
            for (intent in candidates) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (!resolves(pm, intent)) continue
                val started =
                    runCatching { context.startActivity(intent) }
                        .onFailure { Timber.w(it, "Settings intent failed to start") }
                        .isSuccess
                if (started) return true
            }
            return false
        }

        /** True when some activity on this device can take [intent]. */
        private fun resolves(
            pm: PackageManager,
            intent: Intent,
        ): Boolean =
            runCatching {
                pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null ||
                    pm.queryIntentActivities(intent, 0).isNotEmpty()
            }.getOrDefault(false)

        private fun settingsDetourTried(versionName: String): Boolean =
            context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(detourKey(versionName), false)

        private fun markSettingsDetourTried(versionName: String) {
            context
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(detourKey(versionName), true)
                .apply()
        }

        private fun detourKey(versionName: String) = "settings_detour_$versionName"

        /**
         * True when [file] parses as this app's package at the feed's
         * version code (guards truncated/wrong downloads).
         */
        private fun verifies(
            file: java.io.File,
            update: TvUpdate,
        ): Boolean {
            if (!file.isFile || file.length() == 0L) return false
            val info =
                runCatching {
                    context.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
                }.getOrNull() ?: return false
            if (info.packageName != context.packageName) return false
            if (update.versionCode <= 0) return true
            val code =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    info.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    info.versionCode.toLong()
                }
            return code == update.versionCode.toLong()
        }

        companion object {
            const val FEED_URL =
                "https://gitlab.com/KotlinJS5/plavio/-/raw/main/tv-stable.json"

            private const val APK_MIME_TYPE = "application/vnd.android.package-archive"

            private const val PREFS_NAME = "plavio_updater"
        }
    }
