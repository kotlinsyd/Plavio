package com.github.damontecres.wholphin.plavio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.PlavioUpdater
import com.github.damontecres.wholphin.plavio.TvChannelRef
import com.github.damontecres.wholphin.plavio.TvUpdate
import com.github.damontecres.wholphin.plavio.UpdateInstallResult
import com.github.damontecres.wholphin.services.DownloadCallback
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Owns the launch-time update check for the Plavio flow: runs on every
 * cold start (the feed is a few hundred bytes), gated on the user's
 * auto-check setting, and silent only when the feed is missing or
 * unreachable.
 *
 * v0.3.2 fix: the old 12-hour throttle stamped the check time BEFORE
 * fetching, so a day of normal use consumed the one allowed check long
 * before a same-day release was published — v0.3.1 (shipped 16:35) was
 * never even looked for that evening. Install outcomes are surfaced in
 * the dialog now instead of being swallowed.
 */
@HiltViewModel
class PlavioRootViewModel
    @Inject
    constructor(
        private val uiPrefs: PlavioUiPrefs,
        private val updater: PlavioUpdater,
        private val repository: AddonCatalogRepository,
    ) : ViewModel() {
        /** In-player channel zapping: resolve the target channel and hand back its request. */
        fun zapToChannel(
            channel: TvChannelRef,
            siblings: List<TvChannelRef>,
            onResolved: (PlaybackRequest) -> Unit,
        ) {
            viewModelScope.launch {
                val resolved =
                    runCatching { repository.loadChannelRequest(channel, siblings) }
                        .onFailure { Timber.v(it, "Channel zap resolve failed") }
                        .getOrNull()
                if (resolved != null) onResolved(resolved)
            }
        }
        private val _pendingUpdate = MutableStateFlow<TvUpdate?>(null)
        val pendingUpdate: StateFlow<TvUpdate?> = _pendingUpdate

        /** TV look (owner design 2026-11-04): null = never chosen, renders as Full. */
        val lookMode: StateFlow<String?> = uiPrefs.lookMode

        private val _installing = MutableStateFlow(false)
        val installing: StateFlow<Boolean> = _installing

        /**
         * Why the last install attempt did not finish, shown inside the
         * update dialog: a download/verification problem (Failed) or
         * the unknown-sources detour (PermissionNeeded). Null = nothing
         * to report.
         */
        private val _updateProblem = MutableStateFlow<UpdateProblem?>(null)
        val updateProblem: StateFlow<UpdateProblem?> = _updateProblem

        private var checkedThisLaunch = false

        fun maybeCheckOnLaunch() {
            if (checkedThisLaunch) return
            checkedThisLaunch = true
            viewModelScope.launch {
                if (!uiPrefs.autoUpdateCheck.value) return@launch
                // Every cold start checks (v0.3.2): the 12-hour
                // throttle that hid v0.3.1 is gone. The timestamp is
                // bookkeeping only, stamped after a successful fetch.
                runCatching { updater.checkForUpdate() }
                    .onSuccess {
                        uiPrefs.setLastUpdateCheckMs(System.currentTimeMillis())
                        if (it != null) _pendingUpdate.value = it
                    }.onFailure { Timber.v(it, "Launch update check failed") }
            }
        }

        fun dismissUpdate() {
            _pendingUpdate.value = null
            _updateProblem.value = null
        }

        /**
         * The app came back to the foreground while the update dialog
         * waits on the unknown-sources detour: if the permission is
         * granted now, continue straight into the installer — the
         * verified download is still on disk, so the detour costs the
         * user no second tap (v0.3.6).
         */
        fun onResumed() {
            if (_pendingUpdate.value == null) return
            if (_updateProblem.value != UpdateProblem.PermissionNeeded) return
            if (updater.canInstallPackages()) installPendingUpdate()
        }

        fun installPendingUpdate() {
            val update = _pendingUpdate.value ?: return
            if (_installing.value) return
            _installing.value = true
            _updateProblem.value = null
            viewModelScope.launch {
                val result =
                    runCatching {
                        updater.install(
                            update,
                            object : DownloadCallback {
                                override fun contentLength(contentLength: Long) {}

                                override fun bytesDownloaded(bytes: Long) {}
                            },
                        )
                    }.getOrElse {
                        Timber.w(it, "Update install failed")
                        UpdateInstallResult.Failed(it.message)
                    }
                _installing.value = false
                when (result) {
                    UpdateInstallResult.Launched -> {
                        _pendingUpdate.value = null
                        _updateProblem.value = null
                    }
                    // Keep the dialog (and the downloaded file): after
                    // allowing installs in Settings, Update retries
                    // straight into the installer.
                    UpdateInstallResult.NeedsInstallPermission ->
                        _updateProblem.value = UpdateProblem.PermissionNeeded
                    is UpdateInstallResult.Failed ->
                        _updateProblem.value = UpdateProblem.Failed
                }
            }
        }

        enum class UpdateProblem { Failed, PermissionNeeded }
    }
