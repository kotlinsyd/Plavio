package com.github.damontecres.wholphin.plavio.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import androidx.tv.material3.Text
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.StreamBundle
import com.github.damontecres.wholphin.plavio.StreamItem
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import com.github.damontecres.wholphin.plavio.streamQualityRank
import kotlinx.coroutines.launch

/**
 * Stream picker for one playable item: every direct stream from every
 * enabled addon, labelled with its provider and quality, like the phone
 * app. Picking one hands a [PlaybackRequest] to the player, plus the
 * item's saved resume position (the player's existing resume path).
 *
 * v0.3.17 (video-lessons round, from the owner's Nuvio TV recording):
 * the picker is no longer a full-screen switch. It opens as a panel
 * over the title's own backdrop — the title / episode context stays
 * pinned on the left, the panel slides in from the right — and it
 * opens INSTANTLY: skeleton rows hold the list area while the addons
 * answer, and real rows replace them as each addon lands (the owner's
 * progressive-loading rule; nothing waits for the slowest source).
 */
@Composable
fun PlavioStreamsScreen(
    ref: StreamsRef,
    onPlay: (PlaybackRequest, Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioStreamsViewModel =
        hiltViewModel(key = "streams|${ref.type}|${ref.videoId}"),
) {
    LaunchedEffect(ref) {
        viewModel.load(ref.type, ref.videoId, ref.metaId)
    }
    val state by viewModel.state.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val badgeConfig by viewModel.badgeConfig.collectAsState()
    val resumePositionMs by viewModel.resumePositionMs.collectAsState()

    val reducedMotion =
        com.github.damontecres.wholphin.plavio.rememberReducedMotion()
    var panelShown by remember { mutableStateOf(reducedMotion) }
    LaunchedEffect(Unit) { panelShown = true }

    val filling =
        state is PlavioStreamsUiState.Loading ||
            (state as? PlavioStreamsUiState.Loaded)?.filling == true

    // Entry focus (v0.3.11): this screen owned no focus requester at
    // all — it opened with nothing focused, and the remote's first
    // presses landed wherever a root-level focus search happened to
    // put them. The first stream row's play area is now the
    // deliberate home: requested in a bounded loop once rows exist,
    // and again on the return from playback (the playing→stopped
    // flip) — the same discipline as Home/Live/Detail.
    val entryFocus = remember { FocusRequester() }
    var entryLanded by remember { mutableStateOf(false) }
    val loadedStreamCount =
        (state as? PlavioStreamsUiState.Loaded)?.bundle?.streams?.size ?: 0
    // v0.3.14: shared primitive + screen claim, same migration as
    // Live — the entry target's own landed flag still confirms, and
    // any focus inside the screen cancels.
    var streamsClaimed by remember { mutableStateOf(false) }
    val streamsScope = androidx.compose.runtime.rememberCoroutineScope()
    suspend fun landStreams() {
        entryLanded = false
        streamsClaimed = false
        landFocus(
            entryFocus,
            isClaimed = { entryLanded || streamsClaimed },
            attempts = 8,
            delayMs = 150,
        )
    }
    LaunchedEffect(loadedStreamCount) {
        if (loadedStreamCount > 0) landStreams()
    }
    val playerActive = LocalPlavioPlayerActive.current
    var playerWasActive by remember { mutableStateOf(false) }
    LaunchedEffect(playerActive) {
        if (playerActive) {
            playerWasActive = true
        } else if (playerWasActive) {
            playerWasActive = false
            landStreams()
        }
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = { streamsScope.launch { landStreams() } }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) streamsClaimed = true },
    ) {
        // The title's own backdrop under everything (poster is the
        // fallback). The scrims keep the left context legible while
        // the art stays visible; the panel covers the right side.
        val art = ref.backdrop ?: ref.poster
        if (art != null) {
            coil3.compose.AsyncImage(
                model =
                    ImageRequest
                        .Builder(androidx.compose.ui.platform.LocalContext.current)
                        .data(art)
                        .size(1280, 720)
                        .crossfade(false)
                        .build(),
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.38f)),
            )
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                colors =
                                    listOf(
                                        Color.Black.copy(alpha = 0.55f),
                                        Color.Transparent,
                                    ),
                                endX = 900f,
                            ),
                        ),
            )
        }
        // Left: the title / episode context, bottom-pinned like
        // the Detail header so the eye path stays the same. (Overlay
        // siblings in the root Box rather than a Row — a RowScope
        // receiver would shadow the panel's AnimatedVisibility.)
        Column(
            modifier =
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(0.36f)
                    .fillMaxHeight()
                    .padding(top = 28.dp, bottom = 28.dp, end = 16.dp),
            verticalArrangement = Arrangement.Bottom,
        ) {
                if (ref.seriesName != null && ref.season > 0) {
                    Text(
                        text = "S${ref.season} · E${ref.episode}",
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold,
                        color = LocalPlavioAccent.current.primary,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }
                Text(
                    text = ref.seriesName ?: ref.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = PlavioOnyx.TextPrimary,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                ref.episodeTitle?.takeIf { it.isNotBlank() }?.let { title ->
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                Text(
                    text = stringResource(R.string.plavio_streams_heading),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
        // Right: the streams panel, sliding in over the backdrop.
        Box(
            modifier =
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxWidth(0.64f)
                    .fillMaxHeight()
                    .padding(end = 40.dp, top = 28.dp, bottom = 28.dp),
        ) {
                AnimatedVisibility(
                    visible = panelShown,
                    enter =
                        if (reducedMotion) {
                            EnterTransition.None
                        } else {
                            slideInHorizontally(
                                animationSpec =
                                    tween(
                                        durationMillis = 260,
                                        easing = FastOutSlowInEasing,
                                    ),
                            ) { width -> width / 3 } +
                                fadeIn(
                                    animationSpec = tween(durationMillis = 260),
                                )
                        },
                    modifier = Modifier.fillMaxSize(),
                ) {
                    PlavioPanel(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(24.dp),
                    ) {
                        if (notice != null || filling) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                if (notice != null) {
                                    Text(
                                        text = notice ?: "",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = LocalPlavioAccent.current.primary,
                                        modifier = Modifier.weight(1f),
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                                if (filling) {
                                    OrbitLoader(modifier = Modifier.size(22.dp))
                                    Text(
                                        text = stringResource(R.string.plavio_streams_loading),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 10.dp),
                                    )
                                }
                            }
                        }

                        when (val st = state) {
                            PlavioStreamsUiState.Loading -> {
                                SkeletonStreamRows(
                                    count = 5,
                                    modifier = Modifier.weight(1f),
                                )
                            }

                            is PlavioStreamsUiState.Loaded -> {
                                if (st.bundle.streams.isEmpty()) {
                                    if (st.filling) {
                                        SkeletonStreamRows(
                                            count = 5,
                                            modifier = Modifier.weight(1f),
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier.weight(1f).fillMaxWidth(),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text(
                                                text = stringResource(R.string.plavio_streams_none),
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                } else {
                                    StreamList(
                                        ref = ref,
                                        bundle = st.bundle,
                                        episodes = st.episodes,
                                        badgeConfig = badgeConfig,
                                        resumePositionMs = resumePositionMs,
                                        filling = st.filling,
                                        onPlay = { request -> onPlay(request, resumePositionMs) },
                                        onDownload = { stream -> viewModel.download(ref, stream) },
                                        entryFocus = entryFocus,
                                        onEntryFocusChanged = { focused ->
                                            if (focused) entryLanded = true
                                        },
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                            }
                        }
                    }
                }
        }
    }
}

/**
 * Placeholder stream rows for the panel's loading states: the real
 * row's frame and rhythm (name bar, sub-line bar, badge capsules) in
 * the same static white-alpha language as the Detail loading layer —
 * static on purpose, no shimmer tax on a weak TV box. Never focusable;
 * real rows replace them as the addons answer.
 */
@Composable
private fun SkeletonStreamRows(
    count: Int,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        repeat(count) {
            Surface(
                shape = PlavioPanelShape,
                colors =
                    SurfaceDefaults.colors(
                        containerColor = PlavioOnyx.PanelFramed,
                        contentColor = PlavioOnyx.TextPrimary,
                    ),
                border =
                    Border(
                        border = BorderStroke(1.dp, PlavioOnyx.PanelBorder),
                        shape = PlavioPanelShape,
                    ),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(0.55f)
                                .height(18.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(Color.White.copy(alpha = 0.10f)),
                    )
                    Box(
                        modifier =
                            Modifier
                                .fillMaxWidth(0.35f)
                                .height(13.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color.White.copy(alpha = 0.07f)),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(56.dp, 44.dp, 64.dp).forEach { width ->
                            Box(
                                modifier =
                                    Modifier
                                        .size(width = width, height = 18.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.White.copy(alpha = 0.08f)),
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * The "Resume from mm:ss" chip above the stream list (v0.3.17):
 * informational only — picking any stream hands this position to the
 * player through the existing Play resume path, whose own prompt
 * offers Resume / Start over, so no new playback semantics live here.
 * Not focusable, like the badge capsules.
 */
@Composable
private fun ResumePositionChip(
    positionMs: Long,
    modifier: Modifier = Modifier,
) {
    val accent = LocalPlavioAccent.current
    Row(
        modifier =
            modifier
                .clip(PlavioCapsuleShape)
                .background(accent.primary.copy(alpha = 0.16f))
                .border(1.dp, accent.primary.copy(alpha = 0.55f), PlavioCapsuleShape)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        androidx.tv.material3.Icon(
            imageVector = Icons.Filled.PlayArrow,
            contentDescription = null,
            tint = accent.primary,
            modifier = Modifier.size(16.dp),
        )
        Text(
            text = stringResource(R.string.plavio_streams_resume_from, formatResumeTime(positionMs)),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = PlavioOnyx.TextPrimary,
            maxLines = 1,
        )
    }
}

/** "12:34" / "1:02:34" — the player's own time format. */
private fun formatResumeTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}

/** The streams filter capsules (v0.3.21, the sample + mobile v0.14.13). */
private enum class StreamFilter { Any, Recommended, Q4K, Q1080p, Q720p, SD }

@Composable
private fun StreamList(
    ref: StreamsRef,
    bundle: StreamBundle,
    episodes: List<com.github.damontecres.wholphin.plavio.Video>,
    badgeConfig: StreamCapsuleConfig,
    resumePositionMs: Long,
    filling: Boolean,
    onPlay: (PlaybackRequest) -> Unit,
    onDownload: (StreamItem) -> Unit,
    entryFocus: FocusRequester,
    onEntryFocusChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    // v0.3.21 (the approved streams sample): ONE merged list — every
    // stream from every addon, in the established order (debrid-
    // resolved rows first, then quality best-first; the sort is
    // stable, so filtering never reorders). The filter capsules
    // (Any, Recommended, 4K, 1080p, 720p, SD) only FILTER.
    var filter by remember { mutableStateOf(StreamFilter.Any) }
    val allStreams =
        remember(bundle) {
            bundle.streams.sortedWith(
                compareByDescending<StreamItem> { streamDebridService(it) != null }
                    .thenByDescending { streamQualityRank(it) },
            )
        }
    val streams =
        remember(allStreams, filter) {
            when (filter) {
                StreamFilter.Any -> allStreams
                StreamFilter.Recommended -> allStreams.filter { it.plavioPick }
                StreamFilter.Q4K -> allStreams.filter { streamQualityRank(it) >= 6 }
                StreamFilter.Q1080p -> allStreams.filter { streamQualityRank(it) in 4..5 }
                StreamFilter.Q720p -> allStreams.filter { streamQualityRank(it) == 3 }
                StreamFilter.SD -> allStreams.filter { streamQualityRank(it) in 0..2 }
            }
        }
    Column(modifier = modifier) {
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(
                StreamFilter.entries,
                key = { _, entry -> "stream-filter|$entry" },
            ) { _, entry ->
                PlavioFilterCapsule(
                    text =
                        when (entry) {
                            StreamFilter.Any -> stringResource(R.string.plavio_filter_any)
                            StreamFilter.Recommended -> stringResource(R.string.plavio_filter_recommended)
                            StreamFilter.Q4K -> "4K"
                            StreamFilter.Q1080p -> "1080p"
                            StreamFilter.Q720p -> "720p"
                            StreamFilter.SD -> "SD"
                        },
                    selected = filter == entry,
                    onClick = { filter = entry },
                )
            }
        }
        // Resume chip (v0.3.17): sits above the list whenever this
        // item has a saved position; picking any stream resumes there
        // through the player's existing prompt.
        if (resumePositionMs > 0) {
            ResumePositionChip(
                positionMs = resumePositionMs,
                modifier = Modifier.padding(bottom = 2.dp),
            )
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Sample B header: when this tab leads with cached rows,
            // say so up top — "⚡ Instant play / Cached on TorBox ·
            // plays right away".
            val cachedServices =
                streams.mapNotNull { streamDebridService(it) }.distinct()
            if (cachedServices.isNotEmpty()) {
                item(key = "instant-play") {
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "⚡ " + stringResource(R.string.plavio_streams_instant_play),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PlavioOnyx.TextPrimary,
                        )
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text =
                                stringResource(
                                    R.string.plavio_streams_cached_on,
                                    cachedServices.joinToString(" + "),
                                ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = PlavioOnyx.TextSecondary,
                        )
                    }
                }
            }
            if (streams.isEmpty() && !filling) {
                item(key = "filter-empty") {
                    Text(
                        text = stringResource(R.string.plavio_filter_none),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp),
                    )
                }
            }
            itemsIndexed(streams, key = { index, stream -> "$index|${stream.sourceId}|${stream.url}" }) { index, stream ->
                StreamRow(
                    stream = stream,
                    badgeConfig = badgeConfig,
                    onClick = { onPlay(buildPlaybackRequest(ref, bundle, stream, episodes)) },
                    onDownload = { onDownload(stream) },
                    entryFocus = if (index == 0) entryFocus else null,
                    onEntryFocusChanged = onEntryFocusChanged,
                )
            }
            // While the fill is still running, skeleton rows trail
            // the real ones — what's loaded is shown immediately and
            // the placeholders step aside as more addons land.
            if (filling) {
                items(count = 2, key = { index -> "streams-filling-$index" }) {
                    SkeletonStreamRows(count = 1)
                }
            }
        }
    }
}

/**
 * One stream row, in the phone app's final Sources layout: the cleaned
 * name line (title + year ONLY, from [streamFacts]), a provider
 * sub-line, and the badge row under it (fact capsules + the accent
 * size chip) with the download capsule riding LAST. When the title
 * yields no parseable facts the row falls back to the raw title/name
 * lines, exactly like the phone.
 * DASH links are still refused by the view model's download() with
 * an explanation.
 *
 * Focus (v0.3.15): the row used to be ONE clickable tv Card with the
 * download capsule nested inside it — and a focusable nested inside
 * the element that already holds focus is a stop the D-pad can never
 * reach (directional focus search never descends into the bounds of
 * the focused element), so OK always played and the capsule was
 * unreachable by remote. The row is now a NON-clickable frame with
 * the exact shape / fill / hairline the Card drew, holding TWO
 * sibling focus stops: the play area (see [StreamPlayArea]; clicking
 * plays, as before) and the download capsule with its own accent
 * ring. While the play area holds focus the frame draws the same
 * 2.5dp accent ring the focused Card used to draw, so a focused row
 * looks exactly as it did in v0.3.14.
 */
@Composable
private fun StreamRow(
    stream: StreamItem,
    badgeConfig: StreamCapsuleConfig,
    onClick: () -> Unit,
    onDownload: () -> Unit,
    entryFocus: FocusRequester? = null,
    onEntryFocusChanged: (Boolean) -> Unit = {},
) {
    val unresolvedTorrent =
        stream.url.startsWith("infohash:", true) || stream.url.startsWith("magnet:", true)
    // The Size group toggle governs the size fact (the accent size
    // chip in the badge row); it is parsed out entirely when the
    // group is off.
    val facts =
        remember(stream, badgeConfig.showSize) {
            streamFacts(stream, showSize = badgeConfig.showSize)
        }
    val rawLabel =
        remember(stream) {
            listOfNotNull(stream.name, stream.title)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString("\n")
        }
    // Sample B (v0.3.11): a debrid-resolved row carries the green
    // "<Service> Cached" tag, exactly like the phone.
    val debridService = streamDebridService(stream)
    // The frame's ring follows the play area's focus (see the doc
    // comment above): accent ring while play holds focus, the rest
    // hairline otherwise — including while the capsule holds focus,
    // when the capsule's own ring is the focus signal.
    var playFocused by remember { mutableStateOf(false) }
    val accent = LocalPlavioAccent.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = PlavioPanelShape,
        colors =
            SurfaceDefaults.colors(
                containerColor = PlavioOnyx.PanelFramed,
                contentColor = PlavioOnyx.TextPrimary,
            ),
        border =
            if (playFocused) {
                Border(
                    border = BorderStroke(2.5.dp, accent.primary),
                    shape = PlavioPanelShape,
                )
            } else {
                Border(
                    border = BorderStroke(1.dp, PlavioOnyx.PanelBorder),
                    shape = PlavioPanelShape,
                )
            },
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (facts.hasFacts) {
                StreamPlayArea(
                    onClick = onClick,
                    onFocusChanged = { playFocused = it; onEntryFocusChanged(it) },
                    focusRequester = entryFocus,
                ) {
                    Text(
                        text = facts.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    // Sub-line: the provider only (the parser's
                    // bracket tag · addon/sourceName combo). The size
                    // rode here until v0.3.16; since v0.3.17 it is the
                    // accent chip in the badge row, exactly once.
                    val subLine = facts.providerLine.orEmpty()
                    if (subLine.isNotBlank()) {
                        Text(
                            text = subLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (debridService != null) {
                        PlavioStatusChip(
                            text = stringResource(R.string.plavio_cached_tag, debridService),
                            positive = true,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
                if (stream.plavioPick) {
                    RecommendedChip(modifier = Modifier.padding(top = 4.dp))
                }
                BadgeStrip(
                    facts = facts,
                    config = badgeConfig,
                    modifier = Modifier.padding(top = 4.dp),
                    trailing = {
                        StreamDownloadCapsule(
                            style = badgeConfig.style,
                            enabled = !unresolvedTorrent,
                            onClick = onDownload,
                        )
                    },
                )
            } else {
                // Fallback: no parseable facts -> the raw title/name,
                // with the download capsule still riding under it.
                StreamPlayArea(
                    onClick = onClick,
                    onFocusChanged = { playFocused = it; onEntryFocusChanged(it) },
                    focusRequester = entryFocus,
                ) {
                    if (rawLabel.isNotBlank()) {
                        Text(
                            text = rawLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (debridService != null) {
                        PlavioStatusChip(
                            text = stringResource(R.string.plavio_cached_tag, debridService),
                            positive = true,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
                if (stream.plavioPick) {
                    RecommendedChip(modifier = Modifier.padding(top = 4.dp))
                }
                BadgeStrip(
                    facts = facts,
                    config = badgeConfig,
                    modifier = Modifier.padding(top = 4.dp),
                    trailing = {
                        StreamDownloadCapsule(
                            style = badgeConfig.style,
                            enabled = !unresolvedTorrent,
                            onClick = onDownload,
                        )
                    },
                )
            }
        }
    }
}

/**
 * The Smart Picks mark (v0.3.21, mobile pick B): a green OUTLINE
 * capsule reading "★ RECOMMENDED" on plavioPick rows — the same
 * green family as the cached tag, outline not fill.
 */
@Composable
private fun RecommendedChip(modifier: Modifier = Modifier) {
    Box(
        modifier =
            modifier
                .clip(PlavioCapsuleShape)
                .background(PlavioOnyx.CachedGreenFill)
                .border(1.dp, PlavioOnyx.CachedGreen, PlavioCapsuleShape)
                .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(
            text = stringResource(R.string.plavio_recommended_chip),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = PlavioOnyx.CachedGreen,
        )
    }
}

/**
 * The play stop of a stream row: a transparent tv Surface over the
 * row's text block. It draws nothing at rest and nothing on focus —
 * the row frame's accent ring (see [StreamRow]) is its focus
 * signal — it only has to be the D-pad stop that plays on OK: a
 * SIBLING of the download capsule under it, never its ancestor, so
 * directional focus search can move between the two. Its content
 * column keeps the text block's original 4dp rhythm.
 */
@Composable
private fun StreamPlayArea(
    onClick: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    focusRequester: FocusRequester? = null,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier =
            Modifier
                .fillMaxWidth()
                .then(
                    if (focusRequester != null) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                )
                .onFocusChanged { state -> onFocusChanged(state.isFocused) },
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(8.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1f, pressedScale = 1f),
        colors =
            ClickableSurfaceDefaults.colors(
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = Color.Transparent,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
                pressedContainerColor = Color.Transparent,
                pressedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
        border =
            ClickableSurfaceDefaults.border(
                border = Border.None,
                focusedBorder = Border.None,
                pressedBorder = Border.None,
            ),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            content()
        }
    }
}

/**
 * The debrid service behind a resolved stream row, or null. The
 * repository rewrites resolved torrent rows into direct links and
 * names their source "⚡ TorBox · …" / "⚡ RD · …" (the same markers
 * the addon tabs strip for their labels) — that prefix is the
 * identification, no new plumbing.
 */
private fun streamDebridService(stream: StreamItem): String? {
    val name = stream.sourceName ?: return null
    return when {
        name.startsWith("⚡ TorBox · ") -> "TorBox"
        name.startsWith("⚡ RD · ") -> "Real-Debrid"
        else -> null
    }
}
