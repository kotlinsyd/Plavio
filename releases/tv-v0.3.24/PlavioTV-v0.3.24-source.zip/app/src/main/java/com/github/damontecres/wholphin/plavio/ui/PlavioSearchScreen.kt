package com.github.damontecres.wholphin.plavio.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed as lazyRowItemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.github.damontecres.wholphin.R
import com.github.damontecres.wholphin.plavio.CachedMeta
import com.github.damontecres.wholphin.plavio.MetaPreview
import com.github.damontecres.wholphin.ui.components.Button
import com.github.damontecres.wholphin.ui.components.EditTextBox
import kotlinx.coroutines.launch

/**
 * Search: the field capsule at the top-left + the results poster
 * grid on the right, updating AS YOU TYPE (debounced — every key
 * re-searches). Picking a result opens the same detail page the
 * home rows lead to.
 *
 * v0.3.16 (note 10, owner's order): the custom in-app keyboard is
 * REMOVED — Search uses the TV's default system keyboard, as
 * usual. Entering the screen lands focus on the field and raises
 * the system IME; the IME's Search action runs the search and the
 * focus then moves to the first result (the pending-move machine
 * below). This supersedes the v0.3.10 "never pop the IME"
 * discipline and the v0.3.11 bottom-anchored custom grid.
 */
@Composable
fun PlavioSearchScreen(
    onItemClick: (CachedMeta) -> Unit,
    onPersonClick: (com.github.damontecres.wholphin.plavio.CastMember) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PlavioSearchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    // v0.3.16 (note 10): the field IS the entry point — focus lands
    // on it and the system keyboard rises, the usual TV behaviour.
    val fieldFocusRequester = remember { FocusRequester() }
    val entryKeyboardController = LocalSoftwareKeyboardController.current
    // Entry landing (v0.3.14): the shared primitive with a claim fed
    // by the screen root's focus state. Bounded, confirmed,
    // cancellable.
    var searchClaimed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        landFocus(
            requester = fieldFocusRequester,
            isClaimed = { searchClaimed },
            attempts = 8,
            delayMs = 140,
        )
        entryKeyboardController?.show()
    }
    // The capsule's return transfer lands here too (v0.3.14).
    val contentEntry = LocalPlavioContentEntry.current
    val entryScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.DisposableEffect(contentEntry) {
        val handler: () -> Unit = {
            entryScope.launch {
                searchClaimed = false
                landFocus(fieldFocusRequester, isClaimed = { searchClaimed }, attempts = 6, delayMs = 130)
            }
        }
        contentEntry.handler = handler
        onDispose {
            if (contentEntry.handler === handler) contentEntry.handler = null
        }
    }
    // Done → results is a state machine, not a hope (v0.3.14, the
    // reference behaviour): pressing Done records a PENDING move.
    // The move fires only once the search for it has been seen
    // running (Searching) and has finished into Results — if results
    // were already on screen, focus does NOT jump into the stale
    // grid; it waits for the new ones. Any focus the user takes in
    // the results grid himself cancels the pending move.
    var pendingResultsMove by remember { mutableStateOf(false) }
    var moveSawSearching by remember { mutableStateOf(false) }
    var resultsClaimed by remember { mutableStateOf(false) }
    val firstResultFocus = remember { FocusRequester() }
    LaunchedEffect(state, pendingResultsMove) {
        if (!pendingResultsMove) return@LaunchedEffect
        when (state) {
            PlavioSearchUiState.Searching -> moveSawSearching = true
            is PlavioSearchUiState.Results -> {
                if (moveSawSearching) {
                    kotlinx.coroutines.delay(90)
                    landFocus(
                        requester = firstResultFocus,
                        isClaimed = { resultsClaimed || !pendingResultsMove },
                        attempts = 8,
                        delayMs = 120,
                    )
                    pendingResultsMove = false
                    moveSawSearching = false
                }
            }
            is PlavioSearchUiState.NoResults -> {
                pendingResultsMove = false
                moveSawSearching = false
            }
            else -> {}
        }
    }
    // Live search: any query change re-searches after a short settle.
    LaunchedEffect(query) {
        if (query.isBlank()) return@LaunchedEffect
        kotlinx.coroutines.delay(350)
        viewModel.search(query)
    }

    // Voice search: shown only when a speech recognizer is installed
    // on the TV. The system recognizer owns the mic permission and
    // the listening UI; the recognized text lands in the query.
    val context = LocalContext.current
    val voiceAvailable =
        remember {
            context.packageManager
                .queryIntentActivities(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH),
                    0,
                ).isNotEmpty()
        }
    val voicePrompt = stringResource(R.string.plavio_search_voice_prompt)
    val voiceLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val spoken =
                    result.data
                        ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                        ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    query = spoken
                }
            }
        }

    // Layout: the field column on the left, the RESULTS taking
    // whatever height is left (the lazy grid absorbs any height
    // shortage). On short screens the heading line steps aside.
    // (v0.3.16, note 10: the custom keyboard that used to anchor
    // the bottom-left is gone — the system IME overlays instead,
    // as on any other TV app.)
    BoxWithConstraints(
        modifier =
            modifier
                .background(MaterialTheme.colorScheme.background)
                .onFocusChanged { if (it.hasFocus) searchClaimed = true }
                .padding(end = 40.dp, top = 72.dp, bottom = 24.dp),
    ) {
        val compactHeight = maxHeight < 430.dp
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            // Left: the field capsule column.
            Column(
                modifier = Modifier.width(468.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (!compactHeight) {
                    Text(
                        text = stringResource(R.string.plavio_search_heading),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            PlavioPanel(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    EditTextBox(
                        value = query,
                        onValueChange = { query = it },
                        modifier =
                            Modifier
                                .weight(1f)
                                .focusRequester(fieldFocusRequester),
                        keyboardOptions =
                            KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Search,
                            ),
                        keyboardActions =
                            KeyboardActions(
                                onSearch = {
                                    // The system keyboard's Search
                                    // action takes over the old
                                    // custom keyboard's Done job: arm
                                    // the pending results move, then
                                    // search — focus lands on the
                                    // first result when THIS search
                                    // lands (the machine above).
                                    resultsClaimed = false
                                    moveSawSearching = false
                                    pendingResultsMove = true
                                    viewModel.search(query)
                                },
                            ),
                        placeholder = {
                            androidx.compose.material3.Text(
                                text = stringResource(R.string.plavio_search_hint),
                            )
                        },
                    )
                    if (voiceAvailable) {
                        PlavioFixedButton(
                            text = "",
                            onClick = {
                                voiceLauncher.launch(
                                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(
                                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                                        )
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, voicePrompt)
                                    },
                                )
                            },
                            leadingIcon = PlavioIcons.Mic,
                            modifier = Modifier.width(56.dp),
                        )
                    }
                }
            }
        }

        // Right: results.
        Box(modifier = Modifier.weight(1f)) {
            when (val st = state) {
                PlavioSearchUiState.Idle -> {
                    SearchMessage(text = stringResource(R.string.plavio_search_idle))
                }

                PlavioSearchUiState.Searching -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            OrbitLoader(modifier = Modifier.size(56.dp))
                            Text(
                                text = stringResource(R.string.plavio_search_searching),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                is PlavioSearchUiState.Results -> {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 124.dp),
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .onFocusChanged { if (it.hasFocus) resultsClaimed = true },
                        contentPadding = PaddingValues(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        if (st.people.isNotEmpty()) {
                            item(
                                key = "people",
                                span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) },
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = stringResource(R.string.plavio_search_people),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground,
                                    )
                                    androidx.compose.foundation.lazy.LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        lazyRowItemsIndexed(
                                            st.people,
                                            key = { index, member -> "${member.id}|${member.name}|$index" },
                                        ) { personIndex, member ->
                                            PersonCard(
                                                member = member,
                                                onClick = { onPersonClick(member) },
                                                focusRequester =
                                                    if (personIndex == 0) {
                                                        firstResultFocus
                                                    } else {
                                                        null
                                                    },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        items(st.items, key = { "${it.addonId}|${it.meta.type}|${it.meta.id}" }) { item ->
                            SharedPosterCard(
                                item = item.meta,
                                onClick = { onItemClick(item) },
                                modifier = Modifier.fillMaxWidth(),
                                // The pending Done-move lands on the
                                // first poster — unless a people row
                                // sits above it and owns the landing.
                                focusRequester =
                                    if (st.people.isEmpty() &&
                                        item == st.items.firstOrNull()
                                    ) {
                                        firstResultFocus
                                    } else {
                                        null
                                    },
                            )
                        }
                    }
                }

                is PlavioSearchUiState.NoResults -> {
                    SearchMessage(text = stringResource(R.string.plavio_search_no_results, st.query))
                }

                PlavioSearchUiState.NoSearchAddons -> {
                    SearchMessage(text = stringResource(R.string.plavio_search_no_addons))
                }
            }
        }
        }
    }
}

@Composable
private fun SearchMessage(text: String) {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SearchPosterCard(
    item: MetaPreview,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    androidx.tv.material3.Card(
        onClick = onClick,
        modifier = modifier.width(124.dp),
        colors =
            androidx.tv.material3.CardDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
            ),
        scale = plavioCardScale(),
    ) {
        Column {
            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (item.poster != null) {
                    AsyncImage(
                        model =
                            ImageRequest
                                .Builder(LocalContext.current)
                                .data(item.poster)
                                .size(248, 372)
                                .crossfade(false)
                                .build(),
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = item.name.take(1),
                        style = MaterialTheme.typography.displaySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}
