package com.github.damontecres.wholphin.plavio.ui

import android.content.Context
import androidx.annotation.OptIn
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.text.CuesWithTiming
import androidx.media3.ui.SubtitleView
import com.github.damontecres.wholphin.plavio.AddonCatalogRepository
import com.github.damontecres.wholphin.plavio.CrashReports
import com.github.damontecres.wholphin.plavio.IntroDbApi
import com.github.damontecres.wholphin.plavio.LocalSubtitle
import com.github.damontecres.wholphin.plavio.PlaybackRequest
import com.github.damontecres.wholphin.plavio.SkipSegment
import com.github.damontecres.wholphin.plavio.StreamItem
import com.github.damontecres.wholphin.plavio.streamQualityLabel
import com.github.damontecres.wholphin.plavio.PlavioProgressStore
import com.github.damontecres.wholphin.plavio.PlavioSubtitleFiles
import com.github.damontecres.wholphin.plavio.PlavioUiPrefs
import com.github.damontecres.wholphin.plavio.Subtitle
import com.github.damontecres.wholphin.plavio.SubtitleStyle
import com.github.damontecres.wholphin.plavio.SubtitleStyleStore
import com.github.damontecres.wholphin.plavio.Video
import com.github.damontecres.wholphin.plavio.buildPlaybackRequest
import com.github.damontecres.wholphin.plavio.download.PlavioDownloadManager
import com.github.damontecres.wholphin.plavio.pickBestStream
import com.github.damontecres.wholphin.preferences.AssPlaybackMode
import com.github.damontecres.wholphin.preferences.PlayerBackend
import com.github.damontecres.wholphin.services.PlayerFactory
import com.github.damontecres.wholphin.services.UserPreferencesService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import io.github.peerless2012.ass.media.AssHandler
import io.github.peerless2012.ass.media.kt.withAssMkvSupport
import io.github.peerless2012.ass.media.parser.AssSubtitleParserFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import timber.log.Timber
import java.io.File
import java.lang.ref.WeakReference
import javax.inject.Inject

/**
 * One player-state snapshot for the UI (v0.3.18, diagnosis cause
 * #3): the ViewModel's clock job polls the player and publishes
 * these; the player screen's leaf composables read the flow. The
 * 500 ms polling used to live INSIDE the player composition, so
 * every tick recomposed the whole screen (video container, scrims,
 * control stack, and a 2 Hz AndroidView update) on a weak 32-bit
 * box — the reference player polls in its controller and exposes
 * state the same way this flow does.
 */
data class PlayerClock(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedMs: Long = 0L,
    val isPlaying: Boolean = false,
    val buffering: Boolean = true,
)

/**
 * Plays a [PlaybackRequest] (a direct addon stream URL) through the app's
 * existing playback stack: the player itself comes from [PlayerFactory]
 * (same backend choice, renderers, track selector and ASS setup as the
 * rest of the app) and the media item is built the same way the playback
 * flow builds it — direct URL, external subtitle configurations and a
 * container MIME hint. Stream headers, when the addon supplied any, are
 * applied at the data-source layer, mirroring how the factory feeds its
 * own HTTP client into a media source.
 *
 * Stage 7 adds the phone's subtitle machinery: addon subtitles are
 * downloaded to the cache ([PlavioSubtitleFiles]) so the Style rail's
 * per-video delay + Auto Sync can rewrite their timestamps (ExoPlayer
 * has no delay API for side-loaded subtitles), and next-episode
 * resolution for the autoplay countdown.
 */
@OptIn(UnstableApi::class)
@HiltViewModel
class PlavioPlayerViewModel
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
        private val playerFactory: PlayerFactory,
        private val userPreferencesService: UserPreferencesService,
        private val repository: AddonCatalogRepository,
        private val progressStore: PlavioProgressStore,
        private val subtitleStyleStore: SubtitleStyleStore,
        private val uiPrefs: PlavioUiPrefs,
        private val downloadManager: PlavioDownloadManager,
    ) : ViewModel() {
        private val _player = MutableStateFlow<Player?>(null)
        val player: StateFlow<Player?> = _player

        /** Controller-side player clock (v0.3.18 — see [PlayerClock]). */
        private val _playerClock = MutableStateFlow(PlayerClock())
        val playerClock: StateFlow<PlayerClock> = _playerClock
        private var clockJob: Job? = null

        /**
         * Set when a resume was requested but the stored stream is gone
         * from the addons' current answers — the UI lands the user on the
         * item's streams screen instead of showing a playback error.
         */
        private val _resumeFailed = MutableStateFlow(false)
        val resumeFailed: StateFlow<Boolean> = _resumeFailed

        /** The live subtitle style (Settings defaults + player Style rail share this store). */
        val subtitleStyle: StateFlow<SubtitleStyle> = subtitleStyleStore.style

        /** Auto-play next episode switch (phone parity). */
        val autoPlayNextEpisode: StateFlow<Boolean> = uiPrefs.autoPlayNextEpisode

        /** Preferred languages from Settings, used for first-track auto-pick. */
        val subtitleLanguages: StateFlow<List<String>> = uiPrefs.subtitleLanguages
        val preferredAudioLanguage: StateFlow<String?> = uiPrefs.preferredAudioLanguage

        /** Skip intro/recap/outro toggle (Settings → Playback, phone parity). */
        val showSkipIntro: StateFlow<Boolean> = uiPrefs.showSkipIntro

        /** IntroDB skip segments for the current title (empty when unknown/disabled). */
        private val _skipSegments = MutableStateFlow<List<SkipSegment>>(emptyList())
        val skipSegments: StateFlow<List<SkipSegment>> = _skipSegments

        /** Player-creation failure (backend/factory), surfaced as the error state. */
        private val _creationError = MutableStateFlow<String?>(null)
        val creationError: StateFlow<String?> = _creationError

        /** D-pad seek amounts from the playback preferences. */
        private val _skipForwardMs = MutableStateFlow(30_000L)
        val skipForwardMs: StateFlow<Long> = _skipForwardMs

        private val _skipBackMs = MutableStateFlow(10_000L)
        val skipBackMs: StateFlow<Long> = _skipBackMs

        /** Addon subtitles downloaded to the cache for the current title (delay/shift capable). */
        private val _localSubtitles = MutableStateFlow<List<LocalSubtitle>>(emptyList())
        val localSubtitles: StateFlow<List<LocalSubtitle>> = _localSubtitles

        /** The current title's persisted per-video subtitle delay. */
        private val _subtitleDelayMs = MutableStateFlow(0L)
        val subtitleDelayMs: StateFlow<Long> = _subtitleDelayMs

        private var assHandler: AssHandler? = null

        /**
         * Libass-on-pick state (v0.3.21, study fix #1 — OFF means
         * OFF): start() no longer downloads subtitles or builds a
         * libass player speculatively. [assLibassEnabled] caches the
         * user's ASS engine preference from the last start's
         * preferences read; when a pick needs libass and this play's
         * player lacks it, [rebuildWithLibassFor] arms
         * [libassRebuild] for the next start and leaves the pick in
         * [_pendingLibassSubtitle] for the panel to apply once the
         * rebuilt player's tracks land.
         */
        private var assLibassEnabled = false

        private data class LibassRebuild(
            val sub: Subtitle,
            val local: LocalSubtitle?,
        )

        private var libassRebuild: LibassRebuild? = null

        /** The ASS pick waiting for its libass rebuild to land (panel-applied). */
        private val _pendingLibassSubtitle = MutableStateFlow<Subtitle?>(null)
        val pendingLibassSubtitle: StateFlow<Subtitle?> = _pendingLibassSubtitle

        /** Decoder-visibility listener (v0.3.21, study fix #2 — measure only). */
        private var decoderListener: AnalyticsListener? = null

        /**
         * Whether the player screen's control layer is currently
         * presented (v0.3.21, study fix #4): the clock publishes at
         * full rate only while something is on screen to read it.
         */
        @Volatile
        private var controlsPresented = true

        /**
         * Standby hand-off (v0.3.21, study fix #5): the play that
         * [teardownForStandby] tore down when the app left the
         * foreground, waiting for [resumeFromStandby] on return.
         */
        private data class StandbySnapshot(
            val request: PlaybackRequest,
            val positionMs: Long,
            val wasPlaying: Boolean,
        )

        private var standbySnapshot: StandbySnapshot? = null

        /**
         * Single-flight start state (v0.3.17, owner notes 1 + 6):
         * every start() cancels the previous start job and takes a
         * new generation; a superseded launch bails at its next
         * checkpoint and releases any player it created but never
         * published. Before this, two starts could run CONCURRENTLY
         * — the error listener and a watchdog stepping the old
         * source-hopping ladder in the same instant raced two
         * factory creations against each other, the loser leaking
         * unreleased (codec held, surface attached — the
         * post-crash "lagging like hell" the owner then had to
         * power-cycle away) and interleaved player calls on the
         * winner being the crash itself.
         */
        private var startJob: Job? = null
        private var startGeneration = 0

        /** First-frame watchdog state (v0.3.2): see [armFirstFrameWatchdog]. */
        private var watchdogListener: Player.Listener? = null
        private var watchdogJob: Job? = null
        private var startGuardJob: Job? = null
        private var firstFrameSeen = false

        /**
         * Safe-mode state (v0.3.12): once the recovery ladder has
         * rebuilt the player in the factory's safe configuration for
         * this title, every later start for the same title (failover
         * switches included) stays in safe mode — the failure that
         * triggered it is a device/config problem, not a per-stream
         * one. Reset when a different title's bundle starts.
         */
        private var safeModeActive = false

        /** Audio-but-black watchdog state (v0.3.12): see [armFirstFrameWatchdog]. */
        private var videoWatchdogJob: Job? = null
        private var lastTracks: androidx.media3.common.Tracks? = null
        private var lastVideoWidth = 0
        private var lastVideoHeight = 0
        private var currentUrl: String? = null
        private var currentRequest: PlaybackRequest? = null
        private var progressJob: Job? = null
        private var progressListener: Player.Listener? = null

        /**
         * The player [progressListener] was attached to (v0.3.19):
         * [detachProgressTracking] removes the listener from THIS
         * player — before, detach only nulled the field and a
         * listener attached late (its add used to hop through an
         * async launch) could be stranded on a dying player.
         */
        private var progressPlayer: Player? = null
        private var subtitleJob: Job? = null

        /** Per-play skip-segments fetch (v0.3.19: tracked + generation-guarded). */
        private var skipSegmentsJob: Job? = null

        /** stop()'s tracked teardown launch (v0.3.19: see [stop]). */
        private var teardownJob: Job? = null

        /**
         * Sidecar subtitle state (v0.3.18 — the reference-shaped
         * pipeline in [PlavioSidecarSubtitles]): the picked addon
         * subtitle is parsed off-player and its active cues are
         * pushed into the PlayerView's SubtitleView by a 100 ms
         * render loop, so attaching or switching a subtitle NEVER
         * reloads the media item. [sidecarKey] is the active
         * subtitle's URL; [sidecarGeneration] invalidates stale
         * downloads/renders after a newer pick or a stop.
         */
        private var sidecarJob: Job? = null
        private var sidecarCues: List<CuesWithTiming> = emptyList()
        private var sidecarKey: String? = null
        private var sidecarGeneration = 0L
        private var sidecarCounter = 0L
        private var lastSidecarSignature: Long? = null
        private var subtitleViewRef: WeakReference<SubtitleView>? = null

        /** The addon subtitle currently shown via the sidecar (null = none). */
        private val _sidecarSubtitle = MutableStateFlow<Subtitle?>(null)
        val sidecarSubtitle: StateFlow<Subtitle?> = _sidecarSubtitle

        fun currentRequest(): PlaybackRequest? = currentRequest

        /** The live request (changes on source switches), for the player's header lines. */
        private val _currentRequestFlow = MutableStateFlow<PlaybackRequest?>(null)
        val currentRequestFlow: StateFlow<PlaybackRequest?> = _currentRequestFlow

        /**
         * URLs already tried for the current title (v0.3.9): the
         * failover walk re-picks from the untried remainder instead of
         * stepping blindly to the next list entry. Reset when a new
         * title's bundle starts; switchStream shares the bundle, so
         * failovers keep accumulating into the same set.
         */
        private val triedStreamUrls = LinkedHashSet<String>()

        /**
         * Container types proven by the start-time sniff (v0.3.13),
         * by stream URL. Signed URLs rotate, so the map is small and
         * session-scoped; it is flushed if it ever grows past a
         * token-rotation binge.
         */
        private val probedMimeTypes = HashMap<String, String>()

        /**
         * Installed by the player screen while it is composed: runs
         * one bounded SAME-SOURCE recovery (the same path a player
         * error uses — v0.3.17: the player never switches source on
         * its own) and returns true when a recovery was scheduled.
         * The first-frame watchdog calls this before surfacing an
         * error, so a silent hang gets the same recovery a hard
         * error gets.
         */
        var watchdogRecovery: (() -> Boolean)? = null

        fun start(
            request: PlaybackRequest,
            resumePositionMs: Long = 0,
            startPaused: Boolean = false,
        ) {
            if (request.streamUrl == currentUrl && _player.value != null) return
            // v0.3.22 (the 512 MB pass): a play is starting — hand
            // the image loader's memory cache back to the player
            // (see trimImageMemoryForPlayback).
            trimImageMemoryForPlayback()
            if (currentRequest?.streams !== request.streams) {
                triedStreamUrls.clear()
                safeModeActive = false
            }
            triedStreamUrls += request.streamUrl
            currentUrl = request.streamUrl
            currentRequest = request
            _currentRequestFlow.value = request
            _resumeFailed.value = false
            _creationError.value = null
            firstFrameSeen = false
            _skipSegments.value = emptyList()
            _localSubtitles.value = emptyList()
            // v0.3.21 (study fix #1): consume a libass rebuild armed
            // by a subtitle pick. The flag builds THIS start's player
            // with libass; the pick's already-resolved local file
            // (content-sniffed in the sidecar) is restored past the
            // reset above so the media item can carry it. Any other
            // start clears a pending pick — it belonged to the play
            // that armed it, never to a later title.
            val libassForThisStart = libassRebuild
            libassRebuild = null
            if (libassForThisStart == null) {
                _pendingLibassSubtitle.value = null
            } else {
                libassForThisStart.local?.let { _localSubtitles.value = listOf(it) }
            }
            _subtitleDelayMs.value = 0L
            // v0.3.18: a new start drops any sidecar subtitle the
            // previous title had up — subtitles are OFF by default
            // (owner's order, same day: "no setting should be on by
            // default, it's user's choice"), so nothing carries over
            // and nothing auto-applies below; the panel lists the
            // subtitles and a pick is one tap away.
            stopSidecar()
            clockJob?.cancel()
            clockJob = null
            _playerClock.value = PlayerClock()
            loadSkipSegments(request)
            // v0.3.17 single-flight: cancel the previous start and
            // take a new generation (see startJob above). A
            // superseded launch checks its generation after every
            // long await below and bails — releasing a player it
            // created but never published — instead of racing the
            // newer start.
            startJob?.cancel()
            val generation = ++startGeneration
            startJob =
                viewModelScope.launch {
                    // Start-phase guard: everything between here and the
                    // player existing (subtitle-delay read, preferences,
                    // factory creation) is awaited before the first-frame
                    // watchdog can arm — a hang in any of it used to leave
                    // the bare spinner up forever with no error. Bound the
                    // whole phase; the error surface renders even while
                    // _player is still null.
                    startGuardJob?.cancel()
                    startGuardJob =
                        viewModelScope.launch {
                            delay(START_PHASE_TIMEOUT_MS)
                            if (_player.value == null && _creationError.value == null &&
                                currentUrl == request.streamUrl
                            ) {
                                Timber.w("Player start phase exceeded %dms", START_PHASE_TIMEOUT_MS)
                                _creationError.value = "This stream could not be played."
                            }
                        }
                    _subtitleDelayMs.value =
                        runCatching { subtitleStyleStore.delayMsFor(request.videoId) }.getOrDefault(0L)
                    releasePlayer()
                    // Resume: addon stream URLs rotate, so re-resolve the
                    // item first. When the addons answer with streams but the
                    // stored one is no longer among them, the link is dead —
                    // report it so the UI can offer the fresh stream list.
                    // When nothing answers at all (e.g. offline), fall back
                    // to the stored request as-is.
                    //
                    // v0.3.2: the wait is BOUNDED. loadStreams awaits every
                    // addon (25s HTTP cap each) plus the subtitle sweep and
                    // debrid pass, so an unbounded wait put tens of seconds
                    // of black screen before the player was even created —
                    // a top "player takes time to load" cause. After
                    // RESUME_RESOLVE_TIMEOUT_MS the stored request plays.
                    var effective = request
                    // Instant Play (v0.3.16, note 9): a Play press now
                    // opens THIS screen immediately with an unresolved
                    // request (autoplayResolve, no stream URL yet) — the
                    // source finding the detail page used to block on
                    // happens here, inside the player, behind its loading
                    // layer. Same fan-out, same autoplay pick the detail
                    // page made; when nothing playable answers, the start
                    // reports resume-failed, which swaps this Play entry
                    // for the sources picker — the old NoStreams fallback,
                    // reached without ever sitting on a "Finding…" button.
                    if (request.autoplayResolve) {
                        val bundle =
                            runCatching {
                                kotlinx.coroutines.withTimeoutOrNull(AUTOPLAY_RESOLVE_TIMEOUT_MS) {
                                    repository.loadStreams(request.type, request.videoId, request.metaId)
                                }
                            }.onFailure { Timber.v(it, "In-player autoplay resolution failed") }
                                .getOrNull()
                        val best = bundle?.let { repository.pickForAutoplay(it.streams) }
                        if (bundle == null || best == null) {
                            // v0.3.17: only the CURRENT start may
                            // report failure — a superseded launch
                            // (cancelled mid-resolve; runCatching
                            // above swallows its CancellationException
                            // into a null bundle) must not clobber the
                            // newer start's state.
                            if (generation == startGeneration) {
                                _resumeFailed.value = true
                            }
                            return@launch
                        }
                        effective =
                            com.github.damontecres.wholphin.plavio.buildPlaybackRequest(
                                com.github.damontecres.wholphin.plavio.refForPlaybackRequest(request),
                                bundle,
                                best,
                                request.episodes,
                            )
                        currentRequest = effective
                        _currentRequestFlow.value = effective
                        currentUrl = effective.streamUrl
                        triedStreamUrls += effective.streamUrl
                    }
                    if (resumePositionMs > 0) {
                        val bundle =
                            runCatching {
                                kotlinx.coroutines.withTimeoutOrNull(RESUME_RESOLVE_TIMEOUT_MS) {
                                    repository.loadStreams(request.type, request.videoId, request.metaId)
                                }
                            }.onFailure { Timber.v(it, "Resume re-resolution failed") }
                                .getOrNull()
                        if (bundle != null && bundle.streams.isNotEmpty()) {
                            val fresh = bundle.streams.firstOrNull { it.url == request.streamUrl }
                            if (fresh == null) {
                                if (generation == startGeneration) {
                                    _resumeFailed.value = true
                                }
                                return@launch
                            }
                            effective =
                                request.copy(
                                    headers = fresh.headers,
                                    mimeType = fresh.mimeType ?: request.mimeType,
                                    subtitles = bundle.subtitles.ifEmpty { request.subtitles },
                                )
                            currentRequest = effective
                            _currentRequestFlow.value = effective
                        }
                    }
                    // Container sniff (v0.3.13) — the Verity fix. An addon
                    // stream whose URL carries no .m3u8/.mpd suffix and no
                    // MIME hint leaves the MediaItem untyped, and Media3
                    // then infers a PROGRESSIVE source from the
                    // suffix-less URL: an HLS playlist gets fed to the
                    // file extractors and no frame ever renders (the
                    // owner's Verity recording — 25s of black while the
                    // recovery ladder changed renderers, which cannot fix
                    // a source-typing problem; the live channels played
                    // because their URLs do end in .m3u8). When the type
                    // is unknown, sniff it from the wire (the stream's own
                    // headers included) before the player is built.
                    // v0.3.22: the sniff now runs CONCURRENTLY with the
                    // preferences read + player creation below and is only
                    // awaited at media-item build time — its round trip
                    // (up to PROBE_TIMEOUT_MS on a slow host) used to sit
                    // serially in front of player creation on every
                    // untyped start.
                    val probeDeferred =
                        if (containerMimeType(effective) == null) {
                            async { probeContainerMime(effective) }
                        } else {
                            null
                        }
                    // v0.3.21 (study fix #1): OFF means OFF — the
                    // v0.3.18 start-time subtitle sweep is GONE. With
                    // no subtitle selected, a play start downloads
                    // NOTHING: subtitles resolve lazily on the pick
                    // itself (startSidecar resolves the one picked
                    // file; the panel's attach/reload actions resolve
                    // on demand). ASS detection at start is the URL
                    // mime hint only (see hasAssSubtitles below); the
                    // content sniff happens on pick, in the sidecar.
                    val preferences = userPreferencesService.getCurrent()
                    assLibassEnabled =
                        preferences.appPreferences.playbackPreferences.overrides.assPlaybackMode ==
                            AssPlaybackMode.ASS_LIBASS
                    preferences.appPreferences.playbackPreferences.skipForwardMs
                        .takeIf { it > 0 }
                        ?.let { _skipForwardMs.value = it }
                    preferences.appPreferences.playbackPreferences.skipBackMs
                        .takeIf { it > 0 }
                        ?.let { _skipBackMs.value = it }
                    // v0.3.21 (study fix #1): libass is built ONLY
                    // for a start a subtitle pick armed (see the
                    // consumption at the top of start()) — never
                    // speculatively because a title merely carries
                    // ASS subtitles. The factory gate itself is
                    // unchanged (preference + this flag + not safe
                    // mode).
                    val hasAssSubtitles = libassForThisStart != null
                    // ExoPlayer is the only engine (v0.3.2): MPV, the
                    // Auto mode and the backend switcher are removed — a
                    // persisted backend choice in preferences is ignored.
                    val creation =
                        runCatching {
                            playerFactory.createVideoPlayer(
                                PlayerBackend.EXO_PLAYER,
                                preferences.appPreferences,
                                safeMode = safeModeActive,
                                hasAssSubtitles = hasAssSubtitles,
                            )
                        }.onFailure {
                            Timber.e(it, "Player creation failed")
                            CrashReports.captureException(it)
                            if (generation == startGeneration) {
                                _creationError.value = it.message ?: "Could not start the player."
                            }
                        }.getOrNull() ?: return@launch
                    // v0.3.17 single-flight checkpoint: a newer start
                    // superseded this one while the factory worked.
                    // The player below was never published, so
                    // releasePlayer() will never see it — release it
                    // here (on Main, per the Media3 thread rule) and
                    // bail; publishing it would race the newer
                    // start's own player for the surface and the
                    // codec.
                    if (generation != startGeneration) {
                        withContext(Dispatchers.Main) {
                            // v0.3.19: the orphan's libass handler
                            // dies with it — it was never assigned
                            // to the field, so only this call can
                            // free its native instance.
                            releasePlayerNow(creation.player, creation.assHandler)
                        }
                        return@launch
                    }
                    assHandler = creation.assHandler
                    val player = creation.player
                    // Await the sniff launched above (usually already
                    // done — it overlapped creation) and type the item.
                    probeDeferred?.await()?.let { probed ->
                        effective = effective.copy(mimeType = probed)
                        currentRequest = effective
                        _currentRequestFlow.value = effective
                    }
                    // The sniff await can also outlive this start.
                    if (generation != startGeneration) {
                        withContext(Dispatchers.Main) {
                            // v0.3.19: the field already holds this
                            // creation's handler (assigned just above)
                            // — free it here and clear the field, or
                            // the native instance leaks AND the field
                            // would describe a dead player.
                            if (assHandler === creation.assHandler) {
                                assHandler = null
                            }
                            releasePlayerNow(player, creation.assHandler)
                        }
                        return@launch
                    }
                    val mediaItem = buildMediaItem(effective)
                    withContext(Dispatchers.Main) {
                        if (player is ExoPlayer && effective.headers.isNotEmpty()) {
                            player.setMediaSource(buildMediaSource(mediaItem, effective))
                        } else {
                            player.setMediaItem(mediaItem)
                        }
                        player.prepare()
                        // Subtitles OFF by default (v0.3.18, owner
                        // order): the text track type starts
                        // DISABLED on every play. Nothing displays
                        // until the user picks a subtitle in the
                        // panel — a pick re-enables the type (media
                        // path) or starts the sidecar (addon path).
                        runCatching {
                            player.trackSelectionParameters =
                                player.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                    .build()
                        }
                        if (resumePositionMs > 0) {
                            player.seekTo(resumePositionMs)
                        }
                        // v0.3.21 (study fix #5): a standby resume
                        // of a play that was PAUSED when the app
                        // left lands paused at its position; every
                        // other start plays, as before.
                        if (startPaused) {
                            player.pause()
                        } else {
                            player.play()
                        }
                    }
                    _player.value = player
                    startGuardJob?.cancel()
                    startGuardJob = null
                    attachProgressTracking(player, effective)
                    startClock(player)
                    armFirstFrameWatchdog(player)
                    // v0.3.21 (study fix #2): decoder visibility —
                    // log this play's decoder names once. v0.3.22:
                    // the play's buffer profile logs beside them.
                    attachDecoderLogging(player, creation.bufferProfileName)
                }
        }

        /**
         * First-frame watchdog (v0.3.2, carried over from the v0.3.1
         * Auto mode): if ExoPlayer produces no first frame within
         * [FIRST_FRAME_WATCHDOG_MS] — a dead link that never errors,
         * just buffers forever — the start first goes through the
         * same bounded source failover a hard error gets (via
         * [watchdogRecovery]); the standard error surface (Retry /
         * Next source live there) takes over only when that cannot
         * switch, instead of leaving a hung black screen. Once a frame renders, the
         * watchdog disarms: later stalls are buffering, not a dead
         * start. Errors before the first frame keep the screen's own
         * handling (bounded source failover), so the watchdog only
         * covers the silent-hang case.
         */
        private fun armFirstFrameWatchdog(player: Player) {
            firstFrameSeen = false
            lastTracks = null
            lastVideoWidth = 0
            lastVideoHeight = 0
            val listener =
                object : Player.Listener {
                    override fun onRenderedFirstFrame() {
                        markFirstFrame()
                    }
                    // v0.3.5: onIsPlayingChanged no longer disarms the
                    // watchdog. "Playing" only proves the audio path is
                    // alive — on the owner's TV the stream played
                    // (sound) while no frame ever reached the screen,
                    // which disarmed the watchdog and left an endless
                    // buffering circle instead of this error surface.
                    // Only a rendered first frame counts as picture.

                    // v0.3.12: the audio-but-black watchdog below reads
                    // these two feeds.
                    override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                        lastTracks = tracks
                    }

                    override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                        lastVideoWidth = videoSize.width
                        lastVideoHeight = videoSize.height
                    }
                }
            watchdogListener = listener
            runCatching { player.addListener(listener) }
            armVideoTrackWatchdog(player)
            watchdogJob?.cancel()
            watchdogJob =
                viewModelScope.launch {
                    // v0.3.22 early dead-link check: at
                    // FIRST_FRAME_EARLY_CHECK_MS, if NOTHING has been
                    // buffered at all (no bytes are flowing — the host
                    // accepted and went silent, or never answered),
                    // the start is dead and waiting out the full
                    // watchdog only makes the failover feel slower.
                    // When bytes ARE flowing, the full watchdog
                    // stands — a slow-but-alive host keeps its 12s.
                    delay(FIRST_FRAME_EARLY_CHECK_MS)
                    if (!firstFrameSeen && _player.value === player &&
                        !player.isPlaying && player.bufferedPosition <= 0L
                    ) {
                        Timber.w(
                            "No data buffered within %dms — dead link, failing the start early",
                            FIRST_FRAME_EARLY_CHECK_MS,
                        )
                        failFirstFrame(player)
                        return@launch
                    }
                    delay(FIRST_FRAME_WATCHDOG_MS - FIRST_FRAME_EARLY_CHECK_MS)
                    if (!firstFrameSeen && _player.value === player) {
                        Timber.w(
                            "No first frame within %dms — failing the start",
                            FIRST_FRAME_WATCHDOG_MS,
                        )
                        failFirstFrame(player)
                    }
                }
        }

        /**
         * The shared first-frame failure path (v0.3.22; the body is
         * the v0.3.9 watchdog's): a silent hang gets the same bounded
         * same-source recovery a hard player error gets — the screen's hook
         * switches source first (the new start releases this hung
         * player itself); only when it cannot switch does the error
         * surface take over. Error FIRST, release second: until
         * v0.3.5 the order was reversed and the release could throw
         * (see releasePlayer's self-cancel note), leaving neither an
         * error nor a player — the endless spinner with background
         * audio the owner filmed.
         */
        private suspend fun failFirstFrame(player: Player) {
            val switched =
                runCatching { watchdogRecovery?.invoke() }
                    .getOrNull() == true
            if (!switched) {
                _creationError.value = "This stream could not be played."
                releasePlayer()
            }
        }

        /** First frame rendered: the watchdog disarms (v0.3.5: rendering only — playing state no longer counts, see armFirstFrameWatchdog). */
        private fun markFirstFrame() {
            firstFrameSeen = true
            watchdogJob?.cancel()
            watchdogJob = null
        }

        /**
         * Player-entry memory trim (v0.3.22, the 512 MB pass): on a
         * 512 MB set, the browsing bitmaps sitting in Coil's memory
         * cache (Home hero, poster rows) compete with the player for
         * the same scarce RAM for the whole play. A play start
         * clears the MEMORY cache — one call, at entry only, nothing
         * periodic. The disk cache is untouched: browsing re-reads
         * posters from disk (re-fetching only what disk lost) when
         * the user comes back. Failure-proof: no singleton loader
         * (tests, early exits) just skips the trim.
         */
        private fun trimImageMemoryForPlayback() {
            runCatching {
                coil3.SingletonImageLoader.get(context).memoryCache?.clear()
                Timber.i("Image memory cache cleared at play start")
            }.onFailure { Timber.v(it, "Image memory trim skipped") }
        }

        /**
         * Decoder visibility (v0.3.21, study fix #2): logs the video
         * and audio decoder names ONCE per play, with software
         * landings clearly flagged, to logcat and a Sentry
         * breadcrumb. In v0.3.21 it was measure-only; v0.3.22 makes
         * the factory hardware-FIRST for video (see
         * HardwareFirstVideoCodecSelector in PlayerFactory.kt —
         * software decoders last, the fallback kept on the owner's
         * "don't break anything" order), so this listener is now
         * the per-play PROOF of which decoder each play actually
         * landed on, hardware or flagged-[SOFTWARE].
         * The play's buffer profile (v0.3.22's RAM-adaptive
         * LoadControl) logs here too, once per play, beside the
         * decoder lines.
         */
        private fun attachDecoderLogging(
            player: Player,
            bufferProfileName: String,
        ) {
            // v0.3.22 (the 512 MB pass): which LoadControl appetite
            // this play's player was built with — standard on strong
            // TVs, low-ram on the 512 MB class.
            Timber.i("Buffer profile: %s", bufferProfileName)
            CrashReports.addBreadcrumb("buffer-profile: $bufferProfileName")
            val exo = player as? ExoPlayer ?: return
            var videoLogged = false
            var audioLogged = false
            val listener =
                object : AnalyticsListener {
                    override fun onVideoDecoderInitialized(
                        eventTime: AnalyticsListener.EventTime,
                        decoderName: String,
                        initializedTimestampMs: Long,
                        initializationDurationMs: Long,
                    ) {
                        if (videoLogged) return
                        videoLogged = true
                        logDecoder("video", decoderName)
                    }

                    override fun onAudioDecoderInitialized(
                        eventTime: AnalyticsListener.EventTime,
                        decoderName: String,
                        initializedTimestampMs: Long,
                        initializationDurationMs: Long,
                    ) {
                        if (audioLogged) return
                        audioLogged = true
                        logDecoder("audio", decoderName)
                    }
                }
            decoderListener = listener
            runCatching { exo.addAnalyticsListener(listener) }
        }

        private fun logDecoder(
            kind: String,
            decoderName: String,
        ) {
            val software = isSoftwareDecoder(decoderName)
            Timber.i(
                "Decoder %s: %s%s",
                kind,
                decoderName,
                if (software) " [SOFTWARE]" else "",
            )
            CrashReports.addBreadcrumb(
                "decoder-$kind: $decoderName" + if (software) " (software)" else "",
            )
        }

        /** Google's software codecs, the FFmpeg audio extension and dav1d (AV1 software). */
        private fun isSoftwareDecoder(decoderName: String): Boolean =
            decoderName.startsWith("OMX.google.") ||
                decoderName.startsWith("c2.android.") ||
                decoderName.contains("ffmpeg", ignoreCase = true) ||
                decoderName.contains("dav1d", ignoreCase = true)

        /** Detaches the decoder listener from [player] (stop()/releasePlayer() paths). */
        private fun detachDecoderLogging(player: Player) {
            val listener = decoderListener ?: return
            decoderListener = null
            (player as? ExoPlayer)?.let { exo ->
                runCatching { exo.removeAnalyticsListener(listener) }
            }
        }

        /**
         * Audio-but-black watchdog (v0.3.12): the first-frame watchdog
         * only covers a start that never renders. The owner's other
         * failure — sound playing, picture black, sometimes from the
         * start, sometimes after the start — renders a first frame (or
         * selects no renderable video track at all) and then sits
         * there forever. This watchdog checks the playing stream
         * periodically: while the player is READY and the position is
         * advancing, the media's own track list must contain a
         * selected, supported video track that is producing a non-zero
         * video size. Two consecutive checks with a zero size while the
         * position advances — or no renderable video track at all —
         * route through the same recovery ladder a hard error gets
         * (safe-mode rebuild, then next source). Media with NO video
         * track in it at all (audio-only content) is left alone: the
         * check only fires when the file HAS video groups.
         */
        private fun armVideoTrackWatchdog(player: Player) {
            videoWatchdogJob?.cancel()
            videoWatchdogJob =
                viewModelScope.launch {
                    // v0.3.21 (study fix #4): the watchdog's job is
                    // the early-play window it was built for — after
                    // VIDEO_WATCHDOG_WINDOW_MS it disarms instead of
                    // polling the whole play.
                    val armedAtMs = android.os.SystemClock.elapsedRealtime()
                    delay(VIDEO_WATCHDOG_FIRST_CHECK_MS)
                    var zeroSizeStrikes = 0
                    var lastPosition = -1L
                    while (isActive) {
                        if (_player.value !== player) return@launch
                        if (android.os.SystemClock.elapsedRealtime() - armedAtMs >
                            VIDEO_WATCHDOG_WINDOW_MS
                        ) {
                            return@launch
                        }
                        val state =
                            runCatching { player.playbackState }.getOrDefault(-1)
                        val position =
                            runCatching { player.currentPosition }.getOrDefault(0L)
                        val tracks = lastTracks
                        if (state == Player.STATE_READY && position > 3_000 && tracks != null) {
                            val videoGroups =
                                tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
                            if (videoGroups.isNotEmpty()) {
                                val hasRenderableVideo =
                                    videoGroups.any { group ->
                                        group.isSelected &&
                                            (0 until group.length).any { index ->
                                                group.isTrackSupported(index)
                                            }
                                    }
                                val progressed =
                                    lastPosition >= 0 && position > lastPosition + 1_000
                                val failure =
                                    when {
                                        !hasRenderableVideo -> true
                                        lastVideoWidth <= 0 || lastVideoHeight <= 0 -> {
                                            if (progressed) {
                                                zeroSizeStrikes++
                                                zeroSizeStrikes >= 2
                                            } else {
                                                false
                                            }
                                        }
                                        else -> false
                                    }
                                if (failure) {
                                    Timber.w(
                                        "Audio-but-black detected (renderable=%s, videoSize=%dx%d) — failing over",
                                        hasRenderableVideo,
                                        lastVideoWidth,
                                        lastVideoHeight,
                                    )
                                    val switched =
                                        runCatching { watchdogRecovery?.invoke() }
                                            .getOrNull() == true
                                    if (!switched) {
                                        // Same order as the first-frame
                                        // watchdog: error FIRST, release
                                        // second (see its v0.3.5 note).
                                        _creationError.value = "This stream could not be played."
                                        releasePlayer()
                                    }
                                    return@launch
                                }
                            }
                        }
                        lastPosition = position
                        delay(VIDEO_WATCHDOG_INTERVAL_MS)
                    }
                }
        }

        /**
         * Back / dispose path (v0.3.7 shape, v0.3.16 thread fix):
         * stop() does the cheap work synchronously — pause (the
         * sound dies on the Back press itself), drop the listeners
         * and detach the player from the UI — and the progress
         * record runs on the viewModel scope. The v0.3.7 form also
         * sent ExoPlayer.release() to a background dispatcher on the
         * belief that "Media3 release is safe from any thread" —
         * false on the bundled Media3 1.11.1: release() calls
         * verifyApplicationThread() and throws off Main, so the
         * background release silently never happened (the throw was
         * swallowed by runCatching) and the codec stayed held for
         * the factory guard to clean up. The release now launches
         * on the viewModel scope (Main): it still leaves the swap's
         * critical path (pause already killed the sound), it runs a
         * frame later on the thread Media3 requires, and the
         * position snapshot above still lands the title in Continue
         * Watching at the right position.
         */
        fun stop() {
            val request = currentRequest
            val player = _player.value
            // v0.3.17: an in-flight start must not publish a player
            // after the screen is gone — cancel it and move the
            // generation, so a launch that outlives the cancel bails
            // at its checkpoint instead of resurrecting playback
            // (and leaking its player) behind the browse screens.
            startJob?.cancel()
            startJob = null
            startGeneration++
            // v0.3.21: an explicit stop is an EXIT — a pending
            // libass pick and any standby snapshot die with it.
            // (teardownForStandby stores its snapshot AFTER stop()
            // returns, so this clear cannot eat the live hand-off.)
            libassRebuild = null
            _pendingLibassSubtitle.value = null
            standbySnapshot = null
            currentUrl = null
            currentRequest = null
            _currentRequestFlow.value = null
            progressJob?.cancel()
            progressJob = null
            subtitleJob?.cancel()
            subtitleJob = null
            clockJob?.cancel()
            clockJob = null
            // v0.3.19: the skip-segments fetch is per-play too —
            // without this it was an untracked job that could
            // outlive the play (see loadSkipSegments).
            skipSegmentsJob?.cancel()
            skipSegmentsJob = null
            stopSidecar()
            if (player == null) return
            val position = runCatching { player.currentPosition }.getOrDefault(0L)
            val duration = runCatching { player.duration }.getOrDefault(0L)
            runCatching { player.pause() }
            val listener = progressListener
            detachProgressTracking()
            detachDecoderLogging(player)
            val frameListener = watchdogListener
            watchdogListener = null
            watchdogJob?.cancel()
            watchdogJob = null
            videoWatchdogJob?.cancel()
            videoWatchdogJob = null
            _player.value = null
            // v0.3.19: keep the handler for the teardown below —
            // nulling the field without releasing it is exactly
            // the leak this build kills.
            val handler = assHandler
            assHandler = null
            runCatching { if (listener != null) player.removeListener(listener) }
            runCatching { if (frameListener != null) player.removeListener(frameListener) }
            if (request != null && position > 0) {
                viewModelScope.launch {
                    runCatching {
                        progressStore.record(
                            request = request,
                            positionMs = position,
                            durationMs = if (duration <= 0 || duration == C.TIME_UNSET) 0 else duration,
                        )
                    }
                }
            }
            // v0.3.19: the teardown launch is TRACKED now (it used
            // to be a fire-and-forget launch — a racing start's
            // factory gate could then tear the same player down a
            // second time; releasePlayerNow's forgetPlayer claim
            // plus this handle close that class).
            teardownJob =
                viewModelScope.launch {
                    // v0.3.18: the emptied-pipeline teardown order
                    // (see releasePlayerNow) — stop() used to
                    // release the full player here.
                    releasePlayerNow(player, handler)
                }
        }

        // --------------------------------------------------------------
        // Skip segments (IntroDB), source switching, retry
        // --------------------------------------------------------------

        /** Fetches IntroDB segments for the title (once per start; phone behaviour). */
        private fun loadSkipSegments(request: PlaybackRequest) {
            // v0.3.19: TRACKED + guarded. This used to be a
            // fire-and-forget launch per start with no staleness
            // check: on a fast title hop, the PREVIOUS title's fetch
            // could land after the new start and write its segments
            // into the new play. The job is cancelled by the next
            // start (here, before the early returns too) and by
            // stop(), and the write only lands while the current
            // request is still this exact stream.
            skipSegmentsJob?.cancel()
            skipSegmentsJob = null
            val imdbId = request.imdbId ?: return
            if (request.isLive || request.isTrailer) return
            skipSegmentsJob =
                viewModelScope.launch {
                    if (!uiPrefs.showSkipIntro.value) return@launch
                    val segments =
                        runCatching {
                            IntroDbApi().fetchSegments(
                                imdbId,
                                request.season,
                                request.episode,
                                request.isMovie,
                            )
                        }.getOrDefault(emptyList())
                    val current = currentRequest
                    if (current != null &&
                        current.videoId == request.videoId &&
                        current.streamUrl == request.streamUrl
                    ) {
                        _skipSegments.value = segments
                    }
                }
        }

        /**
         * The next source to try for the current title (the MANUAL
         * Next source button only — v0.3.17: nothing automatic calls
         * this any more): the autoplay pick re-run over the streams not
         * yet tried this session — the quality walk decides, already-
         * tried URLs (including the current one) are skipped, and the
         * result is null when nothing untried remains. (v0.3.9: was a
         * blind idx+1 step down the list.)
         */
        fun nextStream(): StreamItem? {
            val request = currentRequest ?: return null
            val untried = request.streams.filter { it.url !in triedStreamUrls }
            if (untried.isEmpty()) return null
            return repository.pickForAutoplay(untried)
        }

        /**
         * Switches playback to [stream] from the current title's bundle,
         * keeping the position — the manual Next source / Sources-panel
         * pick path. Reuses the full start flow (fresh player, fresh media
         * item) minus resume re-resolution.
         */
        fun switchStream(
            stream: StreamItem,
            positionMs: Long,
        ) {
            val request = currentRequest ?: return
            if (stream.url == request.streamUrl) {
                retry(positionMs)
                return
            }
            val next =
                request.copy(
                    streamUrl = stream.url,
                    headers = stream.headers,
                    mimeType = stream.mimeType,
                    streamLabel = streamQualityLabel(stream) ?: request.streamLabel,
                    sourceName = stream.sourceName ?: request.sourceName,
                )
            currentUrl = null // bypass start()'s same-url guard
            start(next, positionMs)
        }

        /**
         * Re-fetches the current title's stream bundle into the live
         * request (v0.3.18) — the in-player Sources panel's reload path
         * for requests that carry no streams (resumed items). Same
         * repository call start()'s resume re-resolution makes; the
         * playing stream itself is untouched, only the bundle the
         * panel lists is filled in.
         */
        fun refreshStreams() {
            val request = currentRequest ?: return
            viewModelScope.launch {
                val bundle =
                    runCatching { repository.loadStreams(request.type, request.videoId, request.metaId) }
                        .onFailure { Timber.v(it, "Sources refresh failed") }
                        .getOrNull() ?: return@launch
                if (bundle.streams.isEmpty()) return@launch
                val current = currentRequest ?: return@launch
                val updated = current.copy(streams = bundle.streams)
                currentRequest = updated
                _currentRequestFlow.value = updated
            }
        }

        /**
         * Light same-source recovery (v0.3.17, attempt one of the
         * reference method): re-prepare the LIVE player on the item
         * it already holds — no factory rebuild, no new player, the
         * cheapest possible second chance for a transient failure.
         * The position steps back 1ms so a seek lands before
         * prepare() (the reference's exact shape). Returns false
         * when no player is live (e.g. a watchdog fired on a start
         * that never produced one) — the caller then falls back to
         * a full same-source restart via [retry].
         */
        fun reprepareCurrentStream(positionMs: Long): Boolean {
            val player = _player.value ?: return false
            viewModelScope.launch {
                withContext(Dispatchers.Main) {
                    runCatching {
                        if (positionMs > 0) {
                            player.seekTo((positionMs - 1).coerceAtLeast(0L))
                        }
                        player.prepare()
                        player.play()
                    }
                }
            }
            return true
        }

        /** Recreates the player for the current stream at [positionMs]. */
        fun retry(positionMs: Long) {
            val request = currentRequest ?: return
            currentUrl = null
            _creationError.value = null
            start(request, positionMs)
        }

        /**
         * Recovery ladder step 1 (v0.3.12): rebuild the player for the
         * CURRENT stream in the factory's safe configuration
         * (MediaCodec-first renderers, no libass, tunnelling off) at
         * the same position. This is the "switch backend" step of the
         * old Auto order, rebuilt for the ExoPlayer-only app: MPV is
         * gone (v0.3.2), so the second chance is a genuinely different
         * ExoPlayer configuration, not a re-run of the one that just
         * failed. Returns false when safe mode is already active (the
         * ladder then moves on to the next source) or nothing is
         * playing. Once tripped, the title stays in safe mode (see
         * [safeModeActive]).
         */
        fun recreateInSafeMode(positionMs: Long): Boolean {
            if (safeModeActive) return false
            val request = currentRequest ?: return false
            safeModeActive = true
            Timber.i("Recovery ladder: rebuilding player in safe mode for %s", request.streamUrl)
            currentUrl = null // bypass start()'s same-url guard
            _creationError.value = null
            start(request, positionMs)
            return true
        }

        /** Outcome of the in-player Download capsule (v0.3.16). */
        enum class PlayerDownloadResult { STARTED, DASH }

        /**
         * The player's Download capsule (Sample B player, v0.3.16):
         * enqueues the CURRENT stream into the one download engine
         * the Streams screen uses — same DASH refusal, same entry
         * shape (title/poster/ids/headers all ride the request).
         * Not a second download path.
         */
        fun downloadCurrent(request: PlaybackRequest): PlayerDownloadResult {
            if (downloadManager.isDashUrl(request.streamUrl)) {
                return PlayerDownloadResult.DASH
            }
            downloadManager.enqueue(
                url = request.streamUrl,
                title =
                    if (request.seriesName != null) {
                        listOfNotNull(request.seriesName, request.episodeTitle)
                            .joinToString(" — ")
                    } else {
                        request.title
                    },
                poster = request.poster,
                type = request.type,
                videoId = request.videoId,
                metaId = request.metaId,
                season = request.season,
                episode = request.episode,
                seriesName = request.seriesName,
                episodeTitle = request.episodeTitle,
                sourceName = request.sourceName,
                headers = request.headers,
                mimeType = request.mimeType,
            )
            return PlayerDownloadResult.STARTED
        }

        /** Resume prompt > Start over: drop the stored position for this title. */
        fun clearProgress() {
            val request = currentRequest ?: return
            viewModelScope.launch {
                runCatching { progressStore.remove(request.type, request.videoId) }
            }
        }

        // --------------------------------------------------------------
        // Subtitles: local resolution, delay, auto sync
        // --------------------------------------------------------------

        /**
         * "Fetch subtitles online": subtitle addons' results for the
         * current title that the request does not already carry.
         */
        suspend fun fetchOnlineSubtitles(): List<Subtitle> {
            val request = currentRequest ?: return emptyList()
            val existing = request.subtitles.map { it.url }.toSet()
            return runCatching {
                repository.fetchOnlineSubtitles(request.type, request.videoId, request.metaId)
            }.getOrDefault(emptyList()).filter { it.url !in existing }
        }

        /**
         * Attaches an online subtitle to the current title: it joins
         * the request's subtitle list (so the panel lists it as a
         * row) and its local copy resolves for delay/Auto Sync work.
         * v0.3.18: attaching no longer rebuilds the media item and
         * no longer selects anything — subtitles are off until the
         * user picks the row in the panel, like every other
         * subtitle (owner's off-by-default order).
         */
        fun attachOnlineSubtitle(subtitle: Subtitle) {
            val request = currentRequest ?: return
            if (request.subtitles.any { it.url == subtitle.url }) return
            val updated = request.copy(subtitles = request.subtitles + subtitle)
            currentRequest = updated
            _currentRequestFlow.value = updated
            resolveAndPublishLocals(updated)
        }

        /** Preferred-language rows inside the player panels (Settings no longer hosts them). */
        fun setSubtitleLanguages(languages: List<String>) {
            viewModelScope.launch { runCatching { uiPrefs.setSubtitleLanguages(languages) } }
        }

        fun setPreferredAudioLanguage(language: String?) {
            viewModelScope.launch { runCatching { uiPrefs.setPreferredAudioLanguage(language) } }
        }

        /**
         * Downloads the current title's addon subtitles to the cache
         * and publishes them — NOTHING else (v0.3.18). History: the
         * v0.3.7 form rebuilt the media item when a delay required
         * shifted files; v0.3.17 added a second rebuild for
         * URL-unguessable formats. Both rebuilds were the same
         * ambush — a setMediaItem + prepare seconds into playback
         * that re-buffered the video — and the 0.3.17 one still did
         * not save the owner's subtitles ("not working at all"),
         * because the break was never only the mime guess (see the
         * 0.3.18 build report). The sidecar pipeline makes arrival
         * rebuilds unnecessary in every case: picks read these
         * files, the delay is a render offset, and the media item
         * carries only the libass ASS configurations, attached at
         * first prepare.
         */
        private fun resolveAndPublishLocals(request: PlaybackRequest) {
            subtitleJob?.cancel()
            if (request.subtitles.isEmpty()) return
            subtitleJob =
                viewModelScope.launch {
                    val locals =
                        runCatching {
                            PlavioSubtitleFiles.resolve(
                                request.subtitles,
                                context.cacheDir,
                                request.headers,
                            )
                        }.getOrDefault(emptyList())
                    if (locals.isEmpty() || currentRequest != request) return@launch
                    _localSubtitles.value = locals
                }
        }

        /** Rebuilds the media item with the local (possibly shifted) subtitle files. */
        private suspend fun reattachSubtitles(request: PlaybackRequest) {
            val player = _player.value ?: return
            val position =
                withContext(Dispatchers.Main) { runCatching { player.currentPosition }.getOrDefault(0L) }
            val wasPlaying =
                withContext(Dispatchers.Main) { runCatching { player.isPlaying }.getOrDefault(true) }
            val mediaItem = buildMediaItem(request)
            withContext(Dispatchers.Main) {
                if (player is ExoPlayer && request.headers.isNotEmpty()) {
                    player.setMediaSource(buildMediaSource(mediaItem, request))
                } else {
                    player.setMediaItem(mediaItem)
                }
                player.prepare()
                if (position > 0) player.seekTo(position)
                if (wasPlaying) player.play()
            }
        }

        /**
         * Style rail delay control: persist the per-video delay and
         * re-shift the downloaded subtitles (a manual change always
         * wins over an in-progress Auto Sync pick — the panel clears
         * its cue list when it calls this).
         */
        fun setSubtitleDelay(delayMs: Long) {
            val request = currentRequest ?: return
            val clamped = delayMs.coerceIn(-60_000L, 60_000L)
            _subtitleDelayMs.value = clamped
            viewModelScope.launch {
                runCatching { subtitleStyleStore.setDelayMsFor(request.videoId, clamped) }
                if (sidecarKey != null) {
                    // Sidecar (v0.3.18): the delay is a render-loop
                    // lookup offset — no file rewrite, no rebuild.
                    // Resetting the signature makes the next tick
                    // re-push the cues for the shifted position.
                    lastSidecarSignature = null
                } else if (_localSubtitles.value.isNotEmpty()) {
                    // Media path (libass ASS): the shifted-file
                    // rebuild, as before — it is the only path that
                    // still carries side-loaded configurations.
                    reattachSubtitles(request)
                }
            }
        }

        /** Auto Sync > Reload: drop the cached downloads + shifted copies and re-resolve fresh. */
        fun reloadSubtitles() {
            val request = currentRequest ?: return
            _localSubtitles.value.forEach { local ->
                PlavioSubtitleFiles.invalidate(local, context.cacheDir)
            }
            _localSubtitles.value = emptyList()
            val sidecarSub = _sidecarSubtitle.value
            if (sidecarSub != null) {
                // Sidecar (v0.3.18): restart the pick against the
                // fresh download — the cache copy was just
                // invalidated, so the sidecar re-downloads, re-parses
                // and keeps rendering without touching the media.
                startSidecar(sidecarSub)
                return
            }
            viewModelScope.launch {
                // Media path: rebuild against the remote URLs first
                // so playback keeps its subtitles while the fresh
                // copies download.
                reattachSubtitles(request)
                resolveAndPublishLocals(request)
            }
        }

        /**
         * Auto Sync > Capture: the five cues of [local] nearest the
         * current playback position, translated into the unshifted
         * timeline (the panel computes the new delay from a tap as
         * captured − cueStart − 300ms, like the phone).
         */
        suspend fun captureCues(local: LocalSubtitle): List<Pair<Long, String>> {
            val player = _player.value ?: return emptyList()
            val position =
                withContext(Dispatchers.Main) { runCatching { player.currentPosition }.getOrDefault(0L) }
            val center = (position - _subtitleDelayMs.value).coerceAtLeast(0L)
            return withContext(Dispatchers.IO) {
                val cues = PlavioSubtitleFiles.parseCues(local.file)
                cues
                    .sortedBy { kotlin.math.abs(it.first - center) }
                    .take(5)
                    .sortedBy { it.first }
            }
        }

        /** Style rail / Settings edits: update the shared subtitle style store. */
        fun updateSubtitleStyle(transform: (SubtitleStyle) -> SubtitleStyle) {
            viewModelScope.launch {
                runCatching { subtitleStyleStore.update(transform) }
            }
        }

        /** Style rail: reset the subtitle style to the phone defaults. */
        fun resetSubtitleStyle() {
            viewModelScope.launch {
                runCatching { subtitleStyleStore.resetDefaults() }
            }
        }

        /** The playback position right now (Auto Sync captures the moment the line is heard). */
        fun currentPositionMs(): Long {
            val player = _player.value ?: return 0L
            return runCatching { player.currentPosition }.getOrDefault(0L)
        }

        // --------------------------------------------------------------
        // Next episode (autoplay + picker)
        // --------------------------------------------------------------

        /** The episode after the current one in the request's episode list, if any. */
        fun nextEpisode(request: PlaybackRequest): Video? {
            if (request.isMovie || request.isTrailer || request.isLive) return null
            val eps = request.episodes.sortedWith(compareBy({ it.season }, { it.episode }))
            val idx = eps.indexOfFirst { it.id == request.videoId }
            return if (idx >= 0) eps.getOrNull(idx + 1) else null
        }

        /**
         * Resolves [video]'s streams in the context of [current] and
         * builds the autoplay request (best stream), or null when the
         * addons offer nothing for it.
         */
        suspend fun resolveEpisode(
            current: PlaybackRequest,
            video: Video,
        ): PlaybackRequest? {
            val bundle =
                runCatching { repository.loadStreams(current.type, video.id, current.metaId) }
                    .getOrNull() ?: return null
            val best = repository.pickForAutoplay(bundle.streams) ?: return null
            val ref =
                StreamsRef(
                    type = current.type,
                    videoId = video.id,
                    metaId = current.metaId,
                    title = current.seriesName ?: current.title,
                    poster = video.thumbnail ?: current.poster,
                    season = video.season,
                    episode = video.episode,
                    episodeTitle = video.title,
                    seriesName = current.seriesName ?: current.title,
                )
            return buildPlaybackRequest(ref, bundle, best, current.episodes)
        }

        // --------------------------------------------------------------
        // Progress tracking (unchanged behaviour)
        // --------------------------------------------------------------

        private fun attachProgressTracking(
            player: Player,
            request: PlaybackRequest,
        ) {
            detachProgressTracking()
            if (request.isTrailer || request.isLive) return
            val listener =
                object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (!isPlaying) saveProgress(player, request)
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            viewModelScope.launch {
                                progressStore.remove(request.type, request.videoId)
                            }
                        }
                    }
                }
            progressListener = listener
            progressPlayer = player
            // v0.3.19: attach SYNCHRONOUSLY. start()'s publish
            // section already runs on Main; the old async hop could
            // land the add on a player that had already been torn
            // down, stranding the listener (and its closures over
            // the request) on a corpse.
            runCatching { player.addListener(listener) }
            progressJob =
                viewModelScope.launch {
                    while (isActive) {
                        delay(PROGRESS_INTERVAL_MS)
                        saveProgress(player, request)
                    }
                }
        }

        // --------------------------------------------------------------
        // Player clock (v0.3.18 — diagnosis cause #3)
        // --------------------------------------------------------------

        /**
         * Polls the live player at [CLOCK_INTERVAL_MS] and publishes
         * [PlayerClock] snapshots. The buffering flag keeps the old
         * in-composition ticker's rule: a position that advanced
         * since the last tick counts as playing even when the state
         * flag sticks at BUFFERING (the MediaTek decoder can hold
         * the flag while audio + position move), so the spinner
         * never spins over progressing playback.
         *
         * v0.3.21 (study fix #4): while the control layer is
         * un-composed ([controlsPresented] false — the screen
         * reports it), a position-only snapshot has no reader, so
         * publishing drops to state changes (buffering / playing /
         * duration) plus a coarse ~2 s cadence for pure position
         * drift (the skip-segment check reads the mirrored
         * position). The full 500 ms rate returns the moment the
         * controls show.
         */
        private fun startClock(player: Player) {
            clockJob?.cancel()
            clockJob =
                viewModelScope.launch {
                    var lastPosition = -1L
                    var lastPublished: PlayerClock? = null
                    var unpublishedTicks = 0
                    while (isActive) {
                        if (_player.value !== player) break
                        runCatching {
                            val position = player.currentPosition.coerceAtLeast(0)
                            val progressing = lastPosition >= 0 && position > lastPosition
                            val snapshot =
                                PlayerClock(
                                    positionMs = position,
                                    durationMs =
                                        player.duration.let {
                                            if (it == C.TIME_UNSET) 0L else it
                                        },
                                    bufferedMs = player.bufferedPosition.coerceAtLeast(0),
                                    isPlaying = player.isPlaying,
                                    buffering =
                                        if (progressing) {
                                            false
                                        } else {
                                            player.playbackState == Player.STATE_BUFFERING &&
                                                !player.isPlaying
                                        },
                                )
                            val stateChanged =
                                lastPublished == null ||
                                    snapshot.isPlaying != lastPublished.isPlaying ||
                                    snapshot.buffering != lastPublished.buffering ||
                                    snapshot.durationMs != lastPublished.durationMs
                            val due =
                                controlsPresented || stateChanged ||
                                    (
                                        unpublishedTicks >= HIDDEN_CLOCK_PUBLISH_TICKS &&
                                            snapshot != lastPublished
                                        )
                            if (due) {
                                _playerClock.value = snapshot
                                lastPublished = snapshot
                                unpublishedTicks = 0
                            } else {
                                unpublishedTicks++
                            }
                            lastPosition = position
                        }
                        delay(CLOCK_INTERVAL_MS)
                    }
                }
        }

        /** The player screen reports whether its control layer is presented (v0.3.21 — see [startClock]). */
        fun setControlsPresented(presented: Boolean) {
            controlsPresented = presented
        }

        private fun detachProgressTracking() {
            progressJob?.cancel()
            progressJob = null
            // v0.3.19: actually REMOVE the listener from the player
            // it was attached to (previously the field was nulled
            // and removal depended on each caller remembering to do
            // it — start()'s publish path did not).
            val listener = progressListener
            val attachedTo = progressPlayer
            progressListener = null
            progressPlayer = null
            if (listener != null && attachedTo != null) {
                runCatching { attachedTo.removeListener(listener) }
            }
        }

        private fun saveProgress(
            player: Player,
            request: PlaybackRequest,
        ) {
            viewModelScope.launch { saveProgressNow(player, request) }
        }

        private suspend fun saveProgressNow(
            player: Player,
            request: PlaybackRequest,
        ) {
            val position =
                withContext(Dispatchers.Main) {
                    runCatching { player.currentPosition }.getOrDefault(0L)
                }
            val duration =
                withContext(Dispatchers.Main) {
                    runCatching { player.duration }.getOrDefault(0L)
                }
            if (position > 0) {
                progressStore.record(
                    request = request,
                    positionMs = position,
                    durationMs = if (duration <= 0 || duration == C.TIME_UNSET) 0 else duration,
                )
            }
        }

        /**
         * Standby/background teardown (v0.3.21, study fix #5 —
         * replaces pauseForBackground): the app left the foreground
         * mid-play (Home button, app switch, TV standby). Snapshot
         * the play, then run the FULL [stop] — the player and its
         * libass handler die through the releasePlayerNow funnel
         * instead of idling warm in the background (the standby
         * case file: a full power-off "fixed" the session lag
         * because it was the only thing that ever tore the player
         * down; the 0.3.19 discipline now applies to backgrounding
         * too). The sound still dies on THIS call: stop() pauses
         * synchronously before anything else, so audio can never
         * keep playing after Home. stop() also records the
         * position to Continue Watching, as the old pause did.
         *
         * The snapshot is stored AFTER stop() returns — stop()
         * clears any stale snapshot as part of an explicit exit.
         * An errored start is NOT snapshotted: its error surface
         * stays exactly as it was.
         */
        fun teardownForStandby() {
            val request = currentRequest ?: return
            if (_creationError.value != null) return
            val player = _player.value
            val snapshot =
                StandbySnapshot(
                    request = request,
                    positionMs =
                        if (request.isLive || request.isTrailer) {
                            0L
                        } else {
                            runCatching { currentPositionMs() }.getOrDefault(0L)
                        },
                    wasPlaying =
                        player?.let {
                            runCatching { it.playWhenReady }.getOrDefault(true)
                        } ?: true,
                )
            stop()
            standbySnapshot = snapshot
        }

        /**
         * Counterpart to [teardownForStandby]: on return to the
         * foreground, re-open the snapshotted play through the same
         * [start] the Continue Watching row uses — the stored
         * request re-resolves (bounded) and a dead stored URL lands
         * on the streams picker via the resume-failed path, never a
         * visible error. A play that was paused lands paused at its
         * position; one that was playing plays. No snapshot — the
         * ordinary foreground return — is a no-op, and a player
         * that is somehow already alive is never double-started.
         */
        fun resumeFromStandby() {
            val snapshot = standbySnapshot ?: return
            standbySnapshot = null
            if (_player.value != null) return
            start(
                snapshot.request,
                snapshot.positionMs,
                startPaused = !snapshot.wasPlaying,
            )
        }

        /**
         * The one teardown order (v0.3.18, diagnosis cause #1 — the
         * reference player's dispose order): pause → stop → clear
         * media items → clear the video surface → release, all on
         * the application thread Media3 requires. Emptying the
         * pipeline BEFORE release() keeps release() short (Media3
         * 1.11's internal release wait is hard-capped at its 500 ms
         * release timeout besides) — on a full player the codec
         * teardown dominates that budget. Callers must already be
         * on Main (the factory gate and start()'s orphan releases
         * hop explicitly; releasePlayer/stop run there).
         *
         * v0.3.19 — this funnel is also the ONLY place a player and
         * its libass handler die, and it closes the per-play
         * accumulation the 0.3.18 field session exposed (movie 1
         * flawless → movie 2 total hang → movie 3 lag):
         *  - [handler] is the creation's [AssHandler], whose
         *    native libass instance player.release() does NOT
         *    free. Before 0.3.19 nothing ever called
         *    [AssHandler.release], so every libass play leaked its
         *    native handler (instance, renderer, parsed tracks)
         *    for the rest of the session.
         *  - [PlayerFactory.forgetPlayer] clears the factory's
         *    pairing FIRST, so the factory's straggler gate can
         *    never find this corpse and tear it down a second
         *    time — nor release a handler this funnel already
         *    released (a second native release is a double-free
         *    risk). Every teardown path is Main-serialized, so
         *    clearing the registries at funnel entry makes the
         *    teardown exactly-once.
         */
        private fun releasePlayerNow(
            player: Player,
            handler: AssHandler? = null,
        ) {
            playerFactory.forgetPlayer(player)
            runCatching { player.pause() }
            runCatching { player.stop() }
            runCatching { player.clearMediaItems() }
            (player as? ExoPlayer)?.let { exo ->
                runCatching { exo.clearVideoSurface() }
            }
            runCatching { player.release() }
                .onFailure { Timber.w(it, "Failed to release player") }
            handler?.let {
                runCatching { it.release() }
                    .onFailure { Timber.w(it, "Failed to release AssHandler") }
            }
        }

        // --------------------------------------------------------------
        // Sidecar subtitles (v0.3.18 — see PlavioSidecarSubtitles)
        // --------------------------------------------------------------

        /** True when this title's player was built with the libass engine. */
        fun playerUsesLibass(): Boolean = assHandler != null

        /**
         * Whether [sub] stays on the media path: it is ASS/SSA AND
         * this player runs libass AND the media item actually
         * carries it (its format was known — from the URL or the
         * content sniff — when the item was built).
         */
        private fun assOnMediaPath(sub: Subtitle): Boolean =
            assHandler != null &&
                (
                    subtitleMimeType(sub) == MimeTypes.TEXT_SSA ||
                        _localSubtitles.value.any {
                            it.sub.url == sub.url && it.mimeType == MimeTypes.TEXT_SSA
                        }
                    )

        /** Whether [sub] can be shown via the buffer-preserving sidecar. */
        fun sidecarEligible(sub: Subtitle): Boolean =
            PlavioSidecarSubtitles.canAttachViaSidecar(
                sub,
                keepAssOnMediaPath = assOnMediaPath(sub),
            )

        /**
         * Binds the PlayerView's SubtitleView (the sidecar's render
         * target). Called from the player view's factory/update and
         * with null when the view is released.
         */
        fun bindSubtitleView(view: SubtitleView?) {
            subtitleViewRef = view?.let { WeakReference(it) }
            if (view != null && sidecarKey != null && sidecarCues.isNotEmpty()) {
                renderSidecarCues()
            }
        }

        /**
         * The user's panel pick of an addon subtitle (v0.3.18): the
         * media text path goes OFF first (the reference's order),
         * then the sidecar downloads + parses + renders — the media
         * item is never reloaded, so the pick costs no re-buffer.
         */
        fun selectSidecarSubtitle(sub: Subtitle) {
            val player = _player.value ?: return
            if (!sidecarEligible(sub)) return
            runCatching {
                player.trackSelectionParameters =
                    player.trackSelectionParameters
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
            }
            startSidecar(sub)
        }

        /**
         * Whether picking [sub] must rebuild the player with libass
         * (v0.3.21, study fix #1): the pick is ASS/SSA by its URL
         * hint, the user's ASS engine preference is libass, this
         * play's player was NOT built with libass (start() builds
         * it on pick only now), and the play is not in safe mode
         * (whose factory configuration disables libass outright).
         */
        fun needsLibassForPick(sub: Subtitle): Boolean =
            assHandler == null &&
                !safeModeActive &&
                assLibassEnabled &&
                subtitleMimeType(sub) == MimeTypes.TEXT_SSA

        /**
         * Rebuilds the current play with a libass player so the
         * picked ASS/SSA subtitle renders styled (v0.3.21, study
         * fix #1) — the safe-mode rebuild's exact shape: same
         * request, given position, new player; the old player and
         * any libass handler die through the releasePlayerNow
         * funnel inside the new start, exactly once. The pick
         * stays pending in [pendingLibassSubtitle]; the panel
         * applies its media track when the rebuilt player's
         * tracks land. The picked subtitle's already-resolved
         * local file rides along so the new media item carries
         * the content-sniffed file, not just the URL hint.
         */
        fun rebuildWithLibassFor(
            sub: Subtitle,
            positionMs: Long,
        ) {
            val request = currentRequest ?: return
            stopSidecar()
            libassRebuild =
                LibassRebuild(
                    sub = sub,
                    local = _localSubtitles.value.firstOrNull { it.sub.url == sub.url },
                )
            _pendingLibassSubtitle.value = sub
            currentUrl = null
            start(request, positionMs)
        }

        /** The panel has applied (or abandoned) the pending libass pick. */
        fun clearPendingLibassSubtitle() {
            _pendingLibassSubtitle.value = null
        }

        /** Stops the sidecar and clears its cues from the view. */
        fun stopSidecar(clearView: Boolean = true) {
            sidecarJob?.cancel()
            sidecarJob = null
            sidecarKey = null
            sidecarGeneration = 0L
            sidecarCues = emptyList()
            lastSidecarSignature = null
            _sidecarSubtitle.value = null
            if (clearView) {
                subtitleViewRef?.get()?.let { view ->
                    view.post { runCatching { view.setCues(emptyList()) } }
                }
            }
        }

        private fun startSidecar(sub: Subtitle) {
            sidecarJob?.cancel()
            val generation = ++sidecarCounter
            sidecarGeneration = generation
            sidecarKey = sub.url
            _sidecarSubtitle.value = sub
            sidecarCues = emptyList()
            lastSidecarSignature = null
            postToSubtitleView(generation, sub.url) { it.setCues(emptyList()) }
            fun isCurrent() = sidecarKey == sub.url && sidecarGeneration == generation
            sidecarJob =
                viewModelScope.launch {
                    try {
                        val locals =
                            runCatching {
                                PlavioSubtitleFiles.resolve(
                                    listOf(sub),
                                    context.cacheDir,
                                    currentRequest?.headers ?: emptyMap(),
                                )
                            }.getOrDefault(emptyList())
                        if (!isCurrent()) return@launch
                        val local = locals.firstOrNull { it.sub.url == sub.url }
                        if (local != null &&
                            _localSubtitles.value.none { it.sub.url == sub.url }
                        ) {
                            _localSubtitles.value = _localSubtitles.value + local
                        }
                        val body =
                            local?.let { lc ->
                                withContext(Dispatchers.IO) {
                                    runCatching { lc.file.readText(Charsets.UTF_8) }
                                        .getOrNull()
                                }
                            } ?: runCatching { downloadSubtitleBody(sub) }.getOrNull()
                        if (!isCurrent()) return@launch
                        if (body == null) {
                            Timber.w("Sidecar subtitle download failed for %s", sub.url.take(80))
                            deactivateSidecar(generation)
                            return@launch
                        }
                        val result =
                            withContext(Dispatchers.Default) {
                                PlavioSidecarSubtitles.parseTimedCuesRobust(body, sub.url)
                            }
                        if (!isCurrent()) return@launch
                        if (result.effectiveMime == MimeTypes.TEXT_SSA &&
                            assHandler == null && !safeModeActive && assLibassEnabled
                        ) {
                            // v0.3.21 (study fix #1): the URL hint
                            // said nothing, but the content sniff
                            // proves this pick is ASS/SSA and the
                            // user's engine for it is libass —
                            // rebuild with libass so it renders
                            // styled instead of as plain sidecar
                            // cues. The resolved local rides along
                            // (see rebuildWithLibassFor), so the new
                            // media item carries the sniffed file.
                            val position =
                                runCatching { _player.value?.currentPosition }
                                    .getOrNull() ?: 0L
                            rebuildWithLibassFor(sub, position)
                            return@launch
                        }
                        if (result.cues.isEmpty()) {
                            // Stay off the media path — a subtitle
                            // that cannot be parsed deactivates
                            // quietly and NEVER falls back to a media
                            // reload (the reference's rule; the
                            // reload was the re-buffer ambush).
                            Timber.w(
                                "Sidecar subtitle parse empty for %s (buffer preserved)",
                                sub.url.take(80),
                            )
                            deactivateSidecar(generation)
                            return@launch
                        }
                        sidecarCues = result.cues
                        Timber.i(
                            "Sidecar subtitle ready: %d cues, mime=%s, via %s",
                            result.cues.size,
                            result.effectiveMime,
                            result.source,
                        )
                        while (isActive && isCurrent()) {
                            renderSidecarCues()
                            delay(PlavioSidecarSubtitles.RENDER_INTERVAL_MS)
                        }
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Timber.w(e, "Sidecar subtitle failed (buffer preserved)")
                        if (isCurrent()) deactivateSidecar(generation)
                    }
                }
        }

        /** A sidecar that failed to load: state cleared, view cleared, playback untouched. */
        private fun deactivateSidecar(generation: Long) {
            if (sidecarGeneration != generation) return
            sidecarKey = null
            sidecarGeneration = 0L
            sidecarCues = emptyList()
            lastSidecarSignature = null
            _sidecarSubtitle.value = null
            subtitleViewRef?.get()?.let { view ->
                view.post { runCatching { view.setCues(emptyList()) } }
            }
        }

        /**
         * Pushes the cues active at the playhead into the bound
         * SubtitleView. The delay applies HERE, as a lookup offset
         * (the reference's shape): a positive delay looks cues up
         * earlier, so they appear later — no file rewrite, no
         * reload, and a delay change takes effect on the next tick.
         */
        private fun renderSidecarCues() {
            val cues = sidecarCues
            if (cues.isEmpty() || sidecarKey == null) return
            val player = _player.value ?: return
            val positionUs =
                (
                    runCatching { player.currentPosition }
                        .getOrDefault(0L)
                        .coerceAtLeast(0L) * 1_000L -
                        _subtitleDelayMs.value * 1_000L
                    ).coerceAtLeast(0L)
            val active = PlavioSidecarSubtitles.collectActiveCues(cues, positionUs)
            val signature = PlavioSidecarSubtitles.activeCueSignature(active)
            if (signature == lastSidecarSignature) return
            lastSidecarSignature = signature
            val merged = PlavioSidecarSubtitles.mergeOverlappingCues(active)
            val key = sidecarKey ?: return
            val generation = sidecarGeneration
            postToSubtitleView(generation, key) { view -> view.setCues(merged) }
        }

        /**
         * Runs [block] on the bound SubtitleView, guarded by the
         * sidecar generation: a runnable posted by a superseded
         * pick (or racing a stop) finds the key/generation moved on
         * and does nothing.
         */
        private fun postToSubtitleView(
            generation: Long,
            key: String?,
            block: (SubtitleView) -> Unit,
        ) {
            val view = subtitleViewRef?.get() ?: return
            view.post {
                if (sidecarGeneration == generation && sidecarKey == key) {
                    subtitleViewRef?.get()?.let { runCatching { block(it) } }
                }
            }
        }

        /**
         * Direct subtitle download for when the cache resolve
         * dropped the file (its content sniff recognizes SRT/VTT/
         * ASS/TTML; an exotic file can still be perfectly parseable
         * by the sidecar's candidate sweep, so a dropped download
         * must not end the pick). Same client discipline as the
         * stream client: the stream's own headers ride along.
         */
        private suspend fun downloadSubtitleBody(sub: Subtitle): String? =
            withContext(Dispatchers.IO) {
                val request =
                    okhttp3.Request
                        .Builder()
                        .url(sub.url)
                        .apply {
                            (currentRequest?.headers ?: emptyMap()).forEach { (k, v) ->
                                header(k, v)
                            }
                        }.get()
                        .build()
                STREAM_HTTP_CLIENT.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null
                    val body = response.body ?: return@withContext null
                    if (body.contentLength() > 4 * 1024 * 1024) return@withContext null
                    body.string().takeIf { it.isNotBlank() }
                }
            }

        private suspend fun releasePlayer() {
            // Never cancel the watchdog job from inside the watchdog
            // itself: its first act used to be watchdogJob.cancel(),
            // and when the CALLER was the watchdog coroutine that marked
            // the running job cancelled — the withContext(Main) below
            // then threw CancellationException before release() ran, so
            // the player kept playing audio with no surface while the
            // screen fell back to the bare loading spinner (the v0.3.5
            // "sound but spinner forever" hang). Other callers (start /
            // stop) still cancel a pending watchdog as before.
            if (watchdogJob !== currentCoroutineContext()[Job]) {
                watchdogJob?.cancel()
            }
            watchdogJob = null
            // Same self-cancel guard for the video watchdog: it can be
            // the caller here (its no-switch path releases the player).
            if (videoWatchdogJob !== currentCoroutineContext()[Job]) {
                videoWatchdogJob?.cancel()
            }
            videoWatchdogJob = null
            // v0.3.18: the clock and the sidecar belong to the player
            // going away — stop both before the teardown.
            clockJob?.cancel()
            clockJob = null
            stopSidecar()
            val existing = _player.value ?: return
            // Sound dies FIRST (owner rule 2026-11-04): on zap / next
            // episode / failover the old player's audio must stop on
            // this call, not after the listener teardown below queues
            // behind a busy main thread.
            runCatching { existing.pause() }
            _player.value = null
            // v0.3.19: capture the handler for the teardown — the
            // field is nulled here (the publish path reassigns it),
            // but the native instance must be RELEASED, not just
            // dropped (that drop was the per-play libass leak).
            val handler = assHandler
            assHandler = null
            val listener = progressListener
            detachProgressTracking()
            detachDecoderLogging(existing)
            val frameListener = watchdogListener
            watchdogListener = null
            withContext(Dispatchers.Main) {
                if (listener != null) {
                    runCatching { existing.removeListener(listener) }
                }
                if (frameListener != null) {
                    runCatching { existing.removeListener(frameListener) }
                }
                // v0.3.16: release() itself runs HERE, on Main — see
                // the note below. v0.3.18: it runs through
                // releasePlayerNow, which empties the pipeline
                // first (the teardown order above). v0.3.19: the
                // funnel also frees the libass handler and clears
                // the factory pairing.
                releasePlayerNow(existing, handler)
            }
            // v0.3.16 — the v0.3.10 "lag fix" is REVERTED: its core
            // assumption ("Media3 release is callable from any
            // thread") is false on the bundled Media3 1.11.1 —
            // ExoPlayerImpl.release() calls
            // verifyApplicationThread() and THROWS off the main
            // thread (bytecode-verified). The Default-thread launch
            // below threw inside runCatching on every single call:
            // the player was never actually released here, the codec
            // stayed held, and only the factory guard's own release
            // saved the next start — until v0.3.15 moved that guard
            // off Main too, at which point nothing released anything
            // and starts began surfacing the wrong-thread error
            // (the owner's photo). Release now runs inside the
            // withContext(Main) above, together with the listener
            // detachment: stable v0.3.10's exact arrangement, whose
            // playback the owner calls flawless. The caller-blocking
            // cost is the price stable paid too; pause-first above
            // still kills the sound on the call itself.
        }

        override fun onCleared() {
            progressJob?.cancel()
            progressJob = null
            subtitleJob?.cancel()
            clockJob?.cancel()
            clockJob = null
            skipSegmentsJob?.cancel()
            skipSegmentsJob = null
            stopSidecar(clearView = false)
            _player.value?.let { player ->
                // v0.3.19: the handler dies with the player here
                // too — onCleared used to drop it unreleased.
                releasePlayerNow(player, assHandler)
            }
            _player.value = null
            assHandler = null
        }

        private fun buildMediaItem(request: PlaybackRequest): MediaItem {
            val locals = _localSubtitles.value
            val delayMs = _subtitleDelayMs.value
            // v0.3.18 (the subtitle fix): addon subtitles do NOT ride
            // the media item any more — the sidecar renders them
            // (see PlavioSidecarSubtitles), because a media-item
            // track is where they died: its format was guessed from
            // the URL (null for extension-less addon URLs = a track
            // that lists but can never cue), and the only way to
            // attach or fix one mid-play was a buffer-wiping reload.
            // The ONE media-path remainder is ASS/SSA on a libass
            // player, whose styling only the libass renderer
            // produces; those configurations attach HERE, at first
            // prepare, preferring the content-sniffed local files.
            // And NO configuration carries SELECTION_FLAG_DEFAULT:
            // subtitles are off by default (owner's order) — the old
            // first-track DEFAULT flag auto-selected a subtitle on
            // every play.
            val mediaPathSubs =
                if (assHandler != null) {
                    request.subtitles.filter { sub ->
                        subtitleMimeType(sub) == MimeTypes.TEXT_SSA ||
                            locals.any {
                                it.sub.url == sub.url && it.mimeType == MimeTypes.TEXT_SSA
                            }
                    }
                } else {
                    emptyList()
                }
            val subtitleConfigurations =
                mediaPathSubs.map { sub ->
                    val index = request.subtitles.indexOf(sub)
                    val local = locals.firstOrNull { it.sub.url == sub.url }
                    if (local != null) {
                        val file =
                            if (delayMs != 0L) {
                                PlavioSubtitleFiles.shiftedFile(local.file, delayMs, context.cacheDir)
                            } else {
                                local.file
                            }
                        MediaItem.SubtitleConfiguration
                            .Builder(android.net.Uri.fromFile(file))
                            .setId("e:$index")
                            .setMimeType(local.mimeType)
                            .setLanguage(sub.lang)
                            .setLabel(sub.lang)
                            .build()
                    } else {
                        MediaItem.SubtitleConfiguration
                            .Builder(sub.url.toUri())
                            .setId("e:$index")
                            .setMimeType(subtitleMimeType(sub))
                            .setLanguage(sub.lang)
                            .setLabel(sub.lang)
                            .build()
                    }
                }
            return MediaItem
                .Builder()
                .setMediaId(request.videoId)
                .setUri(request.streamUrl)
                .setMediaMetadata(
                    MediaMetadata
                        .Builder()
                        .setTitle(request.title)
                        .apply { request.poster?.let { setArtworkUri(it.toUri()) } }
                        .build(),
                ).setSubtitleConfigurations(subtitleConfigurations)
                .apply { containerMimeType(request)?.let { setMimeType(it) } }
                .build()
        }

        /**
         * Media source carrying the addon's required request headers. The
         * factory mirrors [PlayerFactory]'s own media source construction
         * (constant-bitrate seeking extractors, ASS support when the player
         * was created with a libass handler), swapping the data source for
         * an OkHttp one that sends the headers.
         */
        private fun buildMediaSource(
            mediaItem: MediaItem,
            request: PlaybackRequest,
        ): MediaSource {
            val httpFactory =
                OkHttpDataSource
                    .Factory(STREAM_HTTP_CLIENT)
                    .setDefaultRequestProperties(request.headers)
            val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)
            val extractorsFactory =
                DefaultExtractorsFactory()
                    .setConstantBitrateSeekingEnabled(true)
                    .setConstantBitrateSeekingAlwaysEnabled(true)
            val handler = assHandler
            return if (handler != null) {
                val assSubtitleParserFactory = AssSubtitleParserFactory(handler)
                DefaultMediaSourceFactory(
                    dataSourceFactory,
                    extractorsFactory.withAssMkvSupport(assSubtitleParserFactory, handler),
                ).setSubtitleParserFactory(assSubtitleParserFactory)
                    .createMediaSource(mediaItem)
            } else {
                DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)
                    .createMediaSource(mediaItem)
            }
        }

        private fun subtitleMimeType(subtitle: Subtitle): String? {
            val path = subtitle.url.substringBefore('?').lowercase()
            return when {
                path.endsWith(".vtt") -> MimeTypes.TEXT_VTT
                path.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
                path.endsWith(".ass") || path.endsWith(".ssa") -> MimeTypes.TEXT_SSA
                path.endsWith(".ttml") || path.endsWith(".dfxp") || path.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
                else -> null
            }
        }

        /**
         * The sniff's public face: the cached type for this URL when
         * a previous start already proved it, else one bounded probe.
         * Null means "still unknown" — playback proceeds exactly as
         * before (progressive inference), so a failed or refused
         * probe never makes a stream LESS playable.
         */
        private suspend fun probeContainerMime(request: PlaybackRequest): String? {
            probedMimeTypes[request.streamUrl]?.let { return it }
            val probed =
                kotlinx.coroutines.withTimeoutOrNull(PROBE_TIMEOUT_MS) {
                    runCatching { sniffContainerMime(request) }
                        .onFailure { Timber.v(it, "Container sniff failed") }
                        .getOrNull()
                } ?: return null
            if (probedMimeTypes.size > 64) probedMimeTypes.clear()
            probedMimeTypes[request.streamUrl] = probed
            Timber.i("Container sniff: %s -> %s", request.streamUrl.take(80), probed)
            return probed
        }

        /**
         * One bounded GET (the stream's own headers, Range-capped)
         * classified by Content-Type first, then by magic bytes:
         * `#EXTM3U` → HLS, an MPD document → DASH. Anything else
         * (MP4 ftyp, Matroska EBML, …) stays untyped on purpose —
         * the progressive extractor chain resolves those correctly;
         * only the playlist formats MUST be typed, because Media3
         * never infers them from a suffix-less URL.
         */
        private suspend fun sniffContainerMime(request: PlaybackRequest): String? =
            withContext(Dispatchers.IO) {
                val httpRequest =
                    okhttp3.Request
                        .Builder()
                        .url(request.streamUrl)
                        .header("Range", "bytes=0-4095")
                        .apply {
                            request.headers.forEach { (name, value) -> header(name, value) }
                        }.build()
                STREAM_HTTP_CLIENT.newCall(httpRequest).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null
                    val contentType = response.header("Content-Type")?.lowercase().orEmpty()
                    when {
                        contentType.contains("mpegurl") -> return@withContext MimeTypes.APPLICATION_M3U8
                        contentType.contains("dash+xml") -> return@withContext MimeTypes.APPLICATION_MPD
                    }
                    val body = response.body ?: return@withContext null
                    val buffer = okio.Buffer()
                    var remaining = 4096L
                    while (remaining > 0) {
                        val read = body.source().read(buffer, remaining)
                        if (read == -1L) break
                        remaining -= read
                    }
                    val text =
                        String(buffer.readByteArray(), Charsets.UTF_8)
                            .trimStart('\uFEFF', ' ', '\n', '\r', '\t')
                    when {
                        text.startsWith("#EXTM3U") -> MimeTypes.APPLICATION_M3U8
                        text.startsWith("<MPD") ||
                            (text.startsWith("<?xml") && text.contains("<MPD")) ->
                            MimeTypes.APPLICATION_MPD
                        else -> null
                    }
                }
            }

        private fun containerMimeType(request: PlaybackRequest): String? {
            val url = request.streamUrl.lowercase()
            return when {
                url.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
                url.contains(".mpd") -> MimeTypes.APPLICATION_MPD
                request.mimeType?.contains("mpegurl", ignoreCase = true) == true -> MimeTypes.APPLICATION_M3U8
                request.mimeType?.contains("dash+xml", ignoreCase = true) == true -> MimeTypes.APPLICATION_MPD
                else -> null
            }
        }

        private fun String.toUri(): android.net.Uri = android.net.Uri.parse(this)

        private companion object {
            /**
             * How often playback progress is written while playing.
             * v0.3.18: 10s → 90s, the reference player's cadence —
             * the periodic write is a disk hit on a weak box and
             * resume exactness does not depend on it: saves also fire
             * on pause, on ENDED and on stop()/background, which are
             * the moments a resume actually reads.
             */
            const val PROGRESS_INTERVAL_MS = 90_000L

            /** Player-clock poll interval (v0.3.18 — see startClock). */
            const val CLOCK_INTERVAL_MS = 500L

            /**
             * While the control layer is hidden, pure-position clock
             * snapshots publish at most every this many ticks
             * (v0.3.21, study fix #4 — 4 × 500 ms ≈ 2 s; state
             * changes always publish at once).
             */
            const val HIDDEN_CLOCK_PUBLISH_TICKS = 4

            /**
             * How long ExoPlayer gets to produce its first frame before
             * the watchdog fails the start into the error surface.
             * (Owner's orders 2026-11-04: "at least 10s", then "do like
             * Nuvio" — Nuvio-level patience, 30s. The failover itself
             * stays Plavio's: automatic switch to the next source,
             * never asking the user mid-play.)
             */
            const val FIRST_FRAME_WATCHDOG_MS = 30_000L

            /**
             * Early dead-link check inside the first-frame watchdog
             * (v0.3.22): at this point a start with zero bytes
             * buffered is failed over immediately; a start with data
             * flowing keeps the full [FIRST_FRAME_WATCHDOG_MS].
             * v0.3.16 (owner: "give some time to source to play,
             * don't skip too fast"): 15s → 25s. A slow-but-alive
             * host with zero buffered at 15s was being declared dead
             * and hopped away from mid-handshake; at 25s a source
             * gets nearly the whole watchdog window to produce its
             * first byte before the dead-link verdict, and a truly
             * dead link still fails inside the same 30s envelope.
             */
            const val FIRST_FRAME_EARLY_CHECK_MS = 25_000L

            /**
             * How long the whole start phase (preferences + player
             * creation, before the first-frame watchdog can arm) may
             * take before the start is failed into the error surface.
             * v0.3.16: 20s → 30s, the same patience restoration — the
             * start phase now also covers the in-player autoplay
             * resolution (note 9) and the restored on-Main release
             * gate, and a healthy-but-slow phase must not error.
             */
            const val START_PHASE_TIMEOUT_MS = 30_000L

            /**
             * Longest the in-player autoplay resolution (v0.3.16,
             * note 9: a Play press opens the player immediately and
             * the source finding happens inside it) may run before
             * the start falls back to the sources picker — the same
             * full fan-out the detail page used to wait on, now
             * bounded in the player instead.
             */
            const val AUTOPLAY_RESOLVE_TIMEOUT_MS = 30_000L

            /** Longest the container sniff may delay a start (v0.3.13). */
            const val PROBE_TIMEOUT_MS = 4_000L

            /** Audio-but-black watchdog (v0.3.12): first check delay + interval. */
            const val VIDEO_WATCHDOG_FIRST_CHECK_MS = 9_000L
            const val VIDEO_WATCHDOG_INTERVAL_MS = 8_000L

            /**
             * The video-track watchdog's whole working window
             * (v0.3.21, study fix #4): it exists for early-play
             * failures and disarms this long after the play starts
             * instead of polling to the end of the play.
             */
            const val VIDEO_WATCHDOG_WINDOW_MS = 60_000L

            /**
             * Longest the resume re-resolution may delay player
             * creation before the stored stream plays as-is (v0.3.2).
             */
            const val RESUME_RESOLVE_TIMEOUT_MS = 6_000L

            /**
             * Shared HTTP client for header-carrying streams (v0.3.2):
             * one client = connection reuse across plays, instead of a
             * fresh DNS + TLS handshake from a new client every time.
             * Explicit timeouts (v0.3.9; OkHttp stock was 10 s/10 s):
             * connect 5 s so dead hosts fail fast, read 20 s — a
             * per-byte-gap limit, so slow-but-alive hosts stay safe.
             */
            val STREAM_HTTP_CLIENT: OkHttpClient by lazy {
                OkHttpClient
                    .Builder()
                    .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                    .build()
            }
        }
    }
