package com.github.damontecres.wholphin.plavio

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.github.damontecres.wholphin.plavio.ui.PlavioAccent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject
import javax.inject.Singleton

private val Context.plavioUiDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "plavio_ui")

/**
 * Plavio TV's own small preferences: the Onyx accent and the update
 * checker's switches. Kept apart from the proto AppPreferences (which
 * still carries the player/subtitle settings) in the same Preferences
 * DataStore style [AddonStore] uses.
 */
@Singleton
class PlavioUiPrefs
    @Inject
    constructor(
        @param:ApplicationContext private val context: Context,
    ) {
        private val dataStore = context.plavioUiDataStore
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + CrashReports.backgroundScopeHandler)

        val accent: StateFlow<PlavioAccent> =
            dataStore.data
                .map { PlavioAccent.byName(it[KEY_ACCENT]) }
                .stateIn(scope, SharingStarted.Eagerly, PlavioAccent.WHITE)

        val autoUpdateCheck: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTO_UPDATE] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /** Watch Now auto-plays the best stream (phone parity); off = open the picker. */
        val autoplayBestStream: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTOPLAY_BEST] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /** Auto-play the next episode when one ends (phone parity, default on). */
        val autoPlayNextEpisode: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_AUTOPLAY_NEXT] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        /**
         * Preferred subtitle languages (up to 2, phone Settings
         * semantics): the player auto-selects the first matching
         * subtitle track when playback starts.
         */
        val subtitleLanguages: StateFlow<List<String>> =
            dataStore.data
                .map {
                    it[KEY_SUBTITLE_LANGUAGES]
                        ?.split(",")
                        ?.map { code -> code.trim() }
                        ?.filter { code -> code.isNotEmpty() }
                        ?.take(2)
                        ?: emptyList()
                }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        /** Preferred audio language (ISO 639-1) for first-track auto-pick, or null. */
        val preferredAudioLanguage: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PREFERRED_AUDIO_LANGUAGE] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        /** Show the Skip intro/recap/outro button when IntroDB knows the window (phone parity, default on). */
        val showSkipIntro: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_SHOW_SKIP_INTRO] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setSubtitleLanguages(languages: List<String>) {
            val cleaned = languages.map { it.trim() }.filter { it.isNotEmpty() }.take(2)
            dataStore.edit {
                if (cleaned.isEmpty()) {
                    it.remove(KEY_SUBTITLE_LANGUAGES)
                } else {
                    it[KEY_SUBTITLE_LANGUAGES] = cleaned.joinToString(",")
                }
            }
        }

        suspend fun setPreferredAudioLanguage(language: String?) {
            dataStore.edit {
                if (language.isNullOrBlank()) {
                    it.remove(KEY_PREFERRED_AUDIO_LANGUAGE)
                } else {
                    it[KEY_PREFERRED_AUDIO_LANGUAGE] = language.trim()
                }
            }
        }

        suspend fun setAccent(accent: PlavioAccent) {
            dataStore.edit { it[KEY_ACCENT] = accent.name }
        }

        suspend fun setAutoplayBestStream(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTOPLAY_BEST] = enabled }
        }

        suspend fun setAutoPlayNextEpisode(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTOPLAY_NEXT] = enabled }
        }

        suspend fun setAutoUpdateCheck(enabled: Boolean) {
            dataStore.edit { it[KEY_AUTO_UPDATE] = enabled }
        }

        suspend fun setShowSkipIntro(enabled: Boolean) {
            dataStore.edit { it[KEY_SHOW_SKIP_INTRO] = enabled }
        }


        // ---- v0.2.2 parity batch ----

        /** Debrid API keys (Integrations; phone parity — same services, plain storage). */
        val torboxApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_TORBOX_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val realDebridApiKey: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_REALDEBRID_API_KEY]?.takeIf { key -> key.isNotBlank() } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setTorboxApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_TORBOX_API_KEY) else it[KEY_TORBOX_API_KEY] = cleaned
            }
        }

        suspend fun setRealDebridApiKey(key: String?) {
            dataStore.edit {
                val cleaned = key?.trim().orEmpty()
                if (cleaned.isEmpty()) it.remove(KEY_REALDEBRID_API_KEY) else it[KEY_REALDEBRID_API_KEY] = cleaned
            }
        }

        /** Streams rules: quality sort priority, top = highest priority. */
        val qualityOrder: StateFlow<List<String>> =
            dataStore.data
                .map { prefs ->
                    val saved =
                        prefs[KEY_QUALITY_ORDER]
                            ?.split(",")
                            ?.map { it.trim() }
                            ?.filter { it in QUALITY_ORDER_OPTIONS }
                            ?: emptyList()
                    if (saved.isEmpty()) QUALITY_ORDER_OPTIONS else saved
                }.stateIn(scope, SharingStarted.Eagerly, QUALITY_ORDER_OPTIONS)

        suspend fun setQualityOrder(order: List<String>) {
            val cleaned = order.filter { it in QUALITY_ORDER_OPTIONS }
            dataStore.edit {
                if (cleaned.isEmpty()) {
                    it.remove(KEY_QUALITY_ORDER)
                } else {
                    it[KEY_QUALITY_ORDER] = cleaned.joinToString(",")
                }
            }
        }

        /** Streams rules: autoplay picks by the quality + size rule. */
        val streamAutoplay: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_STREAM_AUTOPLAY] ?: false }
                .stateIn(scope, SharingStarted.Eagerly, false)

        suspend fun setStreamAutoplay(enabled: Boolean) {
            dataStore.edit { it[KEY_STREAM_AUTOPLAY] = enabled }
        }

        val autoplayQuality: StateFlow<String> =
            dataStore.data
                .map { prefs ->
                    (prefs[KEY_AUTOPLAY_QUALITY] ?: "Auto")
                        .takeIf { it == "Auto" || it in QUALITY_ORDER_OPTIONS } ?: "Auto"
                }.stateIn(scope, SharingStarted.Eagerly, "Auto")

        suspend fun setAutoplayQuality(value: String) {
            dataStore.edit {
                it[KEY_AUTOPLAY_QUALITY] =
                    if (value == "Auto" || value in QUALITY_ORDER_OPTIONS) value else "Auto"
            }
        }

        /** Home arrangement: addon ids in the user's row order (empty = natural order). */
        val homeAddonOrder: StateFlow<List<String>> =
            dataStore.data
                .map { prefs ->
                    prefs[KEY_HOME_ADDON_ORDER]
                        ?.split(",")
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?: emptyList()
                }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        suspend fun setHomeAddonOrder(ids: List<String>) {
            dataStore.edit {
                if (ids.isEmpty()) {
                    it.remove(KEY_HOME_ADDON_ORDER)
                } else {
                    it[KEY_HOME_ADDON_ORDER] = ids.joinToString(",")
                }
            }
        }

        /** Home arrangement: addons whose catalog rows are hidden from Home. */
        val homeHiddenAddons: StateFlow<Set<String>> =
            dataStore.data
                .map { prefs ->
                    prefs[KEY_HOME_HIDDEN_ADDONS]
                        ?.split(",")
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        ?.toSet()
                        ?: emptySet()
                }.stateIn(scope, SharingStarted.Eagerly, emptySet())

        suspend fun setHomeHiddenAddons(ids: Set<String>) {
            dataStore.edit {
                if (ids.isEmpty()) {
                    it.remove(KEY_HOME_HIDDEN_ADDONS)
                } else {
                    it[KEY_HOME_HIDDEN_ADDONS] = ids.joinToString(",")
                }
            }
        }

        /**
         * The user's chosen default catalog addon (v0.3.16, note 6):
         * the addon id picked in the Addons screen when two or more
         * catalog-providing addons are installed. Null = no choice
         * (the historic behaviour: the first meta addon wins). The
         * repository consults it wherever the app used to hard-pick
         * the first/PMeta addon as the default catalog source.
         */
        val defaultCatalogAddonId: StateFlow<String?> =
            dataStore.data
                .map { prefs -> prefs[KEY_DEFAULT_CATALOG_ADDON] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setDefaultCatalogAddonId(id: String?) {
            dataStore.edit {
                if (id.isNullOrBlank()) {
                    it.remove(KEY_DEFAULT_CATALOG_ADDON)
                } else {
                    it[KEY_DEFAULT_CATALOG_ADDON] = id
                }
            }
        }

        /** New-episode alerts for shows in Continue Watching (phone parity, default on). */
        val episodeAlertsEnabled: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_EPISODE_ALERTS] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setEpisodeAlertsEnabled(enabled: Boolean) {
            dataStore.edit { it[KEY_EPISODE_ALERTS] = enabled }
        }

        /** One-shot read of the episode-alerts toggle (app-start scheduling). */
        suspend fun episodeAlertsEnabledOnce(): Boolean =
            dataStore.data.first()[KEY_EPISODE_ALERTS] ?: true

        // ---- Stream badge styles (v0.3.0; phone parity) ----

        /**
         * How stream-card facts render: "GROUPED" (default, tinted-glass
         * capsules) / "ELITE" / "NARD" / "GOLD" / "MINIMALIST" (bundled
         * badge-pack artwork). Stored as the BadgeStyle enum name.
         */
        val badgeStyle: StateFlow<String> =
            dataStore.data
                .map { it[KEY_BADGE_STYLE] ?: "GROUPED" }
                .stateIn(scope, SharingStarted.Eagerly, "GROUPED")

        suspend fun setBadgeStyle(style: String) {
            dataStore.edit { it[KEY_BADGE_STYLE] = style }
        }

        /** Badge group visibility — one switch per fact family, all default ON. */
        val badgeGroupResolution: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_RESOLUTION] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupResolution(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_RESOLUTION] = enabled }
        }

        val badgeGroupHdr: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_HDR] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupHdr(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_HDR] = enabled }
        }

        val badgeGroupAudio: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_AUDIO] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupAudio(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_AUDIO] = enabled }
        }

        val badgeGroupLanguages: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_LANGUAGES] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupLanguages(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_LANGUAGES] = enabled }
        }

        val badgeGroupSourceCodec: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_SOURCE_CODEC] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupSourceCodec(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_SOURCE_CODEC] = enabled }
        }

        val badgeGroupSize: StateFlow<Boolean> =
            dataStore.data
                .map { it[KEY_BADGE_GROUP_SIZE] ?: true }
                .stateIn(scope, SharingStarted.Eagerly, true)

        suspend fun setBadgeGroupSize(enabled: Boolean) {
            dataStore.edit { it[KEY_BADGE_GROUP_SIZE] = enabled }
        }

        // Profile identity for the Account screen + capsule avatar
        // (v0.3.21): display name and @username are local, editable on
        // the Account page; the photo rides the account backup's
        // profilePhoto field (the phone's format) so it syncs.
        val profileName: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_NAME] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        val profileUsername: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_USERNAME] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        /** Base64 JPEG of the profile photo, or null for the initial-letter avatar. */
        val profilePhotoBase64: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_PROFILE_PHOTO] }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setProfileName(value: String?) {
            dataStore.edit { prefs ->
                val cleaned = value?.trim().orEmpty()
                if (cleaned.isBlank()) prefs.remove(KEY_PROFILE_NAME) else prefs[KEY_PROFILE_NAME] = cleaned
            }
        }

        suspend fun setProfileUsername(value: String?) {
            dataStore.edit { prefs ->
                val cleaned = value?.trim()?.removePrefix("@").orEmpty()
                if (cleaned.isBlank()) prefs.remove(KEY_PROFILE_USERNAME) else prefs[KEY_PROFILE_USERNAME] = cleaned
            }
        }

        suspend fun setProfilePhotoBase64(value: String?) {
            dataStore.edit { prefs ->
                if (value.isNullOrBlank()) prefs.remove(KEY_PROFILE_PHOTO) else prefs[KEY_PROFILE_PHOTO] = value
            }
        }

        /**
         * TV look (owner design 2026-11-04): [PLAVIO_LOOK_FULL] = the
         * full frosted look, [PLAVIO_LOOK_LIGHT] = the same look drawn
         * cheap for low-end TVs. Null = never chosen (renders as Full);
         * the choice lives in Settings only (owner's cut, 2026-11-04).
         */
        val lookMode: StateFlow<String?> =
            dataStore.data
                .map { it[KEY_LOOK_MODE]?.takeIf { mode -> mode == PLAVIO_LOOK_FULL || mode == PLAVIO_LOOK_LIGHT } }
                .stateIn(scope, SharingStarted.Eagerly, null)

        suspend fun setLookMode(mode: String) {
            dataStore.edit { it[KEY_LOOK_MODE] = mode }
        }

        suspend fun lastUpdateCheckMs(): Long = dataStore.data.first()[KEY_LAST_UPDATE_CHECK] ?: 0L

        suspend fun setLastUpdateCheckMs(value: Long) {
            dataStore.edit { it[KEY_LAST_UPDATE_CHECK] = value }
        }

        private companion object {
            val KEY_ACCENT = stringPreferencesKey("accent")
            val KEY_AUTO_UPDATE = booleanPreferencesKey("auto_update_check")
            val KEY_AUTOPLAY_BEST = booleanPreferencesKey("autoplay_best_stream")
            val KEY_AUTOPLAY_NEXT = booleanPreferencesKey("autoplay_next_episode")
            val KEY_SUBTITLE_LANGUAGES = stringPreferencesKey("subtitle_languages")
            val KEY_PREFERRED_AUDIO_LANGUAGE = stringPreferencesKey("preferred_audio_language")
            val KEY_LAST_UPDATE_CHECK = longPreferencesKey("last_update_check")
            val KEY_SHOW_SKIP_INTRO = booleanPreferencesKey("show_skip_intro")
            val KEY_TORBOX_API_KEY = stringPreferencesKey("torbox_api_key")
            val KEY_REALDEBRID_API_KEY = stringPreferencesKey("realdebrid_api_key")
            val KEY_QUALITY_ORDER = stringPreferencesKey("quality_order")
            val KEY_STREAM_AUTOPLAY = booleanPreferencesKey("stream_autoplay")
            val KEY_AUTOPLAY_QUALITY = stringPreferencesKey("autoplay_quality")
            val KEY_HOME_ADDON_ORDER = stringPreferencesKey("home_addon_order")
            val KEY_HOME_HIDDEN_ADDONS = stringPreferencesKey("home_hidden_addons")
            val KEY_DEFAULT_CATALOG_ADDON = stringPreferencesKey("default_catalog_addon")
            val KEY_EPISODE_ALERTS = booleanPreferencesKey("episode_alerts")
            val KEY_BADGE_STYLE = stringPreferencesKey("badge_style")
            val KEY_BADGE_GROUP_RESOLUTION = booleanPreferencesKey("badge_group_resolution")
            val KEY_BADGE_GROUP_HDR = booleanPreferencesKey("badge_group_hdr")
            val KEY_BADGE_GROUP_AUDIO = booleanPreferencesKey("badge_group_audio")
            val KEY_BADGE_GROUP_LANGUAGES = booleanPreferencesKey("badge_group_languages")
            val KEY_BADGE_GROUP_SOURCE_CODEC = booleanPreferencesKey("badge_group_source_codec")
            val KEY_BADGE_GROUP_SIZE = booleanPreferencesKey("badge_group_size")
            val KEY_LOOK_MODE = stringPreferencesKey("look_mode")
            val KEY_PROFILE_NAME = stringPreferencesKey("profile_name")
            val KEY_PROFILE_USERNAME = stringPreferencesKey("profile_username")
            val KEY_PROFILE_PHOTO = stringPreferencesKey("profile_photo")
        }
    }

/** Canonical quality buckets for the streams rules, best first (phone parity). */
val QUALITY_ORDER_OPTIONS: List<String> = listOf("2160p", "1080p", "720p", "480p")

/** TV look values stored under [PlavioUiPrefs.lookMode] (owner design 2026-11-04). */
const val PLAVIO_LOOK_FULL = "full"
const val PLAVIO_LOOK_LIGHT = "light"
