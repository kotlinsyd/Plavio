import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.dsl.ProductFlavor
import com.android.build.api.variant.FilterConfiguration
import com.google.protobuf.gradle.id
import com.mikepenz.aboutlibraries.plugin.DuplicateMode
import com.mikepenz.aboutlibraries.plugin.DuplicateRule
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Base64
import java.util.Properties
import java.util.zip.ZipFile

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.protobuf)
    alias(libs.plugins.kotlin.plugin.serialization)
    alias(libs.plugins.aboutLibraries)
}

val isCI = providers.environmentVariable("CI").orElse("false").map { it.toBoolean() }
val shouldSign =
    isCI.zip(
        providers.environmentVariable("KEY_ALIAS").orElse("").map { it.isNotBlank() },
    ) { isCI, hasKey ->
        isCI && hasKey
    }
val ffmpegModuleExists =
    providers.provider { project.file("libs/lib-decoder-ffmpeg-release.aar").exists() }
val av1ModuleExists =
    providers.provider { project.file("libs/lib-decoder-av1-release.aar").exists() }
val extensionsRepoActive =
    providers.provider { project.hasProperty("WholphinExtensionsUsername") }

// See https://issuetracker.google.com/issues/402800800
val isBuildingBundle =
    providers.provider {
        gradle.startParameter.taskNames.any { it.lowercase().contains("bundle") }
    }

val gitTags =
    providers
        .exec { commandLine("git", "tag", "--list", "v*", "p*") }
        .standardOutput.asText
        .get()

val gitDescribe =
    providers
        .exec { commandLine("git", "describe", "--tags", "--long", "--match=v*") }
        .standardOutput.asText
        .getOrElse("v0.0.0")

kotlin {
    compilerOptions {
        languageVersion = org.jetbrains.kotlin.gradle.dsl.KotlinVersion.KOTLIN_2_3
        jvmTarget = JvmTarget.JVM_11
        javaParameters = true

        // Workaround for https://github.com/google/ksp/issues/2964
        moduleName = "${project.group}_${project.name}"
    }
}

private fun Provider<String>.getInt() = get().toInt()

configure<ApplicationExtension> {
    namespace = "com.github.damontecres.wholphin"
    compileSdk = libs.versions.compileSdk.getInt()

    defaultConfig {
        applicationId = "com.plavio.tv"
        minSdk = libs.versions.minSdk.getInt()
        targetSdk = libs.versions.targetSdk.getInt()
        // Plavio TV releases carry their own version, independent of the
        // Wholphin base's git-describe scheme (which read 1.0.9-x).
        versionCode = 48
        versionName = "0.3.24"
        // ARM only (v0.2.2): filters native libs in EVERY output,
        // including the universal APK — splits alone left x86 libs
        // from the MPV AAR and androidx.graphics in the universal.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        testInstrumentationRunner = "com.github.damontecres.wholphin.test.WholphinTestRunner"

        buildConfigField("long", "BUILD_TIME", System.currentTimeMillis().toString())
        // Gate key for the locked house addon. Passed at build time via
        // -PPLAVIO_GATE_KEY=... (or ORG_GRADLE_PROJECT_PLAVIO_GATE_KEY);
        // never committed.
        buildConfigField(
            "String",
            "PLAVIO_GATE_KEY",
            "\"${providers.gradleProperty("PLAVIO_GATE_KEY").orNull ?: ""}\"",
        )
        // Plavio account backend (Supabase), same build-time injection as
        // the phone app: -PPLAVIO_SUPABASE_URL / -PPLAVIO_SUPABASE_ANON_KEY
        // (or ORG_GRADLE_PROJECT_* env). Empty = account features hide.
        buildConfigField(
            "String",
            "PLAVIO_SUPABASE_URL",
            "\"${providers.gradleProperty("PLAVIO_SUPABASE_URL").orNull ?: ""}\"",
        )
        buildConfigField(
            "String",
            "PLAVIO_SUPABASE_ANON_KEY",
            "\"${providers.gradleProperty("PLAVIO_SUPABASE_ANON_KEY").orNull ?: ""}\"",
        )
        // Sentry DSN, injected at build time only (-PSENTRY_DSN=... or
        // ORG_GRADLE_PROJECT_SENTRY_DSN); never committed. Blank = crash
        // reporting inert.
        buildConfigField(
            "String",
            "SENTRY_DSN",
            "\"${providers.gradleProperty("SENTRY_DSN").orNull ?: ""}\"",
        )
        // MPV is removed entirely (v0.3.2): no MPV_AVAILABLE field —
        // nothing in the app branches on a second engine anymore.
    }

    signingConfigs {
        if (shouldSign.get()) {
            create("ci") {
                file("ci.keystore").writeBytes(
                    Base64.getDecoder().decode(System.getenv("SIGNING_KEY")),
                )
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
                storePassword = System.getenv("KEY_STORE_PASSWORD")
                storeFile = file("ci.keystore")
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            isDebuggable = false
            if (shouldSign.get()) {
                signingConfig = signingConfigs.getByName("ci")
            } else {
                val localPropertiesFile = project.rootProject.file("local.properties")
                if (localPropertiesFile.exists()) {
                    val properties = Properties()
                    properties.load(localPropertiesFile.inputStream())
                    val signingConfigName = properties["release.signing.config"]?.toString()
                    if (signingConfigName != null) {
                        signingConfig = signingConfigs.getByName(signingConfigName)
                    }
                }
            }
        }

        debug {
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
    }
    flavorDimensions += "version"
    productFlavors {
        val featureLeanback = "leanback"
        val featureUpdate = "UPDATING_ENABLED"
        val featureDiscover = "DISCOVER_ENABLED"

        fun ProductFlavor.setFeatureFlag(
            name: String,
            enabled: Boolean,
        ) {
            this.buildConfigField("boolean", name, "Boolean.parseBoolean(\"${enabled}\")")
        }
        create("default") {
            dimension = "version"
            isDefault = true
            manifestPlaceholders += mapOf(featureLeanback to false)
            // Plavio TV: in-app update checks are disabled until Plavio has
            // its own update feed — the app must never check Wholphin's
            // GitHub releases.
            setFeatureFlag(featureUpdate, false)
            setFeatureFlag(featureDiscover, true)
        }
        create("appstore") {
            dimension = "version"
            manifestPlaceholders += mapOf(featureLeanback to true)
            setFeatureFlag(featureUpdate, false)
            setFeatureFlag(featureDiscover, true)
        }
        create("firetv") {
            dimension = "version"
            manifestPlaceholders += mapOf(featureLeanback to true)
            setFeatureFlag(featureUpdate, false)
            setFeatureFlag(featureDiscover, false)
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }

    splits {
        abi {
            // Disable split abis when building bundles
            isEnable = !isBuildingBundle.get()

            reset()
            // ARM only (owner's v0.2.2 order): no x86 / x86_64 builds.
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = true
        }
    }
    packaging {
        jniLibs {
            // libass-android and the ffmpeg decoder AAR both package
            // libc++_shared.so; keep the first.
            pickFirsts += "lib/*/libc++_shared.so"
        }
        // Install-safety (v0.3.16 rebuild, 2026-11-06): the first 0.3.16
        // package refused to install on the owner's TV ("App not
        // installed") while 0.3.15 installed fine. The one payload that
        // changed shape in that build was the AGP-generated baseline
        // profile (assets/dexopt/baseline.prof came out ~19% smaller —
        // recompiled from week-old incremental state instead of fresh).
        // The profile is a pure startup-speed hint that Android verifies
        // and silently discards when it does not match, so the package
        // ships without it rather than risk a strict TV installer
        // rejecting the whole APK over a stale profile. Startup cost:
        // negligible (first-launch JIT only).
        resources {
            excludes += "**/assets/dexopt/baseline.prof"
            excludes += "**/assets/dexopt/baseline.profm"
        }
    }

    // The resources exclusion above notwithstanding, AGP wires the compiled
    // baseline profile into the package task outside the resources merger.
    // Hard guarantee for the v0.3.16 rebuild: delete the compiled profile
    // before packaging runs, so the shipped bytes provably contain no
    // baseline profile at all. (compileDefaultReleaseArtProfile will
    // recompile it on the next ordinary build; packaging no longer sees it.)
    tasks.matching { it.name == "packageDefaultRelease" }.configureEach {
        doFirst {
            delete(
                layout.buildDirectory.dir(
                    "intermediates/binary_art_profile/defaultRelease/compileDefaultReleaseArtProfile",
                ),
            )
            delete(
                layout.buildDirectory.dir(
                    "intermediates/binary_art_profile_metadata/defaultRelease/compileDefaultReleaseArtProfile",
                ),
            )
        }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }

    lint {
        disable.add("MissingTranslation")
    }
    androidResources {
        generateLocaleConfig = true
    }
}

androidComponents {
    onVariants(selector().all()) { variant ->
        variant.outputs
            .map { it as com.android.build.api.variant.impl.VariantOutputImpl }
            .forEach { output ->
                val abi =
                    output
                        .getFilter(FilterConfiguration.FilterType.ABI)
                        .let { if (it != null) "-${it.identifier}" else "" }
                val outputFileName =
                    "PlavioTV-${variant.flavorName}-${variant.buildType}-${output.versionName.get()}-${output.versionCode.get()}$abi.apk"
                output.outputFileName = outputFileName
            }
    }
}

protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:${libs.protobuf.kotlin.lite.get().version}"
    }
    generateProtoTasks {
        all().forEach {
            it.plugins {
                id("java") {
                    option("lite")
                }
            }
            it.builtins {
                id("kotlin") {
                    option("lite")
                }
            }
        }
    }
}
aboutLibraries {
    collect {
        configPath = file("config")
    }
    library {
        duplicationMode = DuplicateMode.MERGE
        duplicationRule = DuplicateRule.SIMPLE
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.runtime)
    implementation(libs.androidx.tv.foundation)
    implementation(libs.androidx.tv.material)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.datastore)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.protobuf.kotlin.lite)
    implementation(libs.androidx.tvprovider)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.hilt.work)
    implementation(libs.androidx.profileinstaller)

    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.session)
    implementation(libs.androidx.media3.datasource.okhttp)
    implementation(libs.androidx.media3.exoplayer.hls)
    implementation(libs.androidx.media3.exoplayer.dash)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.media3.ui.compose)
    implementation(libs.ass.media)

    implementation(libs.coil.core)
    implementation(libs.coil.compose)
    implementation(libs.coil.network.cachecontrol)
    implementation(libs.coil.network.okhttp)
    implementation(libs.coil.gif)
    implementation(libs.coil.svg)

    implementation(libs.androidx.navigation3.ui)
    implementation(libs.androidx.navigation3.runtime)
    implementation(libs.androidx.lifecycle.viewmodel.navigation3)
    implementation(libs.androidx.material3.adaptive.navigation3)
    implementation(libs.kotlinx.serialization.core)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.hilt.android)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.hilt.navigation.compose)
    implementation(libs.androidx.preference.ktx)
    implementation(libs.androidx.palette.ktx)
    implementation(libs.androidx.media3.effect)
    implementation(libs.androidx.runner)
    ksp(libs.hilt.android.compiler)
    ksp(libs.androidx.hilt.compiler)

    implementation(libs.timber)
    implementation(libs.slf4j2.timber)
    implementation(libs.aboutlibraries.core)
    implementation(libs.aboutlibraries.compose.m3)
    implementation(libs.multiplatform.markdown.renderer)
    implementation(libs.multiplatform.markdown.renderer.m3)
    implementation(libs.programguide)
    implementation(libs.sentry.android)
    compileOnly(libs.auto.service.annotations)
    ksp(libs.auto.service.ksp)
    implementation(platform(libs.okhttp.bom))
    implementation(libs.okhttp)
    implementation(libs.kache)
    implementation(libs.kache.file)

    coreLibraryDesugaring(libs.desugar.jdk.libs)

    if (ffmpegModuleExists.get()) {
        logger.info("Using local ffmpeg decoder")
        implementation(files("libs/lib-decoder-ffmpeg-release.aar"))
    } else if (extensionsRepoActive.get()) {
        logger.info("Using prebuilt ffmpeg decoder")
        implementation(libs.wholphin.extensions.ffmpeg)
    } else {
        logger.warn("Media3 ffmpeg decoder was NOT found")
    }
    if (av1ModuleExists.get()) {
        logger.info("Using local av1 decoder")
        implementation(files("libs/lib-decoder-av1-release.aar"))
    } else if (extensionsRepoActive.get()) {
        logger.info("Using prebuilt av1 decoder")
        implementation(libs.wholphin.extensions.av1)
    } else {
        logger.warn("Media3 av1 decoder was NOT found")
    }
    // No MPV dependency (v0.3.2): ExoPlayer is the only engine. The
    // verifyNoMpvInApk gate below fails the release if libmpv ever
    // sneaks back into a package.

    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
    testImplementation(libs.mockk.android)
    testImplementation(libs.mockk.agent)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.androidx.core.testing)
    testImplementation(libs.robolectric)
    testImplementation(libs.hilt.android.testing)
    testImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.mockk.android)
    androidTestImplementation(libs.hilt.android.testing)
    androidTestImplementation(libs.androidx.compose.ui.test.manifest)
}

/**
 * Release gate (v0.3.2): MPV is removed — after every default-release
 * assemble, verify NO shipped APK carries libmpv/libplayer for any
 * ABI, and that the ARM-only packaging still holds (no x86 libs).
 * Fails the build otherwise.
 */
val verifyNoMpvInApk =
    tasks.register("verifyNoMpvInApk") {
        group = "verification"
        description = "Fails if any release APK contains libmpv/libplayer or x86 native libraries."
        doLast {
            val apkDir =
                layout.buildDirectory
                    .dir("outputs/apk/default/release")
                    .get()
                    .asFile
            val apks =
                apkDir
                    .listFiles()
                    ?.filter { it.name.endsWith(".apk") }
                    ?: throw GradleException("verifyNoMpvInApk: no release APKs found in $apkDir")
            if (apks.isEmpty()) {
                throw GradleException("verifyNoMpvInApk: no release APKs found in $apkDir")
            }
            apks.forEach { apk ->
                ZipFile(apk).use { zip ->
                    val names = zip.entries().asSequence().map { it.name }.toList()
                    val mpvLibs =
                        names.filter {
                            it.endsWith("libmpv.so") || it.endsWith("libplayer.so")
                        }
                    if (mpvLibs.isNotEmpty()) {
                        throw GradleException(
                            "verifyNoMpvInApk: MPV libraries present in ${apk.name}: $mpvLibs",
                        )
                    }
                    val x86Libs = names.filter { it.startsWith("lib/x86") }
                    if (x86Libs.isNotEmpty()) {
                        throw GradleException(
                            "verifyNoMpvInApk: x86 libraries present in ${apk.name}: ${x86Libs.take(3)}",
                        )
                    }
                }
            }
            logger.lifecycle("verifyNoMpvInApk: no MPV libraries in ${apks.size} release APKs; ARM only.")
        }
    }
tasks.matching { it.name == "assembleDefaultRelease" }.configureEach {
    finalizedBy(verifyNoMpvInApk)
}
